//! Layer header definitions for multi-layer execution.
//!
//! This module provides types for describing layers in a `.holo` bundle,
//! including their entrypoints, I/O ports, and execution schedule.
//!
//! # Example
//!
//! ```rust
//! use hologram_holo::layer_header::{
//!     LayerHeader, LayerDescriptor, LayerEntrypoint, LayerId, TensorPort,
//! };
//!
//! let mut header = LayerHeader::new();
//!
//! let encoder = LayerDescriptor {
//!     id: LayerId::new(0),
//!     name: "encoder".to_string(),
//!     entrypoint: LayerEntrypoint::default_for("encoder"),
//!     inputs: vec![TensorPort::new("input", vec![-1, 512], 0)],
//!     outputs: vec![TensorPort::new("hidden", vec![-1, 768], 0)],
//!     group: 0,
//!     plane: 0,
//!     plan_offset: Some(1024),
//!     plan_size: Some(4096),
//! };
//!
//! let id = header.add_layer(encoder);
//! header.add_schedule_level(vec![id]);
//! ```

// Allow casts in this module since layer counts won't exceed u32 in practice.
#![allow(clippy::cast_possible_truncation)]

use std::collections::HashSet;

use rkyv::{Archive, Deserialize, Serialize};
use thiserror::Error;

use crate::traits::{EmbeddableSection, FromEmbeddedSection};
use crate::{HoloError, Result};

// ============================================================================
// Core Types
// ============================================================================

/// Unique identifier for a layer within a bundle.
///
/// Layer IDs are sequential u32 values assigned at compile time.
/// This provides O(1) lookup in arrays while remaining compact.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct LayerId(u32);

impl LayerId {
    /// Create a new layer ID.
    #[must_use]
    pub const fn new(id: u32) -> Self {
        Self(id)
    }

    /// Get the raw ID value.
    #[must_use]
    pub const fn raw(self) -> u32 {
        self.0
    }
}

impl From<u32> for LayerId {
    fn from(id: u32) -> Self {
        Self(id)
    }
}

impl From<LayerId> for u32 {
    fn from(id: LayerId) -> Self {
        id.0
    }
}

/// Entrypoint symbol for invoking a layer.
///
/// The symbol follows the convention `{layer_name}::run` by default.
#[derive(Debug, Clone, PartialEq, Eq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct LayerEntrypoint {
    /// Symbol to resolve in the compiled artifact (e.g., `"encoder::run"`).
    pub symbol: String,
}

impl LayerEntrypoint {
    /// Create a new entrypoint with the given symbol.
    #[must_use]
    pub fn new(symbol: impl Into<String>) -> Self {
        Self {
            symbol: symbol.into(),
        }
    }

    /// Create the default entrypoint for a layer name.
    ///
    /// Follows the convention `{name}::run`.
    #[must_use]
    pub fn default_for(name: &str) -> Self {
        Self {
            symbol: format!("{name}::run"),
        }
    }
}

impl Default for LayerEntrypoint {
    fn default() -> Self {
        Self {
            symbol: String::from("main::run"),
        }
    }
}

/// Describes an input or output port for a layer.
///
/// Ports define the expected shape and data type for tensors
/// flowing between layers.
#[derive(Debug, Clone, PartialEq, Eq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct TensorPort {
    /// Port name (e.g., "input", "hidden", "output").
    pub name: String,

    /// Shape specification. Negative values indicate symbolic dimensions.
    /// -1 typically means batch dimension, -2 sequence length, etc.
    pub shape: Vec<i64>,

    /// Data type identifier (matches `DType` encoding: 0=F32, 1=F64, etc.).
    pub dtype: u8,
}

impl TensorPort {
    /// Create a new tensor port.
    #[must_use]
    pub fn new(name: impl Into<String>, shape: Vec<i64>, dtype: u8) -> Self {
        Self {
            name: name.into(),
            shape,
            dtype,
        }
    }
}

// ============================================================================
// Layer Descriptor
// ============================================================================

/// Complete metadata for a single layer in the bundle.
///
/// Describes the layer's identity, entrypoint, I/O signature,
/// and execution grouping.
#[derive(Debug, Clone, PartialEq, Eq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct LayerDescriptor {
    /// Unique layer identifier.
    pub id: LayerId,

    /// Human-readable name (e.g., "encoder", "attention\_0").
    pub name: String,

    /// Entrypoint symbol to invoke this layer.
    pub entrypoint: LayerEntrypoint,

    /// Input ports expected by this layer.
    pub inputs: Vec<TensorPort>,

    /// Output ports produced by this layer.
    pub outputs: Vec<TensorPort>,

    /// Execution group for scheduling.
    ///
    /// Layers in the same group at the same level can run in parallel.
    pub group: u32,

    /// Memory plane for zero-copy buffer sharing.
    ///
    /// Layers on the same plane share memory space.
    pub plane: u32,

    /// Offset into the bundle where this layer's `BackendPlan` is stored.
    ///
    /// Used for embedded layers. External layers use `LayerLocation`.
    pub plan_offset: Option<u64>,

    /// Size of the layer's `BackendPlan` in bytes.
    pub plan_size: Option<u64>,
}

impl Default for LayerDescriptor {
    fn default() -> Self {
        Self {
            id: LayerId::new(0),
            name: String::new(),
            entrypoint: LayerEntrypoint::default(),
            inputs: Vec::new(),
            outputs: Vec::new(),
            group: 0,
            plane: 0,
            plan_offset: None,
            plan_size: None,
        }
    }
}

// ============================================================================
// Layer Header
// ============================================================================

/// Header describing all layers and their execution schedule.
///
/// The schedule defines the order of layer execution:
/// - Layers within the same schedule level can execute in parallel
/// - Schedule levels execute sequentially
#[derive(Debug, Clone, PartialEq, Eq, Default, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct LayerHeader {
    /// All layer descriptors, indexed by `LayerId`.
    pub layers: Vec<LayerDescriptor>,

    /// Execution schedule as levels of parallel layer groups.
    ///
    /// Each inner Vec contains `LayerId`s that can execute concurrently.
    /// The outer Vec represents sequential execution levels.
    ///
    /// Example: `[[0, 1], [2]]` means layers 0 and 1 run in parallel,
    /// then layer 2 runs after both complete.
    pub schedule: Vec<Vec<LayerId>>,
}

impl LayerHeader {
    /// Create an empty layer header.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Add a layer descriptor and return its ID.
    ///
    /// The layer's ID field is overwritten with the next sequential ID.
    pub fn add_layer(&mut self, mut descriptor: LayerDescriptor) -> LayerId {
        let id = LayerId::new(self.layers.len() as u32);
        descriptor.id = id;
        self.layers.push(descriptor);
        id
    }

    /// Add an execution schedule level.
    ///
    /// Layers in the same level can execute in parallel.
    pub fn add_schedule_level(&mut self, layer_ids: Vec<LayerId>) {
        self.schedule.push(layer_ids);
    }

    /// Get a layer descriptor by ID.
    #[must_use]
    pub fn get(&self, id: LayerId) -> Option<&LayerDescriptor> {
        self.layers.get(id.raw() as usize)
    }

    /// Get a mutable layer descriptor by ID.
    #[must_use]
    pub fn get_mut(&mut self, id: LayerId) -> Option<&mut LayerDescriptor> {
        self.layers.get_mut(id.raw() as usize)
    }

    /// Get a layer descriptor by name.
    #[must_use]
    pub fn get_by_name(&self, name: &str) -> Option<&LayerDescriptor> {
        self.layers.iter().find(|l| l.name == name)
    }

    /// Get the number of layers.
    #[must_use]
    pub fn len(&self) -> usize {
        self.layers.len()
    }

    /// Check if the header has no layers.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.layers.is_empty()
    }

    /// Iterate over schedule levels.
    pub fn schedule_levels(&self) -> impl Iterator<Item = &[LayerId]> {
        self.schedule.iter().map(Vec::as_slice)
    }

    /// Validate the header for consistency.
    ///
    /// # Errors
    ///
    /// Returns error if:
    /// - Any scheduled `LayerId` doesn't exist in layers
    /// - Duplicate layer IDs exist
    /// - Duplicate layer names exist
    /// - A layer is not in any schedule level
    pub fn validate(&self) -> std::result::Result<(), LayerHeaderError> {
        // Check for duplicate layer IDs
        let mut seen_ids: HashSet<u32> = HashSet::new();
        for layer in &self.layers {
            if !seen_ids.insert(layer.id.raw()) {
                return Err(LayerHeaderError::DuplicateLayerId(layer.id.raw()));
            }
        }

        // Check for duplicate layer names
        let mut seen_names: HashSet<&str> = HashSet::new();
        for layer in &self.layers {
            if !layer.name.is_empty() && !seen_names.insert(&layer.name) {
                return Err(LayerHeaderError::DuplicateName(layer.name.clone()));
            }
        }

        // Check all scheduled IDs exist
        let mut scheduled_ids: HashSet<u32> = HashSet::new();
        for level in &self.schedule {
            for id in level {
                if id.raw() as usize >= self.layers.len() {
                    return Err(LayerHeaderError::UnknownLayerId(id.raw()));
                }
                scheduled_ids.insert(id.raw());
            }
        }

        // Check all layers are scheduled (unless schedule is empty)
        if !self.schedule.is_empty() {
            for layer in &self.layers {
                if !scheduled_ids.contains(&layer.id.raw()) {
                    return Err(LayerHeaderError::UnscheduledLayer(layer.id.raw()));
                }
            }
        }

        Ok(())
    }
}

// ============================================================================
// Error Types
// ============================================================================

/// Layer header validation errors.
#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum LayerHeaderError {
    /// Layer ID in schedule not found in layers list.
    #[error("unknown layer ID {0} in schedule")]
    UnknownLayerId(u32),

    /// Duplicate layer ID.
    #[error("duplicate layer ID {0}")]
    DuplicateLayerId(u32),

    /// Duplicate layer name.
    #[error("duplicate layer name '{0}'")]
    DuplicateName(String),

    /// Layer not in any schedule level.
    #[error("layer {0} not scheduled for execution")]
    UnscheduledLayer(u32),
}

// ============================================================================
// LayerHeaderSection (EmbeddableSection Implementation)
// ============================================================================

/// Embeddable section wrapper for `LayerHeader`.
///
/// Allows layer headers to be embedded in HOLB bundles using
/// the standard `EmbeddableSection` trait.
#[derive(Debug, Clone)]
pub struct LayerHeaderSection {
    /// The layer header data.
    pub header: LayerHeader,
}

impl LayerHeaderSection {
    /// Section identifier.
    pub const SECTION_ID: &'static str = "layer_header";

    /// Content type for layer headers.
    pub const CONTENT_TYPE: &'static str = "application/vnd.hologram.layer-header";

    /// Current format version.
    pub const VERSION: u32 = 1;

    /// Create a new section from a layer header.
    #[must_use]
    pub fn new(header: LayerHeader) -> Self {
        Self { header }
    }

    /// Consume the section and return the inner header.
    #[must_use]
    pub fn into_header(self) -> LayerHeader {
        self.header
    }
}

impl EmbeddableSection for LayerHeaderSection {
    fn section_id(&self) -> &'static str {
        Self::SECTION_ID
    }

    fn to_bytes(&self) -> Vec<u8> {
        rkyv::to_bytes::<_, 256>(&self.header)
            .map(|bytes| bytes.to_vec())
            .unwrap_or_default()
    }

    fn content_type(&self) -> &'static str {
        Self::CONTENT_TYPE
    }

    fn version(&self) -> u32 {
        Self::VERSION
    }
}

impl FromEmbeddedSection for LayerHeaderSection {
    const SECTION_ID: &'static str = "layer_header";

    fn from_bytes(bytes: &[u8]) -> Result<Self> {
        let header = rkyv::from_bytes::<LayerHeader>(bytes)
            .map_err(|e| HoloError::Deserialization(format!("layer header: {e}")))?;
        Ok(Self { header })
    }

    fn expected_version() -> u32 {
        Self::VERSION
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_layer_id_roundtrip() {
        let id = LayerId::new(42);
        assert_eq!(id.raw(), 42);
    }

    #[test]
    fn test_layer_id_conversions() {
        let id = LayerId::from(123u32);
        let raw: u32 = id.into();
        assert_eq!(raw, 123);
    }

    #[test]
    fn test_layer_entrypoint_default() {
        let ep = LayerEntrypoint::default_for("encoder");
        assert_eq!(ep.symbol, "encoder::run");
    }

    #[test]
    fn test_layer_entrypoint_custom() {
        let ep = LayerEntrypoint::new("custom::entry");
        assert_eq!(ep.symbol, "custom::entry");
    }

    #[test]
    fn test_tensor_port_creation() {
        let port = TensorPort::new("input", vec![-1, 128], 0);
        assert_eq!(port.name, "input");
        assert_eq!(port.shape, vec![-1, 128]);
        assert_eq!(port.dtype, 0);
    }

    #[test]
    fn test_layer_header_add_and_get() {
        let mut header = LayerHeader::new();
        let desc = LayerDescriptor {
            name: "encoder".to_string(),
            entrypoint: LayerEntrypoint::default_for("encoder"),
            ..Default::default()
        };
        let id = header.add_layer(desc);

        assert_eq!(header.len(), 1);
        assert_eq!(header.get(id).unwrap().name, "encoder");
        assert_eq!(header.get(id).unwrap().id, id);
    }

    #[test]
    fn test_layer_header_get_by_name() {
        let mut header = LayerHeader::new();
        header.add_layer(LayerDescriptor {
            name: "encoder".to_string(),
            ..Default::default()
        });
        header.add_layer(LayerDescriptor {
            name: "decoder".to_string(),
            ..Default::default()
        });

        assert!(header.get_by_name("encoder").is_some());
        assert!(header.get_by_name("decoder").is_some());
        assert!(header.get_by_name("nonexistent").is_none());
    }

    #[test]
    fn test_layer_header_schedule() {
        let mut header = LayerHeader::new();
        let id0 = header.add_layer(LayerDescriptor::default());
        let id1 = header.add_layer(LayerDescriptor::default());
        let id2 = header.add_layer(LayerDescriptor::default());

        header.add_schedule_level(vec![id0, id1]);
        header.add_schedule_level(vec![id2]);

        assert_eq!(header.schedule.len(), 2);
        assert_eq!(header.schedule[0].len(), 2);
        assert_eq!(header.schedule[1].len(), 1);
    }

    #[test]
    fn test_layer_header_schedule_levels_iterator() {
        let mut header = LayerHeader::new();
        let id0 = header.add_layer(LayerDescriptor::default());
        let id1 = header.add_layer(LayerDescriptor::default());

        header.add_schedule_level(vec![id0]);
        header.add_schedule_level(vec![id1]);

        let levels: Vec<_> = header.schedule_levels().collect();
        assert_eq!(levels.len(), 2);
    }

    #[test]
    fn test_layer_header_validation_success() {
        let mut header = LayerHeader::new();
        let id0 = header.add_layer(LayerDescriptor {
            name: "layer0".to_string(),
            ..Default::default()
        });
        let id1 = header.add_layer(LayerDescriptor {
            name: "layer1".to_string(),
            ..Default::default()
        });

        header.add_schedule_level(vec![id0, id1]);

        assert!(header.validate().is_ok());
    }

    #[test]
    fn test_layer_header_validation_unknown_id() {
        let header = LayerHeader {
            layers: vec![],
            schedule: vec![vec![LayerId::new(99)]],
        };
        assert!(matches!(
            header.validate(),
            Err(LayerHeaderError::UnknownLayerId(99))
        ));
    }

    #[test]
    fn test_layer_header_validation_duplicate_name() {
        let mut header = LayerHeader::new();
        header.add_layer(LayerDescriptor {
            name: "same".to_string(),
            ..Default::default()
        });
        // Manually push to bypass ID assignment
        header.layers.push(LayerDescriptor {
            id: LayerId::new(1),
            name: "same".to_string(),
            ..Default::default()
        });

        assert!(matches!(
            header.validate(),
            Err(LayerHeaderError::DuplicateName(_))
        ));
    }

    #[test]
    fn test_layer_header_validation_unscheduled() {
        let mut header = LayerHeader::new();
        let id0 = header.add_layer(LayerDescriptor::default());
        header.add_layer(LayerDescriptor::default()); // id1 not scheduled

        header.add_schedule_level(vec![id0]);

        assert!(matches!(
            header.validate(),
            Err(LayerHeaderError::UnscheduledLayer(1))
        ));
    }

    #[test]
    fn test_layer_header_validation_empty_schedule_ok() {
        let mut header = LayerHeader::new();
        header.add_layer(LayerDescriptor::default());
        // Empty schedule is valid (all layers unscheduled is OK when no schedule)
        assert!(header.validate().is_ok());
    }

    #[test]
    fn test_layer_header_section_roundtrip() {
        let mut header = LayerHeader::new();
        header.add_layer(LayerDescriptor {
            name: "test".to_string(),
            entrypoint: LayerEntrypoint::new("test::run"),
            inputs: vec![TensorPort::new("in", vec![-1, 64], 0)],
            outputs: vec![TensorPort::new("out", vec![-1, 64], 0)],
            plan_offset: Some(1024),
            plan_size: Some(4096),
            ..Default::default()
        });
        header.add_schedule_level(vec![LayerId::new(0)]);

        let section = LayerHeaderSection::new(header.clone());

        // Check section metadata
        assert_eq!(section.section_id(), "layer_header");
        assert_eq!(
            section.content_type(),
            "application/vnd.hologram.layer-header"
        );
        assert_eq!(section.version(), 1);

        // Roundtrip
        let bytes = section.to_bytes();
        assert!(!bytes.is_empty());

        let restored = LayerHeaderSection::from_bytes(&bytes).unwrap();
        assert_eq!(restored.header, header);
    }

    #[test]
    fn test_layer_header_section_empty() {
        let header = LayerHeader::new();
        let section = LayerHeaderSection::new(header);

        let bytes = section.to_bytes();
        let restored = LayerHeaderSection::from_bytes(&bytes).unwrap();

        assert!(restored.header.is_empty());
    }

    #[test]
    fn test_layer_descriptor_default() {
        let desc = LayerDescriptor::default();
        assert_eq!(desc.id.raw(), 0);
        assert!(desc.name.is_empty());
        assert!(desc.inputs.is_empty());
        assert!(desc.outputs.is_empty());
        assert!(desc.plan_offset.is_none());
    }

    #[test]
    fn test_layer_header_get_mut() {
        let mut header = LayerHeader::new();
        let id = header.add_layer(LayerDescriptor {
            name: "original".to_string(),
            ..Default::default()
        });

        if let Some(desc) = header.get_mut(id) {
            desc.name = "modified".to_string();
        }

        assert_eq!(header.get(id).unwrap().name, "modified");
    }

    #[test]
    fn test_layer_header_multiple_layers_with_offsets() {
        let mut header = LayerHeader::new();

        let encoder = header.add_layer(LayerDescriptor {
            name: "encoder".to_string(),
            entrypoint: LayerEntrypoint::default_for("encoder"),
            inputs: vec![TensorPort::new("tokens", vec![-1, 512], 0)],
            outputs: vec![TensorPort::new("hidden", vec![-1, 768], 0)],
            plan_offset: Some(1024),
            plan_size: Some(8192),
            ..Default::default()
        });

        let decoder = header.add_layer(LayerDescriptor {
            name: "decoder".to_string(),
            entrypoint: LayerEntrypoint::default_for("decoder"),
            inputs: vec![TensorPort::new("hidden", vec![-1, 768], 0)],
            outputs: vec![TensorPort::new("logits", vec![-1, 50257], 0)],
            plan_offset: Some(9216),
            plan_size: Some(16384),
            ..Default::default()
        });

        // Sequential execution
        header.add_schedule_level(vec![encoder]);
        header.add_schedule_level(vec![decoder]);

        assert!(header.validate().is_ok());
        assert_eq!(header.len(), 2);

        // Verify offsets
        let enc = header.get_by_name("encoder").unwrap();
        assert_eq!(enc.plan_offset, Some(1024));

        let dec = header.get_by_name("decoder").unwrap();
        assert_eq!(dec.plan_offset, Some(9216));
    }
}
