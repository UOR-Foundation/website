//! `InstructionDispatcher` trait implementation for CPU backend.
//!
//! This module implements the unified dispatch trait for `ExecutionContext`,
//! enabling the CPU backend to use the shared dispatch function.

// Standard matrix variable names (m, n, k, a, b, c) are conventional in linear algebra
#![allow(clippy::many_single_char_names)]

use crate::backends::dispatch_unified::InstructionDispatcher;
use crate::types::Result;

use super::context::ExecutionContext;
use super::dispatch;

// Generated from descriptors/shells/isa.shell — see specs/research/shell-dsl-isa-codegen.md
include!(concat!(env!("OUT_DIR"), "/generated_dispatcher_impl.rs"));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::backends::cpu::BufferManager;
    use crate::backends::dispatch_unified::ExecuteOn;
    use hologram_holo::types::BufferType;
    use hologram_holo::{BufferMetadata, IsaInstruction};

    /// Helper to convert f32 slice to aligned byte buffer
    fn f32_to_bytes(data: &[f32]) -> Vec<u8> {
        data.iter().flat_map(|f| f.to_ne_bytes()).collect()
    }

    fn make_metadata(types: &[BufferType], sizes: &[usize]) -> Vec<BufferMetadata> {
        types
            .iter()
            .zip(sizes.iter())
            .map(|(&bt, &sz)| BufferMetadata::new(sz, bt))
            .collect()
    }

    fn make_node_map(count: usize) -> Vec<Option<u32>> {
        #[allow(clippy::cast_possible_truncation)]
        (0..count).map(|i| Some(i as u32)).collect()
    }

    #[test]
    fn test_cpu_dispatcher_add() {
        // Set up buffers: 2 inputs, 1 workspace for result
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[16, 16, 16],
        );
        let a_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
        let b_bytes = f32_to_bytes(&[0.5, 0.5, 0.5, 0.5]);
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        // Use unified dispatch
        let instr = IsaInstruction::Add {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        };
        instr.execute(&mut ctx).unwrap();

        // Verify result: [1+0.5, 2+0.5, 3+0.5, 4+0.5] = [1.5, 2.5, 3.5, 4.5]
        let result = ctx.read_f32(2, 4).unwrap();
        assert_eq!(result, &[1.5, 2.5, 3.5, 4.5]);
    }

    #[test]
    fn test_cpu_dispatcher_sigmoid() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[16, 16]);
        let input_bytes = f32_to_bytes(&[0.0, 1.0, -1.0, 2.0]);
        let inputs: &[&[u8]] = &[&input_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Sigmoid {
            dst: 1,
            src: 0,
            count: 4,
        };
        instr.execute(&mut ctx).unwrap();

        let result = ctx.read_f32(1, 4).unwrap();
        // sigmoid(0) = 0.5, sigmoid(1) ≈ 0.731, sigmoid(-1) ≈ 0.269, sigmoid(2) ≈ 0.881
        assert!((result[0] - 0.5).abs() < 0.01);
        assert!((result[1] - 0.731).abs() < 0.01);
        assert!((result[2] - 0.269).abs() < 0.01);
        assert!((result[3] - 0.881).abs() < 0.01);
    }
}
