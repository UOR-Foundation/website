//! Loader for `.holb` and `.holm` archives.
//!
//! This module provides memory-mapped loading of compiled plans with
//! zero-copy access to instructions and constants. Supports both
//! synchronous and async loading (with the `async` feature).
//!
//! # Multi-Model Pipeline Access
//!
//! For HOLM pipelines containing multiple models, use [`HoloLoader::load_pipeline`]
//! to get a [`LoadedPipeline`] that provides access to all models by name or index.
//!
//! ```rust,no_run
//! # use hologram_holo::loader::{HoloLoader, LoadedPipeline};
//! # fn example() -> hologram_holo::Result<()> {
//! let pipeline = HoloLoader::load_pipeline("models.holo")?;
//! println!("Pipeline has {} models", pipeline.model_count());
//!
//! // Access by name
//! if let Some(plan) = pipeline.get_model("encoder")? {
//!     println!("Encoder has {} instructions", plan.instructions.len());
//! }
//!
//! // Iterate all models
//! for name in pipeline.model_names() {
//!     println!("Model: {name}");
//! }
//! # Ok(())
//! # }
//! ```

#[cfg(feature = "async")]
use tokio::fs::File;
#[cfg(feature = "async")]
use tokio::io::AsyncReadExt;

use memmap2::Mmap;
use std::fs::File as StdFile;
use std::path::Path;
use std::sync::Arc;

use crate::error::HoloError;
use crate::format::{
    crc32, HolbHeader, HolmHeader, PipelineModelEntry, HOLB_MAGIC, HOLM_HEADER_SIZE,
};
use crate::instruction::{ArchivedBackendPlan, BackendPlan};
use crate::Result;

/// Loaded plan with memory-mapped data.
///
/// The plan maintains a reference to the memory-mapped file to ensure
/// zero-copy access to instructions and constants.
pub struct LoadedPlan {
    /// Memory-mapped archive data
    _mmap: Mmap,

    /// Zero-copy reference to archived plan
    plan: &'static ArchivedBackendPlan,
}

impl LoadedPlan {
    /// Get a reference to the archived plan.
    #[must_use]
    pub const fn plan(&self) -> &ArchivedBackendPlan {
        self.plan
    }

    /// Get the plan's constant data (zero-copy).
    #[must_use]
    pub fn constants(&self) -> &[u8] {
        &self.plan.constants
    }
}

/// Entry for a model in a loaded pipeline.
#[derive(Debug, Clone)]
pub struct PipelineEntry {
    /// Model name
    pub name: String,
    /// Offset in mmap to model data
    pub offset: usize,
    /// Size of model data
    pub size: usize,
    /// CRC32 checksum
    pub checksum: u32,
}

/// Loaded pipeline with multi-model access.
///
/// Provides access to all models in a HOLM pipeline by name or index.
/// The underlying memory-mapped data is shared via `Arc` so cloning
/// the pipeline is cheap.
pub struct LoadedPipeline {
    /// Shared memory-mapped archive data
    mmap: Arc<Mmap>,

    /// Model entries (name, offset, size, checksum)
    entries: Vec<PipelineEntry>,
}

impl LoadedPipeline {
    /// Get the number of models in the pipeline.
    #[must_use]
    pub fn model_count(&self) -> usize {
        self.entries.len()
    }

    /// Get the names of all models in the pipeline.
    #[must_use]
    pub fn model_names(&self) -> Vec<&str> {
        self.entries.iter().map(|e| e.name.as_str()).collect()
    }

    /// Check if a model with the given name exists.
    #[must_use]
    pub fn has_model(&self, name: &str) -> bool {
        self.entries.iter().any(|e| e.name == name)
    }

    /// Get a model by name.
    ///
    /// # Errors
    /// Returns error if the model data is corrupted (checksum mismatch).
    pub fn get_model(&self, name: &str) -> Result<Option<&ArchivedBackendPlan>> {
        let Some(entry) = self.entries.iter().find(|e| e.name == name) else {
            return Ok(None);
        };
        self.load_model_at(entry).map(Some)
    }

    /// Get a model by index.
    ///
    /// # Errors
    /// Returns error if index is out of bounds or model data is corrupted.
    pub fn get_model_by_index(&self, index: usize) -> Result<&ArchivedBackendPlan> {
        let entry = self.entries.get(index).ok_or_else(|| {
            HoloError::Other(format!(
                "Model index {index} out of bounds (pipeline has {} models)",
                self.entries.len()
            ))
        })?;
        self.load_model_at(entry)
    }

    /// Get the first (primary) model.
    ///
    /// # Errors
    /// Returns error if pipeline is empty or model data is corrupted.
    pub fn primary_model(&self) -> Result<&ArchivedBackendPlan> {
        self.get_model_by_index(0)
    }

    /// Load a model from its entry.
    #[allow(clippy::cast_possible_truncation)]
    fn load_model_at(&self, entry: &PipelineEntry) -> Result<&ArchivedBackendPlan> {
        let model_bytes = &self.mmap[entry.offset..entry.offset + entry.size];

        // The model is a HOLB bundle - parse its header and get the graph
        if model_bytes.len() < 4 || &model_bytes[0..4] != HOLB_MAGIC {
            return Err(HoloError::invalid_magic(HOLB_MAGIC, &model_bytes[0..4]));
        }

        let holb_header = HolbHeader::from_bytes(model_bytes)?;
        let graph_start = holb_header.graph_offset as usize;
        let graph_end = graph_start + holb_header.graph_size as usize;

        if graph_end > model_bytes.len() {
            return Err(HoloError::invalid_bounds(
                graph_start,
                holb_header.graph_size as usize,
                model_bytes.len(),
            ));
        }

        // Verify graph checksum
        let graph_bytes = &model_bytes[graph_start..graph_end];
        let graph_checksum = crc32(graph_bytes);
        if graph_checksum != holb_header.graph_checksum {
            return Err(HoloError::checksum_mismatch(
                holb_header.graph_checksum,
                graph_checksum,
            ));
        }

        // Get archived plan (zero-copy)
        let archived_plan = unsafe {
            // SAFETY: We verified checksum and bounds
            rkyv::archived_root::<BackendPlan>(graph_bytes)
        };

        Ok(archived_plan)
    }

    /// Iterate over all models in order.
    ///
    /// # Errors
    /// Returns error if any model data is corrupted.
    pub fn iter_models(&self) -> impl Iterator<Item = Result<(&str, &ArchivedBackendPlan)>> + '_ {
        self.entries.iter().map(|entry| {
            let plan = self.load_model_at(entry)?;
            Ok((entry.name.as_str(), plan))
        })
    }
}

/// Async loader for .holo files.
pub struct HoloLoader;

impl HoloLoader {
    /// Load archive file synchronously (.holb or .holo).
    ///
    /// For HOLM pipelines, this loads only the first (primary) model.
    /// Use [`load_pipeline`] for multi-model access.
    ///
    /// # Errors
    /// Returns error if:
    /// - File cannot be opened
    /// - File format is invalid
    /// - Checksums don't match
    /// - rkyv deserialization fails
    pub fn load<P: AsRef<Path>>(path: P) -> Result<LoadedPlan> {
        let file = StdFile::open(path)?;
        let mmap = unsafe { Mmap::map(&file)? };

        // Check magic bytes and dispatch
        if mmap.len() < 4 {
            return Err(HoloError::file_too_small(4, mmap.len()));
        }

        let magic = &mmap[0..4];
        match magic {
            b"HOLB" => Self::load_holb(mmap),
            b"HOLM" => Self::load_holm(mmap),
            _ => Err(HoloError::invalid_magic(HOLB_MAGIC, magic)),
        }
    }

    /// Load a HOLM pipeline with multi-model access.
    ///
    /// Returns a [`LoadedPipeline`] that provides access to all models
    /// by name or index.
    ///
    /// # Errors
    /// Returns error if:
    /// - File cannot be opened
    /// - File is not a valid HOLM pipeline
    /// - Checksums don't match
    /// - Any model data is invalid
    pub fn load_pipeline<P: AsRef<Path>>(path: P) -> Result<LoadedPipeline> {
        let file = StdFile::open(path)?;
        let mmap = unsafe { Mmap::map(&file)? };

        // Check magic bytes
        if mmap.len() < 4 {
            return Err(HoloError::file_too_small(4, mmap.len()));
        }

        let magic = &mmap[0..4];
        if magic != b"HOLM" {
            return Err(HoloError::invalid_magic(b"HOLM", magic));
        }

        Self::load_holm_pipeline(mmap)
    }

    /// Load HOLM as a pipeline with multi-model access.
    #[allow(clippy::cast_possible_truncation)]
    fn load_holm_pipeline(mmap: Mmap) -> Result<LoadedPipeline> {
        // Parse header
        if mmap.len() < HOLM_HEADER_SIZE {
            return Err(HoloError::file_too_small(HOLM_HEADER_SIZE, mmap.len()));
        }

        let header = HolmHeader::from_bytes(&mmap)?;

        // Verify model count
        if header.model_count == 0 {
            return Err(HoloError::EmptyBundle);
        }

        // Verify index bounds
        let index_start = header.index_offset as usize;
        let index_end = index_start + header.index_size as usize;
        if index_end > mmap.len() {
            return Err(HoloError::invalid_bounds(
                index_start,
                header.index_size as usize,
                mmap.len(),
            ));
        }

        // Verify index checksum
        let index_bytes = &mmap[index_start..index_end];
        let computed_checksum = crc32(index_bytes);
        if computed_checksum != header.index_checksum {
            return Err(HoloError::checksum_mismatch(
                header.index_checksum,
                computed_checksum,
            ));
        }

        // Parse model index entries
        let raw_entries = Self::parse_model_entries(index_bytes, header.model_count as usize)?;

        // Validate all model entries and convert to PipelineEntry
        let mut entries = Vec::with_capacity(raw_entries.len());
        for raw in &raw_entries {
            let model_start = raw.offset as usize;
            let model_end = model_start + raw.size as usize;

            // Validate bounds
            if model_end > mmap.len() {
                return Err(HoloError::invalid_bounds(
                    model_start,
                    raw.size as usize,
                    mmap.len(),
                ));
            }

            // Validate model checksum
            let model_bytes = &mmap[model_start..model_end];
            let model_checksum = crc32(model_bytes);
            if model_checksum != raw.checksum {
                return Err(HoloError::checksum_mismatch(raw.checksum, model_checksum));
            }

            // Validate it's a valid HOLB
            if model_bytes.len() < 4 || &model_bytes[0..4] != HOLB_MAGIC {
                let found: [u8; 4] = model_bytes
                    .get(0..4)
                    .map_or([0; 4], |b| [b[0], b[1], b[2], b[3]]);
                return Err(HoloError::invalid_model_magic_by_index(
                    entries.len(),
                    found,
                ));
            }

            entries.push(PipelineEntry {
                name: raw.name.clone(),
                offset: model_start,
                size: raw.size as usize,
                checksum: raw.checksum,
            });
        }

        Ok(LoadedPipeline {
            mmap: Arc::new(mmap),
            entries,
        })
    }

    /// Load HOLB (single model) - synchronous after mmap.
    #[allow(clippy::cast_possible_truncation)]
    fn load_holb(mmap: Mmap) -> Result<LoadedPlan> {
        // Parse header (zero-copy)
        if mmap.len() < std::mem::size_of::<HolbHeader>() {
            return Err(HoloError::file_too_small(
                std::mem::size_of::<HolbHeader>(),
                mmap.len(),
            ));
        }

        #[allow(clippy::cast_ptr_alignment)]
        let header = unsafe {
            // SAFETY: We verified file is large enough for header
            &*(mmap.as_ptr().cast::<HolbHeader>())
        };

        // Verify magic
        if !header.is_valid() {
            return Err(HoloError::invalid_magic(HOLB_MAGIC, &header.magic));
        }

        // Verify bounds
        let graph_end = header
            .graph_offset
            .checked_add(header.graph_size)
            .ok_or_else(|| HoloError::arithmetic_overflow("graph_offset + graph_size"))?;

        if graph_end as usize > mmap.len() {
            return Err(HoloError::invalid_bounds(
                header.graph_offset as usize,
                header.graph_size as usize,
                mmap.len(),
            ));
        }

        // Verify checksum
        let graph_bytes = &mmap[header.graph_offset as usize..graph_end as usize];
        let computed_checksum = crc32(graph_bytes);
        if computed_checksum != header.graph_checksum {
            return Err(HoloError::checksum_mismatch(
                header.graph_checksum,
                computed_checksum,
            ));
        }

        // Get archived plan (zero-copy)
        let archived_plan = unsafe {
            // SAFETY: We verified checksum and bounds
            rkyv::archived_root::<BackendPlan>(graph_bytes)
        };

        // SAFETY: We extend the lifetime to 'static because the Mmap
        // is moved into LoadedPlan and will live as long as the reference.
        let plan = unsafe {
            std::mem::transmute::<&ArchivedBackendPlan, &'static ArchivedBackendPlan>(archived_plan)
        };

        Ok(LoadedPlan { _mmap: mmap, plan })
    }

    /// Load HOLM (pipeline) - loads the first model from the pipeline.
    ///
    /// Parses the HOLM header, validates the index checksum, validates all
    /// model entries exist at their offsets, and loads the first model's
    /// `BackendPlan`.
    ///
    /// For multi-model access, use [`load_pipeline`] instead.
    #[allow(clippy::cast_possible_truncation)]
    fn load_holm(mmap: Mmap) -> Result<LoadedPlan> {
        // Parse header
        if mmap.len() < HOLM_HEADER_SIZE {
            return Err(HoloError::file_too_small(HOLM_HEADER_SIZE, mmap.len()));
        }

        let header = HolmHeader::from_bytes(&mmap)?;

        // Verify model count
        if header.model_count == 0 {
            return Err(HoloError::EmptyBundle);
        }

        // Verify index bounds
        let index_start = header.index_offset as usize;
        let index_end = index_start + header.index_size as usize;
        if index_end > mmap.len() {
            return Err(HoloError::invalid_bounds(
                index_start,
                header.index_size as usize,
                mmap.len(),
            ));
        }

        // Verify index checksum
        let index_bytes = &mmap[index_start..index_end];
        let computed_checksum = crc32(index_bytes);
        if computed_checksum != header.index_checksum {
            return Err(HoloError::checksum_mismatch(
                header.index_checksum,
                computed_checksum,
            ));
        }

        // Parse model index entries
        let entries = Self::parse_model_entries(index_bytes, header.model_count as usize)?;

        // Validate ALL model entries exist at their offsets
        for entry in &entries {
            let model_start = entry.offset as usize;
            let model_end = model_start + entry.size as usize;

            if model_end > mmap.len() {
                return Err(HoloError::invalid_bounds(
                    model_start,
                    entry.size as usize,
                    mmap.len(),
                ));
            }

            // Verify model checksum
            let model_bytes = &mmap[model_start..model_end];
            let model_checksum = crc32(model_bytes);
            if model_checksum != entry.checksum {
                return Err(HoloError::checksum_mismatch(entry.checksum, model_checksum));
            }

            // Verify it's a valid HOLB magic
            if model_bytes.len() < 4 || &model_bytes[0..4] != HOLB_MAGIC {
                let found: [u8; 4] = model_bytes
                    .get(0..4)
                    .map_or([0; 4], |b| [b[0], b[1], b[2], b[3]]);
                return Err(HoloError::invalid_model_magic_by_name(&entry.name, found));
            }
        }

        // Load first model
        let first_entry = &entries[0];
        let model_start = first_entry.offset as usize;
        let model_end = model_start + first_entry.size as usize;
        let model_bytes = &mmap[model_start..model_end];

        let holb_header = HolbHeader::from_bytes(model_bytes)?;
        let graph_start = holb_header.graph_offset as usize;
        let graph_end = graph_start + holb_header.graph_size as usize;

        if graph_end > model_bytes.len() {
            return Err(HoloError::invalid_bounds(
                graph_start,
                holb_header.graph_size as usize,
                model_bytes.len(),
            ));
        }

        // Verify graph checksum
        let graph_bytes = &model_bytes[graph_start..graph_end];
        let graph_checksum = crc32(graph_bytes);
        if graph_checksum != holb_header.graph_checksum {
            return Err(HoloError::checksum_mismatch(
                holb_header.graph_checksum,
                graph_checksum,
            ));
        }

        // Get archived plan (zero-copy)
        let archived_plan = unsafe {
            // SAFETY: We verified checksum and bounds
            rkyv::archived_root::<BackendPlan>(graph_bytes)
        };

        // SAFETY: We extend the lifetime to 'static because the Mmap
        // is moved into LoadedPlan and will live as long as the reference.
        let plan = unsafe {
            std::mem::transmute::<&ArchivedBackendPlan, &'static ArchivedBackendPlan>(archived_plan)
        };

        Ok(LoadedPlan { _mmap: mmap, plan })
    }

    /// Parse model index entries from bytes.
    fn parse_model_entries(bytes: &[u8], count: usize) -> Result<Vec<PipelineModelEntry>> {
        let mut entries = Vec::with_capacity(count);
        let mut offset = 0;

        for _ in 0..count {
            if offset >= bytes.len() {
                return Err(HoloError::table_truncated(offset + 1, bytes.len()));
            }

            let (entry, consumed) = PipelineModelEntry::from_bytes(&bytes[offset..])?;
            entries.push(entry);
            offset += consumed;
        }

        Ok(entries)
    }

    /// Load archive file asynchronously (.holb or .holo).
    ///
    /// # Errors
    /// Returns error if file operations fail or format is invalid.
    #[cfg(feature = "async")]
    pub async fn load_async<P: AsRef<Path>>(path: P) -> Result<LoadedPlan> {
        // Async file I/O with tokio
        let mut file = File::open(path).await?;

        // Read magic bytes to determine format
        let mut magic = [0u8; 4];
        file.read_exact(&mut magic).await?;

        // Convert to std::fs::File for memory-mapping
        // (memmap2 requires std::fs::File)
        let std_file = file.into_std().await;
        let mmap = unsafe { Mmap::map(&std_file)? };

        // Dispatch based on magic
        match &magic {
            b"HOLB" => Self::load_holb(mmap),
            b"HOLM" => Self::load_holm(mmap),
            _ => Err(HoloError::invalid_magic(HOLB_MAGIC, &magic)),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::instruction::{BackendPlan, PlanMetadata};
    use crate::types::ObservableMetadata;
    use crate::{HolbWriter, HolmWriter};
    use rkyv::ser::{serializers::AllocSerializer, Serializer};
    use std::io::Write as _;
    use tempfile::NamedTempFile;

    /// Create a minimal valid `BackendPlan` for testing.
    fn create_test_plan_bytes() -> Vec<u8> {
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![1, 2, 3, 4],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata {
                name: "test".to_string(),
                version: "1.0".to_string(),
                author: None,
                description: None,
            },
            node_buffer_map: vec![],
            observable_metadata: ObservableMetadata::default(),
            lut_section: crate::types::LutSection::new(),
        };

        let mut serializer = AllocSerializer::<256>::default();
        serializer
            .serialize_value(&plan)
            .expect("Failed to serialize plan");
        serializer.into_serializer().into_inner().to_vec()
    }

    #[test]
    fn test_load_holb_file() {
        let plan_bytes = create_test_plan_bytes();

        // Create HOLB bundle
        let mut writer = HolbWriter::new();
        writer.set_graph(&plan_bytes);
        let bundle = writer.build().unwrap();

        // Write to temp file
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(&bundle).unwrap();
        file.flush().unwrap();

        // Load it back
        let loaded = HoloLoader::load(file.path()).unwrap();
        assert_eq!(loaded.constants(), &[1, 2, 3, 4]);
    }

    #[test]
    fn test_load_holm_file() {
        let plan_bytes = create_test_plan_bytes();

        // Create HOLB bundle for the model
        let mut holb_writer = HolbWriter::new();
        holb_writer.set_graph(&plan_bytes);
        let holb_bundle = holb_writer.build().unwrap();

        // Create HOLM pipeline with the model
        let mut holm_writer = HolmWriter::new();
        holm_writer.add_model("test_model", &holb_bundle).unwrap();
        let pipeline = holm_writer.build().unwrap();

        // Write to temp file
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(&pipeline).unwrap();
        file.flush().unwrap();

        // Load it back
        let loaded = HoloLoader::load(file.path()).unwrap();
        assert_eq!(loaded.constants(), &[1, 2, 3, 4]);
    }

    #[test]
    fn test_load_holm_multiple_models() {
        let plan_bytes = create_test_plan_bytes();

        // Create HOLB bundles
        let mut holb_writer1 = HolbWriter::new();
        holb_writer1.set_graph(&plan_bytes);
        let holb1 = holb_writer1.build().unwrap();

        let mut holb_writer2 = HolbWriter::new();
        holb_writer2.set_graph(&plan_bytes);
        let holb2 = holb_writer2.build().unwrap();

        // Create HOLM pipeline with multiple models
        let mut holm_writer = HolmWriter::new();
        holm_writer.add_model("encoder", &holb1).unwrap();
        holm_writer.add_model("decoder", &holb2).unwrap();
        let pipeline = holm_writer.build().unwrap();

        // Write to temp file
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(&pipeline).unwrap();
        file.flush().unwrap();

        // Load it back (loads first model)
        let loaded = HoloLoader::load(file.path()).unwrap();
        assert_eq!(loaded.constants(), &[1, 2, 3, 4]);
    }

    #[test]
    fn test_load_invalid_magic() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"JUNK data here").unwrap();
        file.flush().unwrap();

        let result = HoloLoader::load(file.path());
        assert!(result.is_err());
    }

    #[test]
    fn test_load_empty_holm() {
        // Create empty HOLM (no models)
        let mut writer = HolmWriter::new();
        let result = writer.build();
        assert!(result.is_err()); // Should fail because no models
    }

    #[test]
    fn test_load_file_too_small() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"HOL").unwrap(); // Too small
        file.flush().unwrap();

        let result = HoloLoader::load(file.path());
        assert!(result.is_err());
    }

    #[test]
    fn test_load_pipeline_single_model() {
        let plan_bytes = create_test_plan_bytes();

        // Create HOLB bundle
        let mut holb_writer = HolbWriter::new();
        holb_writer.set_graph(&plan_bytes);
        let holb_bundle = holb_writer.build().unwrap();

        // Create HOLM pipeline
        let mut holm_writer = HolmWriter::new();
        holm_writer.add_model("test_model", &holb_bundle).unwrap();
        let pipeline = holm_writer.build().unwrap();

        // Write to temp file
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(&pipeline).unwrap();
        file.flush().unwrap();

        // Load as pipeline
        let loaded = HoloLoader::load_pipeline(file.path()).unwrap();
        assert_eq!(loaded.model_count(), 1);
        assert_eq!(loaded.model_names(), vec!["test_model"]);
        assert!(loaded.has_model("test_model"));
        assert!(!loaded.has_model("nonexistent"));

        // Access by name
        let model = loaded.get_model("test_model").unwrap().unwrap();
        assert_eq!(&model.constants[..], &[1, 2, 3, 4]);

        // Access by index
        let model = loaded.get_model_by_index(0).unwrap();
        assert_eq!(&model.constants[..], &[1, 2, 3, 4]);

        // Primary model
        let model = loaded.primary_model().unwrap();
        assert_eq!(&model.constants[..], &[1, 2, 3, 4]);
    }

    #[test]
    fn test_load_pipeline_multiple_models() {
        let plan_bytes = create_test_plan_bytes();

        // Create HOLB bundles
        let mut holb_writer1 = HolbWriter::new();
        holb_writer1.set_graph(&plan_bytes);
        let holb1 = holb_writer1.build().unwrap();

        let mut holb_writer2 = HolbWriter::new();
        holb_writer2.set_graph(&plan_bytes);
        let holb2 = holb_writer2.build().unwrap();

        let mut holb_writer3 = HolbWriter::new();
        holb_writer3.set_graph(&plan_bytes);
        let holb3 = holb_writer3.build().unwrap();

        // Create HOLM pipeline with multiple models
        let mut holm_writer = HolmWriter::new();
        holm_writer.add_model("encoder", &holb1).unwrap();
        holm_writer.add_model("decoder", &holb2).unwrap();
        holm_writer.add_model("classifier", &holb3).unwrap();
        let pipeline = holm_writer.build().unwrap();

        // Write to temp file
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(&pipeline).unwrap();
        file.flush().unwrap();

        // Load as pipeline
        let loaded = HoloLoader::load_pipeline(file.path()).unwrap();
        assert_eq!(loaded.model_count(), 3);
        assert_eq!(
            loaded.model_names(),
            vec!["encoder", "decoder", "classifier"]
        );

        // Access each by name
        assert!(loaded.get_model("encoder").unwrap().is_some());
        assert!(loaded.get_model("decoder").unwrap().is_some());
        assert!(loaded.get_model("classifier").unwrap().is_some());
        assert!(loaded.get_model("nonexistent").unwrap().is_none());

        // Access by index
        loaded.get_model_by_index(0).unwrap();
        loaded.get_model_by_index(1).unwrap();
        loaded.get_model_by_index(2).unwrap();
        assert!(loaded.get_model_by_index(3).is_err());
    }

    #[test]
    fn test_load_pipeline_iter_models() {
        let plan_bytes = create_test_plan_bytes();

        // Create HOLB bundles
        let mut holb_writer1 = HolbWriter::new();
        holb_writer1.set_graph(&plan_bytes);
        let holb1 = holb_writer1.build().unwrap();

        let mut holb_writer2 = HolbWriter::new();
        holb_writer2.set_graph(&plan_bytes);
        let holb2 = holb_writer2.build().unwrap();

        // Create HOLM pipeline
        let mut holm_writer = HolmWriter::new();
        holm_writer.add_model("first", &holb1).unwrap();
        holm_writer.add_model("second", &holb2).unwrap();
        let pipeline = holm_writer.build().unwrap();

        // Write to temp file
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(&pipeline).unwrap();
        file.flush().unwrap();

        // Load and iterate
        let loaded = HoloLoader::load_pipeline(file.path()).unwrap();
        let models: Vec<_> = loaded
            .iter_models()
            .map(|r| r.map(|(name, _)| name.to_string()))
            .collect();

        assert_eq!(models.len(), 2);
        assert_eq!(models[0].as_ref().unwrap(), "first");
        assert_eq!(models[1].as_ref().unwrap(), "second");
    }

    #[test]
    fn test_load_pipeline_not_holm() {
        let plan_bytes = create_test_plan_bytes();

        // Create HOLB bundle (not HOLM)
        let mut writer = HolbWriter::new();
        writer.set_graph(&plan_bytes);
        let bundle = writer.build().unwrap();

        // Write to temp file
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(&bundle).unwrap();
        file.flush().unwrap();

        // Should fail - not a HOLM file
        let result = HoloLoader::load_pipeline(file.path());
        assert!(result.is_err());
    }
}
