//! CUDA texture support for activation table lookups.
//!
//! This module implements `TextureActivation` for the CUDA backend,
//! providing GPU texture-based activation lookups using CUDA's
//! texture memory hardware.
//!
//! # Performance
//!
//! CUDA textures provide:
//! - Dedicated texture cache (L1 texture cache)
//! - Hardware-accelerated filtering
//! - Out-of-bounds handling (clamp, wrap)
//! - Efficient broadcasting across warps
//!
//! For 256-byte activation tables, `tex1Dfetch` provides optimal
//! cache utilization as the entire table fits in L1 texture cache.
//!
//! # Usage
//!
//! ```ignore
//! use hologram_backend::backends::cuda::CudaBackend;
//! use hologram_backend::backends::cuda::textures::CudaActivationTextures;
//! use hologram_backend::core::gpu_textures::TextureActivation;
//! use hologram_backend::plan::activation_table_id;
//!
//! let device = CudaDevice::new(0)?;
//! let mut textures = CudaActivationTextures::new(device);
//! textures.preload_standard_textures();
//!
//! // Texture is now available for use in epilogue operations
//! let tex = textures.get_activation_texture(activation_table_id::SIGMOID);
//! ```

use crate::core::gpu_textures::{
    get_activation_table, table_id, TextureActivation, TextureCache, TextureDescriptor,
};
use cudarc::driver::{CudaDevice, CudaSlice, DeviceRepr};
use std::sync::Arc;

/// CUDA texture handle for activation lookups.
///
/// Wraps a CUDA texture object created from an activation table.
#[derive(Clone)]
pub struct CudaTextureHandle {
    /// Device memory containing the texture data.
    pub data: CudaSlice<u8>,
    /// Table ID this texture represents.
    pub table_id: u32,
    /// Device this texture is on.
    pub device: Arc<CudaDevice>,
}

/// CUDA activation texture manager.
///
/// Manages creation and caching of CUDA textures for activation tables.
pub struct CudaActivationTextures {
    device: Arc<CudaDevice>,
    cache: TextureCache<CudaTextureHandle>,
}

impl CudaActivationTextures {
    /// Create a new texture manager for the given device.
    pub fn new(device: Arc<CudaDevice>) -> Self {
        Self {
            device,
            cache: TextureCache::new(),
        }
    }

    /// Create a CUDA texture from an activation table.
    fn create_texture(&self, table_id: u32) -> Option<CudaTextureHandle> {
        let table_data = get_activation_table(table_id)?;

        // Allocate device memory and copy table data
        let data = self.device.htod_copy(table_data.to_vec()).ok()?;

        Some(CudaTextureHandle {
            data,
            table_id,
            device: self.device.clone(),
        })
    }

    /// Get device pointer for use in kernels.
    pub fn get_device_ptr(&self, table_id: u32) -> Option<*const u8> {
        self.cache.get(&table_id).map(|h| {
            // Get raw device pointer from CudaSlice
            // SAFETY: The pointer is valid as long as the CudaSlice exists
            unsafe { *h.data.device_ptr() as *const u8 }
        })
    }
}

impl TextureActivation for CudaActivationTextures {
    type TextureHandle = CudaTextureHandle;

    fn create_activation_texture(&mut self, table_id: u32) -> Option<Self::TextureHandle> {
        // Check cache first
        if let Some(handle) = self.cache.get(&table_id) {
            return Some(handle.clone());
        }

        // Create new texture
        if let Some(handle) = self.create_texture(table_id) {
            self.cache.insert(table_id, handle.clone());
            Some(handle)
        } else {
            None
        }
    }

    fn get_activation_texture(&self, table_id: u32) -> Option<&Self::TextureHandle> {
        self.cache.get(&table_id)
    }

    fn supports_texture_activations(&self) -> bool {
        true
    }
}

/// CUDA PTX snippet for texture-based activation lookup.
///
/// This can be included in CUDA PTX kernels to enable
/// texture-based activation in epilogue operations.
///
/// Note: This uses direct global memory access rather than texture objects
/// for simplicity. For maximum performance with larger tables,
/// consider using cudaTextureObject_t.
pub const ACTIVATION_LOOKUP_PTX: &str = r#"
// Activation table lookup function (PTX)
// Parameters:
//   %rd1 - pointer to activation table (256 bytes)
//   %r1  - input index (0-255)
//   %r2  - output value
//
// Usage:
//   ld.global.u8 %r2, [%rd1 + %r1];
//
// For f32 input (normalize to index):
//   // Clamp to [0, 1], multiply by 255, convert to int
//   mul.f32 %f1, %f_input, 255.0;
//   cvt.rzi.u32.f32 %r1, %f1;
//   min.u32 %r1, %r1, 255;
//   ld.global.u8 %r2, [%rd_table + %r1];
//   // Convert back to f32 if needed
//   cvt.f32.u8 %f_output, %r2;
//   mul.f32 %f_output, %f_output, 0.00392156862;  // 1/255
"#;

/// CUDA C++ device function for activation lookup.
///
/// Include this in CUDA kernels for activation table lookup.
pub const ACTIVATION_LOOKUP_CUDA: &str = r#"
// Device function for activation table lookup
__device__ __forceinline__ unsigned char activation_lookup_u8(
    const unsigned char* __restrict__ table,
    unsigned char index
) {
    return table[index];
}

// Device function for f32 activation with quantization
__device__ __forceinline__ float activation_lookup_f32(
    const unsigned char* __restrict__ table,
    float input
) {
    // Clamp input to [0, 1] range
    float clamped = fminf(fmaxf(input, 0.0f), 1.0f);

    // Convert to table index
    unsigned int index = __float2uint_rz(clamped * 255.0f);
    index = min(index, 255u);

    // Lookup and convert back to float
    return table[index] * (1.0f / 255.0f);
}

// Sigmoid lookup (input in [-8, 8] range)
__device__ __forceinline__ float sigmoid_lookup(
    const unsigned char* __restrict__ sigmoid_table,
    float input
) {
    // Map [-8, 8] to [0, 1] for table lookup
    float normalized = (input + 8.0f) * 0.0625f;  // 1/16
    return activation_lookup_f32(sigmoid_table, normalized);
}

// Apply epilogue activation to matmul output
__device__ __forceinline__ float epilogue_activation(
    float value,
    const unsigned char* __restrict__ activation_table
) {
    // Normalize to [0, 1] assuming value is in reasonable range
    float normalized = (value + 8.0f) * 0.0625f;
    normalized = fminf(fmaxf(normalized, 0.0f), 1.0f);

    unsigned int index = __float2uint_rz(normalized * 255.0f);
    return activation_table[min(index, 255u)] * (1.0f / 255.0f);
}
"#;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cuda_shader_snippets_not_empty() {
        assert!(!ACTIVATION_LOOKUP_PTX.is_empty());
        assert!(!ACTIVATION_LOOKUP_CUDA.is_empty());
    }
}
