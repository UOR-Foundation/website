//! Naming conventions for shell-to-Rust code generation.
//!
//! Converts shell identifiers (snake_case) to PascalCase enum variants and
//! applies annotation overrides like `@suffix("LUT")` and `@variant("ElemMin")`.

use crate::ast::Annotation;

/// Convert `snake_case` to `PascalCase`.
///
/// ```text
/// lut_activation → LutActivation
/// matmul         → Matmul
/// conv2d         → Conv2d
/// avg_pool2d     → AvgPool2d
/// batch_mat_mul  → BatchMatMul
/// ```
pub fn to_pascal_case(s: &str) -> String {
    s.split('_')
        .map(|seg| {
            let mut chars = seg.chars();
            match chars.next() {
                Some(c) => {
                    let upper: String = c.to_uppercase().collect();
                    format!("{upper}{}", chars.as_str())
                }
                None => String::new(),
            }
        })
        .collect()
}

/// Derive the enum variant name for an operation.
///
/// Priority:
/// 1. `@variant("Name")` — exact override
/// 2. `PascalCase(op_name)` + `@suffix("LUT")` → `NameLUT`
/// 3. `PascalCase(op_name)` — default
pub fn variant_name(op_name: &str, annotations: &[Annotation]) -> String {
    // Check for explicit @variant override
    for ann in annotations {
        if let Annotation::Variant(name) = ann {
            return name.clone();
        }
    }

    let base = to_pascal_case(op_name);

    // Check for @suffix
    for ann in annotations {
        if let Annotation::Suffix(suffix) = ann {
            return format!("{base}{suffix}");
        }
    }

    base
}

/// Derive the trait method name: `exec_` + snake_case.
///
/// Group members with a suffix get the suffix in the method name:
/// `sigmoid` in group with `@suffix("LUT")` → `exec_sigmoid_lut`
pub fn method_name(op_name: &str, annotations: &[Annotation]) -> String {
    let suffix = annotations.iter().find_map(|a| match a {
        Annotation::Suffix(s) => Some(s.to_ascii_lowercase()),
        _ => None,
    });

    match suffix {
        Some(s) => format!("exec_{op_name}_{s}"),
        None => format!("exec_{op_name}"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pascal_case_basic() {
        assert_eq!(to_pascal_case("matmul"), "Matmul");
        assert_eq!(to_pascal_case("conv2d"), "Conv2d");
        assert_eq!(to_pascal_case("lut_activation"), "LutActivation");
        assert_eq!(to_pascal_case("batch_mat_mul"), "BatchMatMul");
        assert_eq!(to_pascal_case("avg_pool2d"), "AvgPool2d");
        assert_eq!(to_pascal_case("global_avg_pool"), "GlobalAvgPool");
    }

    #[test]
    fn variant_name_default() {
        assert_eq!(variant_name("matmul", &[]), "Matmul");
        assert_eq!(variant_name("conv2d", &[]), "Conv2d");
    }

    #[test]
    fn variant_name_with_suffix() {
        let anns = vec![Annotation::Suffix("LUT".into())];
        assert_eq!(variant_name("sigmoid", &anns), "SigmoidLUT");
        assert_eq!(variant_name("tanh", &anns), "TanhLUT");
    }

    #[test]
    fn variant_name_explicit_override() {
        let anns = vec![Annotation::Variant("ElemMin".into())];
        assert_eq!(variant_name("elem_min", &anns), "ElemMin");
    }

    #[test]
    fn variant_override_takes_priority() {
        let anns = vec![
            Annotation::Suffix("LUT".into()),
            Annotation::Variant("Custom".into()),
        ];
        assert_eq!(variant_name("something", &anns), "Custom");
    }

    #[test]
    fn method_name_basic() {
        assert_eq!(method_name("matmul", &[]), "exec_matmul");
        assert_eq!(method_name("conv2d", &[]), "exec_conv2d");
    }

    #[test]
    fn method_name_with_suffix() {
        let anns = vec![Annotation::Suffix("LUT".into())];
        assert_eq!(method_name("sigmoid", &anns), "exec_sigmoid_lut");
    }
}
