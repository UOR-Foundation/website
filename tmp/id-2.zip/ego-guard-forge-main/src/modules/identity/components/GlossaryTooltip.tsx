/**
 * GlossaryTooltip — Hover-activated definitions for technical terms.
 *
 * Wrap any text in <Glossary term="Recovery key"> to show a dotted
 * underline and a tooltip on hover with the plain-English definition.
 */

import { useState, useRef, useEffect, type ReactNode } from "react";
import { HelpCircle } from "lucide-react";

const GLOSSARY: Record<string, string> = {
  "Recovery key":
    "A private cryptographic key stored only on your device. It protects your identity and lets you regain access if something goes wrong. Never shared with anyone.",
  "Interaction key":
    "Your public-facing credential. Services you authorize can see it to verify who you are — but it reveals nothing about your private data.",
  "Protection Score":
    "A single number (0–100) that measures how well your overall data is protected. Higher means more of your information stays private.",
  "Privacy compression":
    "How efficiently your privacy settings reduce the amount of information others can see. A higher ratio means the AI sees far less than your full data.",
  "Trust Score":
    "A measure of how much trust you've built through verified interactions and time. Grows as you complete peer verifications.",
  "Proof ID":
    "A unique fingerprint for a verification event. It proves something happened without revealing the details.",
  "Selective disclosure":
    "Sharing specific facts about yourself without revealing everything. For example, proving you're over 18 without showing your birthday.",
  "Auto-redact":
    "When enabled, the AI chat automatically censors any response that tries to reference your private data, replacing it with [REDACTED].",
  "Privacy controls":
    "Toggles that let you decide exactly what data is private, limited, or shared. Each toggle controls one specific piece of information.",
  "Data reconstruction difficulty":
    "How hard it would be for someone to piece together your private data from the limited information you've shared. Higher is safer.",
  "Quantum-safe":
    "Encryption designed to resist attacks from future quantum computers. Your keys use lattice-based cryptography that stays secure even as technology advances.",
  "Peer verification":
    "A mutual trust-building process where two people exchange credentials and create a shared proof that they trust each other.",
  "Consent":
    "Your explicit permission for a service to access specific data. You can revoke consent anytime.",
  "Agent control":
    "How much direct control you have over your own digital identity — including who can act on your behalf.",
  "Data ownership":
    "The degree to which your data stays under your control rather than being held by third parties.",
  "AI processing":
    "How your information is handled when an AI interacts with it — whether it's processed privately or exposed to external systems.",
};

interface Props {
  /** The glossary term to define (must match a key in the dictionary). */
  term: string;
  /** Optional: override the displayed text (defaults to the term itself). */
  children?: ReactNode;
  /** Show a small help icon after the text. */
  showIcon?: boolean;
}

export default function GlossaryTooltip({ term, children, showIcon = false }: Props) {
  const [visible, setVisible] = useState(false);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  const ref = useRef<HTMLSpanElement>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout>>();

  const definition = GLOSSARY[term];

  const show = () => {
    clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const tooltipWidth = 280;
      let left = rect.left + rect.width / 2 - tooltipWidth / 2;
      left = Math.max(8, Math.min(left, window.innerWidth - tooltipWidth - 8));
      const spaceBelow = window.innerHeight - rect.bottom;
      const top =
        spaceBelow > 100
          ? rect.bottom + 8 + window.scrollY
          : rect.top - 8 + window.scrollY;
      setPos({ top, left });
      setVisible(true);
    }, 200);
  };

  const hide = () => {
    clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => setVisible(false), 150);
  };

  useEffect(() => () => clearTimeout(timeoutRef.current), []);

  if (!definition) {
    return <span>{children ?? term}</span>;
  }

  return (
    <>
      <span
        ref={ref}
        onMouseEnter={show}
        onMouseLeave={hide}
        onFocus={show}
        onBlur={hide}
        tabIndex={0}
        className="cursor-help border-b border-dotted border-muted-foreground/40 hover:border-primary/60 transition-colors inline-flex items-center gap-0.5"
        role="term"
        aria-describedby={visible ? `glossary-${term.replace(/\s/g, "-")}` : undefined}
      >
        {children ?? term}
        {showIcon && <HelpCircle className="h-2.5 w-2.5 text-muted-foreground/50" />}
      </span>

      {visible && pos && (
        <div
          id={`glossary-${term.replace(/\s/g, "-")}`}
          role="tooltip"
          className="fixed z-[9998] w-[280px] rounded-lg border border-border bg-card shadow-xl animate-fade-in pointer-events-auto"
          style={{ top: pos.top, left: pos.left, position: "fixed" }}
          onMouseEnter={() => {
            clearTimeout(timeoutRef.current);
            setVisible(true);
          }}
          onMouseLeave={hide}
        >
          <div className="p-3 space-y-1.5">
            <p className="text-[10px] font-semibold text-primary uppercase tracking-wider font-mono">
              {term}
            </p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              {definition}
            </p>
          </div>
        </div>
      )}
    </>
  );
}

/** Re-export the glossary dictionary for use in other components. */
export { GLOSSARY };
