//! CLI command implementations.

pub mod compile;
pub mod distributed;
pub mod holo;
pub mod kernel;
pub mod metrics;
pub mod model;
pub mod registry;
pub mod run;
pub mod tokenizer;
