//! Weight quantization pass for LUT-GEMM optimization.
//!
//! This pass identifies `MatMul` operations with constant weights that can be
//! quantized for LUT-based execution. When enabled, it:
//!
//! 1. Finds `MatMul` nodes with constant weight inputs
//! 2. Quantizes the weights using k-means clustering
//! 3. Creates new constant nodes for quantized indices and centroids
//! 4. Marks the `MatMul` node for LUT-GEMM emission during assembly
//!
//! # Quantization Levels
//!
//! - **Q4 (4-bit)**: 16 centroids, 2-4x speedup, ~5-15% error
//! - **Q8 (8-bit)**: 256 centroids, ~1.5x speedup, <1% error
//!
//! The pass automatically selects Q4 if the quantization error is below the
//! threshold, otherwise falls back to Q8.

use crate::graph::{CompileGraph, ConstantData, OpKind};

/// Quantization mode for `MatMul` operations.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum QuantizeMode {
    /// Never quantize - use traditional `MatMul`.
    #[default]
    Disabled,
    /// Always quantize constant-weight `MatMul` operations.
    Enabled,
    /// Automatically decide based on heuristics (FLOP count, dimensions, cost model).
    Auto,
}

/// Configuration for weight quantization.
#[derive(Debug, Clone, Copy)]
pub struct QuantizeConfig {
    /// Quantization mode.
    pub mode: QuantizeMode,
    /// Maximum allowed quantization error (relative, 0.0-1.0).
    /// If Q4 error exceeds this, falls back to Q8.
    pub error_threshold: f32,

    // --- Auto-mode heuristics ---
    /// Minimum FLOPs for quantization to be worthwhile (default: 4096).
    /// Below this, Psumbook construction overhead exceeds savings.
    pub min_flops: usize,
    /// Minimum K dimension (inner dimension) for LUT to benefit (default: 32).
    /// Smaller K means fewer lookups, reducing LUT advantage.
    pub min_k: usize,
    /// Error threshold scaling by layer depth (default: 0.02).
    /// Early layers get tighter thresholds: `threshold * (1 + depth * scale)`.
    pub depth_error_scale: f32,
}

impl Default for QuantizeConfig {
    fn default() -> Self {
        Self {
            mode: QuantizeMode::Disabled,
            error_threshold: 0.15, // 15% relative error threshold
            min_flops: 4096,
            min_k: 32,
            depth_error_scale: 0.02,
        }
    }
}

impl QuantizeConfig {
    /// Create a config with quantization enabled for all eligible `MatMul` operations.
    #[must_use]
    pub fn enabled() -> Self {
        Self {
            mode: QuantizeMode::Enabled,
            ..Self::default()
        }
    }

    /// Create a config with automatic quantization based on heuristics.
    #[must_use]
    pub fn auto() -> Self {
        Self {
            mode: QuantizeMode::Auto,
            ..Self::default()
        }
    }

    /// Returns true if quantization is enabled (either `Enabled` or `Auto` mode).
    #[must_use]
    pub fn is_active(&self) -> bool {
        !matches!(self.mode, QuantizeMode::Disabled)
    }
}

/// Heuristics for `MatMul` → `MatMulLUT` conversion profitability analysis.
pub struct LutGemmHeuristics;

impl LutGemmHeuristics {
    /// Group size for Psumbook construction (matches L1 cache line).
    const GROUP_SIZE: usize = 32;

    /// Check if LUT-GEMM is profitable for given dimensions.
    #[must_use]
    pub fn is_profitable(m: usize, k: usize, n: usize, config: &QuantizeConfig) -> bool {
        let flops = 2 * m * k * n; // Multiply-add = 2 ops

        // Gate 1: Minimum FLOPs
        if flops < config.min_flops {
            return false;
        }

        // Gate 2: Minimum K dimension
        if k < config.min_k {
            return false;
        }

        // Gate 3: Cost model comparison
        let matmul_cost = Self::estimate_matmul_cost(m, k, n);
        let lutgemm_cost = Self::estimate_lutgemm_cost(m, k, n);

        lutgemm_cost < matmul_cost
    }

    /// Estimate traditional `MatMul` cost (cycles).
    #[allow(clippy::cast_precision_loss)]
    fn estimate_matmul_cost(m: usize, k: usize, n: usize) -> f64 {
        // SIMD throughput: ~16 FLOPs/cycle with AVX2
        let flops = (2 * m * k * n) as f64;
        flops / 16.0
    }

    /// Estimate LUT-GEMM cost (cycles).
    #[allow(clippy::cast_precision_loss)]
    fn estimate_lutgemm_cost(m: usize, k: usize, n: usize) -> f64 {
        let num_groups = k.div_ceil(Self::GROUP_SIZE);

        // Psumbook construction: ~16 cycles per group (16 centroids × accumulate)
        let psumbook_cost = (m * num_groups * 16) as f64;

        // Lookup cost: ~2 cycles per output element (cache hit)
        let lookup_cost = (m * n * 2) as f64;

        psumbook_cost + lookup_cost
    }
}

/// Calculate error threshold adjusted for layer depth.
///
/// Early layers (depth=0) use base threshold. Later layers allow more error.
#[allow(clippy::cast_precision_loss)]
fn adaptive_threshold(base_threshold: f32, layer_depth: usize, scale: f32) -> f32 {
    base_threshold * (1.0 + (layer_depth as f32) * scale)
}

/// Run the weight quantization pass.
///
/// This pass scans for `MatMul` operations with constant weight inputs and
/// quantizes them for LUT-GEMM execution.
///
/// # Arguments
///
/// * `graph` - The compilation graph to transform
/// * `original_constants` - The original constant data from the input graph
/// * `config` - Quantization configuration
///
/// # Returns
///
/// Number of nodes marked for LUT-GEMM execution.
pub fn quantize_weights(
    graph: &mut CompileGraph,
    original_constants: &[ConstantData],
    config: &QuantizeConfig,
) -> usize {
    // Early exit if disabled
    if matches!(config.mode, QuantizeMode::Disabled) {
        return 0;
    }

    // Collect MatMul nodes that can be quantized
    let candidates = find_quantizable_matmuls(graph);
    let mut quantized_count = 0;

    for (idx, (matmul_id, weight_const_id, m, k, n)) in candidates.into_iter().enumerate() {
        // Auto mode: check profitability using heuristics
        if matches!(config.mode, QuantizeMode::Auto)
            && !LutGemmHeuristics::is_profitable(m, k, n, config)
        {
            continue;
        }

        // Get the weight constant data
        let weight_data = get_constant_data(graph, weight_const_id, original_constants);
        let Some(weights) = weight_data else {
            continue;
        };

        // Extract f32 weights
        let ConstantData::F32(ref weight_vec) = weights else {
            continue; // Only handle f32 weights for now
        };

        // Ensure we have the right number of weights (k × n)
        if weight_vec.len() != k * n {
            continue;
        }

        // Calculate adaptive threshold based on layer index (proxy for depth)
        let threshold = adaptive_threshold(config.error_threshold, idx, config.depth_error_scale);

        // Try Q4 first, fall back to Q8 if error is too high
        let quant_result = quantize_with_threshold(weight_vec, k, n, threshold);

        // Create constant nodes for quantized data
        let (indices_id, centroids_id, quant_bits) = match quant_result {
            QuantResult::Q4 { indices, centroids } => {
                let indices_id = create_indices_constant(graph, &indices);
                let centroids_id = create_centroids_constant(graph, &centroids);
                (indices_id, centroids_id, 4u8)
            }
            QuantResult::Q8 { indices, centroids } => {
                let indices_id = create_indices_constant(graph, &indices);
                let centroids_id = create_centroids_constant(graph, &centroids);
                (indices_id, centroids_id, 8u8)
            }
        };

        // Add annotation to mark this MatMul for LUT-GEMM emission
        // Format: `lut_gemm:<bits>:<indices_id>:<centroids_id>:<m>:<k>:<n>`
        let annotation = format!("lut_gemm:{quant_bits}:{indices_id}:{centroids_id}:{m}:{k}:{n}");
        graph.add_annotation(matmul_id, annotation);

        quantized_count += 1;
    }

    quantized_count
}

/// Find `MatMul` nodes that have constant weight inputs.
///
/// Returns tuples of `(matmul_id, weight_constant_id, m, k, n)`.
fn find_quantizable_matmuls(graph: &CompileGraph) -> Vec<(u32, u32, usize, usize, usize)> {
    let mut candidates = Vec::new();

    for (id, node) in graph.nodes() {
        // Only process MatMul nodes
        let OpKind::MatMul { m, k, n } = node.op else {
            continue;
        };

        // Get predecessors (should be 2: activation input and weights)
        let preds = graph.predecessors(id);
        if preds.len() < 2 {
            continue;
        }

        // Check if second predecessor (weights) is a constant
        let weight_id = preds[1];
        let Some(weight_node) = graph.get_node(weight_id) else {
            continue;
        };

        if matches!(weight_node.op, OpKind::Constant) {
            candidates.push((id, weight_id, m, k, n));
        }
    }

    candidates
}

/// Get constant data for a node (either folded or original).
fn get_constant_data<'a>(
    graph: &'a CompileGraph,
    node_id: u32,
    original_constants: &'a [ConstantData],
) -> Option<&'a ConstantData> {
    // First check folded constants
    if let Some(data) = graph.get_folded_constant(node_id) {
        return Some(data);
    }

    // Look up in original constants by order
    let const_order = graph.constant_nodes_in_order();
    let idx = const_order.iter().position(|&id| id == node_id)?;
    original_constants.get(idx)
}

/// Result of quantization attempt.
enum QuantResult {
    Q4 {
        indices: Vec<u8>,
        centroids: Vec<f32>,
    },
    Q8 {
        indices: Vec<u8>,
        centroids: Vec<f32>,
    },
}

/// Quantize weights, trying Q4 first and falling back to Q8 if error exceeds threshold.
fn quantize_with_threshold(weights: &[f32], k: usize, n: usize, threshold: f32) -> QuantResult {
    // Try Q4 first
    let (q4_indices, q4_centroids) = quantize_kmeans(weights, 16);
    let q4_error = measure_quantization_error(weights, &q4_indices, &q4_centroids);

    if q4_error <= threshold {
        // Pack Q4 indices (2 per byte)
        let packed = pack_q4_indices(&q4_indices, k * n);
        return QuantResult::Q4 {
            indices: packed,
            centroids: q4_centroids,
        };
    }

    // Fall back to Q8
    let (q8_indices, q8_centroids) = quantize_kmeans(weights, 256);
    QuantResult::Q8 {
        indices: q8_indices,
        centroids: q8_centroids,
    }
}

/// K-means quantization with given number of clusters.
#[allow(clippy::cast_possible_truncation, clippy::cast_precision_loss)]
fn quantize_kmeans(weights: &[f32], num_clusters: usize) -> (Vec<u8>, Vec<f32>) {
    const MAX_ITERS: usize = 10;

    let n = weights.len();

    // Initialize centroids with min-max spread
    let min_val = weights.iter().copied().fold(f32::INFINITY, f32::min);
    let max_val = weights.iter().copied().fold(f32::NEG_INFINITY, f32::max);

    let mut centroids: Vec<f32> = (0..num_clusters)
        .map(|i| {
            if num_clusters > 1 {
                min_val + (max_val - min_val) * (i as f32) / ((num_clusters - 1) as f32)
            } else {
                f32::midpoint(min_val, max_val)
            }
        })
        .collect();

    // K-means iterations
    let mut indices = vec![0u8; n];
    let mut counts = vec![0usize; num_clusters];
    let mut sums = vec![0.0f32; num_clusters];

    for _ in 0..MAX_ITERS {
        // Assign each weight to nearest centroid
        for (i, &w) in weights.iter().enumerate() {
            let mut best_idx = 0u8;
            let mut best_dist = f32::INFINITY;

            for (j, &c) in centroids.iter().enumerate() {
                let dist = (w - c).abs();
                if dist < best_dist {
                    best_dist = dist;
                    best_idx = j as u8;
                }
            }

            indices[i] = best_idx;
        }

        // Update centroids
        counts.fill(0);
        sums.fill(0.0);

        for (i, &w) in weights.iter().enumerate() {
            let idx = indices[i] as usize;
            counts[idx] += 1;
            sums[idx] += w;
        }

        for j in 0..num_clusters {
            if counts[j] > 0 {
                centroids[j] = sums[j] / counts[j] as f32;
            }
        }
    }

    (indices, centroids)
}

/// Pack Q4 indices (2 per byte, high nibble first).
fn pack_q4_indices(indices: &[u8], count: usize) -> Vec<u8> {
    let packed_len = count.div_ceil(2);
    let mut packed = vec![0u8; packed_len];

    for (i, &idx) in indices.iter().take(count).enumerate() {
        let byte_idx = i / 2;
        if i % 2 == 0 {
            packed[byte_idx] |= (idx & 0x0F) << 4; // High nibble
        } else {
            packed[byte_idx] |= idx & 0x0F; // Low nibble
        }
    }

    packed
}

/// Measure quantization error (relative RMSE).
fn measure_quantization_error(original: &[f32], indices: &[u8], centroids: &[f32]) -> f32 {
    if original.is_empty() {
        return 0.0;
    }

    let mut sum_sq_error = 0.0f32;
    let mut sum_sq_orig = 0.0f32;

    for (i, &w) in original.iter().enumerate() {
        let reconstructed = centroids[indices[i] as usize];
        sum_sq_error += (w - reconstructed).powi(2);
        sum_sq_orig += w.powi(2);
    }

    if sum_sq_orig == 0.0 {
        return 0.0;
    }

    (sum_sq_error / sum_sq_orig).sqrt()
}

/// Create a constant node for packed indices.
fn create_indices_constant(graph: &mut CompileGraph, indices: &[u8]) -> u32 {
    // Generate a unique ID for the new constant
    let new_id = graph.max_node_id() + 1;

    // Store the data as U8 constant
    graph.add_folded_constant(new_id, ConstantData::U8(indices.to_vec()));

    new_id
}

/// Create a constant node for centroids.
fn create_centroids_constant(graph: &mut CompileGraph, centroids: &[f32]) -> u32 {
    // Generate a unique ID for the new constant
    let new_id = graph.max_node_id() + 2; // +2 to avoid collision with indices

    // Store the data as F32 constant
    graph.add_folded_constant(new_id, ConstantData::F32(centroids.to_vec()));

    new_id
}

#[cfg(test)]
#[allow(clippy::cast_precision_loss)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpNode};
    use crate::OperationGraph;

    #[test]
    fn test_quantize_config_default() {
        let config = QuantizeConfig::default();
        assert_eq!(config.mode, QuantizeMode::Disabled);
        assert!((config.error_threshold - 0.15).abs() < 0.001);
        assert_eq!(config.min_flops, 4096);
        assert_eq!(config.min_k, 32);
        assert!((config.depth_error_scale - 0.02).abs() < 0.001);
    }

    #[test]
    fn test_quantize_config_enabled() {
        let config = QuantizeConfig::enabled();
        assert_eq!(config.mode, QuantizeMode::Enabled);
        assert!(config.is_active());
    }

    #[test]
    fn test_quantize_config_auto() {
        let config = QuantizeConfig::auto();
        assert_eq!(config.mode, QuantizeMode::Auto);
        assert!(config.is_active());
    }

    #[test]
    fn test_quantize_disabled() {
        let mut op_graph = OperationGraph::new();
        op_graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        op_graph.add_input("input", 0);

        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();
        let config = QuantizeConfig::default(); // disabled by default

        let count = quantize_weights(&mut graph, &[], &config);
        assert_eq!(count, 0);
    }

    // --- Heuristics tests ---

    #[test]
    fn test_is_profitable_below_min_flops() {
        let config = QuantizeConfig {
            mode: QuantizeMode::Auto,
            min_flops: 4096,
            min_k: 32,
            ..QuantizeConfig::default()
        };
        // 2 * 2 * 16 * 16 = 1024 FLOPs < 4096
        assert!(!LutGemmHeuristics::is_profitable(2, 16, 16, &config));
    }

    #[test]
    fn test_is_profitable_below_min_k() {
        let config = QuantizeConfig {
            mode: QuantizeMode::Auto,
            min_flops: 4096,
            min_k: 32,
            ..QuantizeConfig::default()
        };
        // K=16 < min_k=32
        assert!(!LutGemmHeuristics::is_profitable(32, 16, 32, &config));
    }

    #[test]
    fn test_is_profitable_large_matmul() {
        let config = QuantizeConfig {
            mode: QuantizeMode::Auto,
            min_flops: 4096,
            min_k: 32,
            ..QuantizeConfig::default()
        };
        // 2 * 64 * 64 * 64 = 524288 FLOPs >> 4096, K=64 >= 32
        assert!(LutGemmHeuristics::is_profitable(64, 64, 64, &config));
    }

    #[test]
    fn test_adaptive_threshold_scaling() {
        let base = 0.15;
        let scale = 0.02;

        // Depth 0: base threshold
        let t0 = adaptive_threshold(base, 0, scale);
        assert!((t0 - 0.15).abs() < 0.001);

        // Depth 5: 0.15 * (1 + 5 * 0.02) = 0.15 * 1.1 = 0.165
        let t5 = adaptive_threshold(base, 5, scale);
        assert!((t5 - 0.165).abs() < 0.001);

        // Depth 10: 0.15 * (1 + 10 * 0.02) = 0.15 * 1.2 = 0.18
        let t10 = adaptive_threshold(base, 10, scale);
        assert!((t10 - 0.18).abs() < 0.001);
    }

    #[test]
    fn test_kmeans_quantize_q4() {
        let weights: Vec<f32> = (0..64).map(|i| i as f32 / 63.0).collect();
        let (indices, centroids) = quantize_kmeans(&weights, 16);

        assert_eq!(indices.len(), 64);
        assert_eq!(centroids.len(), 16);

        // All indices should be in range [0, 15]
        for &idx in &indices {
            assert!(idx < 16);
        }
    }

    #[test]
    fn test_kmeans_quantize_q8() {
        let weights: Vec<f32> = (0..256).map(|i| i as f32 / 255.0).collect();
        let (indices, centroids) = quantize_kmeans(&weights, 256);

        assert_eq!(indices.len(), 256);
        assert_eq!(centroids.len(), 256);

        // Verify indices were assigned (just check the range is populated)
        let max_idx = indices.iter().copied().max().unwrap();
        assert!(max_idx > 0, "At least some indices should be non-zero");
    }

    #[test]
    fn test_pack_q4_indices() {
        let indices = vec![0x0A, 0x05, 0x0F, 0x00];
        let packed = pack_q4_indices(&indices, 4);

        assert_eq!(packed.len(), 2);
        assert_eq!(packed[0], 0xA5); // 0xA << 4 | 0x5
        assert_eq!(packed[1], 0xF0); // 0xF << 4 | 0x0
    }

    #[test]
    fn test_pack_q4_indices_odd() {
        let indices = vec![0x03, 0x07, 0x0B];
        let packed = pack_q4_indices(&indices, 3);

        assert_eq!(packed.len(), 2);
        assert_eq!(packed[0], 0x37); // 0x3 << 4 | 0x7
        assert_eq!(packed[1], 0xB0); // 0xB << 4 | 0x0
    }

    #[test]
    fn test_quantization_error() {
        let original = vec![0.0, 0.5, 1.0];
        let indices = vec![0, 1, 2];
        let centroids = vec![0.0, 0.5, 1.0]; // Perfect reconstruction

        let error = measure_quantization_error(&original, &indices, &centroids);
        assert!(error < 0.001);
    }

    #[test]
    fn test_quantization_error_with_loss() {
        let original = vec![0.0, 0.3, 0.6, 1.0];
        let indices = vec![0, 0, 1, 1]; // Only 2 centroids
        let centroids = vec![0.15, 0.8]; // Approximate centroids

        let error = measure_quantization_error(&original, &indices, &centroids);
        assert!(error > 0.0);
        assert!(error < 1.0);
    }

    #[test]
    fn test_quantize_matmul_with_constant() {
        // Create a graph with: Input -> MatMul(with constant weights) -> Output
        let mut op_graph = OperationGraph::new();

        // Input: [4, 8] (batch=4, features=8)
        op_graph.add_node(OpNode::new(0, OpKind::Input, vec![4, 8], DType::F32));

        // Weights: [8, 16] constant
        op_graph.add_node(OpNode::new(1, OpKind::Constant, vec![8, 16], DType::F32));
        let weights: Vec<f32> = (0..128).map(|i| (i as f32) / 127.0).collect();
        op_graph.add_constant_for_node(1, ConstantData::F32(weights));

        // MatMul: [4, 16]
        op_graph.add_node(OpNode::new(
            2,
            OpKind::MatMul { m: 4, k: 8, n: 16 },
            vec![4, 16],
            DType::F32,
        ));

        // Output
        op_graph.add_node(OpNode::new(3, OpKind::Output, vec![4, 16], DType::F32));

        op_graph.add_edge(0, 2);
        op_graph.add_edge(1, 2);
        op_graph.add_edge(2, 3);

        op_graph.add_input("input", 0);
        op_graph.add_output("output", 3);

        let original_constants = op_graph.constants.clone();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        let config = QuantizeConfig::enabled();

        let count = quantize_weights(&mut graph, &original_constants, &config);
        assert_eq!(count, 1);

        // Check that the MatMul node has the lut_gemm annotation
        let annotations = graph.get_annotations(2);
        assert!(annotations.is_some());
        let anns = annotations.unwrap();
        assert!(anns.iter().any(|a| a.starts_with("lut_gemm:")));
    }
}
