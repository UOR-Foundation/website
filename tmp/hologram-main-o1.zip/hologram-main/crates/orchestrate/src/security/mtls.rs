//! mTLS certificate management for cluster communication.
//!
//! This module provides mTLS certificate generation and management
//! for secure communication between coordinators and workers.
//!
//! # Features Required
//!
//! This module requires the `mtls` feature which brings in:
//! - `rcgen` for certificate generation
//! - `x509-parser` for certificate parsing
//! - `time` for validity timestamps

use crate::error::Result;
use crate::types::WorkerHandle;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::time::Duration;

/// mTLS configuration for cluster communication.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MtlsConfig {
    /// Path to cluster CA certificate.
    pub ca_cert_path: PathBuf,
    /// Path to cluster CA private key.
    pub ca_key_path: PathBuf,
    /// Certificate validity duration in seconds.
    pub cert_validity_secs: u64,
    /// Enable automatic certificate renewal.
    pub auto_renew: bool,
    /// Days before expiry to trigger renewal.
    pub renew_before_days: u32,
}

impl Default for MtlsConfig {
    fn default() -> Self {
        Self {
            ca_cert_path: PathBuf::from("/etc/hologram/ca/ca.crt"),
            ca_key_path: PathBuf::from("/etc/hologram/ca/ca.key"),
            cert_validity_secs: 60 * 60, // 1 hour
            auto_renew: true,
            renew_before_days: 1,
        }
    }
}

impl MtlsConfig {
    /// Create a new mTLS config with default settings.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the CA certificate path.
    #[must_use]
    pub fn with_ca_cert_path(mut self, path: impl Into<PathBuf>) -> Self {
        self.ca_cert_path = path.into();
        self
    }

    /// Set the CA key path.
    #[must_use]
    pub fn with_ca_key_path(mut self, path: impl Into<PathBuf>) -> Self {
        self.ca_key_path = path.into();
        self
    }

    /// Set the certificate validity duration.
    #[must_use]
    pub fn with_cert_validity(mut self, validity: Duration) -> Self {
        self.cert_validity_secs = validity.as_secs();
        self
    }

    /// Set whether to auto-renew certificates.
    #[must_use]
    pub const fn with_auto_renew(mut self, auto_renew: bool) -> Self {
        self.auto_renew = auto_renew;
        self
    }

    /// Get the certificate validity as a Duration.
    #[must_use]
    pub const fn cert_validity(&self) -> Duration {
        Duration::from_secs(self.cert_validity_secs)
    }
}

/// Cluster CA for signing worker and coordinator certificates.
///
/// This is a placeholder type. The full implementation requires
/// the `rcgen` and `x509-parser` dependencies which are only
/// available with the `mtls` feature.
pub struct ClusterCA {
    ca_cert_pem: String,
    ca_key_pem: String,
}

impl ClusterCA {
    /// Generate a new cluster CA.
    ///
    /// # Note
    ///
    /// This is a placeholder. Full implementation requires the `rcgen` crate.
    pub fn generate(_cluster_name: &str, _validity: Duration) -> Result<Self> {
        // Placeholder - would use rcgen to generate certificates
        Ok(Self {
            ca_cert_pem: String::new(),
            ca_key_pem: String::new(),
        })
    }

    /// Load a cluster CA from PEM files.
    pub fn load(ca_cert_pem: &str, ca_key_pem: &str) -> Result<Self> {
        Ok(Self {
            ca_cert_pem: ca_cert_pem.to_string(),
            ca_key_pem: ca_key_pem.to_string(),
        })
    }

    /// Load a cluster CA from file paths.
    pub fn load_from_files(
        ca_cert_path: impl AsRef<std::path::Path>,
        ca_key_path: impl AsRef<std::path::Path>,
    ) -> Result<Self> {
        let ca_cert_pem = std::fs::read_to_string(ca_cert_path)?;
        let ca_key_pem = std::fs::read_to_string(ca_key_path)?;
        Self::load(&ca_cert_pem, &ca_key_pem)
    }

    /// Get the CA certificate in PEM format.
    #[must_use]
    pub fn cert_pem(&self) -> &str {
        &self.ca_cert_pem
    }

    /// Get the CA private key in PEM format.
    #[must_use]
    pub fn key_pem(&self) -> &str {
        &self.ca_key_pem
    }

    /// Save the CA to files.
    pub fn save(
        &self,
        ca_cert_path: impl AsRef<std::path::Path>,
        ca_key_path: impl AsRef<std::path::Path>,
    ) -> Result<()> {
        let ca_cert_path = ca_cert_path.as_ref();
        let ca_key_path = ca_key_path.as_ref();

        if let Some(parent) = ca_cert_path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        if let Some(parent) = ca_key_path.parent() {
            std::fs::create_dir_all(parent)?;
        }

        std::fs::write(ca_cert_path, &self.ca_cert_pem)?;
        std::fs::write(ca_key_path, &self.ca_key_pem)?;

        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let permissions = std::fs::Permissions::from_mode(0o600);
            std::fs::set_permissions(ca_key_path, permissions)?;
        }

        Ok(())
    }

    /// Generate a worker certificate signed by this CA.
    ///
    /// # Note
    ///
    /// This is a placeholder. Full implementation requires the `rcgen` crate.
    pub fn generate_worker_cert(
        &self,
        worker_handle: WorkerHandle,
        _validity: Duration,
    ) -> Result<CertificateBundle> {
        // Placeholder
        Ok(CertificateBundle {
            cert_pem: format!("worker-{} certificate placeholder", worker_handle),
            key_pem: String::new(),
            ca_cert_pem: self.ca_cert_pem.clone(),
        })
    }

    /// Generate a coordinator certificate signed by this CA.
    ///
    /// # Note
    ///
    /// This is a placeholder. Full implementation requires the `rcgen` crate.
    pub fn generate_coordinator_cert(
        &self,
        name: &str,
        _dns_names: Vec<String>,
        _validity: Duration,
    ) -> Result<CertificateBundle> {
        // Placeholder
        Ok(CertificateBundle {
            cert_pem: format!("{name} certificate placeholder"),
            key_pem: String::new(),
            ca_cert_pem: self.ca_cert_pem.clone(),
        })
    }
}

/// A bundle containing certificate, private key, and CA certificate.
#[derive(Debug, Clone)]
pub struct CertificateBundle {
    /// Certificate in PEM format.
    pub cert_pem: String,
    /// Private key in PEM format.
    pub key_pem: String,
    /// CA certificate in PEM format (for verification).
    pub ca_cert_pem: String,
}

impl CertificateBundle {
    /// Save the bundle to files.
    pub fn save(
        &self,
        cert_path: &PathBuf,
        key_path: &PathBuf,
        ca_cert_path: Option<&PathBuf>,
    ) -> Result<()> {
        if let Some(parent) = cert_path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        if let Some(parent) = key_path.parent() {
            std::fs::create_dir_all(parent)?;
        }

        std::fs::write(cert_path, &self.cert_pem)?;
        std::fs::write(key_path, &self.key_pem)?;

        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let permissions = std::fs::Permissions::from_mode(0o600);
            std::fs::set_permissions(key_path, permissions)?;
        }

        if let Some(ca_path) = ca_cert_path {
            if let Some(parent) = ca_path.parent() {
                std::fs::create_dir_all(parent)?;
            }
            std::fs::write(ca_path, &self.ca_cert_pem)?;
        }

        Ok(())
    }
}

/// Information about a certificate.
#[derive(Debug, Clone)]
pub struct CertificateInfo {
    /// Common name from the certificate.
    pub common_name: String,
    /// Organization name.
    pub organization: Option<String>,
    /// Whether this is a CA certificate.
    pub is_ca: bool,
    /// Subject Alternative Names (DNS names).
    pub dns_names: Vec<String>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mtls_config_default() {
        let config = MtlsConfig::default();
        assert!(config.auto_renew);
        assert_eq!(config.cert_validity(), Duration::from_secs(3600));
    }

    #[test]
    fn test_mtls_config_builder() {
        let config = MtlsConfig::new()
            .with_ca_cert_path("/tmp/ca.crt")
            .with_ca_key_path("/tmp/ca.key")
            .with_cert_validity(Duration::from_secs(7200))
            .with_auto_renew(false);

        assert_eq!(config.ca_cert_path, PathBuf::from("/tmp/ca.crt"));
        assert_eq!(config.ca_key_path, PathBuf::from("/tmp/ca.key"));
        assert_eq!(config.cert_validity(), Duration::from_secs(7200));
        assert!(!config.auto_renew);
    }

    #[test]
    fn test_cluster_ca_load() {
        let ca = ClusterCA::load("cert pem", "key pem").unwrap();
        assert_eq!(ca.cert_pem(), "cert pem");
        assert_eq!(ca.key_pem(), "key pem");
    }
}
