//! Hash chain fusion pass.
//!
//! Detects `Sha256 -> Sha256` chains and fuses them into a single
//! `DoubleSha256` operation. The fused op keeps state in registers
//! between hashes, avoiding intermediate buffer materialization.

use crate::graph::{CompileGraph, OpKind};

/// Fuse `Sha256 -> Sha256` chains into `DoubleSha256`.
///
/// Finds pairs where the output of one SHA-256 feeds directly into another
/// SHA-256 (with no other consumers of the intermediate). Replaces the pair
/// with a single `DoubleSha256 { src_len }` using the first node's `src_len`.
pub fn hash_chain_fusion(graph: &mut CompileGraph) {
    let pairs = find_sha256_pairs(graph);

    for (first, second) in pairs {
        // Verify both nodes still exist (earlier fusion may have removed them)
        if graph.get_node(first).is_none() || graph.get_node(second).is_none() {
            continue;
        }
        fuse_sha256_pair(graph, first, second);
    }
}

/// Find `Sha256 -> Sha256` pairs where the intermediate has a single consumer.
fn find_sha256_pairs(graph: &CompileGraph) -> Vec<(u32, u32)> {
    let mut pairs = Vec::new();

    for (id, node) in graph.nodes() {
        let src_len = match &node.op {
            OpKind::Sha256 { src_len } => *src_len,
            _ => continue,
        };

        // Must have exactly one successor
        let succs = graph.successors(id);
        if succs.len() != 1 {
            continue;
        }

        let next_id = succs[0];
        let Some(next_node) = graph.get_node(next_id) else {
            continue;
        };

        // Successor must also be Sha256 consuming 32 bytes (the first hash output)
        let OpKind::Sha256 { src_len: 32 } = &next_node.op else {
            continue;
        };

        // Successor must have exactly one predecessor (this node)
        let next_preds = graph.predecessors(next_id);
        if next_preds.len() != 1 || next_preds[0] != id {
            continue;
        }

        pairs.push((id, next_id));

        // Skip: we use src_len from the first node (already captured above)
        let _ = src_len;
    }

    pairs
}

/// Fuse a `Sha256 -> Sha256` pair into a single `DoubleSha256`.
///
/// Replaces the second node's op with `DoubleSha256`, rewires its predecessor
/// to the first node's predecessor, and removes the first node.
fn fuse_sha256_pair(graph: &mut CompileGraph, first: u32, second: u32) {
    // Get the original input's src_len from the first Sha256
    let src_len = match &graph.get_node(first).unwrap().op {
        OpKind::Sha256 { src_len } => *src_len,
        _ => return,
    };

    // Get the first node's predecessors
    let first_preds = graph.predecessors(first);

    // Replace second node's op with DoubleSha256
    if let Some(node) = graph.get_node_mut(second) {
        node.op = OpKind::DoubleSha256 { src_len };
        node.name = Some("fused:Sha256->Sha256".to_string());
    }

    // Rewire: second's predecessor changes from first to first's predecessors
    for &pred in &first_preds {
        graph.replace_predecessor(second, first, pred);
    }

    // Remove the first (now-orphaned) node
    graph.remove_node(first);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpNode, OperationGraph};

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    #[test]
    fn test_sha256_chain_fuses() {
        // Input -> Sha256 -> Sha256 -> Output
        // Should become: Input -> DoubleSha256 -> Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![80], DType::U8),
                OpNode::new(1, OpKind::Sha256 { src_len: 80 }, vec![32], DType::U8),
                OpNode::new(2, OpKind::Sha256 { src_len: 32 }, vec![32], DType::U8),
                OpNode::new(3, OpKind::Output, vec![32], DType::U8),
            ],
            vec![(0, 1), (1, 2), (2, 3)],
        );

        let before = graph.topo_order().len();
        hash_chain_fusion(&mut graph);
        let after = graph.topo_order().len();

        // Should have removed one node (the first Sha256)
        assert_eq!(after, before - 1);

        // The remaining hash node should be DoubleSha256 with original src_len
        let hash_node = graph.get_node(2).unwrap();
        assert_eq!(hash_node.op, OpKind::DoubleSha256 { src_len: 80 });
    }

    #[test]
    fn test_multi_consumer_does_not_fuse() {
        // Input -> Sha256 -> Sha256 -> Output
        //                \-> Output2
        // First Sha256 has 2 consumers, should NOT fuse
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![80], DType::U8),
                OpNode::new(1, OpKind::Sha256 { src_len: 80 }, vec![32], DType::U8),
                OpNode::new(2, OpKind::Sha256 { src_len: 32 }, vec![32], DType::U8),
                OpNode::new(3, OpKind::Output, vec![32], DType::U8),
                OpNode::new(4, OpKind::Output, vec![32], DType::U8),
            ],
            vec![(0, 1), (1, 2), (2, 3), (1, 4)],
        );

        let before = graph.topo_order().len();
        hash_chain_fusion(&mut graph);
        let after = graph.topo_order().len();

        // No fusion — node count unchanged
        assert_eq!(after, before);
    }

    #[test]
    fn test_three_deep_chain_fuses_first_pair() {
        // Input -> Sha256(80) -> Sha256(32) -> Sha256(32) -> Output
        // Greedy: first pair fuses to DoubleSha256(80), leaving:
        // Input -> DoubleSha256(80) -> Sha256(32) -> Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![80], DType::U8),
                OpNode::new(1, OpKind::Sha256 { src_len: 80 }, vec![32], DType::U8),
                OpNode::new(2, OpKind::Sha256 { src_len: 32 }, vec![32], DType::U8),
                OpNode::new(3, OpKind::Sha256 { src_len: 32 }, vec![32], DType::U8),
                OpNode::new(4, OpKind::Output, vec![32], DType::U8),
            ],
            vec![(0, 1), (1, 2), (2, 3), (3, 4)],
        );

        let before = graph.topo_order().len();
        hash_chain_fusion(&mut graph);
        let after = graph.topo_order().len();

        // At least one pair should fuse
        assert!(after < before, "At least one pair should fuse");
    }

    #[test]
    fn test_no_sha256_no_fusion() {
        // Input -> Relu -> Output — no SHA-256 nodes
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let before = graph.topo_order().len();
        hash_chain_fusion(&mut graph);
        let after = graph.topo_order().len();

        assert_eq!(after, before);
    }

    #[test]
    fn test_single_sha256_no_fusion() {
        // Input -> Sha256 -> Output — single SHA-256, nothing to fuse
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![80], DType::U8),
                OpNode::new(1, OpKind::Sha256 { src_len: 80 }, vec![32], DType::U8),
                OpNode::new(2, OpKind::Output, vec![32], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let before = graph.topo_order().len();
        hash_chain_fusion(&mut graph);
        let after = graph.topo_order().len();

        assert_eq!(after, before);
    }

    #[test]
    fn test_double_sha256_not_fused_again() {
        // Input -> DoubleSha256 -> Sha256 -> Output
        // DoubleSha256 is not Sha256, so no fusion
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![80], DType::U8),
                OpNode::new(1, OpKind::DoubleSha256 { src_len: 80 }, vec![32], DType::U8),
                OpNode::new(2, OpKind::Sha256 { src_len: 32 }, vec![32], DType::U8),
                OpNode::new(3, OpKind::Output, vec![32], DType::U8),
            ],
            vec![(0, 1), (1, 2), (2, 3)],
        );

        let before = graph.topo_order().len();
        hash_chain_fusion(&mut graph);
        let after = graph.topo_order().len();

        assert_eq!(after, before);
    }
}
