//! JSON-LD emission for derivation chains and observables.
//!
//! This module provides serialization of derivation chains and observable types
//! to JSON-LD format, compatible with the UOR Foundation ontology.

use crate::chain::{DerivationChain, DerivationStep, StepKind};
use crate::factorize::FactorizationResult;
use uor::observable::{CascadeSpectrum, MonodromySignature, TotalVariation, WindingNumber};

/// Trait for types that can be serialized to JSON-LD.
pub trait ToJsonLd {
    /// Convert to JSON-LD representation.
    fn to_jsonld(&self) -> serde_json::Value;

    /// Get the JSON-LD @type for this value.
    fn jsonld_type() -> &'static str;
}

impl ToJsonLd for StepKind {
    fn to_jsonld(&self) -> serde_json::Value {
        serde_json::json!(self.as_str())
    }

    fn jsonld_type() -> &'static str {
        "derivation:StepKind"
    }
}

impl StepKind {
    /// Get the string representation for JSON-LD.
    pub fn as_str(&self) -> &'static str {
        match self {
            StepKind::TypeDeclaration => "type_declaration",
            StepKind::QuantumSelection => "quantum_selection",
            StepKind::StepPrediction => "step_prediction",
            StepKind::OrbitGeneration => "orbit_generation",
            StepKind::CoordinateReading => "coordinate_reading",
            StepKind::FactorCompletion => "factor_completion",
            StepKind::CertificateEmission => "certificate_emission",
            StepKind::Gcd => "gcd",
            StepKind::IntegerDivision => "integer_division",
            StepKind::Compute => "compute",
        }
    }
}

impl ToJsonLd for DerivationStep {
    fn to_jsonld(&self) -> serde_json::Value {
        let mut step = serde_json::json!({
            "@type": Self::jsonld_type(),
            "derivation:index": self.index,
            "rdfs:label": self.label,
            "derivation:kind": self.kind.as_str(),
            "derivation:input": self.input,
            "derivation:output": self.output
        });

        if let Some(ref assertion) = self.assertion {
            step["derivation:assertion"] = serde_json::json!(assertion);
        }
        if let Some(ref justification) = self.justification {
            step["derivation:justification"] = serde_json::json!(justification);
        }

        step
    }

    fn jsonld_type() -> &'static str {
        "derivation:DerivationStep"
    }
}

impl ToJsonLd for DerivationChain {
    fn to_jsonld(&self) -> serde_json::Value {
        let steps: Vec<serde_json::Value> = self.steps.iter().map(|s| s.to_jsonld()).collect();

        serde_json::json!({
            "@context": {
                "derivation": "https://uor.foundation/derivation/",
                "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
                "xsd": "http://www.w3.org/2001/XMLSchema#"
            },
            "@id": self.id,
            "@type": Self::jsonld_type(),
            "rdfs:label": self.label,
            "rdfs:comment": self.description,
            "derivation:timestamp": self.timestamp,
            "derivation:stepCount": self.steps.len(),
            "derivation:steps": steps
        })
    }

    fn jsonld_type() -> &'static str {
        "derivation:DerivationChain"
    }
}

impl ToJsonLd for FactorizationResult {
    fn to_jsonld(&self) -> serde_json::Value {
        serde_json::json!({
            "@context": {
                "derivation": "https://uor.foundation/derivation/",
                "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
                "xsd": "http://www.w3.org/2001/XMLSchema#"
            },
            "@id": format!("https://uor.foundation/factorization/{}", self.n),
            "@type": Self::jsonld_type(),
            "derivation:semiprime": self.n,
            "derivation:factor_p": self.p,
            "derivation:factor_q": self.q,
            "derivation:quantum": self.k,
            "derivation:orbitIndex": self.i,
            "derivation:orbitValue": self.v,
            "derivation:verified": self.p * self.q == self.n
        })
    }

    fn jsonld_type() -> &'static str {
        "derivation:FactorizationResult"
    }
}

/// Emit a complete factorization proof as JSON-LD.
///
/// This combines the factorization result and its derivation chain
/// into a single JSON-LD document.
pub fn emit_factorization_proof(
    result: &FactorizationResult,
    timestamp: &str,
) -> serde_json::Value {
    let chain = crate::factorize::factorization_derivation(result, timestamp);

    serde_json::json!({
        "@context": {
            "derivation": "https://uor.foundation/derivation/",
            "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
            "xsd": "http://www.w3.org/2001/XMLSchema#",
            "observable": "https://uor.foundation/observable/"
        },
        "@graph": [
            result.to_jsonld(),
            chain.to_jsonld()
        ]
    })
}

// ============================================================================
// Observable ToJsonLd implementations
// ============================================================================

impl ToJsonLd for WindingNumber {
    fn to_jsonld(&self) -> serde_json::Value {
        serde_json::json!({
            "@type": Self::jsonld_type(),
            "observable:value": self.value
        })
    }

    fn jsonld_type() -> &'static str {
        "observable:WindingNumber"
    }
}

impl ToJsonLd for TotalVariation {
    fn to_jsonld(&self) -> serde_json::Value {
        serde_json::json!({
            "@type": Self::jsonld_type(),
            "observable:value": self.value
        })
    }

    fn jsonld_type() -> &'static str {
        "observable:TotalVariation"
    }
}

impl ToJsonLd for CascadeSpectrum {
    fn to_jsonld(&self) -> serde_json::Value {
        serde_json::json!({
            "@type": Self::jsonld_type(),
            "observable:bins": self.bins
        })
    }

    fn jsonld_type() -> &'static str {
        "observable:CascadeSpectrum"
    }
}

impl ToJsonLd for MonodromySignature {
    fn to_jsonld(&self) -> serde_json::Value {
        serde_json::json!({
            "@type": Self::jsonld_type(),
            "observable:winding": self.winding,
            "observable:totalVariation": self.total_variation,
            "observable:cascadeSpectrum": self.cascade_spectrum
        })
    }

    fn jsonld_type() -> &'static str {
        "observable:MonodromySignature"
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::factorize::factorize_semiprime;

    #[test]
    fn test_step_kind_as_str() {
        assert_eq!(StepKind::TypeDeclaration.as_str(), "type_declaration");
        assert_eq!(StepKind::Gcd.as_str(), "gcd");
        assert_eq!(
            StepKind::CertificateEmission.as_str(),
            "certificate_emission"
        );
    }

    #[test]
    fn test_step_to_jsonld() {
        let step = DerivationStep::new(0, "Test Step", StepKind::Compute)
            .with_input(serde_json::json!({"x": 1}))
            .with_output(serde_json::json!({"y": 2}))
            .with_assertion("Test assertion");

        let jsonld = step.to_jsonld();

        assert_eq!(jsonld["@type"], "derivation:DerivationStep");
        assert_eq!(jsonld["derivation:index"], 0);
        assert_eq!(jsonld["rdfs:label"], "Test Step");
        assert!(jsonld["derivation:assertion"].is_string());
    }

    #[test]
    fn test_chain_to_jsonld() {
        let mut chain = DerivationChain::new("https://test/1", "Test Chain")
            .with_description("A test chain")
            .with_timestamp("2026-02-05T00:00:00Z");

        chain.add_step(DerivationStep::new(0, "Step 0", StepKind::Compute));

        let jsonld = chain.to_jsonld();

        assert_eq!(jsonld["@type"], "derivation:DerivationChain");
        assert_eq!(jsonld["derivation:stepCount"], 1);
        assert!(jsonld["derivation:steps"].is_array());
    }

    #[test]
    fn test_factorization_result_to_jsonld() {
        let result = factorize_semiprime(10403, 32).unwrap();
        let jsonld = result.to_jsonld();

        assert_eq!(jsonld["@type"], "derivation:FactorizationResult");
        assert_eq!(jsonld["derivation:semiprime"], 10403);
        assert_eq!(jsonld["derivation:factor_p"], 101);
        assert_eq!(jsonld["derivation:factor_q"], 103);
        assert_eq!(jsonld["derivation:verified"], true);
    }

    #[test]
    fn test_emit_factorization_proof() {
        let result = factorize_semiprime(10403, 32).unwrap();
        let proof = emit_factorization_proof(&result, "2026-02-05T00:00:00Z");

        assert!(proof["@context"].is_object());
        assert!(proof["@graph"].is_array());

        let graph = proof["@graph"].as_array().unwrap();
        assert_eq!(graph.len(), 2);

        // First element is the result
        assert_eq!(graph[0]["@type"], "derivation:FactorizationResult");

        // Second element is the chain
        assert_eq!(graph[1]["@type"], "derivation:DerivationChain");
    }

    #[test]
    fn test_jsonld_is_valid_json() {
        let result = factorize_semiprime(10403, 32).unwrap();
        let proof = emit_factorization_proof(&result, "2026-02-05T00:00:00Z");

        // Verify it can be serialized to a string and back
        let json_string = serde_json::to_string_pretty(&proof).unwrap();
        let _parsed: serde_json::Value = serde_json::from_str(&json_string).unwrap();
    }

    #[test]
    fn test_winding_number_to_jsonld() {
        let w = WindingNumber { value: 42 };
        let json = w.to_jsonld();

        assert_eq!(json["@type"], "observable:WindingNumber");
        assert_eq!(json["observable:value"], 42);
    }

    #[test]
    fn test_total_variation_to_jsonld() {
        let tv = TotalVariation { value: 100 };
        let json = tv.to_jsonld();

        assert_eq!(json["@type"], "observable:TotalVariation");
        assert_eq!(json["observable:value"], 100);
    }

    #[test]
    fn test_cascade_spectrum_to_jsonld() {
        let cs = CascadeSpectrum {
            bins: vec![128, 64, 32, 16, 8, 4, 2, 1],
        };
        let json = cs.to_jsonld();

        assert_eq!(json["@type"], "observable:CascadeSpectrum");
        assert!(json["observable:bins"].is_array());
        assert_eq!(json["observable:bins"].as_array().unwrap().len(), 8);
    }

    #[test]
    fn test_monodromy_signature_to_jsonld() {
        let sig = MonodromySignature {
            winding: 1,
            total_variation: 256,
            cascade_spectrum: vec![128, 64, 32, 16, 8, 4, 2, 1],
        };
        let json = sig.to_jsonld();

        assert_eq!(json["@type"], "observable:MonodromySignature");
        assert_eq!(json["observable:winding"], 1);
        assert_eq!(json["observable:totalVariation"], 256);
        assert!(json["observable:cascadeSpectrum"].is_array());
    }
}
