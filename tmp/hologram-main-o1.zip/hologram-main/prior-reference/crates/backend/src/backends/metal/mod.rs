//! Metal backend implementation (macOS only).
//!
//! This module provides the Metal GPU backend for macOS systems using Metal.framework.
//! Only available on macOS with the `metal` feature enabled.

mod gpu;
pub mod textures;

pub use gpu::MetalBackend;
pub use textures::{MetalActivationTextures, MetalTextureHandle};
