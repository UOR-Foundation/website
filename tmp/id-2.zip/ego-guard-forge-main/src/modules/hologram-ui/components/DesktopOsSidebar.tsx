/**
 * DesktopOsSidebar — Simplified replica of the Hologram OS sidebar.
 * Auth-aware: shows user avatar + sign-out when logged in.
 */

import { useCallback, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/use-auth";
import {
  Home, Fingerprint,
  Settings, HelpCircle, Inbox, PanelLeftOpen, PanelLeftClose,
  LogOut,
} from "lucide-react";
import HologramLogo from "./HologramLogo";

/* ── Tooltip wrapper ───────────────────────────────────────── */
function IconTooltip({ label, children, show }: { label: string; children: React.ReactNode; show: boolean }) {
  if (!show) return <>{children}</>;
  return (
    <div className="relative group/tip">
      {children}
      <div className="pointer-events-none absolute left-full top-1/2 -translate-y-1/2 ml-3 px-3 py-1.5 rounded-lg text-[13px] font-light whitespace-nowrap opacity-0 scale-95 group-hover/tip:opacity-100 group-hover/tip:scale-100 transition-all duration-200 z-50"
        style={{ background: "hsl(25, 8%, 15%)", color: "hsl(38, 10%, 88%)", border: "1px solid hsla(38, 12%, 70%, 0.15)" }}>
        {label}
      </div>
    </div>
  );
}

/* ── Nav items ─────────────────────────────────────────────── */
interface NavItem { label: string; icon: React.ElementType; path: string }

const NAV_ITEMS: NavItem[] = [
  { label: "Home",       icon: Home,        path: "/" },
  { label: "My Space",   icon: Fingerprint, path: "/identity" },
];

const COLLAPSED_W = 68;
const EXPANDED_W = 220;

interface DesktopOsSidebarProps {
  bgMode?: "image" | "white" | "dark";
}

export default function DesktopOsSidebar({ bgMode = "dark" }: DesktopOsSidebarProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [expanded, setExpanded] = useState(false);
  const { profile, session, signOut } = useAuth();

  const isActive = useCallback(
    (path: string) => location.pathname === path || (path !== "/" && location.pathname.startsWith(path.split("#")[0])),
    [location.pathname],
  );

  const collapseAndDo = useCallback((action: () => void) => {
    if (expanded) {
      setExpanded(false);
      requestAnimationFrame(() => action());
    } else {
      action();
    }
  }, [expanded]);

  const handleSignOut = useCallback(async () => {
    await signOut();
    navigate("/");
  }, [signOut, navigate]);

  const w = expanded ? EXPANDED_W : COLLAPSED_W;

  const vars = bgMode === "white"
    ? {
        "--sb-bg": "hsl(0, 0%, 97%)",
        "--sb-hover": "hsla(0, 0%, 0%, 0.04)",
        "--sb-active": "hsla(0, 0%, 0%, 0.08)",
        "--sb-border": "hsla(0, 0%, 0%, 0.08)",
        "--sb-text": "hsl(0, 0%, 15%)",
        "--sb-muted": "hsl(0, 0%, 45%)",
        "--sb-gold": "hsl(38, 35%, 42%)",
      }
    : {
        "--sb-bg": "hsl(25, 8%, 10%)",
        "--sb-hover": "hsla(38, 12%, 90%, 0.08)",
        "--sb-active": "hsla(38, 20%, 85%, 0.12)",
        "--sb-border": "hsla(38, 12%, 70%, 0.1)",
        "--sb-text": "hsl(38, 10%, 88%)",
        "--sb-muted": "hsl(38, 8%, 60%)",
        "--sb-gold": "hsl(38, 40%, 65%)",
      };

  const renderNavButton = (item: NavItem, active: boolean) => (
    <IconTooltip key={item.path} label={item.label} show={!expanded}>
      <button
        onClick={() => collapseAndDo(() => navigate(item.path))}
        className={`w-full flex items-center gap-3 rounded-xl transition-colors duration-200 ${
          !expanded ? "justify-center px-0 py-3" : "px-3.5 py-3"
        }`}
        style={{
          color: active ? "var(--sb-gold)" : "var(--sb-text)",
          background: active ? "var(--sb-active)" : "transparent",
        }}
      >
        <item.icon
          className="w-5 h-5 shrink-0"
          strokeWidth={1.5}
          style={{ color: active ? "var(--sb-gold)" : "var(--sb-muted)" }}
        />
        {expanded && (
          <span className="text-[14px] font-light whitespace-nowrap">{item.label}</span>
        )}
      </button>
    </IconTooltip>
  );

  return (
    <aside
      className="flex flex-col h-full shrink-0 relative"
      style={{
        ...vars,
        width: `${w}px`,
        background: "var(--sb-bg)",
        borderRight: "1px solid var(--sb-border)",
        willChange: "width",
        transition: "width 350ms cubic-bezier(0.4, 0, 0.2, 1)",
        fontFamily: "'DM Sans', system-ui, sans-serif",
      } as React.CSSProperties}
    >
      {/* ── Top: Logo / toggle ─────────────────────────────────── */}
      <div className="flex items-center justify-between px-3 pt-5 pb-6">
        {expanded ? (
          <>
            <div className="flex items-center gap-2.5 px-2 py-1 overflow-hidden">
              <HologramLogo
                size={28}
                color={bgMode === "white" ? "hsl(30, 15%, 30%)" : "hsl(38, 25%, 80%)"}
                className="shrink-0"
              />
              <svg
                viewBox="0 0 360 40"
                className="select-none"
                style={{ width: "115px", height: "auto", opacity: 0.9 }}
              >
                <g
                  fill="none"
                  stroke="var(--sb-text)"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <line x1="10" y1="6" x2="10" y2="34" />
                  <line x1="30" y1="6" x2="30" y2="34" />
                  <line x1="10" y1="20" x2="30" y2="20" />
                  <ellipse cx="60" cy="20" rx="14" ry="14" />
                  <line x1="94" y1="6" x2="94" y2="34" />
                  <line x1="94" y1="34" x2="114" y2="34" />
                  <ellipse cx="144" cy="20" rx="14" ry="14" />
                  <path d="M 198 12 A 14 14 0 1 0 198 28 L 198 20 L 188 20" />
                  <line x1="222" y1="6" x2="222" y2="34" />
                  <path d="M 222 6 L 236 6 A 7 7 0 0 1 236 20 L 222 20" />
                  <line x1="232" y1="20" x2="242" y2="34" />
                  <line x1="266" y1="34" x2="280" y2="6" />
                  <line x1="280" y1="6" x2="294" y2="34" />
                  <line x1="318" y1="34" x2="318" y2="6" />
                  <line x1="318" y1="6" x2="334" y2="22" />
                  <line x1="334" y1="22" x2="350" y2="6" />
                  <line x1="350" y1="6" x2="350" y2="34" />
                </g>
              </svg>
            </div>
            <button
              onClick={() => setExpanded(false)}
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ color: "var(--sb-muted)" }}
              title="Collapse sidebar"
            >
              <PanelLeftClose className="w-4 h-4" />
            </button>
          </>
        ) : (
          <button
            onClick={() => setExpanded(true)}
            className="group/logo w-11 h-11 mx-auto rounded-xl flex items-center justify-center transition-transform duration-200 hover:scale-105 relative"
            title="Expand sidebar"
          >
            <HologramLogo
              size={24}
              color={bgMode === "white" ? "hsl(30, 15%, 30%)" : "hsl(38, 25%, 80%)"}
              className="absolute transition-opacity duration-200 group-hover/logo:opacity-0"
            />
            <PanelLeftOpen
              className="w-5 h-5 absolute transition-opacity duration-200 opacity-0 group-hover/logo:opacity-100"
              strokeWidth={1.4}
              style={{ color: "var(--sb-gold)" }}
            />
          </button>
        )}
      </div>

      {/* ── Core Navigation ───────────────────────────────────── */}
      <div className="flex-1 px-2.5 space-y-1 overflow-hidden">
        {NAV_ITEMS.map((item) => renderNavButton(item, isActive(item.path)))}
      </div>

      {/* ── Bottom: User section + Settings ───────────────────── */}
      <div className="px-2.5 py-4 space-y-1" style={{ borderTop: "1px solid var(--sb-border)" }}>
        {/* User avatar / sign-in indicator */}
        {session && profile ? (
          <IconTooltip label={profile.displayName} show={!expanded}>
            <div
              className={`w-full flex items-center gap-3 rounded-xl px-2 py-2 ${
                !expanded ? "justify-center" : ""
              }`}
            >
              {profile.avatarUrl ? (
                <img
                  src={profile.avatarUrl}
                  alt=""
                  className="w-7 h-7 rounded-full object-cover shrink-0"
                  style={{ border: "1.5px solid var(--sb-border)" }}
                />
              ) : (
                <div
                  className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium shrink-0"
                  style={{
                    background: "var(--sb-active)",
                    color: "var(--sb-gold)",
                    border: "1.5px solid var(--sb-border)",
                  }}
                >
                  {profile.displayName.charAt(0).toUpperCase()}
                </div>
              )}
              {expanded && (
                <div className="flex-1 min-w-0">
                  <p className="text-[13px] font-medium truncate" style={{ color: "var(--sb-text)" }}>
                    {profile.displayName}
                  </p>
                  <p className="text-[11px] truncate" style={{ color: "var(--sb-muted)" }}>
                    {profile.handle}
                  </p>
                </div>
              )}
            </div>
          </IconTooltip>
        ) : null}

        {[
          { label: "Inbox", icon: Inbox, action: undefined },
          { label: "Help", icon: HelpCircle, action: undefined },
          { label: "Settings", icon: Settings, action: undefined },
        ].map(({ label, icon: Icon, action }) => (
          <IconTooltip key={label} label={label} show={!expanded}>
            <button
              onClick={action}
              className={`w-full flex items-center gap-3 rounded-xl transition-colors duration-200 ${
                !expanded ? "justify-center px-0 py-3" : "px-3.5 py-3"
              }`}
              style={{ color: "var(--sb-text)" }}
            >
              <Icon className="w-5 h-5" strokeWidth={1.5} style={{ color: "var(--sb-muted)" }} />
              {expanded && <span className="text-[14px] font-light">{label}</span>}
            </button>
          </IconTooltip>
        ))}

        {/* Sign out — only when logged in */}
        {session && (
          <IconTooltip label="Sign out" show={!expanded}>
            <button
              onClick={handleSignOut}
              className={`w-full flex items-center gap-3 rounded-xl transition-colors duration-200 hover:opacity-80 ${
                !expanded ? "justify-center px-0 py-3" : "px-3.5 py-3"
              }`}
              style={{ color: "var(--sb-muted)" }}
            >
              <LogOut className="w-5 h-5" strokeWidth={1.5} style={{ color: "var(--sb-muted)" }} />
              {expanded && <span className="text-[14px] font-light">Sign out</span>}
            </button>
          </IconTooltip>
        )}
      </div>
    </aside>
  );
}
