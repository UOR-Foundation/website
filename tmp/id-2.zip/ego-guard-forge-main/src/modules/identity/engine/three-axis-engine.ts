/**
 * Three-Axis Separation Engine — Φ_v5 = Φ_agent · Φ_data · Φ_inference
 * ═════════════════════════════════════════════════════════════════════
 *
 * From V5 Pathway §2 (M1) and §3.1 (Compression-as-Defence):
 *
 * Three orthogonal separation axes multiply to produce total sovereignty.
 * Missing any one axis makes the identity vulnerable — the product captures
 * this multiplicative fragility.
 *
 * Φ_agent = min(1.0, (S/M) / κ) · det(Σ)
 * Φ_data  = fragmentation entropy / target entropy
 * Φ_inference = min(1.0, compression_ratio / target_compression)
 *
 * R_v5(d) = R_v4(d) · (1 - 1/compression_ratio)
 *   Every token not emitted is a token the adversary cannot intercept.
 *
 * Pure functions. No classes. No side effects.
 *
 * @module identity/engine/three-axis
 */

import type { SovereigntySurface } from "../types";
import type {
  AgentSeparationMatrix,
  AgentAxisMetrics,
  DataProvider,
  DataAxisMetrics,
  InferenceAxisMetrics,
  ThreeAxisSeparation,
  ThreeAxisConfig,
} from "../types/three-axis";
import { disclosureRatio, dimensionDisclosureRatios } from "./sovereignty-engine";

// ── Default Configuration ───────────────────────────────────────────────────

export const DEFAULT_THREE_AXIS_CONFIG: ThreeAxisConfig = {
  kappa: 1.618033988749895,         // φ — golden ratio (candidate optimal)
  targetCompression: 74,            // 74× from BRAID benchmarks
  targetProviderCount: 3,           // minimum for meaningful fragmentation
  targetEntropy: Math.log(3),       // ln(3) ≈ 1.099 — uniform over 3 providers
};

// ── Agent Axis: Φ_agent ─────────────────────────────────────────────────────

/**
 * Build the 4×4 agent separation matrix Σ from the sovereignty surface.
 *
 * The matrix models the separation between the Guardian (Swordsman/privacy)
 * and Delegate (Mage/interaction) roles across 4 operational modes:
 *   [0] Shield  — Guardian-only, no delegation
 *   [1] Prove   — Guardian signs, Delegate verifies (ZKP mode)
 *   [2] Attest  — Delegate acts, Guardian audits
 *   [3] Open    — Full delegation (reduced sovereignty)
 *
 * σ_ij = separation between mode i and mode j.
 * Diagonal = self-separation (always 1.0).
 * Off-diagonal = derived from the sovereignty surface edge states.
 */
function buildAgentMatrix(surface: SovereigntySurface): AgentSeparationMatrix {
  const ratios = dimensionDisclosureRatios(surface);

  // Map dimensions to operational modes:
  // Shield ← identity+governance (guardian boundary)
  // Prove  ← data+compute (ZKP operations)
  // Attest ← social+economic (delegation scope)
  // Open   ← overall disclosure ratio
  const shieldStrength = 1 - (ratios.identity + ratios.governance) / 2;
  const proveStrength = ratios.data > 0 || ratios.compute > 0
    ? Math.min(1, (ratios.data + ratios.compute) / 2 + 0.3) // ZKP adds baseline
    : 0.3; // Even with no disclosure, ZKP capability exists
  const attestStrength = (ratios.social + ratios.economic) / 2;
  const openLevel = disclosureRatio(surface);

  // Build 4×4 matrix: σ_ij = |mode_i - mode_j| (normalized separation)
  const modes = [shieldStrength, proveStrength, attestStrength, openLevel];
  const entries: number[] = [];

  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      if (i === j) {
        entries.push(1.0); // self-separation is maximal
      } else {
        // Cross-separation: how different are these two modes?
        entries.push(Math.abs(modes[i] - modes[j]));
      }
    }
  }

  // Compute determinant of 4×4 matrix (cofactor expansion)
  const det = determinant4x4(entries);

  // S/M ratio: Shield strength vs Open level (Guardian vs Mage separation)
  const sOverM = openLevel > 0 ? shieldStrength / openLevel : shieldStrength > 0 ? 10 : 1;

  return {
    entries,
    determinant: Math.abs(det),
    separationRatio: sOverM,
    kappa: DEFAULT_THREE_AXIS_CONFIG.kappa,
  };
}

/** Compute determinant of a 4×4 matrix (stored as flat 16-element array). */
function determinant4x4(m: number[]): number {
  // Using cofactor expansion along first row
  const minor = (row: number, col: number): number[] => {
    const result: number[] = [];
    for (let i = 0; i < 4; i++) {
      if (i === row) continue;
      for (let j = 0; j < 4; j++) {
        if (j === col) continue;
        result.push(m[i * 4 + j]);
      }
    }
    return result;
  };

  const det3x3 = (a: number[]): number =>
    a[0] * (a[4] * a[8] - a[5] * a[7]) -
    a[1] * (a[3] * a[8] - a[5] * a[6]) +
    a[2] * (a[3] * a[7] - a[4] * a[6]);

  return (
    m[0] * det3x3(minor(0, 0)) -
    m[1] * det3x3(minor(0, 1)) +
    m[2] * det3x3(minor(0, 2)) -
    m[3] * det3x3(minor(0, 3))
  );
}

export function computeAgentAxis(
  surface: SovereigntySurface,
  config: ThreeAxisConfig = DEFAULT_THREE_AXIS_CONFIG,
): AgentAxisMetrics {
  const matrix = buildAgentMatrix(surface);

  // Φ_agent = min(1.0, (S/M) / κ) · det(Σ)
  const ratioTerm = Math.min(1.0, matrix.separationRatio / config.kappa);
  // Normalize determinant (4×4 det can be large)
  const detNorm = Math.min(1.0, matrix.determinant);
  const phi = ratioTerm * detNorm;

  // Guardian/Delegate active = derived from identity+governance presence
  const ratios = dimensionDisclosureRatios(surface);
  const guardianActive = ratios.identity < 1.0; // not fully disclosed = guardian protecting
  const delegateActive = ratios.social > 0 || ratios.economic > 0; // some delegation happening

  return {
    phi: Math.max(0, Math.min(1, phi)),
    matrix,
    guardianActive,
    delegateActive,
  };
}

// ── Data Axis: Φ_data ───────────────────────────────────────────────────────

/**
 * Derive data providers from the sovereignty surface.
 *
 * The provider topology is inferred from edge states:
 *   - Shielded edges → local-only storage (device)
 *   - Selective edges → decentralized (ZKP-gated, multi-provider)
 *   - Disclosed edges → cloud/federated (shared with services)
 *
 * Fragmentation = Shannon entropy of the edge distribution across providers.
 * Higher entropy = better separation = harder to reconstruct.
 */
function deriveDataProviders(surface: SovereigntySurface): readonly DataProvider[] {
  const shielded = surface.edges.filter((e) => e.state === "shielded").length;
  const selective = surface.edges.filter((e) => e.state === "selective").length;
  const disclosed = surface.edges.filter((e) => e.state === "disclosed").length;

  const providers: DataProvider[] = [];

  if (shielded > 0) {
    providers.push({
      id: "local-device",
      name: "On-Device Storage",
      type: "local",
      edgesCovered: shielded,
    });
  }

  if (selective > 0) {
    providers.push({
      id: "zkp-gateway",
      name: "ZKP-Gated Decentralized",
      type: "decentralized",
      edgesCovered: selective,
    });
  }

  if (disclosed > 0) {
    // Split disclosed edges across cloud and federated to model real-world topology
    const cloudShare = Math.ceil(disclosed * 0.6);
    const fedShare = disclosed - cloudShare;

    providers.push({
      id: "cloud-primary",
      name: "Cloud Provider",
      type: "cloud",
      edgesCovered: cloudShare,
    });

    if (fedShare > 0) {
      providers.push({
        id: "federated-peer",
        name: "Federated Peer Network",
        type: "federated",
        edgesCovered: fedShare,
      });
    }
  }

  // If no edges are non-shielded, there's still the local provider
  if (providers.length === 0) {
    providers.push({
      id: "local-device",
      name: "On-Device Storage",
      type: "local",
      edgesCovered: 96,
    });
  }

  return providers;
}

/** Compute Shannon entropy of a probability distribution. */
function shannonEntropy(probabilities: readonly number[]): number {
  return -probabilities
    .filter((p) => p > 0)
    .reduce((sum, p) => sum + p * Math.log(p), 0);
}

export function computeDataAxis(
  surface: SovereigntySurface,
  config: ThreeAxisConfig = DEFAULT_THREE_AXIS_CONFIG,
): DataAxisMetrics {
  const providers = deriveDataProviders(surface);
  const totalEdges = surface.edges.length;

  // Probability distribution: each provider's share of edges
  const shares = providers.map((p) => p.edgesCovered / totalEdges);
  const entropy = shannonEntropy(shares);
  const maxShare = Math.max(...shares);

  // Shielded fraction = local-only storage
  const shielded = surface.edges.filter((e) => e.state === "shielded").length;
  const shieldedFraction = shielded / totalEdges;

  // Φ_data = (entropy / target_entropy) * provider_count_factor
  // More providers AND higher entropy = better fragmentation
  const entropyRatio = Math.min(1.0, entropy / config.targetEntropy);
  const countFactor = Math.min(1.0, providers.length / config.targetProviderCount);

  // Weight: entropy matters more than count (70/30)
  const phi = 0.7 * entropyRatio + 0.3 * countFactor;

  return {
    phi: Math.max(0, Math.min(1, phi)),
    providerCount: providers.length,
    fragmentationIndex: entropy,
    maxSingleProviderShare: maxShare,
    providers,
    shieldedFraction,
  };
}

// ── Inference Axis: Φ_inference ─────────────────────────────────────────────

/**
 * Compute inference axis metrics from the sovereignty surface.
 *
 * The inference axis measures Generator/Solver split efficiency and
 * compression-as-defence. From V5 §3.1:
 *   R_v5(d) = R_v4(d) · (1 - 1/compression_ratio)
 *   Every token not emitted = a token the adversary cannot intercept.
 *
 * The compute↔social dimension pair models the Generator/Solver boundary:
 *   - Compute = Generator (on-device reasoning, planning)
 *   - Social = Solver (networked execution, delegation)
 *
 * Compression ratio is derived from the boundary topology:
 *   - Fully shielded = maximum compression (nothing leaves device)
 *   - Fully disclosed = minimum compression (1:1, everything visible)
 *   - Selective = intermediate (ZKP compresses proofs)
 */
export function computeInferenceAxis(
  surface: SovereigntySurface,
  config: ThreeAxisConfig = DEFAULT_THREE_AXIS_CONFIG,
): InferenceAxisMetrics {
  const ratios = dimensionDisclosureRatios(surface);

  // Generator = compute dimension (on-device reasoning)
  // Solver = social dimension (networked execution)
  const generatorFraction = 1 - ratios.compute; // more shielded compute = more local generation
  const solverFraction = 1 - generatorFraction;

  // Compression ratio derived from boundary topology
  // Shielded edges = infinite compression (nothing emitted)
  // Selective edges = ZKP compression (~3000× from V5 C5)
  // Disclosed edges = 1:1 (no compression)
  const shielded = surface.edges.filter((e) => e.state === "shielded").length;
  const selective = surface.edges.filter((e) => e.state === "selective").length;
  const disclosed = surface.edges.filter((e) => e.state === "disclosed").length;
  const total = surface.edges.length;

  // Weighted compression: shielded contributes target×2, selective contributes target, disclosed contributes 1
  const compressionRatio = total > 0
    ? (shielded * config.targetCompression * 2 + selective * config.targetCompression + disclosed * 1) / total
    : config.targetCompression;

  // Φ_inference = min(1.0, compression_ratio / target_compression)
  const phi = Math.min(1.0, compressionRatio / config.targetCompression);

  // Reconstruction defence: (1 - 1/compressionRatio)
  const reconstructionDefence = 1 - 1 / Math.max(1, compressionRatio);

  // PPD approximation from BRAID data (scaled by compression efficiency)
  const ppd = phi * 74; // 74× at full efficiency

  return {
    phi: Math.max(0, Math.min(1, phi)),
    compressionRatio,
    reconstructionDefence,
    generatorFraction,
    solverFraction,
    ppd,
    bounded: shielded + selective > disclosed, // bounded if more constrained than open
  };
}

// ── Three-Axis Product ──────────────────────────────────────────────────────

/**
 * Compute the complete V5 three-axis separation:
 *   Φ_v5 = Φ_agent · Φ_data · Φ_inference
 *
 * The product is multiplicative by design — sovereignty requires ALL three axes.
 * Missing any one axis collapses the entire product.
 */
export function computeThreeAxisSeparation(
  surface: SovereigntySurface,
  config: ThreeAxisConfig = DEFAULT_THREE_AXIS_CONFIG,
): ThreeAxisSeparation {
  const agent = computeAgentAxis(surface, config);
  const data = computeDataAxis(surface, config);
  const inference = computeInferenceAxis(surface, config);

  const phi_v5 = agent.phi * data.phi * inference.phi;

  // R_v5(d) = base_difficulty · (1 - 1/compression_ratio)
  // Base difficulty from agent + data separation
  const baseDifficulty = (agent.phi + data.phi) / 2;
  const reconstructionDifficulty = baseDifficulty * inference.reconstructionDefence;

  // Find weakest axis
  const weakestAxis = agent.phi <= data.phi && agent.phi <= inference.phi
    ? "agent"
    : data.phi <= inference.phi
      ? "data"
      : "inference";

  // Classification
  const sovereigntyLevel = phi_v5 >= 0.7
    ? "sovereign"
    : phi_v5 >= 0.4
      ? "separated"
      : phi_v5 >= 0.15
        ? "partial"
        : "exposed";

  return {
    identityId: surface.identityId,
    phi_v5,
    agent,
    data,
    inference,
    reconstructionDifficulty,
    weakestAxis,
    sovereigntyLevel,
    timestamp: Date.now(),
  };
}
