//! Integration tests for generated codecs.

use categorical_codec::{all_codecs, all_streaming_codecs, StreamingCodec};
use std::io::Cursor;

#[test]
fn test_all_codecs_not_empty() {
    let codecs = all_codecs();
    assert!(
        !codecs.is_empty(),
        "Expected at least one codec to be generated"
    );
}

#[test]
fn test_codec_has_unique_ids() {
    let codecs = all_codecs();
    let mut ids: Vec<_> = codecs.iter().map(|c| c.id()).collect();
    let original_len = ids.len();
    ids.sort();
    ids.dedup();
    assert_eq!(ids.len(), original_len, "Codec IDs should be unique");
}

#[test]
fn test_codec_roundtrip() {
    let codecs = all_codecs();
    // Test inputs that should roundtrip cleanly (no leading zeros, non-empty)
    let test_inputs: &[&[u8]] = &[
        &[1],
        &[255],
        &[1, 2, 3],
        &[0xDE, 0xAD, 0xBE, 0xEF],
        &[1, 0, 0, 1], // No leading zeros
    ];

    for codec in &codecs {
        // Skip Braille codecs - they have fixed precision and are tested separately
        if codec.id().contains("braille") {
            continue;
        }

        for &input in test_inputs {
            let encoded = codec.encode(input).unwrap();
            let decoded = codec.decode(&encoded).unwrap();
            assert_eq!(
                decoded,
                input,
                "Codec {} failed roundtrip for input {:?}",
                codec.name(),
                input
            );
        }
    }
}

#[test]
fn test_binary_codec_is_identity() {
    let codecs = all_codecs();
    // Find binary codec by radix == 2
    let binary = codecs
        .iter()
        .find(|c| c.scale_factor().radix == 2 && c.id().contains("binary"));

    if let Some(codec) = binary {
        let input = vec![1, 2, 3, 4, 5];
        let encoded = codec.encode(&input).unwrap();
        // Binary should be identity (input == output)
        assert_eq!(encoded, input, "Binary codec should be identity transform");
    }
}

#[test]
fn test_scale_factor_valid() {
    let codecs = all_codecs();

    for codec in &codecs {
        let sf = codec.scale_factor();
        assert!(sf.radix >= 2, "Radix should be at least 2");
        // If not arbitrary, should have a max precision
        if !sf.arbitrary {
            assert!(
                sf.max_precision_bits.is_some(),
                "Non-arbitrary precision should have a max"
            );
        }
    }
}

#[test]
fn test_decimal_codec_exists() {
    let codecs = all_codecs();
    // Find by ID containing "decimal"
    let decimal = codecs.iter().find(|c| c.id().contains("decimal"));
    assert!(decimal.is_some(), "Decimal codec should exist");

    if let Some(codec) = decimal {
        assert_eq!(codec.scale_factor().radix, 10);
    }
}

#[test]
fn test_hexadecimal_codec_exists() {
    let codecs = all_codecs();
    // Find by ID containing "hexadecimal"
    let hex = codecs.iter().find(|c| c.id().contains("hexadecimal"));
    assert!(hex.is_some(), "Hexadecimal codec should exist");

    if let Some(codec) = hex {
        assert_eq!(codec.scale_factor().radix, 16);
    }
}

#[test]
fn test_braille_codecs_exist() {
    let codecs = all_codecs();

    // All four Braille quantum codecs should exist
    let q0 = codecs.iter().find(|c| c.id().contains("braille/q0"));
    let q1 = codecs.iter().find(|c| c.id().contains("braille/q1"));
    let q2 = codecs.iter().find(|c| c.id().contains("braille/q2"));
    let q3 = codecs.iter().find(|c| c.id().contains("braille/q3"));

    assert!(q0.is_some(), "Braille Q0 codec should exist");
    assert!(q1.is_some(), "Braille Q1 codec should exist");
    assert!(q2.is_some(), "Braille Q2 codec should exist");
    assert!(q3.is_some(), "Braille Q3 codec should exist");
}

#[test]
fn test_braille_q0_roundtrip() {
    let codecs = all_codecs();
    let q0 = codecs
        .iter()
        .find(|c| c.id().contains("braille/q0"))
        .expect("Q0 codec should exist");

    // Q0: 1 byte precision
    assert_eq!(q0.scale_factor().max_precision_bits, Some(8));

    // Test all 256 values
    for byte_val in 0..=255u8 {
        let input = vec![byte_val];
        let encoded = q0.encode(&input).unwrap();
        let decoded = q0.decode(&encoded).unwrap();
        assert_eq!(decoded, input, "Q0 roundtrip failed for {}", byte_val);
    }
}

#[test]
fn test_braille_q1_roundtrip() {
    let codecs = all_codecs();
    let q1 = codecs
        .iter()
        .find(|c| c.id().contains("braille/q1"))
        .expect("Q1 codec should exist");

    // Q1: 16-bit precision
    assert_eq!(q1.scale_factor().max_precision_bits, Some(16));

    // Test sample 2-byte values
    for input in [[0u8, 0], [255, 255], [0xAB, 0xCD]] {
        let encoded = q1.encode(&input).unwrap();
        let decoded = q1.decode(&encoded).unwrap();
        assert_eq!(decoded, input, "Q1 roundtrip failed for {:?}", input);
    }
}

#[test]
fn test_braille_codec_produces_valid_utf8() {
    let codecs = all_codecs();
    let q0 = codecs
        .iter()
        .find(|c| c.id().contains("braille/q0"))
        .expect("Q0 codec should exist");

    // All Braille-encoded bytes should be valid UTF-8
    for byte_val in 0..=255u8 {
        let encoded = q0.encode(&[byte_val]).unwrap();
        let s = std::str::from_utf8(&encoded);
        assert!(s.is_ok(), "Invalid UTF-8 for byte {}", byte_val);

        // Should be a single Braille character
        let s = s.unwrap();
        assert_eq!(s.chars().count(), 1);
    }
}

// ============================================================================
// Streaming codec tests (TASK-228)
// ============================================================================

#[test]
fn test_all_streaming_codecs_not_empty() {
    let codecs = all_streaming_codecs();
    assert!(
        !codecs.is_empty(),
        "Expected at least one streaming codec to be generated"
    );
}

#[test]
fn test_streaming_codec_encoder_decoder() {
    let codecs = all_streaming_codecs();

    for codec in &codecs {
        // Create encoder and decoder
        let mut encoder = codec.encoder();
        let mut decoder = codec.decoder();

        // Test with simple input
        let input = vec![1u8, 2, 3, 4];

        // Encode
        let mut encoded = encoder.feed(&input).unwrap();
        encoded.extend(encoder.finish().unwrap());

        // Decode
        let mut decoded = decoder.feed(&encoded).unwrap();
        decoded.extend(decoder.finish().unwrap());

        // For non-Braille codecs, verify roundtrip
        // Braille codecs have fixed precision so may pad
        if !codec.id().contains("braille") {
            assert_eq!(
                decoded,
                input,
                "Streaming roundtrip failed for codec {}",
                codec.name()
            );
        }
    }
}

#[test]
fn test_braille_streaming_roundtrip() {
    let codecs = all_streaming_codecs();
    let braille_codecs: Vec<_> = codecs
        .iter()
        .filter(|c| c.id().contains("braille"))
        .collect();

    assert!(!braille_codecs.is_empty(), "Should have Braille codecs");

    // Test with all 256 byte values
    let input: Vec<u8> = (0..=255).collect();

    for codec in braille_codecs {
        let mut encoder = codec.encoder();
        let mut decoder = codec.decoder();

        // Encode all bytes
        let mut encoded = encoder.feed(&input).unwrap();
        encoded.extend(encoder.finish().unwrap());

        // Verify valid UTF-8
        assert!(
            std::str::from_utf8(&encoded).is_ok(),
            "Braille streaming should produce valid UTF-8"
        );

        // Decode back
        let mut decoded = decoder.feed(&encoded).unwrap();
        decoded.extend(decoder.finish().unwrap());

        // Braille Q0 streams byte-by-byte, should match exactly
        if codec.id().contains("q0") {
            assert_eq!(
                decoded, input,
                "Braille Q0 streaming roundtrip should preserve all bytes"
            );
        }
    }
}

#[test]
fn test_streaming_chunked_encode() {
    let codecs = all_streaming_codecs();
    let braille = codecs
        .iter()
        .find(|c| c.id().contains("braille/q0"))
        .expect("Braille Q0 should exist");

    // Encode in multiple small chunks
    let mut encoder = braille.encoder();

    let chunk1 = encoder.feed(&[0, 1, 2]).unwrap();
    let chunk2 = encoder.feed(&[3, 4, 5]).unwrap();
    let chunk3 = encoder.feed(&[6, 7, 8]).unwrap();
    let final_chunk = encoder.finish().unwrap();

    // Combine all chunks
    let encoded: Vec<u8> = [chunk1, chunk2, chunk3, final_chunk].concat();

    // Should have 9 Braille characters (27 UTF-8 bytes)
    assert_eq!(encoded.len(), 27, "9 glyphs × 3 bytes each");

    let s = std::str::from_utf8(&encoded).unwrap();
    assert_eq!(s.chars().count(), 9);
}

#[test]
fn test_streaming_chunked_decode() {
    let codecs = all_streaming_codecs();
    let braille = codecs
        .iter()
        .find(|c| c.id().contains("braille/q0"))
        .expect("Braille Q0 should exist");

    // First encode some data using streaming encoder (not batch)
    let input: Vec<u8> = vec![10, 20, 30, 40, 50];
    let mut encoder = braille.encoder();
    let mut encoded = encoder.feed(&input).unwrap();
    encoded.extend(encoder.finish().unwrap());

    // Decode in small chunks (may split UTF-8 sequences)
    let mut decoder = braille.decoder();
    let mut decoded = Vec::new();

    // Feed one byte at a time
    for byte in &encoded {
        let chunk = decoder.feed(&[*byte]).unwrap();
        decoded.extend(chunk);
    }
    decoded.extend(decoder.finish().unwrap());

    assert_eq!(
        decoded, input,
        "Chunked decode should produce original input"
    );
}

#[test]
fn test_encode_stream_to_vec() {
    use categorical_codec::CodecsBrailleQ0;

    let codec = CodecsBrailleQ0;
    let input = vec![0u8, 1, 17, 255];

    let mut input_cursor = Cursor::new(&input);
    let mut output = Vec::new();

    let bytes_written = codec.encode_stream(&mut input_cursor, &mut output).unwrap();

    assert_eq!(bytes_written, 12); // 4 glyphs × 3 bytes
    assert!(std::str::from_utf8(&output).is_ok());

    // Verify roundtrip via decode_stream
    let mut encoded_cursor = Cursor::new(&output);
    let mut decoded = Vec::new();
    codec
        .decode_stream(&mut encoded_cursor, &mut decoded)
        .unwrap();

    assert_eq!(decoded, input);
}

#[test]
fn test_decode_stream_from_vec() {
    use categorical_codec::CodecsBrailleQ0;

    let codec = CodecsBrailleQ0;

    // Create Braille-encoded data
    let braille_str = "⠀⠁⠑⣿"; // bytes 0, 1, 17, 255
    let encoded = braille_str.as_bytes();

    let mut input_cursor = Cursor::new(encoded);
    let mut decoded = Vec::new();

    let bytes_written = codec
        .decode_stream(&mut input_cursor, &mut decoded)
        .unwrap();

    assert_eq!(bytes_written, 4);
    assert_eq!(decoded, vec![0, 1, 17, 255]);
}
