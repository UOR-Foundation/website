//! Minimal memory-mapped input helper used by the backend executor.
//!
//! This mirrors the `hologram-core` mmap helper but lives locally to avoid
//! creating a dependency cycle once `hologram-core` depends on this crate.

use std::io;
use std::path::Path;

#[cfg(unix)]
use std::fs::File;

/// Read-only memory-mapped input.
///
/// On Unix platforms this uses `mmap` for zero-copy access; on other targets it
/// falls back to reading the file into memory.
#[derive(Debug)]
pub struct MappedInput {
    #[cfg(unix)]
    ptr: *const u8,
    #[cfg(unix)]
    len: usize,
    #[cfg(not(unix))]
    data: Vec<u8>,
}

impl MappedInput {
    /// Open and memory-map a file.
    #[cfg(unix)]
    pub fn open<P: AsRef<Path>>(path: P) -> io::Result<Self> {
        use std::os::unix::io::AsRawFd;

        let file = File::open(path)?;
        let metadata = file.metadata()?;
        let len = metadata.len() as usize;

        if len == 0 {
            return Ok(Self {
                ptr: std::ptr::null(),
                len: 0,
            });
        }

        // SAFETY: mmap is called with read-only flags and the file descriptor is valid.
        let ptr = unsafe {
            libc::mmap(
                std::ptr::null_mut(),
                len,
                libc::PROT_READ,
                libc::MAP_PRIVATE,
                file.as_raw_fd(),
                0,
            )
        };

        if ptr == libc::MAP_FAILED {
            return Err(io::Error::last_os_error());
        }

        Ok(Self {
            ptr: ptr as *const u8,
            len,
        })
    }

    /// Fallback loader for non-Unix targets.
    #[cfg(not(unix))]
    pub fn open<P: AsRef<Path>>(path: P) -> io::Result<Self> {
        let data = std::fs::read(path)?;
        Ok(Self { data })
    }

    /// Borrow the mapped data as a byte slice.
    #[must_use]
    pub fn as_slice(&self) -> &[u8] {
        #[cfg(unix)]
        {
            if self.ptr.is_null() {
                &[]
            } else {
                // SAFETY: The mapping is valid for `len` bytes until Drop unmaps it.
                unsafe { std::slice::from_raw_parts(self.ptr, self.len) }
            }
        }
        #[cfg(not(unix))]
        {
            &self.data
        }
    }

    /// Length of the mapped region in bytes.
    #[must_use]
    pub fn len(&self) -> usize {
        #[cfg(unix)]
        {
            self.len
        }
        #[cfg(not(unix))]
        {
            self.data.len()
        }
    }

    /// Returns true if the mapping is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Hint to the kernel that access will be random.
    #[cfg(unix)]
    pub fn advise_random(&self) {
        if !self.ptr.is_null() {
            unsafe {
                libc::madvise(self.ptr as *mut _, self.len, libc::MADV_RANDOM);
            }
        }
    }

    /// Hint to the kernel that access will be sequential.
    #[cfg(unix)]
    pub fn advise_sequential(&self) {
        if !self.ptr.is_null() {
            unsafe {
                libc::madvise(self.ptr as *mut _, self.len, libc::MADV_SEQUENTIAL);
            }
        }
    }

    /// Prefetch a bounded window to keep RSS low.
    #[cfg(unix)]
    pub fn prefetch_range(&self, offset: usize, len: usize) {
        if self.ptr.is_null() || len == 0 {
            return;
        }
        let start = offset.min(self.len);
        let clamped_len = len.min(self.len.saturating_sub(start));
        if clamped_len == 0 {
            return;
        }
        unsafe {
            libc::madvise(
                self.ptr.wrapping_add(start) as *mut _,
                clamped_len,
                libc::MADV_WILLNEED,
            );
        }
    }

    /// No-op hint on non-Unix targets.
    #[cfg(not(unix))]
    pub fn advise_random(&self) {}

    /// No-op hint on non-Unix targets.
    #[cfg(not(unix))]
    pub fn advise_sequential(&self) {}

    /// No-op hint on non-Unix targets.
    #[cfg(not(unix))]
    pub fn prefetch_range(&self, _offset: usize, _len: usize) {}
}

#[cfg(unix)]
impl Drop for MappedInput {
    fn drop(&mut self) {
        if !self.ptr.is_null() {
            unsafe {
                libc::munmap(self.ptr as *mut _, self.len);
            }
        }
    }
}

// SAFETY: Mapping is read-only and immutable for the lifetime of the object.
unsafe impl Send for MappedInput {}
unsafe impl Sync for MappedInput {}
