//! Model command: model operations (info, validate, benchmark).

use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use clap::{Args, Subcommand};
use hologram_backend::cpu::CpuBackend;
use hologram_backend::Backend;
use hologram_holo::types::BufferType;
use hologram_holo::{HolbHeader, HolmHeader, HOLB_MAGIC};

use crate::error::{CliError, CliResult};
use crate::reader::read_holb;

/// Arguments for the model command.
#[derive(Args, Debug)]
pub struct ModelArgs {
    #[command(subcommand)]
    pub command: ModelCommand,
}

/// Model subcommands.
#[derive(Subcommand, Debug)]
pub enum ModelCommand {
    /// Display model information
    Info {
        /// Input .holb file
        #[arg(value_name = "MODEL")]
        model: PathBuf,
    },

    /// Validate model structure and checksums
    Validate {
        /// Input .holb file
        #[arg(value_name = "MODEL")]
        model: PathBuf,

        /// Skip checksum verification
        #[arg(long)]
        skip_checksums: bool,
    },

    /// Run inference benchmark
    Benchmark {
        /// Input .holb file
        #[arg(value_name = "MODEL")]
        model: PathBuf,

        /// Number of warmup iterations
        #[arg(long, default_value = "10")]
        warmup: u32,

        /// Number of benchmark iterations
        #[arg(short, long, default_value = "100")]
        iterations: u32,

        /// Batch size for benchmarking
        #[arg(short, long, default_value = "1")]
        batch_size: u32,
    },
}

/// Execute the model command.
pub fn execute(args: ModelArgs, verbose: bool) -> CliResult<()> {
    match args.command {
        ModelCommand::Info { model } => info(&model, verbose),
        ModelCommand::Validate {
            model,
            skip_checksums,
        } => validate(&model, skip_checksums, verbose),
        ModelCommand::Benchmark {
            model,
            warmup,
            iterations,
            batch_size,
        } => benchmark(&model, warmup, iterations, batch_size, verbose),
    }
}

/// Display model information.
fn info(model: &Path, verbose: bool) -> CliResult<()> {
    if !model.exists() {
        return Err(CliError::FileNotFound(model.to_path_buf()));
    }

    if verbose {
        println!("Loading model info from {}", model.display());
    }

    let bytes = std::fs::read(model)?;

    if bytes.len() < 4 {
        return Err(CliError::InvalidInput("file too small".to_string()));
    }

    let magic = &bytes[0..4];

    println!("Model: {}", model.display());
    println!(
        "Size: {} bytes ({:.2} KB)",
        bytes.len(),
        bytes.len() as f64 / 1024.0
    );

    match magic {
        b"HOLB" => info_holb(&bytes, model)?,
        b"HOLM" => info_holm(&bytes)?,
        _ => {
            println!("Format: Unknown (magic: {:?})", magic);
        }
    }

    Ok(())
}

/// Display HOLB model information.
fn info_holb(bytes: &[u8], path: &Path) -> CliResult<()> {
    let header_size = std::mem::size_of::<HolbHeader>();
    if bytes.len() < header_size {
        return Err(CliError::InvalidInput(
            "file too small for HOLB header".to_string(),
        ));
    }

    #[allow(clippy::cast_ptr_alignment)]
    let header = unsafe { &*(bytes.as_ptr().cast::<HolbHeader>()) };

    println!("Format: HOLB (Unified Bundle)");
    println!("Version: {}", header.version);
    println!();

    // Structure information
    println!("Structure:");
    println!("  Graph offset: {} bytes", header.graph_offset);
    println!("  Graph size: {} bytes", header.graph_size);
    println!("  Weights offset: {} bytes", header.weights_offset);
    println!("  Weights size: {} bytes", header.weights_size);

    // Load and display plan details
    let plan = read_holb(path)?;

    println!();
    println!("Metadata:");
    println!("  Name: {}", plan.metadata.name);
    println!("  Version: {}", plan.metadata.version);
    if let Some(author) = &plan.metadata.author {
        println!("  Author: {author}");
    }
    if let Some(desc) = &plan.metadata.description {
        println!("  Description: {desc}");
    }

    println!();
    println!("Plan:");
    println!("  Instructions: {}", plan.instructions.len());
    println!("  Buffers: {}", plan.buffers.len());
    println!("  Constants: {} bytes", plan.constants.len());
    println!("  Workspace: {} bytes", plan.workspace_size);
    println!("  Dependencies: {}", plan.dependencies.len());

    // Buffer breakdown
    if !plan.buffers.is_empty() {
        println!();
        println!("Buffers:");
        for (i, buf) in plan.buffers.iter().enumerate() {
            println!(
                "  [{i}] {} bytes, align {}, {:?}",
                buf.size, buf.alignment, buf.buffer_type
            );
        }
    }

    // Instruction summary
    if !plan.instructions.is_empty() {
        println!();
        println!("Instruction Summary:");
        let mut counts: std::collections::HashMap<&str, usize> = std::collections::HashMap::new();
        for instr in &plan.instructions {
            let name = instr.name();
            *counts.entry(name).or_insert(0) += 1;
        }
        let mut sorted: Vec<_> = counts.into_iter().collect();
        sorted.sort_by(|a, b| b.1.cmp(&a.1));
        for (name, count) in sorted {
            println!("  {name}: {count}");
        }
    }

    Ok(())
}

/// Display HOLM pipeline information.
fn info_holm(bytes: &[u8]) -> CliResult<()> {
    let header_size = std::mem::size_of::<HolmHeader>();
    if bytes.len() < header_size {
        return Err(CliError::InvalidInput(
            "file too small for HOLM header".to_string(),
        ));
    }

    #[allow(clippy::cast_ptr_alignment)]
    let header = unsafe { &*(bytes.as_ptr().cast::<HolmHeader>()) };

    println!("Format: HOLM (Pipeline Bundle)");
    println!("Version: {}", header.version);
    println!("Models: {}", header.model_count);
    println!("Index offset: {} bytes", header.index_offset);

    // Parse model index
    let mut index_pos = header.index_offset as usize;
    println!();
    println!("Model Index:");

    for i in 0..header.model_count {
        if index_pos + 4 > bytes.len() {
            println!("  [{i}] [truncated]");
            break;
        }

        let name_len = u32::from_le_bytes([
            bytes[index_pos],
            bytes[index_pos + 1],
            bytes[index_pos + 2],
            bytes[index_pos + 3],
        ]) as usize;
        index_pos += 4;

        if index_pos + name_len > bytes.len() {
            println!("  [{i}] [truncated]");
            break;
        }

        let name = String::from_utf8_lossy(&bytes[index_pos..index_pos + name_len]).to_string();
        index_pos += name_len;

        if index_pos + 20 > bytes.len() {
            println!("  [{i}] {name} [truncated]");
            break;
        }

        let _offset = u64::from_le_bytes([
            bytes[index_pos],
            bytes[index_pos + 1],
            bytes[index_pos + 2],
            bytes[index_pos + 3],
            bytes[index_pos + 4],
            bytes[index_pos + 5],
            bytes[index_pos + 6],
            bytes[index_pos + 7],
        ]);
        index_pos += 8;

        let size = u64::from_le_bytes([
            bytes[index_pos],
            bytes[index_pos + 1],
            bytes[index_pos + 2],
            bytes[index_pos + 3],
            bytes[index_pos + 4],
            bytes[index_pos + 5],
            bytes[index_pos + 6],
            bytes[index_pos + 7],
        ]);
        index_pos += 8;

        let _checksum = u32::from_le_bytes([
            bytes[index_pos],
            bytes[index_pos + 1],
            bytes[index_pos + 2],
            bytes[index_pos + 3],
        ]);
        index_pos += 4;

        println!("  [{i}] {name} ({size} bytes)");
    }

    Ok(())
}

/// Validate model structure and checksums.
fn validate(model: &Path, skip_checksums: bool, verbose: bool) -> CliResult<()> {
    if !model.exists() {
        return Err(CliError::FileNotFound(model.to_path_buf()));
    }

    if verbose {
        println!("Validating {}", model.display());
        if skip_checksums {
            println!("  Skipping checksum verification");
        }
    }

    let bytes = std::fs::read(model)?;

    // Basic validation
    if bytes.is_empty() {
        return Err(CliError::InvalidInput("empty file".to_string()));
    }
    println!("✓ File readable ({} bytes)", bytes.len());

    if bytes.len() < 4 {
        return Err(CliError::InvalidInput(
            "file too small for header".to_string(),
        ));
    }

    let magic = &bytes[0..4];
    match magic {
        b"HOLB" => validate_holb(&bytes, model, skip_checksums)?,
        b"HOLM" => validate_holm(&bytes, skip_checksums)?,
        _ => {
            println!("⚠ Unknown format (magic: {:?})", magic);
        }
    }

    println!();
    println!("Validation complete.");
    Ok(())
}

/// Validate HOLB structure and checksums.
fn validate_holb(bytes: &[u8], path: &Path, skip_checksums: bool) -> CliResult<()> {
    let header_size = std::mem::size_of::<HolbHeader>();
    if bytes.len() < header_size {
        return Err(CliError::InvalidInput(
            "file too small for HOLB header".to_string(),
        ));
    }

    #[allow(clippy::cast_ptr_alignment)]
    let header = unsafe { &*(bytes.as_ptr().cast::<HolbHeader>()) };

    // Validate magic
    if !header.is_valid() {
        return Err(CliError::InvalidInput("invalid HOLB magic".to_string()));
    }
    println!("✓ Valid HOLB magic");

    // Validate version
    if header.version != 1 {
        println!("⚠ Unknown version: {}", header.version);
    } else {
        println!("✓ Version: {}", header.version);
    }

    // Validate graph bounds
    let graph_start = header.graph_offset as usize;
    let graph_end = graph_start
        .checked_add(header.graph_size as usize)
        .ok_or_else(|| CliError::InvalidInput("graph offset overflow".to_string()))?;

    if graph_end > bytes.len() {
        return Err(CliError::InvalidInput(format!(
            "graph extends beyond file: {graph_end} > {}",
            bytes.len()
        )));
    }
    println!("✓ Graph bounds valid ({} bytes)", header.graph_size);

    // Validate weights bounds
    if header.weights_size > 0 {
        let weights_start = header.weights_offset as usize;
        let weights_end = weights_start
            .checked_add(header.weights_size as usize)
            .ok_or_else(|| CliError::InvalidInput("weights offset overflow".to_string()))?;

        if weights_end > bytes.len() {
            return Err(CliError::InvalidInput(format!(
                "weights extend beyond file: {weights_end} > {}",
                bytes.len()
            )));
        }
        println!("✓ Weights bounds valid ({} bytes)", header.weights_size);
    }

    // Validate checksums
    if !skip_checksums {
        let graph_bytes = &bytes[graph_start..graph_end];
        let computed_graph_checksum = crc32fast::hash(graph_bytes);
        if computed_graph_checksum == header.graph_checksum {
            println!("✓ Graph checksum valid ({:#010x})", header.graph_checksum);
        } else {
            return Err(CliError::InvalidInput(format!(
                "graph checksum mismatch: expected {:#010x}, computed {:#010x}",
                header.graph_checksum, computed_graph_checksum
            )));
        }

        if header.weights_size > 0 {
            let weights_start = header.weights_offset as usize;
            let weights_end = weights_start + header.weights_size as usize;
            let weights_bytes = &bytes[weights_start..weights_end];
            let computed_weights_checksum = crc32fast::hash(weights_bytes);
            if computed_weights_checksum == header.weights_checksum {
                println!(
                    "✓ Weights checksum valid ({:#010x})",
                    header.weights_checksum
                );
            } else {
                return Err(CliError::InvalidInput(format!(
                    "weights checksum mismatch: expected {:#010x}, computed {:#010x}",
                    header.weights_checksum, computed_weights_checksum
                )));
            }
        }
    }

    // Try to deserialize the plan
    match read_holb(path) {
        Ok(plan) => {
            println!("✓ Plan deserializable");
            println!(
                "✓ Plan structure: {} instructions, {} buffers",
                plan.instructions.len(),
                plan.buffers.len()
            );
        }
        Err(e) => {
            return Err(CliError::InvalidInput(format!(
                "plan deserialization failed: {e}"
            )));
        }
    }

    Ok(())
}

/// Validate HOLM structure and checksums.
fn validate_holm(bytes: &[u8], skip_checksums: bool) -> CliResult<()> {
    let header_size = std::mem::size_of::<HolmHeader>();
    if bytes.len() < header_size {
        return Err(CliError::InvalidInput(
            "file too small for HOLM header".to_string(),
        ));
    }

    #[allow(clippy::cast_ptr_alignment)]
    let header = unsafe { &*(bytes.as_ptr().cast::<HolmHeader>()) };

    // Validate magic
    if !header.is_valid() {
        return Err(CliError::InvalidInput("invalid HOLM magic".to_string()));
    }
    println!("✓ Valid HOLM magic");

    // Validate version
    if header.version != 1 {
        println!("⚠ Unknown version: {}", header.version);
    } else {
        println!("✓ Version: {}", header.version);
    }

    println!("✓ Model count: {}", header.model_count);

    // Validate each model's checksum
    if !skip_checksums && header.model_count > 0 {
        let mut index_pos = header.index_offset as usize;

        for i in 0..header.model_count {
            if index_pos + 4 > bytes.len() {
                return Err(CliError::InvalidInput("truncated model index".to_string()));
            }

            let name_len = u32::from_le_bytes([
                bytes[index_pos],
                bytes[index_pos + 1],
                bytes[index_pos + 2],
                bytes[index_pos + 3],
            ]) as usize;
            index_pos += 4;

            if index_pos + name_len > bytes.len() {
                return Err(CliError::InvalidInput("truncated model name".to_string()));
            }

            let name = String::from_utf8_lossy(&bytes[index_pos..index_pos + name_len]).to_string();
            index_pos += name_len;

            if index_pos + 20 > bytes.len() {
                return Err(CliError::InvalidInput("truncated model entry".to_string()));
            }

            let offset = u64::from_le_bytes([
                bytes[index_pos],
                bytes[index_pos + 1],
                bytes[index_pos + 2],
                bytes[index_pos + 3],
                bytes[index_pos + 4],
                bytes[index_pos + 5],
                bytes[index_pos + 6],
                bytes[index_pos + 7],
            ]) as usize;
            index_pos += 8;

            let size = u64::from_le_bytes([
                bytes[index_pos],
                bytes[index_pos + 1],
                bytes[index_pos + 2],
                bytes[index_pos + 3],
                bytes[index_pos + 4],
                bytes[index_pos + 5],
                bytes[index_pos + 6],
                bytes[index_pos + 7],
            ]) as usize;
            index_pos += 8;

            let expected_checksum = u32::from_le_bytes([
                bytes[index_pos],
                bytes[index_pos + 1],
                bytes[index_pos + 2],
                bytes[index_pos + 3],
            ]);
            index_pos += 4;

            // Verify model data bounds
            if offset + size > bytes.len() {
                return Err(CliError::InvalidInput(format!(
                    "model {i} ({name}) extends beyond file"
                )));
            }

            // Verify checksum
            let model_data = &bytes[offset..offset + size];
            let computed_checksum = crc32fast::hash(model_data);
            if computed_checksum == expected_checksum {
                println!("✓ Model {i} ({name}) checksum valid");
            } else {
                return Err(CliError::InvalidInput(format!(
                    "model {i} ({name}) checksum mismatch: expected {:#010x}, computed {:#010x}",
                    expected_checksum, computed_checksum
                )));
            }
        }
    }

    Ok(())
}

/// Run inference benchmark.
fn benchmark(
    model: &Path,
    warmup: u32,
    iterations: u32,
    batch_size: u32,
    verbose: bool,
) -> CliResult<()> {
    if !model.exists() {
        return Err(CliError::FileNotFound(model.to_path_buf()));
    }

    // Verify it's a HOLB file
    let bytes = std::fs::read(model)?;
    if bytes.len() < 4 || &bytes[0..4] != HOLB_MAGIC {
        return Err(CliError::InvalidInput(
            "benchmark requires a .holb file".to_string(),
        ));
    }

    println!("Benchmarking {}", model.display());
    println!("  Warmup: {warmup} iterations");
    println!("  Iterations: {iterations}");
    println!("  Batch size: {batch_size}");
    println!();

    // Load the plan
    if verbose {
        println!("Loading model...");
    }
    let plan = read_holb(model)?;

    // Determine input/output sizes from buffers
    let input_size = plan
        .buffers
        .iter()
        .find(|b| matches!(b.buffer_type, BufferType::Input))
        .map(|b| b.size)
        .unwrap_or(1024);

    let output_size = plan
        .buffers
        .iter()
        .find(|b| matches!(b.buffer_type, BufferType::Output))
        .map(|b| b.size)
        .unwrap_or(1024);

    if verbose {
        println!("  Input size: {} bytes", input_size);
        println!("  Output size: {} bytes", output_size);
    }

    // Create backend and buffers
    let backend = CpuBackend::new();
    let input_data = vec![0u8; input_size * batch_size as usize];
    let mut output_data = vec![0u8; output_size * batch_size as usize];

    // Warmup
    if verbose {
        println!("Running warmup...");
    }
    for _ in 0..warmup {
        let inputs: &[&[u8]] = &[&input_data];
        let outputs: &mut [&mut [u8]] = &mut [&mut output_data];
        backend
            .execute_plan(&plan, inputs, outputs)
            .map_err(|e| CliError::ExecutionFailed(format!("warmup failed: {e}")))?;
    }

    // Benchmark
    if verbose {
        println!("Running benchmark...");
    }
    let mut times: Vec<Duration> = Vec::with_capacity(iterations as usize);

    for _ in 0..iterations {
        let inputs: &[&[u8]] = &[&input_data];
        let outputs: &mut [&mut [u8]] = &mut [&mut output_data];

        let start = Instant::now();
        backend
            .execute_plan(&plan, inputs, outputs)
            .map_err(|e| CliError::ExecutionFailed(format!("benchmark iteration failed: {e}")))?;
        times.push(start.elapsed());
    }

    // Calculate statistics
    times.sort();
    let total: Duration = times.iter().sum();
    let mean = total / iterations;
    let median = times[times.len() / 2];
    let min = times[0];
    let max = times[times.len() - 1];

    // Calculate std dev
    let mean_nanos = mean.as_nanos() as f64;
    let variance: f64 = times
        .iter()
        .map(|t| {
            let diff = t.as_nanos() as f64 - mean_nanos;
            diff * diff
        })
        .sum::<f64>()
        / iterations as f64;
    let std_dev = Duration::from_nanos(variance.sqrt() as u64);

    // Calculate throughput
    let throughput = if mean.as_secs_f64() > 0.0 {
        batch_size as f64 / mean.as_secs_f64()
    } else {
        0.0
    };

    // Print results
    println!();
    println!("Results ({iterations} iterations, batch size {batch_size}):");
    println!("  Mean:   {:>12.3?}", mean);
    println!("  Median: {:>12.3?}", median);
    println!("  Std:    {:>12.3?}", std_dev);
    println!("  Min:    {:>12.3?}", min);
    println!("  Max:    {:>12.3?}", max);
    println!("  Throughput: {throughput:.2} inferences/sec");

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_holo::{BackendPlan, PlanMetadata};
    use tempfile::tempdir;

    use crate::writer::write_holb;

    fn create_test_holb(dir: &Path, name: &str) -> PathBuf {
        use hologram_holo::types::{BufferMetadata, BufferType};

        let path = dir.join(format!("{name}.holb"));
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![
                BufferMetadata {
                    size: 16,
                    alignment: 4,
                    buffer_type: BufferType::Input,
                    fully_written: false,
                },
                BufferMetadata {
                    size: 16,
                    alignment: 4,
                    buffer_type: BufferType::Output,
                    fully_written: false,
                },
            ],
            constants: vec![1, 2, 3, 4],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata {
                name: name.to_string(),
                version: "1.0.0".to_string(),
                author: Some("Test Author".to_string()),
                description: Some("Test model".to_string()),
            },
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };
        write_holb(&plan, &path).unwrap();
        path
    }

    #[test]
    fn test_info_holb() {
        let dir = tempdir().unwrap();
        let path = create_test_holb(dir.path(), "test-model");

        let result = info(&path, false);
        assert!(result.is_ok(), "info failed: {result:?}");
    }

    #[test]
    fn test_validate_holb() {
        let dir = tempdir().unwrap();
        let path = create_test_holb(dir.path(), "validate-model");

        let result = validate(&path, false, false);
        assert!(result.is_ok(), "validate failed: {result:?}");
    }

    #[test]
    fn test_validate_skip_checksums() {
        let dir = tempdir().unwrap();
        let path = create_test_holb(dir.path(), "skip-checksum");

        let result = validate(&path, true, false);
        assert!(result.is_ok());
    }

    #[test]
    fn test_benchmark_simple() {
        let dir = tempdir().unwrap();
        let path = create_test_holb(dir.path(), "bench-model");

        // Run with minimal iterations
        let result = benchmark(&path, 1, 5, 1, false);
        assert!(result.is_ok(), "benchmark failed: {result:?}");
    }

    #[test]
    fn test_info_missing_file() {
        let result = info(Path::new("/nonexistent/model.holb"), false);
        assert!(result.is_err());
    }

    #[test]
    fn test_validate_empty_file() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("empty.holb");
        std::fs::write(&path, []).unwrap();

        let result = validate(&path, false, false);
        assert!(result.is_err());
    }
}
