//! CPU backend implementation.
//!
//! Executes ISA plans on CPU using SIMD instructions (AVX2, ARM NEON)
//! and Rayon for parallelization.
//!
//! # Architecture
//!
//! - [`BufferManager`]: Manages memory buffers for inputs, outputs, and workspace
//! - [`ExecutionContext`]: Provides instruction dispatch with O(1) buffer lookup
//! - Unified dispatch via `ExecuteOn` trait in `dispatch_unified.rs`
//! - SIMD functions: Vectorized implementations of core operations
//!
//! # Instrumentation
//!
//! When the `instrumentation` feature is enabled, execution timing is recorded:
//! - `execute_plan_setup`: Buffer allocation and input copying
//! - `execute_plan_dispatch`: Total instruction dispatch time
//! - `execute_plan_extract`: Output extraction time
//! - Per-operation timing available via `execute_*` metrics

// Import timing macro (compiles to no-op when instrumentation is disabled)
#[cfg(feature = "instrumentation")]
use hologram_telemetry::timed;

// No-op fallback when instrumentation is disabled
#[cfg(not(feature = "instrumentation"))]
macro_rules! timed {
    ($name:expr, $block:expr) => {
        $block
    };
}

mod buffer;
mod context;
mod dispatch;
mod dispatcher_impl;
pub mod lut_matmul;
mod simd;

#[cfg(any(feature = "accelerate", feature = "openblas"))]
pub mod blas;

pub use buffer::BufferManager;
pub use context::{ExecutionContext, LayerExecutor, LayerExecutorFn};
// dispatch_instruction is deprecated - use ExecuteOn::execute instead
pub use simd::{
    // Transformer operations (unary math)
    abs_scalar,
    abs_simd,
    // Arithmetic operations
    add_inplace_simd,
    add_parallel,
    add_scalar,
    add_simd,
    avg_pool2d,
    // Matrix and CNN operations
    batch_norm_inference,
    conv2d_nchw,
    // Transformer operations (binary math)
    elem_max_inplace_simd,
    elem_max_scalar,
    elem_max_simd,
    elem_min_inplace_simd,
    elem_min_scalar,
    elem_min_simd,
    exp_scalar,
    exp_simd,
    // Shape operations
    expand_parallel,
    expand_scalar,
    global_avg_pool,
    // Transformer operations (comparisons and conditional)
    greater_or_equal_parallel,
    greater_or_equal_scalar,
    greater_or_equal_simd,
    greater_scalar,
    greater_simd,
    // Layer normalization (transformer)
    layer_norm_simd,
    less_or_equal_parallel,
    less_or_equal_scalar,
    less_or_equal_simd,
    less_scalar,
    less_simd,
    log_scalar,
    log_simd,
    matmul_parallel,
    matmul_tiled,
    matmul_tiled_packed,
    max_pool2d,
    // Reduction operations
    max_scalar,
    max_simd,
    min_scalar,
    min_simd,
    mul_inplace_simd,
    mul_parallel,
    mul_scalar,
    mul_simd,
    pow_scalar,
    pow_simd,
    // Activation functions
    relu_parallel,
    relu_scalar,
    relu_simd,
    sigmoid_parallel,
    sigmoid_scalar,
    sigmoid_simd,
    // Softmax with axis support
    softmax_scalar,
    softmax_simd,
    sqrt_scalar,
    sqrt_simd,
    sub_parallel,
    sub_scalar,
    sub_simd,
    sum_scalar,
    sum_simd,
    tanh_parallel,
    tanh_scalar,
    tanh_simd,
    tile_parallel,
    tile_scalar,
    where_scalar,
    where_simd,
    // CNN configuration types
    BatchNormConfig,
    Conv2dConfig,
    LayerNormConfig,
    Pool2dConfig,
};

use hologram_holo::BackendPlan;

use super::dispatch_unified::ExecuteOn;
use crate::backends::Backend;
use crate::types::{BackendCapabilities, BackendType, Result};

/// CPU backend for ISA execution.
///
/// Uses SIMD and Rayon for efficient execution on multi-core CPUs.
pub struct CpuBackend {
    capabilities: BackendCapabilities,
}

impl CpuBackend {
    /// Create a new CPU backend with default capabilities.
    #[must_use]
    pub fn new() -> Self {
        Self {
            capabilities: BackendCapabilities {
                backend_type: BackendType::Cpu,
                vector_width: 8, // AVX2
                l1_cache_size: 32 * 1024,
                l2_cache_size: 256 * 1024,
                has_fma: cfg!(target_feature = "fma"),
                has_sha: cfg!(target_feature = "sha"),
                has_aes: cfg!(target_feature = "aes"),
            },
        }
    }
}

impl Default for CpuBackend {
    fn default() -> Self {
        Self::new()
    }
}

impl Backend for CpuBackend {
    fn backend_type(&self) -> BackendType {
        BackendType::Cpu
    }

    fn execute_plan(
        &self,
        plan: &BackendPlan,
        inputs: &[&[u8]],
        outputs: &mut [&mut [u8]],
    ) -> Result<()> {
        // Create unified buffer manager from plan metadata
        // The buffer manager allocates space for all buffers (inputs, outputs,
        // workspace) based on the plan's buffer metadata and copies input data.
        let mut buffers = timed!("execute_plan_setup", {
            BufferManager::new(&plan.buffers, inputs, &plan.constants)?
        });

        // Create execution context with O(1) node lookup capability
        let mut context = ExecutionContext::new(&mut buffers, &plan.node_buffer_map);

        // Execute instructions with LUT fusion optimization (TASK-286).
        // Consecutive LUT activations are detected and composed into a single
        // table lookup, collapsing N memory passes to 1.
        timed!("execute_plan_dispatch", {
            let instructions = &plan.instructions;
            let mut i = 0;
            while i < instructions.len() {
                // Try to detect a fusable LUT chain (2+ consecutive LUT ops)
                if let Some((chain, dst, src, count, consumed)) =
                    dispatch::scan_lut_chain(instructions, i)
                {
                    let table = context.lut_cache.get_or_compose(&chain);
                    // Safety: table reference is valid for the duration of exec call
                    // because the cache owns it. We clone the 256 bytes to avoid
                    // holding a borrow on context across the mutable exec call.
                    let table_copy = *table;
                    dispatch::exec_fused_lut_chain(&mut context, dst, src, count, &table_copy)?;
                    i += consumed;
                } else {
                    instructions[i].execute(&mut context)?;
                    i += 1;
                }
            }
        });

        // Extract output data from output buffers to caller's slices
        timed!("execute_plan_extract", {
            context.extract_outputs(outputs)?;
        });

        Ok(())
    }

    fn execute_plan_with_layers(
        &self,
        plan: &BackendPlan,
        inputs: &[&[u8]],
        outputs: &mut [&mut [u8]],
        layer_executor: crate::backends::LayerExecutorFn<'_>,
    ) -> Result<()> {
        // Create unified buffer manager from plan metadata
        let mut buffers = BufferManager::new(&plan.buffers, inputs, &plan.constants)?;

        // Create execution context WITH layer executor for CallLayer support
        let mut context = ExecutionContext::with_layer_executor(
            &mut buffers,
            &plan.node_buffer_map,
            layer_executor,
        );

        // Execute with LUT fusion optimization
        let instructions = &plan.instructions;
        let mut i = 0;
        while i < instructions.len() {
            if let Some((chain, dst, src, count, consumed)) =
                dispatch::scan_lut_chain(instructions, i)
            {
                let table = *context.lut_cache.get_or_compose(&chain);
                dispatch::exec_fused_lut_chain(&mut context, dst, src, count, &table)?;
                i += consumed;
            } else {
                instructions[i].execute(&mut context)?;
                i += 1;
            }
        }

        // Extract output data from output buffers to caller's slices
        context.extract_outputs(outputs)?;

        Ok(())
    }

    fn capabilities(&self) -> &BackendCapabilities {
        &self.capabilities
    }
}

// CPU backend execution methods will be implemented in a future task.
// This backend currently only supports empty plans (for interface testing).

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_holo::PlanMetadata;

    #[test]
    fn test_cpu_backend_creation() {
        let backend = CpuBackend::new();
        assert_eq!(backend.backend_type(), BackendType::Cpu);
        assert_eq!(backend.capabilities().backend_type, BackendType::Cpu);
    }

    #[test]
    fn test_cpu_backend_default() {
        let backend = CpuBackend::default();
        assert_eq!(backend.backend_type(), BackendType::Cpu);
    }

    #[test]
    fn test_execute_empty_plan() {
        let backend = CpuBackend::new();
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata {
                name: String::from("test"),
                version: String::from("0.1.0"),
                author: None,
                description: None,
            },
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        let inputs = &[];
        let outputs: &mut [&mut [u8]] = &mut [];
        assert!(backend.execute_plan(&plan, inputs, outputs).is_ok());
    }
}
