// swift-tools-version:5.5
import PackageDescription

let package = Package(
    name: "UORSwiftExample",
    platforms: [
        .macOS(.v11),
        .iOS(.v14)
    ],
    products: [
        .executable(name: "UORExample", targets: ["UORExample"])
    ],
    targets: [
        // C module target (wraps C FFI)
        .systemLibrary(
            name: "CUOR",
            path: "../../bindings/swift",
            pkgConfig: "uor"
        ),
        
        // Swift wrapper target
        .target(
            name: "UOR",
            dependencies: ["CUOR"],
            path: "../../bindings/swift",
            sources: ["UOR.swift"]
        ),
        
        // Example executable
        .executableTarget(
            name: "UORExample",
            dependencies: ["UOR"],
            path: ".",
            sources: ["Example.swift"],
            linkerSettings: [
                .unsafeFlags(["-L../../target/release"]),
                .linkedLibrary("uor_ffi")
            ]
        )
    ]
)
