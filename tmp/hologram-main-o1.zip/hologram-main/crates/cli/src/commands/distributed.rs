//! Distributed execution commands.
//!
//! Provides CLI commands for distributed execution:
//! - `worker start` - Start a worker node
//! - `run` - Submit a job to the cluster
//! - `status` - Check job/worker status

use std::path::PathBuf;
use std::time::Duration;

use clap::{Args, Subcommand};
use hologram_backend::BackendType;
use hologram_network::distributed::{
    ExecutionRequest, LocalPoolConfig, LocalWorkerPool, PartitionExecutorConfig, Scheduler,
    SchedulerConfig,
};
use hologram_telemetry::MetricsRegistry;

use crate::error::{CliError, CliResult};

/// Arguments for the distributed command.
#[derive(Args, Debug)]
pub struct DistributedArgs {
    #[command(subcommand)]
    pub command: DistributedCommand,
}

/// Distributed subcommands.
#[derive(Subcommand, Debug)]
pub enum DistributedCommand {
    /// Start a worker node
    Worker {
        #[command(subcommand)]
        action: WorkerAction,
    },

    /// Submit a job to the cluster for distributed execution
    Run {
        /// Layer reference to execute
        #[arg(value_name = "LAYER")]
        layer_ref: String,

        /// Input data file (JSON array of bytes)
        #[arg(short, long)]
        input: Option<PathBuf>,

        /// Output file for results
        #[arg(short, long)]
        output: Option<PathBuf>,

        /// Number of workers to use
        #[arg(short = 'w', long, default_value = "1")]
        workers: u32,

        /// Backend type (cpu, wasm)
        #[arg(short, long, default_value = "cpu")]
        backend: String,

        /// Priority (higher = more urgent)
        #[arg(short, long, default_value = "0")]
        priority: u32,
    },

    /// Check job or worker status
    Status {
        /// Show detailed information
        #[arg(short, long)]
        detailed: bool,

        /// Show metrics
        #[arg(short, long)]
        metrics: bool,

        /// Filter by worker ID
        #[arg(short, long)]
        worker: Option<u64>,
    },
}

/// Worker subcommands.
#[derive(Subcommand, Debug, Clone)]
pub enum WorkerAction {
    /// Start a worker node
    Start {
        /// Listen address
        #[arg(short, long, default_value = "0.0.0.0:8080")]
        listen: String,

        /// Backend type (cpu, wasm)
        #[arg(short, long, default_value = "cpu")]
        backend: String,

        /// Maximum concurrent partitions
        #[arg(short, long, default_value = "4")]
        max_partitions: u32,

        /// Memory limit in MB
        #[arg(short = 'm', long, default_value = "1024")]
        memory_limit: u64,

        /// Cache size limit in MB
        #[arg(short, long, default_value = "256")]
        cache_size: u64,

        /// Storage path for content
        #[arg(short, long)]
        storage: Option<PathBuf>,
    },

    /// Stop a running worker
    Stop {
        /// Worker ID or "all"
        #[arg(value_name = "ID")]
        worker_id: String,
    },

    /// List running workers
    List {
        /// Show detailed information
        #[arg(short, long)]
        detailed: bool,
    },
}

/// Execute the distributed command.
pub fn execute(args: DistributedArgs, verbose: bool) -> CliResult<()> {
    match args.command {
        DistributedCommand::Worker { action } => execute_worker(action, verbose),
        DistributedCommand::Run {
            layer_ref,
            input,
            output,
            workers,
            backend,
            priority,
        } => execute_run(
            &layer_ref,
            input.as_deref(),
            output.as_deref(),
            workers,
            &backend,
            priority,
            verbose,
        ),
        DistributedCommand::Status {
            detailed,
            metrics,
            worker,
        } => execute_status(detailed, metrics, worker, verbose),
    }
}

/// Execute worker subcommand.
fn execute_worker(action: WorkerAction, verbose: bool) -> CliResult<()> {
    match action {
        WorkerAction::Start {
            listen,
            backend,
            max_partitions,
            memory_limit,
            cache_size,
            storage,
        } => worker_start(
            &listen,
            &backend,
            max_partitions,
            memory_limit,
            cache_size,
            storage.as_deref(),
            verbose,
        ),
        WorkerAction::Stop { worker_id } => worker_stop(&worker_id, verbose),
        WorkerAction::List { detailed } => worker_list(detailed, verbose),
    }
}

/// Parse backend type from string.
fn parse_backend(backend: &str) -> CliResult<BackendType> {
    match backend.to_lowercase().as_str() {
        "cpu" => Ok(BackendType::Cpu),
        "wasm" => Ok(BackendType::Wasm),
        "cuda" => Ok(BackendType::Cuda),
        "metal" => Ok(BackendType::Metal),
        _ => Err(CliError::InvalidInput(format!(
            "Unknown backend: {backend}. Valid options: cpu, wasm, cuda, metal"
        ))),
    }
}

/// Start a worker node.
fn worker_start(
    listen: &str,
    backend: &str,
    max_partitions: u32,
    memory_limit: u64,
    cache_size: u64,
    storage: Option<&std::path::Path>,
    verbose: bool,
) -> CliResult<()> {
    let backend_type = parse_backend(backend)?;

    if verbose {
        println!("Starting worker node...");
        println!("  Listen address: {listen}");
        println!("  Backend: {backend_type:?}");
        println!("  Max partitions: {max_partitions}");
        println!("  Memory limit: {memory_limit} MB");
        println!("  Cache size: {cache_size} MB");
        if let Some(path) = storage {
            println!("  Storage path: {}", path.display());
        }
    }

    // Create runtime for async operations
    let runtime = tokio::runtime::Runtime::new()
        .map_err(|e| CliError::ExecutionFailed(format!("Failed to create runtime: {e}")))?;

    runtime.block_on(async {
        // Create worker pool configuration
        let pool_config = LocalPoolConfig::new().with_max_workers(max_partitions as usize);

        // Create partition executor configuration
        let _executor_config = PartitionExecutorConfig::new()
            .with_backend_type(backend_type.clone())
            .with_max_memory((memory_limit as usize).saturating_mul(1024 * 1024))
            .with_max_cached(cache_size as usize);

        // Create worker pool
        let pool = LocalWorkerPool::new(pool_config);

        // Add worker
        let worker_id = pool.add_worker(backend_type).await;

        println!("Worker started: {worker_id}");
        println!("Listening on: {listen}");
        println!("Press Ctrl+C to stop");

        // Record startup in metrics
        let metrics = MetricsRegistry::global();
        metrics.increment("worker_starts", 1);

        // Keep running until interrupted
        // In a real implementation, this would set up network listeners
        // For now, we simulate the worker being ready
        loop {
            tokio::time::sleep(Duration::from_secs(60)).await;

            // Report stats periodically
            let stats = pool.aggregate_stats().await;
            if verbose {
                println!(
                    "Stats: executions={}, success_rate={:.1}%",
                    stats.total_executions,
                    stats.success_rate() * 100.0
                );
            }
        }
    })
}

/// Stop a worker.
fn worker_stop(worker_id: &str, verbose: bool) -> CliResult<()> {
    if verbose {
        println!("Stopping worker: {worker_id}");
    }

    if worker_id == "all" {
        println!("Stopping all workers...");
        // In a real implementation, this would signal all workers to stop
        println!("All workers stopped");
    } else {
        let id: u64 = worker_id
            .parse()
            .map_err(|_| CliError::InvalidInput(format!("Invalid worker ID: {worker_id}")))?;
        println!("Stopping worker {id}...");
        // In a real implementation, this would signal the specific worker
        println!("Worker {id} stopped");
    }

    Ok(())
}

/// List running workers.
fn worker_list(detailed: bool, verbose: bool) -> CliResult<()> {
    if verbose {
        println!("Listing workers...");
    }

    // In a real implementation, this would query the scheduler or orchestrator
    // For now, show placeholder information
    println!("Workers:");
    println!("  (No workers currently running)");
    println!();
    println!("Use 'hologram distributed worker start' to start a worker");

    if detailed {
        println!();
        println!("Worker configuration:");
        println!("  Default backend: CPU");
        println!("  Default memory limit: 1024 MB");
        println!("  Default cache size: 256 MB");
    }

    Ok(())
}

/// Submit a distributed execution job.
fn execute_run(
    layer_ref: &str,
    input: Option<&std::path::Path>,
    output: Option<&std::path::Path>,
    workers: u32,
    backend: &str,
    priority: u32,
    verbose: bool,
) -> CliResult<()> {
    let backend_type = parse_backend(backend)?;

    if verbose {
        println!("Submitting distributed execution job...");
        println!("  Layer: {layer_ref}");
        println!("  Workers: {workers}");
        println!("  Backend: {backend_type:?}");
        println!("  Priority: {priority}");
    }

    // Read input data if provided
    let input_data = if let Some(path) = input {
        let content = std::fs::read_to_string(path)?;
        let data: Vec<u8> = serde_json::from_str(&content)
            .map_err(|e| CliError::InvalidInput(format!("Invalid input JSON: {e}")))?;
        data
    } else {
        Vec::new()
    };

    if verbose {
        println!("  Input size: {} bytes", input_data.len());
    }

    // Create runtime for async operations
    let runtime = tokio::runtime::Runtime::new()
        .map_err(|e| CliError::ExecutionFailed(format!("Failed to create runtime: {e}")))?;

    let result = runtime.block_on(async {
        // Create scheduler
        let scheduler_config = SchedulerConfig {
            max_concurrent: workers as usize,
            ..Default::default()
        };
        let scheduler = Scheduler::new(scheduler_config);

        // Register workers
        for _ in 0..workers {
            scheduler.register_worker(vec![layer_ref.to_string()]).await;
        }

        if verbose {
            println!("Registered {} workers", scheduler.worker_count().await);
        }

        // Create execution request
        let request = ExecutionRequest::new(layer_ref, input_data.clone()).with_priority(priority);

        // Submit and wait for result
        let request_id = scheduler
            .submit(request)
            .await
            .map_err(|e| CliError::ExecutionFailed(format!("Failed to submit job: {e}")))?;

        if verbose {
            println!("Submitted request: {request_id}");
        }

        // Record metrics
        let metrics = MetricsRegistry::global();
        metrics.increment("distributed_jobs_submitted", 1);

        // In a real implementation, we would wait for the job to complete
        // and retrieve the result from the scheduler
        // For now, return a placeholder result
        Ok::<Vec<u8>, CliError>(input_data)
    })?;

    // Write output if requested
    if let Some(path) = output {
        let json = serde_json::to_string_pretty(&result)
            .map_err(|e| CliError::ExecutionFailed(format!("Failed to serialize output: {e}")))?;
        std::fs::write(path, json)?;
        println!("Output written to: {}", path.display());
    } else {
        println!("Execution complete");
        println!("Output size: {} bytes", result.len());
    }

    Ok(())
}

/// Show status of jobs and workers.
fn execute_status(
    detailed: bool,
    show_metrics: bool,
    worker_filter: Option<u64>,
    verbose: bool,
) -> CliResult<()> {
    if verbose {
        println!("Querying cluster status...");
    }

    // Create runtime for async operations
    let runtime = tokio::runtime::Runtime::new()
        .map_err(|e| CliError::ExecutionFailed(format!("Failed to create runtime: {e}")))?;

    runtime.block_on(async {
        // In a real implementation, this would query the scheduler
        let scheduler = Scheduler::default();

        println!("Cluster Status");
        println!("==============");
        println!();

        // Worker status
        let worker_count = scheduler.worker_count().await;
        let available = scheduler.available_workers().await;
        let pending = scheduler.pending_count().await;

        println!("Workers:");
        println!("  Total: {worker_count}");
        println!("  Available: {}", available.len());
        println!();

        println!("Jobs:");
        println!("  Pending: {pending}");
        println!();

        if let Some(worker_id) = worker_filter {
            println!("Worker {worker_id} details:");
            println!("  (Worker not found or not running)");
        }

        if detailed {
            println!("Configuration:");
            println!("  Default max concurrent: 8");
            println!("  Heartbeat interval: 10s");
            println!("  Request timeout: 30s");
        }

        if show_metrics {
            println!();
            println!("Metrics:");

            let metrics = MetricsRegistry::global();

            // Show counters
            let counters = metrics.counters();
            if counters.is_empty() {
                println!("  (No metrics recorded yet)");
            } else {
                for (name, value) in counters {
                    println!("  {name}: {value}");
                }
            }

            // Show histograms
            let histograms = metrics.histograms();
            for (name, summary) in histograms {
                println!();
                println!("  {name}:");
                println!("    count: {}", summary.count);
                println!("    mean: {:.2}ms", summary.mean);
                println!("    p50: {:.2}ms", summary.p50);
                println!("    p95: {:.2}ms", summary.p95);
                println!("    p99: {:.2}ms", summary.p99);
            }
        }

        Ok(())
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_backend_cpu() {
        assert_eq!(parse_backend("cpu").unwrap(), BackendType::Cpu);
        assert_eq!(parse_backend("CPU").unwrap(), BackendType::Cpu);
    }

    #[test]
    fn test_parse_backend_wasm() {
        assert_eq!(parse_backend("wasm").unwrap(), BackendType::Wasm);
        assert_eq!(parse_backend("WASM").unwrap(), BackendType::Wasm);
    }

    #[test]
    fn test_parse_backend_cuda() {
        assert_eq!(parse_backend("cuda").unwrap(), BackendType::Cuda);
    }

    #[test]
    fn test_parse_backend_metal() {
        assert_eq!(parse_backend("metal").unwrap(), BackendType::Metal);
    }

    #[test]
    fn test_parse_backend_invalid() {
        assert!(parse_backend("invalid").is_err());
    }

    #[test]
    fn test_worker_stop_all() {
        assert!(worker_stop("all", false).is_ok());
    }

    #[test]
    fn test_worker_stop_id() {
        assert!(worker_stop("123", false).is_ok());
    }

    #[test]
    fn test_worker_stop_invalid_id() {
        assert!(worker_stop("not-a-number", false).is_err());
    }

    #[test]
    fn test_worker_list() {
        assert!(worker_list(false, false).is_ok());
        assert!(worker_list(true, true).is_ok());
    }

    #[test]
    fn test_execute_status() {
        assert!(execute_status(false, false, None, false).is_ok());
    }

    #[test]
    fn test_execute_status_detailed() {
        assert!(execute_status(true, false, None, false).is_ok());
    }

    #[test]
    fn test_execute_status_with_metrics() {
        assert!(execute_status(false, true, None, false).is_ok());
    }

    #[test]
    fn test_execute_status_with_worker_filter() {
        assert!(execute_status(false, false, Some(1), false).is_ok());
    }
}
