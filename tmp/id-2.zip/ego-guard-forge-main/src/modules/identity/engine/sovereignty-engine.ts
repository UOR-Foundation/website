/**
 * Sovereignty Surface Engine — Pure Functions
 * ═════════════════════════════════════════════
 *
 * Models the user's privacy configuration as a 96-edge boundary
 * on 6 sovereignty dimensions (2⁶ = 64 interior states).
 *
 * The holographic bound: 96 boundary edges encode 64 volume vertices.
 * Each edge represents one consent/permission decision.
 * Proofs attest to boundary conditions without revealing volume state.
 *
 * Dimensions:
 *   1. Identity  — anonymous ↔ named
 *   2. Data      — local-only ↔ shared
 *   3. Compute   — on-device ↔ delegated
 *   4. Social    — private ↔ networked
 *   5. Economic  — free ↔ transactional
 *   6. Governance — individual ↔ collective
 *
 * 96 edges = 6 dimension-pairs × 16 edges per pair.
 * Each dimension-pair has 4×4 = 16 transitions between their binary states.
 *
 * Pure data. No classes. No side effects.
 *
 * @module identity/engine/sovereignty
 */

import type {
  SovereigntyDimension,
  SovereigntyDimensionId,
  BoundaryEdge,
  EdgeState,
  SovereigntySurface,
  BoundaryCommitment,
  EdgeDiff,
} from "../types";

// ── Dimension Definitions ───────────────────────────────────────────────────

export const SOVEREIGNTY_DIMENSIONS: readonly SovereigntyDimension[] = [
  { id: "identity",   label: "Identity",   offLabel: "Anonymous",  onLabel: "Named",         index: 0 },
  { id: "data",       label: "Data",       offLabel: "Local-only", onLabel: "Shared",        index: 1 },
  { id: "compute",    label: "Compute",    offLabel: "On-device",  onLabel: "Delegated",     index: 2 },
  { id: "social",     label: "Social",     offLabel: "Private",    onLabel: "Networked",     index: 3 },
  { id: "economic",   label: "Economic",   offLabel: "Free",       onLabel: "Transactional", index: 4 },
  { id: "governance", label: "Governance", offLabel: "Individual", onLabel: "Collective",    index: 5 },
];

// ── Dimension-Pair Enumeration ──────────────────────────────────────────────

interface DimensionPair {
  readonly a: SovereigntyDimensionId;
  readonly b: SovereigntyDimensionId;
  readonly pairIndex: number;
}

/** All 15 unique pairs from 6 dimensions (C(6,2) = 15).
 *  We use the first 6 pairs (adjacent) for 96 edges: 6 × 16 = 96. */
function enumeratePairs(): readonly DimensionPair[] {
  const ids = SOVEREIGNTY_DIMENSIONS.map((d) => d.id);
  const pairs: DimensionPair[] = [];
  for (let i = 0; i < ids.length; i++) {
    // Pair each dimension with the next (wrapping), giving 6 pairs
    const j = (i + 1) % ids.length;
    pairs.push({ a: ids[i], b: ids[j], pairIndex: i });
  }
  return pairs;
}

const DIMENSION_PAIRS = enumeratePairs();

// ── Edge Generation ─────────────────────────────────────────────────────────

/**
 * Generate the canonical set of 96 boundary edges.
 * Each dimension-pair produces 16 edges (4 states of dim A × 4 states of dim B).
 * The 4 states per dimension: [off, transitioning-on, transitioning-off, on].
 */
function generateEdgeId(
  pairIndex: number,
  subIndex: number,
): string {
  return `edge-${pairIndex.toString().padStart(2, "0")}-${subIndex.toString().padStart(2, "0")}`;
}

function generateEdgeLabel(
  dimA: SovereigntyDimension,
  dimB: SovereigntyDimension,
  subIndex: number,
): string {
  const stateA = subIndex < 8 ? dimA.offLabel : dimA.onLabel;
  const stateB = subIndex % 2 === 0 ? dimB.offLabel : dimB.onLabel;
  return `${dimA.label}:${stateA} ↔ ${dimB.label}:${stateB}`;
}

function generateAllEdges(): readonly BoundaryEdge[] {
  const edges: BoundaryEdge[] = [];
  const dims = SOVEREIGNTY_DIMENSIONS;

  for (const pair of DIMENSION_PAIRS) {
    const dimA = dims.find((d) => d.id === pair.a)!;
    const dimB = dims.find((d) => d.id === pair.b)!;

    for (let sub = 0; sub < 16; sub++) {
      edges.push({
        id: generateEdgeId(pair.pairIndex, sub),
        dimensionA: pair.a,
        dimensionB: pair.b,
        label: generateEdgeLabel(dimA, dimB, sub),
        state: "shielded",
        index: pair.pairIndex * 16 + sub,
      });
    }
  }

  return edges;
}

/** The canonical 96-edge template (all shielded). */
const CANONICAL_EDGES = generateAllEdges();

// ── Surface Construction ────────────────────────────────────────────────────

/** Create a default sovereignty surface with all edges shielded (conservative). */
export function createDefaultSurface(
  identityId: string,
): SovereigntySurface {
  return {
    identityId,
    edges: CANONICAL_EDGES.map((e) => ({ ...e })),
    dimensions: SOVEREIGNTY_DIMENSIONS,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}

// ── Edge Mutations (immutable) ──────────────────────────────────────────────

/** Flip a single edge's state. Returns a new surface. */
export function flipEdge(
  surface: SovereigntySurface,
  edgeId: string,
  newState: EdgeState,
): SovereigntySurface {
  const edgeExists = surface.edges.some((e) => e.id === edgeId);
  if (!edgeExists) return surface;

  return {
    ...surface,
    edges: surface.edges.map((e) =>
      e.id === edgeId ? { ...e, state: newState } : e,
    ),
    updatedAt: Date.now(),
  };
}

/** Flip multiple edges at once. Returns a new surface. */
export function flipEdges(
  surface: SovereigntySurface,
  changes: ReadonlyArray<{ edgeId: string; newState: EdgeState }>,
): SovereigntySurface {
  const changeMap = new Map(changes.map((c) => [c.edgeId, c.newState]));

  return {
    ...surface,
    edges: surface.edges.map((e) =>
      changeMap.has(e.id) ? { ...e, state: changeMap.get(e.id)! } : e,
    ),
    updatedAt: Date.now(),
  };
}

// ── Surface Diffing ─────────────────────────────────────────────────────────

/** Compute the diff between two surfaces. */
export function diffSurfaces(
  before: SovereigntySurface,
  after: SovereigntySurface,
): readonly EdgeDiff[] {
  const diffs: EdgeDiff[] = [];

  for (let i = 0; i < before.edges.length; i++) {
    const b = before.edges[i];
    const a = after.edges[i];
    if (b && a && b.state !== a.state) {
      diffs.push({
        edgeId: b.id,
        label: b.label,
        before: b.state,
        after: a.state,
        timestamp: after.updatedAt,
      });
    }
  }

  return diffs;
}

// ── Boundary Commitment (SHA-256) ───────────────────────────────────────────

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/**
 * Create a SHA-256 boundary commitment from the current surface state.
 * The commitment is a deterministic hash of all 96 edge states.
 * Verifiers can check the commitment without seeing individual edges.
 */
export async function createBoundaryCommitment(
  surface: SovereigntySurface,
): Promise<BoundaryCommitment> {
  // Canonical serialization: sorted edge states as a deterministic string
  const canonical = surface.edges
    .map((e) => `${e.id}:${e.state}`)
    .join("|");

  const encoded = new TextEncoder().encode(canonical);
  const hashBuffer = await crypto.subtle.digest("SHA-256", encoded);
  const hashHex = bytesToHex(new Uint8Array(hashBuffer));

  // Count edge states
  const shielded = surface.edges.filter((e) => e.state === "shielded").length;
  const disclosed = surface.edges.filter((e) => e.state === "disclosed").length;
  const selective = surface.edges.filter((e) => e.state === "selective").length;

  return {
    identityId: surface.identityId,
    commitmentHash: hashHex,
    edgeCount: surface.edges.length,
    shieldedCount: shielded,
    disclosedCount: disclosed,
    selectiveCount: selective,
    timestamp: Date.now(),
  };
}

// ── Queries ─────────────────────────────────────────────────────────────────

/** Get all edges for a specific dimension. */
export function edgesByDimension(
  surface: SovereigntySurface,
  dimensionId: SovereigntyDimensionId,
): readonly BoundaryEdge[] {
  return surface.edges.filter(
    (e) => e.dimensionA === dimensionId || e.dimensionB === dimensionId,
  );
}

/** Get all edges in a specific state. */
export function edgesByState(
  surface: SovereigntySurface,
  state: EdgeState,
): readonly BoundaryEdge[] {
  return surface.edges.filter((e) => e.state === state);
}

/** Compute the disclosure ratio (0.0 = fully shielded, 1.0 = fully open). */
export function disclosureRatio(surface: SovereigntySurface): number {
  if (surface.edges.length === 0) return 0;
  const open = surface.edges.filter((e) => e.state !== "shielded").length;
  return open / surface.edges.length;
}

/** Compute per-dimension disclosure ratios. */
export function dimensionDisclosureRatios(
  surface: SovereigntySurface,
): Record<SovereigntyDimensionId, number> {
  const result = {} as Record<SovereigntyDimensionId, number>;

  for (const dim of SOVEREIGNTY_DIMENSIONS) {
    const dimEdges = edgesByDimension(surface, dim.id);
    if (dimEdges.length === 0) {
      result[dim.id] = 0;
      continue;
    }
    const open = dimEdges.filter((e) => e.state !== "shielded").length;
    result[dim.id] = open / dimEdges.length;
  }

  return result;
}

// ── Data Category Mapping ───────────────────────────────────────────────────

/**
 * Map existing DataCategory consent categories to sovereignty dimension clusters.
 * Each category maps to 3+ dimensions. With AND logic, only edges whose BOTH
 * endpoints fall within the set are affected.
 *
 * Adjacent dimension pairs (which produce the 96 edges):
 *   identity↔data, data↔compute, compute↔social,
 *   social↔economic, economic↔governance, governance↔identity
 *
 * Each category below covers 2–3 adjacent pairs → 32–48 edges.
 */
export const DATA_CATEGORY_EDGE_MAP: Record<string, readonly SovereigntyDimensionId[]> = {
  profile:   ["identity", "data", "governance"],                // identity↔data + governance↔identity = 32 edges
  activity:  ["data", "compute", "social"],                     // data↔compute + compute↔social = 32 edges
  content:   ["data", "compute", "governance", "identity"],     // identity↔data + data↔compute + governance↔identity = 48 edges
  social:    ["social", "economic", "compute"],                 // compute↔social + social↔economic = 32 edges
  financial: ["economic", "governance", "social"],              // social↔economic + economic↔governance = 32 edges
  biometric: ["identity", "data", "compute"],                   // identity↔data + data↔compute = 32 edges
  location:  ["data", "compute", "social", "economic"],         // data↔compute + compute↔social + social↔economic = 48 edges
};

/** Get edges affected by a data category consent change.
 *  Matches edges where BOTH dimensions belong to the category's dimension set (AND logic). */
export function edgesForDataCategory(
  surface: SovereigntySurface,
  category: string,
): readonly BoundaryEdge[] {
  const dims = DATA_CATEGORY_EDGE_MAP[category];
  if (!dims) return [];

  return surface.edges.filter(
    (e) => dims.includes(e.dimensionA) && dims.includes(e.dimensionB),
  );
}

/** Count how many edges a data category affects (for UI indicators). */
export function edgeCountForDataCategory(
  surface: SovereigntySurface,
  category: string,
): number {
  return edgesForDataCategory(surface, category).length;
}
