//! Metal texture support for activation table lookups.
//!
//! This module implements `TextureActivation` for the Metal backend,
//! providing GPU texture-based activation lookups using Metal's
//! texture hardware.
//!
//! # Performance
//!
//! Metal textures provide:
//! - Dedicated texture cache (separate from buffer L1/L2)
//! - Hardware-accelerated filtering
//! - Efficient broadcast to threads in a threadgroup
//!
//! # Usage
//!
//! ```ignore
//! use hologram_backend::backends::metal::MetalBackend;
//! use hologram_backend::core::gpu_textures::TextureActivation;
//! use hologram_backend::plan::activation_table_id;
//!
//! let mut backend = MetalBackend::new();
//! backend.preload_standard_textures();
//!
//! // Texture is now available for use in epilogue operations
//! let tex = backend.get_activation_texture(activation_table_id::SIGMOID);
//! ```

use crate::core::gpu_textures::{
    get_activation_table, TextureActivation, TextureCache, TextureDescriptor,
};
use metal::{Device, MTLPixelFormat, MTLTextureUsage, Texture};

/// Metal texture handle for activation lookups.
#[derive(Clone)]
pub struct MetalTextureHandle {
    /// The Metal texture object.
    pub texture: Texture,
    /// Table ID this texture represents.
    pub table_id: u32,
}

/// Metal activation texture manager.
///
/// Manages creation and caching of Metal textures for activation tables.
pub struct MetalActivationTextures {
    device: Device,
    cache: TextureCache<MetalTextureHandle>,
}

impl MetalActivationTextures {
    /// Create a new texture manager for the given device.
    pub fn new(device: Device) -> Self {
        Self {
            device,
            cache: TextureCache::new(),
        }
    }

    /// Create a Metal texture from an activation table.
    fn create_texture(&self, table_id: u32) -> Option<MetalTextureHandle> {
        let table_data = get_activation_table(table_id)?;

        let desc = TextureDescriptor::activation_table();

        // Create Metal texture descriptor
        let texture_desc = metal::TextureDescriptor::new();
        texture_desc.set_texture_type(metal::MTLTextureType::D1);
        texture_desc.set_width(desc.width as u64);
        texture_desc.set_pixel_format(MTLPixelFormat::R8Unorm);
        texture_desc.set_usage(MTLTextureUsage::ShaderRead);
        texture_desc.set_storage_mode(metal::MTLStorageMode::Shared);

        // Create the texture
        let texture = self.device.new_texture(&texture_desc);

        // Upload data to texture
        let region = metal::MTLRegion::new_1d(0, desc.width as u64);
        texture.replace_region(region, 0, table_data.as_ptr() as *const _, 256);

        Some(MetalTextureHandle { texture, table_id })
    }
}

impl TextureActivation for MetalActivationTextures {
    type TextureHandle = MetalTextureHandle;

    fn create_activation_texture(&mut self, table_id: u32) -> Option<Self::TextureHandle> {
        // Check cache first
        if let Some(handle) = self.cache.get(table_id) {
            return Some(handle.clone());
        }

        // Create new texture
        if let Some(handle) = self.create_texture(table_id) {
            self.cache.insert(table_id, handle.clone());
            Some(handle)
        } else {
            None
        }
    }

    fn get_activation_texture(&self, table_id: u32) -> Option<&Self::TextureHandle> {
        self.cache.get(table_id)
    }

    fn supports_texture_activations(&self) -> bool {
        true
    }
}

/// MSL shader snippet for texture-based activation lookup.
///
/// This can be included in Metal compute shaders to enable
/// texture-based activation in epilogue operations.
pub const ACTIVATION_TEXTURE_SHADER: &str = r#"
// Activation texture lookup function
// Usage: float result = activation_lookup(texture, input_value);
inline float activation_lookup(
    texture1d<float, access::sample> activation_table,
    float input
) {
    constexpr sampler activation_sampler(
        coord::normalized,
        filter::nearest,
        address::clamp_to_edge
    );

    // Input is assumed to be in [0, 1] range
    // Clamp to valid texture coordinates
    float coord = clamp(input, 0.0f, 1.0f);
    return activation_table.sample(activation_sampler, coord).r;
}

// Integer-indexed activation lookup
// For when input is already a u8 index [0, 255]
inline float activation_lookup_index(
    texture1d<float, access::read> activation_table,
    uint8_t index
) {
    return activation_table.read(uint(index)).r;
}
"#;

/// MSL shader snippet for epilogue with activation texture.
///
/// Applies activation from a texture to the output of a computation.
pub const EPILOGUE_ACTIVATION_SHADER: &str = r#"
// Apply activation to computation result
// Usage: output[idx] = epilogue_with_activation(result, activation_table);
inline float epilogue_with_activation(
    float value,
    texture1d<float, access::sample> activation_table
) {
    constexpr sampler s(coord::normalized, filter::nearest, address::clamp_to_edge);

    // Map value to [0, 1] range for texture lookup
    // Assumes input is roughly in [-8, 8] range
    float normalized = (value + 8.0f) / 16.0f;
    normalized = clamp(normalized, 0.0f, 1.0f);

    return activation_table.sample(s, normalized).r;
}
"#;

#[cfg(test)]
mod tests {
    use super::*;

    // Note: These tests require Metal hardware and will be skipped
    // on non-macOS systems or systems without Metal support.

    #[test]
    #[cfg(target_os = "macos")]
    fn test_texture_shader_compiles() {
        // Verify shader snippets are valid MSL syntax
        // (actual compilation tested in integration tests)
        assert!(!ACTIVATION_TEXTURE_SHADER.is_empty());
        assert!(!EPILOGUE_ACTIVATION_SHADER.is_empty());
    }
}
