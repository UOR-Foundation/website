//! SHA-256 hashing using hologram's UOR foundation.
//!
//! This crate provides SHA-256 hashing with hardware acceleration.
//! The compression function leverages hardware SHA-NI / SHA-2 instructions
//! on supported platforms, falling back to a portable scalar implementation.
//!
//! # Quick Start
//!
//! ```
//! use hologram_sha256::{sha256, Sha256};
//!
//! // One-shot hashing
//! let hash = sha256(b"hello world");
//! assert_eq!(hash.len(), 32);
//!
//! // Incremental hashing
//! let mut hasher = Sha256::new();
//! hasher.update(b"hello ");
//! hasher.update(b"world");
//! let hash = hasher.finalize();
//! ```

mod compress;
mod hasher;
pub mod mining;
pub mod simd;

pub use compress::{compress, compress_second_hash, H0, K};
pub use hasher::{Sha256, Sha256Digest};
pub use mining::MiningState;
pub use simd::{
    compress as compress_fast, compress_second_hash as compress_second_hash_fast,
    double_sha256_fast, has_sha_ni,
};

/// Compute SHA-256 hash of data in one shot.
///
/// # Example
///
/// ```
/// use hologram_sha256::sha256;
///
/// let hash = sha256(b"hello world");
/// assert_eq!(
///     hex::encode(&hash),
///     "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"
/// );
/// ```
#[inline]
pub fn sha256(data: &[u8]) -> Sha256Digest {
    Sha256::digest(data)
}

/// Compute double SHA-256: SHA256(SHA256(data)).
///
/// This is the hash function used in Bitcoin for block headers and transactions.
///
/// # Example
///
/// ```
/// use hologram_sha256::double_sha256;
///
/// let data = b"test";
/// let hash = double_sha256(data);
/// // Double SHA-256 of "test"
/// ```
#[inline]
pub fn double_sha256(data: &[u8]) -> Sha256Digest {
    let first = sha256(data);
    sha256(first.as_ref())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sha256_empty() {
        let hash = sha256(b"");
        assert_eq!(
            hex::encode(hash.0),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
    }

    #[test]
    fn test_sha256_hello_world() {
        let hash = sha256(b"hello world");
        assert_eq!(
            hex::encode(hash.0),
            "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"
        );
    }

    #[test]
    fn test_sha256_abc() {
        let hash = sha256(b"abc");
        assert_eq!(
            hex::encode(hash.0),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
    }

    #[test]
    fn test_double_sha256() {
        // Double SHA-256 of empty is a known value
        let hash = double_sha256(b"");
        // SHA256(SHA256("")) = SHA256(e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
        assert_eq!(
            hex::encode(hash.0),
            "5df6e0e2761359d30a8275058e299fcc0381534545f55cf43e41983f5d4c9456"
        );
    }

    #[test]
    fn test_matches_sha2_crate() {
        use sha2::Digest;

        let test_cases: &[&[u8]] = &[
            b"",
            b"a",
            b"abc",
            b"message digest",
            b"abcdefghijklmnopqrstuvwxyz",
            b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
            &[0u8; 80],     // Bitcoin header size
            &[0xFFu8; 64],  // Single block
            &[0xABu8; 128], // Two blocks
        ];

        for input in test_cases {
            let our_hash = sha256(input);
            let ref_hash = sha2::Sha256::digest(input);
            assert_eq!(
                our_hash.as_ref(),
                ref_hash.as_slice(),
                "Mismatch for input len {}",
                input.len()
            );
        }
    }
}
