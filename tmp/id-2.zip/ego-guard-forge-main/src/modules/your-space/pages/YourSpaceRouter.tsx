/**
 * YourSpaceRouter — Smart entry point for My Space.
 * Re-exports the identity router logic for the your-space module.
 */
export { default } from "@/modules/identity/pages/IdentityHome";
