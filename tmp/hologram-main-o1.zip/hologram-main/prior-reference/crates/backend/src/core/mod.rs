//! Core modules for the backend crate (non-backend-specific).

pub mod activation_dispatch;
#[cfg(feature = "alloc-tracking")]
pub mod alloc_tracker;
pub mod capabilities;
pub mod common_ops;
pub mod context;
pub mod gpu_textures;
pub mod markers;
pub mod parallel;
pub mod simd_activation;
/// Re-export of constant providers housed under `providers::const_provider`.
pub mod const_provider {
    pub use crate::providers::const_provider::*;
}
pub mod detect;
pub mod epilogue;
pub mod error;
pub mod executor;
pub mod handle;
pub mod inspector;
pub mod layout;
pub mod mapped_input;
pub mod plan;
pub mod provenance;
pub mod streaming_executor;
pub mod threading;
pub mod traits;
pub mod transform_cache;
pub mod view;
