//! ISA instruction set and backend plan definitions.
//!
//! This module defines the portable ISA (Instruction Set Architecture) that
//! backends execute. All types are serializable with rkyv for zero-copy
//! deserialization from memory-mapped `.holo` files.

use rkyv::{Archive, Deserialize, Serialize};

// Generated from descriptors/shells/isa.shell — see specs/research/shell-dsl-isa-codegen.md
include!(concat!(env!("OUT_DIR"), "/generated_instruction.rs"));
include!(concat!(env!("OUT_DIR"), "/generated_instruction_name.rs"));

/// Reference to another `.holo` layer (supports composition).
///
/// Layers can be embedded in the same archive or referenced externally.
#[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct LayerRef {
    /// Content hash (SHA-256) for integrity verification
    pub layer_id: [u8; 32],

    /// Optional name/alias for this layer
    pub name: Option<String>,

    /// Location of the layer data
    pub location: LayerLocation,
}

/// Location of a referenced layer.
#[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
#[allow(clippy::used_underscore_binding)]
pub enum LayerLocation {
    /// Embedded in this archive (zero-copy via offset)
    Embedded {
        /// Offset into archive data
        offset: usize,
        /// Size in bytes
        size: usize,
    },

    /// External file path (loaded separately)
    External(String),

    /// Registry reference (fetched from remote)
    Registry {
        /// Registry URL
        registry_url: String,
        /// Version string
        version: String,
    },
}

/// A complete ISA program (optimized, frozen execution plan).
///
/// This is the output of the compilation pipeline and the input to backend
/// execution. All fields are serializable with rkyv for zero-copy access.
#[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct BackendPlan {
    /// Ordered list of instructions to execute
    pub instructions: Vec<IsaInstruction>,

    /// Buffer metadata (sizes, alignments)
    pub buffers: Vec<super::types::BufferMetadata>,

    /// Embedded constant data (weights, lookup tables)
    ///
    /// Zero-copy: when memory-mapped, this is a direct view into the file.
    pub constants: Vec<u8>,

    /// Pre-computed workspace size (bytes)
    ///
    /// The backend allocates this much workspace before execution.
    pub workspace_size: usize,

    /// Layer dependencies (other `.holo` files referenced)
    pub dependencies: Vec<LayerRef>,

    /// Plan metadata (name, version, author, etc.)
    pub metadata: PlanMetadata,

    /// Node ID to buffer index mapping for O(1) lookup.
    ///
    /// `node_buffer_map[node_id]` = `Some(buffer_idx)` if node has output buffer.
    /// Computed at compile time, enables `ExecutionContext` to look up node outputs
    /// without knowing buffer layout details.
    pub node_buffer_map: Vec<Option<u32>>,

    /// Observable metadata for categorical operation verification.
    ///
    /// Contains annotations for fused categorical chains (`RingAdd`, `RingMul`,
    /// `Lift`, `OrbitClassify`) that enable runtime verification of O(1) LUT
    /// operations using monodromy signature equivalence.
    pub observable_metadata: super::types::ObservableMetadata,

    /// Embedded LUT section for O(1) categorical operations.
    ///
    /// When `embedded` is true, contains the full LUT data for ring operations,
    /// lift, and orbit classification. When false, backends use static tables
    /// from `uor::lut`.
    pub lut_section: super::types::LutSection,
}

/// Metadata for a backend plan.
#[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct PlanMetadata {
    /// Plan name
    pub name: String,

    /// Semantic version
    pub version: String,

    /// Optional author
    pub author: Option<String>,

    /// Optional description
    pub description: Option<String>,
}

impl Default for PlanMetadata {
    fn default() -> Self {
        Self {
            name: String::from("unnamed"),
            version: String::from("0.1.0"),
            author: None,
            description: None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_isa_instruction_size() {
        // Ensure instructions are reasonably sized (no accidental bloat)
        // Conv2d has 20 parameters, which increases the enum size to ~152 bytes
        let size = std::mem::size_of::<IsaInstruction>();
        assert!(
            size <= 160,
            "IsaInstruction is {size} bytes, should be <= 160"
        );
    }

    #[test]
    fn test_plan_metadata_default() {
        let meta = PlanMetadata::default();
        assert_eq!(meta.name, "unnamed");
        assert_eq!(meta.version, "0.1.0");
        assert!(meta.author.is_none());
    }

    #[test]
    fn test_layer_location_variants() {
        let embedded = LayerLocation::Embedded {
            offset: 1024,
            size: 4096,
        };
        let external = LayerLocation::External(String::from("model.holb"));
        let registry = LayerLocation::Registry {
            registry_url: String::from("https://registry.example.com"),
            version: String::from("1.0.0"),
        };

        // Ensure all variants compile
        let _ = [embedded, external, registry];
    }

    #[test]
    fn test_encode_instruction_fields() {
        let encode = IsaInstruction::Encode {
            dst: 1,
            src: 0,
            codec_id: 1, // decimal
            count: 256,
        };
        match encode {
            IsaInstruction::Encode {
                dst,
                src,
                codec_id,
                count,
            } => {
                assert_eq!(dst, 1);
                assert_eq!(src, 0);
                assert_eq!(codec_id, 1);
                assert_eq!(count, 256);
            }
            _ => panic!("Expected Encode variant"),
        }
    }

    #[test]
    fn test_decode_instruction_fields() {
        let decode = IsaInstruction::Decode {
            dst: 2,
            src: 1,
            codec_id: 2, // hexadecimal
            count: 128,
        };
        match decode {
            IsaInstruction::Decode {
                dst,
                src,
                codec_id,
                count,
            } => {
                assert_eq!(dst, 2);
                assert_eq!(src, 1);
                assert_eq!(codec_id, 2);
                assert_eq!(count, 128);
            }
            _ => panic!("Expected Decode variant"),
        }
    }

    #[test]
    fn test_codec_id_values() {
        // Document the codec ID mapping
        let codecs = [
            (0, "binary"),
            (1, "decimal"),
            (2, "hexadecimal"),
            (3, "mod96crt"),
            (4, "continuedFraction"),
        ];

        for (id, name) in codecs {
            let encode = IsaInstruction::Encode {
                dst: 0,
                src: 0,
                codec_id: id,
                count: 1,
            };
            match encode {
                IsaInstruction::Encode { codec_id, .. } => {
                    assert_eq!(codec_id, id, "Codec {name} should have ID {id}");
                }
                _ => panic!("Expected Encode variant"),
            }
        }
    }

    // ========================================================================
    // Tokenization Tests
    // ========================================================================

    #[test]
    #[allow(clippy::float_cmp)]
    fn test_viterbi_tokenize_instruction_fields() {
        let instr = IsaInstruction::ViterbiTokenize {
            dst: 0,
            dst_len: 1,
            src: 2,
            src_len: 100,
            vocab_data: 3,
            vocab_size: 32000,
            max_tokens: 512,
            normalize_flags: 0b1100_0110, // NFKC + space_to_underscore + prepend_underscore
            unk_token_id: 2,
            unk_score: -10.0,
        };

        match instr {
            IsaInstruction::ViterbiTokenize {
                dst,
                dst_len,
                src,
                src_len,
                vocab_data,
                vocab_size,
                max_tokens,
                normalize_flags,
                unk_token_id,
                unk_score,
            } => {
                assert_eq!(dst, 0);
                assert_eq!(dst_len, 1);
                assert_eq!(src, 2);
                assert_eq!(src_len, 100);
                assert_eq!(vocab_data, 3);
                assert_eq!(vocab_size, 32000);
                assert_eq!(max_tokens, 512);
                assert_eq!(normalize_flags, 0b1100_0110);
                assert_eq!(unk_token_id, 2);
                assert_eq!(unk_score, -10.0);
            }
            _ => panic!("Expected ViterbiTokenize variant"),
        }
    }

    #[test]
    #[allow(clippy::similar_names)]
    fn test_viterbi_tokenize_normalize_flags() {
        // Test individual normalization flag bits
        let flags_lowercase = 1 << 0;
        let flags_nfkc = 1 << 1;
        let flags_nfc = 1 << 2;
        let flags_replace_whitespace = 1 << 3;
        let flags_collapse_whitespace = 1 << 4;
        let flags_strip_accents = 1 << 5;
        let flags_space_to_underscore = 1 << 6;
        let flags_prepend_underscore = 1 << 7;

        // SentencePiece default: NFKC + space_to_underscore + prepend_underscore
        let sentencepiece_flags = flags_nfkc | flags_space_to_underscore | flags_prepend_underscore;
        assert_eq!(sentencepiece_flags, 0b1100_0010);

        // BERT default: lowercase + strip_accents
        let bert_flags = flags_lowercase | flags_strip_accents;
        assert_eq!(bert_flags, 0b0010_0001);

        // Full normalization
        let full_flags = flags_lowercase
            | flags_nfkc
            | flags_replace_whitespace
            | flags_collapse_whitespace
            | flags_space_to_underscore
            | flags_prepend_underscore;
        assert_eq!(full_flags, 0b1101_1011);

        // Verify each flag position
        assert_eq!(flags_lowercase, 1);
        assert_eq!(flags_nfkc, 2);
        assert_eq!(flags_nfc, 4);
        assert_eq!(flags_replace_whitespace, 8);
        assert_eq!(flags_collapse_whitespace, 16);
        assert_eq!(flags_strip_accents, 32);
        assert_eq!(flags_space_to_underscore, 64);
        assert_eq!(flags_prepend_underscore, 128);
    }

    #[test]
    fn test_viterbi_tokenize_default_config() {
        // T5-style tokenizer config
        let instr = IsaInstruction::ViterbiTokenize {
            dst: 0,
            dst_len: 1,
            src: 2,
            src_len: 256,
            vocab_data: 3,
            vocab_size: 32128, // T5 vocab size
            max_tokens: 512,
            normalize_flags: 0b1100_0010, // NFKC + space_to_underscore + prepend_underscore
            unk_token_id: 2,              // T5 UNK token
            unk_score: -100.0,            // High penalty for UNK
        };

        if let IsaInstruction::ViterbiTokenize {
            vocab_size,
            max_tokens,
            unk_token_id,
            ..
        } = instr
        {
            assert_eq!(vocab_size, 32128);
            assert_eq!(max_tokens, 512);
            assert_eq!(unk_token_id, 2);
        }
    }
}
