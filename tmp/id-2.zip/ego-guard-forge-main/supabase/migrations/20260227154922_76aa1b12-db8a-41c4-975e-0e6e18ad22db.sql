
-- Trust network nodes (entities in a user's trust graph)
CREATE TABLE public.trust_nodes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'person' CHECK (type IN ('self','person','agent','experience','object')),
  description TEXT,
  verified BOOLEAN NOT NULL DEFAULT false,
  trust_level NUMERIC(3,2) DEFAULT 0.5 CHECK (trust_level >= 0 AND trust_level <= 1),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Trust network edges (relationships between nodes)
CREATE TABLE public.trust_edges (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  source_node_id UUID NOT NULL REFERENCES public.trust_nodes(id) ON DELETE CASCADE,
  target_node_id UUID NOT NULL REFERENCES public.trust_nodes(id) ON DELETE CASCADE,
  type TEXT NOT NULL DEFAULT 'trusts' CHECK (type IN ('trusts','verified','interacted','witnessed','created')),
  strength NUMERIC(3,2) DEFAULT 0.5 CHECK (strength >= 0 AND strength <= 1),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Constellation bookmarks
CREATE TABLE public.trust_constellations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  node_id UUID NOT NULL REFERENCES public.trust_nodes(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, node_id)
);

-- Enable RLS
ALTER TABLE public.trust_nodes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trust_edges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trust_constellations ENABLE ROW LEVEL SECURITY;

-- RLS: trust_nodes
CREATE POLICY "Users can view their own nodes" ON public.trust_nodes FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own nodes" ON public.trust_nodes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own nodes" ON public.trust_nodes FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own nodes" ON public.trust_nodes FOR DELETE USING (auth.uid() = user_id);

-- RLS: trust_edges
CREATE POLICY "Users can view their own edges" ON public.trust_edges FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own edges" ON public.trust_edges FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete their own edges" ON public.trust_edges FOR DELETE USING (auth.uid() = user_id);

-- RLS: trust_constellations
CREATE POLICY "Users can view their own constellations" ON public.trust_constellations FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own constellations" ON public.trust_constellations FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete their own constellations" ON public.trust_constellations FOR DELETE USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX idx_trust_nodes_user ON public.trust_nodes(user_id);
CREATE INDEX idx_trust_edges_user ON public.trust_edges(user_id);
CREATE INDEX idx_trust_edges_source ON public.trust_edges(source_node_id);
CREATE INDEX idx_trust_edges_target ON public.trust_edges(target_node_id);
CREATE INDEX idx_trust_constellations_user ON public.trust_constellations(user_id);
