//! LUT Demo — demonstrates O(1) lookup table operations via the FFI crate.
//!
//! Run: `cargo run -p uor-ffi --example lut_demo`

use uor_ffi::{
    abs_lut, curvature_q0, curvature_q1, domain_q0, exp_lut, gelu_lut, log_lut, orbit_class_q0,
    rank_q0, relu_lut, sigmoid_lut, silu_lut, sqrt_lut, stratum_q0, stratum_q1, tanh_lut,
    torus_offset_q0, torus_page_q0, FfiDatum16, FfiDatum16Proof,
};

fn main() {
    println!("=== UOR LUT Demo ===\n");

    // Q0 observables for a sample byte
    let byte = 42u8;
    println!("Q0 observables for byte {}:", byte);
    println!("  stratum (popcount): {}", stratum_q0(byte));
    println!("  curvature:          {}", curvature_q0(byte));
    println!("  domain (mod 3):     {}", domain_q0(byte));
    println!("  rank (div 3):       {}", rank_q0(byte));
    println!("  orbit class:        {}", orbit_class_q0(byte));
    println!("  torus page:         {}", torus_page_q0(byte));
    println!("  torus offset:       {}", torus_offset_q0(byte));

    // Activation functions
    println!("\nActivation functions for byte {}:", byte);
    println!("  sigmoid: {}", sigmoid_lut(byte));
    println!("  tanh:    {}", tanh_lut(byte));
    println!("  relu:    {}", relu_lut(byte));
    println!("  exp:     {}", exp_lut(byte));
    println!("  log:     {}", log_lut(byte));
    println!("  sqrt:    {}", sqrt_lut(byte));
    println!("  abs:     {}", abs_lut(byte));
    println!("  gelu:    {}", gelu_lut(byte));
    println!("  silu:    {}", silu_lut(byte));

    // Q1 (16-bit) observables
    let value = 0x1234u16;
    println!("\nQ1 observables for 0x{:04X}:", value);
    println!("  stratum:   {}", stratum_q1(value));
    println!("  curvature: {}", curvature_q1(value));

    // Datum16
    let datum = FfiDatum16::new(value);
    println!("\nDatum16(0x{:04X}):", value);
    println!("  stratum:   {}", datum.stratum());
    println!("  curvature: {}", datum.curvature());
    println!("  high byte: 0x{:02X}", datum.high_byte());
    println!("  low byte:  0x{:02X}", datum.low_byte());
    println!("  glyph:     {}", datum.glyph());
    println!("  spectrum:  {:?}", datum.spectrum());

    // Datum16Proof
    let proof = FfiDatum16Proof::from_datum(value);
    println!("\nDatum16Proof(0x{:04X}):", value);
    println!("  valid: {}", proof.is_valid());
    println!("  stratum:   {}", proof.stratum());
    println!("  curvature: {}", proof.curvature());

    println!("\nAll lookups are O(1) — pure memory access, zero computation.");
}
