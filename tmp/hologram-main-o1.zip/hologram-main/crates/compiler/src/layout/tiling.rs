//! SIMD tile size computation.
//!
//! This module computes optimal tile sizes for SIMD micro-kernels based on
//! backend capabilities (vector width, cache sizes, FMA support).

use hologram_backend::BackendCapabilities;

/// Tile sizes for SIMD operations.
///
/// Tile sizes are chosen to maximize register utilization and cache efficiency:
/// - Micro-tile: fits in vector registers for the inner kernel
/// - Macro-tile: fits in L1/L2 cache for blocking
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TileSize {
    /// Micro-kernel tile dimensions (rows, cols).
    ///
    /// These determine how many vector registers are used per iteration
    /// of the innermost loop.
    pub micro: (usize, usize),

    /// Macro-tile dimensions (rows, cols).
    ///
    /// These determine the blocking factor for cache efficiency.
    /// One block should fit in L1 cache.
    pub macro_tile: (usize, usize),
}

impl Default for TileSize {
    fn default() -> Self {
        // AVX2 default: 6x16 micro-tile (uses 12 YMM registers for C accumulation)
        // With 8-wide SIMD, 16 columns = 2 vectors per row
        Self {
            micro: (6, 16),
            macro_tile: (72, 256),
        }
    }
}

/// Compute optimal tile sizes based on backend capabilities.
///
/// The tile sizes are chosen to:
/// 1. Maximize vector register utilization
/// 2. Fit working set in L1 cache
/// 3. Minimize memory bandwidth requirements
#[must_use]
pub fn compute_tile_sizes(caps: &BackendCapabilities) -> TileSize {
    let (mr, nr) = compute_micro_tile(caps.vector_width, caps.has_fma);
    let (mc, nc) = compute_macro_tile(caps.l1_cache_size, mr, nr);

    TileSize {
        micro: (mr, nr),
        macro_tile: (mc, nc),
    }
}

/// Compute micro-kernel tile dimensions.
///
/// The micro-tile is sized to fill available vector registers:
/// - For AVX2 (8-wide): 6x16 uses 12 YMM registers for accumulation
/// - For AVX-512 (16-wide): 6x32 uses 12 ZMM registers
/// - For NEON (4-wide): 4x8 uses 8 registers
fn compute_micro_tile(vector_width: usize, has_fma: bool) -> (usize, usize) {
    // Number of columns per micro-tile = 2 * vector_width
    // This allows unrolling 2 vector ops per row
    let nr = vector_width * 2;

    // Number of rows depends on available registers
    // With FMA, we need fewer registers for temporaries
    let mr = if has_fma {
        // FMA allows denser computation, can use 6 rows
        6
    } else {
        // Without FMA, need more registers for temporaries, use 4 rows
        4
    };

    (mr, nr)
}

/// Compute macro-tile dimensions for cache blocking.
///
/// The macro-tile should be sized so that:
/// - A panel of A fits in L2 cache
/// - A block of B fits in L1 cache
/// - The working set for C accumulation fits in registers
fn compute_macro_tile(l1_cache_size: usize, mr: usize, nr: usize) -> (usize, usize) {
    // Assume F32 (4 bytes per element)
    let element_size = 4;

    // Target: fit macro-panel of B in ~half of L1 cache
    // B panel size = depth * cols * element_size
    let l1_half = l1_cache_size / 2;

    // Choose depth to be a reasonable value (256 is typical)
    let depth = 256;

    // Cols should be a multiple of nr
    let max_nc = l1_half / (depth * element_size);
    let nc = (max_nc / nr) * nr;
    let nc = nc.max(nr); // At least one micro-tile

    // Rows should fit A panel in L2 (assume L2 = 256KB)
    // A panel size = rows * depth * element_size
    // For now, use a fixed multiplier of mr
    let mc = mr * 12; // 12 micro-tiles tall

    (mc, nc)
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_backend::BackendType;

    fn avx2_caps() -> BackendCapabilities {
        BackendCapabilities {
            backend_type: BackendType::Cpu,
            vector_width: 8,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: true,
            has_sha: false,
            has_aes: false,
        }
    }

    fn avx512_caps() -> BackendCapabilities {
        BackendCapabilities {
            backend_type: BackendType::Cpu,
            vector_width: 16,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: true,
            has_sha: false,
            has_aes: false,
        }
    }

    fn neon_caps() -> BackendCapabilities {
        BackendCapabilities {
            backend_type: BackendType::Cpu,
            vector_width: 4,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: true,
            has_sha: false,
            has_aes: false,
        }
    }

    fn scalar_caps() -> BackendCapabilities {
        BackendCapabilities {
            backend_type: BackendType::Wasm,
            vector_width: 1,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: false,
            has_sha: false,
            has_aes: false,
        }
    }

    #[test]
    fn test_tile_size_default() {
        let tile = TileSize::default();
        assert_eq!(tile.micro, (6, 16));
        assert_eq!(tile.macro_tile, (72, 256));
    }

    #[test]
    fn test_compute_tile_sizes_avx2() {
        let caps = avx2_caps();
        let tile = compute_tile_sizes(&caps);

        // AVX2: 8-wide, with FMA -> 6x16 micro-tile
        assert_eq!(tile.micro, (6, 16));

        // Macro tile should be reasonable
        assert!(tile.macro_tile.0 >= tile.micro.0);
        assert!(tile.macro_tile.1 >= tile.micro.1);
    }

    #[test]
    fn test_compute_tile_sizes_avx512() {
        let caps = avx512_caps();
        let tile = compute_tile_sizes(&caps);

        // AVX-512: 16-wide -> wider micro-tile
        assert_eq!(tile.micro.1, 32); // 16 * 2
        assert_eq!(tile.micro.0, 6); // FMA allows 6 rows
    }

    #[test]
    fn test_compute_tile_sizes_neon() {
        let caps = neon_caps();
        let tile = compute_tile_sizes(&caps);

        // NEON: 4-wide -> narrower micro-tile
        assert_eq!(tile.micro.1, 8); // 4 * 2
        assert_eq!(tile.micro.0, 6); // FMA allows 6 rows
    }

    #[test]
    fn test_compute_tile_sizes_no_fma() {
        let mut caps = avx2_caps();
        caps.has_fma = false;
        let tile = compute_tile_sizes(&caps);

        // Without FMA, fewer rows
        assert_eq!(tile.micro.0, 4);
        assert_eq!(tile.micro.1, 16); // Still 8 * 2
    }

    #[test]
    fn test_compute_tile_sizes_scalar() {
        let caps = scalar_caps();
        let tile = compute_tile_sizes(&caps);

        // Scalar: 1-wide, no FMA
        assert_eq!(tile.micro, (4, 2)); // 1 * 2 = 2 columns
    }

    #[test]
    fn test_micro_tile_register_usage() {
        // With AVX2 (6x16 micro-tile):
        // - 16 columns / 8-wide = 2 vectors per row
        // - 6 rows * 2 vectors = 12 YMM registers for C accumulation
        // This leaves 4 YMM registers for A and B loading
        let caps = avx2_caps();
        let tile = compute_tile_sizes(&caps);

        let vectors_per_row = tile.micro.1 / caps.vector_width;
        let total_accumulators = tile.micro.0 * vectors_per_row;

        assert_eq!(vectors_per_row, 2);
        assert_eq!(total_accumulators, 12);
        assert!(total_accumulators <= 16); // YMM0-YMM15
    }

    #[test]
    fn test_macro_tile_multiple_of_micro() {
        let caps = avx2_caps();
        let tile = compute_tile_sizes(&caps);

        // Macro tile should be a multiple of micro tile
        assert_eq!(tile.macro_tile.0 % tile.micro.0, 0);
        assert_eq!(tile.macro_tile.1 % tile.micro.1, 0);
    }

    #[test]
    fn test_macro_tile_fits_cache() {
        let caps = avx2_caps();
        let tile = compute_tile_sizes(&caps);

        // A panel of B (depth * cols) should fit in L1 cache
        let depth = 256; // Assumed depth
        let b_panel_size = depth * tile.macro_tile.1 * 4; // F32

        // Should fit in L1 cache (32KB)
        assert!(
            b_panel_size <= caps.l1_cache_size,
            "B panel {} bytes exceeds L1 cache {} bytes",
            b_panel_size,
            caps.l1_cache_size
        );
    }

    #[test]
    fn test_larger_cache_allows_larger_tiles() {
        let small_cache_caps = BackendCapabilities {
            l1_cache_size: 16 * 1024, // 16 KB
            ..avx2_caps()
        };
        let large_cache_caps = BackendCapabilities {
            l1_cache_size: 64 * 1024, // 64 KB
            ..avx2_caps()
        };

        let small_tile = compute_tile_sizes(&small_cache_caps);
        let large_tile = compute_tile_sizes(&large_cache_caps);

        // Larger cache should allow wider macro-tile
        assert!(large_tile.macro_tile.1 >= small_tile.macro_tile.1);
    }
}
