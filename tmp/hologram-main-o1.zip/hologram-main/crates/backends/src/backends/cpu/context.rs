//! Execution context for O(1) node output lookup.
//!
//! The `ExecutionContext` wraps `BufferManager` and provides an additional
//! layer for looking up node outputs by node ID. The node-to-buffer mapping
//! is computed at compile time and stored in the plan, enabling O(1) lookup
//! without hashing.
//!
//! # Layer Execution
//!
//! For plans with `CallLayer` instructions, the context can be extended with
//! a [`LayerExecutor`] that enables recursive execution of sub-layers.

use hologram_holo::{BackendPlan, LayerRef};

use super::buffer::BufferManager;
use crate::layer::{FileSystemLoader, LayerCache, LayerLoader};
use crate::types::{BackendError, Result};

/// Executor for sub-layer invocation during CallLayer execution.
///
/// This struct holds the dependencies and infrastructure needed to execute
/// sub-layers referenced by `CallLayer` instructions.
pub struct LayerExecutor<'a> {
    /// Plan dependencies (layer references by content hash)
    dependencies: &'a [LayerRef],
    /// Archive data for embedded layers
    archive_data: Option<&'a [u8]>,
    /// Layer loader for external and embedded layers
    loader: &'a FileSystemLoader,
    /// Cache for loaded layers
    cache: &'a mut LayerCache,
}

impl<'a> LayerExecutor<'a> {
    /// Create a new layer executor.
    pub fn new(
        dependencies: &'a [LayerRef],
        archive_data: Option<&'a [u8]>,
        loader: &'a FileSystemLoader,
        cache: &'a mut LayerCache,
    ) -> Self {
        Self {
            dependencies,
            archive_data,
            loader,
            cache,
        }
    }

    /// Find a layer reference by its ID (content hash truncated to u64).
    ///
    /// The `layer_id` in CallLayer instructions is the first 8 bytes of the
    /// SHA-256 content hash, interpreted as little-endian u64.
    #[must_use]
    pub fn find_layer(&self, layer_id: u64) -> Option<&LayerRef> {
        self.dependencies.iter().find(|dep| {
            // Compare first 8 bytes of hash as u64
            let hash_prefix = u64::from_le_bytes(dep.layer_id[..8].try_into().unwrap_or([0; 8]));
            hash_prefix == layer_id
        })
    }

    /// Load and execute a sub-layer.
    ///
    /// # Arguments
    ///
    /// * `layer_id` - The layer ID (hash prefix) to execute
    /// * `inputs` - Input data for the sub-layer
    /// * `outputs` - Output buffers to fill
    ///
    /// # Errors
    ///
    /// Returns error if layer not found, loading fails, or execution fails.
    pub fn execute_layer(
        &mut self,
        layer_id: u64,
        inputs: &[&[u8]],
        outputs: &mut [&mut [u8]],
    ) -> Result<()> {
        // Find the layer reference (clone to avoid borrow conflicts)
        let layer_ref = self
            .find_layer(layer_id)
            .ok_or_else(|| BackendError::LayerLoadError {
                layer_id: format!("{layer_id:016x}"),
                reason: "layer not found in dependencies".into(),
            })?
            .clone();

        // Load the sub-layer plan
        let plan = self
            .loader
            .load(&layer_ref, self.archive_data, self.cache)?;

        // Execute the sub-layer using a fresh buffer manager
        execute_plan_internal(&plan, inputs, outputs)
    }
}

/// Internal plan execution without layer support (avoids recursion issues).
fn execute_plan_internal(
    plan: &BackendPlan,
    inputs: &[&[u8]],
    outputs: &mut [&mut [u8]],
) -> Result<()> {
    use crate::backends::dispatch_unified::ExecuteOn;

    let mut buffers = BufferManager::new(&plan.buffers, inputs, &plan.constants)?;
    let mut context = ExecutionContext::new(&mut buffers, &plan.node_buffer_map);

    // Execute with LUT fusion optimization
    let instructions = &plan.instructions;
    let mut i = 0;
    while i < instructions.len() {
        if let Some((chain, dst, src, count, consumed)) =
            super::dispatch::scan_lut_chain(instructions, i)
        {
            let table = *context.lut_cache.get_or_compose(&chain);
            super::dispatch::exec_fused_lut_chain(&mut context, dst, src, count, &table)?;
            i += consumed;
        } else {
            instructions[i].execute(&mut context)?;
            i += 1;
        }
    }

    context.extract_outputs(outputs)
}

/// Type alias for layer execution callback.
///
/// Takes (layer_id, inputs, outputs) and executes the sub-layer.
pub type LayerExecutorFn<'a> = &'a mut dyn FnMut(u64, &[&[u8]], &mut [&mut [u8]]) -> Result<()>;

/// Execution context with O(1) node output lookup.
///
/// This context wraps a `BufferManager` and adds the ability to look up
/// buffer data by node ID rather than buffer index. The mapping from node ID
/// to buffer index is computed at compile time and stored in the plan.
///
/// # Performance
///
/// All lookups are O(1) array indexing:
/// - `get_output(node_id)` performs one array lookup to get buffer index,
///   then one array lookup to get buffer data
/// - Direct buffer access (`read_buffer`, `write_buffer`) is unchanged
///
/// # Layer Execution
///
/// For plans with `CallLayer` instructions, use `with_layer_executor` to
/// provide a callback that can execute sub-layers.
pub struct ExecutionContext<'a> {
    /// Underlying buffer manager for actual data storage
    buffers: &'a mut BufferManager,
    /// Node ID to buffer index mapping from the compiled plan
    node_to_buffer: &'a [Option<u32>],
    /// Optional layer executor for CallLayer support
    layer_executor: Option<LayerExecutorFn<'a>>,
    /// Pre-allocated scratch buffer for in-place operations.
    /// Eliminates per-operation `vec![0.0f32; count]` heap allocations
    /// when destination aliases a source buffer.
    scratch: Vec<u8>,
    /// Cache for fused LUT activation tables (TASK-286).
    /// Consecutive LUT activations are composed into a single table.
    pub(crate) lut_cache: super::dispatch::LutFusionCache,
}

impl<'a> ExecutionContext<'a> {
    /// Create a new execution context without layer execution support.
    ///
    /// Pre-allocates a scratch buffer sized to the largest buffer in the plan
    /// to eliminate per-operation heap allocations in dispatch functions.
    ///
    /// # Arguments
    ///
    /// * `buffers` - The buffer manager for data storage
    /// * `node_to_buffer` - Mapping from node ID to buffer index
    #[inline]
    pub fn new(buffers: &'a mut BufferManager, node_to_buffer: &'a [Option<u32>]) -> Self {
        Self {
            buffers,
            node_to_buffer,
            layer_executor: None,
            scratch: Vec::new(),
            lut_cache: super::dispatch::LutFusionCache::new(),
        }
    }

    /// Create a new execution context with layer execution support.
    ///
    /// # Arguments
    ///
    /// * `buffers` - The buffer manager for data storage
    /// * `node_to_buffer` - Mapping from node ID to buffer index
    /// * `layer_executor` - Callback for executing sub-layers
    #[inline]
    pub fn with_layer_executor(
        buffers: &'a mut BufferManager,
        node_to_buffer: &'a [Option<u32>],
        layer_executor: LayerExecutorFn<'a>,
    ) -> Self {
        Self {
            buffers,
            node_to_buffer,
            layer_executor: Some(layer_executor),
            scratch: Vec::new(),
            lut_cache: super::dispatch::LutFusionCache::new(),
        }
    }

    /// Execute a sub-layer via CallLayer instruction.
    ///
    /// # Errors
    ///
    /// Returns error if no layer executor is configured or execution fails.
    pub fn execute_sublayer(
        &mut self,
        layer_id: u64,
        inputs: &[&[u8]],
        outputs: &mut [&mut [u8]],
    ) -> Result<()> {
        let executor = self.layer_executor.as_mut().ok_or_else(|| {
            BackendError::UnsupportedInstruction(
                "CallLayer requires layer executor (use with_layer_executor)".into(),
            )
        })?;
        executor(layer_id, inputs, outputs)
    }

    /// O(1) lookup of node output by node ID.
    ///
    /// # Errors
    ///
    /// Returns error if node_id is out of bounds or has no associated buffer.
    #[inline]
    pub fn get_output(&self, node_id: u32) -> Result<&[u8]> {
        let idx = self.resolve(node_id)?;
        self.buffers.read(idx)
    }

    /// O(1) write to node output.
    ///
    /// # Errors
    ///
    /// Returns error if node_id is out of bounds or has no associated buffer.
    #[inline]
    pub fn set_output(&mut self, node_id: u32, data: &[u8]) -> Result<()> {
        let idx = self.resolve(node_id)?;
        self.buffers.write(idx, data)
    }

    /// Resolve node_id to buffer index.
    #[inline]
    fn resolve(&self, node_id: u32) -> Result<u32> {
        self.node_to_buffer
            .get(node_id as usize)
            .copied()
            .flatten()
            .ok_or(BackendError::InvalidBufferIndex {
                kind: "node",
                index: node_id,
                count: self.node_to_buffer.len(),
            })
    }

    // ========================================================================
    // Direct buffer access for backward compatibility
    // ========================================================================

    /// Read raw bytes from a buffer by buffer index.
    ///
    /// # Errors
    ///
    /// Returns error if index is out of bounds.
    #[inline]
    pub fn read_buffer(&self, idx: u32) -> Result<&[u8]> {
        self.buffers.read(idx)
    }

    /// Write raw bytes to a buffer by buffer index.
    ///
    /// # Errors
    ///
    /// Returns error if index is out of bounds.
    #[inline]
    pub fn write_buffer(&mut self, idx: u32, data: &[u8]) -> Result<()> {
        self.buffers.write(idx, data)
    }

    // ========================================================================
    // f32 helpers for typed access
    // ========================================================================

    /// Read f32 values from a buffer by buffer index.
    ///
    /// # Errors
    ///
    /// Returns error if buffer is too small or misaligned.
    #[inline]
    pub fn read_f32(&self, idx: u32, count: usize) -> Result<&[f32]> {
        self.buffers.read_f32_slice(idx, count)
    }

    /// Write f32 values to a buffer by buffer index.
    ///
    /// # Errors
    ///
    /// Returns error if buffer is too small or misaligned.
    #[inline]
    pub fn write_f32(&mut self, idx: u32, data: &[f32]) -> Result<()> {
        self.buffers.write_f32_slice(idx, data)
    }

    /// Get a mutable f32 slice for zero-copy writes.
    ///
    /// This allows SIMD functions to write directly into the buffer without
    /// intermediate allocations, which is critical for hot-path performance.
    ///
    /// # Errors
    ///
    /// Returns error if buffer is too small or misaligned.
    #[inline]
    pub fn write_f32_mut(&mut self, idx: u32, count: usize) -> Result<&mut [f32]> {
        self.buffers.get_f32_mut(idx, count)
    }

    // ========================================================================
    // Scratch buffer for in-place operations
    // ========================================================================

    /// Get the scratch buffer as a mutable f32 pointer and ensure capacity.
    ///
    /// Returns a raw pointer to the scratch buffer, grown and zeroed as needed.
    /// Callers construct `&mut [f32]` slices from this pointer after releasing
    /// the mutable borrow on `self`, enabling subsequent `write_f32` calls.
    ///
    /// # Safety
    ///
    /// The returned pointer is valid until the next call to `scratch_ptr` or
    /// any method that resizes the scratch buffer.
    #[inline]
    #[allow(clippy::cast_ptr_alignment)] // Alignment verified by debug_assert below
    pub fn scratch_ptr(&mut self, count: usize) -> *mut f32 {
        let byte_len = count * std::mem::size_of::<f32>();
        if self.scratch.len() < byte_len {
            self.scratch.resize(byte_len, 0);
        } else {
            self.scratch[..byte_len].fill(0);
        }
        let ptr = self.scratch.as_mut_ptr().cast::<f32>();
        debug_assert_eq!(
            ptr.align_offset(std::mem::align_of::<f32>()),
            0,
            "scratch buffer not f32-aligned"
        );
        ptr
    }

    // ========================================================================
    // Output extraction
    // ========================================================================

    /// Extract output buffer data into caller-provided output slices.
    ///
    /// # Errors
    ///
    /// Returns error if output count doesn't match or buffers are too small.
    pub fn extract_outputs(&self, outputs: &mut [&mut [u8]]) -> Result<()> {
        self.buffers.extract_outputs(outputs)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_holo::types::{BufferMetadata, BufferType};

    fn make_metadata(types: &[BufferType], sizes: &[usize]) -> Vec<BufferMetadata> {
        types
            .iter()
            .zip(sizes.iter())
            .map(|(&bt, &sz)| BufferMetadata::new(sz, bt))
            .collect()
    }

    #[test]
    fn test_get_output_valid() {
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Workspace, BufferType::Output],
            &[16, 16, 16],
        );
        let mut input_data = vec![1u8, 2, 3, 4, 5, 6, 7, 8];
        input_data.extend(vec![0u8; 8]); // Pad to 16 bytes to match metadata
        let inputs: &[&[u8]] = &[&input_data];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        // node 0 -> buffer 0, node 1 -> buffer 1, node 2 -> buffer 2
        let node_map: Vec<Option<u32>> = vec![Some(0), Some(1), Some(2)];

        let ctx = ExecutionContext::new(&mut manager, &node_map);

        // Get output for node 0 (input buffer)
        let output = ctx.get_output(0).unwrap();
        assert_eq!(&output[..8], &[1, 2, 3, 4, 5, 6, 7, 8]);
    }

    #[test]
    fn test_get_output_invalid_node() {
        let metadata = make_metadata(&[BufferType::Input], &[16]);
        let input_data = vec![0u8; 16];
        let inputs: &[&[u8]] = &[&input_data];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map: Vec<Option<u32>> = vec![Some(0)];

        let ctx = ExecutionContext::new(&mut manager, &node_map);

        // Node 5 doesn't exist
        let result = ctx.get_output(5);
        assert!(result.is_err());
    }

    #[test]
    fn test_get_output_unmapped_node() {
        let metadata = make_metadata(&[BufferType::Input], &[16]);
        let input_data = vec![0u8; 16];
        let inputs: &[&[u8]] = &[&input_data];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        // Node 1 exists but is not mapped to any buffer
        let node_map: Vec<Option<u32>> = vec![Some(0), None];

        let ctx = ExecutionContext::new(&mut manager, &node_map);

        // Node 1 is unmapped
        let result = ctx.get_output(1);
        assert!(result.is_err());
    }

    #[test]
    fn test_set_output_roundtrip() {
        let metadata = make_metadata(&[BufferType::Workspace], &[16]);

        let mut manager = BufferManager::new(&metadata, &[], &[]).unwrap();
        let node_map: Vec<Option<u32>> = vec![Some(0)];

        {
            let mut ctx = ExecutionContext::new(&mut manager, &node_map);

            // Write data to node 0
            ctx.set_output(0, &[10, 20, 30, 40]).unwrap();
        }

        {
            let ctx = ExecutionContext::new(&mut manager, &node_map);

            // Read it back
            let output = ctx.get_output(0).unwrap();
            assert_eq!(&output[..4], &[10, 20, 30, 40]);
        }
    }

    #[test]
    fn test_buffer_access_unchanged() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[16, 16]);
        let mut input_data = vec![1u8, 2, 3, 4];
        input_data.extend(vec![0u8; 12]); // Pad to 16 bytes to match metadata
        let inputs: &[&[u8]] = &[&input_data];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map: Vec<Option<u32>> = vec![Some(0), Some(1)];

        {
            let mut ctx = ExecutionContext::new(&mut manager, &node_map);

            // Direct buffer access should work
            let data = ctx.read_buffer(0).unwrap();
            assert_eq!(&data[..4], &[1, 2, 3, 4]);

            // Write to buffer 1
            ctx.write_buffer(1, &[5, 6, 7, 8]).unwrap();
        }

        {
            let ctx = ExecutionContext::new(&mut manager, &node_map);

            // Verify write
            let data = ctx.read_buffer(1).unwrap();
            assert_eq!(&data[..4], &[5, 6, 7, 8]);
        }
    }

    #[test]
    fn test_node_lookup_matches_buffer() {
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Workspace, BufferType::Output],
            &[16, 16, 16],
        );
        let input_data = vec![42u8; 16];
        let inputs: &[&[u8]] = &[&input_data];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        // node 5 -> buffer 0, node 10 -> buffer 1, node 15 -> buffer 2
        let mut node_map: Vec<Option<u32>> = vec![None; 16];
        node_map[5] = Some(0);
        node_map[10] = Some(1);
        node_map[15] = Some(2);

        let ctx = ExecutionContext::new(&mut manager, &node_map);

        // Access via node ID should return same data as direct buffer access
        let via_node = ctx.get_output(5).unwrap();
        let via_buffer = ctx.read_buffer(0).unwrap();
        assert_eq!(via_node, via_buffer);
    }

    #[test]
    fn test_f32_helpers() {
        let metadata = make_metadata(&[BufferType::Workspace], &[64]);

        let mut manager = BufferManager::new(&metadata, &[], &[]).unwrap();
        let node_map: Vec<Option<u32>> = vec![Some(0)];

        {
            let mut ctx = ExecutionContext::new(&mut manager, &node_map);

            // Write f32 values
            ctx.write_f32(0, &[1.0, 2.0, 3.0, 4.0]).unwrap();
        }

        {
            let ctx = ExecutionContext::new(&mut manager, &node_map);

            // Read them back
            let floats = ctx.read_f32(0, 4).unwrap();
            assert_eq!(floats, &[1.0, 2.0, 3.0, 4.0]);
        }
    }

    #[test]
    fn test_extract_outputs() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Output], &[16, 16]);
        let input_data = vec![0u8; 16];
        let inputs: &[&[u8]] = &[&input_data];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map: Vec<Option<u32>> = vec![Some(0), Some(1)];

        {
            let mut ctx = ExecutionContext::new(&mut manager, &node_map);

            // Write to output buffer
            ctx.write_buffer(1, &[1, 2, 3, 4]).unwrap();
        }

        {
            let ctx = ExecutionContext::new(&mut manager, &node_map);

            // Extract outputs
            let mut out_buf = vec![0u8; 16];
            let outputs: &mut [&mut [u8]] = &mut [&mut out_buf];
            ctx.extract_outputs(outputs).unwrap();

            assert_eq!(&out_buf[..4], &[1, 2, 3, 4]);
        }
    }
}
