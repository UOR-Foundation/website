//! Centralized `OpKind` properties.
//!
//! Adding a new `OpKind` variant only requires updating methods here,
//! rather than hunting down 7+ exhaustive match sites across the compiler.

use super::OpKind;

/// Operation category for kernel lookup.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum OpCategory {
    /// Binary element-wise (Add, Sub, Mul, Div)
    BinaryElementwise,
    /// Unary activation (Sigmoid, Tanh, Relu, etc.)
    UnaryActivation,
    /// Matrix multiplication
    MatMul,
    /// Batched matrix multiplication
    BatchMatMul,
    /// Reduction (Sum, Max, Min, Mean)
    Reduction,
    /// Softmax
    Softmax,
    /// Categorical (`Lift`, `OrbitClassify`)
    Categorical,
    /// Memory (`Load`, `Store`, `Copy`)
    Memory,
    /// Control flow (`CallLayer`)
    ControlFlow,
    /// I/O (Input, Output, Constant)
    Io,
}

impl OpKind {
    /// Pure operations can be CSE'd and constant-folded.
    ///
    /// Returns `false` for side-effecting operations (I/O, memory, control flow)
    /// and for `Constant` (unique data prevents deduplication).
    #[must_use]
    pub fn is_pure(&self) -> bool {
        !matches!(
            self,
            OpKind::Constant
                | OpKind::Load
                | OpKind::Store
                | OpKind::CallLayer { .. }
                | OpKind::Input
                | OpKind::Output
                | OpKind::ViterbiTokenize { .. }
        )
    }

    /// Kernel execution category.
    #[must_use]
    pub fn category(&self) -> OpCategory {
        match self {
            OpKind::Add
            | OpKind::Sub
            | OpKind::Mul
            | OpKind::Div
            | OpKind::Pow
            | OpKind::ElemMin
            | OpKind::ElemMax
            | OpKind::Greater
            | OpKind::GreaterOrEqual
            | OpKind::Less
            | OpKind::LessOrEqual
            | OpKind::Where
            | OpKind::AddSigmoid => OpCategory::BinaryElementwise,

            OpKind::Sigmoid
            | OpKind::Tanh
            | OpKind::Relu
            | OpKind::Gelu
            | OpKind::Silu
            | OpKind::Sqrt
            | OpKind::Log
            | OpKind::Exp
            | OpKind::Abs
            | OpKind::Conv2d { .. }
            | OpKind::BatchNormalization { .. }
            | OpKind::LayerNorm { .. } => OpCategory::UnaryActivation,

            OpKind::MatMul { .. } | OpKind::MatMulRelu { .. } => OpCategory::MatMul,
            OpKind::BatchMatMul { .. } => OpCategory::BatchMatMul,

            OpKind::Sum
            | OpKind::Max
            | OpKind::Min
            | OpKind::Mean
            | OpKind::MaxPool { .. }
            | OpKind::AvgPool { .. }
            | OpKind::GlobalAveragePool => OpCategory::Reduction,

            OpKind::Softmax { .. } => OpCategory::Softmax,

            OpKind::Lift
            | OpKind::OrbitClassify
            | OpKind::Encode { .. }
            | OpKind::Decode { .. }
            | OpKind::Sha256 { .. }
            | OpKind::DoubleSha256 { .. } => OpCategory::Categorical,

            OpKind::Load
            | OpKind::Store
            | OpKind::Copy
            | OpKind::Reshape { .. }
            | OpKind::Transpose { .. }
            | OpKind::Gather { .. }
            | OpKind::Concat { .. }
            | OpKind::Unsqueeze { .. }
            | OpKind::Squeeze { .. }
            | OpKind::Slice { .. }
            | OpKind::Split { .. }
            | OpKind::Pad { .. }
            | OpKind::Cast { .. }
            | OpKind::Tile { .. }
            | OpKind::Expand { .. }
            | OpKind::Flatten { .. }
            | OpKind::ViterbiTokenize { .. } => OpCategory::Memory,

            OpKind::CallLayer { .. } => OpCategory::ControlFlow,
            OpKind::Input | OpKind::Output | OpKind::Constant => OpCategory::Io,
        }
    }

    /// Element-wise activation functions (Sigmoid, Tanh, `ReLU`, `GELU`, `SiLU`).
    #[must_use]
    pub fn is_activation(&self) -> bool {
        matches!(
            self,
            OpKind::Sigmoid | OpKind::Tanh | OpKind::Relu | OpKind::Gelu | OpKind::Silu
        )
    }

    /// Element-wise operations suitable for SIMD batching.
    #[must_use]
    pub fn is_element_wise(&self) -> bool {
        matches!(
            self,
            OpKind::Add
                | OpKind::Sub
                | OpKind::Mul
                | OpKind::Div
                | OpKind::Sigmoid
                | OpKind::Tanh
                | OpKind::Relu
                | OpKind::Gelu
                | OpKind::Silu
                | OpKind::Copy
                | OpKind::Cast { .. }
        )
    }

    /// I/O nodes (Input, Output, Constant).
    #[must_use]
    pub fn is_io(&self) -> bool {
        matches!(self, OpKind::Input | OpKind::Output | OpKind::Constant)
    }

    /// Minimum number of input edges required.
    ///
    /// Returns 0 for source nodes (Input, Constant) and variable-arity nodes
    /// (`CallLayer`). `Concat` returns its `num_inputs` field.
    #[must_use]
    pub fn min_inputs(&self) -> usize {
        match self {
            // Sources and variable-arity
            OpKind::Input | OpKind::Constant | OpKind::CallLayer { .. } => 0,
            // Ternary
            OpKind::Where => 3,
            // Field-dependent
            OpKind::Concat { num_inputs, .. } => *num_inputs,
            // Binary / multi-input
            OpKind::Add
            | OpKind::Sub
            | OpKind::Mul
            | OpKind::Div
            | OpKind::Pow
            | OpKind::ElemMin
            | OpKind::ElemMax
            | OpKind::Greater
            | OpKind::Less
            | OpKind::LessOrEqual
            | OpKind::GreaterOrEqual
            | OpKind::MatMul { .. }
            | OpKind::MatMulRelu { .. }
            | OpKind::BatchMatMul { .. }
            | OpKind::Gather { .. }
            | OpKind::AddSigmoid
            | OpKind::ViterbiTokenize { .. } => 2,
            // Everything else is unary (1 input)
            _ => 1,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // ---- is_pure ----

    #[test]
    fn pure_ops() {
        assert!(OpKind::Add.is_pure());
        assert!(OpKind::Relu.is_pure());
        assert!(OpKind::MatMul { m: 1, k: 1, n: 1 }.is_pure());
        assert!(OpKind::Reshape { shape: vec![4] }.is_pure());
        assert!(OpKind::MatMulRelu { m: 1, k: 1, n: 1 }.is_pure());
        assert!(OpKind::AddSigmoid.is_pure());
    }

    #[test]
    fn impure_ops() {
        assert!(!OpKind::Constant.is_pure());
        assert!(!OpKind::Load.is_pure());
        assert!(!OpKind::Store.is_pure());
        assert!(!OpKind::Input.is_pure());
        assert!(!OpKind::Output.is_pure());
        assert!(!OpKind::CallLayer { layer_id: 0 }.is_pure());
    }

    // ---- category ----

    #[test]
    fn category_binary() {
        assert_eq!(OpKind::Add.category(), OpCategory::BinaryElementwise);
        assert_eq!(OpKind::AddSigmoid.category(), OpCategory::BinaryElementwise);
    }

    #[test]
    fn category_activation() {
        assert_eq!(OpKind::Sigmoid.category(), OpCategory::UnaryActivation);
        assert_eq!(OpKind::Sqrt.category(), OpCategory::UnaryActivation);
    }

    #[test]
    fn category_matmul() {
        assert_eq!(
            OpKind::MatMul { m: 1, k: 1, n: 1 }.category(),
            OpCategory::MatMul
        );
        assert_eq!(
            OpKind::MatMulRelu { m: 1, k: 1, n: 1 }.category(),
            OpCategory::MatMul
        );
    }

    #[test]
    fn category_io() {
        assert_eq!(OpKind::Input.category(), OpCategory::Io);
        assert_eq!(OpKind::Output.category(), OpCategory::Io);
        assert_eq!(OpKind::Constant.category(), OpCategory::Io);
    }

    #[test]
    fn category_reduction() {
        assert_eq!(OpKind::Sum.category(), OpCategory::Reduction);
        assert_eq!(OpKind::GlobalAveragePool.category(), OpCategory::Reduction);
    }

    #[test]
    fn category_categorical() {
        assert_eq!(OpKind::Lift.category(), OpCategory::Categorical);
        assert_eq!(
            OpKind::Sha256 { src_len: 80 }.category(),
            OpCategory::Categorical
        );
    }

    #[test]
    fn category_memory() {
        assert_eq!(OpKind::Load.category(), OpCategory::Memory);
        assert_eq!(
            OpKind::Reshape { shape: vec![4] }.category(),
            OpCategory::Memory
        );
    }

    // ---- is_activation ----

    #[test]
    fn activations() {
        assert!(OpKind::Sigmoid.is_activation());
        assert!(OpKind::Tanh.is_activation());
        assert!(OpKind::Relu.is_activation());
        assert!(OpKind::Gelu.is_activation());
        assert!(OpKind::Silu.is_activation());

        assert!(!OpKind::Add.is_activation());
        assert!(!OpKind::Softmax { axis: -1 }.is_activation());
    }

    // ---- is_element_wise ----

    #[test]
    fn element_wise() {
        assert!(OpKind::Add.is_element_wise());
        assert!(OpKind::Relu.is_element_wise());
        assert!(OpKind::Copy.is_element_wise());

        assert!(!OpKind::MatMul { m: 1, k: 1, n: 1 }.is_element_wise());
        assert!(!OpKind::Softmax { axis: -1 }.is_element_wise());
        assert!(!OpKind::Sum.is_element_wise());
    }

    // ---- is_io ----

    #[test]
    fn io_nodes() {
        assert!(OpKind::Input.is_io());
        assert!(OpKind::Output.is_io());
        assert!(OpKind::Constant.is_io());
        assert!(!OpKind::Add.is_io());
    }

    // ---- min_inputs ----

    #[test]
    fn min_inputs_sources() {
        assert_eq!(OpKind::Input.min_inputs(), 0);
        assert_eq!(OpKind::Constant.min_inputs(), 0);
    }

    #[test]
    fn min_inputs_unary() {
        assert_eq!(OpKind::Relu.min_inputs(), 1);
        assert_eq!(OpKind::Sigmoid.min_inputs(), 1);
        assert_eq!(OpKind::Output.min_inputs(), 1);
        assert_eq!(OpKind::Sum.min_inputs(), 1);
    }

    #[test]
    fn min_inputs_binary() {
        assert_eq!(OpKind::Add.min_inputs(), 2);
        assert_eq!(OpKind::MatMul { m: 1, k: 1, n: 1 }.min_inputs(), 2);
        assert_eq!(OpKind::AddSigmoid.min_inputs(), 2);
    }

    #[test]
    fn min_inputs_ternary() {
        assert_eq!(OpKind::Where.min_inputs(), 3);
    }

    #[test]
    fn min_inputs_concat() {
        assert_eq!(
            OpKind::Concat {
                axis: 0,
                num_inputs: 4
            }
            .min_inputs(),
            4
        );
    }

    #[test]
    fn min_inputs_variable() {
        assert_eq!(OpKind::CallLayer { layer_id: 0 }.min_inputs(), 0);
    }
}
