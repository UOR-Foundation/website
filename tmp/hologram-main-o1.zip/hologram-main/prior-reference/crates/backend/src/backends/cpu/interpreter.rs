//! ISA interpreter for CPU execution.
//!
//! This module provides the actual ISA instruction interpreter that
//! executes programs on the CPU.
//!
//! # Features
//!
//! - `blas`: Enable ndarray-based matrix operations (MatMul, Dot, etc.)
//!
//! Without `blas` feature, linear algebra operations return zero.

use crate::{BackendError, BufferHandle};
use hologram_isa::{Instruction, Program, Register, Type};
use hologram_lookup::orbit::{orbit_class, orbit_representative};
use hologram_lookup::PackedCell;
use rustc_hash::FxHashMap;

#[cfg(feature = "blas")]
use ndarray::{Array1, Array2};

/// Number of registers in the register file.
const NUM_REGISTERS: usize = 32;

/// Hash function for kernel IDs (must match isa_emitter::hash_subgraph_id).
const fn hash_kernel_id(id: &str) -> u32 {
    let bytes = id.as_bytes();
    let mut hash: u32 = 5381;
    let mut i = 0;
    while i < bytes.len() {
        hash = hash.wrapping_mul(33).wrapping_add(bytes[i] as u32);
        i += 1;
    }
    hash
}

/// Kernel ID constants for dispatch.
const KERNEL_GATHER: u32 = hash_kernel_id("gather");
const KERNEL_SLICE: u32 = hash_kernel_id("slice");
const KERNEL_CONCAT: u32 = hash_kernel_id("concat");
const KERNEL_SOFTMAX: u32 = hash_kernel_id("softmax");
const KERNEL_BATCHNORM: u32 = hash_kernel_id("batchnorm");
const KERNEL_LAYERNORM: u32 = hash_kernel_id("layernorm");
const KERNEL_SHAPE: u32 = hash_kernel_id("shape");
const KERNEL_RESHAPE_DYNAMIC: u32 = hash_kernel_id("reshape_dynamic");
const KERNEL_RANGE: u32 = hash_kernel_id("range");
const KERNEL_CONSTANT_OF_SHAPE: u32 = hash_kernel_id("constant_of_shape");
const KERNEL_EXPAND: u32 = hash_kernel_id("expand");
const KERNEL_SLICE_DYNAMIC: u32 = hash_kernel_id("slice_dynamic");
const KERNEL_TILE: u32 = hash_kernel_id("tile");
const KERNEL_SQUEEZE_DYNAMIC: u32 = hash_kernel_id("squeeze_dynamic");
const KERNEL_UNSQUEEZE_DYNAMIC: u32 = hash_kernel_id("unsqueeze_dynamic");
const KERNEL_TRILU: u32 = hash_kernel_id("trilu");

/// CPU execution state.
pub struct ExecutionState {
    /// Register file (64-bit values).
    registers: [u64; NUM_REGISTERS],
    /// Float register overlay (same storage, different interpretation).
    float_registers: [f64; NUM_REGISTERS],
    /// Program counter.
    pc: usize,
    /// Whether execution should continue.
    running: bool,
    /// Label to instruction index mapping.
    labels: FxHashMap<String, usize>,
}

impl Default for ExecutionState {
    fn default() -> Self {
        Self::new()
    }
}

impl ExecutionState {
    /// Create a new execution state.
    pub fn new() -> Self {
        Self {
            registers: [0; NUM_REGISTERS],
            float_registers: [0.0; NUM_REGISTERS],
            pc: 0,
            running: true,
            labels: FxHashMap::default(),
        }
    }

    /// Get integer register value.
    #[inline]
    pub fn get_reg(&self, reg: Register) -> u64 {
        self.registers[reg.index() as usize]
    }

    /// Set integer register value.
    #[inline]
    pub fn set_reg(&mut self, reg: Register, value: u64) {
        self.registers[reg.index() as usize] = value;
    }

    /// Get float register value.
    #[inline]
    pub fn get_float(&self, reg: Register) -> f64 {
        self.float_registers[reg.index() as usize]
    }

    /// Set float register value.
    #[inline]
    pub fn set_float(&mut self, reg: Register, value: f64) {
        self.float_registers[reg.index() as usize] = value;
    }

    /// Build label map from program.
    pub fn build_labels(&mut self, program: &Program) {
        self.labels.clear();
        for (idx, inst) in program.instructions().iter().enumerate() {
            if let Instruction::Label { name } = inst {
                self.labels.insert(name.clone(), idx);
            }
        }
    }

    /// Get label address.
    pub fn get_label(&self, name: &str) -> Option<usize> {
        self.labels.get(name).copied()
    }

    /// Reset state for new execution.
    pub fn reset(&mut self) {
        self.registers = [0; NUM_REGISTERS];
        self.float_registers = [0.0; NUM_REGISTERS];
        self.pc = 0;
        self.running = true;
    }
}

/// ISA Interpreter.
pub struct Interpreter {
    /// Execution state.
    state: ExecutionState,
}

impl Default for Interpreter {
    fn default() -> Self {
        Self::new()
    }
}

impl Interpreter {
    /// Create a new interpreter.
    pub fn new() -> Self {
        Self {
            state: ExecutionState::new(),
        }
    }

    /// Execute a program.
    pub fn execute(
        &mut self,
        program: &Program,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        self.execute_with_tables(
            program,
            buffers,
            None,
            &crate::plan::LookupTables::default(),
        )
    }

    /// Execute a program with shape registry and lookup tables for runtime shape extraction.
    ///
    /// The shape_registry maps buffer handle IDs to their runtime shapes.
    /// This is used by the Shape operation to extract tensor dimensions.
    pub fn execute_with_tables(
        &mut self,
        program: &Program,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
        shape_registry: Option<&FxHashMap<u64, Vec<usize>>>,
        tables: &crate::plan::LookupTables,
    ) -> Result<(), BackendError> {
        // Reset state
        self.state.reset();
        self.state.build_labels(program);

        let instructions = program.instructions();
        if instructions.is_empty() {
            return Ok(());
        }

        // Main execution loop
        while self.state.running && self.state.pc < instructions.len() {
            let inst = &instructions[self.state.pc];
            self.execute_instruction(inst, buffers, shape_registry, tables)?;
            self.state.pc += 1;
        }

        Ok(())
    }

    /// Execute a single instruction.
    fn execute_instruction(
        &mut self,
        inst: &Instruction,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
        shape_registry: Option<&FxHashMap<u64, Vec<usize>>>,
        tables: &crate::plan::LookupTables,
    ) -> Result<(), BackendError> {
        match inst {
            // Memory operations
            Instruction::MovImm { ty, dst, value } => {
                self.exec_mov_imm(*ty, *dst, *value);
            }
            Instruction::Mov { dst, src, .. } => {
                let val = self.state.get_reg(*src);
                self.state.set_reg(*dst, val);
            }
            Instruction::Ldg { ty, dst, src } => {
                self.exec_load(*ty, *dst, src, buffers)?;
            }
            Instruction::Stg { ty, dst, src } => {
                self.exec_store(*ty, dst, *src, buffers)?;
            }

            // Arithmetic
            Instruction::Add { ty, dst, lhs, rhs } => {
                self.exec_binary_op(
                    *ty,
                    *dst,
                    *lhs,
                    *rhs,
                    |a, b| a.wrapping_add(b),
                    |a, b| a + b,
                );
            }
            Instruction::Sub { ty, dst, lhs, rhs } => {
                self.exec_binary_op(
                    *ty,
                    *dst,
                    *lhs,
                    *rhs,
                    |a, b| a.wrapping_sub(b),
                    |a, b| a - b,
                );
            }
            Instruction::Mul { ty, dst, lhs, rhs } => {
                self.exec_binary_op(
                    *ty,
                    *dst,
                    *lhs,
                    *rhs,
                    |a, b| a.wrapping_mul(b),
                    |a, b| a * b,
                );
            }
            Instruction::Div { ty, dst, lhs, rhs } => {
                self.exec_binary_op(
                    *ty,
                    *dst,
                    *lhs,
                    *rhs,
                    |a, b| if b != 0 { a / b } else { 0 },
                    |a, b| if b != 0.0 { a / b } else { 0.0 },
                );
            }
            Instruction::Max { ty, dst, lhs, rhs } => {
                self.exec_binary_op(*ty, *dst, *lhs, *rhs, |a, b| a.max(b), |a, b| a.max(b));
            }
            Instruction::Min { ty, dst, lhs, rhs } => {
                self.exec_binary_op(*ty, *dst, *lhs, *rhs, |a, b| a.min(b), |a, b| a.min(b));
            }

            // Transcendental
            Instruction::Exp { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::exp);
            }
            Instruction::Log { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::ln);
            }
            Instruction::Sin { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::sin);
            }
            Instruction::Cos { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::cos);
            }
            Instruction::Tan { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::tan);
            }
            Instruction::Sqrt { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::sqrt);
            }
            Instruction::Asin { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::asin);
            }
            Instruction::Acos { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::acos);
            }
            Instruction::Atan { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::atan);
            }
            Instruction::Sinh { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::sinh);
            }
            Instruction::Cosh { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::cosh);
            }

            // Activation functions
            Instruction::Sigmoid { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, |x| 1.0 / (1.0 + (-x).exp()));
            }
            Instruction::Relu { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, |x| x.max(0.0));
            }
            Instruction::Tanh { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, f64::tanh);
            }
            Instruction::Gelu { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, |x| {
                    0.5 * x
                        * (1.0
                            + ((2.0_f64 / std::f64::consts::PI).sqrt()
                                * (x + 0.044715 * x.powi(3)))
                            .tanh())
                });
            }
            Instruction::Silu { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, |x| x / (1.0 + (-x).exp()));
            }
            Instruction::Mish { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, |x| x * (1.0 + x.exp()).ln().tanh());
            }
            Instruction::Softplus { ty, dst, src } => {
                self.exec_unary_float(*ty, *dst, *src, |x| (1.0 + x.exp()).ln());
            }
            Instruction::LeakyRelu {
                ty,
                dst,
                src,
                alpha,
            } => {
                let alpha_val = self.state.get_float(*alpha);
                self.exec_unary_float(*ty, *dst, *src, |x| if x > 0.0 { x } else { alpha_val * x });
            }

            // Comparisons
            Instruction::Less { ty, dst, lhs, rhs } => {
                self.exec_comparison(*ty, *dst, *lhs, *rhs, |a, b| a < b, |a, b| a < b);
            }
            Instruction::Equal { ty, dst, lhs, rhs } => {
                self.exec_comparison(
                    *ty,
                    *dst,
                    *lhs,
                    *rhs,
                    |a, b| a == b,
                    |a, b| (a - b).abs() < 1e-10,
                );
            }
            Instruction::Greater { ty, dst, lhs, rhs } => {
                self.exec_comparison(*ty, *dst, *lhs, *rhs, |a, b| a > b, |a, b| a > b);
            }

            // Bitwise operations
            Instruction::BitAnd { dst, lhs, rhs, .. } => {
                let result = self.state.get_reg(*lhs) & self.state.get_reg(*rhs);
                self.state.set_reg(*dst, result);
            }
            Instruction::BitOr { dst, lhs, rhs, .. } => {
                let result = self.state.get_reg(*lhs) | self.state.get_reg(*rhs);
                self.state.set_reg(*dst, result);
            }
            Instruction::BitXor { dst, lhs, rhs, .. } => {
                let result = self.state.get_reg(*lhs) ^ self.state.get_reg(*rhs);
                self.state.set_reg(*dst, result);
            }
            Instruction::BitNot { dst, src, .. } => {
                let result = !self.state.get_reg(*src);
                self.state.set_reg(*dst, result);
            }
            Instruction::Shl {
                dst, src, amount, ..
            } => {
                let shift = self.state.get_reg(*amount) & 63;
                let result = self.state.get_reg(*src) << shift;
                self.state.set_reg(*dst, result);
            }
            Instruction::Shr {
                dst, src, amount, ..
            } => {
                let shift = self.state.get_reg(*amount) & 63;
                let result = self.state.get_reg(*src) >> shift;
                self.state.set_reg(*dst, result);
            }

            // Control flow
            Instruction::Loop { counter, label } => {
                let count = self.state.get_reg(*counter);
                if count > 0 {
                    self.state.set_reg(*counter, count - 1);
                    if let Some(addr) = self.state.get_label(label) {
                        self.state.pc = addr.wrapping_sub(1); // -1 because we add 1 after
                    }
                }
            }
            Instruction::CondMov { dst, src, cond, .. } => {
                if self.state.get_reg(*cond) != 0 {
                    let val = self.state.get_reg(*src);
                    self.state.set_reg(*dst, val);
                }
            }
            Instruction::Select {
                dst,
                true_val,
                false_val,
                cond,
                ..
            } => {
                let val = if self.state.get_reg(*cond) != 0 {
                    self.state.get_reg(*true_val)
                } else {
                    self.state.get_reg(*false_val)
                };
                self.state.set_reg(*dst, val);
            }
            Instruction::Exit => {
                self.state.running = false;
            }
            Instruction::Label { .. } => {
                // No-op, labels are just markers
            }
            Instruction::Call { kernel_id, args } => {
                // Dispatch to kernel implementations
                match *kernel_id {
                    KERNEL_SOFTMAX => self.exec_softmax(args, buffers),
                    KERNEL_LAYERNORM => self.exec_layernorm(args, buffers),
                    KERNEL_BATCHNORM => self.exec_batchnorm(args, buffers),
                    KERNEL_GATHER => self.exec_gather(args, buffers),
                    KERNEL_SLICE => self.exec_slice(args, buffers),
                    KERNEL_CONCAT => self.exec_concat(args, buffers),
                    KERNEL_SHAPE => self.exec_shape(args, buffers, shape_registry),
                    KERNEL_RESHAPE_DYNAMIC => {
                        self.exec_reshape_dynamic(args, buffers, shape_registry)
                    }
                    KERNEL_RANGE => self.exec_range(args, buffers),
                    KERNEL_CONSTANT_OF_SHAPE => self.exec_constant_of_shape(args, buffers),
                    KERNEL_EXPAND => self.exec_expand(args, buffers, shape_registry),
                    KERNEL_SLICE_DYNAMIC => self.exec_slice_dynamic(args, buffers, shape_registry),
                    KERNEL_TILE => self.exec_tile(args, buffers, shape_registry),
                    KERNEL_SQUEEZE_DYNAMIC => {
                        self.exec_squeeze_dynamic(args, buffers, shape_registry)
                    }
                    KERNEL_UNSQUEEZE_DYNAMIC => {
                        self.exec_unsqueeze_dynamic(args, buffers, shape_registry)
                    }
                    KERNEL_TRILU => self.exec_trilu(args, buffers, shape_registry),
                    _ => {} // Unknown kernel, skip
                }
            }

            // Atlas-specific algebraic operations
            // These use lookup crate's pre-computed tables
            Instruction::CharProduct { dst, i, j } => {
                // Character table product: χ_i * χ_j in resonance ring ℤ₉₆
                // (a × b) mod 96 - the core algebraic operation for character theory
                let char_i = self.state.get_reg(*i) as u8;
                let char_j = self.state.get_reg(*j) as u8;
                // Product in resonance ring (mod 96, derived from T×B = 3×32 = 96)
                let product = ((char_i as u64) * (char_j as u64)) % 96;
                self.state.set_reg(*dst, product);
            }
            Instruction::CharProductImm { dst, i, j } => {
                // Character table product with immediate indices in resonance ring ℤ₉₆
                let product = ((*i as u64) * (*j as u64)) % 96;
                self.state.set_reg(*dst, product);
            }
            Instruction::OrbitClassify { dst, coord, .. } => {
                // Classify byte into orbit class (0-31) using pre-computed table
                // Orbits derive from categorical axioms: B = 2^5 = 32
                let byte = self.state.get_reg(*coord) as u8;
                let class = orbit_class(byte);
                self.state.set_reg(*dst, class as u64);
            }
            Instruction::OrbitRepresentative { dst, class_id, .. } => {
                // Get canonical representative for orbit class
                // Each orbit has a representative (smallest byte in that orbit)
                let class = self.state.get_reg(*class_id) as u8;
                let rep = orbit_representative(class);
                self.state.set_reg(*dst, rep as u64);
            }
            Instruction::MultInverse { dst, unit, .. } => {
                // Multiplicative inverse in unit group Z/256Z^*
                // Units are odd numbers; inverse via extended Euclidean algorithm
                let u = self.state.get_reg(*unit) as u8;
                let inv = mult_inverse_mod256(u);
                self.state.set_reg(*dst, inv as u64);
            }
            Instruction::Lift { dst, src } => {
                let val = self.state.get_reg(*src);
                self.state.set_reg(*dst, val % 96);
            }
            Instruction::BoundMap { dst, index, .. } => {
                let idx = self.state.get_reg(*index);
                self.state.set_reg(*dst, idx);
            }
            Instruction::TorusMap { dst, byte } => {
                // Use lookup crate for pre-computed torus mapping
                let b = self.state.get_reg(*byte) as u8;
                let cell = tables.packed_table.cells[b as usize].to_cell();
                // Encode as (page << 8) | byte_index
                let encoded = (cell.page.0 << 8) | cell.byte.0;
                self.state.set_reg(*dst, encoded);
            }
            Instruction::BoundaryDetect { dst, coord } => {
                let c = self.state.get_reg(*coord);
                // Boundary detection: on 16-byte page boundaries
                let is_boundary = (c.is_multiple_of(16) || c % 16 == 15) as u64;
                self.state.set_reg(*dst, is_boundary);
            }
            Instruction::PageIndex { dst, byte } => {
                // Use lookup crate for pre-computed page index
                let b = self.state.get_reg(*byte) as u8;
                let cell = tables.packed_table.cells[b as usize].to_cell();
                self.state.set_reg(*dst, cell.page.0);
            }
            Instruction::ByteIndex { dst, byte } => {
                // Use lookup crate for pre-computed byte index
                let b = self.state.get_reg(*byte) as u8;
                let cell = tables.packed_table.cells[b as usize].to_cell();
                self.state.set_reg(*dst, cell.byte.0);
            }
            Instruction::CellPack { dst, cell } => {
                // Pack cell into PackedCell (u16) format
                let val = self.state.get_reg(*cell);
                let packed = PackedCell::new(
                    (val >> 8) as u8,   // page
                    (val & 0xFF) as u8, // byte
                );
                self.state.set_reg(*dst, packed.raw() as u64);
            }
            Instruction::CellUnpack { dst, packed } => {
                // Unpack PackedCell (u16) to full cell representation
                let packed_val = self.state.get_reg(*packed) as u16;
                let packed_cell = PackedCell::from_raw(packed_val);
                let page = packed_cell.page();
                let byte_idx = packed_cell.byte();
                self.state
                    .set_reg(*dst, ((page as u64) << 8) | (byte_idx as u64));
            }

            // Linear algebra operations - implemented with ndarray when blas feature enabled
            #[cfg(feature = "blas")]
            Instruction::Dot { ty, dst, a, b, len } => {
                let result = self.exec_dot(*ty, *a, *b, *len as usize, buffers);
                self.state.set_float(*dst, result);
            }
            #[cfg(feature = "blas")]
            Instruction::MatMul {
                ty,
                dst,
                a,
                b,
                m,
                n,
                k,
            } => {
                self.exec_matmul(
                    *ty,
                    *dst,
                    *a,
                    *b,
                    *m as usize,
                    *n as usize,
                    *k as usize,
                    buffers,
                )?;
            }
            #[cfg(feature = "blas")]
            Instruction::MatVec {
                ty,
                dst,
                mat,
                vec,
                rows,
                cols,
            } => {
                self.exec_matvec(
                    *ty,
                    *dst,
                    *mat,
                    *vec,
                    *rows as usize,
                    *cols as usize,
                    buffers,
                )?;
            }

            // Without blas: Pure Rust Dot product
            #[cfg(not(feature = "blas"))]
            Instruction::Dot { ty, dst, a, b, len } => {
                let result = self.exec_dot_pure(*ty, *a, *b, *len as usize, buffers);
                self.state.set_float(*dst, result);
            }

            // Without blas: Pure Rust MatMul
            #[cfg(not(feature = "blas"))]
            Instruction::MatMul {
                ty,
                dst,
                a,
                b,
                m,
                n,
                k,
            } => {
                self.exec_matmul_pure(
                    *ty,
                    *dst,
                    *a,
                    *b,
                    *m as usize,
                    *n as usize,
                    *k as usize,
                    buffers,
                )?;
            }

            // Without blas: Pure Rust MatVec
            #[cfg(not(feature = "blas"))]
            Instruction::MatVec {
                ty,
                dst,
                mat,
                vec,
                rows,
                cols,
            } => {
                self.exec_matvec_pure(
                    *ty,
                    *dst,
                    *mat,
                    *vec,
                    *rows as usize,
                    *cols as usize,
                    buffers,
                )?;
            }

            // Without blas: Pure Rust VecMat
            #[cfg(not(feature = "blas"))]
            Instruction::VecMat {
                ty,
                dst,
                vec,
                mat,
                rows,
                cols,
            } => {
                self.exec_vecmat_pure(
                    *ty,
                    *dst,
                    *vec,
                    *mat,
                    *rows as usize,
                    *cols as usize,
                    buffers,
                )?;
            }

            // Without blas: Pure Rust Outer product
            #[cfg(not(feature = "blas"))]
            Instruction::Outer {
                ty,
                dst,
                a,
                b,
                m,
                n,
            } => {
                self.exec_outer_pure(*ty, *dst, *a, *b, *m as usize, *n as usize, buffers)?;
            }

            // Without blas: Pure Rust Transpose
            #[cfg(not(feature = "blas"))]
            Instruction::Transpose {
                ty,
                dst,
                src,
                rows,
                cols,
            } => {
                self.exec_transpose_pure(*ty, *dst, *src, *rows as usize, *cols as usize, buffers)?;
            }

            // Without blas: Pure Rust BatchMatMul
            #[cfg(not(feature = "blas"))]
            Instruction::BatchMatMul {
                ty,
                dst,
                a,
                b,
                batch,
                m,
                n,
                k,
            } => {
                self.exec_batch_matmul_pure(
                    *ty,
                    *dst,
                    *a,
                    *b,
                    *batch as usize,
                    *m as usize,
                    *n as usize,
                    *k as usize,
                    buffers,
                )?;
            }

            // Without blas: Pure Rust Conv1D
            #[cfg(not(feature = "blas"))]
            Instruction::Conv1D {
                ty,
                dst,
                input,
                kernel,
                input_len,
                kernel_size,
                stride,
                padding,
            } => {
                self.exec_conv1d_pure(
                    *ty,
                    *dst,
                    *input,
                    *kernel,
                    *input_len as usize,
                    *kernel_size as usize,
                    *stride as usize,
                    *padding as usize,
                    buffers,
                )?;
            }

            // Without blas: Pure Rust Conv2D
            #[cfg(not(feature = "blas"))]
            Instruction::Conv2D {
                ty,
                dst,
                input,
                kernel,
                in_h,
                in_w,
                k_h,
                k_w,
                stride,
                padding,
            } => {
                self.exec_conv2d_pure(
                    *ty,
                    *dst,
                    *input,
                    *kernel,
                    *in_h as usize,
                    *in_w as usize,
                    *k_h as usize,
                    *k_w as usize,
                    *stride as usize,
                    *padding as usize,
                    buffers,
                )?;
            }

            // Without blas: Pure Rust Pool
            #[cfg(not(feature = "blas"))]
            Instruction::Pool {
                ty,
                dst,
                src,
                in_h,
                in_w,
                pool_h,
                pool_w,
                stride,
                pool_type,
            } => {
                self.exec_pool_pure(
                    *ty,
                    *dst,
                    *src,
                    *in_h as usize,
                    *in_w as usize,
                    *pool_h as usize,
                    *pool_w as usize,
                    *stride as usize,
                    *pool_type,
                    buffers,
                )?;
            }

            // With blas: VecMat implementation
            #[cfg(feature = "blas")]
            Instruction::VecMat {
                ty,
                dst,
                vec,
                mat,
                rows,
                cols,
            } => {
                self.exec_vecmat(
                    *ty,
                    *dst,
                    *vec,
                    *mat,
                    *rows as usize,
                    *cols as usize,
                    buffers,
                )?;
            }

            // With blas: Outer product implementation
            #[cfg(feature = "blas")]
            Instruction::Outer {
                ty,
                dst,
                a,
                b,
                m,
                n,
            } => {
                self.exec_outer(*ty, *dst, *a, *b, *m as usize, *n as usize, buffers)?;
            }

            // With blas: Transpose implementation
            #[cfg(feature = "blas")]
            Instruction::Transpose {
                ty,
                dst,
                src,
                rows,
                cols,
            } => {
                self.exec_transpose(*ty, *dst, *src, *rows as usize, *cols as usize, buffers)?;
            }

            // With blas: BatchMatMul implementation
            #[cfg(feature = "blas")]
            Instruction::BatchMatMul {
                ty,
                dst,
                a,
                b,
                batch,
                m,
                n,
                k,
            } => {
                self.exec_batch_matmul(
                    *ty,
                    *dst,
                    *a,
                    *b,
                    *batch as usize,
                    *m as usize,
                    *n as usize,
                    *k as usize,
                    buffers,
                )?;
            }

            // With blas: Conv1D implementation
            #[cfg(feature = "blas")]
            Instruction::Conv1D {
                ty,
                dst,
                input,
                kernel,
                input_len,
                kernel_size,
                stride,
                padding,
            } => {
                self.exec_conv1d(
                    *ty,
                    *dst,
                    *input,
                    *kernel,
                    *input_len as usize,
                    *kernel_size as usize,
                    *stride as usize,
                    *padding as usize,
                    buffers,
                )?;
            }

            // With blas: Conv2D implementation
            #[cfg(feature = "blas")]
            Instruction::Conv2D {
                ty,
                dst,
                input,
                kernel,
                in_h,
                in_w,
                k_h,
                k_w,
                stride,
                padding,
            } => {
                self.exec_conv2d(
                    *ty,
                    *dst,
                    *input,
                    *kernel,
                    *in_h as usize,
                    *in_w as usize,
                    *k_h as usize,
                    *k_w as usize,
                    *stride as usize,
                    *padding as usize,
                    buffers,
                )?;
            }

            // With blas: Pool implementation
            #[cfg(feature = "blas")]
            Instruction::Pool {
                ty,
                dst,
                src,
                in_h,
                in_w,
                pool_h,
                pool_w,
                stride,
                pool_type,
            } => {
                self.exec_pool(
                    *ty,
                    *dst,
                    *src,
                    *in_h as usize,
                    *in_w as usize,
                    *pool_h as usize,
                    *pool_w as usize,
                    *stride as usize,
                    *pool_type,
                    buffers,
                )?;
            }

            // Reduction operations - use buffer data
            Instruction::Mean { ty, dst, src, len } => {
                let result = self.exec_mean(*ty, *src, *len as usize, buffers);
                self.state.set_float(*dst, result);
            }
            Instruction::Variance { ty, dst, src, len } => {
                let result = self.exec_variance(*ty, *src, *len as usize, buffers);
                self.state.set_float(*dst, result);
            }
            Instruction::Norm {
                ty, dst, src, len, ..
            } => {
                let result = self.exec_norm(*ty, *src, *len as usize, buffers);
                self.state.set_float(*dst, result);
            }
            Instruction::ArgMax { dst, src, len, .. } => {
                let result = self.exec_argmax(*src, *len as usize, buffers);
                self.state.set_reg(*dst, result);
            }
            Instruction::ArgMin { dst, src, len, .. } => {
                let result = self.exec_argmin(*src, *len as usize, buffers);
                self.state.set_reg(*dst, result);
            }
            Instruction::TopK {
                ty,
                dst_vals,
                dst_indices,
                src,
                len,
                k,
            } => {
                self.exec_topk(
                    *ty,
                    *dst_vals,
                    *dst_indices,
                    *src,
                    *len as usize,
                    *k as usize,
                    buffers,
                )?;
            }

            // Loss functions - compute from buffer data
            Instruction::Mse {
                ty,
                dst,
                pred,
                target,
                len,
            } => {
                let result = self.exec_mse(*ty, *pred, *target, *len as usize, buffers);
                self.state.set_float(*dst, result);
            }
            Instruction::Mae {
                ty,
                dst,
                pred,
                target,
                len,
            } => {
                let result = self.exec_mae(*ty, *pred, *target, *len as usize, buffers);
                self.state.set_float(*dst, result);
            }
            Instruction::CrossEntropy {
                ty,
                dst,
                pred,
                target,
                len,
            } => {
                let result = self.exec_cross_entropy(*ty, *pred, *target, *len as usize, buffers);
                self.state.set_float(*dst, result);
            }
            Instruction::Huber {
                ty,
                dst,
                pred,
                target,
                len,
                delta,
            } => {
                let delta_val = self.state.get_float(*delta);
                let result =
                    self.exec_huber(*ty, *pred, *target, *len as usize, delta_val, buffers);
                self.state.set_float(*dst, result);
            }

            // Handle any future instructions (non-exhaustive enum)
            _ => {
                // Unknown instruction - no-op for forward compatibility
            }
        }

        Ok(())
    }

    /// Execute move immediate.
    fn exec_mov_imm(&mut self, ty: Type, dst: Register, value: i128) {
        if ty.is_float() {
            self.state.set_float(dst, value as f64);
        } else {
            self.state.set_reg(dst, value as u64);
        }
    }

    /// Execute load from buffer.
    fn exec_load(
        &mut self,
        ty: Type,
        dst: Register,
        addr: &hologram_isa::Address,
        buffers: &FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        match addr {
            hologram_isa::Address::Buffer { handle, offset } => {
                let buf = buffers.get(&(*handle as u64)).ok_or_else(|| {
                    BackendError::InvalidHandle(BufferHandle::new(*handle as u64))
                })?;

                let size = ty.size_bytes();
                if *offset + size > buf.len() {
                    return Err(BackendError::buffer("Load out of bounds"));
                }

                let bytes = &buf[*offset..*offset + size];
                let value = load_value(bytes, ty);

                if ty.is_float() {
                    self.state.set_float(dst, f64::from_bits(value));
                } else {
                    self.state.set_reg(dst, value);
                }
            }
            hologram_isa::Address::RegisterOffset { base, offset } => {
                let base_addr = self.state.get_reg(Register::new(*base));
                let addr = (base_addr as i64 + *offset as i64) as u64;
                // For register-indirect, we'd need buffer lookup by address
                self.state.set_reg(dst, addr);
            }
        }
        Ok(())
    }

    /// Execute store to buffer.
    fn exec_store(
        &mut self,
        ty: Type,
        addr: &hologram_isa::Address,
        src: Register,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        match addr {
            hologram_isa::Address::Buffer { handle, offset } => {
                let value = if ty.is_float() {
                    self.state.get_float(src).to_bits()
                } else {
                    self.state.get_reg(src)
                };

                let buf = buffers.get_mut(&(*handle as u64)).ok_or_else(|| {
                    BackendError::InvalidHandle(BufferHandle::new(*handle as u64))
                })?;

                let size = ty.size_bytes();
                if *offset + size > buf.len() {
                    return Err(BackendError::buffer("Store out of bounds"));
                }

                store_value(&mut buf[*offset..*offset + size], value, ty);
            }
            hologram_isa::Address::RegisterOffset { .. } => {
                // Register-indirect store not implemented
            }
        }
        Ok(())
    }

    /// Execute binary operation.
    fn exec_binary_op<F, G>(
        &mut self,
        ty: Type,
        dst: Register,
        lhs: Register,
        rhs: Register,
        int_op: F,
        float_op: G,
    ) where
        F: Fn(u64, u64) -> u64,
        G: Fn(f64, f64) -> f64,
    {
        if ty.is_float() {
            let a = self.state.get_float(lhs);
            let b = self.state.get_float(rhs);
            self.state.set_float(dst, float_op(a, b));
        } else {
            let a = self.state.get_reg(lhs);
            let b = self.state.get_reg(rhs);
            self.state.set_reg(dst, int_op(a, b));
        }
    }

    /// Execute unary float operation.
    fn exec_unary_float<F>(&mut self, _ty: Type, dst: Register, src: Register, op: F)
    where
        F: Fn(f64) -> f64,
    {
        let val = self.state.get_float(src);
        self.state.set_float(dst, op(val));
    }

    /// Execute comparison operation.
    fn exec_comparison<F, G>(
        &mut self,
        ty: Type,
        dst: Register,
        lhs: Register,
        rhs: Register,
        int_cmp: F,
        float_cmp: G,
    ) where
        F: Fn(u64, u64) -> bool,
        G: Fn(f64, f64) -> bool,
    {
        let result = if ty.is_float() {
            let a = self.state.get_float(lhs);
            let b = self.state.get_float(rhs);
            float_cmp(a, b)
        } else {
            let a = self.state.get_reg(lhs);
            let b = self.state.get_reg(rhs);
            int_cmp(a, b)
        };
        self.state.set_reg(dst, result as u64);
    }

    /// Execute mean reduction.
    fn exec_mean(
        &self,
        ty: Type,
        src: Register,
        len: usize,
        buffers: &FxHashMap<u64, Vec<u8>>,
    ) -> f64 {
        if len == 0 {
            return 0.0;
        }
        let handle = self.state.get_reg(src);
        let Some(buf) = buffers.get(&handle) else {
            return 0.0;
        };
        let elem_size = ty.size_bytes();
        let sum: f64 = (0..len)
            .filter_map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= buf.len() {
                    Some(read_float(&buf[offset..offset + elem_size], ty))
                } else {
                    None
                }
            })
            .sum();
        sum / len as f64
    }

    /// Execute variance reduction.
    fn exec_variance(
        &self,
        ty: Type,
        src: Register,
        len: usize,
        buffers: &FxHashMap<u64, Vec<u8>>,
    ) -> f64 {
        if len == 0 {
            return 0.0;
        }
        let mean = self.exec_mean(ty, src, len, buffers);
        let handle = self.state.get_reg(src);
        let Some(buf) = buffers.get(&handle) else {
            return 0.0;
        };
        let elem_size = ty.size_bytes();
        let sum_sq: f64 = (0..len)
            .filter_map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= buf.len() {
                    let val = read_float(&buf[offset..offset + elem_size], ty);
                    Some((val - mean).powi(2))
                } else {
                    None
                }
            })
            .sum();
        sum_sq / len as f64
    }

    /// Execute L2 norm.
    fn exec_norm(
        &self,
        ty: Type,
        src: Register,
        len: usize,
        buffers: &FxHashMap<u64, Vec<u8>>,
    ) -> f64 {
        let handle = self.state.get_reg(src);
        let Some(buf) = buffers.get(&handle) else {
            return 0.0;
        };
        let elem_size = ty.size_bytes();
        let sum_sq: f64 = (0..len)
            .filter_map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= buf.len() {
                    let val = read_float(&buf[offset..offset + elem_size], ty);
                    Some(val * val)
                } else {
                    None
                }
            })
            .sum();
        sum_sq.sqrt()
    }

    /// Execute argmax.
    fn exec_argmax(&self, src: Register, len: usize, buffers: &FxHashMap<u64, Vec<u8>>) -> u64 {
        let handle = self.state.get_reg(src);
        let Some(buf) = buffers.get(&handle) else {
            return 0;
        };
        // Assume f32 elements
        let elem_size = 4;
        let mut max_idx = 0u64;
        let mut max_val = f64::NEG_INFINITY;
        for i in 0..len {
            let offset = i * elem_size;
            if offset + elem_size <= buf.len() {
                let val = read_float(&buf[offset..offset + elem_size], Type::F32);
                if val > max_val {
                    max_val = val;
                    max_idx = i as u64;
                }
            }
        }
        max_idx
    }

    /// Execute argmin.
    fn exec_argmin(&self, src: Register, len: usize, buffers: &FxHashMap<u64, Vec<u8>>) -> u64 {
        let handle = self.state.get_reg(src);
        let Some(buf) = buffers.get(&handle) else {
            return 0;
        };
        // Assume f32 elements
        let elem_size = 4;
        let mut min_idx = 0u64;
        let mut min_val = f64::INFINITY;
        for i in 0..len {
            let offset = i * elem_size;
            if offset + elem_size <= buf.len() {
                let val = read_float(&buf[offset..offset + elem_size], Type::F32);
                if val < min_val {
                    min_val = val;
                    min_idx = i as u64;
                }
            }
        }
        min_idx
    }

    /// Execute mean squared error loss.
    fn exec_mse(
        &self,
        ty: Type,
        pred: Register,
        target: Register,
        len: usize,
        buffers: &FxHashMap<u64, Vec<u8>>,
    ) -> f64 {
        if len == 0 {
            return 0.0;
        }
        let pred_handle = self.state.get_reg(pred);
        let target_handle = self.state.get_reg(target);
        let (Some(pred_buf), Some(target_buf)) =
            (buffers.get(&pred_handle), buffers.get(&target_handle))
        else {
            return 0.0;
        };
        let elem_size = ty.size_bytes();
        let sum: f64 = (0..len)
            .filter_map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= pred_buf.len() && offset + elem_size <= target_buf.len() {
                    let p = read_float(&pred_buf[offset..offset + elem_size], ty);
                    let t = read_float(&target_buf[offset..offset + elem_size], ty);
                    Some((p - t).powi(2))
                } else {
                    None
                }
            })
            .sum();
        sum / len as f64
    }

    /// Execute mean absolute error loss.
    fn exec_mae(
        &self,
        ty: Type,
        pred: Register,
        target: Register,
        len: usize,
        buffers: &FxHashMap<u64, Vec<u8>>,
    ) -> f64 {
        if len == 0 {
            return 0.0;
        }
        let pred_handle = self.state.get_reg(pred);
        let target_handle = self.state.get_reg(target);
        let (Some(pred_buf), Some(target_buf)) =
            (buffers.get(&pred_handle), buffers.get(&target_handle))
        else {
            return 0.0;
        };
        let elem_size = ty.size_bytes();
        let sum: f64 = (0..len)
            .filter_map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= pred_buf.len() && offset + elem_size <= target_buf.len() {
                    let p = read_float(&pred_buf[offset..offset + elem_size], ty);
                    let t = read_float(&target_buf[offset..offset + elem_size], ty);
                    Some((p - t).abs())
                } else {
                    None
                }
            })
            .sum();
        sum / len as f64
    }

    /// Execute dot product (with blas feature).
    #[cfg(feature = "blas")]
    fn exec_dot(
        &self,
        ty: Type,
        a: Register,
        b: Register,
        len: usize,
        buffers: &FxHashMap<u64, Vec<u8>>,
    ) -> f64 {
        let a_handle = self.state.get_reg(a);
        let b_handle = self.state.get_reg(b);
        let (Some(a_buf), Some(b_buf)) = (buffers.get(&a_handle), buffers.get(&b_handle)) else {
            return 0.0;
        };
        let elem_size = ty.size_bytes();
        let a_vec: Vec<f64> = (0..len)
            .filter_map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= a_buf.len() {
                    Some(read_float(&a_buf[offset..offset + elem_size], ty))
                } else {
                    None
                }
            })
            .collect();
        let b_vec: Vec<f64> = (0..len)
            .filter_map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= b_buf.len() {
                    Some(read_float(&b_buf[offset..offset + elem_size], ty))
                } else {
                    None
                }
            })
            .collect();

        let a_arr = Array1::from_vec(a_vec);
        let b_arr = Array1::from_vec(b_vec);
        a_arr.dot(&b_arr)
    }

    /// Execute matrix multiply (with blas feature).
    #[cfg(feature = "blas")]
    #[allow(clippy::too_many_arguments)]
    fn exec_matmul(
        &mut self,
        ty: Type,
        dst: Register,
        a: Register,
        b: Register,
        m: usize,
        n: usize,
        k: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let a_handle = self.state.get_reg(a);
        let b_handle = self.state.get_reg(b);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let a_buf = buffers
            .get(&a_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(a_handle)))?
            .clone();
        let b_buf = buffers
            .get(&b_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(b_handle)))?
            .clone();

        // Read matrices
        let a_data: Vec<f64> = (0..m * k)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= a_buf.len() {
                    read_float(&a_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();
        let b_data: Vec<f64> = (0..k * n)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= b_buf.len() {
                    read_float(&b_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();

        let a_mat = Array2::from_shape_vec((m, k), a_data)
            .map_err(|e| BackendError::buffer(format!("Invalid matrix A shape: {}", e)))?;
        let b_mat = Array2::from_shape_vec((k, n), b_data)
            .map_err(|e| BackendError::buffer(format!("Invalid matrix B shape: {}", e)))?;

        let c_mat = a_mat.dot(&b_mat);

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in c_mat.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Execute matrix-vector multiply (with blas feature).
    #[cfg(feature = "blas")]
    #[allow(clippy::too_many_arguments)]
    fn exec_matvec(
        &mut self,
        ty: Type,
        dst: Register,
        mat: Register,
        vec: Register,
        rows: usize,
        cols: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let mat_handle = self.state.get_reg(mat);
        let vec_handle = self.state.get_reg(vec);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let mat_buf = buffers
            .get(&mat_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(mat_handle)))?
            .clone();
        let vec_buf = buffers
            .get(&vec_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(vec_handle)))?
            .clone();

        // Read matrix and vector
        let mat_data: Vec<f64> = (0..rows * cols)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= mat_buf.len() {
                    read_float(&mat_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();
        let vec_data: Vec<f64> = (0..cols)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= vec_buf.len() {
                    read_float(&vec_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();

        let m = Array2::from_shape_vec((rows, cols), mat_data)
            .map_err(|e| BackendError::buffer(format!("Invalid matrix shape: {}", e)))?;
        let v = Array1::from_vec(vec_data);

        let result = m.dot(&v);

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Execute vector-matrix multiply (with blas feature).
    /// dst = vec @ mat (1×rows) @ (rows×cols) = (1×cols)
    #[cfg(feature = "blas")]
    #[allow(clippy::too_many_arguments)]
    fn exec_vecmat(
        &mut self,
        ty: Type,
        dst: Register,
        vec: Register,
        mat: Register,
        rows: usize,
        cols: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let vec_handle = self.state.get_reg(vec);
        let mat_handle = self.state.get_reg(mat);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let vec_buf = buffers
            .get(&vec_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(vec_handle)))?
            .clone();
        let mat_buf = buffers
            .get(&mat_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(mat_handle)))?
            .clone();

        // Read vector and matrix
        let vec_data: Vec<f64> = (0..rows)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= vec_buf.len() {
                    read_float(&vec_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();
        let mat_data: Vec<f64> = (0..rows * cols)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= mat_buf.len() {
                    read_float(&mat_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();

        let v = Array1::from_vec(vec_data);
        let m = Array2::from_shape_vec((rows, cols), mat_data)
            .map_err(|e| BackendError::buffer(format!("Invalid matrix shape: {}", e)))?;

        // v @ M = v.T.dot(M) for row vector semantics
        // Using column vector approach: result[j] = sum_i(v[i] * M[i,j])
        let mut result = vec![0.0_f64; cols];
        for j in 0..cols {
            for i in 0..rows {
                result[j] += v[i] * m[[i, j]];
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Execute outer product (with blas feature).
    /// dst[i,j] = a[i] * b[j]
    #[cfg(feature = "blas")]
    #[allow(clippy::too_many_arguments)]
    fn exec_outer(
        &mut self,
        ty: Type,
        dst: Register,
        a: Register,
        b: Register,
        m: usize,
        n: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let a_handle = self.state.get_reg(a);
        let b_handle = self.state.get_reg(b);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let a_buf = buffers
            .get(&a_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(a_handle)))?
            .clone();
        let b_buf = buffers
            .get(&b_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(b_handle)))?
            .clone();

        // Read vectors
        let a_data: Vec<f64> = (0..m)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= a_buf.len() {
                    read_float(&a_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();
        let b_data: Vec<f64> = (0..n)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= b_buf.len() {
                    read_float(&b_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();

        // Compute outer product
        let mut result = vec![0.0_f64; m * n];
        for i in 0..m {
            for j in 0..n {
                result[i * n + j] = a_data[i] * b_data[j];
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Execute matrix transpose (with blas feature).
    /// dst = src^T
    #[cfg(feature = "blas")]
    fn exec_transpose(
        &mut self,
        ty: Type,
        dst: Register,
        src: Register,
        rows: usize,
        cols: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let src_handle = self.state.get_reg(src);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let src_buf = buffers
            .get(&src_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(src_handle)))?
            .clone();

        // Read matrix
        let src_data: Vec<f64> = (0..rows * cols)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= src_buf.len() {
                    read_float(&src_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();

        // Transpose: src[i,j] -> dst[j,i]
        let mut result = vec![0.0_f64; rows * cols];
        for i in 0..rows {
            for j in 0..cols {
                result[j * rows + i] = src_data[i * cols + j];
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Execute batched matrix multiply (with blas feature).
    /// dst[b] = a[b] @ b[b] for each batch
    #[cfg(feature = "blas")]
    #[allow(clippy::too_many_arguments)]
    fn exec_batch_matmul(
        &mut self,
        ty: Type,
        dst: Register,
        a: Register,
        b: Register,
        batch: usize,
        m: usize,
        n: usize,
        k: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let a_handle = self.state.get_reg(a);
        let b_handle = self.state.get_reg(b);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let a_buf = buffers
            .get(&a_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(a_handle)))?
            .clone();
        let b_buf = buffers
            .get(&b_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(b_handle)))?
            .clone();

        let a_batch_size = m * k;
        let b_batch_size = k * n;
        let c_batch_size = m * n;
        let mut result = vec![0.0_f64; batch * c_batch_size];

        for batch_idx in 0..batch {
            // Read batch matrices
            let a_data: Vec<f64> = (0..a_batch_size)
                .map(|i| {
                    let offset = (batch_idx * a_batch_size + i) * elem_size;
                    if offset + elem_size <= a_buf.len() {
                        read_float(&a_buf[offset..offset + elem_size], ty)
                    } else {
                        0.0
                    }
                })
                .collect();
            let b_data: Vec<f64> = (0..b_batch_size)
                .map(|i| {
                    let offset = (batch_idx * b_batch_size + i) * elem_size;
                    if offset + elem_size <= b_buf.len() {
                        read_float(&b_buf[offset..offset + elem_size], ty)
                    } else {
                        0.0
                    }
                })
                .collect();

            let a_mat = Array2::from_shape_vec((m, k), a_data).map_err(|e| {
                BackendError::buffer(format!("Invalid batch matrix A shape: {}", e))
            })?;
            let b_mat = Array2::from_shape_vec((k, n), b_data).map_err(|e| {
                BackendError::buffer(format!("Invalid batch matrix B shape: {}", e))
            })?;

            let c_mat = a_mat.dot(&b_mat);

            // Copy to result
            for (i, &val) in c_mat.iter().enumerate() {
                result[batch_idx * c_batch_size + i] = val;
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Execute 1D convolution.
    #[cfg(feature = "blas")]
    #[allow(clippy::too_many_arguments)]
    fn exec_conv1d(
        &mut self,
        ty: Type,
        dst: Register,
        input: Register,
        kernel: Register,
        input_len: usize,
        kernel_size: usize,
        stride: usize,
        padding: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let input_handle = self.state.get_reg(input);
        let kernel_handle = self.state.get_reg(kernel);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let input_buf = buffers
            .get(&input_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(input_handle)))?
            .clone();
        let kernel_buf = buffers
            .get(&kernel_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(kernel_handle)))?
            .clone();

        // Read input and kernel
        let input_data: Vec<f64> = (0..input_len)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= input_buf.len() {
                    read_float(&input_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();
        let kernel_data: Vec<f64> = (0..kernel_size)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= kernel_buf.len() {
                    read_float(&kernel_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();

        // Compute output length
        let padded_len = input_len + 2 * padding;
        let output_len = (padded_len - kernel_size) / stride + 1;
        let mut result = vec![0.0_f64; output_len];

        // Perform convolution
        for (out_idx, result_val) in result.iter_mut().enumerate() {
            let start = out_idx * stride;
            let mut sum = 0.0_f64;
            for (k_idx, kernel_val) in kernel_data.iter().enumerate() {
                let in_idx = start + k_idx;
                let val = if in_idx < padding || in_idx >= padding + input_len {
                    0.0 // Zero padding
                } else {
                    input_data[in_idx - padding]
                };
                sum += val * kernel_val;
            }
            *result_val = sum;
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Execute 2D convolution.
    #[cfg(feature = "blas")]
    #[allow(clippy::too_many_arguments)]
    fn exec_conv2d(
        &mut self,
        ty: Type,
        dst: Register,
        input: Register,
        kernel: Register,
        in_h: usize,
        in_w: usize,
        k_h: usize,
        k_w: usize,
        stride: usize,
        padding: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let input_handle = self.state.get_reg(input);
        let kernel_handle = self.state.get_reg(kernel);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let input_buf = buffers
            .get(&input_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(input_handle)))?
            .clone();
        let kernel_buf = buffers
            .get(&kernel_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(kernel_handle)))?
            .clone();

        // Read input and kernel
        let input_data: Vec<f64> = (0..in_h * in_w)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= input_buf.len() {
                    read_float(&input_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();
        let kernel_data: Vec<f64> = (0..k_h * k_w)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= kernel_buf.len() {
                    read_float(&kernel_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();

        // Compute output dimensions
        let padded_h = in_h + 2 * padding;
        let padded_w = in_w + 2 * padding;
        let out_h = (padded_h - k_h) / stride + 1;
        let out_w = (padded_w - k_w) / stride + 1;
        let mut result = vec![0.0_f64; out_h * out_w];

        // Perform 2D convolution
        for out_row in 0..out_h {
            for out_col in 0..out_w {
                let start_row = out_row * stride;
                let start_col = out_col * stride;
                let mut sum = 0.0_f64;

                for k_row in 0..k_h {
                    for k_col in 0..k_w {
                        let in_row = start_row + k_row;
                        let in_col = start_col + k_col;

                        let val = if in_row < padding
                            || in_row >= padding + in_h
                            || in_col < padding
                            || in_col >= padding + in_w
                        {
                            0.0 // Zero padding
                        } else {
                            let actual_row = in_row - padding;
                            let actual_col = in_col - padding;
                            input_data[actual_row * in_w + actual_col]
                        };

                        sum += val * kernel_data[k_row * k_w + k_col];
                    }
                }
                result[out_row * out_w + out_col] = sum;
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Execute pooling operation (max or average).
    #[cfg(feature = "blas")]
    #[allow(clippy::too_many_arguments)]
    fn exec_pool(
        &mut self,
        ty: Type,
        dst: Register,
        src: Register,
        in_h: usize,
        in_w: usize,
        pool_h: usize,
        pool_w: usize,
        stride: usize,
        pool_type: u8,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let src_handle = self.state.get_reg(src);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let src_buf = buffers
            .get(&src_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(src_handle)))?
            .clone();

        // Read input
        let input_data: Vec<f64> = (0..in_h * in_w)
            .map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= src_buf.len() {
                    read_float(&src_buf[offset..offset + elem_size], ty)
                } else {
                    0.0
                }
            })
            .collect();

        // Compute output dimensions
        let out_h = (in_h - pool_h) / stride + 1;
        let out_w = (in_w - pool_w) / stride + 1;
        let mut result = vec![0.0_f64; out_h * out_w];

        // Perform pooling
        for out_row in 0..out_h {
            for out_col in 0..out_w {
                let start_row = out_row * stride;
                let start_col = out_col * stride;

                if pool_type == 0 {
                    // Max pooling
                    let mut max_val = f64::NEG_INFINITY;
                    for p_row in 0..pool_h {
                        for p_col in 0..pool_w {
                            let in_row = start_row + p_row;
                            let in_col = start_col + p_col;
                            if in_row < in_h && in_col < in_w {
                                let val = input_data[in_row * in_w + in_col];
                                if val > max_val {
                                    max_val = val;
                                }
                            }
                        }
                    }
                    result[out_row * out_w + out_col] = max_val;
                } else {
                    // Average pooling
                    let mut sum = 0.0_f64;
                    let mut count = 0;
                    for p_row in 0..pool_h {
                        for p_col in 0..pool_w {
                            let in_row = start_row + p_row;
                            let in_col = start_col + p_col;
                            if in_row < in_h && in_col < in_w {
                                sum += input_data[in_row * in_w + in_col];
                                count += 1;
                            }
                        }
                    }
                    result[out_row * out_w + out_col] =
                        if count > 0 { sum / count as f64 } else { 0.0 };
                }
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Execute TopK operation.
    #[allow(clippy::too_many_arguments)]
    fn exec_topk(
        &mut self,
        ty: Type,
        dst_vals: Register,
        dst_indices: Register,
        src: Register,
        len: usize,
        k: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let src_handle = self.state.get_reg(src);
        let vals_handle = self.state.get_reg(dst_vals);
        let indices_handle = self.state.get_reg(dst_indices);

        let elem_size = ty.size_bytes();
        let src_buf = buffers
            .get(&src_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(src_handle)))?
            .clone();

        // Read input data with indices
        let mut indexed_data: Vec<(usize, f64)> = (0..len)
            .map(|i| {
                let offset = i * elem_size;
                let val = if offset + elem_size <= src_buf.len() {
                    read_float(&src_buf[offset..offset + elem_size], ty)
                } else {
                    f64::NEG_INFINITY
                };
                (i, val)
            })
            .collect();

        // Sort by value (descending) to get top-k
        indexed_data.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

        // Take top k
        let k = k.min(len);
        let top_k: Vec<(usize, f64)> = indexed_data.into_iter().take(k).collect();

        // Write values
        if let Some(vals_buf) = buffers.get_mut(&vals_handle) {
            for (i, (_, val)) in top_k.iter().enumerate() {
                let offset = i * elem_size;
                if offset + elem_size <= vals_buf.len() {
                    write_float(&mut vals_buf[offset..offset + elem_size], *val, ty);
                }
            }
        }

        // Write indices (as u64)
        if let Some(indices_buf) = buffers.get_mut(&indices_handle) {
            for (i, (idx, _)) in top_k.iter().enumerate() {
                let offset = i * 8; // Indices are always u64
                if offset + 8 <= indices_buf.len() {
                    indices_buf[offset..offset + 8].copy_from_slice(&(*idx as u64).to_le_bytes());
                }
            }
        }

        Ok(())
    }

    /// Execute cross-entropy loss.
    /// loss = -sum(target * log(pred))
    fn exec_cross_entropy(
        &self,
        ty: Type,
        pred: Register,
        target: Register,
        len: usize,
        buffers: &FxHashMap<u64, Vec<u8>>,
    ) -> f64 {
        if len == 0 {
            return 0.0;
        }
        let pred_handle = self.state.get_reg(pred);
        let target_handle = self.state.get_reg(target);
        let (Some(pred_buf), Some(target_buf)) =
            (buffers.get(&pred_handle), buffers.get(&target_handle))
        else {
            return 0.0;
        };
        let elem_size = ty.size_bytes();
        let sum: f64 = (0..len)
            .filter_map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= pred_buf.len() && offset + elem_size <= target_buf.len() {
                    let p = read_float(&pred_buf[offset..offset + elem_size], ty);
                    let t = read_float(&target_buf[offset..offset + elem_size], ty);
                    // Clamp prediction to avoid log(0)
                    let p_clamped = p.clamp(1e-15, 1.0 - 1e-15);
                    Some(-t * p_clamped.ln())
                } else {
                    None
                }
            })
            .sum();
        sum
    }

    /// Execute Huber loss (smooth L1 loss).
    /// loss = 0.5 * (pred - target)^2 if |pred - target| <= delta
    /// loss = delta * (|pred - target| - 0.5 * delta) otherwise
    fn exec_huber(
        &self,
        ty: Type,
        pred: Register,
        target: Register,
        len: usize,
        delta: f64,
        buffers: &FxHashMap<u64, Vec<u8>>,
    ) -> f64 {
        if len == 0 {
            return 0.0;
        }
        let pred_handle = self.state.get_reg(pred);
        let target_handle = self.state.get_reg(target);
        let (Some(pred_buf), Some(target_buf)) =
            (buffers.get(&pred_handle), buffers.get(&target_handle))
        else {
            return 0.0;
        };
        let elem_size = ty.size_bytes();
        let sum: f64 = (0..len)
            .filter_map(|i| {
                let offset = i * elem_size;
                if offset + elem_size <= pred_buf.len() && offset + elem_size <= target_buf.len() {
                    let p = read_float(&pred_buf[offset..offset + elem_size], ty);
                    let t = read_float(&target_buf[offset..offset + elem_size], ty);
                    let diff = (p - t).abs();
                    let loss = if diff <= delta {
                        0.5 * diff * diff
                    } else {
                        delta * (diff - 0.5 * delta)
                    };
                    Some(loss)
                } else {
                    None
                }
            })
            .sum();
        sum / len as f64
    }

    // ========================================================================
    // PURE RUST IMPLEMENTATIONS (without ndarray/blas)
    // ========================================================================

    /// Pure Rust dot product (without blas).
    #[cfg(not(feature = "blas"))]
    fn exec_dot_pure(
        &self,
        ty: Type,
        a: Register,
        b: Register,
        len: usize,
        buffers: &FxHashMap<u64, Vec<u8>>,
    ) -> f64 {
        let a_handle = self.state.get_reg(a);
        let b_handle = self.state.get_reg(b);
        let (Some(a_buf), Some(b_buf)) = (buffers.get(&a_handle), buffers.get(&b_handle)) else {
            return 0.0;
        };
        let elem_size = ty.size_bytes();
        let mut sum = 0.0_f64;
        for i in 0..len {
            let offset = i * elem_size;
            if offset + elem_size <= a_buf.len() && offset + elem_size <= b_buf.len() {
                let a_val = read_float(&a_buf[offset..offset + elem_size], ty);
                let b_val = read_float(&b_buf[offset..offset + elem_size], ty);
                sum += a_val * b_val;
            }
        }
        sum
    }

    /// Pure Rust matrix multiply (without blas).
    /// C[m,n] = A[m,k] @ B[k,n]
    #[cfg(not(feature = "blas"))]
    #[allow(clippy::too_many_arguments)]
    fn exec_matmul_pure(
        &mut self,
        ty: Type,
        dst: Register,
        a: Register,
        b: Register,
        m: usize,
        n: usize,
        k: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let a_handle = self.state.get_reg(a);
        let b_handle = self.state.get_reg(b);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let a_buf = buffers
            .get(&a_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(a_handle)))?
            .clone();
        let b_buf = buffers
            .get(&b_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(b_handle)))?
            .clone();

        // Read A[m,k] and B[k,n]
        let read_a = |i, j| {
            let offset = (i * k + j) * elem_size;
            if offset + elem_size <= a_buf.len() {
                read_float(&a_buf[offset..offset + elem_size], ty)
            } else {
                0.0
            }
        };
        let read_b = |i, j| {
            let offset = (i * n + j) * elem_size;
            if offset + elem_size <= b_buf.len() {
                read_float(&b_buf[offset..offset + elem_size], ty)
            } else {
                0.0
            }
        };

        // C[i,j] = sum_l A[i,l] * B[l,j]
        let mut result = vec![0.0_f64; m * n];
        for i in 0..m {
            for j in 0..n {
                let mut sum = 0.0_f64;
                for l in 0..k {
                    sum += read_a(i, l) * read_b(l, j);
                }
                result[i * n + j] = sum;
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Pure Rust matrix-vector multiply (without blas).
    /// dst = mat[rows,cols] @ vec[cols]
    #[cfg(not(feature = "blas"))]
    #[allow(clippy::too_many_arguments)]
    fn exec_matvec_pure(
        &mut self,
        ty: Type,
        dst: Register,
        mat: Register,
        vec: Register,
        rows: usize,
        cols: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let mat_handle = self.state.get_reg(mat);
        let vec_handle = self.state.get_reg(vec);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let mat_buf = buffers
            .get(&mat_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(mat_handle)))?
            .clone();
        let vec_buf = buffers
            .get(&vec_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(vec_handle)))?
            .clone();

        let mut result = vec![0.0_f64; rows];
        for i in 0..rows {
            let mut sum = 0.0_f64;
            for j in 0..cols {
                let mat_offset = (i * cols + j) * elem_size;
                let vec_offset = j * elem_size;
                if mat_offset + elem_size <= mat_buf.len()
                    && vec_offset + elem_size <= vec_buf.len()
                {
                    let m_val = read_float(&mat_buf[mat_offset..mat_offset + elem_size], ty);
                    let v_val = read_float(&vec_buf[vec_offset..vec_offset + elem_size], ty);
                    sum += m_val * v_val;
                }
            }
            result[i] = sum;
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Pure Rust vector-matrix multiply (without blas).
    /// dst = vec[rows] @ mat[rows,cols]
    #[cfg(not(feature = "blas"))]
    #[allow(clippy::too_many_arguments)]
    fn exec_vecmat_pure(
        &mut self,
        ty: Type,
        dst: Register,
        vec: Register,
        mat: Register,
        rows: usize,
        cols: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let vec_handle = self.state.get_reg(vec);
        let mat_handle = self.state.get_reg(mat);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let vec_buf = buffers
            .get(&vec_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(vec_handle)))?
            .clone();
        let mat_buf = buffers
            .get(&mat_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(mat_handle)))?
            .clone();

        let mut result = vec![0.0_f64; cols];
        for j in 0..cols {
            let mut sum = 0.0_f64;
            for i in 0..rows {
                let vec_offset = i * elem_size;
                let mat_offset = (i * cols + j) * elem_size;
                if vec_offset + elem_size <= vec_buf.len()
                    && mat_offset + elem_size <= mat_buf.len()
                {
                    let v_val = read_float(&vec_buf[vec_offset..vec_offset + elem_size], ty);
                    let m_val = read_float(&mat_buf[mat_offset..mat_offset + elem_size], ty);
                    sum += v_val * m_val;
                }
            }
            result[j] = sum;
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Pure Rust outer product (without blas).
    /// dst[i,j] = a[i] * b[j]
    #[cfg(not(feature = "blas"))]
    #[allow(clippy::too_many_arguments)]
    fn exec_outer_pure(
        &mut self,
        ty: Type,
        dst: Register,
        a: Register,
        b: Register,
        m: usize,
        n: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let a_handle = self.state.get_reg(a);
        let b_handle = self.state.get_reg(b);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let a_buf = buffers
            .get(&a_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(a_handle)))?
            .clone();
        let b_buf = buffers
            .get(&b_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(b_handle)))?
            .clone();

        let mut result = vec![0.0_f64; m * n];
        for i in 0..m {
            let a_offset = i * elem_size;
            let a_val = if a_offset + elem_size <= a_buf.len() {
                read_float(&a_buf[a_offset..a_offset + elem_size], ty)
            } else {
                0.0
            };
            for j in 0..n {
                let b_offset = j * elem_size;
                let b_val = if b_offset + elem_size <= b_buf.len() {
                    read_float(&b_buf[b_offset..b_offset + elem_size], ty)
                } else {
                    0.0
                };
                result[i * n + j] = a_val * b_val;
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Pure Rust matrix transpose (without blas).
    /// dst = src^T
    #[cfg(not(feature = "blas"))]
    fn exec_transpose_pure(
        &mut self,
        ty: Type,
        dst: Register,
        src: Register,
        rows: usize,
        cols: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let src_handle = self.state.get_reg(src);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let src_buf = buffers
            .get(&src_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(src_handle)))?
            .clone();

        // Transpose: src[i,j] -> dst[j,i]
        let mut result = vec![0.0_f64; rows * cols];
        for i in 0..rows {
            for j in 0..cols {
                let src_offset = (i * cols + j) * elem_size;
                let val = if src_offset + elem_size <= src_buf.len() {
                    read_float(&src_buf[src_offset..src_offset + elem_size], ty)
                } else {
                    0.0
                };
                result[j * rows + i] = val;
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Pure Rust batched matrix multiply (without blas).
    #[cfg(not(feature = "blas"))]
    #[allow(clippy::too_many_arguments)]
    fn exec_batch_matmul_pure(
        &mut self,
        ty: Type,
        dst: Register,
        a: Register,
        b: Register,
        batch: usize,
        m: usize,
        n: usize,
        k: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let a_handle = self.state.get_reg(a);
        let b_handle = self.state.get_reg(b);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let a_buf = buffers
            .get(&a_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(a_handle)))?
            .clone();
        let b_buf = buffers
            .get(&b_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(b_handle)))?
            .clone();

        let a_batch_size = m * k;
        let b_batch_size = k * n;
        let c_batch_size = m * n;
        let mut result = vec![0.0_f64; batch * c_batch_size];

        for batch_idx in 0..batch {
            for i in 0..m {
                for j in 0..n {
                    let mut sum = 0.0_f64;
                    for l in 0..k {
                        let a_offset = (batch_idx * a_batch_size + i * k + l) * elem_size;
                        let b_offset = (batch_idx * b_batch_size + l * n + j) * elem_size;
                        let a_val = if a_offset + elem_size <= a_buf.len() {
                            read_float(&a_buf[a_offset..a_offset + elem_size], ty)
                        } else {
                            0.0
                        };
                        let b_val = if b_offset + elem_size <= b_buf.len() {
                            read_float(&b_buf[b_offset..b_offset + elem_size], ty)
                        } else {
                            0.0
                        };
                        sum += a_val * b_val;
                    }
                    result[batch_idx * c_batch_size + i * n + j] = sum;
                }
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Pure Rust 1D convolution (without blas).
    #[cfg(not(feature = "blas"))]
    #[allow(clippy::too_many_arguments)]
    fn exec_conv1d_pure(
        &mut self,
        ty: Type,
        dst: Register,
        input: Register,
        kernel: Register,
        input_len: usize,
        kernel_size: usize,
        stride: usize,
        padding: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let input_handle = self.state.get_reg(input);
        let kernel_handle = self.state.get_reg(kernel);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let input_buf = buffers
            .get(&input_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(input_handle)))?
            .clone();
        let kernel_buf = buffers
            .get(&kernel_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(kernel_handle)))?
            .clone();

        // Compute output length
        let padded_len = input_len + 2 * padding;
        let output_len = if padded_len >= kernel_size {
            (padded_len - kernel_size) / stride + 1
        } else {
            0
        };
        let mut result = vec![0.0_f64; output_len];

        // Perform convolution
        for (out_idx, result_val) in result.iter_mut().enumerate() {
            let start = out_idx * stride;
            let mut sum = 0.0_f64;
            for k_idx in 0..kernel_size {
                let in_idx = start + k_idx;
                let kernel_offset = k_idx * elem_size;
                let kernel_val = if kernel_offset + elem_size <= kernel_buf.len() {
                    read_float(&kernel_buf[kernel_offset..kernel_offset + elem_size], ty)
                } else {
                    0.0
                };
                let input_val = if in_idx < padding || in_idx >= padding + input_len {
                    0.0 // Zero padding
                } else {
                    let input_offset = (in_idx - padding) * elem_size;
                    if input_offset + elem_size <= input_buf.len() {
                        read_float(&input_buf[input_offset..input_offset + elem_size], ty)
                    } else {
                        0.0
                    }
                };
                sum += input_val * kernel_val;
            }
            *result_val = sum;
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Pure Rust 2D convolution (without blas).
    #[cfg(not(feature = "blas"))]
    #[allow(clippy::too_many_arguments)]
    fn exec_conv2d_pure(
        &mut self,
        ty: Type,
        dst: Register,
        input: Register,
        kernel: Register,
        in_h: usize,
        in_w: usize,
        k_h: usize,
        k_w: usize,
        stride: usize,
        padding: usize,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let input_handle = self.state.get_reg(input);
        let kernel_handle = self.state.get_reg(kernel);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let input_buf = buffers
            .get(&input_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(input_handle)))?
            .clone();
        let kernel_buf = buffers
            .get(&kernel_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(kernel_handle)))?
            .clone();

        // Compute output dimensions
        let padded_h = in_h + 2 * padding;
        let padded_w = in_w + 2 * padding;
        let out_h = if padded_h >= k_h {
            (padded_h - k_h) / stride + 1
        } else {
            0
        };
        let out_w = if padded_w >= k_w {
            (padded_w - k_w) / stride + 1
        } else {
            0
        };
        let mut result = vec![0.0_f64; out_h * out_w];

        // Perform 2D convolution
        for out_row in 0..out_h {
            for out_col in 0..out_w {
                let start_row = out_row * stride;
                let start_col = out_col * stride;
                let mut sum = 0.0_f64;

                for k_row in 0..k_h {
                    for k_col in 0..k_w {
                        let in_row = start_row + k_row;
                        let in_col = start_col + k_col;

                        let kernel_offset = (k_row * k_w + k_col) * elem_size;
                        let kernel_val = if kernel_offset + elem_size <= kernel_buf.len() {
                            read_float(&kernel_buf[kernel_offset..kernel_offset + elem_size], ty)
                        } else {
                            0.0
                        };

                        let input_val = if in_row < padding
                            || in_row >= padding + in_h
                            || in_col < padding
                            || in_col >= padding + in_w
                        {
                            0.0 // Zero padding
                        } else {
                            let actual_row = in_row - padding;
                            let actual_col = in_col - padding;
                            let input_offset = (actual_row * in_w + actual_col) * elem_size;
                            if input_offset + elem_size <= input_buf.len() {
                                read_float(&input_buf[input_offset..input_offset + elem_size], ty)
                            } else {
                                0.0
                            }
                        };

                        sum += input_val * kernel_val;
                    }
                }
                result[out_row * out_w + out_col] = sum;
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    /// Pure Rust pooling operation (without blas).
    #[cfg(not(feature = "blas"))]
    #[allow(clippy::too_many_arguments)]
    fn exec_pool_pure(
        &mut self,
        ty: Type,
        dst: Register,
        src: Register,
        in_h: usize,
        in_w: usize,
        pool_h: usize,
        pool_w: usize,
        stride: usize,
        pool_type: u8,
        buffers: &mut FxHashMap<u64, Vec<u8>>,
    ) -> Result<(), BackendError> {
        let src_handle = self.state.get_reg(src);
        let dst_handle = self.state.get_reg(dst);

        let elem_size = ty.size_bytes();
        let src_buf = buffers
            .get(&src_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(src_handle)))?
            .clone();

        // Compute output dimensions
        let out_h = if in_h >= pool_h {
            (in_h - pool_h) / stride + 1
        } else {
            0
        };
        let out_w = if in_w >= pool_w {
            (in_w - pool_w) / stride + 1
        } else {
            0
        };
        let mut result = vec![0.0_f64; out_h * out_w];

        // Perform pooling
        for out_row in 0..out_h {
            for out_col in 0..out_w {
                let start_row = out_row * stride;
                let start_col = out_col * stride;

                if pool_type == 0 {
                    // Max pooling
                    let mut max_val = f64::NEG_INFINITY;
                    for p_row in 0..pool_h {
                        for p_col in 0..pool_w {
                            let in_row = start_row + p_row;
                            let in_col = start_col + p_col;
                            if in_row < in_h && in_col < in_w {
                                let offset = (in_row * in_w + in_col) * elem_size;
                                if offset + elem_size <= src_buf.len() {
                                    let val = read_float(&src_buf[offset..offset + elem_size], ty);
                                    if val > max_val {
                                        max_val = val;
                                    }
                                }
                            }
                        }
                    }
                    result[out_row * out_w + out_col] = max_val;
                } else {
                    // Average pooling
                    let mut sum = 0.0_f64;
                    let mut count = 0;
                    for p_row in 0..pool_h {
                        for p_col in 0..pool_w {
                            let in_row = start_row + p_row;
                            let in_col = start_col + p_col;
                            if in_row < in_h && in_col < in_w {
                                let offset = (in_row * in_w + in_col) * elem_size;
                                if offset + elem_size <= src_buf.len() {
                                    sum += read_float(&src_buf[offset..offset + elem_size], ty);
                                    count += 1;
                                }
                            }
                        }
                    }
                    result[out_row * out_w + out_col] =
                        if count > 0 { sum / count as f64 } else { 0.0 };
                }
            }
        }

        // Write result
        let dst_buf = buffers
            .get_mut(&dst_handle)
            .ok_or_else(|| BackendError::InvalidHandle(BufferHandle::new(dst_handle)))?;
        for (i, &val) in result.iter().enumerate() {
            let offset = i * elem_size;
            if offset + elem_size <= dst_buf.len() {
                write_float(&mut dst_buf[offset..offset + elem_size], val, ty);
            }
        }
        Ok(())
    }

    // =========================================================================
    // Optimized IR Operation Kernels
    // =========================================================================

    /// Execute softmax operation on buffer.
    fn exec_softmax(&mut self, args: &[Register], buffers: &mut FxHashMap<u64, Vec<u8>>) {
        if args.is_empty() {
            return;
        }
        let dst = args[0];
        let handle = self.state.get_reg(dst);

        if let Some(buffer) = buffers.get_mut(&handle) {
            // Interpret buffer as f32 slice
            if buffer.len() % 4 != 0 {
                return;
            }
            let len = buffer.len() / 4;
            if len == 0 {
                return;
            }

            // Read f32 values
            let mut data: Vec<f32> = buffer
                .chunks_exact(4)
                .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
                .collect();

            // Compute max for numerical stability
            let max = data.iter().copied().fold(f32::NEG_INFINITY, f32::max);

            // exp(x - max)
            for x in data.iter_mut() {
                *x = (*x - max).exp();
            }

            // sum
            let sum: f32 = data.iter().sum();

            // normalize
            if sum > 0.0 {
                for x in data.iter_mut() {
                    *x /= sum;
                }
            }

            // Write back
            for (i, &val) in data.iter().enumerate() {
                let bytes = val.to_le_bytes();
                buffer[i * 4..(i + 1) * 4].copy_from_slice(&bytes);
            }
        }
    }

    /// Execute layer normalization on buffer.
    fn exec_layernorm(&mut self, args: &[Register], buffers: &mut FxHashMap<u64, Vec<u8>>) {
        if args.is_empty() {
            return;
        }
        let dst = args[0];
        let handle = self.state.get_reg(dst);
        let epsilon = 1e-5f32;

        if let Some(buffer) = buffers.get_mut(&handle) {
            if buffer.len() % 4 != 0 {
                return;
            }
            let len = buffer.len() / 4;
            if len == 0 {
                return;
            }

            // Read f32 values
            let mut data: Vec<f32> = buffer
                .chunks_exact(4)
                .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
                .collect();

            let n = data.len() as f32;
            let mean: f32 = data.iter().sum::<f32>() / n;
            let variance: f32 = data.iter().map(|x| (x - mean).powi(2)).sum::<f32>() / n;
            let std = (variance + epsilon).sqrt();

            for x in data.iter_mut() {
                *x = (*x - mean) / std;
            }

            // Write back
            for (i, &val) in data.iter().enumerate() {
                let bytes = val.to_le_bytes();
                buffer[i * 4..(i + 1) * 4].copy_from_slice(&bytes);
            }
        }
    }

    /// Execute batch normalization on buffer.
    fn exec_batchnorm(&mut self, args: &[Register], buffers: &mut FxHashMap<u64, Vec<u8>>) {
        if args.is_empty() {
            return;
        }
        let dst = args[0];
        let handle = self.state.get_reg(dst);
        let epsilon = 1e-5f32;

        if let Some(buffer) = buffers.get_mut(&handle) {
            if buffer.len() % 4 != 0 {
                return;
            }
            let len = buffer.len() / 4;
            if len == 0 {
                return;
            }

            // Read f32 values
            let mut data: Vec<f32> = buffer
                .chunks_exact(4)
                .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
                .collect();

            // Batch norm: normalize using running statistics
            // For inference, we normalize per-element (simplified)
            let n = data.len() as f32;
            let mean: f32 = data.iter().sum::<f32>() / n;
            let variance: f32 = data.iter().map(|x| (x - mean).powi(2)).sum::<f32>() / n;
            let std = (variance + epsilon).sqrt();

            for x in data.iter_mut() {
                *x = (*x - mean) / std;
            }

            // Write back
            for (i, &val) in data.iter().enumerate() {
                let bytes = val.to_le_bytes();
                buffer[i * 4..(i + 1) * 4].copy_from_slice(&bytes);
            }
        }
    }

    /// Execute gather operation (index-based selection).
    fn exec_gather(&mut self, args: &[Register], buffers: &mut FxHashMap<u64, Vec<u8>>) {
        if args.len() < 3 {
            return;
        }
        let dst = args[0];
        let _axis = args[1].index(); // Axis for gather (0-255)
        let _indices_count = args[2].index(); // Number of indices

        let handle = self.state.get_reg(dst);

        // Gather operates on pre-arranged data where source data and indices
        // are passed via the plan's buffer layout. The dst buffer already
        // contains the gathered results computed during plan execution.
        // This instruction validates the operation completed successfully.
        if let Some(buffer) = buffers.get(&handle) {
            // Verify buffer has expected size based on indices_count
            let expected_size = _indices_count as usize * 4; // f32 elements
            debug_assert!(
                buffer.len() >= expected_size,
                "Gather output buffer too small: {} < {}",
                buffer.len(),
                expected_size
            );
        }
    }

    /// Execute slice operation (contiguous memory region).
    ///
    /// Slice extracts a contiguous region from a tensor. The plan executor
    /// pre-computes slice offsets and copies data to the destination buffer
    /// before this instruction runs. This instruction validates the result.
    fn exec_slice(&mut self, args: &[Register], buffers: &mut FxHashMap<u64, Vec<u8>>) {
        if args.len() < 2 {
            return;
        }
        let dst = args[0];
        let size = args[1].index(); // Size of slice in elements

        let handle = self.state.get_reg(dst);

        // Slice data is pre-computed by the plan executor. Validate the buffer.
        if let Some(buffer) = buffers.get(&handle) {
            let expected_bytes = size as usize * 4; // f32 elements
            debug_assert!(
                buffer.len() >= expected_bytes,
                "Slice output buffer too small: {} < {}",
                buffer.len(),
                expected_bytes
            );
        }
    }

    /// Execute concat operation (concatenate buffers).
    ///
    /// Concat joins multiple input tensors along a specified axis. The plan
    /// executor pre-computes the concatenation and writes results to the
    /// destination buffer before this instruction runs.
    fn exec_concat(&mut self, args: &[Register], buffers: &mut FxHashMap<u64, Vec<u8>>) {
        if args.len() < 3 {
            return;
        }
        let dst = args[0];
        let _axis = args[1].index(); // Axis for concatenation
        let input_count = args[2].index(); // Number of inputs

        let handle = self.state.get_reg(dst);

        // Concat data is pre-computed by the plan executor. Validate the buffer exists.
        if let Some(buffer) = buffers.get(&handle) {
            debug_assert!(
                !buffer.is_empty() || input_count == 0,
                "Concat output buffer is empty but {} inputs expected",
                input_count
            );
        }
    }

    /// Execute shape operation - extract tensor dimensions as i64 array.
    ///
    /// Args format: [dst_handle, src_handle, start, end]
    /// - dst_handle: Output buffer handle (will contain i64 dimension values)
    /// - src_handle: Input tensor buffer handle (shape looked up in registry)
    /// - start: Starting dimension index
    /// - end: Ending dimension index (-1 means rank of input)
    fn exec_shape(
        &mut self,
        args: &[Register],
        buffers: &mut FxHashMap<u64, Vec<u8>>,
        shape_registry: Option<&FxHashMap<u64, Vec<usize>>>,
    ) {
        if args.len() < 4 {
            return;
        }

        let dst_handle = self.state.get_reg(args[0]);
        let src_handle = self.state.get_reg(args[1]);
        let start = self.state.get_reg(args[2]) as i64;
        let end = self.state.get_reg(args[3]) as i64;

        // Look up the shape from the registry
        let Some(registry) = shape_registry else {
            return; // No shape registry, can't extract shape
        };

        let Some(shape) = registry.get(&src_handle) else {
            return; // Shape not registered for this buffer
        };

        let rank = shape.len() as i64;
        let start_idx = if start < 0 {
            (rank + start).max(0) as usize
        } else {
            start as usize
        };
        let end_idx = if end < 0 {
            rank as usize
        } else {
            (end as usize).min(rank as usize)
        };

        // Extract the requested dimensions and convert to i64
        let dims: Vec<i64> = shape
            .get(start_idx..end_idx)
            .unwrap_or(&[])
            .iter()
            .map(|&d| d as i64)
            .collect();

        // Write the dimensions to the output buffer as i64 values
        let bytes_needed = dims.len() * 8; // i64 = 8 bytes
        let output_bytes: Vec<u8> = dims.iter().flat_map(|&d| d.to_le_bytes()).collect();

        // Insert or update the output buffer
        if let Some(buffer) = buffers.get_mut(&dst_handle) {
            if buffer.len() >= bytes_needed {
                buffer[..bytes_needed].copy_from_slice(&output_bytes);
            }
        } else {
            buffers.insert(dst_handle, output_bytes);
        }
    }

    /// Execute dynamic reshape kernel.
    ///
    /// Args: [dst_handle, src_handle, shape_handle, allow_zero_flag]
    ///
    /// Reshapes the input tensor to the shape specified by the shape tensor.
    /// The shape tensor is a 1D i64 tensor containing the target dimensions.
    /// Special values:
    /// - `-1` means infer this dimension from total element count
    /// - `0` (when allow_zero=true) means copy from input dimension at same index
    fn exec_reshape_dynamic(
        &mut self,
        args: &[Register],
        buffers: &mut FxHashMap<u64, Vec<u8>>,
        shape_registry: Option<&FxHashMap<u64, Vec<usize>>>,
    ) {
        if args.len() < 4 {
            return;
        }

        let dst_handle = self.state.get_reg(args[0]);
        let src_handle = self.state.get_reg(args[1]);
        let shape_handle = self.state.get_reg(args[2]);
        let allow_zero = self.state.get_reg(args[3]) != 0;

        // Get source buffer
        let Some(src_buf) = buffers.get(&src_handle) else {
            return;
        };

        // Get source shape from registry
        let src_shape = shape_registry
            .and_then(|r| r.get(&src_handle))
            .cloned()
            .unwrap_or_default();

        // Get shape tensor values (stored as i64)
        let Some(shape_buf) = buffers.get(&shape_handle) else {
            return;
        };
        let shape_values: Vec<i64> = shape_buf
            .chunks_exact(8)
            .map(|c| i64::from_le_bytes(c.try_into().unwrap()))
            .collect();

        // Compute input element count
        let total_elements: usize = if src_shape.is_empty() {
            // Infer from buffer size (assuming f32)
            src_buf.len() / 4
        } else {
            src_shape.iter().product()
        };

        // Process shape values to compute new shape
        let mut new_shape = Vec::with_capacity(shape_values.len());
        let mut infer_dim_idx = None;
        let mut known_elements = 1usize;

        for (idx, &dim) in shape_values.iter().enumerate() {
            if dim == -1 {
                // Infer this dimension
                if infer_dim_idx.is_some() {
                    return; // Error: multiple -1 dimensions
                }
                infer_dim_idx = Some(idx);
                new_shape.push(0); // Sentinel: actual value computed after loop
            } else if dim == 0 && allow_zero {
                // Copy dimension from input shape
                let d = src_shape.get(idx).copied().unwrap_or(1);
                new_shape.push(d);
                known_elements = known_elements.saturating_mul(d);
            } else if dim > 0 {
                new_shape.push(dim as usize);
                known_elements = known_elements.saturating_mul(dim as usize);
            } else {
                return; // Error: invalid dimension value
            }
        }

        // Infer the -1 dimension if present
        if let Some(idx) = infer_dim_idx {
            if known_elements == 0 || !total_elements.is_multiple_of(known_elements) {
                return; // Error: cannot infer dimension
            }
            new_shape[idx] = total_elements / known_elements;
        }

        // Verify total element count matches
        let new_total: usize = new_shape.iter().product();
        if new_total != total_elements {
            return; // Error: element count mismatch
        }

        // Reshape is a view operation - copy buffer to destination
        // (In a zero-copy implementation, this would just update the shape registry)
        let dst_buf = src_buf.clone();
        buffers.insert(dst_handle, dst_buf);

        // Note: Shape registry update would require mutable access.
        // In a complete implementation, we'd update the shape registry here:
        // shape_registry.insert(dst_handle, new_shape);
    }

    /// Execute Range kernel: generate sequence from start to limit with step delta.
    /// Args: [dst_handle, start_handle, limit_handle, delta_handle]
    fn exec_range(&mut self, args: &[Register], buffers: &mut FxHashMap<u64, Vec<u8>>) {
        if args.len() < 4 {
            return;
        }

        let dst_handle = self.state.get_reg(args[0]);
        let start_handle = self.state.get_reg(args[1]);
        let limit_handle = self.state.get_reg(args[2]);
        let delta_handle = self.state.get_reg(args[3]);

        // Get scalar input buffers
        let Some(start_buf) = buffers.get(&start_handle) else {
            return;
        };
        let Some(limit_buf) = buffers.get(&limit_handle) else {
            return;
        };
        let Some(delta_buf) = buffers.get(&delta_handle) else {
            return;
        };

        // Detect type from buffer size (assuming all inputs have same type)
        let output_bytes = match start_buf.len() {
            8 => {
                // i64 or f64 - try i64 first
                let start = i64::from_le_bytes(start_buf[..8].try_into().unwrap());
                let limit = i64::from_le_bytes(limit_buf[..8].try_into().unwrap());
                let delta = i64::from_le_bytes(delta_buf[..8].try_into().unwrap());

                if delta == 0 {
                    return; // Invalid: delta cannot be zero
                }

                let num_elements = compute_range_length_i64(start, limit, delta);
                let mut values = Vec::with_capacity(num_elements * 8);
                for i in 0..num_elements {
                    let val = start + (i as i64) * delta;
                    values.extend_from_slice(&val.to_le_bytes());
                }
                values
            }
            4 => {
                // i32 or f32 - check if it looks like a float
                let bytes: [u8; 4] = start_buf[..4].try_into().unwrap();
                let as_i32 = i32::from_le_bytes(bytes);
                let as_f32 = f32::from_le_bytes(bytes);

                // Type inference heuristic for 4-byte values:
                // - Finite f32 with fractional component -> definitely float
                // - Large magnitude integer (>1M) that fits f32 range -> likely float
                // - Otherwise -> treat as i32
                // Note: The plan's dtype metadata should match this inference.
                if as_f32.is_finite()
                    && as_f32.abs() < 1e10
                    && (as_f32.fract() != 0.0 || as_i32.abs() > 1_000_000)
                {
                    // Treat as f32
                    let start = as_f32;
                    let limit = f32::from_le_bytes(limit_buf[..4].try_into().unwrap());
                    let delta = f32::from_le_bytes(delta_buf[..4].try_into().unwrap());

                    if delta == 0.0 {
                        return;
                    }

                    let num_elements = compute_range_length_f32(start, limit, delta);
                    let mut values = Vec::with_capacity(num_elements * 4);
                    for i in 0..num_elements {
                        let val = start + (i as f32) * delta;
                        values.extend_from_slice(&val.to_le_bytes());
                    }
                    values
                } else {
                    // Treat as i32
                    let start = as_i32;
                    let limit = i32::from_le_bytes(limit_buf[..4].try_into().unwrap());
                    let delta = i32::from_le_bytes(delta_buf[..4].try_into().unwrap());

                    if delta == 0 {
                        return;
                    }

                    let num_elements = compute_range_length_i32(start, limit, delta);
                    let mut values = Vec::with_capacity(num_elements * 4);
                    for i in 0..num_elements {
                        let val = start + (i as i32) * delta;
                        values.extend_from_slice(&val.to_le_bytes());
                    }
                    values
                }
            }
            _ => return, // Unsupported type size
        };

        buffers.insert(dst_handle, output_bytes);
    }

    /// Execute ConstantOfShape kernel: create a tensor filled with a constant value.
    /// Args: [dst_handle, shape_handle, fill_value_handle]
    fn exec_constant_of_shape(&mut self, args: &[Register], buffers: &mut FxHashMap<u64, Vec<u8>>) {
        if args.len() < 3 {
            return;
        }

        let dst_handle = self.state.get_reg(args[0]);
        let shape_handle = self.state.get_reg(args[1]);
        let fill_handle = self.state.get_reg(args[2]);

        // Get shape tensor
        let Some(shape_buf) = buffers.get(&shape_handle) else {
            return;
        };

        // Get fill value tensor
        let Some(fill_buf) = buffers.get(&fill_handle) else {
            return;
        };

        // Extract shape dimensions from shape tensor (assuming i64)
        let shape_dims: Vec<usize> = if shape_buf.len() % 8 == 0 {
            // i64 shape tensor
            shape_buf
                .chunks_exact(8)
                .filter_map(|chunk| chunk.try_into().ok())
                .map(|bytes: [u8; 8]| i64::from_le_bytes(bytes) as usize)
                .collect()
        } else if shape_buf.len() % 4 == 0 {
            // i32 shape tensor
            shape_buf
                .chunks_exact(4)
                .filter_map(|chunk| chunk.try_into().ok())
                .map(|bytes: [u8; 4]| i32::from_le_bytes(bytes) as usize)
                .collect()
        } else {
            return; // Invalid shape tensor
        };

        if shape_dims.is_empty() {
            return;
        }

        // Calculate total number of elements
        let total_elements: usize = shape_dims.iter().product();

        // Create output buffer filled with the fill value
        let output_bytes = match fill_buf.len() {
            4 => {
                // f32 or i32
                let val_bytes: [u8; 4] = fill_buf[..4].try_into().unwrap();
                let mut output = Vec::with_capacity(total_elements * 4);
                for _ in 0..total_elements {
                    output.extend_from_slice(&val_bytes);
                }
                output
            }
            8 => {
                // f64 or i64
                let val_bytes: [u8; 8] = fill_buf[..8].try_into().unwrap();
                let mut output = Vec::with_capacity(total_elements * 8);
                for _ in 0..total_elements {
                    output.extend_from_slice(&val_bytes);
                }
                output
            }
            1 => {
                // u8 or bool
                let val = fill_buf[0];
                vec![val; total_elements]
            }
            _ => return, // Unsupported fill value size
        };

        buffers.insert(dst_handle, output_bytes);
    }

    /// Execute expand (broadcast) operation.
    ///
    /// Broadcasts input tensor to target shape using numpy-style broadcasting rules.
    /// Args: [dst_handle, data_handle, shape_handle]
    fn exec_expand(
        &mut self,
        args: &[Register],
        buffers: &mut FxHashMap<u64, Vec<u8>>,
        shape_registry: Option<&FxHashMap<u64, Vec<usize>>>,
    ) {
        if args.len() < 3 {
            return;
        }

        let dst_handle = self.state.get_reg(args[0]);
        let data_handle = self.state.get_reg(args[1]);
        let shape_handle = self.state.get_reg(args[2]);

        // Get input data tensor
        let Some(data_buf) = buffers.get(&data_handle).cloned() else {
            return;
        };

        // Get target shape tensor
        let Some(shape_buf) = buffers.get(&shape_handle) else {
            return;
        };

        // Extract target shape dimensions from shape tensor
        let target_dims: Vec<usize> = if shape_buf.len() % 8 == 0 {
            shape_buf
                .chunks_exact(8)
                .filter_map(|chunk| chunk.try_into().ok())
                .map(|bytes: [u8; 8]| {
                    let val = i64::from_le_bytes(bytes);
                    if val < 0 {
                        0
                    } else {
                        val as usize
                    }
                })
                .collect()
        } else if shape_buf.len() % 4 == 0 {
            shape_buf
                .chunks_exact(4)
                .filter_map(|chunk| chunk.try_into().ok())
                .map(|bytes: [u8; 4]| {
                    let val = i32::from_le_bytes(bytes);
                    if val < 0 {
                        0
                    } else {
                        val as usize
                    }
                })
                .collect()
        } else {
            return;
        };

        if target_dims.is_empty() {
            return;
        }

        // Get input shape from shape registry
        let input_shape: Vec<usize> = shape_registry
            .and_then(|reg| reg.get(&data_handle).cloned())
            .unwrap_or_else(|| {
                // Fallback: try to infer from buffer size
                // Default to 1D tensor with element count
                vec![data_buf.len() / 4] // Assume f32
            });

        // Determine element size from shape and buffer
        let input_elements: usize = input_shape.iter().product();
        let elem_size = if input_elements > 0 {
            data_buf.len() / input_elements
        } else {
            4 // Default to f32
        };

        if elem_size == 0 || data_buf.len() % elem_size != 0 {
            return;
        }

        // Calculate total output elements
        let total_output: usize = target_dims.iter().product();

        if total_output == 0 {
            buffers.insert(dst_handle, Vec::new());
            return;
        }

        // Handle special case: single element broadcast
        if input_elements == 1 {
            let elem = &data_buf[..elem_size];
            let mut output = Vec::with_capacity(total_output * elem_size);
            for _ in 0..total_output {
                output.extend_from_slice(elem);
            }
            buffers.insert(dst_handle, output);
            return;
        }

        // Full N-D broadcasting
        let output_rank = target_dims.len();
        let input_rank = input_shape.len();

        // Compute input strides (for row-major layout)
        let mut input_strides = vec![1usize; input_rank];
        for i in (0..input_rank.saturating_sub(1)).rev() {
            input_strides[i] = input_strides[i + 1] * input_shape[i + 1];
        }

        // Compute output strides
        let mut output_strides = vec![1usize; output_rank];
        for i in (0..output_rank.saturating_sub(1)).rev() {
            output_strides[i] = output_strides[i + 1] * target_dims[i + 1];
        }

        // Create broadcast strides: 0 if dimension is broadcast, else input stride
        // Align dimensions from the right
        let mut broadcast_strides = vec![0usize; output_rank];
        for i in 0..output_rank {
            let input_idx = if i < output_rank - input_rank {
                None
            } else {
                Some(i - (output_rank - input_rank))
            };

            if let Some(idx) = input_idx {
                let in_dim = input_shape[idx];
                let out_dim = target_dims[i];
                // If input dim is 1, stride is 0 (broadcast)
                // Otherwise, use normal stride
                if in_dim == 1 {
                    broadcast_strides[i] = 0;
                } else if in_dim == out_dim {
                    broadcast_strides[i] = input_strides[idx];
                } else {
                    // Incompatible dimensions - this shouldn't happen if IR validation worked
                    broadcast_strides[i] = 0;
                }
            }
            // else: leading dimensions get stride 0 (implicit broadcast from size 1)
        }

        // Create output buffer
        let mut output = Vec::with_capacity(total_output * elem_size);

        // Iterate over all output positions
        for out_flat in 0..total_output {
            // Convert flat output index to multi-dimensional index
            let mut out_idx = vec![0usize; output_rank];
            let mut remaining = out_flat;
            for d in 0..output_rank {
                out_idx[d] = remaining / output_strides[d];
                remaining %= output_strides[d];
            }

            // Compute input flat index using broadcast strides
            let mut in_flat = 0usize;
            for d in 0..output_rank {
                in_flat += out_idx[d] * broadcast_strides[d];
            }

            // Copy element from input
            let src_offset = in_flat * elem_size;
            if src_offset + elem_size <= data_buf.len() {
                output.extend_from_slice(&data_buf[src_offset..src_offset + elem_size]);
            } else {
                // Fallback: replicate first element
                output.extend_from_slice(&data_buf[..elem_size]);
            }
        }

        buffers.insert(dst_handle, output);
    }

    /// Execute slice_dynamic kernel.
    ///
    /// Performs slicing with runtime-computed starts, ends, axes, and steps.
    /// Args: [dst_handle, data_handle, starts_handle, ends_handle, axes_handle?, steps_handle?]
    fn exec_slice_dynamic(
        &mut self,
        args: &[Register],
        buffers: &mut FxHashMap<u64, Vec<u8>>,
        shape_registry: Option<&FxHashMap<u64, Vec<usize>>>,
    ) {
        if args.len() < 4 {
            return;
        }

        let dst_handle = self.state.get_reg(args[0]);
        let data_handle = self.state.get_reg(args[1]);
        let starts_handle = self.state.get_reg(args[2]);
        let ends_handle = self.state.get_reg(args[3]);

        // Optional axes and steps
        let axes_handle = if args.len() > 4 {
            Some(self.state.get_reg(args[4]))
        } else {
            None
        };
        let steps_handle = if args.len() > 5 {
            Some(self.state.get_reg(args[5]))
        } else {
            None
        };

        // Get input data tensor
        let Some(data_buf) = buffers.get(&data_handle).cloned() else {
            return;
        };

        // Get starts tensor (i64)
        let Some(starts_buf) = buffers.get(&starts_handle) else {
            return;
        };
        let starts: Vec<i64> = starts_buf
            .chunks_exact(8)
            .filter_map(|chunk| chunk.try_into().ok())
            .map(|bytes: [u8; 8]| i64::from_le_bytes(bytes))
            .collect();

        // Get ends tensor (i64)
        let Some(ends_buf) = buffers.get(&ends_handle) else {
            return;
        };
        let ends: Vec<i64> = ends_buf
            .chunks_exact(8)
            .filter_map(|chunk| chunk.try_into().ok())
            .map(|bytes: [u8; 8]| i64::from_le_bytes(bytes))
            .collect();

        if starts.is_empty() || ends.is_empty() || starts.len() != ends.len() {
            return;
        }

        // Get optional axes tensor (i32 or i64)
        let axes: Vec<i64> = if let Some(handle) = axes_handle {
            if let Some(axes_buf) = buffers.get(&handle) {
                if axes_buf.len() % 8 == 0 {
                    // i64
                    axes_buf
                        .chunks_exact(8)
                        .filter_map(|chunk| chunk.try_into().ok())
                        .map(|bytes: [u8; 8]| i64::from_le_bytes(bytes))
                        .collect()
                } else if axes_buf.len() % 4 == 0 {
                    // i32
                    axes_buf
                        .chunks_exact(4)
                        .filter_map(|chunk| chunk.try_into().ok())
                        .map(|bytes: [u8; 4]| i32::from_le_bytes(bytes) as i64)
                        .collect()
                } else {
                    (0..starts.len() as i64).collect()
                }
            } else {
                (0..starts.len() as i64).collect()
            }
        } else {
            (0..starts.len() as i64).collect()
        };

        // Get optional steps tensor (i64)
        let steps: Vec<i64> = if let Some(handle) = steps_handle {
            if let Some(steps_buf) = buffers.get(&handle) {
                steps_buf
                    .chunks_exact(8)
                    .filter_map(|chunk| chunk.try_into().ok())
                    .map(|bytes: [u8; 8]| i64::from_le_bytes(bytes))
                    .collect()
            } else {
                vec![1i64; starts.len()]
            }
        } else {
            vec![1i64; starts.len()]
        };

        // Get data shape from shape_registry or infer 1D
        let data_shape: Vec<usize> = shape_registry
            .and_then(|r| r.get(&data_handle))
            .cloned()
            .unwrap_or_else(|| vec![data_buf.len() / 4]); // Assume f32 for fallback

        let data_elements: usize = data_shape.iter().product();

        // Determine element size from shape and buffer
        let elem_size = if data_elements > 0 {
            data_buf.len() / data_elements
        } else {
            4 // Default to f32
        };

        if elem_size == 0 || data_buf.len() % elem_size != 0 {
            buffers.insert(dst_handle, Vec::new());
            return;
        }

        let rank = data_shape.len();

        // Normalize axes (handle negative values)
        let norm_axes: Vec<usize> = axes
            .iter()
            .map(|&ax| {
                if ax < 0 {
                    (rank as i64 + ax) as usize
                } else {
                    ax as usize
                }
            })
            .collect();

        // Validate axes
        if norm_axes.iter().any(|&ax| ax >= rank) {
            buffers.insert(dst_handle, data_buf);
            return;
        }

        // Build slice specification for each dimension
        // Default: take the entire dimension
        let mut slice_specs: Vec<(usize, usize, i64)> =
            data_shape.iter().map(|&dim| (0, dim, 1)).collect();

        for (i, &axis) in norm_axes.iter().enumerate() {
            let dim_size = data_shape[axis] as i64;
            let start = starts.get(i).copied().unwrap_or(0);
            let end = ends.get(i).copied().unwrap_or(dim_size);
            let step = steps.get(i).copied().unwrap_or(1);

            // Normalize negative indices and handle i64::MAX
            let norm_start = if start < 0 {
                (dim_size + start).max(0) as usize
            } else if start == i64::MAX {
                data_shape[axis]
            } else {
                (start as usize).min(data_shape[axis])
            };

            let norm_end = if end < 0 {
                (dim_size + end).max(0) as usize
            } else if end == i64::MAX {
                data_shape[axis]
            } else {
                (end as usize).min(data_shape[axis])
            };

            slice_specs[axis] = (norm_start, norm_end, step);
        }

        // Compute output shape
        let output_shape: Vec<usize> = slice_specs
            .iter()
            .map(|&(start, end, step)| {
                if step > 0 {
                    let range = end.saturating_sub(start);
                    range.div_ceil(step as usize)
                } else if step < 0 {
                    let range = start.saturating_sub(end);
                    range.div_ceil((-step) as usize)
                } else {
                    0 // step=0 is invalid, return 0
                }
            })
            .collect();

        // Check for zero step (invalid)
        if output_shape.contains(&0) && steps.contains(&0) {
            buffers.insert(dst_handle, Vec::new());
            return;
        }

        // Total output elements
        let output_elements: usize = output_shape.iter().product();
        if output_elements == 0 {
            buffers.insert(dst_handle, Vec::new());
            return;
        }

        // Compute strides for row-major layout
        let mut strides: Vec<usize> = vec![1; rank];
        for i in (0..rank.saturating_sub(1)).rev() {
            strides[i] = strides[i + 1] * data_shape[i + 1];
        }

        // Perform N-D slice
        let mut output = Vec::with_capacity(output_elements * elem_size);
        let mut output_indices = vec![0usize; rank];

        for _ in 0..output_elements {
            // Compute source index for this output position
            let mut src_flat_idx: usize = 0;
            for dim in 0..rank {
                let (start, _end, step) = slice_specs[dim];
                let src_dim_idx = if step > 0 {
                    start + output_indices[dim] * step as usize
                } else {
                    // Negative step: start from high index, go down
                    start.saturating_sub(output_indices[dim] * (-step) as usize)
                };
                src_flat_idx += src_dim_idx * strides[dim];
            }

            // Copy element
            let src_offset = src_flat_idx * elem_size;
            if src_offset + elem_size <= data_buf.len() {
                output.extend_from_slice(&data_buf[src_offset..src_offset + elem_size]);
            } else {
                // Out of bounds, write zeros
                output.extend(std::iter::repeat_n(0u8, elem_size));
            }

            // Increment output indices (row-major order)
            for dim in (0..rank).rev() {
                output_indices[dim] += 1;
                if output_indices[dim] < output_shape[dim] {
                    break;
                }
                output_indices[dim] = 0;
            }
        }

        buffers.insert(dst_handle, output);
    }

    /// Execute tile (repeat) operation.
    ///
    /// Tiles input tensor by repeating along each dimension.
    /// Args: [dst_handle, data_handle, repeats_handle]
    fn exec_tile(
        &mut self,
        args: &[Register],
        buffers: &mut FxHashMap<u64, Vec<u8>>,
        shape_registry: Option<&FxHashMap<u64, Vec<usize>>>,
    ) {
        if args.len() < 3 {
            return;
        }

        let dst_handle = self.state.get_reg(args[0]);
        let data_handle = self.state.get_reg(args[1]);
        let repeats_handle = self.state.get_reg(args[2]);

        // Get input data tensor
        let Some(data_buf) = buffers.get(&data_handle).cloned() else {
            return;
        };

        // Get repeats tensor
        let Some(repeats_buf) = buffers.get(&repeats_handle) else {
            return;
        };

        // Extract repeats (i64 or i32)
        let repeats: Vec<usize> = if repeats_buf.len() % 8 == 0 {
            repeats_buf
                .chunks_exact(8)
                .filter_map(|chunk| chunk.try_into().ok())
                .map(|bytes: [u8; 8]| {
                    let val = i64::from_le_bytes(bytes);
                    val.max(1) as usize
                })
                .collect()
        } else if repeats_buf.len() % 4 == 0 {
            repeats_buf
                .chunks_exact(4)
                .filter_map(|chunk| chunk.try_into().ok())
                .map(|bytes: [u8; 4]| {
                    let val = i32::from_le_bytes(bytes);
                    val.max(1) as usize
                })
                .collect()
        } else {
            return;
        };

        if repeats.is_empty() {
            return;
        }

        // Get input shape from shape_registry
        let input_shape: Vec<usize> = shape_registry
            .and_then(|reg| reg.get(&data_handle).cloned())
            .unwrap_or_else(|| vec![data_buf.len() / 4]); // Assume f32

        // Validate repeats length matches input rank
        if repeats.len() != input_shape.len() {
            // Mismatch - try to pad or truncate
            return;
        }

        let input_elements: usize = input_shape.iter().product();
        let elem_size = if input_elements > 0 {
            data_buf.len() / input_elements
        } else {
            4 // Default to f32
        };

        if elem_size == 0 || data_buf.len() % elem_size != 0 {
            return;
        }

        let rank = input_shape.len();

        // Compute output shape = input_shape * repeats
        let output_shape: Vec<usize> = input_shape
            .iter()
            .zip(repeats.iter())
            .map(|(&s, &r)| s * r)
            .collect();

        let output_elements: usize = output_shape.iter().product();

        if output_elements == 0 {
            buffers.insert(dst_handle, Vec::new());
            return;
        }

        // Compute input strides (row-major)
        let mut input_strides = vec![1usize; rank];
        for i in (0..rank.saturating_sub(1)).rev() {
            input_strides[i] = input_strides[i + 1] * input_shape[i + 1];
        }

        // Compute output strides
        let mut output_strides = vec![1usize; rank];
        for i in (0..rank.saturating_sub(1)).rev() {
            output_strides[i] = output_strides[i + 1] * output_shape[i + 1];
        }

        // Perform tiling
        let mut output = Vec::with_capacity(output_elements * elem_size);

        for out_flat in 0..output_elements {
            // Convert flat output index to multi-dimensional
            let mut out_idx = vec![0usize; rank];
            let mut remaining = out_flat;
            for d in 0..rank {
                out_idx[d] = remaining / output_strides[d];
                remaining %= output_strides[d];
            }

            // Map to input index using modulo (tile wraps)
            let mut in_flat = 0usize;
            for d in 0..rank {
                let in_dim_idx = out_idx[d] % input_shape[d];
                in_flat += in_dim_idx * input_strides[d];
            }

            // Copy element
            let src_offset = in_flat * elem_size;
            if src_offset + elem_size <= data_buf.len() {
                output.extend_from_slice(&data_buf[src_offset..src_offset + elem_size]);
            } else {
                output.extend(std::iter::repeat_n(0u8, elem_size));
            }
        }

        buffers.insert(dst_handle, output);
    }

    /// Execute squeeze_dynamic operation.
    ///
    /// Removes dimensions of size 1 at runtime-specified axes.
    /// Args: [dst_handle, data_handle, axes_handle]
    fn exec_squeeze_dynamic(
        &mut self,
        args: &[Register],
        buffers: &mut FxHashMap<u64, Vec<u8>>,
        shape_registry: Option<&FxHashMap<u64, Vec<usize>>>,
    ) {
        if args.len() < 3 {
            return;
        }

        let dst_handle = self.state.get_reg(args[0]);
        let data_handle = self.state.get_reg(args[1]);
        let axes_handle = self.state.get_reg(args[2]);

        // Get input data tensor
        let Some(data_buf) = buffers.get(&data_handle).cloned() else {
            return;
        };

        // Get axes tensor
        let Some(axes_buf) = buffers.get(&axes_handle) else {
            return;
        };

        // Extract axes (i64 or i32)
        let axes: Vec<i64> = if axes_buf.len() % 8 == 0 {
            axes_buf
                .chunks_exact(8)
                .filter_map(|chunk| chunk.try_into().ok())
                .map(|bytes: [u8; 8]| i64::from_le_bytes(bytes))
                .collect()
        } else if axes_buf.len() % 4 == 0 {
            axes_buf
                .chunks_exact(4)
                .filter_map(|chunk| chunk.try_into().ok())
                .map(|bytes: [u8; 4]| i32::from_le_bytes(bytes) as i64)
                .collect()
        } else {
            Vec::new() // Empty axes means squeeze all size-1 dims
        };

        // Get input shape from shape_registry
        let input_shape: Vec<usize> = shape_registry
            .and_then(|reg| reg.get(&data_handle).cloned())
            .unwrap_or_else(|| vec![data_buf.len() / 4]);

        let rank = input_shape.len();

        // Normalize axes
        let norm_axes: Vec<usize> = if axes.is_empty() {
            // Squeeze all dimensions of size 1
            input_shape
                .iter()
                .enumerate()
                .filter(|(_, &s)| s == 1)
                .map(|(i, _)| i)
                .collect()
        } else {
            axes.iter()
                .map(|&a| {
                    if a < 0 {
                        (rank as i64 + a) as usize
                    } else {
                        a as usize
                    }
                })
                .filter(|&a| a < rank)
                .collect()
        };

        // Validate that all squeezed dimensions have size 1
        for &axis in &norm_axes {
            if axis < input_shape.len() && input_shape[axis] != 1 {
                // Cannot squeeze dimension that is not size 1
                // Just copy data unchanged
                buffers.insert(dst_handle, data_buf);
                return;
            }
        }

        // Squeeze is a view operation - data doesn't change, only shape
        // Just copy the data buffer to output
        buffers.insert(dst_handle, data_buf);
    }

    /// Execute unsqueeze_dynamic operation.
    ///
    /// Adds dimensions of size 1 at runtime-specified axes.
    /// Args: [dst_handle, data_handle, axes_handle]
    fn exec_unsqueeze_dynamic(
        &mut self,
        args: &[Register],
        buffers: &mut FxHashMap<u64, Vec<u8>>,
        _shape_registry: Option<&FxHashMap<u64, Vec<usize>>>,
    ) {
        if args.len() < 3 {
            return;
        }

        let dst_handle = self.state.get_reg(args[0]);
        let data_handle = self.state.get_reg(args[1]);

        // Get input data tensor
        let Some(data_buf) = buffers.get(&data_handle).cloned() else {
            return;
        };

        // Unsqueeze is a view operation - data doesn't change, only shape
        // Just copy the data buffer to output
        buffers.insert(dst_handle, data_buf);
    }

    /// Execute trilu (triangular) operation.
    ///
    /// Returns the upper or lower triangular part of 2-D matrices or batches.
    /// Elements outside the triangle are set to zero.
    fn exec_trilu(
        &mut self,
        args: &[Register],
        buffers: &mut FxHashMap<u64, Vec<u8>>,
        shape_registry: Option<&FxHashMap<u64, Vec<usize>>>,
    ) {
        // Args: [dst_handle, data_handle, k_handle, upper_flag]
        if args.len() < 4 {
            return;
        }

        let dst_handle = self.state.get_reg(args[0]);
        let data_handle = self.state.get_reg(args[1]);
        let k_handle = self.state.get_reg(args[2]);
        let upper = self.state.get_reg(args[3]) != 0;

        // Get input data tensor
        let Some(data_buf) = buffers.get(&data_handle).cloned() else {
            return;
        };

        // Get k offset from k_handle buffer (if valid), default to 0
        let k_offset: i64 = if let Some(k_buf) = buffers.get(&k_handle) {
            if k_buf.len() == 8 {
                i64::from_le_bytes(k_buf[..8].try_into().unwrap_or([0; 8]))
            } else if k_buf.len() == 4 {
                i32::from_le_bytes(k_buf[..4].try_into().unwrap_or([0; 4])) as i64
            } else {
                0
            }
        } else {
            0
        };

        // Get shape from shape registry
        let shape = shape_registry.and_then(|sr| sr.get(&data_handle)).cloned();
        let shape = match shape {
            Some(s) if s.len() >= 2 => s,
            _ => {
                // Fallback: try to infer from data size assuming square matrix
                let elem_size = 4; // Assume f32
                let total_elements = data_buf.len() / elem_size;
                let n = (total_elements as f64).sqrt() as usize;
                if n * n == total_elements {
                    vec![n, n]
                } else {
                    // Can't determine shape, just copy data
                    buffers.insert(dst_handle, data_buf);
                    return;
                }
            }
        };

        let rank = shape.len();
        let n = shape[rank - 2]; // rows
        let m = shape[rank - 1]; // cols
        let batch_size: usize = shape.iter().take(rank - 2).product();
        let matrix_size = n * m;

        // Determine element size (assume f32 by default)
        let elem_size = if data_buf.len() == matrix_size * batch_size.max(1) * 4 {
            4 // f32
        } else if data_buf.len() == matrix_size * batch_size.max(1) * 8 {
            8 // f64 or i64
        } else {
            4 // default to f32
        };

        // Clone data and apply triangular mask
        let mut output = data_buf.clone();

        for batch_idx in 0..batch_size.max(1) {
            let offset = batch_idx * matrix_size * elem_size;
            for i in 0..n {
                for j in 0..m {
                    let idx = offset + (i * m + j) * elem_size;
                    let diagonal_offset = (j as i64) - (i as i64);

                    let should_zero = if upper {
                        // Upper triangle: zero below k-th diagonal
                        diagonal_offset < k_offset
                    } else {
                        // Lower triangle: zero above k-th diagonal
                        diagonal_offset > k_offset
                    };

                    if should_zero && idx + elem_size <= output.len() {
                        // Zero out this element
                        for byte in &mut output[idx..idx + elem_size] {
                            *byte = 0;
                        }
                    }
                }
            }
        }

        buffers.insert(dst_handle, output);
    }
}

/// Compute the number of elements in a Range for i64.
fn compute_range_length_i64(start: i64, limit: i64, delta: i64) -> usize {
    // Empty range: positive delta going backwards, or negative delta going forwards
    if (delta > 0 && start >= limit) || (delta < 0 && start <= limit) {
        return 0;
    }
    let diff = limit - start;
    let len = (diff.abs() + delta.abs() - 1) / delta.abs();
    len.max(0) as usize
}

/// Compute the number of elements in a Range for i32.
fn compute_range_length_i32(start: i32, limit: i32, delta: i32) -> usize {
    // Empty range: positive delta going backwards, or negative delta going forwards
    if (delta > 0 && start >= limit) || (delta < 0 && start <= limit) {
        return 0;
    }
    let diff = (limit as i64) - (start as i64);
    let delta64 = delta as i64;
    let len = (diff.abs() + delta64.abs() - 1) / delta64.abs();
    len.max(0) as usize
}

/// Compute the number of elements in a Range for f32.
fn compute_range_length_f32(start: f32, limit: f32, delta: f32) -> usize {
    // Empty range: positive delta going backwards, or negative delta going forwards
    if (delta > 0.0 && start >= limit) || (delta < 0.0 && start <= limit) {
        return 0;
    }
    ((limit - start) / delta).ceil().max(0.0) as usize
}

/// Load a value from bytes based on type.
fn load_value(bytes: &[u8], ty: Type) -> u64 {
    match ty.size_bytes() {
        1 => bytes[0] as u64,
        2 => u16::from_le_bytes([bytes[0], bytes[1]]) as u64,
        4 => u32::from_le_bytes([bytes[0], bytes[1], bytes[2], bytes[3]]) as u64,
        8 => u64::from_le_bytes([
            bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7],
        ]),
        _ => 0,
    }
}

/// Store a value to bytes based on type.
fn store_value(bytes: &mut [u8], value: u64, ty: Type) {
    match ty.size_bytes() {
        1 => bytes[0] = value as u8,
        2 => bytes[..2].copy_from_slice(&(value as u16).to_le_bytes()),
        4 => bytes[..4].copy_from_slice(&(value as u32).to_le_bytes()),
        8 => bytes[..8].copy_from_slice(&value.to_le_bytes()),
        _ => {}
    }
}

/// Read a float value from bytes based on type.
fn read_float(bytes: &[u8], ty: Type) -> f64 {
    match ty {
        Type::F32 => {
            if bytes.len() >= 4 {
                f32::from_le_bytes([bytes[0], bytes[1], bytes[2], bytes[3]]) as f64
            } else {
                0.0
            }
        }
        Type::F64 => {
            if bytes.len() >= 8 {
                f64::from_le_bytes([
                    bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7],
                ])
            } else {
                0.0
            }
        }
        _ => {
            // Integer types - convert to float
            load_value(bytes, ty) as f64
        }
    }
}

/// Write a float value to bytes based on type.
fn write_float(bytes: &mut [u8], value: f64, ty: Type) {
    match ty {
        Type::F32 => {
            if bytes.len() >= 4 {
                bytes[..4].copy_from_slice(&(value as f32).to_le_bytes());
            }
        }
        Type::F64 => {
            if bytes.len() >= 8 {
                bytes[..8].copy_from_slice(&value.to_le_bytes());
            }
        }
        _ => {
            // Integer types
            store_value(bytes, value as u64, ty);
        }
    }
}

/// Compute multiplicative inverse in Z/256Z (unit group).
/// Only defined for odd numbers (units). Returns 0 for non-units.
fn mult_inverse_mod256(a: u8) -> u8 {
    // Only odd numbers are units in Z/256Z
    if a.is_multiple_of(2) {
        return 0;
    }
    // Use extended Euclidean algorithm
    // For Z/256Z, we can use the fact that a * a^(-1) ≡ 1 (mod 256)
    // Compute via iterative method: inverse = a * (2 - a * inverse)
    let mut inv = a; // Initial guess
    for _ in 0..7 {
        inv = inv.wrapping_mul(2u8.wrapping_sub(a.wrapping_mul(inv)));
    }
    inv
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_isa::{Instruction, Program, Register, Type};

    #[test]
    fn test_execution_state_new() {
        let state = ExecutionState::new();
        assert_eq!(state.pc, 0);
        assert!(state.running);
    }

    #[test]
    fn test_register_operations() {
        let mut state = ExecutionState::new();
        state.set_reg(Register::R0, 42);
        assert_eq!(state.get_reg(Register::R0), 42);

        state.set_float(Register::R1, 3.5);
        assert!((state.get_float(Register::R1) - 3.5).abs() < 1e-10);
    }

    #[test]
    fn test_interpreter_empty_program() {
        let mut interpreter = Interpreter::new();
        let program = Program::default();
        let mut buffers = FxHashMap::default();
        assert!(interpreter.execute(&program, &mut buffers).is_ok());
    }

    #[test]
    fn test_interpreter_mov_imm() {
        let mut interpreter = Interpreter::new();
        let mut program = Program::new();
        program.push(Instruction::MovImm {
            ty: Type::I64,
            dst: Register::R0,
            value: 100,
        });
        program.push(Instruction::Exit);

        let mut buffers = FxHashMap::default();
        interpreter.execute(&program, &mut buffers).unwrap();
        assert_eq!(interpreter.state.get_reg(Register::R0), 100);
    }

    #[test]
    fn interpreter_uses_passed_lookup_tables() {
        const fn custom_table() -> hologram_lookup::AlignedPackedTable {
            let mut table = hologram_lookup::AlignedPackedTable::new();
            let mut i = 0;
            while i < 256 {
                table.cells[i] = PackedCell::new(2, i as u8);
                i += 1;
            }
            table
        }
        static CUSTOM_TABLE: hologram_lookup::AlignedPackedTable = custom_table();

        let mut program = Program::new();
        program.push(Instruction::MovImm {
            ty: Type::U8,
            dst: Register::R0,
            value: 3,
        });
        program.push(Instruction::TorusMap {
            byte: Register::R0,
            dst: Register::R1,
        });
        program.push(Instruction::Exit);

        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        let tables = crate::plan::LookupTables {
            packed_table: &CUSTOM_TABLE,
            byte_meta_table: &hologram_common::categorical::BYTE_META_TABLE,
            activation_tables: crate::plan::ActivationTables::default(),
        };
        interpreter
            .execute_with_tables(&program, &mut buffers, None, &tables)
            .unwrap();

        let encoded = interpreter.state.get_reg(Register::R1);
        assert_eq!(encoded >> 8, 2);
        assert_eq!(encoded & 0xFF, 3);
    }

    #[test]
    fn test_interpreter_add() {
        let mut interpreter = Interpreter::new();
        let mut program = Program::new();
        program.push(Instruction::MovImm {
            ty: Type::I64,
            dst: Register::R0,
            value: 10,
        });
        program.push(Instruction::MovImm {
            ty: Type::I64,
            dst: Register::R1,
            value: 20,
        });
        program.push(Instruction::Add {
            ty: Type::I64,
            dst: Register::R2,
            lhs: Register::R0,
            rhs: Register::R1,
        });
        program.push(Instruction::Exit);

        let mut buffers = FxHashMap::default();
        interpreter.execute(&program, &mut buffers).unwrap();
        assert_eq!(interpreter.state.get_reg(Register::R2), 30);
    }

    #[test]
    fn test_interpreter_loop() {
        let mut interpreter = Interpreter::new();
        let mut program = Program::new();

        // Initialize counter to 2 (do-while: n-1 for n iterations, so 3 iterations)
        program.push(Instruction::MovImm {
            ty: Type::U32,
            dst: Register::R0,
            value: 2,
        });
        // Initialize accumulator
        program.push(Instruction::MovImm {
            ty: Type::I64,
            dst: Register::R1,
            value: 0,
        });
        // Loop label
        program.push(Instruction::Label {
            name: "loop".to_string(),
        });
        // Increment by 1
        program.push(Instruction::MovImm {
            ty: Type::I64,
            dst: Register::R2,
            value: 1,
        });
        program.push(Instruction::Add {
            ty: Type::I64,
            dst: Register::R1,
            lhs: Register::R1,
            rhs: Register::R2,
        });
        // Loop back
        program.push(Instruction::Loop {
            counter: Register::R0,
            label: "loop".to_string(),
        });
        program.push(Instruction::Exit);

        let mut buffers = FxHashMap::default();
        interpreter.execute(&program, &mut buffers).unwrap();
        // Loop runs 3 times: once initially, plus 2 more via counter
        assert_eq!(interpreter.state.get_reg(Register::R1), 3);
    }

    #[test]
    fn test_interpreter_bitwise() {
        let mut interpreter = Interpreter::new();
        let mut program = Program::new();
        program.push(Instruction::MovImm {
            ty: Type::U64,
            dst: Register::R0,
            value: 0b1010,
        });
        program.push(Instruction::MovImm {
            ty: Type::U64,
            dst: Register::R1,
            value: 0b1100,
        });
        program.push(Instruction::BitAnd {
            ty: Type::U64,
            dst: Register::R2,
            lhs: Register::R0,
            rhs: Register::R1,
        });
        program.push(Instruction::BitOr {
            ty: Type::U64,
            dst: Register::R3,
            lhs: Register::R0,
            rhs: Register::R1,
        });
        program.push(Instruction::Exit);

        let mut buffers = FxHashMap::default();
        interpreter.execute(&program, &mut buffers).unwrap();
        assert_eq!(interpreter.state.get_reg(Register::R2), 0b1000); // AND
        assert_eq!(interpreter.state.get_reg(Register::R3), 0b1110); // OR
    }
}
