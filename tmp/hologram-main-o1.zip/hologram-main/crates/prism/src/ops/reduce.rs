//! Reduction operations: `xor_reduce`, `sum`, `max`, `min`.
//!
//! Portable implementations that fold across all 624 bytes of a state.
//!
//! ```
//! use prism::state::State;
//! use prism::ops::reduce;
//!
//! let s = State::zeros();
//! assert_eq!(reduce::sum(&s), 0);
//! assert_eq!(reduce::xor_reduce(&s), 0);
//! ```

use crate::state::State;

/// XOR-fold all 624 bytes into a single byte.
///
/// ```
/// use prism::state::State;
/// use prism::ops::reduce::xor_reduce;
///
/// assert_eq!(xor_reduce(&State::zeros()), 0);
/// assert_eq!(xor_reduce(&State::from_bytes(&[0xFF])), 0xFF);
/// ```
#[inline]
#[must_use]
pub fn xor_reduce(state: &State) -> u8 {
    state.as_bytes().iter().fold(0u8, |acc, &b| acc ^ b)
}

/// Sum all 624 bytes as a `u64`.
///
/// ```
/// use prism::state::State;
/// use prism::ops::reduce::sum;
///
/// assert_eq!(sum(&State::zeros()), 0);
/// assert_eq!(sum(&State::ones()), 624 * 255);
/// ```
#[inline]
#[must_use]
pub fn sum(state: &State) -> u64 {
    state.as_bytes().iter().map(|&b| u64::from(b)).sum()
}

/// Maximum byte value in the state.
///
/// ```
/// use prism::state::State;
/// use prism::ops::reduce::max;
///
/// assert_eq!(max(&State::zeros()), 0);
/// assert_eq!(max(&State::ones()), 255);
/// ```
#[inline]
#[must_use]
pub fn max(state: &State) -> u8 {
    state.as_bytes().iter().copied().max().unwrap_or(0)
}

/// Minimum byte value in the state.
///
/// ```
/// use prism::state::State;
/// use prism::ops::reduce::min;
///
/// assert_eq!(min(&State::zeros()), 0);
/// assert_eq!(min(&State::ones()), 255);
/// ```
#[inline]
#[must_use]
pub fn min(state: &State) -> u8 {
    state.as_bytes().iter().copied().min().unwrap_or(0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_xor_reduce_zeros() {
        assert_eq!(xor_reduce(&State::zeros()), 0);
    }

    #[test]
    fn test_xor_reduce_ones() {
        // 624 bytes of 0xFF; XOR of even count of identical values = 0
        assert_eq!(xor_reduce(&State::ones()), 0);
    }

    #[test]
    fn test_xor_reduce_known() {
        let mut s = State::zeros();
        s.as_bytes_mut()[0] = 0xAB;
        s.as_bytes_mut()[1] = 0xCD;
        assert_eq!(xor_reduce(&s), 0xAB ^ 0xCD);
    }

    #[test]
    fn test_sum_zeros() {
        assert_eq!(sum(&State::zeros()), 0);
    }

    #[test]
    fn test_sum_ones() {
        assert_eq!(sum(&State::ones()), 624 * 255);
    }

    #[test]
    fn test_sum_known() {
        let s = State::from_bytes(&[10, 20, 30]);
        assert_eq!(sum(&s), 60);
    }

    #[test]
    fn test_max_zeros() {
        assert_eq!(max(&State::zeros()), 0);
    }

    #[test]
    fn test_max_ones() {
        assert_eq!(max(&State::ones()), 255);
    }

    #[test]
    fn test_max_known() {
        let mut s = State::zeros();
        s.as_bytes_mut()[100] = 42;
        assert_eq!(max(&s), 42);
    }

    #[test]
    fn test_min_zeros() {
        assert_eq!(min(&State::zeros()), 0);
    }

    #[test]
    fn test_min_ones() {
        assert_eq!(min(&State::ones()), 255);
    }

    #[test]
    fn test_min_known() {
        let mut s = State::ones();
        s.as_bytes_mut()[200] = 7;
        assert_eq!(min(&s), 7);
    }
}
