/**
 * your-space module — barrel export
 * ══════════════════════════════════
 *
 * The "My Space" experience: dashboard, identity journey, trust graph
 * visualization, and profile management UI.
 *
 * Depends on:
 *   - identity module (engine, types, hooks)
 *   - hologram-ui module (layout, sidebar)
 *   - use-auth hook (reactive auth state)
 *
 * @module your-space
 */

// ── Pages ───────────────────────────────────────────────────────────────────
export { default as YourSpaceDashboard } from "./pages/YourSpaceDashboard";
export { default as YourSpaceRouter } from "./pages/YourSpaceRouter";

// ── Components ──────────────────────────────────────────────────────────────
export { default as TrustGraph } from "./components/TrustGraph";
export { default as IdentityJourney } from "./components/IdentityJourney";
export { default as CoverImage } from "./components/CoverImage";
export { default as AvatarUpload } from "./components/AvatarUpload";
export { default as EditProfileDialog } from "./components/EditProfileDialog";
