//! Large graph regression tests (Bug: 100+ buffer graphs produce zero output).
//!
//! These tests verify that computation graphs with many buffers execute correctly.
//! The bug was discovered with ResNet-like architectures where residual blocks
//! create graphs with 100+ buffers.

use hologram_backend::backends::cpu::CpuBackend;
use hologram_backend::backends::Backend;
use hologram_compiler::{
    compile, CompilerConfig, ConstantData, DType, OpKind, OpNode, OperationGraph,
};

/// Helper to convert f32 slice to byte buffer.
fn f32_to_bytes(data: &[f32]) -> Vec<u8> {
    data.iter().flat_map(|f| f.to_ne_bytes()).collect()
}

/// Test: Single residual block should produce non-zero output.
/// This is the baseline test that should pass.
#[test]
fn test_single_residual_block_produces_nonzero_output() {
    let mut graph = OperationGraph::new();
    let mut node_id = 0u32;
    let mut next_id = || {
        let id = node_id;
        node_id += 1;
        id
    };

    let channels = 4usize;
    let spatial = 4usize;

    // Input: [1, 4, 4, 4]
    let input_id = next_id();
    graph.add_node(OpNode::new(
        input_id,
        OpKind::Input,
        vec![1, channels, spatial, spatial],
        DType::F32,
    ));
    graph.add_input("input", input_id);

    // Conv weight: [4, 4, 3, 3]
    let conv_weight_id = next_id();
    graph.add_node(OpNode::new(
        conv_weight_id,
        OpKind::Constant,
        vec![channels, channels, 3, 3],
        DType::F32,
    ));
    graph.add_constant_for_node(
        conv_weight_id,
        ConstantData::F32(vec![0.01; channels * channels * 9]),
    );

    // Conv output: [1, 4, 4, 4] (padding=1 preserves spatial)
    let conv_out_id = next_id();
    graph.add_node(OpNode::new(
        conv_out_id,
        OpKind::Conv2d {
            kernel: (3, 3),
            stride: (1, 1),
            padding: (1, 1),
            dilation: (1, 1),
            groups: 1,
        },
        vec![1, channels, spatial, spatial],
        DType::F32,
    ));
    graph.add_edge(input_id, conv_out_id);
    graph.add_edge(conv_weight_id, conv_out_id);

    // BatchNorm parameters
    let bn_scale_id = next_id();
    let bn_bias_id = next_id();
    let bn_mean_id = next_id();
    let bn_var_id = next_id();
    graph.add_node(OpNode::new(
        bn_scale_id,
        OpKind::Constant,
        vec![channels],
        DType::F32,
    ));
    graph.add_node(OpNode::new(
        bn_bias_id,
        OpKind::Constant,
        vec![channels],
        DType::F32,
    ));
    graph.add_node(OpNode::new(
        bn_mean_id,
        OpKind::Constant,
        vec![channels],
        DType::F32,
    ));
    graph.add_node(OpNode::new(
        bn_var_id,
        OpKind::Constant,
        vec![channels],
        DType::F32,
    ));
    graph.add_constant_for_node(bn_scale_id, ConstantData::F32(vec![1.0; channels])); // scale
    graph.add_constant_for_node(bn_bias_id, ConstantData::F32(vec![0.0; channels])); // bias
    graph.add_constant_for_node(bn_mean_id, ConstantData::F32(vec![0.0; channels])); // mean
    graph.add_constant_for_node(bn_var_id, ConstantData::F32(vec![1.0; channels])); // var

    // BatchNorm output
    let bn_out_id = next_id();
    graph.add_node(OpNode::new(
        bn_out_id,
        OpKind::BatchNormalization { epsilon: 1e-5 },
        vec![1, channels, spatial, spatial],
        DType::F32,
    ));
    graph.add_edge(conv_out_id, bn_out_id);
    graph.add_edge(bn_scale_id, bn_out_id);
    graph.add_edge(bn_bias_id, bn_out_id);
    graph.add_edge(bn_mean_id, bn_out_id);
    graph.add_edge(bn_var_id, bn_out_id);

    // ReLU
    let relu_id = next_id();
    graph.add_node(OpNode::new(
        relu_id,
        OpKind::Relu,
        vec![1, channels, spatial, spatial],
        DType::F32,
    ));
    graph.add_edge(bn_out_id, relu_id);

    // Add (residual connection)
    let add_id = next_id();
    graph.add_node(OpNode::new(
        add_id,
        OpKind::Add,
        vec![1, channels, spatial, spatial],
        DType::F32,
    ));
    graph.add_edge(input_id, add_id); // skip connection
    graph.add_edge(relu_id, add_id);

    // Output
    let output_id = next_id();
    graph.add_node(OpNode::new(
        output_id,
        OpKind::Output,
        vec![1, channels, spatial, spatial],
        DType::F32,
    ));
    graph.add_edge(add_id, output_id);
    graph.add_output("output", output_id);

    // Compile
    let plan = compile(&graph, &CompilerConfig::default()).expect("compilation failed");

    eprintln!("Single block stats:");
    eprintln!("  Buffers: {}", plan.buffers.len());
    eprintln!("  Instructions: {}", plan.instructions.len());
    eprintln!("  Constants: {} bytes", plan.constants.len());

    // Execute
    let input_size = channels * spatial * spatial;
    let input_data: Vec<f32> = vec![1.0; input_size];
    let input_bytes = f32_to_bytes(&input_data);

    let output_size = channels * spatial * spatial;
    let mut output_data: Vec<f32> = vec![0.0; output_size];
    let output_bytes: &mut [u8] = bytemuck::cast_slice_mut(&mut output_data);

    let backend = CpuBackend::new();
    backend
        .execute_plan(&plan, &[&input_bytes], &mut [output_bytes])
        .expect("execution failed");

    // Check output
    let non_zero = output_data.iter().filter(|&&x| x.abs() > 1e-10).count();
    eprintln!("Output: {}/{} non-zero", non_zero, output_data.len());
    eprintln!("First 5: {:?}", &output_data[..5.min(output_data.len())]);

    assert!(non_zero > 0, "Single residual block produces all zeros");
}

/// Test: Large CNN graph with 8 residual blocks (BUG REPRODUCTION).
/// Each block: Conv -> BN -> ReLU -> Conv -> BN -> Add -> ReLU
/// This test creates ~175 buffers.
#[test]
fn test_large_cnn_graph_produces_nonzero_output() {
    let mut graph = OperationGraph::new();
    let mut node_id = 0u32;
    let mut next_id = || {
        let id = node_id;
        node_id += 1;
        id
    };

    // Use smaller dimensions for faster test, but enough to exercise the bug
    let channels = 16usize;
    let spatial = 8usize;
    let num_blocks = 8;

    // Input: [1, 16, 8, 8]
    let input_id = next_id();
    graph.add_node(OpNode::new(
        input_id,
        OpKind::Input,
        vec![1, channels, spatial, spatial],
        DType::F32,
    ));
    graph.add_input("input", input_id);

    let mut prev_output = input_id;

    // Create 8 residual blocks
    for _block in 0..num_blocks {
        // === Conv 1 ===
        let conv1_weight_id = next_id();
        graph.add_node(OpNode::new(
            conv1_weight_id,
            OpKind::Constant,
            vec![channels, channels, 3, 3],
            DType::F32,
        ));
        graph.add_constant_for_node(
            conv1_weight_id,
            ConstantData::F32(vec![0.01; channels * channels * 9]),
        );

        let conv1_out_id = next_id();
        graph.add_node(OpNode::new(
            conv1_out_id,
            OpKind::Conv2d {
                kernel: (3, 3),
                stride: (1, 1),
                padding: (1, 1),
                dilation: (1, 1),
                groups: 1,
            },
            vec![1, channels, spatial, spatial],
            DType::F32,
        ));
        graph.add_edge(prev_output, conv1_out_id);
        graph.add_edge(conv1_weight_id, conv1_out_id);

        // === BatchNorm 1 ===
        let bn1_scale_id = next_id();
        let bn1_bias_id = next_id();
        let bn1_mean_id = next_id();
        let bn1_var_id = next_id();
        graph.add_node(OpNode::new(
            bn1_scale_id,
            OpKind::Constant,
            vec![channels],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            bn1_bias_id,
            OpKind::Constant,
            vec![channels],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            bn1_mean_id,
            OpKind::Constant,
            vec![channels],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            bn1_var_id,
            OpKind::Constant,
            vec![channels],
            DType::F32,
        ));
        graph.add_constant_for_node(bn1_scale_id, ConstantData::F32(vec![1.0; channels])); // scale
        graph.add_constant_for_node(bn1_bias_id, ConstantData::F32(vec![0.0; channels])); // bias
        graph.add_constant_for_node(bn1_mean_id, ConstantData::F32(vec![0.0; channels])); // mean
        graph.add_constant_for_node(bn1_var_id, ConstantData::F32(vec![1.0; channels])); // var

        let bn1_out_id = next_id();
        graph.add_node(OpNode::new(
            bn1_out_id,
            OpKind::BatchNormalization { epsilon: 1e-5 },
            vec![1, channels, spatial, spatial],
            DType::F32,
        ));
        graph.add_edge(conv1_out_id, bn1_out_id);
        graph.add_edge(bn1_scale_id, bn1_out_id);
        graph.add_edge(bn1_bias_id, bn1_out_id);
        graph.add_edge(bn1_mean_id, bn1_out_id);
        graph.add_edge(bn1_var_id, bn1_out_id);

        // === ReLU 1 ===
        let relu1_id = next_id();
        graph.add_node(OpNode::new(
            relu1_id,
            OpKind::Relu,
            vec![1, channels, spatial, spatial],
            DType::F32,
        ));
        graph.add_edge(bn1_out_id, relu1_id);

        // === Conv 2 ===
        let conv2_weight_id = next_id();
        graph.add_node(OpNode::new(
            conv2_weight_id,
            OpKind::Constant,
            vec![channels, channels, 3, 3],
            DType::F32,
        ));
        graph.add_constant_for_node(
            conv2_weight_id,
            ConstantData::F32(vec![0.01; channels * channels * 9]),
        );

        let conv2_out_id = next_id();
        graph.add_node(OpNode::new(
            conv2_out_id,
            OpKind::Conv2d {
                kernel: (3, 3),
                stride: (1, 1),
                padding: (1, 1),
                dilation: (1, 1),
                groups: 1,
            },
            vec![1, channels, spatial, spatial],
            DType::F32,
        ));
        graph.add_edge(relu1_id, conv2_out_id);
        graph.add_edge(conv2_weight_id, conv2_out_id);

        // === BatchNorm 2 ===
        let bn2_scale_id = next_id();
        let bn2_bias_id = next_id();
        let bn2_mean_id = next_id();
        let bn2_var_id = next_id();
        graph.add_node(OpNode::new(
            bn2_scale_id,
            OpKind::Constant,
            vec![channels],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            bn2_bias_id,
            OpKind::Constant,
            vec![channels],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            bn2_mean_id,
            OpKind::Constant,
            vec![channels],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            bn2_var_id,
            OpKind::Constant,
            vec![channels],
            DType::F32,
        ));
        graph.add_constant_for_node(bn2_scale_id, ConstantData::F32(vec![1.0; channels]));
        graph.add_constant_for_node(bn2_bias_id, ConstantData::F32(vec![0.0; channels]));
        graph.add_constant_for_node(bn2_mean_id, ConstantData::F32(vec![0.0; channels]));
        graph.add_constant_for_node(bn2_var_id, ConstantData::F32(vec![1.0; channels]));

        let bn2_out_id = next_id();
        graph.add_node(OpNode::new(
            bn2_out_id,
            OpKind::BatchNormalization { epsilon: 1e-5 },
            vec![1, channels, spatial, spatial],
            DType::F32,
        ));
        graph.add_edge(conv2_out_id, bn2_out_id);
        graph.add_edge(bn2_scale_id, bn2_out_id);
        graph.add_edge(bn2_bias_id, bn2_out_id);
        graph.add_edge(bn2_mean_id, bn2_out_id);
        graph.add_edge(bn2_var_id, bn2_out_id);

        // === Add (residual) ===
        let add_id = next_id();
        graph.add_node(OpNode::new(
            add_id,
            OpKind::Add,
            vec![1, channels, spatial, spatial],
            DType::F32,
        ));
        graph.add_edge(prev_output, add_id); // skip connection
        graph.add_edge(bn2_out_id, add_id);

        // === ReLU 2 ===
        let relu2_id = next_id();
        graph.add_node(OpNode::new(
            relu2_id,
            OpKind::Relu,
            vec![1, channels, spatial, spatial],
            DType::F32,
        ));
        graph.add_edge(add_id, relu2_id);

        prev_output = relu2_id;
    }

    // === GlobalAveragePool ===
    let gap_id = next_id();
    graph.add_node(OpNode::new(
        gap_id,
        OpKind::GlobalAveragePool,
        vec![1, channels, 1, 1],
        DType::F32,
    ));
    graph.add_edge(prev_output, gap_id);

    // === Flatten ===
    let flatten_id = next_id();
    graph.add_node(OpNode::new(
        flatten_id,
        OpKind::Flatten { start_dim: 1 },
        vec![1, channels],
        DType::F32,
    ));
    graph.add_edge(gap_id, flatten_id);

    // === Output ===
    let output_id = next_id();
    graph.add_node(OpNode::new(
        output_id,
        OpKind::Output,
        vec![1, channels],
        DType::F32,
    ));
    graph.add_edge(flatten_id, output_id);
    graph.add_output("output", output_id);

    // Compile
    let plan = compile(&graph, &CompilerConfig::default()).expect("compilation failed");

    eprintln!("Large graph stats:");
    eprintln!("  Nodes: {}", node_id);
    eprintln!("  Buffers: {}", plan.buffers.len());
    eprintln!("  Instructions: {}", plan.instructions.len());
    eprintln!("  Constants: {} bytes", plan.constants.len());

    // Verify we have a large graph
    assert!(
        plan.buffers.len() > 100,
        "Expected 100+ buffers, got {}",
        plan.buffers.len()
    );

    // Execute
    let input_size = channels * spatial * spatial;
    let input_data: Vec<f32> = vec![1.0; input_size];
    let input_bytes = f32_to_bytes(&input_data);

    let mut output_data: Vec<f32> = vec![0.0; channels];
    let output_bytes: &mut [u8] = bytemuck::cast_slice_mut(&mut output_data);

    let backend = CpuBackend::new();
    backend
        .execute_plan(&plan, &[&input_bytes], &mut [output_bytes])
        .expect("execution failed");

    // Check output
    let non_zero = output_data.iter().filter(|&&x| x.abs() > 1e-10).count();
    eprintln!("Output: {}/{} non-zero", non_zero, output_data.len());
    eprintln!("First 5: {:?}", &output_data[..5.min(output_data.len())]);

    // This assertion FAILS for large graphs - BUG!
    assert!(
        non_zero > 0,
        "Large graph produces all zeros - BUG! Check instruction emission and buffer registration."
    );
}

/// Test: Verify instruction count matches operation count.
/// This helps diagnose if instructions are being silently dropped.
#[test]
fn test_instruction_count_matches_operations() {
    let mut graph = OperationGraph::new();
    let mut node_id = 0u32;
    let mut next_id = || {
        let id = node_id;
        node_id += 1;
        id
    };

    let channels = 4usize;
    let spatial = 4usize;
    let num_blocks = 4;

    // Input
    let input_id = next_id();
    graph.add_node(OpNode::new(
        input_id,
        OpKind::Input,
        vec![1, channels, spatial, spatial],
        DType::F32,
    ));
    graph.add_input("input", input_id);

    let mut prev_output = input_id;

    // Track expected operations (non-Input, non-Constant)
    let mut expected_ops = 0;

    for _block in 0..num_blocks {
        // Conv weight (Constant - no instruction)
        let conv_weight_id = next_id();
        graph.add_node(OpNode::new(
            conv_weight_id,
            OpKind::Constant,
            vec![channels, channels, 3, 3],
            DType::F32,
        ));
        graph.add_constant_for_node(
            conv_weight_id,
            ConstantData::F32(vec![0.01; channels * channels * 9]),
        );

        // Conv (emits instruction)
        let conv_out_id = next_id();
        graph.add_node(OpNode::new(
            conv_out_id,
            OpKind::Conv2d {
                kernel: (3, 3),
                stride: (1, 1),
                padding: (1, 1),
                dilation: (1, 1),
                groups: 1,
            },
            vec![1, channels, spatial, spatial],
            DType::F32,
        ));
        graph.add_edge(prev_output, conv_out_id);
        graph.add_edge(conv_weight_id, conv_out_id);
        expected_ops += 1;

        // ReLU (emits instruction)
        let relu_id = next_id();
        graph.add_node(OpNode::new(
            relu_id,
            OpKind::Relu,
            vec![1, channels, spatial, spatial],
            DType::F32,
        ));
        graph.add_edge(conv_out_id, relu_id);
        expected_ops += 1;

        // Add (emits instruction)
        let add_id = next_id();
        graph.add_node(OpNode::new(
            add_id,
            OpKind::Add,
            vec![1, channels, spatial, spatial],
            DType::F32,
        ));
        graph.add_edge(prev_output, add_id);
        graph.add_edge(relu_id, add_id);
        expected_ops += 1;

        prev_output = add_id;
    }

    // Output (emits Copy instruction)
    let output_id = next_id();
    graph.add_node(OpNode::new(
        output_id,
        OpKind::Output,
        vec![1, channels, spatial, spatial],
        DType::F32,
    ));
    graph.add_edge(prev_output, output_id);
    graph.add_output("output", output_id);
    expected_ops += 1;

    // Compile
    let plan = compile(&graph, &CompilerConfig::default()).expect("compilation failed");

    eprintln!("Instruction count test:");
    eprintln!("  Expected ops: {}", expected_ops);
    eprintln!("  Actual instructions: {}", plan.instructions.len());

    // Verify instruction count
    assert_eq!(
        plan.instructions.len(),
        expected_ops,
        "Instruction count mismatch: expected {}, got {}. Instructions are being dropped!",
        expected_ops,
        plan.instructions.len()
    );
}

/// Test: Deep chain without skip connections.
/// This isolates the issue from residual connections.
#[test]
fn test_deep_chain_produces_nonzero_output() {
    let mut graph = OperationGraph::new();
    let mut node_id = 0u32;
    let mut next_id = || {
        let id = node_id;
        node_id += 1;
        id
    };

    let size = 64usize;
    let num_ops = 50;

    // Input
    let input_id = next_id();
    graph.add_node(OpNode::new(input_id, OpKind::Input, vec![size], DType::F32));
    graph.add_input("input", input_id);

    let mut prev_output = input_id;

    // Create a chain of Relu -> Sigmoid -> Relu -> Sigmoid -> ...
    for i in 0..num_ops {
        let op = if i % 2 == 0 {
            OpKind::Relu
        } else {
            OpKind::Sigmoid
        };
        let op_id = next_id();
        graph.add_node(OpNode::new(op_id, op, vec![size], DType::F32));
        graph.add_edge(prev_output, op_id);
        prev_output = op_id;
    }

    // Output
    let output_id = next_id();
    graph.add_node(OpNode::new(
        output_id,
        OpKind::Output,
        vec![size],
        DType::F32,
    ));
    graph.add_edge(prev_output, output_id);
    graph.add_output("output", output_id);

    // Compile
    let plan = compile(&graph, &CompilerConfig::default()).expect("compilation failed");

    eprintln!("Deep chain stats:");
    eprintln!("  Buffers: {}", plan.buffers.len());
    eprintln!("  Instructions: {}", plan.instructions.len());

    // Execute
    let input_data: Vec<f32> = (0..size).map(|i| (i as f32) * 0.1 - 3.0).collect();
    let input_bytes = f32_to_bytes(&input_data);

    let mut output_data: Vec<f32> = vec![0.0; size];
    let output_bytes: &mut [u8] = bytemuck::cast_slice_mut(&mut output_data);

    let backend = CpuBackend::new();
    backend
        .execute_plan(&plan, &[&input_bytes], &mut [output_bytes])
        .expect("execution failed");

    // Check output
    let non_zero = output_data.iter().filter(|&&x| x.abs() > 1e-10).count();
    eprintln!("Output: {}/{} non-zero", non_zero, output_data.len());

    assert!(non_zero > 0, "Deep chain produces all zeros");
}
