//! Cluster identity management using Ed25519 cryptography.

use crate::error::{OrchestrateError, Result};
use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use rand::rngs::OsRng;
use serde::{Deserialize, Serialize};
use std::fs;
use std::path::Path;
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use zeroize::Zeroizing;

/// Cluster identity containing Ed25519 keypair for signing operations.
#[derive(Debug)]
pub struct ClusterIdentity {
    signing_key: SigningKey,
    verifying_key: VerifyingKey,
    created_at: SystemTime,
    rotation_interval: Duration,
    previous_verifying_key: Option<VerifyingKey>,
    previous_key_expires: Option<SystemTime>,
}

#[derive(Serialize, Deserialize)]
struct StoredIdentity {
    secret_key: Vec<u8>,
    created_at_secs: u64,
    rotation_interval_secs: u64,
    previous_public_key: Option<Vec<u8>>,
    previous_key_expires_secs: Option<u64>,
}

impl ClusterIdentity {
    /// Generate a new cluster identity with a fresh Ed25519 keypair.
    #[must_use]
    pub fn generate(rotation_interval: Duration) -> Self {
        let signing_key = SigningKey::generate(&mut OsRng);
        let verifying_key = signing_key.verifying_key();

        Self {
            signing_key,
            verifying_key,
            created_at: SystemTime::now(),
            rotation_interval,
            previous_verifying_key: None,
            previous_key_expires: None,
        }
    }

    /// Load cluster identity from a file.
    pub fn load(path: impl AsRef<Path>) -> Result<Self> {
        let path = path.as_ref();
        let content = fs::read(path)?;
        let content = Zeroizing::new(content);

        let stored: StoredIdentity = serde_json::from_slice(&content)
            .map_err(|e| OrchestrateError::serialization(e.to_string()))?;

        let secret_bytes: [u8; 32] = stored
            .secret_key
            .try_into()
            .map_err(|_| OrchestrateError::security("invalid secret key length"))?;

        let signing_key = SigningKey::from_bytes(&secret_bytes);
        let verifying_key = signing_key.verifying_key();
        let created_at = UNIX_EPOCH + Duration::from_secs(stored.created_at_secs);
        let rotation_interval = Duration::from_secs(stored.rotation_interval_secs);

        let previous_verifying_key = stored
            .previous_public_key
            .map(|bytes| {
                let key_bytes: [u8; 32] = bytes.try_into().map_err(|_| {
                    OrchestrateError::security("invalid previous public key length")
                })?;
                VerifyingKey::from_bytes(&key_bytes).map_err(|e| {
                    OrchestrateError::security(format!("invalid previous public key: {e}"))
                })
            })
            .transpose()?;

        let previous_key_expires = stored
            .previous_key_expires_secs
            .map(|secs| UNIX_EPOCH + Duration::from_secs(secs));

        Ok(Self {
            signing_key,
            verifying_key,
            created_at,
            rotation_interval,
            previous_verifying_key,
            previous_key_expires,
        })
    }

    /// Save cluster identity to a file.
    pub fn save(&self, path: impl AsRef<Path>) -> Result<()> {
        let path = path.as_ref();

        let created_at_secs = self
            .created_at
            .duration_since(UNIX_EPOCH)
            .map_err(|_| OrchestrateError::security("invalid creation timestamp"))?
            .as_secs();

        let previous_key_expires_secs = self
            .previous_key_expires
            .map(|t| {
                t.duration_since(UNIX_EPOCH)
                    .map(|d| d.as_secs())
                    .map_err(|_| OrchestrateError::security("invalid previous key expiration"))
            })
            .transpose()?;

        let stored = StoredIdentity {
            secret_key: self.signing_key.to_bytes().to_vec(),
            created_at_secs,
            rotation_interval_secs: self.rotation_interval.as_secs(),
            previous_public_key: self.previous_verifying_key.map(|k| k.to_bytes().to_vec()),
            previous_key_expires_secs,
        };

        let content = serde_json::to_vec_pretty(&stored)
            .map_err(|e| OrchestrateError::serialization(e.to_string()))?;

        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }

        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            let mut opts = fs::OpenOptions::new();
            opts.write(true).create(true).truncate(true).mode(0o600);
            let mut file = opts.open(path)?;
            std::io::Write::write_all(&mut file, &content)?;
        }

        #[cfg(not(unix))]
        {
            fs::write(path, &content)?;
        }

        Ok(())
    }

    /// Save the public key to a separate file (base64 encoded).
    pub fn save_public_key(&self, path: impl AsRef<Path>) -> Result<()> {
        use base64::Engine;

        let path = path.as_ref();
        let public_key_bytes = self.verifying_key.to_bytes();
        let encoded = base64::engine::general_purpose::STANDARD.encode(public_key_bytes);

        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }

        fs::write(path, encoded)?;
        Ok(())
    }

    /// Get the cluster ID (BLAKE3 hash of the public key).
    #[must_use]
    pub fn cluster_id(&self) -> [u8; 32] {
        *blake3::hash(&self.verifying_key.to_bytes()).as_bytes()
    }

    /// Get the cluster ID as a hex string.
    #[must_use]
    pub fn cluster_id_hex(&self) -> String {
        hex_encode(self.cluster_id())
    }

    /// Get the verifying (public) key.
    #[must_use]
    pub const fn verifying_key(&self) -> &VerifyingKey {
        &self.verifying_key
    }

    /// Get the key creation timestamp.
    #[must_use]
    pub const fn created_at(&self) -> SystemTime {
        self.created_at
    }

    /// Get the key age.
    #[must_use]
    pub fn key_age(&self) -> Duration {
        SystemTime::now()
            .duration_since(self.created_at)
            .unwrap_or(Duration::ZERO)
    }

    /// Check if key rotation is needed.
    #[must_use]
    pub fn needs_rotation(&self) -> bool {
        self.key_age() > self.rotation_interval
    }

    /// Get time until rotation is needed.
    #[must_use]
    pub fn time_until_rotation(&self) -> Option<Duration> {
        self.rotation_interval.checked_sub(self.key_age())
    }

    /// Rotate to a new keypair.
    pub fn rotate(&mut self, grace_period: Duration) {
        self.previous_verifying_key = Some(self.verifying_key);
        self.previous_key_expires = Some(SystemTime::now() + grace_period);
        self.signing_key = SigningKey::generate(&mut OsRng);
        self.verifying_key = self.signing_key.verifying_key();
        self.created_at = SystemTime::now();
    }

    /// Check if the previous key is still in grace period.
    #[must_use]
    pub fn has_previous_key(&self) -> bool {
        if let (Some(_), Some(expires)) = (&self.previous_verifying_key, self.previous_key_expires)
        {
            SystemTime::now() <= expires
        } else {
            false
        }
    }

    /// Sign arbitrary data.
    #[must_use]
    pub fn sign(&self, data: &[u8]) -> [u8; 64] {
        self.signing_key.sign(data).to_bytes()
    }

    /// Verify a signature.
    #[must_use]
    pub fn verify(&self, data: &[u8], signature: &[u8; 64]) -> bool {
        let sig = Signature::from_bytes(signature);

        if self.verifying_key.verify(data, &sig).is_ok() {
            return true;
        }

        if let (Some(prev_key), Some(expires)) =
            (&self.previous_verifying_key, self.previous_key_expires)
        {
            if SystemTime::now() <= expires {
                return prev_key.verify(data, &sig).is_ok();
            }
        }

        false
    }
}

impl Clone for ClusterIdentity {
    fn clone(&self) -> Self {
        Self {
            signing_key: SigningKey::from_bytes(&self.signing_key.to_bytes()),
            verifying_key: self.verifying_key,
            created_at: self.created_at,
            rotation_interval: self.rotation_interval,
            previous_verifying_key: self.previous_verifying_key,
            previous_key_expires: self.previous_key_expires,
        }
    }
}

/// Encode bytes as hexadecimal string.
fn hex_encode(data: [u8; 32]) -> String {
    const HEX_CHARS: &[u8; 16] = b"0123456789abcdef";
    let mut result = String::with_capacity(64);
    for byte in data {
        result.push(HEX_CHARS[(byte >> 4) as usize] as char);
        result.push(HEX_CHARS[(byte & 0x0f) as usize] as char);
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[test]
    fn test_generate_identity() {
        let identity = ClusterIdentity::generate(Duration::from_secs(86400));
        assert!(!identity.needs_rotation());
        assert!(identity.time_until_rotation().is_some());
    }

    #[test]
    fn test_cluster_id() {
        let identity = ClusterIdentity::generate(Duration::from_secs(86400));
        let id = identity.cluster_id();
        assert_eq!(id.len(), 32);

        let id2 = identity.cluster_id();
        assert_eq!(id, id2);

        let identity2 = ClusterIdentity::generate(Duration::from_secs(86400));
        let id3 = identity2.cluster_id();
        assert_ne!(id, id3);
    }

    #[test]
    fn test_cluster_id_hex() {
        let identity = ClusterIdentity::generate(Duration::from_secs(86400));
        let hex = identity.cluster_id_hex();
        assert_eq!(hex.len(), 64);
        assert!(hex.chars().all(|c| c.is_ascii_hexdigit()));
    }

    #[test]
    fn test_sign_and_verify() {
        let identity = ClusterIdentity::generate(Duration::from_secs(86400));
        let data = b"test message";
        let signature = identity.sign(data);

        assert!(identity.verify(data, &signature));
        assert!(!identity.verify(b"wrong message", &signature));
    }

    #[test]
    fn test_save_and_load() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("identity.key");

        let identity = ClusterIdentity::generate(Duration::from_secs(86400));
        let cluster_id = identity.cluster_id();

        identity.save(&path).unwrap();

        let loaded = ClusterIdentity::load(&path).unwrap();
        assert_eq!(loaded.cluster_id(), cluster_id);

        let data = b"test";
        let sig = identity.sign(data);
        assert!(loaded.verify(data, &sig));
    }

    #[test]
    fn test_key_rotation() {
        let mut identity = ClusterIdentity::generate(Duration::from_secs(86400));
        let old_cluster_id = identity.cluster_id();

        let data = b"test message";
        let old_signature = identity.sign(data);

        identity.rotate(Duration::from_secs(3600));

        let new_cluster_id = identity.cluster_id();
        assert_ne!(old_cluster_id, new_cluster_id);

        // Old signature should still verify during grace period
        assert!(identity.verify(data, &old_signature));
        assert!(identity.has_previous_key());

        // New signature should also work
        let new_signature = identity.sign(data);
        assert!(identity.verify(data, &new_signature));
    }

    #[test]
    fn test_public_key_export() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("identity.pub");

        let identity = ClusterIdentity::generate(Duration::from_secs(86400));
        identity.save_public_key(&path).unwrap();

        let content = std::fs::read_to_string(&path).unwrap();
        let decoded =
            base64::Engine::decode(&base64::engine::general_purpose::STANDARD, &content).unwrap();
        assert_eq!(decoded.len(), 32);
    }

    #[test]
    fn test_clone() {
        let identity = ClusterIdentity::generate(Duration::from_secs(86400));
        let cloned = identity.clone();

        assert_eq!(identity.cluster_id(), cloned.cluster_id());

        let data = b"test";
        let sig = identity.sign(data);
        assert!(cloned.verify(data, &sig));
    }
}
