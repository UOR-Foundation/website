
CREATE OR REPLACE FUNCTION public.derive_uor_id(p_user_id uuid)
RETURNS text
LANGUAGE sql
IMMUTABLE
SET search_path = public, extensions
AS $$
  SELECT 'uor:' || encode(extensions.digest(p_user_id::text || ':uor-identity-v1', 'sha256'), 'hex')
$$;
