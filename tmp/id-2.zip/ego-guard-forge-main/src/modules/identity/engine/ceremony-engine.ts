/**
 * Ceremony Engine — Pure Functions for Trust Ceremony Logic
 * ═════════════════════════════════════════════════════════
 *
 * Generates Guardian/Delegate keypairs and founding ceremonies.
 * All functions are pure and deterministic (aside from crypto key generation).
 * Private keys never enter module state — they are returned once for export.
 *
 * ═══════════════════════════════════════════════════════════════
 * POST-QUANTUM: Uses CRYSTALS-Dilithium3 (ML-DSA-65, FIPS 204)
 * lattice-based signatures. Quantum computers cannot break geometry —
 * the sovereignty surface topology is the quantum-resistant invariant.
 * The signature scheme is a replaceable layer underneath.
 * ═══════════════════════════════════════════════════════════════
 *
 * Guardian Key = stays on-device, protects privacy boundary
 * Delegate Key = shared with services, acts on behalf of identity
 *
 * @module identity/engine/ceremony
 */

import type {
  CeremonyRecord,
  CeremonyType,
  KeyFingerprint,
  KeyPairMeta,
} from "../types";
import { singleProofHash } from "../compat/uor-canonical";
import {
  generateDilithiumKeyPair,
  computeFingerprint,
  DILITHIUM_PARAMS,
  type PQKeyPair,
} from "./pq-crypto";

// ── Re-export fingerprint utility ───────────────────────────────────────────

export { computeFingerprint } from "./pq-crypto";

// ── Keypair Generation ──────────────────────────────────────────────────────

export interface GeneratedKeyPair {
  readonly publicKeyHex: string;
  readonly privateKeyHex: string;
  readonly fingerprint: KeyFingerprint;
  readonly meta: KeyPairMeta;
}

/**
 * Generate a post-quantum keypair (Dilithium3 / ML-DSA-65).
 *
 * Returns the same GeneratedKeyPair interface as before for backward
 * compatibility. The underlying algorithm is now lattice-based:
 *   - Public key:  1952 bytes (vs Ed25519's 32 bytes)
 *   - Secret key:  4000 bytes (vs Ed25519's 64 bytes)
 *   - NIST Level 3: 128-bit quantum / 192-bit classical security
 */
export async function generateKeyPair(): Promise<GeneratedKeyPair> {
  const pqKey: PQKeyPair = await generateDilithiumKeyPair();

  return {
    publicKeyHex: pqKey.publicKeyHex,
    privateKeyHex: pqKey.secretKeyHex,
    fingerprint: pqKey.fingerprint,
    meta: {
      fingerprint: pqKey.fingerprint,
      algorithm: pqKey.algorithm,  // "ML-DSA-65" instead of "Ed25519"
      createdAt: pqKey.createdAt,
    },
  };
}

// ── Founding Ceremony ───────────────────────────────────────────────────────

export interface FoundingCeremonyResult {
  readonly ceremonyRecord: CeremonyRecord;
  readonly guardianKey: GeneratedKeyPair;
  readonly delegateKey: GeneratedKeyPair;
  readonly identityDerivationId: string;
  readonly identityGlyph: string;
  readonly identityCid: string;
  readonly identityIpv6: string;
}

/**
 * Execute a founding ceremony — generates Guardian + Delegate keypairs
 * and derives a canonical identity from the founding proof.
 *
 * Now uses Dilithium3 lattice-based signatures. The geometric boundary
 * topology (96 edges, 6 dimensions) remains unchanged — it IS the
 * quantum-resistant invariant. The signature scheme rotates underneath.
 */
export async function createFoundingCeremony(
  seed: Record<string, unknown>,
): Promise<FoundingCeremonyResult> {
  // Step 1: Generate Guardian keypair (privacy boundary — never leaves device)
  const guardianKey = await generateKeyPair();

  // Step 2: Generate Delegate keypair (interaction credential — public key shared)
  const delegateKey = await generateKeyPair();

  // Step 3: Founding derivation proof
  const foundingClaim = {
    "@context": "https://uor.foundation/contexts/uor-v1.jsonld",
    "@type": "u:FoundingCeremony",
    "u:algorithm": DILITHIUM_PARAMS.fipsDesignation,
    "u:nistLevel": DILITHIUM_PARAMS.nistLevel,
    "u:guardianFingerprint": guardianKey.fingerprint,
    "u:delegateFingerprint": delegateKey.fingerprint,
    "u:delegatePublicKey": delegateKey.publicKeyHex,
    "u:operation": "neg(bnot(42))",
    "u:expectedResult": "43",
    ...seed,
  };
  const foundingProof = await singleProofHash(foundingClaim);

  // Step 4: Derive canonical identity from ceremony
  const identitySeed = {
    "@context": "https://uor.foundation/contexts/uor-v1.jsonld",
    "@type": "u:CeremonyIdentity",
    "u:algorithm": DILITHIUM_PARAMS.fipsDesignation,
    "u:foundingDerivationId": foundingProof.derivationId,
    "u:guardianFingerprint": guardianKey.fingerprint,
    "u:delegatePublicKey": delegateKey.publicKeyHex,
    "u:createdAt": new Date().toISOString(),
    ...seed,
  };
  const identityProof = await singleProofHash(identitySeed);

  // Step 5: Build ceremony record
  const ceremonyRecord: CeremonyRecord = {
    id: foundingProof.derivationId,
    type: "founding",
    identityId: identityProof.derivationId,
    participants: [identityProof.derivationId],
    derivationId: foundingProof.derivationId,
    guardianFingerprint: guardianKey.fingerprint,
    delegateFingerprint: delegateKey.fingerprint,
    timestamp: Date.now(),
    metadata: {
      bootstrapMethod: (seed["u:bootstrapMethod"] as string) ?? "founding-derivation",
      algorithm: DILITHIUM_PARAMS.fipsDesignation,
      nistLevel: DILITHIUM_PARAMS.nistLevel,
      quantumSecurityBits: 128,
    },
  };

  return {
    ceremonyRecord,
    guardianKey,
    delegateKey,
    identityDerivationId: identityProof.derivationId,
    identityGlyph: identityProof.uorAddress["u:glyph"],
    identityCid: identityProof.cid,
    identityIpv6: identityProof.ipv6Address["u:ipv6"],
  };
}

// ── Ceremony Validation ─────────────────────────────────────────────────────

/** Check if a ceremony record is well-formed. */
export function isCeremonyValid(record: CeremonyRecord): boolean {
  return (
    record.id.length > 0 &&
    record.derivationId.length > 0 &&
    record.guardianFingerprint.length === 64 &&
    record.delegateFingerprint.length === 64 &&
    record.participants.length > 0 &&
    record.timestamp > 0
  );
}

/** Count ceremonies by type. */
export function ceremoniesByType(
  ceremonies: readonly CeremonyRecord[],
  type: CeremonyType,
): readonly CeremonyRecord[] {
  return ceremonies.filter((c) => c.type === type);
}

/** Compute trust level based on ceremony count (peer ceremonies only). */
export function trustLevelFromCeremonies(
  ceremonies: readonly CeremonyRecord[],
): "unknown" | "minimal" | "basic" | "verified" | "sovereign" {
  const peerCount = ceremonies.filter((c) => c.type === "peer").length;
  if (peerCount >= 25) return "sovereign";
  if (peerCount >= 11) return "verified";
  if (peerCount >= 4) return "basic";
  if (peerCount >= 1) return "minimal";
  return "unknown";
}

// ── Peer Ceremony ───────────────────────────────────────────────────────────

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Status of a peer ceremony handshake. */
export type PeerCeremonyStatus = "initiated" | "accepted" | "completed" | "rejected";

/** A pending peer ceremony invitation. */
export interface PeerCeremonyInvite {
  readonly id: string;
  readonly status: PeerCeremonyStatus;
  readonly initiatorId: string;
  readonly initiatorDelegateKey: string;
  readonly initiatorFingerprint: KeyFingerprint;
  readonly responderId?: string;
  readonly responderDelegateKey?: string;
  readonly responderFingerprint?: KeyFingerprint;
  readonly derivationId?: string;
  readonly algorithm: string;
  readonly createdAt: number;
  readonly completedAt?: number;
}

/**
 * Initiate a peer ceremony — the first step in bilateral trust formation.
 * Returns an invite that the initiator shares with the peer.
 */
export async function initiatePeerCeremony(
  initiatorId: string,
  initiatorDelegateKeyHex: string,
  initiatorGuardianFingerprint: KeyFingerprint,
): Promise<PeerCeremonyInvite> {
  const inviteSeed = {
    "@context": "https://uor.foundation/contexts/uor-v1.jsonld",
    "@type": "u:PeerCeremonyInvite",
    "u:algorithm": DILITHIUM_PARAMS.fipsDesignation,
    "u:initiatorId": initiatorId,
    "u:initiatorDelegateKey": initiatorDelegateKeyHex,
    "u:createdAt": new Date().toISOString(),
    "u:entropy": bytesToHex(crypto.getRandomValues(new Uint8Array(16))),
  };
  const proof = await singleProofHash(inviteSeed);

  return {
    id: proof.derivationId,
    status: "initiated",
    initiatorId,
    initiatorDelegateKey: initiatorDelegateKeyHex,
    initiatorFingerprint: initiatorGuardianFingerprint,
    algorithm: DILITHIUM_PARAMS.fipsDesignation,
    createdAt: Date.now(),
  };
}

/**
 * Accept a peer ceremony invitation — the responder adds their credentials.
 */
export async function acceptPeerCeremony(
  invite: PeerCeremonyInvite,
  responderId: string,
  responderDelegateKeyHex: string,
  responderGuardianFingerprint: KeyFingerprint,
): Promise<PeerCeremonyInvite> {
  if (invite.status !== "initiated") {
    return { ...invite, status: "rejected" };
  }

  return {
    ...invite,
    status: "accepted",
    responderId,
    responderDelegateKey: responderDelegateKeyHex,
    responderFingerprint: responderGuardianFingerprint,
  };
}

/**
 * Complete a peer ceremony — finalizes bilateral trust and produces a CeremonyRecord.
 */
export async function completePeerCeremony(
  invite: PeerCeremonyInvite,
): Promise<{ invite: PeerCeremonyInvite; record: CeremonyRecord } | null> {
  if (invite.status !== "accepted" || !invite.responderId || !invite.responderDelegateKey || !invite.responderFingerprint) {
    return null;
  }

  const completionSeed = {
    "@context": "https://uor.foundation/contexts/uor-v1.jsonld",
    "@type": "u:PeerCeremonyCompletion",
    "u:algorithm": DILITHIUM_PARAMS.fipsDesignation,
    "u:inviteId": invite.id,
    "u:initiatorId": invite.initiatorId,
    "u:responderId": invite.responderId,
    "u:initiatorDelegateKey": invite.initiatorDelegateKey,
    "u:responderDelegateKey": invite.responderDelegateKey,
    "u:completedAt": new Date().toISOString(),
  };
  const proof = await singleProofHash(completionSeed);

  const record: CeremonyRecord = {
    id: proof.derivationId,
    type: "peer",
    identityId: invite.initiatorId,
    participants: [invite.initiatorId, invite.responderId],
    derivationId: proof.derivationId,
    guardianFingerprint: invite.initiatorFingerprint,
    delegateFingerprint: invite.responderFingerprint,
    timestamp: Date.now(),
    metadata: {
      inviteId: invite.id,
      peerType: "bilateral",
      algorithm: DILITHIUM_PARAMS.fipsDesignation,
      nistLevel: DILITHIUM_PARAMS.nistLevel,
    },
  };

  return {
    invite: {
      ...invite,
      status: "completed",
      derivationId: proof.derivationId,
      completedAt: Date.now(),
    },
    record,
  };
}
