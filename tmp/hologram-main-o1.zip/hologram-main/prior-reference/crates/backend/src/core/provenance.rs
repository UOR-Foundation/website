//! Data provenance tracking for debugging and analysis.
//!
//! This module provides types for tracking the origin and lineage of data
//! as it flows through the execution pipeline. All provenance tracking is
//! feature-gated behind `debug-provenance` to ensure zero overhead in
//! production builds.
//!
//! # Usage
//!
//! Enable provenance tracking by compiling with the `debug-provenance` feature:
//!
//! ```bash
//! cargo build --features debug-provenance
//! ```
//!
//! # Data Origins
//!
//! The system tracks two main categories of data:
//!
//! ## Without Weights (Pure Lookup Mode)
//! - Dynamic user input (SHA256 input, hash data, etc.)
//! - Results of pure lookup operations (no weights involved)
//!
//! ## With Weights (AI Model Mode)
//! - Embedded weights in .holo files (mmap'd, zero-copy)
//! - External memory-mapped weight files
//! - Inline weight data (compilation-time only)

/// Origin of data in the execution pipeline.
///
/// This enum tracks where data comes from, enabling debugging tools to
/// trace data flow through the computation graph.
#[cfg(feature = "debug-provenance")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DataOrigin {
    // === WITHOUT WEIGHTS (pure lookup mode) ===
    /// Dynamic user input (SHA256 input, hash data, etc.)
    ///
    /// This is the entry point for data in pure lookup mode where
    /// no model weights are involved.
    ModelInput {
        /// Index of the input in the inputs array.
        input_id: usize,
        /// Optional human-readable name for debugging.
        name: Option<String>,
    },

    /// Result of a pure lookup operation (no weights involved).
    ///
    /// The lookup table transforms bytes via pre-computed tables,
    /// not through learned weights.
    PureLookup {
        /// Identifier of the lookup table used.
        table_id: u32,
        /// Origin of the input data to the lookup.
        input_origin: Box<DataOrigin>,
    },

    // === WITH WEIGHTS (AI model mode) ===
    /// Embedded in .holo file (maps to `WeightLocation::Embedded`).
    ///
    /// Zero-copy via mmap into `plan.constant_data`. This is the most
    /// common case for deployed models.
    HoloEmbedded {
        /// Path to the .holo file (if known).
        holo_path: Option<String>,
        /// Byte offset within the file where weights start.
        offset: usize,
        /// Human-readable weight name (e.g., "encoder.layer1.weight").
        weight_name: Option<String>,
    },

    /// Memory-mapped external file (maps to `WeightLocation::MemoryMapped`).
    ///
    /// Used for large weight files that are loaded lazily via mmap.
    HoloMapped {
        /// Path to the external .weights file.
        path: String,
        /// Byte offset within the file.
        offset: usize,
    },

    /// Inline weight data (maps to `WeightLocation::Inline`).
    ///
    /// Only used during compilation; weights are embedded into the
    /// plan before execution.
    InlineWeight {
        /// Source name for debugging (e.g., ONNX initializer name).
        source_name: Option<String>,
    },

    // === COMMON ===
    /// Computed from other operations (both modes).
    ///
    /// The result of a kernel execution, with lineage to inputs.
    Computed {
        /// Index of the operation in the plan's ops array.
        op_index: usize,
        /// The kernel that produced this data.
        kernel_id: u32,
    },

    /// Workspace allocation (temporary buffers).
    ///
    /// Intermediate results stored in workspace memory.
    Workspace {
        /// Slot index in the workspace layout.
        slot: usize,
    },
}

/// Complete provenance information for a data buffer.
///
/// Combines origin tracking with transformation history and
/// debugging metadata.
#[cfg(feature = "debug-provenance")]
#[derive(Debug, Clone, Default)]
pub struct ProvenanceInfo {
    /// The origin of the data (where it came from).
    pub origin: Option<DataOrigin>,

    /// Chain of transforms applied to the data.
    ///
    /// Each entry is a kernel ID representing a transformation step.
    /// The order is from oldest to newest (first transform first).
    pub transform_chain: Vec<u32>,

    /// The IR node ID that produced this data (if available).
    ///
    /// Links back to the original OperationGraph for source mapping.
    pub ir_node_id: Option<usize>,

    /// Human-readable name for debugging.
    pub debug_name: Option<String>,
}

#[cfg(feature = "debug-provenance")]
impl ProvenanceInfo {
    /// Create a new empty provenance info.
    pub fn new() -> Self {
        Self::default()
    }

    /// Create provenance for a model input.
    pub fn from_input(input_id: usize, name: Option<String>) -> Self {
        Self {
            origin: Some(DataOrigin::ModelInput { input_id, name }),
            transform_chain: Vec::new(),
            ir_node_id: None,
            debug_name: None,
        }
    }

    /// Create provenance for embedded weights.
    pub fn from_embedded(
        holo_path: Option<String>,
        offset: usize,
        weight_name: Option<String>,
    ) -> Self {
        Self {
            origin: Some(DataOrigin::HoloEmbedded {
                holo_path,
                offset,
                weight_name,
            }),
            transform_chain: Vec::new(),
            ir_node_id: None,
            debug_name: None,
        }
    }

    /// Create provenance for a computed result.
    pub fn from_computed(op_index: usize, kernel_id: u32) -> Self {
        Self {
            origin: Some(DataOrigin::Computed {
                op_index,
                kernel_id,
            }),
            transform_chain: Vec::new(),
            ir_node_id: None,
            debug_name: None,
        }
    }

    /// Add a transformation to the chain.
    pub fn add_transform(&mut self, kernel_id: u32) {
        self.transform_chain.push(kernel_id);
    }

    /// Set the debug name.
    pub fn with_name(mut self, name: impl Into<String>) -> Self {
        self.debug_name = Some(name.into());
        self
    }

    /// Set the IR node ID.
    pub fn with_ir_node(mut self, node_id: usize) -> Self {
        self.ir_node_id = Some(node_id);
        self
    }

    /// Check if this data originated from a model input.
    pub fn is_from_input(&self) -> bool {
        matches!(self.origin, Some(DataOrigin::ModelInput { .. }))
    }

    /// Check if this data originated from weights.
    pub fn is_from_weights(&self) -> bool {
        matches!(
            self.origin,
            Some(DataOrigin::HoloEmbedded { .. })
                | Some(DataOrigin::HoloMapped { .. })
                | Some(DataOrigin::InlineWeight { .. })
        )
    }

    /// Check if this data was computed (not a direct input or weight).
    pub fn is_computed(&self) -> bool {
        matches!(self.origin, Some(DataOrigin::Computed { .. }))
    }

    /// Get the number of transformations applied.
    pub fn transform_count(&self) -> usize {
        self.transform_chain.len()
    }
}

#[cfg(feature = "debug-provenance")]
impl std::fmt::Display for DataOrigin {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            DataOrigin::ModelInput { input_id, name } => {
                if let Some(n) = name {
                    write!(f, "Input[{}]: {}", input_id, n)
                } else {
                    write!(f, "Input[{}]", input_id)
                }
            }
            DataOrigin::PureLookup { table_id, .. } => {
                write!(f, "Lookup[table={}]", table_id)
            }
            DataOrigin::HoloEmbedded { weight_name, .. } => {
                if let Some(n) = weight_name {
                    write!(f, "Embedded: {}", n)
                } else {
                    write!(f, "Embedded")
                }
            }
            DataOrigin::HoloMapped { path, offset } => {
                write!(f, "Mapped: {}@{}", path, offset)
            }
            DataOrigin::InlineWeight { source_name } => {
                if let Some(n) = source_name {
                    write!(f, "Inline: {}", n)
                } else {
                    write!(f, "Inline")
                }
            }
            DataOrigin::Computed {
                op_index,
                kernel_id,
            } => {
                write!(f, "Computed[op={}, kernel=0x{:04x}]", op_index, kernel_id)
            }
            DataOrigin::Workspace { slot } => {
                write!(f, "Workspace[{}]", slot)
            }
        }
    }
}

#[cfg(feature = "debug-provenance")]
impl std::fmt::Display for ProvenanceInfo {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if let Some(name) = &self.debug_name {
            write!(f, "{}: ", name)?;
        }

        if let Some(origin) = &self.origin {
            write!(f, "{}", origin)?;
        } else {
            write!(f, "Unknown")?;
        }

        if !self.transform_chain.is_empty() {
            write!(f, " -> {} transforms", self.transform_chain.len())?;
        }

        Ok(())
    }
}

// ============================================================================
// Stubs for when feature is disabled (zero-cost)
// ============================================================================

/// Stub origin type when provenance is disabled.
#[cfg(not(feature = "debug-provenance"))]
#[derive(Debug, Clone, Copy, Default)]
pub struct DataOrigin;

/// Stub provenance info when feature is disabled.
#[cfg(not(feature = "debug-provenance"))]
#[derive(Debug, Clone, Copy, Default)]
pub struct ProvenanceInfo;

#[cfg(not(feature = "debug-provenance"))]
impl ProvenanceInfo {
    /// Create a new empty provenance info (no-op).
    #[inline(always)]
    pub const fn new() -> Self {
        Self
    }
}

#[cfg(test)]
#[cfg(feature = "debug-provenance")]
mod tests {
    use super::*;

    #[test]
    fn test_data_origin_display() {
        let input = DataOrigin::ModelInput {
            input_id: 0,
            name: Some("image".into()),
        };
        assert_eq!(format!("{}", input), "Input[0]: image");

        let computed = DataOrigin::Computed {
            op_index: 5,
            kernel_id: 0x0100,
        };
        assert_eq!(format!("{}", computed), "Computed[op=5, kernel=0x0100]");
    }

    #[test]
    fn test_provenance_info_from_input() {
        let prov = ProvenanceInfo::from_input(0, Some("test_input".into()));
        assert!(prov.is_from_input());
        assert!(!prov.is_from_weights());
        assert!(!prov.is_computed());
    }

    #[test]
    fn test_provenance_info_from_embedded() {
        let prov = ProvenanceInfo::from_embedded(
            Some("model.holo".into()),
            1024,
            Some("layer1.weight".into()),
        );
        assert!(!prov.is_from_input());
        assert!(prov.is_from_weights());
        assert!(!prov.is_computed());
    }

    #[test]
    fn test_provenance_info_from_computed() {
        let prov = ProvenanceInfo::from_computed(10, 0x0200);
        assert!(!prov.is_from_input());
        assert!(!prov.is_from_weights());
        assert!(prov.is_computed());
    }

    #[test]
    fn test_provenance_transform_chain() {
        let mut prov = ProvenanceInfo::from_input(0, None);
        assert_eq!(prov.transform_count(), 0);

        prov.add_transform(0x0100);
        prov.add_transform(0x0400);
        assert_eq!(prov.transform_count(), 2);
        assert_eq!(prov.transform_chain, vec![0x0100, 0x0400]);
    }

    #[test]
    fn test_provenance_builder_pattern() {
        let prov = ProvenanceInfo::from_input(0, None)
            .with_name("test_buffer")
            .with_ir_node(42);

        assert_eq!(prov.debug_name, Some("test_buffer".to_string()));
        assert_eq!(prov.ir_node_id, Some(42));
    }

    #[test]
    fn test_provenance_display() {
        let prov = ProvenanceInfo::from_input(0, Some("image".into())).with_name("input_tensor");

        let display = format!("{}", prov);
        assert!(display.contains("input_tensor"));
        assert!(display.contains("image"));
    }
}
