//! Fusion passes for the compilation pipeline (Stage 2).
//!
//! Fusion passes reduce the graph by combining operations:
//! - Constant folding: evaluate all-constant operations
//! - CSE: deduplicate identical operations
//! - Activation fusion: chain activations into lookup tables
//! - Activation LUT: mark quantized activations for O(1) LUT execution
//! - Batch fusion: sequential lookups into SIMD batches
//! - Weight quantization: quantize `MatMul` weights for LUT-GEMM

mod activation;
mod activation_lut;
mod batch;
mod constant;
mod cse;
mod hash_chain;
mod instruction;
mod observable;
mod quantize;

pub use activation::activation_fusion;
pub use activation_lut::{
    activation_lut_fusion, parse_activation_lut_annotation, ActivationLutConfig,
};
pub use batch::batch_fusion;
pub use constant::constant_folding;
pub use cse::cse;
pub use hash_chain::hash_chain_fusion;
pub use instruction::instruction_fusion;
pub use observable::{
    estimate_variation_cost, is_verifiable_chain, observable_fusion, ObservableAnnotation,
};
pub use quantize::{quantize_weights, LutGemmHeuristics, QuantizeConfig, QuantizeMode};

use crate::graph::CompileGraph;

/// Run all fusion passes.
pub fn run_all_passes(graph: &mut CompileGraph, parallel_threshold: usize) {
    run_all_passes_with_config(graph, parallel_threshold, &ActivationLutConfig::default());
}

/// Run all fusion passes with activation LUT configuration.
pub fn run_all_passes_with_config(
    graph: &mut CompileGraph,
    parallel_threshold: usize,
    activation_lut_config: &ActivationLutConfig,
) {
    // Note: constant_folding requires original constants, but during pure fusion passes
    // we don't have access to them. Use empty slice - folding will be limited to
    // shape-only transformations without actual value propagation.
    constant_folding(graph, &[]);
    cse(graph);
    // Observable-based fusion for categorical operations (ring, torus, orbit)
    // Uses monodromy signature equivalence to safely fuse operation chains.
    observable_fusion(graph);
    activation_fusion(graph);
    // Hash chain fusion: Sha256 -> Sha256 = DoubleSha256
    hash_chain_fusion(graph);
    // Instruction fusion: MatMul->Relu = MatMulRelu, Add->Sigmoid = AddSigmoid
    instruction_fusion(graph);
    // Activation LUT fusion: mark quantized activations for O(1) LUT execution
    activation_lut_fusion(graph, activation_lut_config);
    batch_fusion(graph, parallel_threshold);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{DType, OpKind, OpNode, OperationGraph};

    fn create_simple_graph() -> OperationGraph {
        let mut graph = OperationGraph::new();

        // Input -> Relu -> Output
        let input = OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32);
        let relu = OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32);
        let output = OpNode::new(2, OpKind::Output, vec![1, 4], DType::F32);

        graph.add_node(input);
        graph.add_node(relu);
        graph.add_node(output);

        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        graph.add_input("input", 0);
        graph.add_output("output", 2);

        graph
    }

    fn create_matmul_relu_graph() -> OperationGraph {
        let mut graph = OperationGraph::new();

        // Input -> MatMul -> Relu -> Output
        let input = OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32);
        let matmul = OpNode::new(
            1,
            OpKind::MatMul { m: 1, k: 4, n: 8 },
            vec![1, 8],
            DType::F32,
        );
        let relu = OpNode::new(2, OpKind::Relu, vec![1, 8], DType::F32);
        let output = OpNode::new(3, OpKind::Output, vec![1, 8], DType::F32);

        graph.add_node(input);
        graph.add_node(matmul);
        graph.add_node(relu);
        graph.add_node(output);

        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);

        graph.add_input("input", 0);
        graph.add_output("output", 3);

        graph
    }

    fn create_add_chain_graph() -> OperationGraph {
        let mut graph = OperationGraph::new();

        // Input1 -> Add -> Add -> Output
        // Input2 -----^    ^
        // Input3 ----------|
        let input1 = OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32);
        let input2 = OpNode::new(1, OpKind::Input, vec![1, 4], DType::F32);
        let input3 = OpNode::new(2, OpKind::Input, vec![1, 4], DType::F32);
        let add1 = OpNode::new(3, OpKind::Add, vec![1, 4], DType::F32);
        let add2 = OpNode::new(4, OpKind::Add, vec![1, 4], DType::F32);
        let output = OpNode::new(5, OpKind::Output, vec![1, 4], DType::F32);

        graph.add_node(input1);
        graph.add_node(input2);
        graph.add_node(input3);
        graph.add_node(add1);
        graph.add_node(add2);
        graph.add_node(output);

        graph.add_edge(0, 3);
        graph.add_edge(1, 3);
        graph.add_edge(3, 4);
        graph.add_edge(2, 4);
        graph.add_edge(4, 5);

        graph.add_input("input1", 0);
        graph.add_input("input2", 1);
        graph.add_input("input3", 2);
        graph.add_output("output", 5);

        graph
    }

    #[test]
    fn test_run_all_passes_simple_graph() {
        let op_graph = create_simple_graph();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        let node_count_before = graph.topo_order().len();

        run_all_passes(&mut graph, 1024);

        // Graph should still have nodes after passes
        let node_count_after = graph.topo_order().len();
        assert!(
            node_count_after > 0,
            "Graph should not be empty after passes"
        );

        // For a simple graph, node count may reduce due to fusion but shouldn't increase
        assert!(
            node_count_after <= node_count_before,
            "Fusion should not add nodes"
        );
    }

    #[test]
    fn test_run_all_passes_matmul_relu() {
        let op_graph = create_matmul_relu_graph();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        run_all_passes(&mut graph, 1024);

        // The graph should still be valid and have nodes
        let topo = graph.topo_order();
        assert!(!topo.is_empty(), "Graph should have nodes after passes");
    }

    #[test]
    fn test_run_all_passes_add_chain() {
        let op_graph = create_add_chain_graph();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        run_all_passes(&mut graph, 1024);

        // Graph should remain valid
        let topo = graph.topo_order();
        assert!(!topo.is_empty(), "Graph should have nodes after passes");
    }

    #[test]
    fn test_run_all_passes_empty_graph() {
        let op_graph = OperationGraph::new();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        // Should not panic on empty graph
        run_all_passes(&mut graph, 1024);

        assert!(
            graph.topo_order().is_empty(),
            "Empty graph should stay empty"
        );
    }

    #[test]
    fn test_run_all_passes_single_node() {
        let mut op_graph = OperationGraph::new();
        let input = OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32);
        op_graph.add_node(input);
        op_graph.add_input("input", 0);

        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        run_all_passes(&mut graph, 1024);

        // Single node graph should remain valid
        let topo = graph.topo_order();
        assert_eq!(topo.len(), 1, "Single node graph should have one node");
    }

    #[test]
    fn test_constant_folding_pass() {
        let op_graph = create_simple_graph();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        // Run only constant folding
        constant_folding(&mut graph, &[]);

        // Graph should still be valid
        assert!(
            !graph.topo_order().is_empty(),
            "Graph should have nodes after constant folding"
        );
    }

    #[test]
    fn test_cse_pass() {
        let op_graph = create_add_chain_graph();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        // Run only CSE
        cse(&mut graph);

        // Graph should still be valid
        assert!(
            !graph.topo_order().is_empty(),
            "Graph should have nodes after CSE"
        );
    }

    #[test]
    fn test_activation_fusion_pass() {
        let op_graph = create_matmul_relu_graph();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        // Run only activation fusion
        activation_fusion(&mut graph);

        // Graph should still be valid
        assert!(
            !graph.topo_order().is_empty(),
            "Graph should have nodes after activation fusion"
        );
    }

    #[test]
    fn test_batch_fusion_pass() {
        let op_graph = create_simple_graph();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        // Run only batch fusion
        batch_fusion(&mut graph, 1024);

        // Graph should still be valid
        assert!(
            !graph.topo_order().is_empty(),
            "Graph should have nodes after batch fusion"
        );
    }

    #[test]
    fn test_pass_order_no_panic() {
        // Test that passes can be run in different orders without panic
        let op_graph = create_matmul_relu_graph();

        // Standard order
        let mut graph1 = CompileGraph::from_operation_graph(&op_graph).unwrap();
        constant_folding(&mut graph1, &[]);
        cse(&mut graph1);
        activation_fusion(&mut graph1);
        batch_fusion(&mut graph1, 1024);

        // Different order (for comparison)
        let mut graph2 = CompileGraph::from_operation_graph(&op_graph).unwrap();
        activation_fusion(&mut graph2);
        cse(&mut graph2);
        batch_fusion(&mut graph2, 1024);
        constant_folding(&mut graph2, &[]);

        // Both should complete without panic
        assert!(!graph1.topo_order().is_empty());
        assert!(!graph2.topo_order().is_empty());
    }

    #[test]
    fn test_run_all_passes_parallel_threshold_variants() {
        let op_graph = create_add_chain_graph();

        // Test with different parallel thresholds
        for threshold in [0, 1, 16, 256, 1024, 4096] {
            let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();
            run_all_passes(&mut graph, threshold);
            assert!(
                !graph.topo_order().is_empty(),
                "Graph should be valid with threshold {threshold}"
            );
        }
    }

    #[test]
    fn test_multiple_run_all_passes() {
        let op_graph = create_simple_graph();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        // Run passes multiple times (should be idempotent-ish)
        run_all_passes(&mut graph, 1024);
        let count1 = graph.topo_order().len();

        run_all_passes(&mut graph, 1024);
        let count2 = graph.topo_order().len();

        // Node count should not increase on repeated passes
        assert!(
            count2 <= count1,
            "Repeated passes should not increase node count"
        );
    }

    fn create_categorical_chain_graph() -> OperationGraph {
        let mut graph = OperationGraph::new();

        let input = OpNode::new(0, OpKind::Input, vec![256], DType::F32);
        let lift = OpNode::new(1, OpKind::Lift, vec![256], DType::F32);
        let orbit = OpNode::new(2, OpKind::OrbitClassify, vec![256], DType::F32);
        let lift2 = OpNode::new(3, OpKind::Lift, vec![256], DType::F32);
        let output = OpNode::new(4, OpKind::Output, vec![256], DType::F32);

        graph.add_node(input);
        graph.add_node(lift);
        graph.add_node(orbit);
        graph.add_node(lift2);
        graph.add_node(output);

        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        graph.add_edge(3, 4);

        graph.add_input("input", 0);
        graph.add_output("output", 4);

        graph
    }

    #[test]
    fn test_observable_fusion_pass() {
        let op_graph = create_categorical_chain_graph();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        let node_count_before = graph.topo_order().len();

        // Run observable fusion
        observable_fusion(&mut graph);

        let node_count_after = graph.topo_order().len();

        // Categorical chain should be fused (fewer nodes)
        assert!(
            node_count_after < node_count_before,
            "Observable fusion should reduce node count for categorical chain"
        );
    }

    #[test]
    fn test_observable_fusion_in_full_pipeline() {
        let op_graph = create_categorical_chain_graph();
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        // Run all passes including observable fusion
        run_all_passes(&mut graph, 1024);

        // Graph should still be valid
        assert!(
            !graph.topo_order().is_empty(),
            "Graph should have nodes after all passes"
        );
    }

    #[test]
    fn test_estimate_variation_cost_api() {
        // Test the public API for variation cost estimation
        let categorical_ops = vec![OpKind::Lift, OpKind::OrbitClassify];
        let cost = estimate_variation_cost(&categorical_ops);
        assert_eq!(cost, 2); // 1 + 1 for torus ops
    }

    #[test]
    fn test_is_verifiable_chain_api() {
        // Test the public API for chain verifiability
        assert!(is_verifiable_chain(&[OpKind::Lift, OpKind::OrbitClassify]));
        assert!(!is_verifiable_chain(&[OpKind::Sigmoid]));
    }
}
