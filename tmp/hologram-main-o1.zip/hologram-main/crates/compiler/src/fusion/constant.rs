//! Constant folding pass.
//!
//! Evaluates operations with all-constant inputs at compile time and
//! replaces them with constant nodes. This pass now computes actual
//! constant values for foldable operations.

use crate::graph::{CompileGraph, ConstantData, OpKind};

/// Evaluate operations with all-constant inputs at compile time.
///
/// This pass propagates constantness through the graph:
/// 1. Find nodes where all predecessors are Constant nodes
/// 2. Compute the actual constant value using the operation
/// 3. Store the computed value and mark the node as constant
/// 4. Repeat until no more nodes can be folded
///
/// The computed constant values are stored in `graph.folded_constants` and
/// will be serialized into the `BackendPlan.constants` blob.
pub fn constant_folding(graph: &mut CompileGraph, original_constants: &[ConstantData]) {
    // Iterate until no more changes
    loop {
        let folded = fold_constants_once(graph, original_constants);
        if folded == 0 {
            break;
        }
    }
}

/// Single pass of constant folding. Returns count of folded nodes.
fn fold_constants_once(graph: &mut CompileGraph, original_constants: &[ConstantData]) -> usize {
    // Collect nodes to fold with their computed values (can't mutate while iterating)
    let to_fold: Vec<(u32, Option<ConstantData>)> = graph
        .nodes()
        .filter_map(|(id, node)| {
            // Skip nodes that are already constants, inputs, or outputs
            if matches!(node.op, OpKind::Constant | OpKind::Input | OpKind::Output) {
                return None;
            }

            // Check if all predecessors are constants
            if !graph.all_predecessors_constant(id) || !node.op.is_pure() {
                return None;
            }

            // Get predecessor constant data and compute result
            let preds = graph.predecessors(id);
            let pred_data = get_predecessor_constant(graph, &preds, original_constants);

            // Evaluate the operation if we have input data
            let computed = if let Some(input_data) = pred_data {
                let pred_node = graph.get_node(preds[0])?;
                evaluate_constant_op(&node.op, &pred_node.shape, input_data)
            } else {
                None
            };

            Some((id, computed))
        })
        .collect();

    // Count actual conversions, not candidates
    let mut count = 0;

    // Fold the nodes and store computed values
    // Only convert to Constant if we have the computed data
    for (id, computed) in to_fold {
        if let Some(data) = computed {
            graph.replace_op(id, OpKind::Constant);
            graph.add_folded_constant(id, data);
            count += 1;
        }
    }

    count
}

/// Get the constant data for a predecessor node.
///
/// Checks both folded constants (from this pass) and original constants.
fn get_predecessor_constant<'a>(
    graph: &'a CompileGraph,
    preds: &[u32],
    original_constants: &'a [ConstantData],
) -> Option<&'a ConstantData> {
    if preds.is_empty() {
        return None;
    }

    let pred_id = preds[0];

    // First check if it's a folded constant
    if let Some(data) = graph.get_folded_constant(pred_id) {
        return Some(data);
    }

    // Otherwise look up in original constants by index
    let const_order = graph.constant_nodes_in_order();
    let idx = const_order.iter().position(|&id| id == pred_id)?;
    original_constants.get(idx)
}

/// Evaluate an operation with constant inputs.
///
/// Returns the computed `ConstantData` or `None` if evaluation is not supported.
fn evaluate_constant_op(
    op: &OpKind,
    input_shape: &[usize],
    input_data: &ConstantData,
) -> Option<ConstantData> {
    match op {
        // Identity operations - data is unchanged, only shape metadata differs
        OpKind::Reshape { .. }
        | OpKind::Squeeze { .. }
        | OpKind::Unsqueeze { .. }
        | OpKind::Flatten { .. }
        | OpKind::Copy => Some(input_data.clone()),

        // Transpose - requires actual data permutation
        OpKind::Transpose { perm } => evaluate_transpose(input_data, input_shape, perm),

        // Activation functions with constant input (element-wise)
        OpKind::Relu => evaluate_relu(input_data),
        OpKind::Sigmoid => evaluate_sigmoid(input_data),
        OpKind::Tanh => evaluate_tanh(input_data),

        // Transformer math operations (unary)
        OpKind::Sqrt => evaluate_sqrt(input_data),
        OpKind::Log => evaluate_log(input_data),
        OpKind::Exp => evaluate_exp(input_data),
        OpKind::Abs => evaluate_abs(input_data),

        // Other operations - not yet implemented
        _ => None,
    }
}

/// Evaluate transpose operation on constant data.
fn evaluate_transpose(
    data: &ConstantData,
    shape: &[usize],
    perm: &[usize],
) -> Option<ConstantData> {
    match data {
        ConstantData::F32(values) => {
            let transposed = transpose_elements(values, shape, perm)?;
            Some(ConstantData::F32(transposed))
        }
        ConstantData::F64(values) => {
            let transposed = transpose_elements(values, shape, perm)?;
            Some(ConstantData::F64(transposed))
        }
        ConstantData::I32(values) => {
            let transposed = transpose_elements(values, shape, perm)?;
            Some(ConstantData::I32(transposed))
        }
        ConstantData::I64(values) => {
            let transposed = transpose_elements(values, shape, perm)?;
            Some(ConstantData::I64(transposed))
        }
        ConstantData::U8(values) => {
            let transposed = transpose_elements(values, shape, perm)?;
            Some(ConstantData::U8(transposed))
        }
        ConstantData::U16(values) => {
            let transposed = transpose_elements(values, shape, perm)?;
            Some(ConstantData::U16(transposed))
        }
        ConstantData::U32(values) => {
            let transposed = transpose_elements(values, shape, perm)?;
            Some(ConstantData::U32(transposed))
        }
        ConstantData::Bool(values) => {
            let transposed = transpose_elements(values, shape, perm)?;
            Some(ConstantData::Bool(transposed))
        }
    }
}

/// Generic transpose implementation for any element type.
fn transpose_elements<T: Copy>(values: &[T], shape: &[usize], perm: &[usize]) -> Option<Vec<T>> {
    if shape.is_empty() || perm.len() != shape.len() {
        return None;
    }

    let total: usize = shape.iter().product();
    if values.len() != total {
        return None;
    }

    // Compute input strides
    let mut in_strides = vec![1usize; shape.len()];
    for i in (0..shape.len() - 1).rev() {
        in_strides[i] = in_strides[i + 1] * shape[i + 1];
    }

    // Compute output shape and strides
    let out_shape: Vec<usize> = perm.iter().map(|&p| shape[p]).collect();
    let mut out_strides = vec![1usize; out_shape.len()];
    for i in (0..out_shape.len() - 1).rev() {
        out_strides[i] = out_strides[i + 1] * out_shape[i + 1];
    }

    // Transpose by iterating output positions
    let mut result = vec![values[0]; total];
    for (out_idx, result_elem) in result.iter_mut().enumerate() {
        // Compute output coordinates
        let mut out_coords = vec![0usize; out_shape.len()];
        let mut idx = out_idx;
        for d in 0..out_shape.len() {
            out_coords[d] = idx / out_strides[d];
            idx %= out_strides[d];
        }

        // Map to input coordinates using inverse permutation
        let mut in_idx = 0;
        for (d, &p) in perm.iter().enumerate() {
            in_idx += out_coords[d] * in_strides[p];
        }

        *result_elem = values[in_idx];
    }

    Some(result)
}

/// Evaluate `ReLU` on constant data.
fn evaluate_relu(data: &ConstantData) -> Option<ConstantData> {
    match data {
        ConstantData::F32(values) => {
            let result: Vec<f32> = values.iter().map(|&x| x.max(0.0)).collect();
            Some(ConstantData::F32(result))
        }
        ConstantData::F64(values) => {
            let result: Vec<f64> = values.iter().map(|&x| x.max(0.0)).collect();
            Some(ConstantData::F64(result))
        }
        _ => None,
    }
}

/// Evaluate Sigmoid on constant data.
fn evaluate_sigmoid(data: &ConstantData) -> Option<ConstantData> {
    match data {
        ConstantData::F32(values) => {
            let result: Vec<f32> = values.iter().map(|&x| 1.0 / (1.0 + (-x).exp())).collect();
            Some(ConstantData::F32(result))
        }
        ConstantData::F64(values) => {
            let result: Vec<f64> = values.iter().map(|&x| 1.0 / (1.0 + (-x).exp())).collect();
            Some(ConstantData::F64(result))
        }
        _ => None,
    }
}

/// Evaluate Tanh on constant data.
fn evaluate_tanh(data: &ConstantData) -> Option<ConstantData> {
    match data {
        ConstantData::F32(values) => {
            let result: Vec<f32> = values.iter().map(|&x| x.tanh()).collect();
            Some(ConstantData::F32(result))
        }
        ConstantData::F64(values) => {
            let result: Vec<f64> = values.iter().map(|&x| x.tanh()).collect();
            Some(ConstantData::F64(result))
        }
        _ => None,
    }
}

/// Evaluate Sqrt on constant data.
fn evaluate_sqrt(data: &ConstantData) -> Option<ConstantData> {
    match data {
        ConstantData::F32(values) => {
            let result: Vec<f32> = values.iter().map(|&x| x.sqrt()).collect();
            Some(ConstantData::F32(result))
        }
        ConstantData::F64(values) => {
            let result: Vec<f64> = values.iter().map(|&x| x.sqrt()).collect();
            Some(ConstantData::F64(result))
        }
        _ => None,
    }
}

/// Evaluate Log (natural logarithm) on constant data.
fn evaluate_log(data: &ConstantData) -> Option<ConstantData> {
    match data {
        ConstantData::F32(values) => {
            let result: Vec<f32> = values.iter().map(|&x| x.ln()).collect();
            Some(ConstantData::F32(result))
        }
        ConstantData::F64(values) => {
            let result: Vec<f64> = values.iter().map(|&x| x.ln()).collect();
            Some(ConstantData::F64(result))
        }
        _ => None,
    }
}

/// Evaluate Exp (exponential) on constant data.
fn evaluate_exp(data: &ConstantData) -> Option<ConstantData> {
    match data {
        ConstantData::F32(values) => {
            let result: Vec<f32> = values.iter().map(|&x| x.exp()).collect();
            Some(ConstantData::F32(result))
        }
        ConstantData::F64(values) => {
            let result: Vec<f64> = values.iter().map(|&x| x.exp()).collect();
            Some(ConstantData::F64(result))
        }
        _ => None,
    }
}

/// Evaluate Abs (absolute value) on constant data.
fn evaluate_abs(data: &ConstantData) -> Option<ConstantData> {
    match data {
        ConstantData::F32(values) => {
            let result: Vec<f32> = values.iter().map(|&x| x.abs()).collect();
            Some(ConstantData::F32(result))
        }
        ConstantData::F64(values) => {
            let result: Vec<f64> = values.iter().map(|&x| x.abs()).collect();
            Some(ConstantData::F64(result))
        }
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpNode, OperationGraph};

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    #[test]
    fn test_constant_folding_empty_graph() {
        let mut graph = make_graph(vec![], vec![]);
        constant_folding(&mut graph, &[]);
        assert_eq!(graph.node_count(), 0);
    }

    #[test]
    fn test_constant_folding_no_constants() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        constant_folding(&mut graph, &[]);

        // Nothing should be folded - input is not a constant
        assert!(matches!(graph.get_node(0).unwrap().op, OpKind::Input));
        assert!(matches!(graph.get_node(1).unwrap().op, OpKind::Relu));
        assert!(matches!(graph.get_node(2).unwrap().op, OpKind::Output));
    }

    #[test]
    fn test_constant_folding_single_constant_input() {
        // Test with actual constant data (required for evaluation)
        let mut op_graph = OperationGraph::new();
        op_graph.add_node(OpNode::new(0, OpKind::Constant, vec![2, 3], DType::F32));
        op_graph.add_constant_for_node(0, ConstantData::F32(vec![-1.0, 0.0, 1.0, 2.0, -3.0, 4.0]));
        op_graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
        op_graph.add_node(OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32));
        op_graph.add_edge(0, 1);
        op_graph.add_edge(1, 2);

        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();
        constant_folding(&mut graph, &op_graph.constants);

        // Relu should be folded to constant (all predecessors are constant)
        assert!(matches!(graph.get_node(0).unwrap().op, OpKind::Constant));
        assert!(matches!(graph.get_node(1).unwrap().op, OpKind::Constant));
        // Output is not folded
        assert!(matches!(graph.get_node(2).unwrap().op, OpKind::Output));
    }

    #[test]
    fn test_constant_folding_chain() {
        // Test with actual constant data (required for evaluation)
        let mut op_graph = OperationGraph::new();
        op_graph.add_node(OpNode::new(0, OpKind::Constant, vec![2, 3], DType::F32));
        op_graph.add_constant_for_node(0, ConstantData::F32(vec![-1.0, 0.0, 1.0, 2.0, -3.0, 4.0]));
        op_graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
        op_graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![2, 3], DType::F32));
        op_graph.add_node(OpNode::new(3, OpKind::Tanh, vec![2, 3], DType::F32));
        op_graph.add_node(OpNode::new(4, OpKind::Output, vec![2, 3], DType::F32));
        op_graph.add_edge(0, 1);
        op_graph.add_edge(1, 2);
        op_graph.add_edge(2, 3);
        op_graph.add_edge(3, 4);

        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();
        constant_folding(&mut graph, &op_graph.constants);

        // All ops in the chain should be folded
        assert!(matches!(graph.get_node(0).unwrap().op, OpKind::Constant));
        assert!(matches!(graph.get_node(1).unwrap().op, OpKind::Constant));
        assert!(matches!(graph.get_node(2).unwrap().op, OpKind::Constant));
        assert!(matches!(graph.get_node(3).unwrap().op, OpKind::Constant));
        assert!(matches!(graph.get_node(4).unwrap().op, OpKind::Output));
    }

    #[test]
    fn test_constant_folding_binary_op() {
        // Binary ops (Add, Sub, Mul, etc.) don't have evaluation implemented yet,
        // so they won't be folded even with constant inputs. This test verifies
        // no infinite loop occurs when an op is foldable but can't be evaluated.
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Constant, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Constant, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Add, vec![2, 3], DType::F32),
                OpNode::new(3, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        constant_folding(&mut graph, &[]);

        // Add is not folded because binary op evaluation is not implemented
        assert!(matches!(graph.get_node(2).unwrap().op, OpKind::Add));
    }

    #[test]
    fn test_constant_folding_mixed_inputs() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Constant, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Add, vec![2, 3], DType::F32),
                OpNode::new(3, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        constant_folding(&mut graph, &[]);

        // Add should NOT be folded (one input is not constant)
        assert!(matches!(graph.get_node(2).unwrap().op, OpKind::Add));
    }

    #[test]
    fn test_constant_folding_load_not_folded() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Constant, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Load, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        constant_folding(&mut graph, &[]);

        // Load should NOT be folded (it has side effects)
        assert!(matches!(graph.get_node(1).unwrap().op, OpKind::Load));
    }

    #[test]
    fn test_constant_folding_matmul() {
        // MatMul doesn't have evaluation implemented yet, so it won't be folded
        // even with constant inputs. This test verifies no infinite loop occurs.
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Constant, vec![2, 4], DType::F32),
                OpNode::new(1, OpKind::Constant, vec![4, 8], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul { m: 2, k: 4, n: 8 },
                    vec![2, 8],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Output, vec![2, 8], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        constant_folding(&mut graph, &[]);

        // MatMul is not folded because MatMul evaluation is not implemented
        assert!(matches!(
            graph.get_node(2).unwrap().op,
            OpKind::MatMul { .. }
        ));
    }

    #[test]
    fn test_constant_folding_preserves_shape() {
        // Test with actual constant data to verify shape preservation
        let mut op_graph = OperationGraph::new();
        op_graph.add_node(OpNode::new(0, OpKind::Constant, vec![4, 8], DType::F32));
        op_graph.add_constant_for_node(0, ConstantData::F32(vec![1.0; 32]));
        op_graph.add_node(OpNode::new(1, OpKind::Relu, vec![4, 8], DType::F32));
        op_graph.add_edge(0, 1);

        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();
        constant_folding(&mut graph, &op_graph.constants);

        // Shape should be preserved after folding
        let node = graph.get_node(1).unwrap();
        assert!(matches!(node.op, OpKind::Constant));
        assert_eq!(node.shape, vec![4, 8]);
        assert_eq!(node.dtype, DType::F32);
    }

    #[test]
    fn test_is_pure_for_folding() {
        assert!(OpKind::Add.is_pure());
        assert!(OpKind::Sub.is_pure());
        assert!(OpKind::Mul.is_pure());
        assert!(OpKind::Div.is_pure());
        assert!(OpKind::Sigmoid.is_pure());
        assert!(OpKind::Relu.is_pure());
        assert!(OpKind::MatMul { m: 1, k: 1, n: 1 }.is_pure());
        assert!(OpKind::Sum.is_pure());

        assert!(!OpKind::Load.is_pure());
        assert!(!OpKind::Store.is_pure());
        assert!(!OpKind::CallLayer { layer_id: 0 }.is_pure());
        assert!(!OpKind::Input.is_pure());
        assert!(!OpKind::Output.is_pure());
        assert!(!OpKind::Constant.is_pure());
    }

    #[test]
    fn test_transpose_evaluation() {
        // Test 2D transpose: [2, 3] -> [3, 2]
        let data = ConstantData::F32(vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0]);
        let shape = vec![2, 3];
        let perm = vec![1, 0];

        let result = evaluate_transpose(&data, &shape, &perm).unwrap();
        if let ConstantData::F32(values) = result {
            // Original: [[1, 2, 3], [4, 5, 6]]
            // Transposed: [[1, 4], [2, 5], [3, 6]]
            assert_eq!(values, vec![1.0, 4.0, 2.0, 5.0, 3.0, 6.0]);
        } else {
            panic!("Expected F32 result");
        }
    }

    #[test]
    #[allow(clippy::cast_precision_loss)]
    fn test_transpose_evaluation_nd() {
        // Test 3D transpose: [2, 3, 4] with perm [0, 2, 1] -> [2, 4, 3]
        let data: Vec<f32> = (1..=24).map(|x| x as f32).collect();
        let shape = vec![2, 3, 4];
        let perm = vec![0, 2, 1];

        let result = evaluate_transpose(&ConstantData::F32(data), &shape, &perm).unwrap();
        if let ConstantData::F32(values) = result {
            // Verify output has same number of elements
            assert_eq!(values.len(), 24);
            // Verify first element is unchanged (all permutations start at 0)
            assert!((values[0] - 1.0).abs() < f32::EPSILON);
        } else {
            panic!("Expected F32 result");
        }
    }

    #[test]
    fn test_relu_evaluation() {
        let data = ConstantData::F32(vec![-1.0, 0.0, 1.0, -2.0, 3.0]);
        let result = evaluate_relu(&data).unwrap();
        if let ConstantData::F32(values) = result {
            assert_eq!(values, vec![0.0, 0.0, 1.0, 0.0, 3.0]);
        } else {
            panic!("Expected F32 result");
        }
    }

    #[test]
    fn test_constant_folding_with_data() {
        // Test that folding a Constant -> Relu produces computed data
        let mut op_graph = OperationGraph::new();
        op_graph.add_node(OpNode::new(0, OpKind::Constant, vec![4], DType::F32));
        op_graph.add_constant_for_node(0, ConstantData::F32(vec![-1.0, 0.0, 1.0, 2.0]));
        op_graph.add_node(OpNode::new(1, OpKind::Relu, vec![4], DType::F32));
        op_graph.add_edge(0, 1);

        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();
        constant_folding(&mut graph, &op_graph.constants);

        // Relu should be folded and have computed data
        assert!(matches!(graph.get_node(1).unwrap().op, OpKind::Constant));
        let folded = graph.get_folded_constant(1).unwrap();
        if let ConstantData::F32(values) = folded {
            assert_eq!(*values, vec![0.0, 0.0, 1.0, 2.0]);
        } else {
            panic!("Expected F32 folded data");
        }
    }

    #[test]
    fn test_constant_folding_transpose_with_data() {
        // Test that folding a Constant -> Transpose produces correctly transposed data
        let mut op_graph = OperationGraph::new();
        op_graph.add_node(OpNode::new(0, OpKind::Constant, vec![2, 3], DType::F32));
        op_graph.add_constant_for_node(0, ConstantData::F32(vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0]));
        op_graph.add_node(OpNode::new(
            1,
            OpKind::Transpose { perm: vec![1, 0] },
            vec![3, 2],
            DType::F32,
        ));
        op_graph.add_edge(0, 1);

        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();
        constant_folding(&mut graph, &op_graph.constants);

        // Transpose should be folded and have transposed data
        assert!(matches!(graph.get_node(1).unwrap().op, OpKind::Constant));
        let folded = graph.get_folded_constant(1).unwrap();
        if let ConstantData::F32(values) = folded {
            // Original: [[1, 2, 3], [4, 5, 6]]
            // Transposed: [[1, 4], [2, 5], [3, 6]]
            assert_eq!(*values, vec![1.0, 4.0, 2.0, 5.0, 3.0, 6.0]);
        } else {
            panic!("Expected F32 folded data");
        }
    }

    #[test]
    fn test_sqrt_evaluation() {
        let data = ConstantData::F32(vec![0.0, 1.0, 4.0, 9.0, 16.0]);
        let result = evaluate_sqrt(&data).unwrap();
        if let ConstantData::F32(values) = result {
            let expected = [0.0, 1.0, 2.0, 3.0, 4.0];
            for (a, b) in values.iter().zip(expected.iter()) {
                assert!((a - b).abs() < 1e-6, "sqrt mismatch: {a} vs {b}");
            }
        } else {
            panic!("Expected F32 result");
        }
    }

    #[test]
    fn test_log_evaluation() {
        let data = ConstantData::F32(vec![1.0, std::f32::consts::E, 10.0]);
        let result = evaluate_log(&data).unwrap();
        if let ConstantData::F32(values) = result {
            assert!((values[0] - 0.0).abs() < 1e-6);
            assert!((values[1] - 1.0).abs() < 1e-6);
            assert!((values[2] - 10.0_f32.ln()).abs() < 1e-6);
        } else {
            panic!("Expected F32 result");
        }
    }

    #[test]
    fn test_exp_evaluation() {
        let data = ConstantData::F32(vec![0.0, 1.0, 2.0]);
        let result = evaluate_exp(&data).unwrap();
        if let ConstantData::F32(values) = result {
            assert!((values[0] - 1.0).abs() < 1e-6);
            assert!((values[1] - std::f32::consts::E).abs() < 1e-6);
            assert!((values[2] - (2.0_f32).exp()).abs() < 1e-6);
        } else {
            panic!("Expected F32 result");
        }
    }

    #[test]
    fn test_abs_evaluation() {
        let data = ConstantData::F32(vec![-3.0, -1.0, 0.0, 1.0, 3.0]);
        let result = evaluate_abs(&data).unwrap();
        if let ConstantData::F32(values) = result {
            assert_eq!(values, vec![3.0, 1.0, 0.0, 1.0, 3.0]);
        } else {
            panic!("Expected F32 result");
        }
    }

    #[test]
    fn test_constant_folding_sqrt_with_data() {
        let mut op_graph = OperationGraph::new();
        op_graph.add_node(OpNode::new(0, OpKind::Constant, vec![4], DType::F32));
        op_graph.add_constant_for_node(0, ConstantData::F32(vec![1.0, 4.0, 9.0, 16.0]));
        op_graph.add_node(OpNode::new(1, OpKind::Sqrt, vec![4], DType::F32));
        op_graph.add_edge(0, 1);

        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();
        constant_folding(&mut graph, &op_graph.constants);

        assert!(matches!(graph.get_node(1).unwrap().op, OpKind::Constant));
        let folded = graph.get_folded_constant(1).unwrap();
        if let ConstantData::F32(values) = folded {
            assert_eq!(*values, vec![1.0, 2.0, 3.0, 4.0]);
        } else {
            panic!("Expected F32 folded data");
        }
    }
}
