//! Benchmarks comparing Winograd convolution with cached filters vs Im2Col+GEMM.
//!
//! This benchmark verifies the performance benefit of pre-transforming Winograd
//! filters at compile time. The key insight is that Winograd filter transforms
//! are expensive (~O(n²) per filter), but the convolution itself uses 2.25x fewer
//! FLOPs than Im2Col+GEMM.
//!
//! With cached filters, Winograd should be significantly faster for 3x3 convolutions.

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use hologram_backend::cpu::simd_dispatch::SimdDispatcher;
use hologram_backend::cpu::winograd::{winograd_conv2d_f23, winograd_conv2d_f23_simd};
use hologram_backend::layout::WinogradVariant;
use hologram_backend::transform_cache::{FilterId, TransformCache};

/// Benchmark parameters for different tensor sizes.
struct ConvParams {
    name: &'static str,
    batch: usize,
    in_channels: usize,
    out_channels: usize,
    height: usize,
    width: usize,
}

const BENCH_PARAMS: &[ConvParams] = &[
    ConvParams {
        name: "small_c16h14w14",
        batch: 1,
        in_channels: 16,
        out_channels: 32,
        height: 14,
        width: 14,
    },
    ConvParams {
        name: "medium_c64h28w28",
        batch: 1,
        in_channels: 64,
        out_channels: 128,
        height: 28,
        width: 28,
    },
    ConvParams {
        name: "large_c128h56w56",
        batch: 1,
        in_channels: 128,
        out_channels: 256,
        height: 56,
        width: 56,
    },
];

/// Create input tensor with test values.
fn create_input(batch: usize, channels: usize, height: usize, width: usize) -> Vec<f32> {
    let size = batch * channels * height * width;
    (0..size).map(|i| (i % 17) as f32 * 0.1).collect()
}

/// Create 3x3 filter tensor with test values.
fn create_filter_3x3(out_channels: usize, in_channels: usize) -> Vec<f32> {
    let size = out_channels * in_channels * 3 * 3;
    (0..size).map(|i| ((i % 11) as f32 - 5.0) * 0.1).collect()
}

/// Benchmark Im2Col + GEMM convolution (current production path).
fn bench_im2col_gemm(c: &mut Criterion) {
    let mut group = c.benchmark_group("conv_im2col_gemm");
    let dispatcher = SimdDispatcher::new();

    for params in BENCH_PARAMS {
        let input = create_input(
            params.batch,
            params.in_channels,
            params.height,
            params.width,
        );
        let filter = create_filter_3x3(params.out_channels, params.in_channels);

        // 3x3 kernel, stride 1, padding 1 → same output size
        let out_height = params.height;
        let out_width = params.width;
        let output_size = params.batch * params.out_channels * out_height * out_width;
        let mut output = vec![0.0f32; output_size];

        let flops = params.batch
            * params.out_channels
            * out_height
            * out_width
            * params.in_channels
            * 9
            * 2; // 3x3 = 9 muls + 9 adds

        group.throughput(Throughput::Elements(flops as u64));
        group.bench_with_input(
            BenchmarkId::new("im2col", params.name),
            &params,
            |b, params| {
                b.iter(|| {
                    dispatcher
                        .conv2d_f32(
                            black_box(&mut output),
                            black_box(&input),
                            black_box(&filter),
                            None,
                            params.batch,
                            params.in_channels,
                            params.height,
                            params.width,
                            params.out_channels,
                            3, // kernel_h
                            3, // kernel_w
                            out_height,
                            out_width,
                            1, // stride_h
                            1, // stride_w
                            1, // pad_h
                            1, // pad_w
                        )
                        .unwrap()
                })
            },
        );
    }

    group.finish();
}

/// Benchmark Winograd convolution with pre-cached filters (scalar version).
fn bench_winograd_cached(c: &mut Criterion) {
    let mut group = c.benchmark_group("conv_winograd_scalar");

    for params in BENCH_PARAMS {
        let input = create_input(
            params.batch,
            params.in_channels,
            params.height,
            params.width,
        );
        let filter = create_filter_3x3(params.out_channels, params.in_channels);

        // Pre-transform filter (simulating compile-time caching)
        let mut cache = TransformCache::new();
        cache.add_winograd_filter(
            FilterId(0),
            &filter,
            [params.out_channels, params.in_channels, 3, 3],
            WinogradVariant::F23,
        );
        let prepacked = cache.get_winograd_filter(FilterId(0)).unwrap();

        // 3x3 kernel, stride 1, padding 1 → same output size
        let out_height = params.height;
        let out_width = params.width;
        let output_size = params.batch * params.out_channels * out_height * out_width;
        let mut output = vec![0.0f32; output_size];

        // Winograd uses 2.25x fewer FLOPs
        let flops = (params.batch
            * params.out_channels
            * out_height
            * out_width
            * params.in_channels
            * 9
            * 2) as f64
            / 2.25;

        group.throughput(Throughput::Elements(flops as u64));
        group.bench_with_input(
            BenchmarkId::new("scalar", params.name),
            &params,
            |b, params| {
                b.iter(|| {
                    winograd_conv2d_f23(
                        black_box(&mut output),
                        black_box(&input),
                        black_box(prepacked),
                        None, // no bias
                        params.batch,
                        params.in_channels,
                        params.height,
                        params.width,
                        params.out_channels,
                        out_height,
                        out_width,
                        1, // pad_h
                        1, // pad_w
                    )
                })
            },
        );
    }

    group.finish();
}

/// Benchmark SIMD-optimized Winograd convolution.
fn bench_winograd_simd(c: &mut Criterion) {
    let mut group = c.benchmark_group("conv_winograd_simd");

    for params in BENCH_PARAMS {
        let input = create_input(
            params.batch,
            params.in_channels,
            params.height,
            params.width,
        );
        let filter = create_filter_3x3(params.out_channels, params.in_channels);

        // Pre-transform filter (simulating compile-time caching)
        let mut cache = TransformCache::new();
        cache.add_winograd_filter(
            FilterId(0),
            &filter,
            [params.out_channels, params.in_channels, 3, 3],
            WinogradVariant::F23,
        );
        let prepacked = cache.get_winograd_filter(FilterId(0)).unwrap();

        // 3x3 kernel, stride 1, padding 1 → same output size
        let out_height = params.height;
        let out_width = params.width;
        let output_size = params.batch * params.out_channels * out_height * out_width;
        let mut output = vec![0.0f32; output_size];

        // Winograd uses 2.25x fewer FLOPs
        let flops = (params.batch
            * params.out_channels
            * out_height
            * out_width
            * params.in_channels
            * 9
            * 2) as f64
            / 2.25;

        group.throughput(Throughput::Elements(flops as u64));
        group.bench_with_input(
            BenchmarkId::new("simd", params.name),
            &params,
            |b, params| {
                b.iter(|| {
                    winograd_conv2d_f23_simd(
                        black_box(&mut output),
                        black_box(&input),
                        black_box(prepacked),
                        None, // no bias
                        params.batch,
                        params.in_channels,
                        params.height,
                        params.width,
                        params.out_channels,
                        out_height,
                        out_width,
                        1, // pad_h
                        1, // pad_w
                    )
                })
            },
        );
    }

    group.finish();
}

/// Benchmark Winograd with filter transform on every call (the slow path).
fn bench_winograd_uncached(c: &mut Criterion) {
    let mut group = c.benchmark_group("conv_winograd_uncached");

    for params in BENCH_PARAMS {
        let input = create_input(
            params.batch,
            params.in_channels,
            params.height,
            params.width,
        );
        let filter = create_filter_3x3(params.out_channels, params.in_channels);

        // 3x3 kernel, stride 1, padding 1 → same output size
        let out_height = params.height;
        let out_width = params.width;
        let output_size = params.batch * params.out_channels * out_height * out_width;
        let mut output = vec![0.0f32; output_size];

        group.bench_with_input(
            BenchmarkId::new("winograd_uncached", params.name),
            &params,
            |b, params| {
                b.iter(|| {
                    // Create cache and transform filter on every iteration
                    let mut cache = TransformCache::new();
                    cache.add_winograd_filter(
                        FilterId(0),
                        &filter,
                        [params.out_channels, params.in_channels, 3, 3],
                        WinogradVariant::F23,
                    );
                    let prepacked = cache.get_winograd_filter(FilterId(0)).unwrap();

                    winograd_conv2d_f23(
                        black_box(&mut output),
                        black_box(&input),
                        black_box(prepacked),
                        None,
                        params.batch,
                        params.in_channels,
                        params.height,
                        params.width,
                        params.out_channels,
                        out_height,
                        out_width,
                        1,
                        1,
                    )
                })
            },
        );
    }

    group.finish();
}

/// Benchmark filter transform alone to show the overhead being cached.
fn bench_filter_transform(c: &mut Criterion) {
    let mut group = c.benchmark_group("winograd_filter_transform");

    for params in BENCH_PARAMS {
        let filter = create_filter_3x3(params.out_channels, params.in_channels);
        let filter_elements = params.out_channels * params.in_channels * 9;

        group.throughput(Throughput::Elements(filter_elements as u64));
        group.bench_with_input(
            BenchmarkId::new("transform", params.name),
            &params,
            |b, params| {
                b.iter(|| {
                    let mut cache = TransformCache::new();
                    cache.add_winograd_filter(
                        FilterId(0),
                        black_box(&filter),
                        [params.out_channels, params.in_channels, 3, 3],
                        WinogradVariant::F23,
                    );
                    // Consume the cache to prevent returning a reference
                    let has_filter = cache.get_winograd_filter(FilterId(0)).is_some();
                    black_box(has_filter)
                })
            },
        );
    }

    group.finish();
}

/// Benchmark reconstruct PrepackedFilter from bytes (used by executor).
fn bench_prepacked_from_bytes(c: &mut Criterion) {
    use hologram_backend::cpu::winograd::prepacked_filter_from_bytes;

    let mut group = c.benchmark_group("prepacked_from_bytes");

    for params in BENCH_PARAMS {
        let filter = create_filter_3x3(params.out_channels, params.in_channels);

        // Pre-transform and get bytes
        let mut cache = TransformCache::new();
        cache.add_winograd_filter(
            FilterId(0),
            &filter,
            [params.out_channels, params.in_channels, 3, 3],
            WinogradVariant::F23,
        );
        let prepacked = cache.get_winograd_filter(FilterId(0)).unwrap();

        // Simulate serialized bytes from PrepackedFilter data
        let bytes: Vec<u8> = prepacked
            .data
            .iter()
            .flat_map(|f: &f32| f.to_le_bytes())
            .collect();

        group.bench_with_input(
            BenchmarkId::new("from_bytes", params.name),
            &params,
            |b, params| {
                b.iter(|| {
                    prepacked_filter_from_bytes(
                        black_box(&bytes),
                        params.out_channels,
                        params.in_channels,
                        WinogradVariant::F23,
                    )
                })
            },
        );
    }

    group.finish();
}

/// Benchmark the optimized Winograd with V_cache and parallelization.
fn bench_winograd_optimized(c: &mut Criterion) {
    use hologram_backend::cpu::winograd::winograd_conv2d_f23_optimized;

    let mut group = c.benchmark_group("conv_winograd_optimized");

    for params in BENCH_PARAMS {
        let input = create_input(
            params.batch,
            params.in_channels,
            params.height,
            params.width,
        );
        let filter = create_filter_3x3(params.out_channels, params.in_channels);

        // Pre-transform filter (simulating compile-time caching)
        let mut cache = TransformCache::new();
        cache.add_winograd_filter(
            FilterId(0),
            &filter,
            [params.out_channels, params.in_channels, 3, 3],
            WinogradVariant::F23,
        );
        let prepacked = cache.get_winograd_filter(FilterId(0)).unwrap();

        // 3x3 kernel, stride 1, padding 1 → same output size
        let out_height = params.height;
        let out_width = params.width;
        let output_size = params.batch * params.out_channels * out_height * out_width;
        let mut output = vec![0.0f32; output_size];

        // Winograd uses 2.25x fewer FLOPs
        let flops = (params.batch
            * params.out_channels
            * out_height
            * out_width
            * params.in_channels
            * 9
            * 2) as f64
            / 2.25;

        group.throughput(Throughput::Elements(flops as u64));
        group.bench_with_input(
            BenchmarkId::new("optimized", params.name),
            &params,
            |b, params| {
                b.iter(|| {
                    winograd_conv2d_f23_optimized(
                        black_box(&mut output),
                        black_box(&input),
                        black_box(prepacked),
                        None, // no bias
                        params.batch,
                        params.in_channels,
                        params.height,
                        params.width,
                        params.out_channels,
                        out_height,
                        out_width,
                        1, // pad_h
                        1, // pad_w
                    )
                })
            },
        );
    }

    group.finish();
}

criterion_group!(
    benches,
    bench_im2col_gemm,
    bench_winograd_cached,
    bench_winograd_simd,
    bench_winograd_optimized,
    bench_winograd_uncached,
    bench_filter_transform,
    bench_prepacked_from_bytes,
);

criterion_main!(benches);
