//! Backend capabilities for compile-time planning.
//!
//! This module defines static capability data that backends expose to the compiler.
//! Capabilities are pure data, serializable, and usable during compile-time planning.
//! They must NEVER be queried inside hot loops.
//!
//! # Design Principles
//!
//! - All data is static and const-constructible where possible
//! - Capabilities are immutable after backend initialization
//! - Used only during compilation/planning phase, never at runtime
//! - Enables compile-time kernel selection and optimization decisions

use crate::BackendType;
use hologram_isa::Type;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Supported memory layouts for tensors.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum MemoryLayout {
    /// Row-major (C-style) layout.
    RowMajor,
    /// Column-major (Fortran-style) layout.
    ColMajor,
    /// Tiled layout for cache efficiency.
    Tiled,
    /// Packed Winograd transform layout.
    PackedWinograd,
    /// Im2Col layout for convolution.
    Im2Col,
    /// Interleaved for SIMD operations.
    Interleaved,
}

/// Supported convolution modes.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum ConvMode {
    /// Direct convolution (sliding window).
    Direct,
    /// Im2Col + GEMM approach.
    Im2Col,
    /// Winograd F(2,3) transform.
    WinogradF23,
    /// Winograd F(4,3) transform.
    WinogradF43,
    /// FFT-based convolution.
    Fft,
}

/// Algorithm family support flags.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct AlgorithmSupport {
    /// Strassen matrix multiplication (O(n^2.81)).
    pub strassen: bool,
    /// Winograd F(2,3) convolution.
    pub winograd_f23: bool,
    /// Winograd F(4,3) convolution.
    pub winograd_f43: bool,
    /// Im2Col convolution.
    pub im2col: bool,
    /// FFT-based operations.
    pub fft: bool,
}

impl AlgorithmSupport {
    /// Create with all algorithms supported.
    pub const fn all() -> Self {
        Self {
            strassen: true,
            winograd_f23: true,
            winograd_f43: true,
            im2col: true,
            fft: true,
        }
    }

    /// Create with no algorithms supported (basic only).
    pub const fn none() -> Self {
        Self {
            strassen: false,
            winograd_f23: false,
            winograd_f43: false,
            im2col: false,
            fft: false,
        }
    }

    /// Create for CPU backend.
    #[cfg(feature = "fft")]
    pub const fn cpu() -> Self {
        Self {
            strassen: true,
            winograd_f23: true,
            winograd_f43: true,
            im2col: true,
            fft: true,
        }
    }

    /// Create for CPU backend (without FFT feature).
    #[cfg(not(feature = "fft"))]
    pub const fn cpu() -> Self {
        Self {
            strassen: true,
            winograd_f23: true,
            winograd_f43: true,
            im2col: true,
            fft: false,
        }
    }
}

/// Workspace ownership model.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum WorkspaceOwnership {
    /// Workspace is managed by the caller.
    CallerManaged,
    /// Workspace is managed by the backend.
    BackendManaged,
    /// Shared pool managed by runtime.
    PoolManaged,
}

/// Static capability data for a backend.
///
/// This struct contains all compile-time visible information about a backend's
/// capabilities. It is used by the compiler to:
/// - Select appropriate kernels
/// - Choose algorithm variants
/// - Plan memory layouts
/// - Size workspace buffers
///
/// # Thread Safety
///
/// `BackendCapabilities` is `Send + Sync` and can be safely shared across threads.
/// All fields are immutable after construction.
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct BackendCapabilities {
    /// Backend type identifier.
    pub backend_type: BackendType,

    /// Supported data types for computation.
    pub supported_dtypes: &'static [Type],

    /// Supported memory layouts.
    pub supported_layouts: &'static [MemoryLayout],

    /// Supported convolution modes.
    pub supported_conv_modes: &'static [ConvMode],

    /// Algorithm family support flags.
    pub algorithm_support: AlgorithmSupport,

    /// SIMD vector width in floats (e.g., 8 for AVX2, 16 for AVX-512, 4 for NEON).
    pub vector_width: usize,

    /// GPU warp/wavefront size (None for CPU).
    pub warp_size: Option<usize>,

    /// Workspace ownership model.
    pub workspace_ownership: WorkspaceOwnership,

    /// Maximum shared memory per block in bytes (GPU only).
    pub max_shared_memory: Option<usize>,

    /// Maximum threads per block (GPU only).
    pub max_threads_per_block: Option<usize>,

    /// Number of compute units (CPU cores or GPU SMs).
    pub compute_units: usize,

    /// L1 cache size per compute unit in bytes.
    pub l1_cache_size: usize,

    /// L2 cache size in bytes.
    pub l2_cache_size: usize,

    /// Memory bandwidth in GB/s (approximate).
    pub memory_bandwidth_gbps: f32,

    /// Peak GFLOPS for F32 operations (approximate).
    pub peak_gflops_f32: f32,

    /// Whether FMA (fused multiply-add) is supported.
    pub has_fma: bool,

    /// Whether native half-precision (F16) is supported.
    pub has_native_f16: bool,

    /// Preferred tile sizes for cache blocking.
    pub preferred_tile_m: usize,
    /// Preferred tile size for N dimension.
    pub preferred_tile_n: usize,
    /// Preferred tile size for K dimension.
    pub preferred_tile_k: usize,
}

impl BackendCapabilities {
    /// Default data types supported by all backends.
    pub const DEFAULT_DTYPES: &'static [Type] = &[Type::F32, Type::F64, Type::I32, Type::I64];

    /// Default layouts supported by CPU backends.
    pub const DEFAULT_LAYOUTS: &'static [MemoryLayout] = &[
        MemoryLayout::RowMajor,
        MemoryLayout::ColMajor,
        MemoryLayout::Tiled,
    ];

    /// Default conv modes for CPU.
    pub const DEFAULT_CONV_MODES: &'static [ConvMode] =
        &[ConvMode::Direct, ConvMode::Im2Col, ConvMode::WinogradF23];

    /// Create capabilities for the CPU backend with detected features.
    pub fn cpu() -> Self {
        let (vector_width, has_fma) = detect_cpu_simd_features();
        let compute_units = num_cpus();

        Self {
            backend_type: BackendType::Cpu,
            supported_dtypes: Self::DEFAULT_DTYPES,
            supported_layouts: Self::DEFAULT_LAYOUTS,
            supported_conv_modes: Self::DEFAULT_CONV_MODES,
            algorithm_support: AlgorithmSupport::cpu(),
            vector_width,
            warp_size: None,
            workspace_ownership: WorkspaceOwnership::CallerManaged,
            max_shared_memory: None,
            max_threads_per_block: None,
            compute_units,
            l1_cache_size: 32 * 1024,  // 32KB typical L1
            l2_cache_size: 256 * 1024, // 256KB typical L2 per core
            memory_bandwidth_gbps: 50.0,
            peak_gflops_f32: compute_peak_gflops(vector_width, compute_units),
            has_fma,
            has_native_f16: false, // Most CPUs don't have native F16
            preferred_tile_m: compute_preferred_tile_m(vector_width),
            preferred_tile_n: compute_preferred_tile_n(vector_width),
            preferred_tile_k: 256,
        }
    }

    /// Create capabilities for a CUDA backend.
    pub fn cuda(_device_id: usize) -> Self {
        Self {
            backend_type: BackendType::Cuda,
            supported_dtypes: &[Type::F32, Type::F64, Type::F16, Type::I32],
            supported_layouts: &[
                MemoryLayout::RowMajor,
                MemoryLayout::ColMajor,
                MemoryLayout::Tiled,
            ],
            supported_conv_modes: &[ConvMode::Direct, ConvMode::Im2Col, ConvMode::WinogradF23],
            algorithm_support: AlgorithmSupport {
                strassen: false, // Strassen not efficient on GPU
                winograd_f23: true,
                winograd_f43: true,
                im2col: true,
                fft: true,
            },
            vector_width: 32, // CUDA operates on warps
            warp_size: Some(32),
            workspace_ownership: WorkspaceOwnership::BackendManaged,
            max_shared_memory: Some(48 * 1024), // 48KB typical
            max_threads_per_block: Some(1024),
            compute_units: 80, // RTX 3080 SMs - typical high-end consumer GPU
            l1_cache_size: 128 * 1024,
            l2_cache_size: 6 * 1024 * 1024, // 6MB typical
            memory_bandwidth_gbps: 900.0,   // High-end GPU
            peak_gflops_f32: 10000.0,       // ~30 TFLOPS theoretical for RTX 3080
            has_fma: true,
            has_native_f16: true,
            preferred_tile_m: 128,
            preferred_tile_n: 128,
            preferred_tile_k: 32,
        }
    }

    /// Create capabilities for a Metal backend.
    pub fn metal() -> Self {
        Self {
            backend_type: BackendType::Metal,
            supported_dtypes: &[Type::F32, Type::F16, Type::I32],
            supported_layouts: &[MemoryLayout::RowMajor, MemoryLayout::Tiled],
            supported_conv_modes: &[ConvMode::Direct, ConvMode::Im2Col],
            algorithm_support: AlgorithmSupport {
                strassen: false,
                winograd_f23: true,
                winograd_f43: false,
                im2col: true,
                fft: false,
            },
            vector_width: 32, // SIMD group size
            warp_size: Some(32),
            workspace_ownership: WorkspaceOwnership::BackendManaged,
            max_shared_memory: Some(32 * 1024),
            max_threads_per_block: Some(1024),
            compute_units: 8, // M1 GPU cores - base Apple Silicon configuration
            l1_cache_size: 64 * 1024,
            l2_cache_size: 4 * 1024 * 1024,
            memory_bandwidth_gbps: 400.0, // M1/M2 typical
            peak_gflops_f32: 2600.0,      // M1 Max approximate
            has_fma: true,
            has_native_f16: true,
            preferred_tile_m: 64,
            preferred_tile_n: 64,
            preferred_tile_k: 32,
        }
    }

    /// Create capabilities for a WebGPU backend.
    pub fn webgpu() -> Self {
        Self {
            backend_type: BackendType::WebGpu,
            supported_dtypes: &[Type::F32, Type::I32],
            supported_layouts: &[MemoryLayout::RowMajor],
            supported_conv_modes: &[ConvMode::Direct],
            algorithm_support: AlgorithmSupport::none(),
            vector_width: 4, // Minimum guaranteed
            warp_size: None, // Varies by device
            workspace_ownership: WorkspaceOwnership::BackendManaged,
            max_shared_memory: Some(16 * 1024), // Conservative
            max_threads_per_block: Some(256),
            compute_units: 1, // Unknown
            l1_cache_size: 16 * 1024,
            l2_cache_size: 1024 * 1024,
            memory_bandwidth_gbps: 100.0,
            peak_gflops_f32: 1000.0,
            has_fma: false, // Not guaranteed
            has_native_f16: false,
            preferred_tile_m: 32,
            preferred_tile_n: 32,
            preferred_tile_k: 32,
        }
    }

    /// Create capabilities for a Wasm backend (CPU/interpreter based).
    pub fn wasm() -> Self {
        Self {
            backend_type: BackendType::Wasm,
            supported_dtypes: Self::DEFAULT_DTYPES,
            supported_layouts: Self::DEFAULT_LAYOUTS,
            supported_conv_modes: Self::DEFAULT_CONV_MODES,
            algorithm_support: AlgorithmSupport::cpu(),
            vector_width: 4,
            warp_size: None,
            workspace_ownership: WorkspaceOwnership::CallerManaged,
            max_shared_memory: None,
            max_threads_per_block: None,
            compute_units: num_cpus(),
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            memory_bandwidth_gbps: 10.0,
            peak_gflops_f32: 50.0,
            has_fma: false,
            has_native_f16: false,
            preferred_tile_m: 32,
            preferred_tile_n: 32,
            preferred_tile_k: 64,
        }
    }

    /// Check if a data type is supported.
    pub fn supports_dtype(&self, dtype: Type) -> bool {
        self.supported_dtypes.contains(&dtype)
    }

    /// Check if a memory layout is supported.
    pub fn supports_layout(&self, layout: MemoryLayout) -> bool {
        self.supported_layouts.contains(&layout)
    }

    /// Check if a convolution mode is supported.
    pub fn supports_conv_mode(&self, mode: ConvMode) -> bool {
        self.supported_conv_modes.contains(&mode)
    }

    /// Check if Strassen algorithm is beneficial for given matrix size.
    pub fn should_use_strassen(&self, m: usize, k: usize, n: usize) -> bool {
        if !self.algorithm_support.strassen {
            return false;
        }
        // Strassen is beneficial for large, roughly square matrices
        let min_dim = m.min(k).min(n);
        let max_dim = m.max(k).max(n);
        min_dim >= 512 && max_dim <= min_dim * 2
    }

    /// Check if Winograd is beneficial for given convolution.
    pub fn should_use_winograd(&self, kernel_h: usize, kernel_w: usize) -> Option<ConvMode> {
        if kernel_h == 3 && kernel_w == 3 {
            if self.algorithm_support.winograd_f43 {
                Some(ConvMode::WinogradF43)
            } else if self.algorithm_support.winograd_f23 {
                Some(ConvMode::WinogradF23)
            } else {
                None
            }
        } else {
            None
        }
    }

    /// Get optimal tile configuration for given operation size.
    pub fn optimal_tiles(&self, m: usize, n: usize, k: usize) -> (usize, usize, usize) {
        let tile_m = self.preferred_tile_m.min(m);
        let tile_n = self.preferred_tile_n.min(n);
        let tile_k = self.preferred_tile_k.min(k);
        (tile_m, tile_n, tile_k)
    }
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/// Detect CPU SIMD features and return (vector_width, has_fma).
#[allow(unreachable_code)]
fn detect_cpu_simd_features() -> (usize, bool) {
    #[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
    {
        if is_x86_feature_detected!("avx512f") {
            return (16, true);
        }
        if is_x86_feature_detected!("avx2") && is_x86_feature_detected!("fma") {
            return (8, true);
        }
        if is_x86_feature_detected!("avx2") {
            return (8, false);
        }
        if is_x86_feature_detected!("sse4.2") {
            return (4, false);
        }
    }

    #[cfg(target_arch = "aarch64")]
    {
        // NEON is always available on aarch64
        return (4, true);
    }

    // Fallback
    (1, false)
}

/// Get number of CPU cores.
fn num_cpus() -> usize {
    std::thread::available_parallelism()
        .map(|p| p.get())
        .unwrap_or(1)
}

/// Compute approximate peak GFLOPS.
fn compute_peak_gflops(vector_width: usize, cores: usize) -> f32 {
    // Assume 2 FMA units per core at 3 GHz
    let ops_per_cycle = vector_width * 2 * 2; // FMA = 2 ops
    let ghz = 3.0;
    (ops_per_cycle * cores) as f32 * ghz
}

/// Compute preferred M tile size based on vector width.
fn compute_preferred_tile_m(vector_width: usize) -> usize {
    match vector_width {
        16 => 96, // AVX-512
        8 => 72,  // AVX2
        4 => 64,  // SSE/NEON
        _ => 64,  // Scalar
    }
}

/// Compute preferred N tile size based on vector width.
fn compute_preferred_tile_n(vector_width: usize) -> usize {
    match vector_width {
        16 => 256, // AVX-512
        8 => 256,  // AVX2
        4 => 128,  // SSE/NEON
        _ => 64,   // Scalar
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cpu_capabilities() {
        let caps = BackendCapabilities::cpu();
        assert_eq!(caps.backend_type, BackendType::Cpu);
        assert!(caps.supports_dtype(Type::F32));
        assert!(caps.supports_layout(MemoryLayout::RowMajor));
        assert!(caps.warp_size.is_none());
    }

    #[test]
    fn test_cuda_capabilities() {
        let caps = BackendCapabilities::cuda(0);
        assert_eq!(caps.backend_type, BackendType::Cuda);
        assert_eq!(caps.warp_size, Some(32));
        assert!(caps.has_native_f16);
    }

    #[test]
    fn test_algorithm_support() {
        let support = AlgorithmSupport::cpu();
        assert!(support.strassen);
        assert!(support.winograd_f23);
        #[cfg(feature = "fft")]
        assert!(support.fft);
        #[cfg(not(feature = "fft"))]
        assert!(!support.fft);
    }

    #[test]
    fn test_strassen_decision() {
        let caps = BackendCapabilities::cpu();
        // Too small
        assert!(!caps.should_use_strassen(64, 64, 64));
        // Good size
        assert!(caps.should_use_strassen(1024, 1024, 1024));
        // Too rectangular
        assert!(!caps.should_use_strassen(1024, 1024, 128));
    }

    #[test]
    fn test_winograd_decision() {
        let caps = BackendCapabilities::cpu();
        // 3x3 kernel should use Winograd
        let result = caps.should_use_winograd(3, 3);
        assert!(result.is_some());
        // 5x5 kernel should not use Winograd
        assert!(caps.should_use_winograd(5, 5).is_none());
    }

    #[test]
    fn test_optimal_tiles() {
        let caps = BackendCapabilities::cpu();
        let (tm, tn, tk) = caps.optimal_tiles(1024, 1024, 1024);
        assert!(tm > 0 && tm <= 1024);
        assert!(tn > 0 && tn <= 1024);
        assert!(tk > 0 && tk <= 1024);
    }
}
