/**
 * Hologram UI Compatibility Layer — Barrel Export
 * ═══════════════════════════════════════════════
 *
 * On merge: delete entire compat/ folder, update imports to hologram-ui.
 */

export { P } from "./palette";
export {
  useAttentionMode,
  useScreenContext,
  useFocusGate,
  type AttentionState,
  type ScreenContextDigest,
  type ContextBeacon,
  type BeaconContentType,
} from "./hooks";
export { singleProofHash, type ProofResult } from "./uor-canonical";
export { supabaseStub, lovableStub } from "./supabase-stub";
