//! Error types for the schema server.

use axum::{
    http::StatusCode,
    response::{IntoResponse, Response},
    Json,
};
use serde::Serialize;
use thiserror::Error;

/// Server error type.
#[derive(Debug, Error)]
pub enum ServerError {
    #[error("Schema not found: {0}")]
    SchemaNotFound(String),

    #[error("Entity not found: {0}")]
    EntityNotFound(String),

    #[error("Taxon not found: {0}")]
    TaxonNotFound(u8),

    #[error("Constant not found: {0}")]
    ConstantNotFound(String),

    #[error("Domain not found: {0}")]
    DomainNotFound(String),

    #[error("Gauge level not found: {0}")]
    GaugeLevelNotFound(usize),

    #[error("Validation error: {0}")]
    ValidationError(String),

    #[error("Immutable constant: {0}")]
    ImmutableConstant(String),

    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),
}

/// API error response body.
#[derive(Debug, Serialize)]
struct ErrorResponse {
    error: String,
    message: String,
}

impl IntoResponse for ServerError {
    fn into_response(self) -> Response {
        let (status, error_type) = match &self {
            ServerError::SchemaNotFound(_) => (StatusCode::NOT_FOUND, "schema_not_found"),
            ServerError::EntityNotFound(_) => (StatusCode::NOT_FOUND, "entity_not_found"),
            ServerError::TaxonNotFound(_) => (StatusCode::NOT_FOUND, "taxon_not_found"),
            ServerError::ConstantNotFound(_) => (StatusCode::NOT_FOUND, "constant_not_found"),
            ServerError::DomainNotFound(_) => (StatusCode::NOT_FOUND, "domain_not_found"),
            ServerError::GaugeLevelNotFound(_) => (StatusCode::NOT_FOUND, "gauge_level_not_found"),
            ServerError::ValidationError(_) => (StatusCode::BAD_REQUEST, "validation_error"),
            ServerError::ImmutableConstant(_) => (StatusCode::BAD_REQUEST, "immutable_constant"),
            ServerError::Io(_) => (StatusCode::INTERNAL_SERVER_ERROR, "io_error"),
            ServerError::Json(_) => (StatusCode::INTERNAL_SERVER_ERROR, "json_error"),
        };

        let body = ErrorResponse {
            error: error_type.to_string(),
            message: self.to_string(),
        };

        (status, Json(body)).into_response()
    }
}

/// Result type alias for server operations.
pub type Result<T> = std::result::Result<T, ServerError>;
