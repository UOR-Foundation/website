//! Benchmarks for instruction dispatch overhead.
//!
//! Measures the cost of dispatching individual ISA instructions through
//! the unified dispatch trait.

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};

use hologram_backend::backends::cpu::{BufferManager, ExecutionContext};
use hologram_backend::backends::ExecuteOn;
use hologram_holo::types::{BufferMetadata, BufferType};
use hologram_holo::IsaInstruction;

/// Helper to create f32 test data as bytes.
fn make_f32_data(size: usize, seed: f32) -> Vec<u8> {
    let floats: Vec<f32> = (0..size).map(|i| seed + i as f32 * 0.1).collect();
    floats.iter().flat_map(|f| f.to_ne_bytes()).collect()
}

/// Helper to create buffer metadata.
fn make_metadata(types: &[BufferType], sizes: &[usize]) -> Vec<BufferMetadata> {
    types
        .iter()
        .zip(sizes.iter())
        .map(|(&bt, &sz)| BufferMetadata::new(sz, bt))
        .collect()
}

/// Helper to create node_buffer_map (simple 1:1 mapping).
#[allow(clippy::cast_possible_truncation)]
fn make_node_map(count: usize) -> Vec<Option<u32>> {
    (0..count).map(|i| Some(i as u32)).collect()
}

/// Benchmark dispatch overhead for arithmetic operations.
fn bench_dispatch_arithmetic(c: &mut Criterion) {
    let mut group = c.benchmark_group("dispatch/arithmetic");

    for size in [256, 1024, 4096] {
        group.throughput(Throughput::Elements(size as u64));

        let byte_size = size * 4; // f32 = 4 bytes
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[byte_size, byte_size, byte_size],
        );
        let a = make_f32_data(size, 1.0);
        let b = make_f32_data(size, 2.0);
        let node_map = make_node_map(3);

        // Add instruction
        let add_instr = IsaInstruction::Add {
            dst: 2,
            a: 0,
            b: 1,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("add", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&a, &b];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&add_instr).execute(black_box(&mut ctx))
            })
        });

        // Sub instruction
        let sub_instr = IsaInstruction::Sub {
            dst: 2,
            a: 0,
            b: 1,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("sub", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&a, &b];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&sub_instr).execute(black_box(&mut ctx))
            })
        });

        // Mul instruction
        let mul_instr = IsaInstruction::Mul {
            dst: 2,
            a: 0,
            b: 1,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("mul", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&a, &b];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&mul_instr).execute(black_box(&mut ctx))
            })
        });
    }

    group.finish();
}

/// Benchmark dispatch overhead for activation functions.
fn bench_dispatch_activations(c: &mut Criterion) {
    let mut group = c.benchmark_group("dispatch/activations");

    for size in [256, 1024, 4096] {
        group.throughput(Throughput::Elements(size as u64));

        let byte_size = size * 4;
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Workspace],
            &[byte_size, byte_size],
        );
        let input = make_f32_data(size, -2.0);
        let node_map = make_node_map(2);

        // ReLU instruction
        let relu_instr = IsaInstruction::Relu {
            dst: 1,
            src: 0,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("relu", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&input];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&relu_instr).execute(black_box(&mut ctx))
            })
        });

        // Sigmoid instruction
        let sigmoid_instr = IsaInstruction::Sigmoid {
            dst: 1,
            src: 0,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("sigmoid", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&input];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&sigmoid_instr).execute(black_box(&mut ctx))
            })
        });

        // Tanh instruction
        let tanh_instr = IsaInstruction::Tanh {
            dst: 1,
            src: 0,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("tanh", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&input];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&tanh_instr).execute(black_box(&mut ctx))
            })
        });
    }

    group.finish();
}

/// Benchmark dispatch overhead for reductions.
fn bench_dispatch_reductions(c: &mut Criterion) {
    let mut group = c.benchmark_group("dispatch/reductions");

    for size in [256, 1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        let byte_size = size * 4;
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Workspace],
            &[byte_size, 4], // Output is single f32
        );
        let input = make_f32_data(size, 1.0);
        let node_map = make_node_map(2);

        // Sum instruction
        let sum_instr = IsaInstruction::Sum {
            dst: 1,
            src: 0,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("sum", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&input];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&sum_instr).execute(black_box(&mut ctx))
            })
        });

        // Max instruction
        let max_instr = IsaInstruction::Max {
            dst: 1,
            src: 0,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("max", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&input];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&max_instr).execute(black_box(&mut ctx))
            })
        });

        // Min instruction
        let min_instr = IsaInstruction::Min {
            dst: 1,
            src: 0,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("min", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&input];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&min_instr).execute(black_box(&mut ctx))
            })
        });
    }

    group.finish();
}

/// Benchmark dispatch overhead for matrix multiplication.
fn bench_dispatch_matmul(c: &mut Criterion) {
    let mut group = c.benchmark_group("dispatch/matmul");

    for (m, n, k) in [(16, 16, 16), (32, 32, 32), (64, 64, 64), (128, 128, 128)] {
        let flops = 2 * m * n * k;
        group.throughput(Throughput::Elements(flops as u64));

        let a_size = m * k * 4;
        let b_size = k * n * 4;
        let c_size = m * n * 4;

        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[a_size, b_size, c_size],
        );
        let a = make_f32_data(m * k, 1.0);
        let b = make_f32_data(k * n, 1.0);
        let node_map = make_node_map(3);

        let matmul_instr = IsaInstruction::MatMul {
            c: 2,
            a: 0,
            b: 1,
            m,
            k,
            n,
        };

        group.bench_with_input(
            BenchmarkId::new("matmul", format!("{m}x{n}x{k}")),
            &(m, n, k),
            |bench, _| {
                bench.iter(|| {
                    let inputs: &[&[u8]] = &[&a, &b];
                    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                    let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                    black_box(&matmul_instr).execute(black_box(&mut ctx))
                })
            },
        );
    }

    group.finish();
}

/// Benchmark dispatch overhead for categorical operations.
fn bench_dispatch_categorical(c: &mut Criterion) {
    let mut group = c.benchmark_group("dispatch/categorical");

    for size in [256, 1024, 4096] {
        group.throughput(Throughput::Elements(size as u64));

        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[size, size]);
        let input: Vec<u8> = (0..size).map(|i| (i % 256) as u8).collect();
        let node_map = make_node_map(2);

        // Lift instruction
        let lift_instr = IsaInstruction::Lift {
            dst: 1,
            src: 0,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("lift", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&input];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&lift_instr).execute(black_box(&mut ctx))
            })
        });

        // OrbitClassify instruction
        let orbit_instr = IsaInstruction::OrbitClassify {
            dst: 1,
            src: 0,
            count: size,
        };

        group.bench_with_input(
            BenchmarkId::new("orbit_classify", size),
            &size,
            |bench, _| {
                bench.iter(|| {
                    let inputs: &[&[u8]] = &[&input];
                    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                    let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                    black_box(&orbit_instr).execute(black_box(&mut ctx))
                })
            },
        );
    }

    // Ring operations need two inputs
    for size in [256, 1024, 4096] {
        group.throughput(Throughput::Elements(size as u64));

        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[size, size, size],
        );
        let input1: Vec<u8> = (0..size).map(|i| (i % 256) as u8).collect();
        let input2: Vec<u8> = (0..size).map(|i| ((i + 50) % 256) as u8).collect();
        let node_map = make_node_map(3);

        // RingAdd instruction
        let ring_add_instr = IsaInstruction::RingAdd {
            dst: 2,
            a: 0,
            b: 1,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("ring_add", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&input1, &input2];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&ring_add_instr).execute(black_box(&mut ctx))
            })
        });

        // RingMul instruction
        let ring_mul_instr = IsaInstruction::RingMul {
            dst: 2,
            a: 0,
            b: 1,
            count: size,
        };

        group.bench_with_input(BenchmarkId::new("ring_mul", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&input1, &input2];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&ring_mul_instr).execute(black_box(&mut ctx))
            })
        });
    }

    group.finish();
}

/// Benchmark memory operations.
fn bench_dispatch_memory(c: &mut Criterion) {
    let mut group = c.benchmark_group("dispatch/memory");

    for size in [256, 1024, 4096, 16384] {
        group.throughput(Throughput::Bytes(size as u64));

        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[size, size]);
        let source: Vec<u8> = (0..size).map(|i| (i % 256) as u8).collect();
        let node_map = make_node_map(2);

        // Copy instruction
        let copy_instr = IsaInstruction::Copy {
            dst: 1,
            src: 0,
            size,
        };

        group.bench_with_input(BenchmarkId::new("copy", size), &size, |bench, _| {
            bench.iter(|| {
                let inputs: &[&[u8]] = &[&source];
                let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                black_box(&copy_instr).execute(black_box(&mut ctx))
            })
        });
    }

    group.finish();
}

/// Benchmark SHA-256 dispatch: compiled pipeline vs direct library call.
fn bench_dispatch_sha256(c: &mut Criterion) {
    let mut group = c.benchmark_group("dispatch/sha256");

    for input_size in [32, 80, 256] {
        group.throughput(Throughput::Bytes(input_size as u64));

        // Input data
        let data: Vec<u8> = (0..input_size).map(|i| (i & 0xFF) as u8).collect();

        // Dispatch benchmark: IsaInstruction::Sha256 through ExecuteOn trait
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Workspace],
            &[input_size, 32],
        );
        let node_map = make_node_map(2);
        let sha_instr = IsaInstruction::Sha256 {
            dst: 1,
            src: 0,
            src_len: input_size,
        };

        group.bench_with_input(
            BenchmarkId::new("dispatch", input_size),
            &input_size,
            |bench, _| {
                bench.iter(|| {
                    let inputs: &[&[u8]] = &[&data];
                    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                    let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                    black_box(&sha_instr).execute(black_box(&mut ctx))
                })
            },
        );

        // Direct call benchmark: hologram_sha256::sha256() for comparison
        group.bench_with_input(
            BenchmarkId::new("direct", input_size),
            &input_size,
            |bench, _| bench.iter(|| black_box(hologram_sha256::sha256(black_box(&data)))),
        );

        // Double SHA-256 dispatch
        let dsha_instr = IsaInstruction::DoubleSha256 {
            dst: 1,
            src: 0,
            src_len: input_size,
        };

        group.bench_with_input(
            BenchmarkId::new("double_dispatch", input_size),
            &input_size,
            |bench, _| {
                bench.iter(|| {
                    let inputs: &[&[u8]] = &[&data];
                    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
                    let mut ctx = ExecutionContext::new(&mut manager, &node_map);
                    black_box(&dsha_instr).execute(black_box(&mut ctx))
                })
            },
        );

        // Direct double SHA-256 for comparison
        group.bench_with_input(
            BenchmarkId::new("double_direct", input_size),
            &input_size,
            |bench, _| bench.iter(|| black_box(hologram_sha256::double_sha256(black_box(&data)))),
        );
    }

    group.finish();
}

criterion_group!(
    benches,
    bench_dispatch_arithmetic,
    bench_dispatch_activations,
    bench_dispatch_reductions,
    bench_dispatch_matmul,
    bench_dispatch_categorical,
    bench_dispatch_memory,
    bench_dispatch_sha256,
);
criterion_main!(benches);
