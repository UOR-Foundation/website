//! Batch fusion pass.
//!
//! Converts sequential element-wise operations to SIMD batch operations
//! when the element count exceeds a threshold.

use crate::graph::CompileGraph;

/// Convert element-wise ops above threshold to batch operations.
///
/// This pass identifies element-wise operations with sufficient elements
/// and marks them for SIMD batch execution:
/// 1. Find all element-wise operations (Add, Sub, Mul, Div, activations)
/// 2. Calculate element count from shape
/// 3. If count >= threshold, mark for batch execution
///
/// The actual SIMD code generation is deferred to the backend.
/// This pass only identifies batch-eligible operations.
pub fn batch_fusion(graph: &mut CompileGraph, parallel_threshold: usize) {
    // Collect nodes to mark (can't mutate while iterating)
    let to_mark: Vec<(u32, usize)> = graph
        .nodes()
        .filter_map(|(id, node)| {
            if !node.op.is_element_wise() {
                return None;
            }

            let element_count = node.shape.iter().product();
            if element_count >= parallel_threshold {
                Some((id, element_count))
            } else {
                None
            }
        })
        .collect();

    // Mark nodes for batch execution
    for (id, element_count) in to_mark {
        if let Some(node) = graph.get_node_mut(id) {
            // Append batch marker to existing name or create new name
            let batch_marker = format!("batch:{element_count}");
            node.name = Some(match &node.name {
                Some(existing) => format!("{existing}|{batch_marker}"),
                None => batch_marker,
            });
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpKind, OpNode, OperationGraph};

    /// Returns the element count of a shape.
    fn element_count(shape: &[usize]) -> usize {
        shape.iter().product()
    }

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    #[test]
    fn test_batch_fusion_empty_graph() {
        let mut graph = make_graph(vec![], vec![]);
        batch_fusion(&mut graph, 1024);
        assert_eq!(graph.node_count(), 0);
    }

    #[test]
    fn test_batch_fusion_below_threshold() {
        // 2x3 = 6 elements, below threshold of 1024
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        batch_fusion(&mut graph, 1024);

        // Relu should NOT be marked (below threshold)
        let relu = graph.get_node(1).unwrap();
        assert!(relu.name.is_none() || !relu.name.as_ref().unwrap().contains("batch:"));
    }

    #[test]
    fn test_batch_fusion_above_threshold() {
        // 64x64 = 4096 elements, above threshold of 1024
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        batch_fusion(&mut graph, 1024);

        // Relu should be marked for batch execution
        let relu = graph.get_node(1).unwrap();
        assert!(relu.name.as_ref().is_some_and(|n| n.contains("batch:4096")));
    }

    #[test]
    fn test_batch_fusion_exact_threshold() {
        // 32x32 = 1024 elements, exactly at threshold
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![32, 32], DType::F32),
                OpNode::new(1, OpKind::Sigmoid, vec![32, 32], DType::F32),
                OpNode::new(2, OpKind::Output, vec![32, 32], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        batch_fusion(&mut graph, 1024);

        // Sigmoid should be marked (>= threshold)
        let sigmoid = graph.get_node(1).unwrap();
        assert!(sigmoid
            .name
            .as_ref()
            .is_some_and(|n| n.contains("batch:1024")));
    }

    #[test]
    fn test_batch_fusion_multiple_ops() {
        // Multiple element-wise ops, all above threshold
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64, 64], DType::F32),
                OpNode::new(3, OpKind::Tanh, vec![64, 64], DType::F32),
                OpNode::new(4, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3), (3, 4)],
        );

        batch_fusion(&mut graph, 1024);

        // All activations should be marked
        for id in [1, 2, 3] {
            let node = graph.get_node(id).unwrap();
            assert!(
                node.name.as_ref().is_some_and(|n| n.contains("batch:4096")),
                "Node {id} should be marked for batch",
            );
        }
    }

    #[test]
    fn test_batch_fusion_binary_ops() {
        // Binary ops (Add) above threshold
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        batch_fusion(&mut graph, 1024);

        // Add should be marked
        let add = graph.get_node(2).unwrap();
        assert!(add.name.as_ref().is_some_and(|n| n.contains("batch:4096")));
    }

    #[test]
    fn test_batch_fusion_non_element_wise_not_marked() {
        // MatMul is not element-wise
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        batch_fusion(&mut graph, 1024);

        // MatMul should NOT be marked
        let matmul = graph.get_node(2).unwrap();
        assert!(matmul.name.is_none() || !matmul.name.as_ref().unwrap().contains("batch:"));
    }

    #[test]
    fn test_batch_fusion_softmax_not_marked() {
        // Softmax is not element-wise (depends on all elements in axis)
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Softmax { axis: -1 }, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        batch_fusion(&mut graph, 1024);

        // Softmax should NOT be marked
        let softmax = graph.get_node(1).unwrap();
        assert!(softmax.name.is_none() || !softmax.name.as_ref().unwrap().contains("batch:"));
    }

    #[test]
    fn test_batch_fusion_reductions_not_marked() {
        // Reductions are not element-wise
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Sum, vec![1], DType::F32),
                OpNode::new(2, OpKind::Output, vec![1], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        batch_fusion(&mut graph, 1024);

        // Sum should NOT be marked
        let sum = graph.get_node(1).unwrap();
        assert!(sum.name.is_none() || !sum.name.as_ref().unwrap().contains("batch:"));
    }

    #[test]
    fn test_batch_fusion_preserves_existing_name() {
        // Node with existing name should have batch marker appended
        let mut op_graph = OperationGraph::new();
        let mut node = OpNode::new(0, OpKind::Relu, vec![64, 64], DType::F32);
        node.name = Some("my_relu".to_string());
        op_graph.add_node(OpNode::new(100, OpKind::Input, vec![64, 64], DType::F32));
        op_graph.add_node(node);
        op_graph.add_edge(100, 0);
        let mut graph = CompileGraph::from_operation_graph(&op_graph).unwrap();

        batch_fusion(&mut graph, 1024);

        let relu = graph.get_node(0).unwrap();
        assert!(relu
            .name
            .as_ref()
            .is_some_and(|n| n == "my_relu|batch:4096"));
    }

    #[test]
    fn test_batch_fusion_3d_tensor() {
        // 3D tensor: 8x8x16 = 1024 elements
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![8, 8, 16], DType::F32),
                OpNode::new(1, OpKind::Gelu, vec![8, 8, 16], DType::F32),
                OpNode::new(2, OpKind::Output, vec![8, 8, 16], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        batch_fusion(&mut graph, 1024);

        let gelu = graph.get_node(1).unwrap();
        assert!(gelu.name.as_ref().is_some_and(|n| n.contains("batch:1024")));
    }

    #[test]
    fn test_batch_fusion_mixed_sizes() {
        // Some ops above threshold, some below
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32), // 4096, above
                OpNode::new(2, OpKind::Relu, vec![4, 4], DType::F32),   // 16, below
                OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3)],
        );

        batch_fusion(&mut graph, 1024);

        // Large Relu marked
        let relu_large = graph.get_node(1).unwrap();
        assert!(relu_large
            .name
            .as_ref()
            .is_some_and(|n| n.contains("batch:4096")));

        // Small Relu not marked
        let relu_small = graph.get_node(2).unwrap();
        assert!(relu_small.name.is_none() || !relu_small.name.as_ref().unwrap().contains("batch:"));
    }

    #[test]
    fn test_is_element_wise() {
        // Element-wise ops
        assert!(OpKind::Add.is_element_wise());
        assert!(OpKind::Sub.is_element_wise());
        assert!(OpKind::Mul.is_element_wise());
        assert!(OpKind::Div.is_element_wise());
        assert!(OpKind::Sigmoid.is_element_wise());
        assert!(OpKind::Tanh.is_element_wise());
        assert!(OpKind::Relu.is_element_wise());
        assert!(OpKind::Gelu.is_element_wise());
        assert!(OpKind::Silu.is_element_wise());
        assert!(OpKind::Copy.is_element_wise());

        // Non-element-wise ops
        assert!(!OpKind::MatMul { m: 1, k: 1, n: 1 }.is_element_wise());
        assert!(!OpKind::Softmax { axis: -1 }.is_element_wise());
        assert!(!OpKind::Sum.is_element_wise());
        assert!(!OpKind::Max.is_element_wise());
        assert!(!OpKind::Min.is_element_wise());
        assert!(!OpKind::Mean.is_element_wise());
        assert!(!OpKind::Input.is_element_wise());
        assert!(!OpKind::Output.is_element_wise());
        assert!(!OpKind::Load.is_element_wise());
        assert!(!OpKind::Store.is_element_wise());
        assert!(!OpKind::Constant.is_element_wise());
    }

    #[test]
    fn test_element_count() {
        assert_eq!(element_count(&[]), 1);
        assert_eq!(element_count(&[5]), 5);
        assert_eq!(element_count(&[2, 3]), 6);
        assert_eq!(element_count(&[2, 3, 4]), 24);
        assert_eq!(element_count(&[64, 64]), 4096);
    }
}
