//! HTTP-based registry implementations.
//!
//! This module provides HTTP clients for remote layer registries:
//! - `AsyncHttpRegistry`: Async client using reqwest (feature: `http-async`)
//! - `SyncHttpRegistry`: Sync client using ureq (feature: `http-sync`)

use crate::error::{RegistryError, Result};
use crate::layer_ref::LayerReference;
use crate::metadata::{LayerMetadata, SearchResult};
use std::path::Path;

/// URL-encode a string for use in query parameters.
fn url_encode(s: &str) -> String {
    let mut result = String::with_capacity(s.len() * 3);
    for c in s.chars() {
        match c {
            'a'..='z' | 'A'..='Z' | '0'..='9' | '-' | '_' | '.' | '~' => {
                result.push(c);
            }
            _ => {
                for byte in c.to_string().bytes() {
                    result.push('%');
                    result.push_str(&format!("{:02X}", byte));
                }
            }
        }
    }
    result
}

/// Helper to convert a LayerReference to URL path components.
fn layer_to_path_components(layer: &LayerReference) -> Result<(String, String, String)> {
    match layer {
        LayerReference::ByName {
            namespace,
            name,
            version,
        } => {
            let ns = namespace.clone().unwrap_or_else(|| "default".to_string());
            Ok((ns, name.clone(), version.clone()))
        }
        LayerReference::ByHash(hash) => {
            // Use hash as both namespace and name for hash-based references
            let hash_hex = hex::encode(hash);
            Ok(("blobs".to_string(), hash_hex.clone(), hash_hex))
        }
        LayerReference::ByPath(_) => Err(RegistryError::InvalidRef(
            "cannot use path reference with HTTP registry".to_string(),
        )),
    }
}

// ============================================================================
// Async HTTP Registry (reqwest)
// ============================================================================

#[cfg(feature = "http-async")]
pub use async_impl::AsyncHttpRegistry;

#[cfg(feature = "http-async")]
mod async_impl {
    use super::*;
    use crate::traits::AsyncRegistry;
    use std::path::PathBuf;

    /// Async HTTP registry client using reqwest.
    ///
    /// This client communicates with a remote layer registry over HTTP/HTTPS.
    ///
    /// # Example
    ///
    /// ```rust,ignore
    /// use hologram_registry::AsyncHttpRegistry;
    ///
    /// let registry = AsyncHttpRegistry::new("https://registry.example.com")?;
    /// let layer_ref = "model:v1.0".parse()?;
    ///
    /// if registry.exists(&layer_ref).await? {
    ///     let path = registry.pull(&layer_ref, "./cache").await?;
    ///     println!("Downloaded to: {}", path.display());
    /// }
    /// ```
    pub struct AsyncHttpRegistry {
        base_url: String,
        auth_token: Option<String>,
        client: reqwest::Client,
    }

    impl AsyncHttpRegistry {
        /// Create a new async HTTP registry client.
        ///
        /// # Errors
        ///
        /// Returns an error if the HTTP client cannot be created.
        pub fn new(base_url: impl Into<String>) -> Result<Self> {
            let base_url = base_url.into().trim_end_matches('/').to_string();
            let client = reqwest::Client::builder()
                .timeout(std::time::Duration::from_secs(30))
                .build()
                .map_err(|e| RegistryError::Network(e.to_string()))?;

            Ok(Self {
                base_url,
                auth_token: None,
                client,
            })
        }

        /// Set authentication token.
        #[must_use]
        pub fn with_auth(mut self, token: impl Into<String>) -> Self {
            self.auth_token = Some(token.into());
            self
        }

        /// Get the base URL.
        #[must_use]
        pub fn base_url(&self) -> &str {
            &self.base_url
        }

        fn build_url(&self, path: &str) -> String {
            format!("{}/{}", self.base_url, path.trim_start_matches('/'))
        }

        fn manifest_url(&self, ns: &str, name: &str, tag: &str) -> String {
            self.build_url(&format!("v1/layers/{}/{}/manifests/{}", ns, name, tag))
        }

        fn blob_url(&self, ns: &str, name: &str, tag: &str) -> String {
            self.build_url(&format!("v1/layers/{}/{}/blobs/{}", ns, name, tag))
        }

        fn tags_url(&self, ns: &str, name: &str) -> String {
            self.build_url(&format!("v1/layers/{}/{}/tags", ns, name))
        }

        fn search_url(&self, query: &str, limit: usize) -> String {
            self.build_url(&format!(
                "v1/search?q={}&limit={}",
                url_encode(query),
                limit
            ))
        }

        fn add_auth(&self, request: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
            if let Some(ref token) = self.auth_token {
                request.bearer_auth(token)
            } else {
                request
            }
        }
    }

    #[async_trait::async_trait]
    impl AsyncRegistry for AsyncHttpRegistry {
        async fn exists(&self, layer: &LayerReference) -> Result<bool> {
            let (ns, name, tag) = layer_to_path_components(layer)?;
            let url = self.manifest_url(&ns, &name, &tag);
            let request = self.add_auth(self.client.head(&url));

            match request.send().await {
                Ok(response) => Ok(response.status().is_success()),
                Err(e) if e.is_status() => Ok(false),
                Err(e) => Err(RegistryError::Network(e.to_string())),
            }
        }

        async fn metadata(&self, layer: &LayerReference) -> Result<LayerMetadata> {
            let (ns, name, tag) = layer_to_path_components(layer)?;
            let url = self.manifest_url(&ns, &name, &tag);
            let request = self.add_auth(self.client.get(&url));

            let response = request
                .send()
                .await
                .map_err(|e| RegistryError::Network(e.to_string()))?;

            if response.status() == reqwest::StatusCode::NOT_FOUND {
                return Err(RegistryError::NotFound(layer.to_string()));
            }

            if !response.status().is_success() {
                return Err(RegistryError::Network(format!(
                    "Unexpected status: {}",
                    response.status()
                )));
            }

            let metadata: LayerMetadata = response
                .json()
                .await
                .map_err(|e| RegistryError::InvalidResponse(e.to_string()))?;

            Ok(metadata)
        }

        async fn pull(&self, layer: &LayerReference, output_dir: &Path) -> Result<PathBuf> {
            let (ns, name, tag) = layer_to_path_components(layer)?;

            tokio::fs::create_dir_all(output_dir)
                .await
                .map_err(|e| RegistryError::io(output_dir, e))?;

            let url = self.blob_url(&ns, &name, &tag);
            let request = self.add_auth(self.client.get(&url));

            let response = request
                .send()
                .await
                .map_err(|e| RegistryError::Network(e.to_string()))?;

            if response.status() == reqwest::StatusCode::NOT_FOUND {
                return Err(RegistryError::NotFound(layer.to_string()));
            }

            if !response.status().is_success() {
                return Err(RegistryError::Network(format!(
                    "Unexpected status: {}",
                    response.status()
                )));
            }

            let filename = format!("{}_{}.holb", name, tag);
            let output_path = output_dir.join(&filename);

            let bytes = response
                .bytes()
                .await
                .map_err(|e| RegistryError::Network(e.to_string()))?;

            tokio::fs::write(&output_path, &bytes)
                .await
                .map_err(|e| RegistryError::io(&output_path, e))?;

            Ok(output_path)
        }

        async fn push(&self, layer: &LayerReference, source_path: &Path) -> Result<String> {
            let (ns, name, tag) = layer_to_path_components(layer)?;

            if !source_path.exists() {
                return Err(RegistryError::io(
                    source_path,
                    std::io::Error::new(
                        std::io::ErrorKind::NotFound,
                        format!("Source file not found: {}", source_path.display()),
                    ),
                ));
            }

            let content = tokio::fs::read(source_path)
                .await
                .map_err(|e| RegistryError::io(source_path, e))?;

            let url = self.blob_url(&ns, &name, &tag);

            let request = self
                .add_auth(self.client.put(&url))
                .header("Content-Type", "application/octet-stream")
                .body(content);

            let response = request
                .send()
                .await
                .map_err(|e| RegistryError::Network(e.to_string()))?;

            if !response.status().is_success() {
                return Err(RegistryError::Network(format!(
                    "Upload failed: {}",
                    response.status()
                )));
            }

            let digest = response
                .headers()
                .get("Docker-Content-Digest")
                .and_then(|v| v.to_str().ok())
                .map(String::from)
                .unwrap_or_else(|| "sha256:unknown".to_string());

            Ok(digest)
        }

        async fn search(&self, query: &str, limit: usize) -> Result<Vec<SearchResult>> {
            let url = self.search_url(query, limit);
            let request = self.add_auth(self.client.get(&url));

            let response = request
                .send()
                .await
                .map_err(|e| RegistryError::Network(e.to_string()))?;

            if !response.status().is_success() {
                return Err(RegistryError::Network(format!(
                    "Search failed: {}",
                    response.status()
                )));
            }

            #[derive(serde::Deserialize)]
            struct SearchResponse {
                results: Vec<SearchResult>,
            }

            let search_response: SearchResponse = response
                .json()
                .await
                .map_err(|e| RegistryError::InvalidResponse(e.to_string()))?;

            Ok(search_response.results)
        }

        async fn tags(&self, layer: &LayerReference) -> Result<Vec<String>> {
            let (ns, name, _) = layer_to_path_components(layer)?;
            let url = self.tags_url(&ns, &name);
            let request = self.add_auth(self.client.get(&url));

            let response = request
                .send()
                .await
                .map_err(|e| RegistryError::Network(e.to_string()))?;

            if response.status() == reqwest::StatusCode::NOT_FOUND {
                return Err(RegistryError::NotFound(format!("{}/{}", ns, name)));
            }

            if !response.status().is_success() {
                return Err(RegistryError::Network(format!(
                    "Failed to fetch tags: {}",
                    response.status()
                )));
            }

            #[derive(serde::Deserialize)]
            struct TagsResponse {
                tags: Vec<String>,
            }

            let tags_response: TagsResponse = response
                .json()
                .await
                .map_err(|e| RegistryError::InvalidResponse(e.to_string()))?;

            Ok(tags_response.tags)
        }

        async fn delete(&self, layer: &LayerReference) -> Result<()> {
            let (ns, name, tag) = layer_to_path_components(layer)?;
            let url = self.manifest_url(&ns, &name, &tag);
            let request = self.add_auth(self.client.delete(&url));

            let response = request
                .send()
                .await
                .map_err(|e| RegistryError::Network(e.to_string()))?;

            if response.status() == reqwest::StatusCode::NOT_FOUND {
                return Err(RegistryError::NotFound(layer.to_string()));
            }

            if !response.status().is_success() {
                return Err(RegistryError::Network(format!(
                    "Delete failed: {}",
                    response.status()
                )));
            }

            Ok(())
        }
    }
}

// ============================================================================
// Sync HTTP Registry (ureq)
// ============================================================================

#[cfg(feature = "http-sync")]
pub use sync_impl::SyncHttpRegistry;

#[cfg(feature = "http-sync")]
mod sync_impl {
    use super::*;
    use crate::traits::Registry;
    use std::path::PathBuf;

    /// Synchronous HTTP registry client using ureq.
    ///
    /// This client provides blocking HTTP operations for environments
    /// that don't use async/await.
    ///
    /// # Example
    ///
    /// ```rust,ignore
    /// use hologram_registry::SyncHttpRegistry;
    ///
    /// let registry = SyncHttpRegistry::new("https://registry.example.com");
    /// let layer_ref = "model:v1.0".parse()?;
    ///
    /// if registry.exists(&layer_ref)? {
    ///     let path = registry.pull(&layer_ref, "./cache".as_ref())?;
    ///     println!("Downloaded to: {}", path.display());
    /// }
    /// ```
    pub struct SyncHttpRegistry {
        base_url: String,
        auth_token: Option<String>,
        timeout_secs: u64,
    }

    impl SyncHttpRegistry {
        /// Create a new sync HTTP registry client.
        #[must_use]
        pub fn new(base_url: impl Into<String>) -> Self {
            Self {
                base_url: base_url.into().trim_end_matches('/').to_string(),
                auth_token: None,
                timeout_secs: 30,
            }
        }

        /// Set authentication token.
        #[must_use]
        pub fn with_auth(mut self, token: impl Into<String>) -> Self {
            self.auth_token = Some(token.into());
            self
        }

        /// Set request timeout in seconds.
        #[must_use]
        pub fn with_timeout(mut self, timeout_secs: u64) -> Self {
            self.timeout_secs = timeout_secs;
            self
        }

        /// Get the base URL.
        #[must_use]
        pub fn base_url(&self) -> &str {
            &self.base_url
        }

        fn build_url(&self, path: &str) -> String {
            format!("{}/{}", self.base_url, path.trim_start_matches('/'))
        }

        fn manifest_url(&self, ns: &str, name: &str, tag: &str) -> String {
            self.build_url(&format!("v1/layers/{}/{}/manifests/{}", ns, name, tag))
        }

        fn blob_url(&self, ns: &str, name: &str, tag: &str) -> String {
            self.build_url(&format!("v1/layers/{}/{}/blobs/{}", ns, name, tag))
        }

        fn tags_url(&self, ns: &str, name: &str) -> String {
            self.build_url(&format!("v1/layers/{}/{}/tags", ns, name))
        }

        fn search_url(&self, query: &str, limit: usize) -> String {
            self.build_url(&format!(
                "v1/search?q={}&limit={}",
                url_encode(query),
                limit
            ))
        }

        fn agent(&self) -> ureq::Agent {
            ureq::AgentBuilder::new()
                .timeout(std::time::Duration::from_secs(self.timeout_secs))
                .build()
        }

        fn add_auth(&self, request: ureq::Request) -> ureq::Request {
            if let Some(ref token) = self.auth_token {
                request.set("Authorization", &format!("Bearer {}", token))
            } else {
                request
            }
        }
    }

    impl Registry for SyncHttpRegistry {
        fn exists(&self, layer: &LayerReference) -> Result<bool> {
            let (ns, name, tag) = layer_to_path_components(layer)?;
            let url = self.manifest_url(&ns, &name, &tag);
            let request = self.add_auth(self.agent().head(&url));

            match request.call() {
                Ok(_) => Ok(true),
                Err(ureq::Error::Status(404, _)) => Ok(false),
                Err(e) => Err(RegistryError::Network(e.to_string())),
            }
        }

        fn metadata(&self, layer: &LayerReference) -> Result<LayerMetadata> {
            let (ns, name, tag) = layer_to_path_components(layer)?;
            let url = self.manifest_url(&ns, &name, &tag);
            let request = self.add_auth(self.agent().get(&url));

            let response = request.call().map_err(|e| match e {
                ureq::Error::Status(404, _) => RegistryError::NotFound(layer.to_string()),
                _ => RegistryError::Network(e.to_string()),
            })?;

            let metadata: LayerMetadata = response
                .into_json()
                .map_err(|e| RegistryError::InvalidResponse(e.to_string()))?;

            Ok(metadata)
        }

        fn pull(&self, layer: &LayerReference, output_dir: &Path) -> Result<PathBuf> {
            let (ns, name, tag) = layer_to_path_components(layer)?;

            std::fs::create_dir_all(output_dir).map_err(|e| RegistryError::io(output_dir, e))?;

            let url = self.blob_url(&ns, &name, &tag);
            let request = self.add_auth(self.agent().get(&url));

            let response = request.call().map_err(|e| match e {
                ureq::Error::Status(404, _) => RegistryError::NotFound(layer.to_string()),
                _ => RegistryError::Network(e.to_string()),
            })?;

            let filename = format!("{}_{}.holb", name, tag);
            let output_path = output_dir.join(&filename);

            let mut reader = response.into_reader();
            let mut file = std::fs::File::create(&output_path)
                .map_err(|e| RegistryError::io(&output_path, e))?;

            std::io::copy(&mut reader, &mut file)
                .map_err(|e| RegistryError::io(&output_path, e))?;

            Ok(output_path)
        }

        fn push(&self, layer: &LayerReference, source_path: &Path) -> Result<String> {
            let (ns, name, tag) = layer_to_path_components(layer)?;

            if !source_path.exists() {
                return Err(RegistryError::io(
                    source_path,
                    std::io::Error::new(
                        std::io::ErrorKind::NotFound,
                        format!("Source file not found: {}", source_path.display()),
                    ),
                ));
            }

            let content =
                std::fs::read(source_path).map_err(|e| RegistryError::io(source_path, e))?;

            let url = self.blob_url(&ns, &name, &tag);

            let request = self
                .add_auth(self.agent().put(&url))
                .set("Content-Type", "application/octet-stream");

            let response = request
                .send_bytes(&content)
                .map_err(|e| RegistryError::Network(e.to_string()))?;

            let digest = response
                .header("Docker-Content-Digest")
                .map(String::from)
                .unwrap_or_else(|| "sha256:unknown".to_string());

            Ok(digest)
        }

        fn search(&self, query: &str, limit: usize) -> Result<Vec<SearchResult>> {
            let url = self.search_url(query, limit);
            let request = self.add_auth(self.agent().get(&url));

            let response = request
                .call()
                .map_err(|e| RegistryError::Network(e.to_string()))?;

            #[derive(serde::Deserialize)]
            struct SearchResponse {
                results: Vec<SearchResult>,
            }

            let search_response: SearchResponse = response
                .into_json()
                .map_err(|e| RegistryError::InvalidResponse(e.to_string()))?;

            Ok(search_response.results)
        }

        fn tags(&self, layer: &LayerReference) -> Result<Vec<String>> {
            let (ns, name, _) = layer_to_path_components(layer)?;
            let url = self.tags_url(&ns, &name);
            let request = self.add_auth(self.agent().get(&url));

            let response = request.call().map_err(|e| match e {
                ureq::Error::Status(404, _) => RegistryError::NotFound(format!("{}/{}", ns, name)),
                _ => RegistryError::Network(e.to_string()),
            })?;

            #[derive(serde::Deserialize)]
            struct TagsResponse {
                tags: Vec<String>,
            }

            let tags_response: TagsResponse = response
                .into_json()
                .map_err(|e| RegistryError::InvalidResponse(e.to_string()))?;

            Ok(tags_response.tags)
        }

        fn delete(&self, layer: &LayerReference) -> Result<()> {
            let (ns, name, tag) = layer_to_path_components(layer)?;
            let url = self.manifest_url(&ns, &name, &tag);
            let request = self.add_auth(self.agent().delete(&url));

            request.call().map_err(|e| match e {
                ureq::Error::Status(404, _) => RegistryError::NotFound(layer.to_string()),
                _ => RegistryError::Network(e.to_string()),
            })?;

            Ok(())
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_url_encode_simple() {
        assert_eq!(url_encode("hello"), "hello");
        assert_eq!(url_encode("a-b_c.d~e"), "a-b_c.d~e");
    }

    #[test]
    fn test_url_encode_special_chars() {
        assert_eq!(url_encode("hello world"), "hello%20world");
        assert_eq!(url_encode("a+b"), "a%2Bb");
        assert_eq!(url_encode("foo?bar=baz"), "foo%3Fbar%3Dbaz");
    }

    #[test]
    fn test_layer_to_path_components_by_name() {
        let layer = LayerReference::from_name(Some("org"), "model", "v1.0");
        let (ns, name, tag) = layer_to_path_components(&layer).unwrap();
        assert_eq!(ns, "org");
        assert_eq!(name, "model");
        assert_eq!(tag, "v1.0");
    }

    #[test]
    fn test_layer_to_path_components_no_namespace() {
        let layer = LayerReference::from_name(None::<String>, "model", "v1.0");
        let (ns, name, tag) = layer_to_path_components(&layer).unwrap();
        assert_eq!(ns, "default");
        assert_eq!(name, "model");
        assert_eq!(tag, "v1.0");
    }

    #[test]
    fn test_layer_to_path_components_by_hash() {
        let layer = LayerReference::from_hash([0xab; 32]);
        let (ns, name, tag) = layer_to_path_components(&layer).unwrap();
        assert_eq!(ns, "blobs");
        assert!(name.contains("ab")); // Hash hex
        assert_eq!(name, tag);
    }

    #[test]
    fn test_layer_to_path_components_by_path_fails() {
        let layer = LayerReference::from_path("/some/path");
        let result = layer_to_path_components(&layer);
        assert!(result.is_err());
    }

    #[cfg(feature = "http-sync")]
    #[test]
    fn test_sync_registry_new() {
        let registry = sync_impl::SyncHttpRegistry::new("https://example.com");
        assert_eq!(registry.base_url(), "https://example.com");
    }

    #[cfg(feature = "http-sync")]
    #[test]
    fn test_sync_registry_with_auth() {
        let registry = sync_impl::SyncHttpRegistry::new("https://example.com")
            .with_auth("token123")
            .with_timeout(60);
        assert_eq!(registry.base_url(), "https://example.com");
    }

    #[cfg(feature = "http-async")]
    #[test]
    fn test_async_registry_new() {
        let registry = async_impl::AsyncHttpRegistry::new("https://example.com").unwrap();
        assert_eq!(registry.base_url(), "https://example.com");
    }

    #[cfg(feature = "http-async")]
    #[test]
    fn test_async_registry_with_auth() {
        let registry = async_impl::AsyncHttpRegistry::new("https://example.com")
            .unwrap()
            .with_auth("token123");
        assert_eq!(registry.base_url(), "https://example.com");
    }

    #[test]
    fn test_url_encode_unicode() {
        let encoded = url_encode("hello 世界");
        assert!(encoded.contains("%"));
        assert!(encoded.starts_with("hello%20"));
    }

    #[test]
    fn test_url_encode_empty() {
        assert_eq!(url_encode(""), "");
    }
}
