/**
 * PrivacyPolicyViewer — Displays privacy policy sections.
 */

import { BookOpen, Tag } from "lucide-react";
import type { PrivacyPolicy } from "../types";

interface Props {
  readonly policy: PrivacyPolicy | null;
}

export default function PrivacyPolicyViewer({ policy }: Props) {
  if (!policy) return null;

  return (
    <div className="rounded-lg border border-border bg-card p-6 animate-fade-in" style={{ animationDelay: "0.4s" }}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
          Privacy Policy
        </h3>
        <span className="text-xs text-text-dim font-mono">v{policy.version}</span>
      </div>

      <div className="space-y-4">
        {policy.sections.map((section) => (
          <div key={section.id} className="border-l-2 border-primary/30 pl-4">
            <div className="flex items-center gap-2 mb-1">
              <BookOpen className="h-3.5 w-3.5 text-primary" />
              <h4 className="text-sm font-semibold text-foreground">{section.title}</h4>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">{section.content}</p>
            <div className="mt-2 flex flex-wrap gap-1">
              {section.dataCategories.map((cat) => (
                <span
                  key={cat}
                  className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded bg-gold-bg text-primary font-mono"
                >
                  <Tag className="h-2.5 w-2.5" />
                  {cat}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-3 border-t border-border text-xs text-text-dim">
        Effective: {new Date(policy.effectiveDate).toLocaleDateString()}
      </div>
    </div>
  );
}
