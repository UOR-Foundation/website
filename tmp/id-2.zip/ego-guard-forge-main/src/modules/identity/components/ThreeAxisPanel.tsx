/**
 * ThreeAxisPanel — Shows your protection level across three key areas:
 * who controls your AI agent, where your data lives, and how AI processes it.
 */

import { useMemo } from "react";
import {
  Shield, Database, Cpu, Layers,
  Lock, Unlock, AlertTriangle,
} from "lucide-react";
import GlossaryTooltip from "./GlossaryTooltip";
import type { SovereigntySurface } from "../types";
import type { ThreeAxisSeparation } from "../types/three-axis";
import { computeThreeAxisSeparation } from "../engine/three-axis-engine";

interface Props {
  readonly surface: SovereigntySurface;
}

function pct(v: number): string {
  return (v * 100).toFixed(1);
}

const LEVEL_STYLE: Record<string, string> = {
  sovereign: "text-primary",
  separated: "text-primary/80",
  partial: "text-accent-foreground",
  exposed: "text-destructive",
};

const LEVEL_LABEL: Record<string, string> = {
  sovereign: "Fully Protected",
  separated: "Well Protected",
  partial: "Partially Protected",
  exposed: "At Risk",
};

function AxisBar({
  label,
  icon: Icon,
  phi,
  detail,
  isWeakest,
}: {
  label: string;
  icon: typeof Shield;
  phi: number;
  detail: string;
  isWeakest: boolean;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Icon className="h-3 w-3 text-muted-foreground" />
          <span className="text-[10px] font-semibold text-foreground uppercase tracking-wider">
            {label}
          </span>
          {isWeakest && (
            <span className="text-[8px] px-1.5 py-0.5 rounded bg-destructive/10 text-destructive font-semibold">
              Weakest area
            </span>
          )}
        </div>
        <span className="text-[10px] font-mono text-muted-foreground">
          {pct(phi)}%
        </span>
      </div>
      <div className="h-2.5 rounded-full bg-muted overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{
            width: `${Math.max(phi * 100, 2)}%`,
            backgroundColor: isWeakest
              ? "hsl(0, 40%, 40%)"
              : phi > 0.6
                ? "hsl(38, 60%, 55%)"
                : "hsl(38, 30%, 40%)",
          }}
        />
      </div>
      <div className="text-[9px] text-muted-foreground">{detail}</div>
    </div>
  );
}

export default function ThreeAxisPanel({ surface }: Props) {
  const separation: ThreeAxisSeparation = useMemo(
    () => computeThreeAxisSeparation(surface),
    [surface],
  );

  const { agent, data, inference } = separation;

  return (
    <div className="rounded-lg border border-border bg-card p-6 animate-fade-in space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
          <Layers className="h-3.5 w-3.5" />
          Protection Breakdown
        </h3>
        <span className={`text-[10px] font-semibold ${LEVEL_STYLE[separation.sovereigntyLevel]}`}>
          {LEVEL_LABEL[separation.sovereigntyLevel]}
        </span>
      </div>

      {/* Overall score */}
      <div className="rounded-md border border-border bg-muted/20 px-3 py-2 text-center">
        <span className="text-xs text-muted-foreground">
          Overall protection: <span className={`font-semibold ${LEVEL_STYLE[separation.sovereigntyLevel]}`}>
            {pct(separation.phi_v5)}%
          </span>
          <span className="text-muted-foreground/60 ml-2">
            (Agent {pct(agent.phi)}% × Data {pct(data.phi)}% × AI Processing {pct(inference.phi)}%)
          </span>
        </span>
      </div>

      {/* Three Axis Bars */}
      <div className="space-y-4">
        <AxisBar
          label="Agent Control"
          icon={Shield}
          phi={agent.phi}
          isWeakest={separation.weakestAxis === "agent"}
          detail={`${agent.guardianActive ? "Recovery key active" : "No recovery key"} · ${agent.delegateActive ? "Delegate active" : "No delegate"}`}
        />
        <AxisBar
          label="Data Ownership"
          icon={Database}
          phi={data.phi}
          isWeakest={separation.weakestAxis === "data"}
          detail={`${data.providerCount} storage location${data.providerCount !== 1 ? "s" : ""} · ${pct(data.shieldedFraction)}% kept on-device · Largest share: ${pct(data.maxSingleProviderShare)}%`}
        />
        <AxisBar
          label="AI Processing"
          icon={Cpu}
          phi={inference.phi}
          isWeakest={separation.weakestAxis === "inference"}
          detail={`${inference.compressionRatio.toFixed(1)}× privacy compression · ${pct(inference.reconstructionDefence)}% data reconstruction difficulty`}
        />
      </div>

      {/* Key stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-md bg-muted/50 p-3 text-center">
          <div className="text-lg font-semibold text-foreground font-mono">
            {inference.compressionRatio.toFixed(1)}×
          </div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            <GlossaryTooltip term="Privacy compression">Privacy compression</GlossaryTooltip>
          </div>
        </div>
        <div className="rounded-md bg-muted/50 p-3 text-center">
          <div className="text-lg font-semibold text-foreground font-mono">
            {pct(separation.reconstructionDifficulty)}%
          </div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            <GlossaryTooltip term="Data reconstruction difficulty">Data reconstruction difficulty</GlossaryTooltip>
          </div>
        </div>
      </div>

      {/* Data storage distribution */}
      <div className="space-y-2">
        <span className="text-[10px] font-semibold text-muted-foreground uppercase">
          Where Your Data Lives
        </span>
        <div className="flex gap-1">
          {data.providers.map((provider) => {
            const share = provider.edgesCovered / surface.edges.length;
            return (
              <div
                key={provider.id}
                className="rounded transition-all duration-500 flex items-center justify-center"
                style={{
                  width: `${Math.max(share * 100, 8)}%`,
                  height: "28px",
                  backgroundColor:
                    provider.type === "local"
                      ? "hsl(38, 50%, 25%)"
                      : provider.type === "decentralized"
                        ? "hsl(38, 60%, 35%)"
                        : provider.type === "federated"
                          ? "hsl(38, 40%, 45%)"
                          : "hsl(38, 30%, 50%)",
                }}
                title={`${provider.name}: ${provider.edgesCovered} data points (${pct(share)}%)`}
              >
                {provider.type === "local" ? (
                  <Lock className="h-2.5 w-2.5 text-foreground/60" />
                ) : provider.type === "decentralized" ? (
                  <Shield className="h-2.5 w-2.5 text-foreground/60" />
                ) : (
                  <Unlock className="h-2.5 w-2.5 text-foreground/60" />
                )}
              </div>
            );
          })}
        </div>
        <div className="flex gap-1">
          {data.providers.map((provider) => {
            const typeLabel = provider.type === "local" ? "Your device"
              : provider.type === "decentralized" ? "Distributed"
              : provider.type === "federated" ? "Federated"
              : "Cloud";
            return (
              <div
                key={provider.id}
                className="text-center"
                style={{
                  width: `${Math.max((provider.edgesCovered / surface.edges.length) * 100, 8)}%`,
                }}
              >
                <span className="text-[7px] text-muted-foreground truncate block">
                  {typeLabel}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Weakest axis warning */}
      {separation.phi_v5 < 0.4 && (
        <div className="flex items-start gap-2 rounded-md border border-destructive/20 bg-destructive/5 p-3">
          <AlertTriangle className="h-3.5 w-3.5 text-destructive mt-0.5 shrink-0" />
          <div className="text-[10px] text-muted-foreground">
            <span className="text-destructive font-semibold">
              {separation.weakestAxis === "agent" ? "Agent Control"
                : separation.weakestAxis === "data" ? "Data Ownership"
                : "AI Processing"}
            </span>{" "}
            is your weakest area ({pct(separation[separation.weakestAxis].phi)}% protected).
            {separation.weakestAxis === "data" && " Try spreading your data across more storage locations or keeping more on-device."}
            {separation.weakestAxis === "agent" && " Activate your recovery key and set up delegation to strengthen this."}
            {separation.weakestAxis === "inference" && " Increase the number of private data points to limit what AI can reconstruct."}
          </div>
        </div>
      )}
    </div>
  );
}
