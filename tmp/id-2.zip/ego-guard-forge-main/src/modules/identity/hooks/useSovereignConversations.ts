/**
 * useSovereignConversations — Local-only persistence for sovereign inference chat history.
 * Stores conversations with boundary attestation snapshots in localStorage.
 */

import { useState, useCallback, useEffect } from "react";
import type { BoundaryAttestation } from "../engine/attestation-engine";

export interface ChatMessage {
  readonly id: string;
  readonly role: "user" | "assistant";
  readonly content: string;
  readonly timestamp: number;
}

export interface ConversationSnapshot {
  readonly id: string;
  readonly title: string;
  readonly messages: ChatMessage[];
  readonly attestation: BoundaryAttestation | null;
  readonly createdAt: number;
  readonly updatedAt: number;
}

const STORAGE_KEY = "sovereign-conversations";
const MAX_CONVERSATIONS = 50;

function loadConversations(): ConversationSnapshot[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveConversations(convos: ConversationSnapshot[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(convos.slice(0, MAX_CONVERSATIONS)));
  } catch { /* quota exceeded — silently drop oldest */ }
}

function deriveTitle(messages: ChatMessage[]): string {
  const first = messages.find((m) => m.role === "user");
  if (!first) return "New conversation";
  return first.content.length > 60 ? first.content.slice(0, 57) + "…" : first.content;
}

export function useSovereignConversations() {
  const [conversations, setConversations] = useState<ConversationSnapshot[]>(loadConversations);
  const [activeId, setActiveId] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    saveConversations(conversations);
  }, [conversations]);

  const activeConversation = conversations.find((c) => c.id === activeId) ?? null;

  const createConversation = useCallback((): string => {
    const id = `conv-${Date.now()}`;
    const convo: ConversationSnapshot = {
      id,
      title: "New conversation",
      messages: [],
      attestation: null,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setConversations((prev) => [convo, ...prev]);
    setActiveId(id);
    return id;
  }, []);

  const updateConversation = useCallback(
    (id: string, messages: ChatMessage[], attestation: BoundaryAttestation | null) => {
      setConversations((prev) =>
        prev.map((c) =>
          c.id === id
            ? { ...c, messages, attestation, title: deriveTitle(messages), updatedAt: Date.now() }
            : c,
        ),
      );
    },
    [],
  );

  const deleteConversation = useCallback((id: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== id));
    setActiveId((prev) => (prev === id ? null : prev));
  }, []);

  const clearAll = useCallback(() => {
    setConversations([]);
    setActiveId(null);
  }, []);

  return {
    conversations,
    activeConversation,
    activeId,
    setActiveId,
    createConversation,
    updateConversation,
    deleteConversation,
    clearAll,
  };
}
