/**
 * YourSpaceDashboard — The main My Space dashboard.
 * Re-exports the identity dashboard for the your-space module.
 */
export { default } from "@/modules/identity/pages/IdentityDashboard";
