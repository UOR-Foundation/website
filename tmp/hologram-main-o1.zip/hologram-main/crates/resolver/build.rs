//! Build script for hologram-resolver.
//!
//! Generates Rust types from the type: namespace in uor-foundation.jsonld.

use std::env;
use std::fs;
use std::path::Path;

fn main() {
    let out_dir = env::var("OUT_DIR").unwrap();
    let manifest_dir = env::var("CARGO_MANIFEST_DIR").unwrap();

    // Path to uor-foundation.jsonld
    let workspace_root = Path::new(&manifest_dir).parent().unwrap().parent().unwrap();
    let schema_path = workspace_root.join("descriptors/uor-foundation.jsonld");

    // Rerun if schema changes
    println!("cargo:rerun-if-changed={}", schema_path.display());
    println!("cargo:rerun-if-changed=build.rs");

    let code = match fs::read_to_string(&schema_path) {
        Ok(content) => generate_from_schema(&content),
        Err(e) => {
            eprintln!(
                "Warning: Schema not found at {}: {}",
                schema_path.display(),
                e
            );
            generate_stub()
        }
    };

    let output_path = Path::new(&out_dir).join("generated_types.rs");
    fs::write(&output_path, code).expect("Failed to write generated_types.rs");
}

fn generate_stub() -> String {
    r#"// Schema not found - using stub types
// These are manually defined fallbacks

/// Stub: TypedDatum not generated
pub const TYPED_DATUM_GENERATED: bool = false;
/// Stub: HashDigest not generated
pub const HASH_DIGEST_GENERATED: bool = false;
/// Stub: CompressedReference not generated
pub const COMPRESSED_REFERENCE_GENERATED: bool = false;
"#
    .to_string()
}

fn generate_from_schema(content: &str) -> String {
    let schema: serde_json::Value = match serde_json::from_str(content) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("Warning: Failed to parse schema: {}", e);
            return generate_stub();
        }
    };

    let graph = match schema.get("@graph").and_then(|g| g.as_array()) {
        Some(g) => g,
        None => {
            eprintln!("Warning: No @graph in schema");
            return generate_stub();
        }
    };

    // Extract type definitions
    let mut typed_datum_found = false;
    let mut hash_digest_found = false;
    let mut hash_digest_bits = 256u16;
    let mut compressed_ref_found = false;
    let mut effective_entropy_found = false;

    for node in graph {
        let id = node.get("@id").and_then(|v| v.as_str()).unwrap_or("");

        match id {
            "https://uor.foundation/type/TypedDatum" => {
                typed_datum_found = true;
            }
            "https://uor.foundation/type/HashDigest" => {
                hash_digest_found = true;
                if let Some(bits) = node
                    .get("https://uor.foundation/type/bitWidth")
                    .and_then(|v| v.as_u64())
                {
                    hash_digest_bits = bits as u16;
                }
            }
            "https://uor.foundation/type/CompressedReference" => {
                compressed_ref_found = true;
            }
            "https://uor.foundation/type/effectiveEntropy" => {
                effective_entropy_found = true;
            }
            _ => {}
        }
    }

    let mut code = String::new();

    code.push_str("// Auto-generated from descriptors/uor-foundation.jsonld\n");
    code.push_str("// DO NOT EDIT - regenerate by rebuilding the crate\n\n");

    // Constants indicating what was found
    code.push_str(&format!(
        "/// TypedDatum class found in schema.\npub const TYPED_DATUM_GENERATED: bool = {};\n\n",
        typed_datum_found
    ));
    code.push_str(&format!(
        "/// HashDigest class found in schema.\npub const HASH_DIGEST_GENERATED: bool = {};\n\n",
        hash_digest_found
    ));
    code.push_str(&format!(
        "/// CompressedReference class found in schema.\npub const COMPRESSED_REFERENCE_GENERATED: bool = {};\n\n",
        compressed_ref_found
    ));
    code.push_str(&format!(
        "/// effectiveEntropy property found in schema.\npub const EFFECTIVE_ENTROPY_GENERATED: bool = {};\n\n",
        effective_entropy_found
    ));

    // HashDigest bit width from schema
    code.push_str(&format!(
        "/// Bit width of HashDigest from schema.\npub const HASH_DIGEST_BITS: u16 = {};\n\n",
        hash_digest_bits
    ));
    code.push_str(&format!(
        "/// Byte size of HashDigest.\npub const HASH_DIGEST_BYTES: usize = {};\n\n",
        hash_digest_bits / 8
    ));

    // Schema URIs
    code.push_str("/// URI for TypedDatum in the ontology.\n");
    code.push_str(
        "pub const TYPED_DATUM_URI: &str = \"https://uor.foundation/type/TypedDatum\";\n\n",
    );
    code.push_str("/// URI for HashDigest in the ontology.\n");
    code.push_str(
        "pub const HASH_DIGEST_URI: &str = \"https://uor.foundation/type/HashDigest\";\n\n",
    );
    code.push_str("/// URI for CompressedReference in the ontology.\n");
    code.push_str("pub const COMPRESSED_REFERENCE_URI: &str = \"https://uor.foundation/type/CompressedReference\";\n\n");

    // Validation function
    code.push_str(
        r#"/// Validate that all required types were found in the schema.
#[must_use]
pub const fn schema_complete() -> bool {
    TYPED_DATUM_GENERATED && HASH_DIGEST_GENERATED && COMPRESSED_REFERENCE_GENERATED && EFFECTIVE_ENTROPY_GENERATED
}
"#,
    );

    code
}
