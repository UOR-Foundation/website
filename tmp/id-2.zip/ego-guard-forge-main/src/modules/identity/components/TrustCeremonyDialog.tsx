/**
 * TrustCeremonyDialog — Peer trust verification initiation and simulation.
 */

import { useState, useCallback } from "react";
import { Users, Loader2, CheckCircle, ArrowRight, Handshake } from "lucide-react";
import type { CeremonyRecord } from "../types";
import {
  initiatePeerCeremony,
  acceptPeerCeremony,
  completePeerCeremony,
  type PeerCeremonyInvite,
} from "../engine/ceremony-engine";

interface Props {
  readonly identityId: string;
  readonly delegateKeyHex: string;
  readonly guardianFingerprint: string;
  readonly onCeremonyComplete: (record: CeremonyRecord) => void;
}

type Step = "idle" | "initiating" | "waiting" | "completing" | "done";

function truncate(s: string, len = 16): string {
  return s.length > len ? `${s.slice(0, len)}…` : s;
}

export default function TrustCeremonyDialog({
  identityId,
  delegateKeyHex,
  guardianFingerprint,
  onCeremonyComplete,
}: Props) {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<Step>("idle");
  const [invite, setInvite] = useState<PeerCeremonyInvite | null>(null);
  const [completedRecord, setCompletedRecord] = useState<CeremonyRecord | null>(null);
  const [peerHandle, setPeerHandle] = useState("");

  const reset = useCallback(() => {
    setStep("idle");
    setInvite(null);
    setCompletedRecord(null);
    setPeerHandle("");
  }, []);

  const handleInitiate = useCallback(async () => {
    if (!peerHandle.trim()) return;
    setStep("initiating");

    try {
      const inv = await initiatePeerCeremony(identityId, delegateKeyHex, guardianFingerprint);
      setInvite(inv);
      setStep("waiting");

      // Simulate peer acceptance after a short delay (in production this would be async)
      setTimeout(async () => {
        const simPeerId = `urn:uor:identity:peer:${peerHandle.replace(/[^a-zA-Z0-9]/g, "")}`;
        const simPeerKey = Array.from(crypto.getRandomValues(new Uint8Array(32)))
          .map((b) => b.toString(16).padStart(2, "0"))
          .join("");
        const simPeerFp = Array.from(crypto.getRandomValues(new Uint8Array(32)))
          .map((b) => b.toString(16).padStart(2, "0"))
          .join("");

        const accepted = await acceptPeerCeremony(inv, simPeerId, simPeerKey, simPeerFp);
        setInvite(accepted);
        setStep("completing");

        const result = await completePeerCeremony(accepted);
        if (result) {
          setInvite(result.invite);
          setCompletedRecord(result.record);
          onCeremonyComplete(result.record);
          setStep("done");
        }
      }, 1500);
    } catch {
      setStep("idle");
    }
  }, [identityId, delegateKeyHex, guardianFingerprint, peerHandle, onCeremonyComplete]);

  if (!open) {
    return (
      <button
        onClick={() => { setOpen(true); reset(); }}
        className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border bg-card text-sm font-semibold text-foreground hover:border-primary/40 hover:bg-muted transition-colors w-full"
      >
        <Handshake className="h-4 w-4 text-primary" />
        Verify a Peer
      </button>
    );
  }

  return (
    <div className="rounded-lg border border-border bg-card p-6 animate-fade-in space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
          <Users className="h-3.5 w-3.5" />
          Peer Verification
        </h3>
        <button
          onClick={() => setOpen(false)}
          className="text-xs text-muted-foreground hover:text-foreground transition-colors"
        >
          Close
        </button>
      </div>

      {step === "idle" && (
        <div className="space-y-4">
          <p className="text-xs text-muted-foreground">
            Enter someone's handle to start a mutual trust verification. You'll both exchange
            credentials and create a shared proof that you trust each other.
          </p>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-foreground">Their Handle</label>
            <input
              value={peerHandle}
              onChange={(e) => setPeerHandle(e.target.value)}
              placeholder="@peer.uor"
              className="w-full px-3 py-2 rounded-md border border-border bg-input text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring"
            />
          </div>
          <button
            onClick={handleInitiate}
            disabled={!peerHandle.trim()}
            className="flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold bg-primary text-primary-foreground disabled:opacity-40 transition-opacity"
          >
            <ArrowRight className="h-3 w-3" />
            Send Verification Request
          </button>
        </div>
      )}

      {step === "initiating" && (
        <div className="flex items-center gap-3 py-4">
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
          <span className="text-sm text-muted-foreground">Creating verification request…</span>
        </div>
      )}

      {step === "waiting" && invite && (
        <div className="space-y-3">
          <div className="flex items-center gap-3 py-2">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
            <span className="text-sm text-muted-foreground">
              Waiting for <span className="text-foreground font-medium">@{peerHandle}</span> to accept…
            </span>
          </div>
          <div className="text-xs text-muted-foreground space-y-1">
            <div>Request ID: <span className="font-mono text-foreground">{truncate(invite.id, 24)}</span></div>
            <div>Your key: <span className="font-mono text-foreground">{truncate(invite.initiatorFingerprint)}</span></div>
          </div>
        </div>
      )}

      {step === "completing" && (
        <div className="flex items-center gap-3 py-4">
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
          <span className="text-sm text-muted-foreground">Peer accepted — completing verification…</span>
        </div>
      )}

      {step === "done" && completedRecord && invite && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-primary">
            <CheckCircle className="h-5 w-5" />
            <span className="text-sm font-semibold">Verification Complete</span>
          </div>

          <div className="rounded-md border border-border bg-muted/30 p-4 space-y-2 text-xs">
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
              <span className="text-muted-foreground">Type</span>
              <span className="text-foreground font-semibold">Mutual Peer Verification</span>

              <span className="text-muted-foreground">Proof ID</span>
              <span className="font-mono text-foreground">{truncate(completedRecord.derivationId, 20)}</span>

              <span className="text-muted-foreground">Participants</span>
              <span className="text-foreground">{completedRecord.participants.length} identities</span>

              <span className="text-muted-foreground">Your key</span>
              <span className="font-mono text-foreground">{truncate(completedRecord.guardianFingerprint)}</span>

              <span className="text-muted-foreground">Peer's key</span>
              <span className="font-mono text-foreground">{truncate(completedRecord.delegateFingerprint)}</span>

              <span className="text-muted-foreground">Timestamp</span>
              <span className="text-foreground">{new Date(completedRecord.timestamp).toLocaleTimeString()}</span>
            </div>
          </div>

          <button
            onClick={() => { reset(); }}
            className="text-xs text-primary hover:text-primary/80 transition-colors font-semibold"
          >
            + Verify another peer
          </button>
        </div>
      )}
    </div>
  );
}
