//! Criterion benchmarks for codec encode/decode throughput.
//!
//! Run with: `cargo bench -p categorical-codec`

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};

use categorical_codec::{
    Codec, CodecsBrailleQ0, CodecsBrailleQ1, CodecsBrailleQ2, CodecsBrailleQ3,
    NumeralsSystemsBinary, NumeralsSystemsDecimal, NumeralsSystemsHexadecimal,
    NumeralsSystemsMod96crt,
};

/// Input sizes to benchmark (in bytes).
const INPUT_SIZES: &[usize] = &[1, 4, 16, 64, 256, 1024];

/// Generate test data of the specified size.
fn generate_input(size: usize) -> Vec<u8> {
    (0..size).map(|i| (i % 256) as u8).collect()
}

// =============================================================================
// Base-N Codec Benchmarks
// =============================================================================

fn bench_binary_codec(c: &mut Criterion) {
    let codec = NumeralsSystemsBinary;
    let mut group = c.benchmark_group("binary");

    for &size in INPUT_SIZES {
        let input = generate_input(size);
        group.throughput(Throughput::Bytes(size as u64));

        group.bench_with_input(BenchmarkId::new("encode", size), &input, |b, input| {
            b.iter(|| codec.encode(black_box(input)));
        });

        let encoded = codec.encode(&input).unwrap();
        group.bench_with_input(BenchmarkId::new("decode", size), &encoded, |b, encoded| {
            b.iter(|| codec.decode(black_box(encoded)));
        });
    }

    group.finish();
}

fn bench_decimal_codec(c: &mut Criterion) {
    let codec = NumeralsSystemsDecimal;
    let mut group = c.benchmark_group("decimal");

    for &size in INPUT_SIZES {
        let input = generate_input(size);
        group.throughput(Throughput::Bytes(size as u64));

        group.bench_with_input(BenchmarkId::new("encode", size), &input, |b, input| {
            b.iter(|| codec.encode(black_box(input)));
        });

        let encoded = codec.encode(&input).unwrap();
        group.bench_with_input(BenchmarkId::new("decode", size), &encoded, |b, encoded| {
            b.iter(|| codec.decode(black_box(encoded)));
        });
    }

    group.finish();
}

fn bench_hexadecimal_codec(c: &mut Criterion) {
    let codec = NumeralsSystemsHexadecimal;
    let mut group = c.benchmark_group("hexadecimal");

    for &size in INPUT_SIZES {
        let input = generate_input(size);
        group.throughput(Throughput::Bytes(size as u64));

        group.bench_with_input(BenchmarkId::new("encode", size), &input, |b, input| {
            b.iter(|| codec.encode(black_box(input)));
        });

        let encoded = codec.encode(&input).unwrap();
        group.bench_with_input(BenchmarkId::new("decode", size), &encoded, |b, encoded| {
            b.iter(|| codec.decode(black_box(encoded)));
        });
    }

    group.finish();
}

fn bench_mod96crt_codec(c: &mut Criterion) {
    let codec = NumeralsSystemsMod96crt;
    let mut group = c.benchmark_group("mod96crt");

    for &size in INPUT_SIZES {
        let input = generate_input(size);
        group.throughput(Throughput::Bytes(size as u64));

        group.bench_with_input(BenchmarkId::new("encode", size), &input, |b, input| {
            b.iter(|| codec.encode(black_box(input)));
        });

        let encoded = codec.encode(&input).unwrap();
        group.bench_with_input(BenchmarkId::new("decode", size), &encoded, |b, encoded| {
            b.iter(|| codec.decode(black_box(encoded)));
        });
    }

    group.finish();
}

// =============================================================================
// Braille Codec Benchmarks
// =============================================================================

fn bench_braille_q0(c: &mut Criterion) {
    let codec = CodecsBrailleQ0;
    let mut group = c.benchmark_group("braille_q0");

    // Q0 is fixed at 1 byte, so we benchmark single operations and batches
    let input = vec![0x42u8];
    group.throughput(Throughput::Elements(1));

    group.bench_function("encode", |b| {
        b.iter(|| codec.encode(black_box(&input)));
    });

    let encoded = codec.encode(&input).unwrap();
    group.bench_function("decode", |b| {
        b.iter(|| codec.decode(black_box(&encoded)));
    });

    // Batch test: encode 256 values (all possible bytes)
    group.throughput(Throughput::Elements(256));
    group.bench_function("encode_all_256", |b| {
        b.iter(|| {
            for byte in 0..=255u8 {
                let _ = codec.encode(black_box(&[byte]));
            }
        });
    });

    group.finish();
}

fn bench_braille_q1(c: &mut Criterion) {
    let codec = CodecsBrailleQ1;
    let mut group = c.benchmark_group("braille_q1");

    let input = vec![0xAB, 0xCD];
    group.throughput(Throughput::Bytes(2));

    group.bench_function("encode", |b| {
        b.iter(|| codec.encode(black_box(&input)));
    });

    let encoded = codec.encode(&input).unwrap();
    group.bench_function("decode", |b| {
        b.iter(|| codec.decode(black_box(&encoded)));
    });

    group.finish();
}

fn bench_braille_q2(c: &mut Criterion) {
    let codec = CodecsBrailleQ2;
    let mut group = c.benchmark_group("braille_q2");

    let input = vec![0xDE, 0xAD, 0xBE];
    group.throughput(Throughput::Bytes(3));

    group.bench_function("encode", |b| {
        b.iter(|| codec.encode(black_box(&input)));
    });

    let encoded = codec.encode(&input).unwrap();
    group.bench_function("decode", |b| {
        b.iter(|| codec.decode(black_box(&encoded)));
    });

    group.finish();
}

fn bench_braille_q3(c: &mut Criterion) {
    let codec = CodecsBrailleQ3;
    let mut group = c.benchmark_group("braille_q3");

    let input = vec![0xDE, 0xAD, 0xBE, 0xEF];
    group.throughput(Throughput::Bytes(4));

    group.bench_function("encode", |b| {
        b.iter(|| codec.encode(black_box(&input)));
    });

    let encoded = codec.encode(&input).unwrap();
    group.bench_function("decode", |b| {
        b.iter(|| codec.decode(black_box(&encoded)));
    });

    group.finish();
}

// =============================================================================
// Comparison Benchmarks
// =============================================================================

fn bench_codec_comparison(c: &mut Criterion) {
    let mut group = c.benchmark_group("comparison_64bytes");

    let input = generate_input(64);
    group.throughput(Throughput::Bytes(64));

    // Binary (passthrough - baseline)
    let binary = NumeralsSystemsBinary;
    group.bench_function("binary_encode", |b| {
        b.iter(|| binary.encode(black_box(&input)));
    });

    // Decimal
    let decimal = NumeralsSystemsDecimal;
    group.bench_function("decimal_encode", |b| {
        b.iter(|| decimal.encode(black_box(&input)));
    });

    // Hexadecimal
    let hex = NumeralsSystemsHexadecimal;
    group.bench_function("hexadecimal_encode", |b| {
        b.iter(|| hex.encode(black_box(&input)));
    });

    // Mod96 CRT
    let mod96 = NumeralsSystemsMod96crt;
    group.bench_function("mod96crt_encode", |b| {
        b.iter(|| mod96.encode(black_box(&input)));
    });

    group.finish();
}

criterion_group!(
    benches,
    bench_binary_codec,
    bench_decimal_codec,
    bench_hexadecimal_codec,
    bench_mod96crt_codec,
    bench_braille_q0,
    bench_braille_q1,
    bench_braille_q2,
    bench_braille_q3,
    bench_codec_comparison,
);

criterion_main!(benches);
