export {
  computeTrustScore,
  hasPermission,
  permissionsByScope,
  isConsentActive,
  activeConsents,
} from "./trust-engine";

export {
  generateKeyPair,
  computeFingerprint,
  createFoundingCeremony,
  isCeremonyValid,
  ceremoniesByType,
  trustLevelFromCeremonies,
  initiatePeerCeremony,
  acceptPeerCeremony,
  completePeerCeremony,
  type GeneratedKeyPair,
  type FoundingCeremonyResult,
  type PeerCeremonyInvite,
  type PeerCeremonyStatus,
} from "./ceremony-engine";

export {
  SOVEREIGNTY_DIMENSIONS,
  createDefaultSurface,
  flipEdge,
  flipEdges,
  diffSurfaces,
  createBoundaryCommitment,
  edgesByDimension,
  edgesByState,
  disclosureRatio,
  dimensionDisclosureRatios,
  edgesForDataCategory,
  edgeCountForDataCategory,
  DATA_CATEGORY_EDGE_MAP,
} from "./sovereignty-engine";

export {
  buildMerkleTree,
  createDisclosureProof,
  verifyDisclosureProof,
  proofSummary,
  treeDepth,
  type MerkleTree,
  type MerkleNode,
  type DisclosureProof,
  type RevealedEdge,
  type SiblingEntry,
} from "./disclosure-engine";

export {
  computePathIntegral,
  buildValueGraph,
  pairValueBreakdown,
  strongestSegment,
  weakestSegment,
  pathEfficiency,
  DEFAULT_PATH_INTEGRAL_CONFIG,
} from "./path-integral-engine";

export {
  computeThreeAxisSeparation,
  computeAgentAxis,
  computeDataAxis,
  computeInferenceAxis,
  DEFAULT_THREE_AXIS_CONFIG,
} from "./three-axis-engine";

export {
  generateDilithiumKeyPair,
  sign as pqSign,
  verify as pqVerify,
  algorithmInfo,
  DILITHIUM_PARAMS,
  type PQKeyPair,
  type PQSignature,
} from "./pq-crypto";

export {
  buildBoundaryAttestation,
  buildSanitizedContext,
  type BoundaryAttestation,
  type DimensionClaim,
  type SanitizedContext,
} from "./attestation-engine";

export {
  detectViolations,
  detectViolationsIncremental,
  redactViolations,
  getShieldedDimensions,
  type BoundaryViolation,
  type ViolationReport,
  type ViolationSeverity,
} from "./boundary-violation-detector";
