//! Integration tests for constant propagation from OperationGraph to BackendPlan.
//!
//! These tests verify that constant data (weights, biases) embedded in `OperationGraph`
//! is correctly propagated through the compilation pipeline to `BackendPlan.constants`.

use hologram_compiler::{
    compile, CompilerConfig, ConstantData, DType, OpKind, OpNode, OperationGraph,
};

/// Build a graph: Input + Constant -> Add -> Output
fn make_input_plus_constant_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();

    // Node 0: Input [4] f32
    graph.add_node(OpNode::new(0, OpKind::Input, vec![4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Constant [4] f32 with known values
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant_for_node(1, ConstantData::F32(vec![1.0, 2.0, 3.0, 4.0]));

    // Node 2: Add (input + constant)
    graph.add_node(OpNode::new(2, OpKind::Add, vec![4], DType::F32));
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);

    // Node 3: Output
    graph.add_node(OpNode::new(3, OpKind::Output, vec![4], DType::F32));
    graph.add_edge(2, 3);
    graph.add_output("output", 3);

    graph
}

/// Build a graph: Input * Weight + Bias -> Output (typical dense layer)
fn make_dense_layer_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();

    // Node 0: Input [4] f32
    graph.add_node(OpNode::new(0, OpKind::Input, vec![4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Weight constant [4] f32
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant_for_node(1, ConstantData::F32(vec![0.5, 1.0, 1.5, 2.0]));

    // Node 2: Bias constant [4] f32
    graph.add_node(OpNode::new(2, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant_for_node(2, ConstantData::F32(vec![0.1, 0.2, 0.3, 0.4]));

    // Node 3: Mul (input * weight)
    graph.add_node(OpNode::new(3, OpKind::Mul, vec![4], DType::F32));
    graph.add_edge(0, 3);
    graph.add_edge(1, 3);

    // Node 4: Add (mul_result + bias)
    graph.add_node(OpNode::new(4, OpKind::Add, vec![4], DType::F32));
    graph.add_edge(3, 4);
    graph.add_edge(2, 4);

    // Node 5: Output
    graph.add_node(OpNode::new(5, OpKind::Output, vec![4], DType::F32));
    graph.add_edge(4, 5);
    graph.add_output("output", 5);

    graph
}

#[test]
fn test_constants_propagated_to_plan() {
    let graph = make_input_plus_constant_graph();
    let config = CompilerConfig::default();

    let plan = compile(&graph, &config).expect("compilation failed");

    // Verify constants are embedded
    assert!(
        !plan.constants.is_empty(),
        "BackendPlan.constants should contain the constant data, but is empty"
    );

    // Expected: 4 floats * 4 bytes = 16 bytes
    assert_eq!(plan.constants.len(), 16);

    // Verify the actual constant values
    let expected: Vec<u8> = [1.0f32, 2.0, 3.0, 4.0]
        .iter()
        .flat_map(|f| f.to_le_bytes())
        .collect();
    assert_eq!(plan.constants, expected);
}

#[test]
fn test_multiple_constants_propagated() {
    let graph = make_dense_layer_graph();

    // Debug: print graph constants
    println!("Graph constants count: {}", graph.constants.len());
    for (i, c) in graph.constants.iter().enumerate() {
        println!("  Constant {}: {} bytes", i, c.to_bytes().len());
    }

    // Test with opt_level 2 (default)
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");
    println!("opt_level 2: constants.len() = {}", plan.constants.len());

    // Check buffer types
    for (i, buf) in plan.buffers.iter().enumerate() {
        println!(
            "  Buffer {}: type={:?}, size={}",
            i, buf.buffer_type, buf.size
        );
    }

    // 2 constants * 4 floats * 4 bytes = 32 bytes
    assert_eq!(plan.constants.len(), 32);
}

#[test]
fn test_constants_match_buffer_metadata() {
    let graph = make_input_plus_constant_graph();
    let config = CompilerConfig::default();

    let plan = compile(&graph, &config).expect("compilation failed");

    // Find the Constant buffer
    let constant_buffer = plan
        .buffers
        .iter()
        .find(|b| b.buffer_type == hologram_holo::types::BufferType::Constant)
        .expect("should have a Constant buffer");

    // Constant buffer size should match the constants blob size
    assert_eq!(
        constant_buffer.size,
        plan.constants.len(),
        "Constant buffer size should match constants blob size"
    );
}

#[test]
fn test_empty_constants_when_no_constant_nodes() {
    let mut graph = OperationGraph::new();

    // Simple graph with no constants: Input -> Relu -> Output
    graph.add_node(OpNode::new(0, OpKind::Input, vec![4], DType::F32));
    graph.add_input("input", 0);

    graph.add_node(OpNode::new(1, OpKind::Relu, vec![4], DType::F32));
    graph.add_edge(0, 1);

    graph.add_node(OpNode::new(2, OpKind::Output, vec![4], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // No constants should be present
    assert!(
        plan.constants.is_empty(),
        "Plan should have empty constants when graph has no Constant nodes"
    );
}

#[test]
fn test_i32_constants_propagated() {
    let mut graph = OperationGraph::new();

    // Input
    graph.add_node(OpNode::new(0, OpKind::Input, vec![3], DType::I32));
    graph.add_input("input", 0);

    // Constant [3] i32
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![3], DType::I32));
    graph.add_constant_for_node(1, ConstantData::I32(vec![10, 20, 30]));

    // Add
    graph.add_node(OpNode::new(2, OpKind::Add, vec![3], DType::I32));
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);

    // Output
    graph.add_node(OpNode::new(3, OpKind::Output, vec![3], DType::I32));
    graph.add_edge(2, 3);
    graph.add_output("output", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // 3 i32 * 4 bytes = 12 bytes
    assert_eq!(plan.constants.len(), 12);

    // Verify the actual constant values
    let expected: Vec<u8> = [10i32, 20, 30]
        .iter()
        .flat_map(|i| i.to_le_bytes())
        .collect();
    assert_eq!(plan.constants, expected);
}

#[test]
fn test_u8_constants_propagated() {
    let mut graph = OperationGraph::new();

    // Input
    graph.add_node(OpNode::new(0, OpKind::Input, vec![5], DType::U8));
    graph.add_input("input", 0);

    // Constant [5] u8
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![5], DType::U8));
    graph.add_constant_for_node(1, ConstantData::U8(vec![1, 2, 3, 4, 5]));

    // Add
    graph.add_node(OpNode::new(2, OpKind::Add, vec![5], DType::U8));
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);

    // Output
    graph.add_node(OpNode::new(3, OpKind::Output, vec![5], DType::U8));
    graph.add_edge(2, 3);
    graph.add_output("output", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // 5 u8 * 1 byte = 5 bytes
    assert_eq!(plan.constants.len(), 5);

    // Verify the actual constant values
    assert_eq!(plan.constants, vec![1, 2, 3, 4, 5]);
}

#[test]
fn test_constants_roundtrip_through_serialization() {
    let graph = make_dense_layer_graph();
    let config = CompilerConfig::default();

    let plan = compile(&graph, &config).expect("compilation failed");

    // Serialize
    let bytes = rkyv::to_bytes::<_, 1024>(&plan)
        .expect("serialization failed")
        .to_vec();

    // Deserialize
    let archived = unsafe { rkyv::archived_root::<hologram_holo::BackendPlan>(&bytes) };
    let deserialized: hologram_holo::BackendPlan =
        rkyv::Deserialize::deserialize(archived, &mut rkyv::Infallible)
            .expect("deserialization failed");

    // Verify constants are preserved
    assert_eq!(deserialized.constants, plan.constants);
    assert_eq!(deserialized.constants.len(), 32);
}
