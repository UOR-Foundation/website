import React, { useEffect, useRef, useState } from 'react';
import { RefreshCw, Play, BarChart, Grid } from 'lucide-react';
import { interleaveBigIntBits } from '../services/codec';

const TSPDemo: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [pointCount, setPointCount] = useState(50);
  const [isSolving, setIsSolving] = useState(false);
  const [points, setPoints] = useState<{x: number, y: number}[]>([]);
  const [path, setPath] = useState<number[]>([]);
  const [algorithmName, setAlgorithmName] = useState<string>("");

  const generatePoints = () => {
    const newPoints = Array.from({ length: pointCount }, () => ({
      x: Math.random() * 800,
      y: Math.random() * 500 + 50
    }));
    setPoints(newPoints);
    setPath([]);
    setAlgorithmName("");
  };

  useEffect(() => {
    generatePoints();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pointCount]);

  // Helper to get ontology name for visualization
  const getLevelLabel = (level: number) => {
    if (level === 1) return "L1: Complex (4)";
    if (level === 2) return "L2: Quaternions (16)";
    if (level === 3) return "L3: Octonions (64)";
    if (level === 4) return "L4: Sedenions (256)";
    return `L${level}: Gauge`;
  };

  const solveTSP = async () => {
    setIsSolving(true);
    setPath([]);
    setAlgorithmName("Gauge Address Sort (128-bit Arbitrary Precision)");

    await new Promise(r => setTimeout(r, 300));

    // 1. Calculate Gauge Address for all points
    // To demonstrate First Principles and Arbitrary Scale, we map the canvas coordinates
    // into a 128-bit discrete hyper-space (64 bits per dimension).
    // This produces a 128-bit Z-Order index, far exceeding standard JS number limits.
    const GRID_DIMENSION = 18446744073709551615n; // 2^64 - 1
    const CANVAS_W = 800;
    const CANVAS_H = 600;

    const indices = points.map((p, idx) => {
        // Map Continuous Reals (approx) to Discrete Gauge Grid (Exact BigInt)
        // Formula: floor( (x / Width) * (2^64 - 1) )
        // Using BigInt arithmetic for the scaling to preserve 64-bit precision
        
        // Convert input coordinate to fixed precision BigInt first (scale by 1M to capture decimal)
        const xScaled = BigInt(Math.floor(p.x * 1000)); 
        const yScaled = BigInt(Math.floor(p.y * 1000));
        
        const wScaled = BigInt(CANVAS_W * 1000);
        const hScaled = BigInt(CANVAS_H * 1000);

        // Project to 64-bit Grid
        const bigX = (xScaled * GRID_DIMENSION) / wScaled;
        const bigY = (yScaled * GRID_DIMENSION) / hScaled;
        
        // Use the arbitrary precision service to generate 128-bit index
        const address = interleaveBigIntBits(bigX, bigY);
        
        return { idx, address, p };
    });

    // 2. Sort by Gauge Address
    // BigInt sort
    indices.sort((a, b) => {
        if (a.address < b.address) return -1;
        if (a.address > b.address) return 1;
        return 0;
    });

    const sortedPath = indices.map(i => i.idx);
    
    // Animate
    const currentPath: number[] = [];
    for(let i=0; i<sortedPath.length; i++) {
        currentPath.push(sortedPath[i]);
        setPath([...currentPath]);
        await new Promise(r => setTimeout(r, Math.max(5, 400 / pointCount))); 
    }
    setPath([...currentPath, currentPath[0]]);
    setIsSolving(false);
  };

  // Rendering
  useEffect(() => {
    const canvas = canvasRef.current;
    if(!canvas) return;
    const ctx = canvas.getContext('2d');
    if(!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw Hierarchical Gauge Grid
    const levelsToDraw = [1, 2, 3];
    levelsToDraw.forEach(level => {
        const segments = Math.pow(2, level);
        const w = canvas.width / segments;
        const h = canvas.height / segments;
        
        ctx.strokeStyle = `rgba(59, 130, 246, ${0.1 + (level * 0.05)})`; // Faint blue
        ctx.lineWidth = 1;
        
        // Vertical lines
        for(let i=1; i<segments; i++) {
            ctx.beginPath();
            ctx.moveTo(i * w, 0);
            ctx.lineTo(i * w, canvas.height);
            ctx.stroke();
        }
        // Horizontal lines
        for(let i=1; i<segments; i++) {
            ctx.beginPath();
            ctx.moveTo(0, i * h);
            ctx.lineTo(canvas.width, i * h);
            ctx.stroke();
        }
        
        // Label
        if (level <= 2) {
            ctx.fillStyle = `rgba(148, 163, 184, 0.5)`;
            ctx.font = '10px monospace';
            ctx.fillText(getLevelLabel(level), 5 + (level*10), 15 + (level*10));
        }
    });

    // Draw Path
    if(path.length > 1) {
        ctx.beginPath();
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 2;
        const start = points[path[0]];
        if (start) {
            ctx.moveTo(start.x, start.y);
            for(let i=1; i<path.length; i++) {
                const p = points[path[i]];
                if (p) ctx.lineTo(p.x, p.y);
            }
            ctx.stroke();
        }
    }

    // Draw Points
    points.forEach((p, index) => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
      const isInPath = path.includes(index);
      ctx.fillStyle = isInPath ? '#10b981' : '#ef4444';
      ctx.fill();
      
      if (path.length > 0 && path[path.length-1] === index && isSolving) {
          ctx.strokeStyle = '#f59e0b';
          ctx.lineWidth = 3;
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(p.x, p.y, 10, 0, Math.PI*2);
          ctx.stroke();
      } else {
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    });

  }, [points, path, isSolving]);

  return (
    <div className="h-full flex flex-col p-6 space-y-6">
         <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-lg">
            <h2 className="text-2xl font-bold text-white mb-2">Complexity Decomposition: TSP</h2>
            <p className="text-slate-400 mb-6">
                Hierarchical solution using <strong>Categorical Gauge Addressing</strong>. 
                The 2D plane is mapped to a 128-bit Z-Order curve (interleaved 64-bit BigInt coordinates) to sort points by locality in $O(N \log N)$ time, demonstrating arbitrary precision handling.
            </p>

            <div className="flex flex-wrap gap-4 mb-4 items-center">
                 <button 
                    onClick={generatePoints}
                    disabled={isSolving}
                    className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded flex items-center gap-2"
                >
                    <RefreshCw className="w-4 h-4" /> Reset
                </button>
                <button 
                    onClick={solveTSP}
                    disabled={isSolving}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded flex items-center gap-2 disabled:opacity-50"
                >
                    <Play className="w-4 h-4" /> Solve with Gauge Address
                </button>
                
                <div className="flex items-center gap-2 ml-auto bg-slate-900 p-2 rounded border border-slate-700">
                    <span className="text-slate-400 text-sm">Nodes:</span>
                    <input 
                        type="range" 
                        min="10" 
                        max="500" 
                        value={pointCount} 
                        onChange={(e) => setPointCount(parseInt(e.target.value))}
                        disabled={isSolving}
                        className="w-32"
                    />
                    <span className="text-white font-mono w-8 text-right">{pointCount}</span>
                </div>
            </div>

            <div className="relative w-full aspect-video bg-slate-950 rounded-lg border border-slate-800 overflow-hidden shadow-inner">
                <canvas 
                    ref={canvasRef}
                    width={800} 
                    height={600}
                    className="w-full h-full object-contain"
                />
                
                {algorithmName && (
                     <div className="absolute top-4 left-4">
                        <div className="bg-slate-900/90 backdrop-blur px-4 py-2 rounded border border-blue-500/30 shadow-lg">
                            <span className="text-xs text-slate-400 uppercase tracking-wider block">Algorithm</span>
                            <span className="text-blue-400 font-bold">{algorithmName}</span>
                        </div>
                     </div>
                )}

                {isSolving && (
                    <div className="absolute top-4 right-4 bg-slate-800/80 px-3 py-1 rounded text-emerald-400 font-mono text-sm animate-pulse border border-emerald-500/30 flex items-center gap-2">
                        <BarChart className="w-4 h-4" />
                        Sorting High-Precision Addresses...
                    </div>
                )}
            </div>
         </div>
    </div>
  );
};

export default TSPDemo;