//! Graph validation for Stage 1 IR conversion.
//!
//! Validates the input [`OperationGraph`] before conversion to [`CompileGraph`](crate::graph::CompileGraph).

use std::collections::{HashMap, HashSet};

use crate::error::CompileError;
use crate::graph::{DType, OpKind, OperationGraph};
use crate::shape::{infer_flatten, infer_global_avg_pool, shapes_broadcast_compatible};

/// Validate an operation graph before compilation.
///
/// Checks:
/// - No duplicate node IDs
/// - All edge references are valid
/// - Shape compatibility between connected operations
/// - Data type compatibility between connected operations
/// - Input nodes have no incoming edges
/// - Non-input nodes have required inputs
/// - Named inputs and outputs reference valid nodes
/// - All nodes are reachable from inputs (no orphan nodes)
/// - All nodes contribute to outputs (no dead code)
/// - Constant nodes have associated data
///
/// # Errors
///
/// Returns the first validation error encountered.
pub fn validate_graph(graph: &OperationGraph) -> Result<(), CompileError> {
    validate_node_ids(graph)?;
    validate_edges(graph)?;
    validate_inputs_outputs(graph)?;
    validate_shapes_and_dtypes(graph)?;
    validate_node_connectivity(graph)?;
    validate_reachability(graph)?;
    validate_constants(graph)?;
    Ok(())
}

/// Check for duplicate node IDs.
fn validate_node_ids(graph: &OperationGraph) -> Result<(), CompileError> {
    let mut seen = HashSet::with_capacity(graph.nodes.len());
    for node in &graph.nodes {
        if !seen.insert(node.id) {
            return Err(CompileError::DuplicateNodeId(node.id));
        }
    }
    Ok(())
}

/// Check that all edge references are valid.
fn validate_edges(graph: &OperationGraph) -> Result<(), CompileError> {
    let node_ids: HashSet<u32> = graph.nodes.iter().map(|n| n.id).collect();

    for &(source, target) in &graph.edges {
        if !node_ids.contains(&source) || !node_ids.contains(&target) {
            return Err(CompileError::InvalidEdge {
                src: source,
                dst: target,
            });
        }
    }
    Ok(())
}

/// Check that named inputs and outputs reference valid nodes.
fn validate_inputs_outputs(graph: &OperationGraph) -> Result<(), CompileError> {
    let node_ids: HashSet<u32> = graph.nodes.iter().map(|n| n.id).collect();

    for (name, node_id) in &graph.inputs {
        if !node_ids.contains(node_id) {
            return Err(CompileError::InvalidInput {
                name: name.clone(),
                node_id: *node_id,
            });
        }
    }

    for (name, node_id) in &graph.outputs {
        if !node_ids.contains(node_id) {
            return Err(CompileError::InvalidOutput {
                name: name.clone(),
                node_id: *node_id,
            });
        }
    }

    Ok(())
}

/// Build a map of node ID to shape and dtype.
fn build_node_info(graph: &OperationGraph) -> HashMap<u32, (&[usize], DType)> {
    graph
        .nodes
        .iter()
        .map(|n| (n.id, (n.shape.as_slice(), n.dtype)))
        .collect()
}

/// Check shape and dtype compatibility across edges.
fn validate_shapes_and_dtypes(graph: &OperationGraph) -> Result<(), CompileError> {
    let node_info = build_node_info(graph);

    // Build map of node ID -> OpKind for operation-aware validation
    let node_ops: HashMap<u32, &OpKind> = graph.nodes.iter().map(|n| (n.id, &n.op)).collect();

    for &(source, target) in &graph.edges {
        let Some(&(src_shape, src_dtype)) = node_info.get(&source) else {
            continue; // Edge validation will catch this
        };
        let Some(&(tgt_shape, tgt_dtype)) = node_info.get(&target) else {
            continue;
        };
        let Some(&tgt_op) = node_ops.get(&target) else {
            continue;
        };

        // Check dtype compatibility
        if src_dtype != tgt_dtype && !is_dtype_cast_allowed(src_dtype, tgt_dtype, tgt_op) {
            return Err(CompileError::DTypeMismatch {
                node_id: target,
                expected: format!("{src_dtype:?}"),
                actual: format!("{tgt_dtype:?}"),
            });
        }

        // Check shape compatibility based on target operation
        if !shapes_compatible(src_shape, tgt_shape, tgt_op) {
            return Err(CompileError::ShapeMismatch {
                node_id: target,
                expected: src_shape.to_vec(),
                actual: tgt_shape.to_vec(),
            });
        }
    }

    Ok(())
}

/// Check if dtype cast is implicitly allowed for an operation.
///
/// Some operations naturally have mixed-dtype inputs:
/// - `Gather`: data (any dtype) + indices (I64) → output matches data
/// - `Where`: condition (Bool) + x (any dtype) + y (same) → output matches x/y
/// - `Cast`: explicitly converts between dtypes
fn is_dtype_cast_allowed(src: DType, _tgt: DType, op: &OpKind) -> bool {
    match op {
        // Gather takes data of any dtype + indices of I64/I32
        // Output dtype matches the data, not the indices
        OpKind::Gather { .. } => {
            matches!(src, DType::I64 | DType::I32)
        }
        // Where takes bool condition + x/y of matching dtype
        // Allow bool/f32 condition to differ from output dtype
        // (F32 allowed because comparisons may be represented as F32 1.0/0.0)
        OpKind::Where => matches!(src, DType::Bool | DType::F32),
        // Cast explicitly changes dtype
        OpKind::Cast { .. } => true,
        // All other operations require exact dtype match
        _ => false,
    }
}

/// Check if shapes are compatible for the target operation.
#[allow(clippy::too_many_lines)]
fn shapes_compatible(src_shape: &[usize], tgt_shape: &[usize], tgt_op: &OpKind) -> bool {
    match tgt_op {
        // Binary/ternary operations support NumPy-style broadcasting
        // Where is ternary (cond, x, y) but all inputs must broadcast
        OpKind::Add
        | OpKind::Sub
        | OpKind::Mul
        | OpKind::Div
        | OpKind::Pow
        | OpKind::ElemMin
        | OpKind::ElemMax
        | OpKind::Greater
        | OpKind::Less
        | OpKind::LessOrEqual
        | OpKind::GreaterOrEqual
        | OpKind::Where
        | OpKind::AddSigmoid => shapes_broadcast_compatible(src_shape, tgt_shape),

        // Unary operations require exact shape match
        OpKind::Sigmoid
        | OpKind::Tanh
        | OpKind::Relu
        | OpKind::Gelu
        | OpKind::Silu
        | OpKind::Softmax { .. }
        | OpKind::Sqrt
        | OpKind::Log
        | OpKind::Exp
        | OpKind::Abs
        | OpKind::Load
        | OpKind::Store
        | OpKind::Copy
        | OpKind::Input
        | OpKind::Constant => src_shape == tgt_shape,

        // MatMul / MatMulRelu: validate input dimensions match [m,k] or [k,n], output is [m,n]
        OpKind::MatMul { m, k, n } | OpKind::MatMulRelu { m, k, n } => {
            let is_input_a = src_shape == [*m, *k];
            let is_input_b = src_shape == [*k, *n];
            let valid_output = tgt_shape == [*m, *n];
            (is_input_a || is_input_b) && valid_output
        }

        // BatchMatMul: validate input dimensions for batched matrix multiplication
        // Supports broadcast matmul: [batch, m, k] x [k, n] -> [batch, m, n]
        OpKind::BatchMatMul { batch, m, k, n } => {
            // Build expected shapes
            let mut batched_a: Vec<usize> = batch.clone();
            batched_a.extend([*m, *k]);
            let mut batched_b: Vec<usize> = batch.clone();
            batched_b.extend([*k, *n]);
            let mut expected_out: Vec<usize> = batch.clone();
            expected_out.extend([*m, *n]);

            // A can be batched [batch, m, k] or just the matrix dimensions
            let is_input_a = src_shape == batched_a;
            // B can be batched [batch, k, n] or just 2D [k, n] (broadcast case)
            let is_input_b = src_shape == batched_b || src_shape == [*k, *n];
            let valid_output = tgt_shape == expected_out;
            (is_input_a || is_input_b) && valid_output
        }

        // Reductions can change shape
        OpKind::Sum | OpKind::Max | OpKind::Min | OpKind::Mean => {
            // Reduction output is typically smaller or scalar
            tgt_shape.iter().product::<usize>() <= src_shape.iter().product::<usize>()
        }

        // GlobalAveragePool: [N, C, H, W] -> [N, C, 1, 1]
        OpKind::GlobalAveragePool => {
            infer_global_avg_pool(src_shape).is_some_and(|expected| expected == tgt_shape)
        }

        // Flatten: validate output shape matches inference
        OpKind::Flatten { start_dim } => {
            infer_flatten(src_shape, *start_dim).is_some_and(|expected| expected == tgt_shape)
        }

        // Operations that allow any shape transformation:
        // - Output: buffer size may differ from source logical shape
        // - Categorical: Lift doubles output, others preserve
        // - CallLayer: arbitrary sub-layer transformation
        // - CNN operations: handle shape transformations internally
        OpKind::Output
        | OpKind::Lift
        | OpKind::OrbitClassify
        | OpKind::Encode { .. }
        | OpKind::Decode { .. }
        | OpKind::CallLayer { .. }
        | OpKind::Conv2d { .. }
        | OpKind::BatchNormalization { .. }
        | OpKind::LayerNorm { .. }
        | OpKind::MaxPool { .. }
        | OpKind::AvgPool { .. } => true,

        // Shape operations
        OpKind::Reshape { shape } => {
            // Total element count must match
            src_shape.iter().product::<usize>() == shape.iter().product::<usize>()
        }

        OpKind::Transpose { perm } => {
            // Permutation must have same length as dimensions and valid indices
            perm.len() == src_shape.len() && perm.iter().all(|&p| p < src_shape.len())
        }

        OpKind::Gather { axis } => {
            // Axis must be valid for source shape
            *axis < src_shape.len()
        }

        OpKind::Concat { axis, .. } => {
            // Axis must be valid for target shape
            *axis < tgt_shape.len()
        }

        OpKind::Unsqueeze { axis } => {
            // Output has one more dimension, axis must be valid
            tgt_shape.len() == src_shape.len() + 1 && *axis <= src_shape.len()
        }

        OpKind::Squeeze { axis } => {
            // Axis must be valid and have size 1
            *axis < src_shape.len() && src_shape[*axis] == 1
        }

        OpKind::Slice {
            starts,
            ends,
            steps,
        } => {
            use std::cmp::Ordering;
            // Starts, ends, and steps must match source dimensions
            starts.len() == src_shape.len()
                && ends.len() == src_shape.len()
                && steps.len() == src_shape.len()
                // Validate starts vs ends (accounting for direction based on step sign)
                && starts.iter().zip(ends.iter()).zip(steps.iter()).all(
                    |((&s, &e), &step)| match step.cmp(&0) {
                        Ordering::Greater => s < e, // Forward slice
                        Ordering::Less => s > e,    // Reverse slice
                        Ordering::Equal => false,   // Zero step is invalid
                    },
                )
        }

        OpKind::Split {
            axis,
            split_sizes,
            output_index,
        } => {
            // Axis must be valid
            if *axis >= src_shape.len() {
                return false;
            }
            // output_index must be within split_sizes range
            if *output_index >= split_sizes.len() {
                return false;
            }
            // Sum of split_sizes must equal source dimension along axis
            let sum: usize = split_sizes.iter().sum();
            if sum != src_shape[*axis] {
                return false;
            }
            // Target shape should match split output
            if tgt_shape.len() != src_shape.len() {
                return false;
            }
            for (i, (&src_dim, &tgt_dim)) in src_shape.iter().zip(tgt_shape.iter()).enumerate() {
                if i == *axis {
                    // Along split axis, target should be split_sizes[output_index]
                    if tgt_dim != split_sizes[*output_index] {
                        return false;
                    }
                } else if src_dim != tgt_dim {
                    // Other dims should match
                    return false;
                }
            }
            true
        }

        OpKind::Pad { pads, .. } => {
            // Pads length must match source dimensions
            if pads.len() != src_shape.len() {
                return false;
            }
            // Target shape must be src_shape + padding amounts
            if tgt_shape.len() != src_shape.len() {
                return false;
            }
            for (i, (&src_dim, &tgt_dim)) in src_shape.iter().zip(tgt_shape.iter()).enumerate() {
                let expected = src_dim + pads[i].0 + pads[i].1;
                if tgt_dim != expected {
                    return false;
                }
            }
            true
        }

        OpKind::Cast { .. } => {
            // Shape must be preserved (only dtype changes)
            src_shape == tgt_shape
        }

        OpKind::Tile { multiples } => {
            // Multiples length must match source dimensions
            multiples.len() == src_shape.len()
        }

        OpKind::Expand { shape } => {
            // Target shape must be broadcast-compatible with source
            shapes_broadcast_compatible(src_shape, shape)
        }

        // ViterbiTokenize: input is UTF-8 bytes, output is token IDs
        OpKind::ViterbiTokenize { max_tokens, .. } => {
            // Output should be up to max_tokens u32 values
            tgt_shape.iter().product::<usize>() <= *max_tokens
        }

        // SHA-256: any input size, output is always 32 bytes
        OpKind::Sha256 { .. } | OpKind::DoubleSha256 { .. } => {
            tgt_shape.iter().product::<usize>() == 32
        }
    }
}

/// Build incoming edge map: `node_id` -> list of source node ids.
fn build_incoming_edges(graph: &OperationGraph) -> HashMap<u32, Vec<u32>> {
    let mut incoming: HashMap<u32, Vec<u32>> = HashMap::new();
    for node in &graph.nodes {
        incoming.insert(node.id, Vec::new());
    }
    for &(src, tgt) in &graph.edges {
        if let Some(list) = incoming.get_mut(&tgt) {
            list.push(src);
        }
    }
    incoming
}

/// Check node connectivity requirements.
fn validate_node_connectivity(graph: &OperationGraph) -> Result<(), CompileError> {
    let incoming = build_incoming_edges(graph);

    for node in &graph.nodes {
        let inputs = incoming.get(&node.id).map_or(0, Vec::len);

        // Source nodes (Input, Constant) must have no incoming edges
        if matches!(&node.op, OpKind::Input | OpKind::Constant) {
            if inputs > 0 {
                return Err(CompileError::InputHasEdges { node_id: node.id });
            }
        } else {
            let min = node.op.min_inputs();
            if inputs < min {
                return Err(CompileError::MissingInputs {
                    node_id: node.id,
                    op_name: format!("{:?}", node.op),
                });
            }
        }
    }

    Ok(())
}

/// Validate that all nodes are reachable and contribute to outputs.
///
/// Checks:
/// - All non-input nodes are reachable from at least one input
/// - All non-output nodes lead to at least one output (no dead code)
fn validate_reachability(graph: &OperationGraph) -> Result<(), CompileError> {
    if graph.nodes.is_empty() {
        return Ok(());
    }

    // Build adjacency lists
    let mut forward: HashMap<u32, Vec<u32>> = HashMap::new();
    let mut backward: HashMap<u32, Vec<u32>> = HashMap::new();
    for node in &graph.nodes {
        forward.insert(node.id, Vec::new());
        backward.insert(node.id, Vec::new());
    }
    for &(src, tgt) in &graph.edges {
        if let Some(list) = forward.get_mut(&src) {
            list.push(tgt);
        }
        if let Some(list) = backward.get_mut(&tgt) {
            list.push(src);
        }
    }

    // Find all input nodes (Input, Constant)
    let input_nodes: Vec<u32> = graph
        .nodes
        .iter()
        .filter(|n| matches!(n.op, OpKind::Input | OpKind::Constant))
        .map(|n| n.id)
        .collect();

    // Find all output nodes
    let output_nodes: Vec<u32> = graph
        .nodes
        .iter()
        .filter(|n| matches!(n.op, OpKind::Output))
        .map(|n| n.id)
        .collect();

    // If no inputs or outputs defined, skip reachability check
    if input_nodes.is_empty() || output_nodes.is_empty() {
        return Ok(());
    }

    // Forward reachability: find all nodes reachable from inputs
    let mut reachable_from_inputs: HashSet<u32> = HashSet::new();
    let mut stack: Vec<u32> = input_nodes.clone();
    while let Some(node_id) = stack.pop() {
        if reachable_from_inputs.insert(node_id) {
            if let Some(successors) = forward.get(&node_id) {
                stack.extend(successors.iter().copied());
            }
        }
    }

    // Backward reachability: find all nodes that lead to outputs
    let mut leads_to_output: HashSet<u32> = HashSet::new();
    let mut stack: Vec<u32> = output_nodes.clone();
    while let Some(node_id) = stack.pop() {
        if leads_to_output.insert(node_id) {
            if let Some(predecessors) = backward.get(&node_id) {
                stack.extend(predecessors.iter().copied());
            }
        }
    }

    // Check all nodes
    for node in &graph.nodes {
        // Skip input/constant nodes for forward reachability
        if !matches!(node.op, OpKind::Input | OpKind::Constant)
            && !reachable_from_inputs.contains(&node.id)
        {
            return Err(CompileError::UnreachableFromInputs {
                node_id: node.id,
                op_name: format!("{:?}", node.op),
            });
        }

        // Skip output/constant nodes for backward reachability
        // Constants may be metadata-only (shapes, axes) consumed during compilation
        if !matches!(node.op, OpKind::Output | OpKind::Constant)
            && !leads_to_output.contains(&node.id)
        {
            return Err(CompileError::DeadNode {
                node_id: node.id,
                op_name: format!("{:?}", node.op),
            });
        }
    }

    Ok(())
}

/// Validate that constant nodes have associated data.
fn validate_constants(graph: &OperationGraph) -> Result<(), CompileError> {
    // Count constant nodes
    let constant_node_count = graph
        .nodes
        .iter()
        .filter(|n| matches!(n.op, OpKind::Constant))
        .count();

    // If there are constant nodes but no constant data, that's an error
    if constant_node_count > 0 && graph.constants.is_empty() {
        // Find the first constant node without data
        if let Some(node) = graph
            .nodes
            .iter()
            .find(|n| matches!(n.op, OpKind::Constant))
        {
            return Err(CompileError::MissingConstantData { node_id: node.id });
        }
    }

    // Note: More sophisticated validation would map constant nodes to constant data
    // entries by index. For now, we just verify that if constants exist, data exists.

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::OpNode;

    fn simple_valid_graph() -> OperationGraph {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph
    }

    #[test]
    fn test_valid_graph_passes() {
        let graph = simple_valid_graph();
        assert!(validate_graph(&graph).is_ok());
    }

    #[test]
    fn test_empty_graph_passes() {
        let graph = OperationGraph::new();
        assert!(validate_graph(&graph).is_ok());
    }

    #[test]
    fn test_duplicate_node_id_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_node(OpNode::new(0, OpKind::Relu, vec![1], DType::F32)); // Duplicate!
        let result = validate_graph(&graph);
        assert!(matches!(result, Err(CompileError::DuplicateNodeId(0))));
    }

    #[test]
    fn test_invalid_edge_source_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_edge(99, 0); // Source doesn't exist
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::InvalidEdge { src: 99, dst: 0 })
        ));
    }

    #[test]
    fn test_invalid_edge_target_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_edge(0, 99); // Target doesn't exist
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::InvalidEdge { src: 0, dst: 99 })
        ));
    }

    #[test]
    fn test_invalid_named_input_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_input("x", 99); // Node doesn't exist
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::InvalidInput {
                name,
                node_id: 99
            }) if name == "x"
        ));
    }

    #[test]
    fn test_invalid_named_output_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_output("y", 99); // Node doesn't exist
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::InvalidOutput {
                name,
                node_id: 99
            }) if name == "y"
        ));
    }

    #[test]
    fn test_shape_mismatch_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![4, 5], DType::F32)); // Wrong shape!
        graph.add_edge(0, 1);
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::ShapeMismatch { node_id: 1, .. })
        ));
    }

    #[test]
    fn test_dtype_mismatch_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::I32)); // Wrong dtype!
        graph.add_edge(0, 1);
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::DTypeMismatch { node_id: 1, .. })
        ));
    }

    #[test]
    fn test_input_with_incoming_edge_fails() {
        let mut graph = OperationGraph::new();
        // Create an Input that receives an edge from another Input
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![1], DType::F32)); // Another input
        graph.add_edge(0, 1); // Input shouldn't have incoming edges
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::InputHasEdges { node_id: 1 })
        ));
    }

    #[test]
    fn test_unary_op_missing_input_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Relu, vec![1], DType::F32)); // No input edge!
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::MissingInputs { node_id: 0, .. })
        ));
    }

    #[test]
    fn test_binary_op_missing_inputs_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Add, vec![1], DType::F32)); // Needs 2 inputs!
        graph.add_edge(0, 1); // Only 1 input
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::MissingInputs { node_id: 1, .. })
        ));
    }

    #[test]
    fn test_binary_op_with_two_inputs_passes() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Add, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![2, 3], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        assert!(validate_graph(&graph).is_ok());
    }

    #[test]
    fn test_matmul_missing_inputs_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32));
        graph.add_node(OpNode::new(
            1,
            OpKind::MatMul { m: 2, k: 4, n: 8 },
            vec![2, 8],
            DType::F32,
        ));
        graph.add_edge(0, 1); // Only 1 input, MatMul needs 2
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::MissingInputs { node_id: 1, .. })
        ));
    }

    #[test]
    fn test_matmul_with_two_inputs_passes() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![4, 8], DType::F32));
        graph.add_node(OpNode::new(
            2,
            OpKind::MatMul { m: 2, k: 4, n: 8 },
            vec![2, 8],
            DType::F32,
        ));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![2, 8], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        assert!(validate_graph(&graph).is_ok());
    }

    #[test]
    fn test_reduction_shape_change_passes() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![4, 8], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Sum, vec![4], DType::F32)); // Reduced shape
        graph.add_node(OpNode::new(2, OpKind::Output, vec![4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        assert!(validate_graph(&graph).is_ok());
    }

    #[test]
    fn test_constant_with_incoming_edge_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Constant, vec![1], DType::F32));
        graph.add_edge(0, 1); // Constant shouldn't have incoming edges
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::InputHasEdges { node_id: 1 })
        ));
    }

    #[test]
    fn test_valid_named_io_passes() {
        let mut graph = simple_valid_graph();
        graph.add_input("x", 0);
        graph.add_output("y", 2);
        assert!(validate_graph(&graph).is_ok());
    }

    // ============================================================================
    // Reachability Tests (TASK-111)
    // ============================================================================

    #[test]
    fn test_unreachable_node_fails() {
        let mut graph = OperationGraph::new();
        // Create a valid path: Input -> Relu -> Output
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        // Add unreachable nodes in a cycle (each has an input edge but not from main graph)
        // This passes connectivity check but fails reachability check
        graph.add_node(OpNode::new(3, OpKind::Relu, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(4, OpKind::Sigmoid, vec![2, 3], DType::F32));
        graph.add_edge(3, 4); // 3 -> 4
        graph.add_edge(4, 3); // 4 -> 3 (creates cycle)

        let result = validate_graph(&graph);
        // One of nodes 3 or 4 will be detected as unreachable
        assert!(
            matches!(result, Err(CompileError::UnreachableFromInputs { node_id, .. }) if node_id == 3 || node_id == 4),
            "Expected UnreachableFromInputs for node 3 or 4, got {result:?}"
        );
    }

    #[test]
    fn test_dead_node_fails() {
        let mut graph = OperationGraph::new();
        // Create a valid path: Input -> Relu -> Output
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        // Add a dead node (connected from input but doesn't lead to output)
        graph.add_node(OpNode::new(3, OpKind::Sigmoid, vec![2, 3], DType::F32));
        graph.add_edge(0, 3); // Connected from input but goes nowhere

        let result = validate_graph(&graph);
        assert!(
            matches!(result, Err(CompileError::DeadNode { node_id: 3, .. })),
            "Expected DeadNode for node 3, got {result:?}"
        );
    }

    #[test]
    fn test_branching_graph_passes() {
        let mut graph = OperationGraph::new();
        // Input -> Relu -> Output1
        //       -> Sigmoid -> Output2
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(4, OpKind::Output, vec![2, 3], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(0, 2);
        graph.add_edge(1, 3);
        graph.add_edge(2, 4);
        assert!(validate_graph(&graph).is_ok());
    }

    #[test]
    fn test_merging_graph_passes() {
        let mut graph = OperationGraph::new();
        // Input1 -> Add -> Output
        // Input2 ->
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Add, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![2, 3], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        assert!(validate_graph(&graph).is_ok());
    }

    // ============================================================================
    // Constant Validation Tests (TASK-111)
    // ============================================================================

    #[test]
    fn test_constant_without_data_fails() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Constant, vec![4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Output, vec![4], DType::F32));
        graph.add_edge(0, 1);
        // No graph.constants added!

        let result = validate_graph(&graph);
        assert!(
            matches!(
                result,
                Err(CompileError::MissingConstantData { node_id: 0 })
            ),
            "Expected MissingConstantData, got {result:?}"
        );
    }

    #[test]
    fn test_constant_with_data_passes() {
        use crate::graph::ConstantData;

        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Constant, vec![4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Output, vec![4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_constant_for_node(0, ConstantData::F32(vec![1.0, 2.0, 3.0, 4.0]));

        assert!(validate_graph(&graph).is_ok());
    }

    #[test]
    fn test_no_constants_no_data_passes() {
        // Graph with no Constant nodes should pass even without constants
        let graph = simple_valid_graph();
        assert!(validate_graph(&graph).is_ok());
    }

    // ============================================================================
    // Broadcasting Tests (ResNet18 shape fix)
    // ============================================================================

    #[test]
    fn test_add_broadcast_bias() {
        // ResNet classifier: [1, 1000] + [1000] should pass
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 1000], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![1000], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Add, vec![1, 1000], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![1, 1000], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        assert!(validate_graph(&graph).is_ok());
    }

    #[test]
    fn test_add_broadcast_batch() {
        // Batch-wise bias: [32, 512] + [512] should pass
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![32, 512], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![512], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Add, vec![32, 512], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![32, 512], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        assert!(validate_graph(&graph).is_ok());
    }

    #[test]
    fn test_add_broadcast_incompatible_fails() {
        // Incompatible: [1, 1000] + [999] should fail
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 1000], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![999], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Add, vec![1, 1000], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![1, 1000], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::ShapeMismatch { node_id: 2, .. })
        ));
    }

    // ============================================================================
    // GlobalAveragePool Tests (ResNet18 shape fix)
    // ============================================================================

    #[test]
    fn test_global_avg_pool_valid() {
        // [1, 512, 7, 7] -> [1, 512, 1, 1]
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(
            0,
            OpKind::Input,
            vec![1, 512, 7, 7],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            1,
            OpKind::GlobalAveragePool,
            vec![1, 512, 1, 1],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            2,
            OpKind::Output,
            vec![1, 512, 1, 1],
            DType::F32,
        ));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        assert!(validate_graph(&graph).is_ok());
    }

    #[test]
    fn test_global_avg_pool_wrong_output_fails() {
        // [1, 512, 7, 7] -> [1, 512, 2, 2] should fail (spatial dims must be 1)
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(
            0,
            OpKind::Input,
            vec![1, 512, 7, 7],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            1,
            OpKind::GlobalAveragePool,
            vec![1, 512, 2, 2],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            2,
            OpKind::Output,
            vec![1, 512, 2, 2],
            DType::F32,
        ));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::ShapeMismatch { node_id: 1, .. })
        ));
    }

    #[test]
    fn test_global_avg_pool_non_4d_fails() {
        // Non-4D input should fail
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 512], DType::F32));
        graph.add_node(OpNode::new(
            1,
            OpKind::GlobalAveragePool,
            vec![1, 512],
            DType::F32,
        ));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![1, 512], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::ShapeMismatch { node_id: 1, .. })
        ));
    }

    // ============================================================================
    // Flatten Tests (ResNet18 shape fix)
    // ============================================================================

    #[test]
    fn test_flatten_start_dim_1() {
        // [1, 512, 1, 1] -> [1, 512] with start_dim=1
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(
            0,
            OpKind::Input,
            vec![1, 512, 1, 1],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            1,
            OpKind::Flatten { start_dim: 1 },
            vec![1, 512],
            DType::F32,
        ));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![1, 512], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        assert!(validate_graph(&graph).is_ok());
    }

    #[test]
    fn test_flatten_element_mismatch_fails() {
        // [1, 512, 1, 1] -> [1, 256] should fail (512 != 256)
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(
            0,
            OpKind::Input,
            vec![1, 512, 1, 1],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            1,
            OpKind::Flatten { start_dim: 1 },
            vec![1, 256],
            DType::F32,
        ));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![1, 256], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        let result = validate_graph(&graph);
        assert!(matches!(
            result,
            Err(CompileError::ShapeMismatch { node_id: 1, .. })
        ));
    }

    // ============================================================================
    // MatMul m=1 Tests (ResNet18 shape fix)
    // ============================================================================

    #[test]
    fn test_matmul_m1_preserves_shape() {
        // [1, 512] x [512, 1000] -> [1, 1000] (not [1000])
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 512], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![512, 1000], DType::F32));
        graph.add_node(OpNode::new(
            2,
            OpKind::MatMul {
                m: 1,
                k: 512,
                n: 1000,
            },
            vec![1, 1000],
            DType::F32,
        ));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![1, 1000], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        assert!(validate_graph(&graph).is_ok());
    }
}
