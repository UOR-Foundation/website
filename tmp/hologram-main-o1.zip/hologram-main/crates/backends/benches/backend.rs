//! Benchmarks for backend execution.
//!
//! Measures instruction throughput for:
//! - Arithmetic operations (Add, Sub, Mul)
//! - Activation functions (Sigmoid, Tanh, Relu)
//! - Reduction operations (Sum, Max, Min)
//! - Matrix multiplication (MatMul)

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};

use hologram_backend::backends::{cpu::CpuBackend, Backend};
use hologram_compiler::{compile, CompilerConfig, DType, OpKind, OpNode, OperationGraph};
use hologram_holo::BackendPlan;

/// Helper to create input data of specified size.
fn make_input(size: usize, seed: f32) -> Vec<u8> {
    let floats: Vec<f32> = (0..size).map(|i| seed + i as f32 * 0.1).collect();
    floats.iter().flat_map(|f| f.to_le_bytes()).collect()
}

/// Helper to create a binary op graph (Add, Sub, Mul).
fn make_binary_op_graph(op: OpKind, size: usize) -> BackendPlan {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![size], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![size], DType::F32);
    let operation = OpNode::new(2, op, vec![size], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![size], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(operation);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("result", 3);

    let config = CompilerConfig::default();
    compile(&graph, &config).expect("compilation failed")
}

/// Helper to create a unary op graph (Sigmoid, Tanh, Relu).
fn make_unary_op_graph(op: OpKind, size: usize) -> BackendPlan {
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![size], DType::F32);
    let operation = OpNode::new(1, op, vec![size], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![size], DType::F32);

    graph.add_node(input);
    graph.add_node(operation);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("result", 2);

    let config = CompilerConfig::default();
    compile(&graph, &config).expect("compilation failed")
}

/// Helper to create a reduction op graph (Sum, Max, Min).
fn make_reduce_op_graph(op: OpKind, size: usize) -> BackendPlan {
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![size], DType::F32);
    let operation = OpNode::new(1, op, vec![1], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![1], DType::F32);

    graph.add_node(input);
    graph.add_node(operation);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("result", 2);

    let config = CompilerConfig::default();
    compile(&graph, &config).expect("compilation failed")
}

/// Helper to create a LayerNorm graph.
/// Shape: [batch_size, feature_dim] with normalization over feature_dim.
fn make_layernorm_graph(batch_size: usize, feature_dim: usize) -> BackendPlan {
    let mut graph = OperationGraph::new();

    // Input [batch_size, feature_dim]
    let input = OpNode::new(0, OpKind::Input, vec![batch_size, feature_dim], DType::F32);
    graph.add_node(input);
    graph.add_input("input", 0);

    // Scale [feature_dim] = all 1.0
    let scale = OpNode::new(1, OpKind::Constant, vec![feature_dim], DType::F32);
    graph.add_node(scale);
    graph.add_constant_for_node(
        1,
        hologram_compiler::ConstantData::F32(vec![1.0; feature_dim]),
    );

    // Bias [feature_dim] = all 0.0
    let bias = OpNode::new(2, OpKind::Constant, vec![feature_dim], DType::F32);
    graph.add_node(bias);
    graph.add_constant_for_node(
        2,
        hologram_compiler::ConstantData::F32(vec![0.0; feature_dim]),
    );

    // LayerNorm
    let layernorm = OpNode::new(
        3,
        OpKind::LayerNorm {
            normalized_dims: 1,
            epsilon: 1e-5,
        },
        vec![batch_size, feature_dim],
        DType::F32,
    );
    graph.add_node(layernorm);
    graph.add_edge(0, 3); // input
    graph.add_edge(1, 3); // scale
    graph.add_edge(2, 3); // bias

    // Output
    let output = OpNode::new(4, OpKind::Output, vec![batch_size, feature_dim], DType::F32);
    graph.add_node(output);
    graph.add_edge(3, 4);
    graph.add_output("result", 4);

    let config = CompilerConfig::default();
    compile(&graph, &config).expect("LayerNorm compilation failed")
}

/// Helper to create a Softmax graph.
/// Shape: [batch_size, axis_size] with softmax over axis_size (axis=-1).
fn make_softmax_graph(batch_size: usize, axis_size: usize) -> BackendPlan {
    let mut graph = OperationGraph::new();

    // Input [batch_size, axis_size]
    let input = OpNode::new(0, OpKind::Input, vec![batch_size, axis_size], DType::F32);
    graph.add_node(input);
    graph.add_input("input", 0);

    // Softmax along last axis
    let softmax = OpNode::new(
        1,
        OpKind::Softmax { axis: -1 },
        vec![batch_size, axis_size],
        DType::F32,
    );
    graph.add_node(softmax);
    graph.add_edge(0, 1);

    // Output
    let output = OpNode::new(2, OpKind::Output, vec![batch_size, axis_size], DType::F32);
    graph.add_node(output);
    graph.add_edge(1, 2);
    graph.add_output("result", 2);

    let config = CompilerConfig::default();
    compile(&graph, &config).expect("Softmax compilation failed")
}

/// Helper to create a MatMul graph.
fn make_matmul_graph(m: usize, n: usize, k: usize) -> BackendPlan {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![m, k], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![k, n], DType::F32);
    let matmul = OpNode::new(2, OpKind::MatMul { m, k, n }, vec![m, n], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![m, n], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(matmul);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("result", 3);

    let config = CompilerConfig::default();
    compile(&graph, &config).expect("compilation failed")
}

fn bench_arithmetic_ops(c: &mut Criterion) {
    let mut group = c.benchmark_group("arithmetic");
    let backend = CpuBackend::new();

    for size in [256, 1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        // Add
        let plan = make_binary_op_graph(OpKind::Add, size);
        let a = make_input(size, 1.0);
        let b = make_input(size, 2.0);
        let inputs: &[&[u8]] = &[&a, &b];
        let mut output = vec![0u8; size * 4];

        group.bench_with_input(BenchmarkId::new("add", size), &size, |bench, _| {
            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
            })
        });

        // Sub
        let plan = make_binary_op_graph(OpKind::Sub, size);

        group.bench_with_input(BenchmarkId::new("sub", size), &size, |bench, _| {
            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
            })
        });

        // Mul
        let plan = make_binary_op_graph(OpKind::Mul, size);

        group.bench_with_input(BenchmarkId::new("mul", size), &size, |bench, _| {
            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
            })
        });
    }

    group.finish();
}

fn bench_activations(c: &mut Criterion) {
    let mut group = c.benchmark_group("activations");
    let backend = CpuBackend::new();

    for size in [256, 1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        let x = make_input(size, -2.0);
        let inputs: &[&[u8]] = &[&x];
        let mut output = vec![0u8; size * 4];

        // Sigmoid
        let plan = make_unary_op_graph(OpKind::Sigmoid, size);

        group.bench_with_input(BenchmarkId::new("sigmoid", size), &size, |bench, _| {
            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
            })
        });

        // Tanh
        let plan = make_unary_op_graph(OpKind::Tanh, size);

        group.bench_with_input(BenchmarkId::new("tanh", size), &size, |bench, _| {
            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
            })
        });

        // Relu
        let plan = make_unary_op_graph(OpKind::Relu, size);

        group.bench_with_input(BenchmarkId::new("relu", size), &size, |bench, _| {
            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
            })
        });
    }

    group.finish();
}

fn bench_reductions(c: &mut Criterion) {
    let mut group = c.benchmark_group("reductions");
    let backend = CpuBackend::new();

    for size in [256, 1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        let x = make_input(size, 1.0);
        let inputs: &[&[u8]] = &[&x];
        let mut output = vec![0u8; 4]; // Single f32 output

        // Sum
        let plan = make_reduce_op_graph(OpKind::Sum, size);

        group.bench_with_input(BenchmarkId::new("sum", size), &size, |bench, _| {
            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
            })
        });

        // Max
        let plan = make_reduce_op_graph(OpKind::Max, size);

        group.bench_with_input(BenchmarkId::new("max", size), &size, |bench, _| {
            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
            })
        });

        // Min
        let plan = make_reduce_op_graph(OpKind::Min, size);

        group.bench_with_input(BenchmarkId::new("min", size), &size, |bench, _| {
            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
            })
        });
    }

    group.finish();
}

fn bench_matmul(c: &mut Criterion) {
    let mut group = c.benchmark_group("matmul");
    let backend = CpuBackend::new();

    // Test various matrix sizes
    // GFLOPS = 2 * M * N * K / time_seconds / 1e9
    // Small sizes (scalar path)
    for (m, n, k) in [(16, 16, 16), (32, 32, 32)] {
        let flops = 2 * m * n * k;
        group.throughput(Throughput::Elements(flops as u64));

        let plan = make_matmul_graph(m, n, k);

        let a = make_input(m * k, 1.0);
        let b = make_input(k * n, 1.0);
        let inputs: &[&[u8]] = &[&a, &b];
        let mut output = vec![0u8; m * n * 4];

        group.bench_with_input(
            BenchmarkId::new("small", format!("{m}x{n}x{k}")),
            &(m, n, k),
            |bench, _| {
                bench.iter(|| {
                    let outputs: &mut [&mut [u8]] = &mut [&mut output];
                    backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
                })
            },
        );
    }

    // Medium sizes (SIMD micro-kernel)
    for (m, n, k) in [(64, 64, 64), (128, 128, 128), (256, 256, 256)] {
        let flops = 2 * m * n * k;
        group.throughput(Throughput::Elements(flops as u64));

        let plan = make_matmul_graph(m, n, k);

        let a = make_input(m * k, 1.0);
        let b = make_input(k * n, 1.0);
        let inputs: &[&[u8]] = &[&a, &b];
        let mut output = vec![0u8; m * n * 4];

        group.bench_with_input(
            BenchmarkId::new("medium", format!("{m}x{n}x{k}")),
            &(m, n, k),
            |bench, _| {
                bench.iter(|| {
                    let outputs: &mut [&mut [u8]] = &mut [&mut output];
                    backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
                })
            },
        );
    }

    // Large sizes (cache-blocking benefits)
    {
        let (m, n, k) = (512, 512, 512);
        let flops = 2 * m * n * k;
        group.throughput(Throughput::Elements(flops as u64));

        let plan = make_matmul_graph(m, n, k);

        let a = make_input(m * k, 1.0);
        let b = make_input(k * n, 1.0);
        let inputs: &[&[u8]] = &[&a, &b];
        let mut output = vec![0u8; m * n * 4];

        group.bench_with_input(
            BenchmarkId::new("large", format!("{m}x{n}x{k}")),
            &(m, n, k),
            |bench, _| {
                bench.iter(|| {
                    let outputs: &mut [&mut [u8]] = &mut [&mut output];
                    backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
                })
            },
        );
    }

    // Non-square matrices
    for (m, n, k) in [(64, 128, 32), (128, 64, 256), (96, 192, 384)] {
        let flops = 2 * m * n * k;
        group.throughput(Throughput::Elements(flops as u64));

        let plan = make_matmul_graph(m, n, k);

        let a = make_input(m * k, 1.0);
        let b = make_input(k * n, 1.0);
        let inputs: &[&[u8]] = &[&a, &b];
        let mut output = vec![0u8; m * n * 4];

        group.bench_with_input(
            BenchmarkId::new("rectangular", format!("{m}x{n}x{k}")),
            &(m, n, k),
            |bench, _| {
                bench.iter(|| {
                    let outputs: &mut [&mut [u8]] = &mut [&mut output];
                    backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
                })
            },
        );
    }

    group.finish();
}

fn bench_layernorm(c: &mut Criterion) {
    let mut group = c.benchmark_group("layernorm");
    let backend = CpuBackend::new();

    // Test various 2D tensor sizes: [batch_size, feature_dim]
    // Small: 64x64 (4K elements)
    // Medium: 512x512 (256K elements)
    // Large: 2048x768 (1.5M elements, common in language models)
    for (batch, features) in [(64, 64), (256, 256), (512, 512), (1024, 768), (2048, 768)] {
        let total_elements = batch * features;
        group.throughput(Throughput::Elements(total_elements as u64));

        let plan = make_layernorm_graph(batch, features);

        let input = make_input(total_elements, 1.0);
        let inputs: &[&[u8]] = &[&input];
        let mut output = vec![0u8; total_elements * 4];

        group.bench_with_input(
            BenchmarkId::new("2d", format!("{batch}x{features}")),
            &(batch, features),
            |bench, _| {
                bench.iter(|| {
                    let outputs: &mut [&mut [u8]] = &mut [&mut output];
                    backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
                })
            },
        );
    }

    group.finish();
}

fn bench_softmax(c: &mut Criterion) {
    let mut group = c.benchmark_group("softmax");
    let backend = CpuBackend::new();

    // Test various 2D tensor sizes: [batch_size, axis_size]
    // Softmax is computed independently per row
    for (batch, axis_size) in [(64, 64), (256, 256), (512, 512), (1024, 1024), (2048, 512)] {
        let total_elements = batch * axis_size;
        group.throughput(Throughput::Elements(total_elements as u64));

        let plan = make_softmax_graph(batch, axis_size);

        let input = make_input(total_elements, 0.5);
        let inputs: &[&[u8]] = &[&input];
        let mut output = vec![0u8; total_elements * 4];

        group.bench_with_input(
            BenchmarkId::new("2d", format!("{batch}x{axis_size}")),
            &(batch, axis_size),
            |bench, _| {
                bench.iter(|| {
                    let outputs: &mut [&mut [u8]] = &mut [&mut output];
                    backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
                })
            },
        );
    }

    group.finish();
}

fn bench_simd_comparison(c: &mut Criterion) {
    let mut group = c.benchmark_group("simd_comparison");
    let backend = CpuBackend::new();

    // Large size to highlight SIMD benefits
    let size = 65536;
    group.throughput(Throughput::Elements(size as u64));

    let a = make_input(size, 1.0);
    let b = make_input(size, 2.0);
    let inputs: &[&[u8]] = &[&a, &b];
    let mut output = vec![0u8; size * 4];

    // Add (uses SIMD path)
    let plan = make_binary_op_graph(OpKind::Add, size);

    group.bench_function("add_simd", |bench| {
        bench.iter(|| {
            let outputs: &mut [&mut [u8]] = &mut [&mut output];
            backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
        })
    });

    // Relu (uses SIMD path)
    let x = make_input(size, -1000.0);
    let inputs: &[&[u8]] = &[&x];

    let plan = make_unary_op_graph(OpKind::Relu, size);

    group.bench_function("relu_simd", |bench| {
        bench.iter(|| {
            let outputs: &mut [&mut [u8]] = &mut [&mut output];
            backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
        })
    });

    group.finish();
}

/// Benchmark LUT-GEMM vs traditional MatMul.
///
/// Compares quantized lookup-table matrix multiplication against the standard
/// SIMD tiled implementation at various batch sizes.
fn bench_lut_matmul(c: &mut Criterion) {
    use hologram_backend::backends::cpu::lut_matmul::{
        matmul_lut_q4, matmul_lut_q8, quantize_weights_q4, quantize_weights_q8,
    };
    use hologram_backend::backends::cpu::matmul_tiled;

    let mut group = c.benchmark_group("lut_matmul");

    // Test various matrix sizes
    // Focus on small batch sizes where LUT-GEMM excels
    for (m, k, n) in [
        (1, 64, 64),
        (4, 64, 64),
        (8, 128, 128),
        (16, 256, 256),
        (32, 256, 256),
    ] {
        let flops = 2 * m * k * n;
        group.throughput(Throughput::Elements(flops as u64));

        // Generate test data
        let a: Vec<f32> = (0..m * k).map(|i| (i as f32 * 0.01).sin()).collect();
        let b: Vec<f32> = (0..k * n).map(|i| (i as f32 * 0.02).cos()).collect();

        // Pre-quantize weights (simulates compile-time quantization)
        let qw_q4 = quantize_weights_q4(&b, k, n);
        let qw_q8 = quantize_weights_q8(&b, k, n);

        // Baseline: traditional tiled MatMul
        group.bench_with_input(
            BenchmarkId::new("tiled", format!("{m}x{k}x{n}")),
            &(m, k, n),
            |bench, _| {
                let mut c = vec![0.0f32; m * n];
                bench.iter(|| {
                    matmul_tiled(black_box(&a), black_box(&b), &mut c, m, k, n);
                })
            },
        );

        // LUT-GEMM Q4 (4-bit quantized)
        group.bench_with_input(
            BenchmarkId::new("lut_q4", format!("{m}x{k}x{n}")),
            &(m, k, n),
            |bench, _| {
                let mut c = vec![0.0f32; m * n];
                bench.iter(|| {
                    matmul_lut_q4(black_box(&a), black_box(&qw_q4), &mut c, m, k, n);
                })
            },
        );

        // LUT-GEMM Q8 (8-bit quantized)
        group.bench_with_input(
            BenchmarkId::new("lut_q8", format!("{m}x{k}x{n}")),
            &(m, k, n),
            |bench, _| {
                let mut c = vec![0.0f32; m * n];
                bench.iter(|| {
                    matmul_lut_q8(black_box(&a), black_box(&qw_q8), &mut c, m, k, n);
                })
            },
        );
    }

    group.finish();
}

criterion_group!(
    benches,
    bench_arithmetic_ops,
    bench_activations,
    bench_reductions,
    bench_matmul,
    bench_layernorm,
    bench_softmax,
    bench_simd_comparison,
    bench_lut_matmul,
);
criterion_main!(benches);
