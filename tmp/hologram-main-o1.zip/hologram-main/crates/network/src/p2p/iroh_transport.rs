//! Iroh-based P2P transport layer.
//!
//! This module provides production-ready P2P networking using Iroh,
//! which includes:
//! - QUIC transport with built-in encryption
//! - NAT traversal and hole punching
//! - Relay server fallback
//! - Content-addressed blob transfer

use crate::error::NetworkError;
use iroh::{Endpoint, NodeAddr, NodeId, SecretKey};
use iroh_blobs::{
    store::{fs::Store as FsStore, mem::Store as MemStore},
    Hash,
};
use std::path::Path;
use std::sync::Arc;
use thiserror::Error;
use tokio::sync::RwLock;

/// Protocol identifier for hologram network.
pub const HOLOGRAM_ALPN: &[u8] = b"hologram/layer/1";

/// Iroh transport error.
#[derive(Debug, Error)]
pub enum IrohError {
    /// Endpoint creation failed.
    #[error("failed to create endpoint: {0}")]
    EndpointCreation(String),

    /// Connection failed.
    #[error("connection failed: {0}")]
    ConnectionFailed(String),

    /// Stream error.
    #[error("stream error: {0}")]
    StreamError(String),

    /// Blob store error.
    #[error("blob store error: {0}")]
    BlobStore(String),

    /// Content not found.
    #[error("content not found: {0}")]
    ContentNotFound(String),

    /// Generic error.
    #[error("{0}")]
    Other(String),
}

impl From<IrohError> for NetworkError {
    fn from(err: IrohError) -> Self {
        match err {
            IrohError::EndpointCreation(msg) | IrohError::ConnectionFailed(msg) => {
                NetworkError::connection_failed(msg)
            }
            IrohError::StreamError(msg) | IrohError::Other(msg) => NetworkError::ProtocolError(msg),
            IrohError::BlobStore(msg) | IrohError::ContentNotFound(msg) => {
                NetworkError::ContentNotFound(msg)
            }
        }
    }
}

/// Configuration for the Iroh transport.
#[derive(Debug, Clone, Default)]
pub struct IrohConfig {
    /// Secret key for the node (generates random if None).
    pub secret_key: Option<SecretKey>,
    /// Path for persistent blob storage (uses memory if None).
    pub blob_store_path: Option<std::path::PathBuf>,
    /// Custom relay URLs (uses default if empty).
    pub relay_urls: Vec<String>,
    /// Enable metrics collection.
    pub enable_metrics: bool,
}

impl IrohConfig {
    /// Create a new configuration.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the secret key.
    #[must_use]
    pub fn with_secret_key(mut self, key: SecretKey) -> Self {
        self.secret_key = Some(key);
        self
    }

    /// Set the blob store path.
    #[must_use]
    pub fn with_blob_store_path(mut self, path: impl Into<std::path::PathBuf>) -> Self {
        self.blob_store_path = Some(path.into());
        self
    }

    /// Add a relay URL.
    #[must_use]
    pub fn with_relay_url(mut self, url: impl Into<String>) -> Self {
        self.relay_urls.push(url.into());
        self
    }

    /// Enable metrics.
    #[must_use]
    pub fn with_metrics(mut self, enable: bool) -> Self {
        self.enable_metrics = enable;
        self
    }
}

/// Iroh-based transport for P2P networking.
///
/// Provides encrypted QUIC connections with automatic NAT traversal.
pub struct IrohTransport {
    /// The iroh endpoint.
    endpoint: Endpoint,
    /// Our node ID.
    node_id: NodeId,
    /// Known peers.
    peers: Arc<RwLock<std::collections::HashMap<NodeId, NodeAddr>>>,
}

impl IrohTransport {
    /// Create a new Iroh transport with default configuration.
    pub async fn new() -> Result<Self, IrohError> {
        Self::with_config(IrohConfig::default()).await
    }

    /// Create a new Iroh transport with custom configuration.
    pub async fn with_config(config: IrohConfig) -> Result<Self, IrohError> {
        let secret_key = config
            .secret_key
            .unwrap_or_else(|| SecretKey::generate(&mut rand::rngs::OsRng));

        let mut builder = Endpoint::builder().secret_key(secret_key.clone());

        // Add ALPN protocol
        builder = builder.alpns(vec![HOLOGRAM_ALPN.to_vec()]);

        let endpoint = builder
            .bind()
            .await
            .map_err(|e| IrohError::EndpointCreation(format!("failed to bind endpoint: {e}")))?;

        let node_id = endpoint.node_id();

        tracing::info!(node_id = %node_id, "Iroh transport initialized");

        Ok(Self {
            endpoint,
            node_id,
            peers: Arc::new(RwLock::new(std::collections::HashMap::new())),
        })
    }

    /// Get our node ID.
    #[must_use]
    pub fn node_id(&self) -> NodeId {
        self.node_id
    }

    /// Get our node address for sharing with peers.
    pub async fn node_addr(&self) -> NodeAddr {
        self.endpoint.node_addr().await.unwrap_or_else(|_| {
            // Fallback to just node_id if we can't get full address
            NodeAddr::new(self.node_id)
        })
    }

    /// Add a known peer.
    pub async fn add_peer(&self, addr: NodeAddr) {
        self.peers.write().await.insert(addr.node_id, addr);
    }

    /// Connect to a peer.
    pub async fn connect(&self, addr: NodeAddr) -> Result<iroh::endpoint::Connection, IrohError> {
        // Add to known peers
        self.add_peer(addr.clone()).await;

        // Connect using our ALPN
        let conn = self
            .endpoint
            .connect(addr, HOLOGRAM_ALPN)
            .await
            .map_err(|e| IrohError::ConnectionFailed(format!("failed to connect: {e}")))?;

        if let Ok(peer_id) = conn.remote_node_id() {
            tracing::debug!(peer = %peer_id, "Connected to peer");
        }

        Ok(conn)
    }

    /// Accept incoming connections.
    pub async fn accept(&self) -> Result<iroh::endpoint::Connection, IrohError> {
        let incoming = self
            .endpoint
            .accept()
            .await
            .ok_or_else(|| IrohError::ConnectionFailed("endpoint closed".to_string()))?;

        let conn = incoming
            .await
            .map_err(|e| IrohError::ConnectionFailed(format!("accept failed: {e}")))?;

        if let Ok(peer_id) = conn.remote_node_id() {
            tracing::debug!(peer_id = %peer_id, "Accepted connection from peer");
        }

        Ok(conn)
    }

    /// Get the number of known peers.
    pub async fn peer_count(&self) -> usize {
        self.peers.read().await.len()
    }

    /// Get all known peer IDs.
    pub async fn known_peers(&self) -> Vec<NodeId> {
        self.peers.read().await.keys().copied().collect()
    }

    /// Close the transport.
    pub async fn close(self) {
        self.endpoint.close().await;
        tracing::info!("Iroh transport closed");
    }
}

/// Blob store type enum (since Store trait is not dyn-safe).
#[allow(dead_code)] // Variant fields stored but only pattern-matched, not read
pub enum BlobStoreKind {
    /// In-memory store.
    Memory(MemStore),
    /// Filesystem-backed store.
    Filesystem(FsStore),
}

/// Iroh-based content store using iroh-blobs.
pub struct IrohBlobStore {
    store: BlobStoreKind,
}

impl IrohBlobStore {
    /// Create an in-memory blob store.
    #[must_use]
    pub fn in_memory() -> Self {
        Self {
            store: BlobStoreKind::Memory(MemStore::new()),
        }
    }

    /// Create a persistent blob store at the given path.
    pub async fn persistent(path: impl AsRef<Path>) -> Result<Self, IrohError> {
        let store = FsStore::load(path)
            .await
            .map_err(|e| IrohError::BlobStore(format!("failed to load store: {e}")))?;

        Ok(Self {
            store: BlobStoreKind::Filesystem(store),
        })
    }

    /// Compute the hash for data (without storing).
    #[must_use]
    pub fn hash(data: &[u8]) -> Hash {
        iroh_blobs::Hash::new(data)
    }

    /// Check if this is a memory store.
    #[must_use]
    pub fn is_memory(&self) -> bool {
        matches!(self.store, BlobStoreKind::Memory(_))
    }

    /// Check if this is a filesystem store.
    #[must_use]
    pub fn is_filesystem(&self) -> bool {
        matches!(self.store, BlobStoreKind::Filesystem(_))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_iroh_config_default() {
        let config = IrohConfig::default();
        assert!(config.secret_key.is_none());
        assert!(config.blob_store_path.is_none());
        assert!(config.relay_urls.is_empty());
        assert!(!config.enable_metrics);
    }

    #[test]
    fn test_iroh_config_builder() {
        let config = IrohConfig::new()
            .with_blob_store_path("/tmp/blobs")
            .with_relay_url("https://relay.example.com")
            .with_metrics(true);

        assert_eq!(
            config.blob_store_path,
            Some(std::path::PathBuf::from("/tmp/blobs"))
        );
        assert_eq!(config.relay_urls, vec!["https://relay.example.com"]);
        assert!(config.enable_metrics);
    }

    #[test]
    fn test_iroh_error_display() {
        let err = IrohError::ConnectionFailed("timeout".to_string());
        assert!(err.to_string().contains("timeout"));

        let err = IrohError::ContentNotFound("abc123".to_string());
        assert!(err.to_string().contains("abc123"));
    }

    #[tokio::test]
    async fn test_iroh_transport_creation() {
        let transport = IrohTransport::new().await.unwrap();
        assert_eq!(transport.peer_count().await, 0);

        // Node ID should be set
        let node_id = transport.node_id();
        assert!(!node_id.as_bytes().iter().all(|&b| b == 0));

        transport.close().await;
    }

    #[tokio::test]
    async fn test_iroh_transport_node_addr() {
        let transport = IrohTransport::new().await.unwrap();
        let addr = transport.node_addr().await;

        // Address should contain our node ID
        assert_eq!(addr.node_id, transport.node_id());

        transport.close().await;
    }

    #[tokio::test]
    async fn test_iroh_transport_add_peer() {
        let transport = IrohTransport::new().await.unwrap();

        // Create a fake peer address
        let peer_key = SecretKey::generate(&mut rand::rngs::OsRng);
        let peer_id = peer_key.public();
        let peer_addr = NodeAddr::new(peer_id);

        transport.add_peer(peer_addr).await;
        assert_eq!(transport.peer_count().await, 1);
        assert!(transport.known_peers().await.contains(&peer_id));

        transport.close().await;
    }

    #[test]
    fn test_iroh_blob_store_memory() {
        let store = IrohBlobStore::in_memory();
        assert!(store.is_memory());
        assert!(!store.is_filesystem());
    }

    #[test]
    fn test_iroh_blob_hash() {
        let data = b"hello world";
        let hash = IrohBlobStore::hash(data);

        // Same data should produce same hash
        let hash2 = IrohBlobStore::hash(data);
        assert_eq!(hash, hash2);

        // Different data should produce different hash
        let hash3 = IrohBlobStore::hash(b"different");
        assert_ne!(hash, hash3);
    }
}
