//! Backend execution plans.
//!
//! This module defines the `BackendPlan` struct - an immutable, fully-resolved
//! execution plan that can be executed with O(1) runtime overhead.
//!
//! # Design Principles
//!
//! - Immutable after creation
//! - Backend-specific (CPU plan != CUDA plan)
//! - Executable without inspecting shapes or layouts
//! - No branching in execute() except bounds checks
//!
//! # Compile-Time vs Runtime
//!
//! All expensive decisions happen at compile time:
//! - Kernel selection
//! - Tiling parameters
//! - Memory layout
//! - Thread partitioning
//!
//! Runtime execution is just:
//! - Pointer chasing
//! - Precomputed offsets
//! - Tight SIMD loops

// Allow missing docs for rkyv-generated archived types
#![allow(missing_docs)]

use super::markers::ZeroCopyPath;
use crate::{BackendError, BackendType, BufferHandle};
use hologram_common::categorical::BYTE_META_TABLE;
use hologram_ir::DimExpr;
use hologram_lookup::fusion::activation::{GELU_U8, RELU_U8, SIGMOID_U8, SILU_U8, TANH_U8};
use hologram_lookup::PACKED_TABLE;
use parking_lot::RwLock;
use rkyv::{Archive, Deserialize as RkyvDeserialize, Serialize as RkyvSerialize};
use std::collections::HashMap;
use std::sync::OnceLock;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Unique identifier for a kernel.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct KernelId(pub u32);

impl KernelId {
    // ========================================================================
    // Category Constants (upper byte of kernel_id)
    // ========================================================================

    /// No-op / Passthrough category.
    pub const CATEGORY_NOOP: u8 = 0x00;
    /// GEMM (General Matrix Multiply) category.
    pub const CATEGORY_GEMM: u8 = 0x01;
    /// Convolution category.
    pub const CATEGORY_CONV: u8 = 0x02;
    /// Binary elementwise operations category.
    pub const CATEGORY_ELEMENTWISE_BINARY: u8 = 0x03;
    /// Unary activation functions category.
    pub const CATEGORY_ACTIVATION: u8 = 0x04;
    /// Transcendental functions category.
    pub const CATEGORY_TRANSCENDENTAL: u8 = 0x05;
    /// Reduction operations category.
    pub const CATEGORY_REDUCE: u8 = 0x06;
    /// Tensor manipulation category.
    pub const CATEGORY_TENSOR_OPS: u8 = 0x07;
    /// Normalization operations category.
    pub const CATEGORY_NORMALIZATION: u8 = 0x08;
    /// Loss functions category.
    pub const CATEGORY_LOSS: u8 = 0x09;
    /// Comparison operations category.
    pub const CATEGORY_COMPARISON: u8 = 0x0A;
    /// Bitwise operations category.
    pub const CATEGORY_BITWISE: u8 = 0x0B;
    /// Linear algebra (non-GEMM) category.
    pub const CATEGORY_LINALG: u8 = 0x0C;
    /// Pooling operations category.
    pub const CATEGORY_POOLING: u8 = 0x0D;
    /// Categorical algebra operations category (resonance ring ℤ₉₆).
    pub const CATEGORY_CATEGORICAL: u8 = 0x0E;
    /// Metadata/auxiliary category.
    pub const CATEGORY_METADATA: u8 = 0x10;
    /// Minimum value for dynamic/custom kernel categories.
    pub const CATEGORY_DYNAMIC_MIN: u8 = 0x10;

    // ========================================================================
    // 0x00XX: No-op / Passthrough
    // ========================================================================

    /// No-op kernel (passthrough, reshape, etc.).
    pub const NOOP: Self = Self(0x0000);

    // ========================================================================
    // 0x01XX: GEMM (General Matrix Multiply)
    // ========================================================================

    /// Standard GEMM kernel.
    pub const GEMM_STANDARD: Self = Self(0x0101);
    /// Strassen GEMM kernel for large matrices.
    pub const GEMM_STRASSEN: Self = Self(0x0102);
    /// Tiled GEMM kernel.
    pub const GEMM_TILED: Self = Self(0x0103);
    /// Batch GEMM kernel.
    pub const GEMM_BATCH: Self = Self(0x0104);

    // ========================================================================
    // 0x02XX: Convolution
    // ========================================================================

    /// Direct convolution kernel.
    pub const CONV_DIRECT: Self = Self(0x0201);
    /// Im2Col convolution kernel.
    pub const CONV_IM2COL: Self = Self(0x0202);
    /// Winograd F(2,3) convolution kernel.
    pub const CONV_WINOGRAD_F23: Self = Self(0x0203);
    /// Winograd F(4,3) convolution kernel.
    pub const CONV_WINOGRAD_F43: Self = Self(0x0204);
    /// 1D convolution kernel.
    pub const CONV_1D: Self = Self(0x0205);
    /// Depthwise convolution kernel.
    pub const CONV_DEPTHWISE: Self = Self(0x0206);

    // ========================================================================
    // 0x03XX: Binary Elementwise Operations
    // ========================================================================

    /// Element-wise addition.
    pub const ELEM_ADD: Self = Self(0x0301);
    /// Element-wise subtraction.
    pub const ELEM_SUB: Self = Self(0x0302);
    /// Element-wise multiplication.
    pub const ELEM_MUL: Self = Self(0x0303);
    /// Element-wise division.
    pub const ELEM_DIV: Self = Self(0x0304);
    /// Element-wise maximum.
    pub const ELEM_MAX: Self = Self(0x0305);
    /// Element-wise minimum.
    pub const ELEM_MIN: Self = Self(0x0306);
    /// Element-wise power.
    pub const ELEM_POW: Self = Self(0x0307);
    /// Element-wise modulo.
    pub const ELEM_MOD: Self = Self(0x0308);

    // ========================================================================
    // 0x04XX: Unary Activation Functions
    // ========================================================================

    /// ReLU activation.
    pub const ACT_RELU: Self = Self(0x0401);
    /// Sigmoid activation.
    pub const ACT_SIGMOID: Self = Self(0x0402);
    /// Tanh activation.
    pub const ACT_TANH: Self = Self(0x0403);
    /// GELU activation.
    pub const ACT_GELU: Self = Self(0x0404);
    /// SiLU (Swish) activation.
    pub const ACT_SILU: Self = Self(0x0405);
    /// Mish activation.
    pub const ACT_MISH: Self = Self(0x0406);
    /// Softplus activation.
    pub const ACT_SOFTPLUS: Self = Self(0x0407);
    /// Leaky ReLU activation.
    pub const ACT_LEAKY_RELU: Self = Self(0x0408);
    /// Quantized ReLU activation (u8 table lookup).
    pub const ACT_RELU_U8: Self = Self(0x0409);
    /// Quantized Sigmoid activation (u8 table lookup).
    pub const ACT_SIGMOID_U8: Self = Self(0x040A);
    /// Quantized Tanh activation (u8 table lookup).
    pub const ACT_TANH_U8: Self = Self(0x040B);
    /// Quantized GELU activation (u8 table lookup).
    pub const ACT_GELU_U8: Self = Self(0x040C);
    /// Quantized SiLU activation (u8 table lookup).
    pub const ACT_SILU_U8: Self = Self(0x040D);
    /// Quantized fused Sigmoid->ReLU activation.
    pub const ACT_FUSED_SIGMOID_RELU_U8: Self = Self(0x040E);
    /// Quantized fused Sigmoid->Tanh activation.
    pub const ACT_FUSED_SIGMOID_TANH_U8: Self = Self(0x040F);
    /// Quantized fused Sigmoid->Tanh->ReLU activation.
    pub const ACT_FUSED_SIGMOID_TANH_RELU_U8: Self = Self(0x0410);

    // ========================================================================
    // 0x05XX: Transcendental Functions
    // ========================================================================

    /// Exponential function.
    pub const TRANS_EXP: Self = Self(0x0501);
    /// Natural logarithm.
    pub const TRANS_LOG: Self = Self(0x0502);
    /// Square root.
    pub const TRANS_SQRT: Self = Self(0x0503);
    /// Sine function.
    pub const TRANS_SIN: Self = Self(0x0504);
    /// Cosine function.
    pub const TRANS_COS: Self = Self(0x0505);
    /// Tangent function.
    pub const TRANS_TAN: Self = Self(0x0506);
    /// Inverse sine.
    pub const TRANS_ASIN: Self = Self(0x0507);
    /// Inverse cosine.
    pub const TRANS_ACOS: Self = Self(0x0508);
    /// Negate (multiply by -1).
    pub const UNARY_NEG: Self = Self(0x0509);
    /// Absolute value.
    pub const UNARY_ABS: Self = Self(0x050A);
    /// Error function (erf).
    pub const TRANS_ERF: Self = Self(0x050B);

    // ========================================================================
    // 0x06XX: Reduction Operations
    // ========================================================================

    /// Sum reduction.
    pub const REDUCE_SUM: Self = Self(0x0601);
    /// Max reduction.
    pub const REDUCE_MAX: Self = Self(0x0602);
    /// Min reduction.
    pub const REDUCE_MIN: Self = Self(0x0603);
    /// Mean reduction.
    pub const REDUCE_MEAN: Self = Self(0x0604);
    /// Variance reduction.
    pub const REDUCE_VARIANCE: Self = Self(0x0605);
    /// ArgMax reduction.
    pub const REDUCE_ARGMAX: Self = Self(0x0606);
    /// ArgMin reduction.
    pub const REDUCE_ARGMIN: Self = Self(0x0607);
    /// Product reduction.
    pub const REDUCE_PROD: Self = Self(0x0608);
    /// ArgMax over last token position.
    pub const REDUCE_ARGMAX_LAST_TOKEN: Self = Self(0x0609);

    // ========================================================================
    // 0x07XX: Tensor Manipulation
    // ========================================================================

    /// Gather operation.
    pub const TENSOR_GATHER: Self = Self(0x0701);
    /// Slice operation.
    pub const TENSOR_SLICE: Self = Self(0x0702);
    /// Concat operation.
    pub const TENSOR_CONCAT: Self = Self(0x0703);
    /// Reshape operation (noop in memory).
    pub const TENSOR_RESHAPE: Self = Self(0x0704);
    /// Expand operation.
    pub const TENSOR_EXPAND: Self = Self(0x0705);
    /// Tile operation.
    pub const TENSOR_TILE: Self = Self(0x0706);
    /// Squeeze operation.
    pub const TENSOR_SQUEEZE: Self = Self(0x0707);
    /// Unsqueeze operation.
    pub const TENSOR_UNSQUEEZE: Self = Self(0x0708);
    /// Transpose operation.
    pub const TENSOR_TRANSPOSE: Self = Self(0x0709);
    /// Shape query operation.
    pub const TENSOR_SHAPE: Self = Self(0x070A);
    /// Range generation operation.
    pub const TENSOR_RANGE: Self = Self(0x070B);
    /// ConstantOfShape operation.
    pub const TENSOR_CONSTANT_SHAPE: Self = Self(0x070C);
    /// Trilu (triangular) operation.
    pub const TENSOR_TRILU: Self = Self(0x070D);
    /// ScatterND operation.
    pub const TENSOR_SCATTER_ND: Self = Self(0x070E);
    /// Split operation.
    pub const TENSOR_SPLIT: Self = Self(0x070F);

    // ========================================================================
    // 0x08XX: Normalization Operations
    // ========================================================================

    /// Batch normalization.
    pub const NORM_BATCH: Self = Self(0x0801);
    /// Layer normalization.
    pub const NORM_LAYER: Self = Self(0x0802);
    /// Softmax normalization.
    pub const NORM_SOFTMAX: Self = Self(0x0803);
    /// Log softmax.
    pub const NORM_LOG_SOFTMAX: Self = Self(0x0804);
    /// Instance normalization.
    pub const NORM_INSTANCE: Self = Self(0x0805);
    /// Group normalization.
    pub const NORM_GROUP: Self = Self(0x0806);

    // ========================================================================
    // 0x09XX: Loss Functions
    // ========================================================================

    /// Cross entropy loss.
    pub const LOSS_CROSS_ENTROPY: Self = Self(0x0901);
    /// Mean squared error loss.
    pub const LOSS_MSE: Self = Self(0x0902);
    /// Mean absolute error loss.
    pub const LOSS_MAE: Self = Self(0x0903);
    /// Huber loss.
    pub const LOSS_HUBER: Self = Self(0x0904);

    // ========================================================================
    // 0x0AXX: Comparison Operations
    // ========================================================================

    /// Less than comparison.
    pub const CMP_LESS: Self = Self(0x0A01);
    /// Equal comparison.
    pub const CMP_EQUAL: Self = Self(0x0A02);
    /// Greater than comparison.
    pub const CMP_GREATER: Self = Self(0x0A03);
    /// Less than or equal comparison.
    pub const CMP_LESS_EQUAL: Self = Self(0x0A04);
    /// Greater than or equal comparison.
    pub const CMP_GREATER_EQUAL: Self = Self(0x0A05);
    /// Not equal comparison.
    pub const CMP_NOT_EQUAL: Self = Self(0x0A06);

    // ========================================================================
    // 0x0BXX: Bitwise Operations
    // ========================================================================

    /// Bitwise AND.
    pub const BIT_AND: Self = Self(0x0B01);
    /// Bitwise OR.
    pub const BIT_OR: Self = Self(0x0B02);
    /// Bitwise XOR.
    pub const BIT_XOR: Self = Self(0x0B03);
    /// Bitwise NOT.
    pub const BIT_NOT: Self = Self(0x0B04);
    /// Bit shift left.
    pub const BIT_SHL: Self = Self(0x0B05);
    /// Bit shift right.
    pub const BIT_SHR: Self = Self(0x0B06);
    /// Bit rotate right.
    pub const BIT_ROTR: Self = Self(0x0B07);
    /// Bit rotate left.
    pub const BIT_ROTL: Self = Self(0x0B08);

    // ========================================================================
    // 0x0CXX: Linear Algebra (non-GEMM)
    // ========================================================================

    /// Matrix-vector multiply.
    pub const LINALG_MATVEC: Self = Self(0x0C01);
    /// Vector-matrix multiply.
    pub const LINALG_VECMAT: Self = Self(0x0C02);
    /// Dot product.
    pub const LINALG_DOT: Self = Self(0x0C03);
    /// Outer product.
    pub const LINALG_OUTER: Self = Self(0x0C04);
    /// Batch matrix multiply.
    pub const LINALG_BATCH_MATMUL: Self = Self(0x0C05);

    // ========================================================================
    // 0x0DXX: Pooling Operations
    // ========================================================================

    /// Max pooling.
    pub const POOL_MAX: Self = Self(0x0D01);
    /// Average pooling.
    pub const POOL_AVG: Self = Self(0x0D02);
    /// Global max pooling.
    pub const POOL_GLOBAL_MAX: Self = Self(0x0D03);
    /// Global average pooling.
    pub const POOL_GLOBAL_AVG: Self = Self(0x0D04);

    // ========================================================================
    // 0x0EXX: Categorical Algebra Operations (Resonance Ring ℤ₉₆)
    // ========================================================================

    /// Character product in ℤ₉₆: (a × b) mod 96.
    pub const CATEGORICAL_CHAR_PRODUCT: Self = Self(0x0E01);
    /// Orbit classification: byte → orbit class (0-31).
    pub const CATEGORICAL_ORBIT_CLASSIFY: Self = Self(0x0E02);
    /// Lift operation: val % 96.
    pub const CATEGORICAL_LIFT: Self = Self(0x0E03);
    /// Multiplicative inverse in ℤ₉₆ unit group.
    pub const CATEGORICAL_MULT_INVERSE: Self = Self(0x0E04);
    /// Monster group character table lookup (194×194).
    pub const CATEGORICAL_MONSTER_CHAR: Self = Self(0x0E05);

    // ========================================================================
    // 0x10XX+: Dynamic / Custom Kernels (Runtime Registered)
    // ========================================================================

    /// Base ID for dynamic kernels.
    pub const DYNAMIC_BASE: Self = Self(0x1000);

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /// Get the category of this kernel ID (upper byte).
    #[inline]
    pub const fn category(&self) -> u8 {
        (self.0 >> 8) as u8
    }

    /// Get the index within the category (lower byte).
    #[inline]
    pub const fn index(&self) -> u8 {
        (self.0 & 0xFF) as u8
    }

    /// Check if this is a dynamic (runtime-registered) kernel.
    #[inline]
    pub const fn is_dynamic(&self) -> bool {
        self.0 >= 0x1000
    }

    /// Get the dynamic kernel index (offset from DYNAMIC_BASE).
    #[inline]
    pub const fn dynamic_index(&self) -> Option<usize> {
        if self.is_dynamic() {
            Some((self.0 - 0x1000) as usize)
        } else {
            None
        }
    }
}

// SAFETY: KernelId is Copy, Send, Sync, has no heap allocation, and is fixed size (u32).
unsafe impl ZeroCopyPath for KernelId {}

/// Pre-resolved buffer reference for zero-overhead dispatch.
///
/// The enum discriminant tells the executor exactly which buffer array
/// to access, eliminating runtime comparisons. The match compiles to
/// a jump table indexed by the discriminant.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum BufferRef {
    /// Index into the inputs slice provided by caller.
    Input(usize),
    /// Index into the outputs slice provided by caller.
    Output(usize),
    /// Slot index into workspace memory for intermediate results.
    Workspace(usize),
    /// Offset and size into plan.constant_data for embedded constants.
    /// Zero-copy: points directly to constant_data without runtime copying.
    Constant { offset: usize, size: usize },
    /// External constant reference (memory-mapped lazily by the executor).
    /// Includes path, byte offset, and size within the external file.
    ExternalConstant {
        path: String,
        offset: usize,
        size: usize,
    },
}

/// Function pointer type for kernel execution.
///
/// Kernels receive pre-computed parameters and execute without decision-making.
pub type KernelFn = fn(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    tables: &LookupTables,
) -> Result<(), BackendError>;

/// Parameters passed to kernel functions.
///
/// All values are pre-computed during planning, but dimensions can be
/// resolved at runtime for dynamic shapes using `dim_exprs`.
#[derive(Debug, Clone, Default, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct KernelParams {
    /// Dimensions for the operation.
    ///
    /// For static shapes, these contain the actual dimension values.
    /// For dynamic shapes, these contain compile-time defaults that are
    /// overwritten at runtime by resolving `dim_exprs`.
    pub dims: [usize; 4],
    /// Dynamic dimension expressions for runtime resolution.
    ///
    /// When set, these expressions are resolved from actual input tensor
    /// shapes at runtime, allowing the same compiled plan to work with
    /// different input sizes (e.g., varying batch size, sequence length).
    ///
    /// Each entry corresponds to `dims[i]`:
    /// - `None` = use the static value from `dims[i]`
    /// - `Some(DimExpr::Static(n))` = use constant value `n`
    /// - `Some(DimExpr::InputRef { input_id, dim_index })` = read from input tensor shape
    pub dim_exprs: [Option<DimExpr>; 4],
    /// Strides for input tensors.
    pub input_strides: [[usize; 4]; 4],
    /// Strides for output tensors.
    pub output_strides: [[usize; 4]; 4],
    /// Tiling parameters.
    pub tiles: TileParams,
    /// Workspace offset for this kernel.
    pub workspace_offset: usize,
    /// Workspace size needed by this kernel.
    pub workspace_size: usize,
    /// Additional kernel-specific parameters.
    pub extra: [usize; 8],
}

impl KernelParams {
    /// Resolve dimension expressions from actual input tensor shapes.
    ///
    /// This method is called at runtime before kernel execution when
    /// the operation has dynamic dimensions.
    ///
    /// # Arguments
    /// * `input_shapes` - Shapes of input tensors as `[input_id][dim_index]`
    ///
    /// # Returns
    /// A new `KernelParams` with resolved dimension values.
    pub fn resolve_dims(&self, input_shapes: &[[usize; 4]]) -> Self {
        let mut resolved = self.clone();
        for (i, dim_expr) in self.dim_exprs.iter().enumerate() {
            if let Some(expr) = dim_expr {
                if let Some(val) = expr.evaluate(input_shapes) {
                    resolved.dims[i] = val;
                }
            }
        }
        resolved
    }

    /// Resolve dimension expressions with predecessor buffer element counts.
    ///
    /// This method supports `PredecessorElementsDiv` expressions which compute
    /// dimensions from intermediate tensor sizes rather than model inputs.
    ///
    /// # Arguments
    /// * `input_shapes` - Shapes of model input tensors as `[input_id][dim_index]`
    /// * `predecessor_elements` - Element counts of predecessor operation outputs
    ///
    /// # Returns
    /// A new `KernelParams` with resolved dimension values.
    pub fn resolve_dims_with_predecessors(
        &self,
        input_shapes: &[[usize; 4]],
        predecessor_elements: &[usize],
    ) -> Self {
        let mut resolved = self.clone();
        for (i, dim_expr) in self.dim_exprs.iter().enumerate() {
            if let Some(expr) = dim_expr {
                if let Some(val) =
                    expr.evaluate_with_predecessors(input_shapes, predecessor_elements)
                {
                    resolved.dims[i] = val;
                }
            }
        }
        resolved
    }

    /// Check if any dimension requires runtime resolution.
    pub fn has_dynamic_dims(&self) -> bool {
        self.dim_exprs.iter().any(|e| e.is_some())
    }

    /// Check if any dimension requires predecessor buffer information.
    pub fn needs_predecessor_info(&self) -> bool {
        self.dim_exprs
            .iter()
            .any(|e| matches!(e, Some(DimExpr::PredecessorElementsDiv { .. })))
    }
}

/// Table of kernel function pointers organized by category.
///
/// Selected based on SIMD capabilities at process initialization.
/// Never changes during execution. Category matches KernelId upper byte.
#[derive(Clone, Copy)]
pub struct KernelTable {
    // Category 0x01: GEMM (General Matrix Multiply)
    /// GEMM kernels: [standard, strassen, tiled, batch]
    pub gemm: [KernelFn; 4],

    // Category 0x02: Convolution
    /// Convolution kernels: [direct, im2col, winograd_f23, winograd_f43, conv1d, depthwise, _, _]
    pub conv: [KernelFn; 8],

    // Category 0x03: Binary Elementwise
    /// Binary elementwise: [add, sub, mul, div, max, min, pow, mod]
    pub elementwise_binary: [KernelFn; 8],

    // Category 0x04: Unary Activation
    /// Activation kernels: [relu, sigmoid, tanh, gelu, silu, mish, softplus, leaky_relu,
    ///                      relu_u8, sigmoid_u8, tanh_u8, gelu_u8, silu_u8,
    ///                      fused_sigmoid_relu_u8, fused_sigmoid_tanh_u8,
    ///                      fused_sigmoid_tanh_relu_u8]
    pub activation: [KernelFn; 16],

    // Category 0x05: Transcendental + Unary Math
    /// Transcendental: [exp, log, sqrt, sin, cos, tan, asin, acos, neg, abs]
    pub transcendental: [KernelFn; 11],

    // Category 0x06: Reduction
    /// Reduction kernels: [sum, max, min, mean, variance, argmax, argmin, prod, argmax_last_token]
    pub reduce: [KernelFn; 9],

    // Category 0x07: Tensor Manipulation
    /// Tensor ops: [gather, slice, concat, reshape, expand, tile, squeeze, unsqueeze,
    ///              transpose, shape, range, constant_shape, trilu, scatter_nd, split, _]
    pub tensor_ops: [KernelFn; 16],

    // Category 0x08: Normalization
    /// Normalization: [batch_norm, layer_norm, softmax, log_softmax, instance_norm, group_norm, _, _]
    pub normalization: [KernelFn; 8],

    // Category 0x09: Loss Functions
    /// Loss kernels: [cross_entropy, mse, mae, huber]
    pub loss: [KernelFn; 4],

    // Category 0x0A: Comparison
    /// Comparison: [less, equal, greater, less_equal, greater_equal, not_equal, _, _]
    pub comparison: [KernelFn; 8],

    // Category 0x0B: Bitwise
    /// Bitwise: [and, or, xor, not, shl, shr, _, _]
    pub bitwise: [KernelFn; 8],

    // Category 0x0C: Linear Algebra
    /// Linear algebra: [matvec, vecmat, dot, outer, batch_matmul, _, _, _]
    pub linalg: [KernelFn; 8],

    // Category 0x0D: Pooling
    /// Pooling: [max_pool, avg_pool, global_max, global_avg]
    pub pooling: [KernelFn; 4],

    /// Metadata kernels (auxiliary): [byte_meta_emit, _, _, _]
    pub metadata: [KernelFn; 4],
}

impl Default for KernelTable {
    fn default() -> Self {
        Self {
            gemm: [fallback_kernel; 4],
            conv: [fallback_kernel; 8],
            elementwise_binary: [fallback_kernel; 8],
            activation: [fallback_kernel; 16],
            transcendental: [fallback_kernel; 11],
            reduce: [fallback_kernel; 9],
            tensor_ops: [fallback_kernel; 16],
            normalization: [fallback_kernel; 8],
            loss: [fallback_kernel; 4],
            comparison: [fallback_kernel; 8],
            bitwise: [fallback_kernel; 8],
            linalg: [fallback_kernel; 8],
            pooling: [fallback_kernel; 4],
            metadata: [fallback_kernel; 4],
        }
    }
}

/// Fallback kernel that returns an error.
fn fallback_kernel(
    _inputs: &[*const u8],
    _outputs: &[*mut u8],
    _params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    Err(BackendError::Unsupported(
        "Kernel not implemented".to_string(),
    ))
}

impl std::fmt::Debug for KernelTable {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("KernelTable")
            .field("gemm", &"[KernelFn; 4]")
            .field("conv", &"[KernelFn; 8]")
            .field("elementwise_binary", &"[KernelFn; 8]")
            .field("activation", &"[KernelFn; 8]")
            .field("transcendental", &"[KernelFn; 8]")
            .field("reduce", &"[KernelFn; 8]")
            .field("tensor_ops", &"[KernelFn; 16]")
            .field("normalization", &"[KernelFn; 8]")
            .field("loss", &"[KernelFn; 4]")
            .field("comparison", &"[KernelFn; 8]")
            .field("bitwise", &"[KernelFn; 8]")
            .field("linalg", &"[KernelFn; 8]")
            .field("pooling", &"[KernelFn; 4]")
            .finish()
    }
}

// ============================================================================
// DYNAMIC KERNEL TABLE
// ============================================================================

/// Thread-safe table for dynamically registered kernels.
///
/// Dynamic kernels use IDs starting at `KernelId::DYNAMIC_BASE` (0x1000).
/// This allows runtime registration of custom kernels from Python/C/TypeScript.
///
/// # Example
///
/// ```ignore
/// use hologram_backend::plan::{dynamic_kernel_table, KernelId, KernelFn};
///
/// // Register a custom kernel
/// fn my_kernel(inputs: &[*const u8], outputs: &[*mut u8], params: &KernelParams) -> Result<(), BackendError> {
///     // Custom implementation
///     Ok(())
/// }
///
/// let kernel_id = dynamic_kernel_table().register(my_kernel);
/// assert!(kernel_id.is_dynamic());
///
/// // Later, retrieve and execute
/// if let Some(kernel_fn) = dynamic_kernel_table().get(kernel_id) {
///     kernel_fn(inputs, outputs, params)?;
/// }
/// ```
pub struct DynamicKernelTable {
    /// Kernels indexed by kernel_id (actual u32 value).
    kernels: RwLock<HashMap<u32, KernelFn>>,
    /// Next available ID (starting from DYNAMIC_BASE).
    next_id: RwLock<u32>,
}

impl DynamicKernelTable {
    /// Create a new empty dynamic kernel table.
    pub fn new() -> Self {
        Self {
            kernels: RwLock::new(HashMap::new()),
            next_id: RwLock::new(KernelId::DYNAMIC_BASE.0),
        }
    }

    /// Register a kernel with an auto-assigned ID.
    ///
    /// Returns the assigned `KernelId` which can be used in compiled plans.
    pub fn register(&self, kernel_fn: KernelFn) -> KernelId {
        let mut next_id = self.next_id.write();
        let id = *next_id;
        *next_id += 1;

        let mut kernels = self.kernels.write();
        kernels.insert(id, kernel_fn);

        KernelId(id)
    }

    /// Register a kernel with a specific ID.
    ///
    /// Returns `true` if registration succeeded, `false` if the ID is
    /// already registered or is in the static range (< DYNAMIC_BASE).
    pub fn register_with_id(&self, kernel_id: KernelId, kernel_fn: KernelFn) -> bool {
        if !kernel_id.is_dynamic() {
            return false; // Can't override static kernels
        }

        let mut kernels = self.kernels.write();
        if kernels.contains_key(&kernel_id.0) {
            return false; // Already registered
        }

        kernels.insert(kernel_id.0, kernel_fn);

        // Update next_id if necessary to avoid conflicts
        let mut next_id = self.next_id.write();
        if kernel_id.0 >= *next_id {
            *next_id = kernel_id.0 + 1;
        }

        true
    }

    /// Unregister a dynamic kernel.
    ///
    /// Returns `true` if the kernel was removed, `false` if not found.
    pub fn unregister(&self, kernel_id: KernelId) -> bool {
        if !kernel_id.is_dynamic() {
            return false;
        }
        let mut kernels = self.kernels.write();
        kernels.remove(&kernel_id.0).is_some()
    }

    /// Get a kernel function by ID.
    ///
    /// Returns `None` if the kernel is not registered.
    pub fn get(&self, kernel_id: KernelId) -> Option<KernelFn> {
        if !kernel_id.is_dynamic() {
            return None;
        }
        let kernels = self.kernels.read();
        kernels.get(&kernel_id.0).copied()
    }

    /// Get the number of registered dynamic kernels.
    pub fn count(&self) -> usize {
        self.kernels.read().len()
    }

    /// List all registered dynamic kernel IDs.
    pub fn list_ids(&self) -> Vec<KernelId> {
        self.kernels.read().keys().map(|&id| KernelId(id)).collect()
    }

    /// Clear all dynamic kernels.
    pub fn clear(&self) {
        self.kernels.write().clear();
        *self.next_id.write() = KernelId::DYNAMIC_BASE.0;
    }
}

impl Default for DynamicKernelTable {
    fn default() -> Self {
        Self::new()
    }
}

impl std::fmt::Debug for DynamicKernelTable {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let count = self.count();
        f.debug_struct("DynamicKernelTable")
            .field("count", &count)
            .field("next_id", &*self.next_id.read())
            .finish()
    }
}

/// Global dynamic kernel table.
static DYNAMIC_KERNELS: OnceLock<DynamicKernelTable> = OnceLock::new();

/// Get the global dynamic kernel table.
///
/// This table stores runtime-registered kernels with IDs >= 0x1000.
/// The table is thread-safe and lazily initialized on first access.
///
/// # Example
///
/// ```ignore
/// let table = dynamic_kernel_table();
/// let kernel_id = table.register(my_custom_kernel);
/// ```
pub fn dynamic_kernel_table() -> &'static DynamicKernelTable {
    DYNAMIC_KERNELS.get_or_init(DynamicKernelTable::new)
}

/// Tiling parameters for cache-efficient execution.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct TileParams {
    /// Tile size for M dimension (rows).
    pub tile_m: usize,
    /// Tile size for N dimension (columns).
    pub tile_n: usize,
    /// Tile size for K dimension (reduction).
    pub tile_k: usize,
    /// Micro-kernel rows.
    pub micro_m: usize,
    /// Micro-kernel columns.
    pub micro_n: usize,
}

impl Default for TileParams {
    fn default() -> Self {
        Self {
            tile_m: 64,
            tile_n: 64,
            tile_k: 256,
            micro_m: 6,
            micro_n: 16,
        }
    }
}

impl TileParams {
    /// Create tile parameters for AVX2.
    pub const fn avx2() -> Self {
        Self {
            tile_m: 72,
            tile_n: 256,
            tile_k: 256,
            micro_m: 6,
            micro_n: 16,
        }
    }

    /// Create tile parameters for AVX-512.
    pub const fn avx512() -> Self {
        Self {
            tile_m: 96,
            tile_n: 256,
            tile_k: 256,
            micro_m: 8,
            micro_n: 32,
        }
    }

    /// Create tile parameters for ARM NEON.
    pub const fn neon() -> Self {
        Self {
            tile_m: 64,
            tile_n: 128,
            tile_k: 256,
            micro_m: 4,
            micro_n: 8,
        }
    }

    /// Create tile parameters for scalar fallback.
    pub const fn scalar() -> Self {
        Self {
            tile_m: 64,
            tile_n: 64,
            tile_k: 64,
            micro_m: 1,
            micro_n: 4,
        }
    }
}

/// Metadata about tensor layouts in the plan.
#[derive(Debug, Clone, Default, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct LayoutMetadata {
    /// Number of input tensors.
    pub num_inputs: usize,
    /// Number of output tensors.
    pub num_outputs: usize,
    /// Input tensor sizes in bytes.
    pub input_sizes: Vec<usize>,
    /// Output tensor sizes in bytes.
    pub output_sizes: Vec<usize>,
    /// Input tensor shapes.
    pub input_shapes: Vec<[usize; 4]>,
    /// Output tensor shapes.
    pub output_shapes: Vec<[usize; 4]>,
    /// Shape expressions for dynamic outputs (None = fully static).
    ///
    /// When an output has dynamic dimensions (e.g., depends on input batch size),
    /// this stores expressions that can be resolved at runtime from input shapes.
    pub output_shape_exprs: Vec<Option<Vec<DimExpr>>>,
}

/// Workspace memory layout with pre-computed offsets.
#[derive(Debug, Clone, Default, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct WorkspaceLayout {
    /// Total workspace size in bytes.
    pub total_size: u64,
    /// Required alignment in bytes.
    pub alignment: u64,
    /// Named regions with their offsets and sizes.
    pub regions: Vec<WorkspaceRegion>,
}

/// Expression for workspace size that can be resolved at runtime.
///
/// This enables symbolic workspace allocation where the actual size depends
/// on runtime input dimensions (e.g., batch size, sequence length).
#[derive(Debug, Clone, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum WorkspaceSizeExpr {
    /// Static size known at compile time.
    Static(usize),

    /// MatMul workspace: output buffer + optional packing buffers.
    ///
    /// Formula: `m * n * elem_size + pack_overhead`
    /// where `pack_overhead = m * k * elem_size + k * n * elem_size` if `include_packing`
    MatMul {
        /// M dimension expression (output rows).
        m: DimExpr,
        /// K dimension expression (inner/contraction dimension).
        k: DimExpr,
        /// N dimension expression (output columns).
        n: DimExpr,
        /// Element size in bytes (typically 4 for f32).
        elem_size: usize,
        /// Whether to include packing buffers (for large matrices).
        include_packing: bool,
    },

    /// Element count workspace: `numel * elem_size * multiplier`.
    ///
    /// Used for elementwise ops, reductions, and general scratch space.
    ElementCount {
        /// Expression for number of elements.
        numel: DimExpr,
        /// Element size in bytes.
        elem_size: usize,
        /// Multiplier for additional scratch space (default 1).
        multiplier: usize,
    },

    /// Conv2D workspace: im2col buffer or Winograd tiles.
    ///
    /// Formula depends on algorithm:
    /// - Im2col: `batch * out_h * out_w * (in_c * kh * kw) * elem_size`
    /// - Direct: `batch * out_h * out_w * out_c * elem_size`
    Conv2d {
        /// Batch dimension expression.
        batch: DimExpr,
        /// Output height expression.
        out_h: DimExpr,
        /// Output width expression.
        out_w: DimExpr,
        /// Output/input channels (depends on algorithm).
        channels: DimExpr,
        /// Kernel area (kh * kw) for im2col, or 1 for direct.
        kernel_area: usize,
        /// Element size in bytes.
        elem_size: usize,
    },

    /// Softmax workspace: temporary buffer for exp values.
    ///
    /// Formula: `batch * seq_len * elem_size`
    Softmax {
        /// Batch * sequence length expression.
        outer_size: DimExpr,
        /// Inner dimension (for partial softmax).
        inner_size: DimExpr,
        /// Element size in bytes.
        elem_size: usize,
    },

    /// MatMul workspace with explicit output plus packing.
    ///
    /// Formula: `(m * n + m * k + k * n) * elem_size`
    /// This is the expanded form of MatMul with include_packing=true.
    MatMulWithPacking {
        /// M dimension expression (output rows).
        m: DimExpr,
        /// K dimension expression (inner/contraction dimension).
        k: DimExpr,
        /// N dimension expression (output columns).
        n: DimExpr,
        /// Element size in bytes.
        elem_size: usize,
    },
}

impl WorkspaceSizeExpr {
    /// Create a static size expression.
    #[must_use]
    pub const fn static_size(size: usize) -> Self {
        Self::Static(size)
    }

    /// Create a MatMul workspace expression.
    #[must_use]
    pub fn matmul(
        m: DimExpr,
        k: DimExpr,
        n: DimExpr,
        elem_size: usize,
        include_packing: bool,
    ) -> Self {
        Self::MatMul {
            m,
            k,
            n,
            elem_size,
            include_packing,
        }
    }

    /// Create an element count workspace expression.
    #[must_use]
    pub fn element_count(numel: DimExpr, elem_size: usize, multiplier: usize) -> Self {
        Self::ElementCount {
            numel,
            elem_size,
            multiplier,
        }
    }

    /// Create a MatMul workspace with packing expression.
    #[must_use]
    pub fn matmul_with_packing(m: DimExpr, k: DimExpr, n: DimExpr, elem_size: usize) -> Self {
        Self::MatMulWithPacking { m, k, n, elem_size }
    }

    /// Evaluate this expression given input tensor shapes.
    ///
    /// # Arguments
    /// * `input_shapes` - Shapes of input tensors as `[input_id][dim_index]`
    ///
    /// # Returns
    /// The computed workspace size in bytes, or None if resolution fails.
    #[must_use]
    pub fn evaluate(&self, input_shapes: &[[usize; 4]]) -> Option<usize> {
        match self {
            Self::Static(size) => Some(*size),

            Self::MatMul {
                m,
                k,
                n,
                elem_size,
                include_packing,
            } => {
                let m_val = m.evaluate(input_shapes)?;
                let k_val = k.evaluate(input_shapes)?;
                let n_val = n.evaluate(input_shapes)?;

                // Output buffer: m * n elements
                let output_size = m_val.checked_mul(n_val)?.checked_mul(*elem_size)?;

                if *include_packing {
                    // Pack A: m * k elements, Pack B: k * n elements
                    let pack_a = m_val.checked_mul(k_val)?.checked_mul(*elem_size)?;
                    let pack_b = k_val.checked_mul(n_val)?.checked_mul(*elem_size)?;
                    output_size.checked_add(pack_a)?.checked_add(pack_b)
                } else {
                    Some(output_size)
                }
            }

            Self::ElementCount {
                numel,
                elem_size,
                multiplier,
            } => {
                let count = numel.evaluate(input_shapes)?;
                count.checked_mul(*elem_size)?.checked_mul(*multiplier)
            }

            Self::Conv2d {
                batch,
                out_h,
                out_w,
                channels,
                kernel_area,
                elem_size,
            } => {
                let b = batch.evaluate(input_shapes)?;
                let h = out_h.evaluate(input_shapes)?;
                let w = out_w.evaluate(input_shapes)?;
                let c = channels.evaluate(input_shapes)?;

                b.checked_mul(h)?
                    .checked_mul(w)?
                    .checked_mul(c)?
                    .checked_mul(*kernel_area)?
                    .checked_mul(*elem_size)
            }

            Self::Softmax {
                outer_size,
                inner_size,
                elem_size,
            } => {
                let outer = outer_size.evaluate(input_shapes)?;
                let inner = inner_size.evaluate(input_shapes)?;
                outer.checked_mul(inner)?.checked_mul(*elem_size)
            }

            Self::MatMulWithPacking { m, k, n, elem_size } => {
                let m_val = m.evaluate(input_shapes)?;
                let k_val = k.evaluate(input_shapes)?;
                let n_val = n.evaluate(input_shapes)?;

                // output (m*n) + pack_a (m*k) + pack_b (k*n)
                let output = m_val.checked_mul(n_val)?;
                let pack_a = m_val.checked_mul(k_val)?;
                let pack_b = k_val.checked_mul(n_val)?;
                output
                    .checked_add(pack_a)?
                    .checked_add(pack_b)?
                    .checked_mul(*elem_size)
            }
        }
    }

    /// Evaluate with predecessor buffer sizes for intermediate operations.
    #[must_use]
    pub fn evaluate_with_predecessors(
        &self,
        input_shapes: &[[usize; 4]],
        predecessor_elements: &[usize],
    ) -> Option<usize> {
        match self {
            Self::ElementCount {
                numel,
                elem_size,
                multiplier,
            } => {
                let count = numel.evaluate_with_predecessors(input_shapes, predecessor_elements)?;
                count.checked_mul(*elem_size)?.checked_mul(*multiplier)
            }
            // Other variants use regular evaluate (they don't depend on predecessors)
            _ => self.evaluate(input_shapes),
        }
    }

    /// Check if this expression is fully static.
    #[must_use]
    pub fn is_static(&self) -> bool {
        matches!(self, Self::Static(_))
    }

    /// Get static value if fully static.
    #[must_use]
    pub fn static_value(&self) -> Option<usize> {
        match self {
            Self::Static(size) => Some(*size),
            _ => None,
        }
    }
}

/// A named region within the workspace.
#[derive(Debug, Clone, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct WorkspaceRegion {
    /// Region name for debugging.
    pub name: String,
    /// Offset from workspace start in bytes.
    ///
    /// For dynamic workspaces, this is the offset within the static layout.
    /// Dynamic regions are appended after the static portion.
    pub offset: u64,
    /// Static size of this region in bytes.
    ///
    /// Used when `size_expr` is None, or as a fallback/minimum.
    pub size: u64,
    /// Required alignment for this region.
    pub alignment: u64,
    /// Dynamic size expression (resolved at runtime if present).
    ///
    /// When `Some`, the actual size is computed at runtime based on input shapes.
    /// When `None`, the static `size` field is used.
    pub size_expr: Option<WorkspaceSizeExpr>,
}

impl WorkspaceLayout {
    /// Create a new empty workspace layout.
    pub fn new() -> Self {
        Self {
            total_size: 0,
            alignment: 64, // Cache line alignment
            regions: Vec::new(),
        }
    }

    /// Add a static region to the workspace and return its offset.
    ///
    /// The size is fixed at compile time. For dynamic sizing, use `add_region_dynamic`.
    pub fn add_region(&mut self, name: &str, size: usize, alignment: usize) -> usize {
        // Convert to u64 for internal storage
        let size_u64 = size as u64;
        let alignment_u64 = alignment as u64;

        // Align current offset
        let offset = (self.total_size + alignment_u64 - 1) & !(alignment_u64 - 1);

        self.regions.push(WorkspaceRegion {
            name: name.to_string(),
            offset,
            size: size_u64,
            alignment: alignment_u64,
            size_expr: None, // Static region
        });

        self.total_size = offset + size_u64;
        self.alignment = self.alignment.max(alignment_u64);

        offset as usize
    }

    /// Add a dynamic region with a size expression.
    ///
    /// For dynamic regions, the actual size and offset are computed at runtime
    /// based on input shapes. The `static_size` is stored as a minimum/fallback
    /// but is NOT used to compute `total_size` (which would be incorrect for
    /// symbolic shapes).
    ///
    /// Returns the region index. Call `resolve()` at runtime with input shapes
    /// to get the actual offsets and total size.
    pub fn add_region_dynamic(
        &mut self,
        name: &str,
        static_size: usize,
        alignment: usize,
        size_expr: WorkspaceSizeExpr,
    ) -> usize {
        // Convert to u64 for internal storage
        let static_size_u64 = static_size as u64;
        let alignment_u64 = alignment as u64;

        // For dynamic regions, we don't pre-compute offsets or add to total_size.
        // The offset stored here is a placeholder - resolve() recomputes from scratch.
        // Using region index as a sentinel to make debugging easier.
        let region_idx = self.regions.len();

        self.regions.push(WorkspaceRegion {
            name: name.to_string(),
            offset: region_idx as u64, // Placeholder - resolved at runtime
            size: static_size_u64,     // Minimum/fallback size
            alignment: alignment_u64,
            size_expr: Some(size_expr),
        });

        // DON'T update total_size for dynamic regions!
        // Runtime resolution via resolve() will compute the actual total.
        self.alignment = self.alignment.max(alignment_u64);

        region_idx
    }

    /// Check if this layout has any dynamic regions.
    #[must_use]
    pub fn has_dynamic_regions(&self) -> bool {
        self.regions.iter().any(|r| r.size_expr.is_some())
    }

    /// Get the number of dynamic regions.
    #[must_use]
    pub fn dynamic_region_count(&self) -> usize {
        self.regions
            .iter()
            .filter(|r| r.size_expr.is_some())
            .count()
    }

    /// Resolve all dynamic sizes and compute actual total size.
    ///
    /// Returns a new `ResolvedWorkspaceLayout` with computed offsets and sizes.
    ///
    /// # Arguments
    /// * `input_shapes` - Shapes of input tensors for resolving DimExpr
    ///
    /// # Errors
    /// Returns `None` if any dynamic expression fails to resolve.
    #[must_use]
    pub fn resolve(&self, input_shapes: &[[usize; 4]]) -> Option<ResolvedWorkspaceLayout> {
        let mut resolved_regions = Vec::with_capacity(self.regions.len());
        let mut current_offset = 0usize;

        // Track element counts for each resolved workspace region
        // This allows PredecessorElementsDiv expressions to reference earlier regions
        let mut predecessor_elements = Vec::with_capacity(self.regions.len());

        for (idx, region) in self.regions.iter().enumerate() {
            // Convert u64 to usize for runtime operations
            let alignment_usize = region.alignment as usize;

            // Align offset
            let aligned_offset = (current_offset + alignment_usize - 1) & !(alignment_usize - 1);

            // Resolve size: use expression if present, otherwise static size
            let resolved_size = if let Some(ref expr) = region.size_expr {
                // Try using evaluate_with_predecessors first (supports PredecessorElementsDiv)
                match expr.evaluate_with_predecessors(input_shapes, &predecessor_elements) {
                    Some(size) => {
                        // Log resolution for debugging workspace issues
                        if idx == 71 || idx == 101 || size > 10_000_000 || (65..=75).contains(&idx)
                        {
                            tracing::warn!(
                                "Resolved workspace region {}: name={}, expr={:?}, size={} bytes ({:.2} MB), predecessor_elements[..5]={:?}",
                                idx,
                                region.name,
                                expr,
                                size,
                                size as f64 / 1_048_576.0,
                                &predecessor_elements.iter().take(5).copied().collect::<Vec<_>>()
                            );
                        }
                        size
                    }
                    None => {
                        tracing::error!(
                            "Failed to resolve workspace region '{}': expr={:?}, input_shapes={:?}, predecessor_elements={:?}",
                            region.name,
                            expr,
                            input_shapes,
                            predecessor_elements
                        );
                        return None;
                    }
                }
            } else {
                region.size as usize
            };

            resolved_regions.push(ResolvedWorkspaceRegion {
                name: region.name.clone(),
                offset: aligned_offset,
                size: resolved_size,
                alignment: alignment_usize,
            });

            // Add this region's element count to predecessor_elements for next iterations
            // Assuming f32 elements (4 bytes each)
            let element_count = resolved_size / 4;
            predecessor_elements.push(element_count);

            current_offset = aligned_offset + resolved_size;
        }

        // Final alignment for total size
        let alignment_usize = self.alignment as usize;
        let total_size = (current_offset + alignment_usize - 1) & !(alignment_usize - 1);

        Some(ResolvedWorkspaceLayout {
            total_size,
            alignment: alignment_usize,
            regions: resolved_regions,
        })
    }

    /// Resolve with predecessor buffer sizes for intermediate operations.
    #[must_use]
    pub fn resolve_with_predecessors(
        &self,
        input_shapes: &[[usize; 4]],
        predecessor_elements: &[usize],
    ) -> Option<ResolvedWorkspaceLayout> {
        let mut resolved_regions = Vec::with_capacity(self.regions.len());
        let mut current_offset = 0usize;

        for region in &self.regions {
            // Convert u64 to usize for runtime operations
            let alignment_usize = region.alignment as usize;

            let aligned_offset = (current_offset + alignment_usize - 1) & !(alignment_usize - 1);

            let resolved_size = if let Some(ref expr) = region.size_expr {
                expr.evaluate_with_predecessors(input_shapes, predecessor_elements)?
            } else {
                region.size as usize
            };

            resolved_regions.push(ResolvedWorkspaceRegion {
                name: region.name.clone(),
                offset: aligned_offset,
                size: resolved_size,
                alignment: alignment_usize,
            });

            current_offset = aligned_offset + resolved_size;
        }

        let alignment_usize = self.alignment as usize;
        let total_size = (current_offset + alignment_usize - 1) & !(alignment_usize - 1);

        Some(ResolvedWorkspaceLayout {
            total_size,
            alignment: alignment_usize,
            regions: resolved_regions,
        })
    }

    /// Get a region by index.
    pub fn region(&self, idx: usize) -> Option<&WorkspaceRegion> {
        self.regions.get(idx)
    }

    /// Get a region by name.
    pub fn region_by_name(&self, name: &str) -> Option<&WorkspaceRegion> {
        self.regions.iter().find(|r| r.name == name)
    }
}

/// A fully resolved workspace layout with concrete sizes.
///
/// Created by calling `WorkspaceLayout::resolve()` with input shapes.
/// All sizes and offsets are concrete values, ready for allocation.
#[derive(Debug, Clone)]
pub struct ResolvedWorkspaceLayout {
    /// Total workspace size in bytes (resolved).
    pub total_size: usize,
    /// Required alignment in bytes.
    pub alignment: usize,
    /// Resolved regions with concrete offsets and sizes.
    pub regions: Vec<ResolvedWorkspaceRegion>,
}

/// A resolved workspace region with concrete values.
#[derive(Debug, Clone)]
pub struct ResolvedWorkspaceRegion {
    /// Region name for debugging.
    pub name: String,
    /// Resolved offset from workspace start in bytes.
    pub offset: usize,
    /// Resolved size of this region in bytes.
    pub size: usize,
    /// Required alignment for this region.
    pub alignment: usize,
}

impl ResolvedWorkspaceLayout {
    /// Get a region by index.
    pub fn region(&self, idx: usize) -> Option<&ResolvedWorkspaceRegion> {
        self.regions.get(idx)
    }

    /// Get a region by name.
    pub fn region_by_name(&self, name: &str) -> Option<&ResolvedWorkspaceRegion> {
        self.regions.iter().find(|r| r.name == name)
    }
}

/// Handle to pre-allocated workspace memory.
#[derive(Debug)]
pub struct WorkspaceHandle {
    /// Pointer to workspace memory.
    ptr: *mut u8,
    /// Layout of the workspace.
    layout: WorkspaceLayout,
}

impl WorkspaceHandle {
    /// Create a new workspace handle.
    ///
    /// # Safety
    /// The caller must ensure that `ptr` points to memory of at least
    /// `layout.total_size` bytes with proper alignment.
    pub unsafe fn new(ptr: *mut u8, layout: WorkspaceLayout) -> Self {
        Self { ptr, layout }
    }

    /// Create a null workspace handle.
    pub fn null() -> Self {
        Self {
            ptr: std::ptr::null_mut(),
            layout: WorkspaceLayout::new(),
        }
    }

    /// Check if this handle is null.
    pub fn is_null(&self) -> bool {
        self.ptr.is_null()
    }

    /// Get the total size of the workspace.
    pub fn total_size(&self) -> usize {
        self.layout.total_size as usize
    }

    /// Get the base pointer of the workspace.
    pub fn base_ptr(&self) -> *mut u8 {
        self.ptr
    }

    /// Check if a pointer falls within this workspace's memory range.
    ///
    /// Used to identify workspace-derived BufferHandles during resolution.
    /// Returns `false` if the workspace is null.
    pub fn contains_ptr(&self, ptr: *const u8) -> bool {
        if self.ptr.is_null() {
            return false;
        }
        let ws_start = self.ptr as usize;
        let ws_end = ws_start + (self.layout.total_size as usize);
        let ptr_addr = ptr as usize;
        ptr_addr >= ws_start && ptr_addr < ws_end
    }

    /// Get a pointer to a region by index.
    ///
    /// # Safety
    /// The caller must ensure the region index is valid and the
    /// returned pointer is used correctly.
    pub unsafe fn region_ptr(&self, idx: usize) -> *mut u8 {
        if let Some(region) = self.layout.region(idx) {
            self.ptr.add(region.offset as usize)
        } else {
            std::ptr::null_mut()
        }
    }

    /// Get a slice for a region by index.
    ///
    /// # Safety
    /// The caller must ensure the region index is valid and no other references
    /// exist to this region. This function returns a mutable reference to
    /// memory that is internally mutable.
    #[allow(clippy::mut_from_ref)]
    pub unsafe fn region_slice(&self, idx: usize) -> &mut [u8] {
        if let Some(region) = self.layout.region(idx) {
            std::slice::from_raw_parts_mut(
                self.ptr.add(region.offset as usize),
                region.size as usize,
            )
        } else {
            &mut []
        }
    }

    /// Get a typed slice for a region.
    ///
    /// # Safety
    /// The caller must ensure the region contains properly aligned data of type T
    /// and no other references exist to this region.
    #[allow(clippy::mut_from_ref)]
    pub unsafe fn region_as<T>(&self, idx: usize) -> &mut [T] {
        if let Some(region) = self.layout.region(idx) {
            let ptr = self.ptr.add(region.offset as usize) as *mut T;
            let len = (region.size as usize) / std::mem::size_of::<T>();
            std::slice::from_raw_parts_mut(ptr, len)
        } else {
            &mut []
        }
    }
}

// WorkspaceHandle is Send + Sync because the underlying memory is owned
// by the caller and we only provide access to it.
unsafe impl Send for WorkspaceHandle {}
unsafe impl Sync for WorkspaceHandle {}

/// Handle to dynamically-resolved workspace memory.
///
/// This is the runtime counterpart to `WorkspaceLayout`. After resolving
/// dimension expressions with actual input shapes, this handle manages
/// the allocated workspace memory.
///
/// Unlike `WorkspaceHandle` which uses compile-time static offsets,
/// `DynamicWorkspaceHandle` computes offsets at runtime from `ResolvedWorkspaceLayout`.
#[derive(Debug)]
pub struct DynamicWorkspaceHandle {
    /// Pointer to workspace memory (owned via Vec or external).
    ptr: *mut u8,
    /// Resolved layout with concrete sizes.
    layout: ResolvedWorkspaceLayout,
    /// Owned memory buffer (Some if we allocated, None if external).
    _owned: Option<Vec<u8>>,
}

impl DynamicWorkspaceHandle {
    /// Create a dynamic workspace by resolving the layout with input shapes.
    ///
    /// Allocates memory based on the resolved sizes.
    ///
    /// # Arguments
    /// * `workspace_layout` - The compile-time layout with size expressions
    /// * `input_shapes` - Actual input tensor shapes for resolution
    ///
    /// # Returns
    /// A new handle with allocated memory, or `None` if resolution fails.
    pub fn resolve_and_allocate(
        workspace_layout: &WorkspaceLayout,
        input_shapes: &[[usize; 4]],
    ) -> Option<Self> {
        let resolved = workspace_layout.resolve(input_shapes)?;

        if resolved.total_size == 0 {
            return Some(Self {
                ptr: std::ptr::null_mut(),
                layout: resolved,
                _owned: None,
            });
        }

        // Allocate with proper alignment
        let mut buffer = vec![0u8; resolved.total_size + resolved.alignment];
        let ptr = buffer.as_mut_ptr();
        let aligned_ptr =
            ((ptr as usize + resolved.alignment - 1) & !(resolved.alignment - 1)) as *mut u8;

        Some(Self {
            ptr: aligned_ptr,
            layout: resolved,
            _owned: Some(buffer),
        })
    }

    /// Create from external memory with a resolved layout.
    ///
    /// # Safety
    /// The caller must ensure that `ptr` points to memory of at least
    /// `layout.total_size` bytes with proper alignment.
    pub unsafe fn from_ptr(ptr: *mut u8, layout: ResolvedWorkspaceLayout) -> Self {
        Self {
            ptr,
            layout,
            _owned: None,
        }
    }

    /// Get the total size of the workspace.
    pub fn total_size(&self) -> usize {
        self.layout.total_size
    }

    /// Get the resolved layout.
    pub fn layout(&self) -> &ResolvedWorkspaceLayout {
        &self.layout
    }

    /// Get the base pointer of the workspace.
    pub fn base_ptr(&self) -> *mut u8 {
        self.ptr
    }

    /// Check if this handle is null.
    pub fn is_null(&self) -> bool {
        self.ptr.is_null()
    }

    /// Get a pointer to a region by index.
    ///
    /// # Safety
    /// The caller must ensure the region index is valid and the
    /// returned pointer is used correctly.
    pub unsafe fn region_ptr(&self, idx: usize) -> *mut u8 {
        if let Some(region) = self.layout.region(idx) {
            self.ptr.add(region.offset)
        } else {
            std::ptr::null_mut()
        }
    }

    /// Get a slice for a region by index.
    ///
    /// # Safety
    /// The caller must ensure the region index is valid and no other references
    /// exist to this region.
    #[allow(clippy::mut_from_ref)]
    pub unsafe fn region_slice(&self, idx: usize) -> &mut [u8] {
        if let Some(region) = self.layout.region(idx) {
            std::slice::from_raw_parts_mut(self.ptr.add(region.offset), region.size)
        } else {
            &mut []
        }
    }

    /// Get a typed slice for a region.
    ///
    /// # Safety
    /// The caller must ensure the region contains properly aligned data of type T
    /// and no other references exist to this region.
    #[allow(clippy::mut_from_ref)]
    pub unsafe fn region_as<T>(&self, idx: usize) -> &mut [T] {
        if let Some(region) = self.layout.region(idx) {
            let ptr = self.ptr.add(region.offset) as *mut T;
            let len = region.size / std::mem::size_of::<T>();
            std::slice::from_raw_parts_mut(ptr, len)
        } else {
            &mut []
        }
    }

    /// Check if a pointer falls within this workspace's memory range.
    pub fn contains_ptr(&self, ptr: *const u8) -> bool {
        if self.ptr.is_null() {
            return false;
        }
        let ws_start = self.ptr as usize;
        let ws_end = ws_start + self.layout.total_size;
        let ptr_addr = ptr as usize;
        ptr_addr >= ws_start && ptr_addr < ws_end
    }
}

// DynamicWorkspaceHandle is Send + Sync because the underlying memory is owned
// or properly managed by the caller.
unsafe impl Send for DynamicWorkspaceHandle {}
unsafe impl Sync for DynamicWorkspaceHandle {}

/// Epilogue operation type.
#[derive(Debug, Clone, Copy, PartialEq, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum EpilogueOp {
    /// No operation (identity).
    None,
    /// Add bias from workspace offset.
    BiasAdd {
        /// Offset in workspace where bias data is stored.
        offset: usize,
    },
    /// Add bias from read-only constant_data.
    BiasAddConst {
        /// Offset in elements into plan.constant_data.
        offset: usize,
        /// Stride in elements between consecutive bias values.
        stride: usize,
        /// Channel dimension for modulo when broadcasting across spatial.
        channel_dim: usize,
    },
    /// ReLU activation.
    ReLU,
    /// SiLU activation.
    SiLU,
    /// Sigmoid activation.
    Sigmoid,
    /// Tanh activation.
    Tanh,
    /// GELU activation.
    GELU,
    /// Scale by constant.
    Scale {
        /// Scaling factor to multiply.
        alpha: f32,
    },
    /// Clamp to range.
    Clamp {
        /// Minimum value.
        min: f32,
        /// Maximum value.
        max: f32,
    },
    /// LeakyReLU activation: f(x) = x if x >= 0, alpha * x if x < 0.
    LeakyReLU {
        /// Scale factor for negative values.
        alpha: f32,
    },
    /// Custom activation via lookup table.
    CustomTable {
        /// ID of the lookup table to use.
        table_id: u32,
    },
}

/// Chain of epilogue operations to apply after kernel.
#[derive(Debug, Clone, Default, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct EpilogueChain {
    /// Ordered list of epilogue operations.
    pub ops: Vec<EpilogueOp>,
}

impl EpilogueChain {
    /// Create an empty epilogue chain.
    pub fn new() -> Self {
        Self { ops: Vec::new() }
    }

    /// Create a chain with a single operation.
    pub fn single(op: EpilogueOp) -> Self {
        Self { ops: vec![op] }
    }

    /// Add an operation to the chain.
    pub fn push(&mut self, op: EpilogueOp) {
        self.ops.push(op);
    }

    /// Check if the chain is empty.
    pub fn is_empty(&self) -> bool {
        self.ops.is_empty()
    }

    /// Get the number of operations.
    pub fn len(&self) -> usize {
        self.ops.len()
    }
}

/// Strategy for partitioning work across threads.
#[derive(Debug, Clone, PartialEq, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum PartitionStrategy {
    /// Partition by rows.
    BlockRows {
        /// Number of rows assigned to each thread.
        rows_per_thread: usize,
    },
    /// Partition by tiles.
    BlockTiles {
        /// Number of tiles assigned to each thread.
        tiles_per_thread: usize,
    },
    /// Partition Winograd tiles.
    WinogradTiles {
        /// Number of tiles assigned to each thread.
        tiles_per_thread: usize,
        /// Total number of Winograd tiles.
        total_tiles: usize,
    },
    /// No parallelism (single-threaded).
    Sequential,
}

/// Range of work assigned to a thread.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct WorkRange {
    /// Thread identifier.
    pub thread_id: usize,
    /// Starting index (inclusive).
    pub start: usize,
    /// Ending index (exclusive).
    pub end: usize,
}

/// Thread partitioning for parallel execution.
#[derive(Debug, Clone, Default, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct ThreadPartition {
    /// Partitioning strategy.
    pub strategy: Option<PartitionStrategy>,
    /// Number of threads to use.
    pub num_threads: usize,
    /// Pre-computed work ranges per thread.
    pub work_ranges: Vec<WorkRange>,
}

impl ThreadPartition {
    /// Create a single-threaded partition.
    pub fn sequential() -> Self {
        Self {
            strategy: Some(PartitionStrategy::Sequential),
            num_threads: 1,
            work_ranges: vec![WorkRange {
                thread_id: 0,
                start: 0,
                end: usize::MAX,
            }],
        }
    }

    /// Create a partition for parallel execution.
    pub fn parallel(num_threads: usize, total_work: usize) -> Self {
        let work_per_thread = total_work.div_ceil(num_threads);
        let work_ranges = (0..num_threads)
            .map(|i| {
                let start = i * work_per_thread;
                let end = ((i + 1) * work_per_thread).min(total_work);
                WorkRange {
                    thread_id: i,
                    start,
                    end,
                }
            })
            .collect();

        Self {
            strategy: Some(PartitionStrategy::BlockRows {
                rows_per_thread: work_per_thread,
            }),
            num_threads,
            work_ranges,
        }
    }
}

/// Execution context provided by the backend.
#[derive(Debug)]
pub struct BackendContext {
    /// Backend type.
    pub backend_type: BackendType,
    /// Number of available threads.
    pub num_threads: usize,
    /// SIMD vector width.
    pub vector_width: usize,
}

impl Default for BackendContext {
    fn default() -> Self {
        Self {
            backend_type: BackendType::Cpu,
            num_threads: std::thread::available_parallelism()
                .map(|p| p.get())
                .unwrap_or(1),
            vector_width: 1,
        }
    }
}

/// A single operation in the execution plan.
#[derive(Debug, Clone)]
pub struct PlanOp {
    /// Kernel to execute.
    pub kernel_id: KernelId,
    /// Index into kernel table.
    pub kernel_idx: usize,
    /// Parameters for this operation.
    pub params: KernelParams,
    /// Epilogue chain for this operation.
    pub epilogue: EpilogueChain,
    /// Thread partition for this operation.
    pub partition: ThreadPartition,
    /// Input buffer references (pre-resolved for zero-overhead dispatch).
    pub input_refs: Vec<BufferRef>,
    /// Output buffer references (pre-resolved for zero-overhead dispatch).
    pub output_refs: Vec<BufferRef>,
}

/// Well-known activation table IDs for `EpilogueOp::CustomTable`.
///
/// These IDs correspond to pre-computed activation lookup tables that enable
/// O(1) activation function application via table lookup instead of computation.
pub mod activation_table_id {
    /// Sigmoid activation table (u8 → u8).
    pub const SIGMOID: u32 = 0;
    /// Tanh activation table (u8 → u8).
    pub const TANH: u32 = 1;
    /// ReLU activation table (u8 → u8, zero point at 128).
    pub const RELU: u32 = 2;
    /// GELU activation table (u8 → u8).
    pub const GELU: u32 = 3;
    /// SiLU (Swish) activation table (u8 → u8).
    pub const SILU: u32 = 4;
}

/// Pre-computed activation lookup tables (256 entries each).
///
/// Each table maps input byte (0-255) to output byte (0-255), enabling
/// O(1) activation function application for quantized inference.
#[derive(Clone, Copy)]
pub struct ActivationTables {
    /// Sigmoid: 1 / (1 + exp(-x))
    pub sigmoid: &'static [u8; 256],
    /// Tanh: (exp(x) - exp(-x)) / (exp(x) + exp(-x))
    pub tanh: &'static [u8; 256],
    /// ReLU: max(0, x) with zero point at 128
    pub relu: &'static [u8; 256],
    /// GELU: x * Φ(x) approximation
    pub gelu: &'static [u8; 256],
    /// SiLU (Swish): x * sigmoid(x)
    pub silu: &'static [u8; 256],
}

impl Default for ActivationTables {
    fn default() -> Self {
        Self {
            sigmoid: &SIGMOID_U8,
            tanh: &TANH_U8,
            relu: &RELU_U8,
            gelu: &GELU_U8,
            silu: &SILU_U8,
        }
    }
}

impl std::fmt::Debug for ActivationTables {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ActivationTables")
            .field("sigmoid", &format_args!("{:p}", self.sigmoid))
            .field("tanh", &format_args!("{:p}", self.tanh))
            .field("relu", &format_args!("{:p}", self.relu))
            .field("gelu", &format_args!("{:p}", self.gelu))
            .field("silu", &format_args!("{:p}", self.silu))
            .finish()
    }
}

impl ActivationTables {
    /// Get an activation table by its well-known ID.
    ///
    /// Returns `None` for unknown table IDs.
    #[inline]
    pub fn get(&self, table_id: u32) -> Option<&'static [u8; 256]> {
        match table_id {
            activation_table_id::SIGMOID => Some(self.sigmoid),
            activation_table_id::TANH => Some(self.tanh),
            activation_table_id::RELU => Some(self.relu),
            activation_table_id::GELU => Some(self.gelu),
            activation_table_id::SILU => Some(self.silu),
            _ => None,
        }
    }

    /// Apply activation table lookup with f32 quantization.
    ///
    /// Converts f32 value (assumed normalized 0.0-1.0) to u8 index,
    /// performs table lookup, and converts back to f32.
    ///
    /// For best performance, use quantized (u8) data paths directly.
    #[inline]
    pub fn apply_f32(&self, table_id: u32, value: f32) -> f32 {
        if let Some(table) = self.get(table_id) {
            // Quantize: map 0.0-1.0 to 0-255
            let idx = (value.clamp(0.0, 1.0) * 255.0) as usize;
            // Lookup
            let result = table[idx];
            // Dequantize: map 0-255 back to 0.0-1.0
            result as f32 / 255.0
        } else {
            // Unknown table - return unchanged
            value
        }
    }
}

/// Pre-computed lookup tables passed to every kernel at runtime.
///
/// **Important**: These are pre-computed 256-entry lookup tables, NOT a key-value store.
/// Each table maps byte values (0-255) to transformed outputs in O(1) time.
///
/// # Zero-Copy Design
///
/// These are cheap pointers to statically generated tables in `hologram-lookup`
/// and `hologram-common`. They allow runtime to guarantee zero-copy access to
/// the same data used during compilation and codegen.
///
/// # Performance
///
/// - Single lookup: ~4 cycles (L1 cache hit)
/// - Tables fit entirely in L1 cache (< 4KB total)
/// - No allocation, no computation - pure memory access
///
/// # Example
///
/// ```ignore
/// // Kernels receive LookupTables for O(1) byte transformations
/// fn my_kernel(inputs: &[*const u8], outputs: &[*mut u8], tables: &LookupTables) {
///     // Apply activation via lookup table (zero computation)
///     let result = tables.activation_tables.apply(ActivationId::Sigmoid, input_byte);
/// }
/// ```
#[doc(alias = "precomputed tables")]
#[doc(alias = "byte tables")]
#[doc(alias = "activation tables")]
#[derive(Clone, Copy)]
pub struct LookupTables {
    /// Packed lookup table (512 bytes, 64-byte aligned).
    pub packed_table: &'static hologram_lookup::AlignedPackedTable,
    /// Categorical metadata (level, octave, property loss, automorphism dim).
    pub byte_meta_table: &'static [hologram_common::categorical::LookupMeta; 256],
    /// Pre-computed activation tables for epilogue fusion.
    pub activation_tables: ActivationTables,
}

impl std::fmt::Debug for LookupTables {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("LookupTables")
            .field("packed_table", &format_args!("{:p}", self.packed_table))
            .field(
                "byte_meta_table",
                &format_args!("{:p}", self.byte_meta_table),
            )
            .field("activation_tables", &self.activation_tables)
            .finish()
    }
}

impl Default for LookupTables {
    fn default() -> Self {
        Self {
            packed_table: &PACKED_TABLE,
            byte_meta_table: &BYTE_META_TABLE,
            activation_tables: ActivationTables::default(),
        }
    }
}

/// Fully-resolved execution plan.
///
/// Created by the compiler at compile time. Executed with O(1) overhead at runtime.
///
/// # Thread Safety
///
/// `BackendPlan` is `Send + Sync`. It can be shared across threads and executed
/// from any thread. The plan itself is immutable; only the workspace is modified.
#[derive(Debug, Clone)]
pub struct BackendPlan {
    /// Backend this plan is compiled for.
    pub backend_type: BackendType,
    /// Kernel function pointer table.
    pub kernel_table: KernelTable,
    /// Global tile parameters.
    pub tile_params: TileParams,
    /// Layout metadata for tensors.
    pub layout_metadata: LayoutMetadata,
    /// Workspace memory layout.
    pub workspace_layout: WorkspaceLayout,
    /// Global epilogue chain (applied to final output).
    pub epilogue_chain: EpilogueChain,
    /// Global thread partition.
    pub thread_partition: ThreadPartition,
    /// Ordered list of operations to execute.
    pub ops: Vec<PlanOp>,
    /// Pre-computed constant data (transformed filters, packed weights).
    ///
    /// This data is computed at compile time and used at runtime. Kernels
    /// reference this via offsets stored in `KernelParams.extra[6..8]`:
    /// - `extra[6]`: Offset into constant_data (usize::MAX if none)
    /// - `extra[7]`: Size of the constant data region
    pub constant_data: Vec<u8>,
    /// Canonical lookup tables used by this plan.
    pub lookup_tables: LookupTables,
}

impl BackendPlan {
    /// Create a new empty plan.
    pub fn new(backend_type: BackendType) -> Self {
        Self {
            backend_type,
            kernel_table: KernelTable::default(),
            tile_params: TileParams::default(),
            layout_metadata: LayoutMetadata::default(),
            workspace_layout: WorkspaceLayout::new(),
            epilogue_chain: EpilogueChain::new(),
            thread_partition: ThreadPartition::sequential(),
            ops: Vec::new(),
            constant_data: Vec::new(),
            lookup_tables: LookupTables::default(),
        }
    }

    /// Execute the plan.
    ///
    /// This is the main entry point for running a compiled plan.
    /// All decisions have been made at compile time; this just
    /// executes the pre-computed sequence of operations.
    ///
    /// # Arguments
    /// * `inputs` - Input buffer handles
    /// * `outputs` - Output buffer handles (mutable)
    /// * `workspace` - Pre-allocated workspace memory
    /// * `ctx` - Backend context
    ///
    /// # Errors
    /// Returns an error if execution fails (e.g., buffer size mismatch).
    pub fn execute(
        &self,
        inputs: &[BufferHandle],
        outputs: &mut [BufferHandle],
        workspace: &mut WorkspaceHandle,
        _ctx: &BackendContext,
    ) -> Result<(), BackendError> {
        // Validate input/output counts
        if inputs.len() != self.layout_metadata.num_inputs {
            return Err(BackendError::InvalidConfiguration(format!(
                "Expected {} inputs, got {}",
                self.layout_metadata.num_inputs,
                inputs.len()
            )));
        }
        if outputs.len() != self.layout_metadata.num_outputs {
            return Err(BackendError::InvalidConfiguration(format!(
                "Expected {} outputs, got {}",
                self.layout_metadata.num_outputs,
                outputs.len()
            )));
        }

        // Validate workspace size
        if !workspace.is_null()
            && workspace.total_size() < (self.workspace_layout.total_size as usize)
        {
            return Err(BackendError::BufferError(format!(
                "Workspace too small: need {} bytes, got {}",
                self.workspace_layout.total_size,
                workspace.total_size()
            )));
        }

        // Execute each operation in sequence
        for op in &self.ops {
            // Get kernel function from table based on kernel_id
            let kernel_fn = match op.kernel_id {
                KernelId::GEMM_STANDARD | KernelId::GEMM_STRASSEN => {
                    self.kernel_table.gemm.get(op.kernel_idx).copied()
                }
                KernelId::CONV_WINOGRAD_F23
                | KernelId::CONV_WINOGRAD_F43
                | KernelId::CONV_IM2COL
                | KernelId::CONV_DIRECT => self.kernel_table.conv.get(op.kernel_idx).copied(),
                _ => self.kernel_table.gemm.first().copied(),
            };

            let kernel_fn = kernel_fn.ok_or_else(|| {
                BackendError::InvalidConfiguration(format!(
                    "Kernel index {} out of bounds for kernel_id {:?}",
                    op.kernel_idx, op.kernel_id
                ))
            })?;

            // Resolve BufferRef to pointers for kernel execution.
            // BufferRef discriminant provides zero-overhead dispatch:
            // - Input(idx): index into inputs slice
            // - Output(idx): index into outputs slice
            // - Workspace(slot): region in workspace memory
            let input_ptrs: Vec<*const u8> = op
                .input_refs
                .iter()
                .filter_map(|buf_ref| match buf_ref {
                    BufferRef::Input(idx) => inputs.get(*idx).map(|h| h.id() as *const u8),
                    BufferRef::Output(idx) => outputs.get(*idx).map(|h| h.id() as *const u8),
                    BufferRef::Workspace(slot) => {
                        // SAFETY: workspace region access is checked at compile time
                        Some(unsafe { workspace.region_ptr(*slot) as *const u8 })
                    }
                    BufferRef::Constant { offset, size: _ } => {
                        // Zero-copy: pointer directly into plan.constant_data
                        Some(self.constant_data.as_ptr().wrapping_add(*offset))
                    }
                    BufferRef::ExternalConstant { offset, .. } => {
                        Some(self.constant_data.as_ptr().wrapping_add(*offset))
                    }
                })
                .collect();

            let output_ptrs: Vec<*mut u8> = op
                .output_refs
                .iter()
                .filter_map(|buf_ref| match buf_ref {
                    BufferRef::Input(idx) => inputs.get(*idx).map(|h| h.id() as *mut u8),
                    BufferRef::Output(idx) => outputs.get(*idx).map(|h| h.id() as *mut u8),
                    BufferRef::Workspace(slot) => {
                        // SAFETY: workspace region access is checked at compile time
                        Some(unsafe { workspace.region_ptr(*slot) })
                    }
                    BufferRef::Constant { .. } => {
                        // Constants are read-only, cannot be used as output buffers
                        None
                    }
                    BufferRef::ExternalConstant { .. } => None,
                })
                .collect();

            // Resolve dimensions if this operation has dynamic dimensions.
            // This allows the same compiled plan to work with different input sizes.
            let params = if op.params.has_dynamic_dims() {
                if op.params.needs_predecessor_info() {
                    // Compute predecessor element counts from buffer sizes.
                    // Each predecessor's element count = buffer_size / sizeof(f32)
                    let predecessor_elements: Vec<usize> = op
                        .input_refs
                        .iter()
                        .map(|buf_ref| {
                            let bytes = match buf_ref {
                                BufferRef::Workspace(slot) => self
                                    .workspace_layout
                                    .regions
                                    .get(*slot)
                                    .map(|r| r.size)
                                    .unwrap_or(0),
                                BufferRef::Input(idx) => {
                                    // Get from input shapes if available
                                    self.layout_metadata
                                        .input_shapes
                                        .get(*idx)
                                        .map(|s| {
                                            (s.iter().filter(|&&d| d > 0).product::<usize>() * 4)
                                                as u64
                                        })
                                        .unwrap_or(0)
                                }
                                BufferRef::Constant { size, .. } => *size as u64,
                                BufferRef::ExternalConstant { size, .. } => *size as u64,
                                BufferRef::Output(_) => 0,
                            };
                            // Convert bytes to f32 elements (4 bytes per element)
                            (bytes / 4) as usize
                        })
                        .collect();

                    op.params.resolve_dims_with_predecessors(
                        &self.layout_metadata.input_shapes,
                        &predecessor_elements,
                    )
                } else {
                    op.params.resolve_dims(&self.layout_metadata.input_shapes)
                }
            } else {
                op.params.clone()
            };

            // Execute kernel with resolved parameters
            kernel_fn(&input_ptrs, &output_ptrs, &params, &self.lookup_tables)?;
        }

        Ok(())
    }

    /// Execute the plan with explicit runtime input shapes.
    ///
    /// Use this method when input tensor shapes are different from compile-time shapes.
    /// This allows the same compiled plan to work with varying batch sizes, sequence
    /// lengths, or other dynamic dimensions.
    ///
    /// # Arguments
    /// * `inputs` - Input buffer handles
    /// * `outputs` - Output buffer handles (mutable)
    /// * `workspace` - Pre-allocated workspace memory
    /// * `ctx` - Backend context
    /// * `runtime_shapes` - Actual shapes of input tensors at runtime
    ///
    /// # Errors
    /// Returns an error if execution fails.
    pub fn execute_with_shapes(
        &self,
        inputs: &[BufferHandle],
        outputs: &mut [BufferHandle],
        workspace: &mut WorkspaceHandle,
        _ctx: &BackendContext,
        runtime_shapes: &[[usize; 4]],
    ) -> Result<(), BackendError> {
        // Validate input/output counts
        if inputs.len() != self.layout_metadata.num_inputs {
            return Err(BackendError::InvalidConfiguration(format!(
                "Expected {} inputs, got {}",
                self.layout_metadata.num_inputs,
                inputs.len()
            )));
        }
        if outputs.len() != self.layout_metadata.num_outputs {
            return Err(BackendError::InvalidConfiguration(format!(
                "Expected {} outputs, got {}",
                self.layout_metadata.num_outputs,
                outputs.len()
            )));
        }

        // Validate workspace size
        if !workspace.is_null()
            && workspace.total_size() < (self.workspace_layout.total_size as usize)
        {
            return Err(BackendError::BufferError(format!(
                "Workspace too small: need {} bytes, got {}",
                self.workspace_layout.total_size,
                workspace.total_size()
            )));
        }

        // Execute each operation in sequence
        for op in &self.ops {
            // Get kernel function from table based on kernel_id
            let kernel_fn = self.get_kernel_fn(op)?;

            // Resolve BufferRef to pointers
            let input_ptrs: Vec<*const u8> = op
                .input_refs
                .iter()
                .filter_map(|buf_ref| {
                    self.resolve_buffer_ptr_const(buf_ref, inputs, outputs, workspace)
                })
                .collect();

            let output_ptrs: Vec<*mut u8> = op
                .output_refs
                .iter()
                .filter_map(|buf_ref| {
                    self.resolve_buffer_ptr_mut(buf_ref, inputs, outputs, workspace)
                })
                .collect();

            // Resolve dimensions from runtime shapes
            let params = if op.params.has_dynamic_dims() {
                op.params.resolve_dims(runtime_shapes)
            } else {
                op.params.clone()
            };

            // Execute kernel with resolved parameters
            kernel_fn(&input_ptrs, &output_ptrs, &params, &self.lookup_tables)?;
        }

        Ok(())
    }

    /// Helper to get kernel function from table.
    fn get_kernel_fn(&self, op: &PlanOp) -> Result<KernelFn, BackendError> {
        let kernel_fn = match op.kernel_id {
            KernelId::GEMM_STANDARD | KernelId::GEMM_STRASSEN => {
                self.kernel_table.gemm.get(op.kernel_idx).copied()
            }
            KernelId::CONV_WINOGRAD_F23
            | KernelId::CONV_WINOGRAD_F43
            | KernelId::CONV_IM2COL
            | KernelId::CONV_DIRECT => self.kernel_table.conv.get(op.kernel_idx).copied(),
            _ => self.kernel_table.gemm.first().copied(),
        };

        kernel_fn.ok_or_else(|| {
            BackendError::InvalidConfiguration(format!(
                "Kernel index {} out of bounds for kernel_id {:?}",
                op.kernel_idx, op.kernel_id
            ))
        })
    }

    /// Helper to resolve BufferRef to const pointer.
    fn resolve_buffer_ptr_const(
        &self,
        buf_ref: &BufferRef,
        inputs: &[BufferHandle],
        outputs: &[BufferHandle],
        workspace: &WorkspaceHandle,
    ) -> Option<*const u8> {
        match buf_ref {
            BufferRef::Input(idx) => inputs.get(*idx).map(|h| h.id() as *const u8),
            BufferRef::Output(idx) => outputs.get(*idx).map(|h| h.id() as *const u8),
            BufferRef::Workspace(slot) => Some(unsafe { workspace.region_ptr(*slot) as *const u8 }),
            BufferRef::Constant { offset, size: _ } => {
                Some(self.constant_data.as_ptr().wrapping_add(*offset))
            }
            BufferRef::ExternalConstant { offset, .. } => {
                Some(self.constant_data.as_ptr().wrapping_add(*offset))
            }
        }
    }

    /// Helper to resolve BufferRef to mutable pointer.
    fn resolve_buffer_ptr_mut(
        &self,
        buf_ref: &BufferRef,
        inputs: &[BufferHandle],
        outputs: &mut [BufferHandle],
        workspace: &WorkspaceHandle,
    ) -> Option<*mut u8> {
        match buf_ref {
            BufferRef::Input(idx) => inputs.get(*idx).map(|h| h.id() as *mut u8),
            BufferRef::Output(idx) => outputs.get(*idx).map(|h| h.id() as *mut u8),
            BufferRef::Workspace(slot) => Some(unsafe { workspace.region_ptr(*slot) }),
            BufferRef::Constant { .. } => None,
            BufferRef::ExternalConstant { .. } => None,
        }
    }

    /// Get the required workspace size.
    pub fn workspace_size(&self) -> usize {
        self.workspace_layout.total_size as usize
    }

    /// Get the required workspace alignment.
    pub fn workspace_alignment(&self) -> usize {
        self.workspace_layout.alignment as usize
    }

    /// Get the number of operations in the plan.
    pub fn num_ops(&self) -> usize {
        self.ops.len()
    }
}

// BackendPlan is Send + Sync because all its fields are either Send + Sync
// or contain only static function pointers.
unsafe impl Send for BackendPlan {}
unsafe impl Sync for BackendPlan {}

// ============================================================================
// SERIALIZABLE PLAN TYPES
// ============================================================================

/// Serializable version of BackendPlan for .holo files.
///
/// This type stores kernel IDs instead of function pointers, allowing it
/// to be serialized to disk. At load time, kernel IDs are resolved back
/// to function pointers based on the current CPU capabilities.
#[derive(Debug, Clone, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
pub struct SerializableBackendPlan {
    /// Format version for compatibility checking.
    pub version: u32,
    /// Backend this plan is compiled for.
    pub backend_type: BackendType,
    /// Kernel selection info (IDs, not function pointers).
    pub kernel_info: SerializableKernelInfo,
    /// Global tile parameters.
    pub tile_params: TileParams,
    /// Layout metadata for tensors.
    pub layout_metadata: LayoutMetadata,
    /// Workspace memory layout.
    pub workspace_layout: WorkspaceLayout,
    /// Global epilogue chain.
    pub epilogue_chain: EpilogueChain,
    /// Global thread partition.
    pub thread_partition: ThreadPartition,
    /// Ordered list of operations.
    pub ops: Vec<SerializablePlanOp>,
    /// Pre-computed constant data (transformed filters, packed weights).
    pub constant_data: Vec<u8>,
}

/// Current format version for SerializableBackendPlan.
pub const PLAN_FORMAT_VERSION: u32 = 1;

/// Serializable kernel info with IDs instead of function pointers.
#[derive(Debug, Clone, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
pub struct SerializableKernelInfo {
    /// GEMM kernel IDs by tile config index.
    pub gemm_kernels: [KernelId; 4],
    /// Convolution kernel IDs by algorithm index.
    pub conv_kernels: [KernelId; 8],
    /// Binary elementwise kernel IDs.
    pub elementwise_binary_kernels: [KernelId; 8],
    /// Activation kernel IDs.
    pub activation_kernels: [KernelId; 16],
    /// Transcendental + Unary Math kernel IDs.
    pub transcendental_kernels: [KernelId; 11],
    /// Reduction kernel IDs.
    pub reduce_kernels: [KernelId; 8],
    /// Tensor operation kernel IDs.
    pub tensor_ops_kernels: [KernelId; 16],
    /// Normalization kernel IDs.
    pub normalization_kernels: [KernelId; 8],
    /// Loss function kernel IDs.
    pub loss_kernels: [KernelId; 4],
    /// Comparison kernel IDs.
    pub comparison_kernels: [KernelId; 8],
    /// Bitwise kernel IDs.
    pub bitwise_kernels: [KernelId; 8],
    /// Linear algebra kernel IDs.
    pub linalg_kernels: [KernelId; 8],
    /// Pooling kernel IDs.
    pub pooling_kernels: [KernelId; 4],
    /// Metadata kernel IDs.
    pub metadata_kernels: [KernelId; 4],
    /// SIMD capability used during compilation (for compatibility check).
    pub simd_capability: u8,
}

/// Serializable operation in the plan.
#[derive(Debug, Clone, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
pub struct SerializablePlanOp {
    /// Kernel to execute.
    pub kernel_id: KernelId,
    /// Index into kernel table category.
    pub kernel_idx: usize,
    /// Parameters for this operation.
    pub params: KernelParams,
    /// Epilogue chain for this operation.
    pub epilogue: EpilogueChain,
    /// Thread partition for this operation.
    pub partition: ThreadPartition,
    /// Input buffer references (pre-resolved for zero-overhead dispatch).
    pub input_refs: Vec<BufferRef>,
    /// Output buffer references (pre-resolved for zero-overhead dispatch).
    pub output_refs: Vec<BufferRef>,
}

impl SerializableBackendPlan {
    /// Convert to an executable BackendPlan by resolving kernel function pointers.
    ///
    /// This resolves kernel IDs to actual function pointers based on the
    /// current CPU's capabilities.
    pub fn into_backend_plan(self) -> Result<BackendPlan, BackendError> {
        // Resolve kernel table from kernel info
        let kernel_table = KernelTable::from_serializable_info(&self.kernel_info)?;

        // Convert ops
        let ops = self
            .ops
            .into_iter()
            .map(|op| PlanOp {
                kernel_id: op.kernel_id,
                kernel_idx: op.kernel_idx,
                params: op.params,
                epilogue: op.epilogue,
                partition: op.partition,
                input_refs: op.input_refs,
                output_refs: op.output_refs,
            })
            .collect();

        Ok(BackendPlan {
            backend_type: self.backend_type,
            kernel_table,
            tile_params: self.tile_params,
            layout_metadata: self.layout_metadata,
            workspace_layout: self.workspace_layout,
            epilogue_chain: self.epilogue_chain,
            thread_partition: self.thread_partition,
            ops,
            constant_data: self.constant_data,
            lookup_tables: LookupTables::default(),
        })
    }
}

impl BackendPlan {
    /// Convert to serializable form for .holo storage.
    pub fn to_serializable(&self) -> SerializableBackendPlan {
        SerializableBackendPlan {
            version: PLAN_FORMAT_VERSION,
            backend_type: self.backend_type.clone(),
            kernel_info: self.kernel_table.to_serializable_info(),
            tile_params: self.tile_params,
            layout_metadata: self.layout_metadata.clone(),
            workspace_layout: self.workspace_layout.clone(),
            epilogue_chain: self.epilogue_chain.clone(),
            thread_partition: self.thread_partition.clone(),
            ops: self
                .ops
                .iter()
                .map(|op| SerializablePlanOp {
                    kernel_id: op.kernel_id,
                    kernel_idx: op.kernel_idx,
                    params: op.params.clone(),
                    epilogue: op.epilogue.clone(),
                    partition: op.partition.clone(),
                    input_refs: op.input_refs.clone(),
                    output_refs: op.output_refs.clone(),
                })
                .collect(),
            constant_data: self.constant_data.clone(),
        }
    }

    /// Access the canonical lookup tables bundled with this plan.
    #[must_use]
    pub const fn lookup_tables(&self) -> LookupTables {
        self.lookup_tables
    }
}

impl KernelTable {
    /// Convert to serializable kernel info.
    pub fn to_serializable_info(&self) -> SerializableKernelInfo {
        // For now, use default kernel IDs since we don't track which specific
        // kernels were selected. The kernel resolution at load time will
        // select the appropriate kernels based on CPU capabilities.
        SerializableKernelInfo {
            gemm_kernels: [KernelId::GEMM_STANDARD; 4],
            conv_kernels: [KernelId::CONV_DIRECT; 8],
            elementwise_binary_kernels: [KernelId::ELEM_ADD; 8],
            activation_kernels: [
                KernelId::ACT_RELU,
                KernelId::ACT_SIGMOID,
                KernelId::ACT_TANH,
                KernelId::ACT_GELU,
                KernelId::ACT_SILU,
                KernelId::ACT_MISH,
                KernelId::ACT_SOFTPLUS,
                KernelId::ACT_LEAKY_RELU,
                KernelId::ACT_RELU_U8,
                KernelId::ACT_SIGMOID_U8,
                KernelId::ACT_TANH_U8,
                KernelId::ACT_GELU_U8,
                KernelId::ACT_SILU_U8,
                KernelId::ACT_FUSED_SIGMOID_RELU_U8,
                KernelId::ACT_FUSED_SIGMOID_TANH_U8,
                KernelId::ACT_FUSED_SIGMOID_TANH_RELU_U8,
            ],
            transcendental_kernels: [KernelId::TRANS_EXP; 11],
            reduce_kernels: [KernelId::REDUCE_SUM; 8],
            tensor_ops_kernels: [KernelId::TENSOR_GATHER; 16],
            normalization_kernels: [KernelId::NORM_BATCH; 8],
            loss_kernels: [KernelId::LOSS_MSE; 4],
            comparison_kernels: [KernelId::CMP_LESS; 8],
            bitwise_kernels: [KernelId::BIT_AND; 8],
            linalg_kernels: [KernelId::LINALG_DOT; 8],
            pooling_kernels: [KernelId::POOL_MAX; 4],
            metadata_kernels: [KernelId::GEMM_STANDARD; 4],
            simd_capability: 0, // Will be set by CPU detection
        }
    }

    /// Resolve function pointers from kernel info.
    ///
    /// Reconstructs the kernel table from serialized kernel IDs.
    /// Populates the kernel table with real CPU kernel implementations
    /// that use SIMD-accelerated SimdDispatcher methods.
    pub fn from_serializable_info(_info: &SerializableKernelInfo) -> Result<Self, BackendError> {
        use crate::backends::cpu::kernels;

        Ok(Self {
            // Category 0x01: GEMM
            gemm: [
                kernels::gemm_kernel_f32,         // GEMM_STANDARD
                kernels::gemm_kernel_f32,         // GEMM_STRASSEN (uses standard for now)
                kernels::gemm_kernel_f32,         // GEMM_TILED (uses standard for now)
                kernels::batch_matmul_kernel_f32, // GEMM_BATCH
            ],
            // Category 0x02: Convolution
            conv: [
                kernels::conv_direct_kernel_f32,   // CONV_DIRECT
                kernels::conv_im2col_kernel_f32,   // CONV_IM2COL
                kernels::conv_winograd_kernel_f32, // CONV_WINOGRAD_F23
                kernels::conv_winograd_kernel_f32, // CONV_WINOGRAD_F43
                fallback_kernel,                   // CONV_1D
                fallback_kernel,                   // CONV_DEPTHWISE
                fallback_kernel,
                fallback_kernel,
            ],
            // Category 0x03: Binary Elementwise
            elementwise_binary: [
                kernels::add_kernel_f32, // ELEM_ADD
                kernels::sub_kernel_f32, // ELEM_SUB
                kernels::mul_kernel_f32, // ELEM_MUL
                kernels::div_kernel_f32, // ELEM_DIV
                kernels::max_kernel_f32, // ELEM_MAX
                kernels::min_kernel_f32, // ELEM_MIN
                kernels::pow_kernel_f32, // ELEM_POW
                kernels::mod_kernel_f32, // ELEM_MOD
            ],
            // Category 0x04: Activation
            activation: [
                kernels::relu_kernel_f32,            // ACT_RELU
                kernels::sigmoid_kernel_f32,         // ACT_SIGMOID
                kernels::tanh_kernel_f32,            // ACT_TANH
                kernels::gelu_kernel_f32,            // ACT_GELU
                kernels::silu_kernel_f32,            // ACT_SILU
                kernels::mish_kernel_f32,            // ACT_MISH
                kernels::softplus_kernel_f32,        // ACT_SOFTPLUS
                kernels::leaky_relu_kernel_f32,      // ACT_LEAKY_RELU
                kernels::relu_kernel_u8,             // ACT_RELU_U8
                kernels::sigmoid_kernel_u8,          // ACT_SIGMOID_U8
                kernels::tanh_kernel_u8,             // ACT_TANH_U8
                kernels::gelu_kernel_u8,             // ACT_GELU_U8
                kernels::silu_kernel_u8,             // ACT_SILU_U8
                kernels::fused_sigmoid_relu_u8,      // ACT_FUSED_SIGMOID_RELU_U8
                kernels::fused_sigmoid_tanh_u8,      // ACT_FUSED_SIGMOID_TANH_U8
                kernels::fused_sigmoid_tanh_relu_u8, // ACT_FUSED_SIGMOID_TANH_RELU_U8
            ],
            // Category 0x05: Transcendental + Unary Math
            transcendental: [
                kernels::exp_kernel_f32,  // TRANS_EXP (0)
                kernels::log_kernel_f32,  // TRANS_LOG (1)
                kernels::sqrt_kernel_f32, // TRANS_SQRT (2)
                kernels::sin_kernel_f32,  // TRANS_SIN (3)
                kernels::cos_kernel_f32,  // TRANS_COS (4)
                kernels::tan_kernel_f32,  // TRANS_TAN (5)
                kernels::asin_kernel_f32, // TRANS_ASIN (6)
                kernels::acos_kernel_f32, // TRANS_ACOS (7)
                kernels::neg_kernel_f32,  // UNARY_NEG (8)
                kernels::abs_kernel_f32,  // UNARY_ABS (9)
                kernels::erf_kernel_f32,  // TRANS_ERF (10)
            ],
            // Category 0x06: Reduction
            reduce: [
                kernels::reduce_sum_kernel_f32,               // REDUCE_SUM
                kernels::reduce_max_kernel_f32,               // REDUCE_MAX
                kernels::reduce_min_kernel_f32,               // REDUCE_MIN
                kernels::reduce_mean_kernel_f32,              // REDUCE_MEAN
                kernels::reduce_variance_kernel_f32,          // REDUCE_VARIANCE
                kernels::reduce_argmax_kernel_f32,            // REDUCE_ARGMAX
                kernels::reduce_argmin_kernel_f32,            // REDUCE_ARGMIN
                kernels::reduce_prod_kernel_f32,              // REDUCE_PROD
                kernels::reduce_argmax_last_token_kernel_f32, // REDUCE_ARGMAX_LAST_TOKEN
            ],
            // Category 0x07: Tensor Operations
            tensor_ops: [
                kernels::gather_kernel_f32,            // TENSOR_GATHER
                kernels::slice_kernel_f32,             // TENSOR_SLICE
                kernels::concat_kernel_f32,            // TENSOR_CONCAT
                kernels::reshape_kernel_f32,           // TENSOR_RESHAPE
                kernels::expand_kernel_f32,            // TENSOR_EXPAND
                kernels::tile_kernel_f32,              // TENSOR_TILE
                kernels::squeeze_kernel_f32,           // TENSOR_SQUEEZE
                kernels::unsqueeze_kernel_f32,         // TENSOR_UNSQUEEZE
                kernels::transpose_kernel_f32,         // TENSOR_TRANSPOSE
                kernels::shape_kernel_f32,             // TENSOR_SHAPE
                kernels::range_kernel_f32,             // TENSOR_RANGE
                kernels::constant_of_shape_kernel_f32, // TENSOR_CONSTANT_SHAPE
                kernels::trilu_kernel_f32,             // TENSOR_TRILU
                kernels::scatter_nd_kernel_f32,        // TENSOR_SCATTER_ND
                kernels::split_kernel_f32,             // TENSOR_SPLIT
                fallback_kernel,
            ],
            // Category 0x08: Normalization
            normalization: [
                kernels::batch_norm_kernel_f32,    // NORM_BATCH
                kernels::layer_norm_kernel_f32,    // NORM_LAYER
                kernels::softmax_kernel_f32,       // NORM_SOFTMAX
                kernels::log_softmax_kernel_f32,   // NORM_LOG_SOFTMAX
                kernels::instance_norm_kernel_f32, // NORM_INSTANCE
                kernels::group_norm_kernel_f32,    // NORM_GROUP
                fallback_kernel,
                fallback_kernel,
            ],
            // Category 0x09: Loss Functions
            loss: [
                kernels::cross_entropy_kernel_f32, // LOSS_CROSS_ENTROPY
                kernels::mse_kernel_f32,           // LOSS_MSE
                kernels::mae_kernel_f32,           // LOSS_MAE
                kernels::huber_kernel_f32,         // LOSS_HUBER
            ],
            // Category 0x0A: Comparison
            comparison: [
                kernels::less_kernel_f32,          // CMP_LESS
                kernels::equal_kernel_f32,         // CMP_EQUAL
                kernels::greater_kernel_f32,       // CMP_GREATER
                kernels::less_equal_kernel_f32,    // CMP_LESS_EQUAL
                kernels::greater_equal_kernel_f32, // CMP_GREATER_EQUAL
                kernels::not_equal_kernel_f32,     // CMP_NOT_EQUAL
                fallback_kernel,
                fallback_kernel,
            ],
            // Category 0x0B: Bitwise
            bitwise: [
                kernels::bitwise_and_kernel, // BIT_AND
                kernels::bitwise_or_kernel,  // BIT_OR
                kernels::bitwise_xor_kernel, // BIT_XOR
                kernels::bitwise_not_kernel, // BIT_NOT
                kernels::shl_kernel,         // BIT_SHL
                kernels::shr_kernel,         // BIT_SHR
                fallback_kernel,
                fallback_kernel,
            ],
            // Category 0x0C: Linear Algebra
            linalg: [
                kernels::matvec_kernel_f32,       // LINALG_MATVEC
                kernels::vecmat_kernel_f32,       // LINALG_VECMAT
                kernels::dot_kernel_f32,          // LINALG_DOT
                kernels::outer_kernel_f32,        // LINALG_OUTER
                kernels::batch_matmul_kernel_f32, // LINALG_BATCH_MATMUL
                fallback_kernel,
                fallback_kernel,
                fallback_kernel,
            ],
            // Category 0x0D: Pooling
            pooling: [
                kernels::max_pool_kernel_f32,        // POOL_MAX
                kernels::avg_pool_kernel_f32,        // POOL_AVG
                kernels::global_max_pool_kernel_f32, // POOL_GLOBAL_MAX
                kernels::global_avg_pool_kernel_f32, // POOL_GLOBAL_AVG
            ],
            // Category 0x0E: Metadata
            metadata: [
                fallback_kernel, // META_BYTE
                fallback_kernel,
                fallback_kernel,
                fallback_kernel,
            ],
        })
    }
}

// =============================================================================
// PARTITION TYPES (Phase 7C: Distributed Execution)
// =============================================================================

/// A partition within a larger distributed execution plan.
///
/// Partitions store portable IR (not pre-compiled BackendPlans), allowing each
/// worker to compile for its own backend. This enables heterogeneous clusters
/// where CPU and GPU workers can execute the same partition.
#[derive(Debug, Clone, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
pub struct PlanPartition {
    /// Unique name for this partition (e.g., "encoder/layer_0").
    pub name: String,
    /// Content hash (BLAKE3) of the IR subgraph.
    pub content_id: [u8; 32],
    /// Serialized IR subgraph bytes.
    pub ir_bytes: Vec<u8>,
    /// Input specifications for this partition.
    pub inputs: Vec<PartitionIO>,
    /// Output specifications for this partition.
    pub outputs: Vec<PartitionIO>,
    /// Estimated compute cost (FLOPs).
    pub estimated_cost: u64,
    /// Estimated memory requirement (bytes).
    pub estimated_memory: u64,
}

/// Input/output specification for a partition.
#[derive(Debug, Clone, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
pub struct PartitionIO {
    /// Name of this tensor.
    pub name: String,
    /// Buffer index within the partition.
    pub buffer_idx: usize,
    /// Shape dimensions.
    pub shape: Vec<usize>,
    /// Data type (as u8, maps to DType).
    pub dtype: u8,
    /// For inputs: source partition name (None = external input).
    pub source_partition: Option<String>,
    /// For inputs: source output index within source partition.
    pub source_output_idx: Option<usize>,
}

impl PartitionIO {
    /// Create an external input (from outside the partitioned graph).
    #[must_use]
    pub fn external_input(
        name: impl Into<String>,
        buffer_idx: usize,
        shape: Vec<usize>,
        dtype: u8,
    ) -> Self {
        Self {
            name: name.into(),
            buffer_idx,
            shape,
            dtype,
            source_partition: None,
            source_output_idx: None,
        }
    }

    /// Create an input from another partition's output.
    #[must_use]
    pub fn from_partition(
        name: impl Into<String>,
        buffer_idx: usize,
        shape: Vec<usize>,
        dtype: u8,
        source_partition: impl Into<String>,
        source_output_idx: usize,
    ) -> Self {
        Self {
            name: name.into(),
            buffer_idx,
            shape,
            dtype,
            source_partition: Some(source_partition.into()),
            source_output_idx: Some(source_output_idx),
        }
    }

    /// Create an output specification.
    #[must_use]
    pub fn output(
        name: impl Into<String>,
        buffer_idx: usize,
        shape: Vec<usize>,
        dtype: u8,
    ) -> Self {
        Self {
            name: name.into(),
            buffer_idx,
            shape,
            dtype,
            source_partition: None,
            source_output_idx: None,
        }
    }

    /// Check if this is an external input (not from another partition).
    #[must_use]
    pub fn is_external(&self) -> bool {
        self.source_partition.is_none()
    }
}

/// A complete partitioned execution plan for distributed execution.
#[derive(Debug, Clone, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug))]
pub struct PartitionedPlan {
    /// All partitions in this plan.
    pub partitions: Vec<PlanPartition>,
    /// Execution dependencies: partition name → names of partitions it depends on.
    pub dependencies: Vec<(String, Vec<String>)>,
    /// External input names (inputs to the overall graph).
    pub external_inputs: Vec<String>,
    /// External output names (outputs from the overall graph).
    pub external_outputs: Vec<String>,
}

impl PartitionedPlan {
    /// Create a new empty partitioned plan.
    #[must_use]
    pub fn new() -> Self {
        Self {
            partitions: Vec::new(),
            dependencies: Vec::new(),
            external_inputs: Vec::new(),
            external_outputs: Vec::new(),
        }
    }

    /// Get the number of partitions.
    #[must_use]
    pub fn num_partitions(&self) -> usize {
        self.partitions.len()
    }

    /// Get a partition by name.
    #[must_use]
    pub fn get_partition(&self, name: &str) -> Option<&PlanPartition> {
        self.partitions.iter().find(|p| p.name == name)
    }

    /// Get partitions that have no dependencies (can execute first).
    #[must_use]
    pub fn root_partitions(&self) -> Vec<&PlanPartition> {
        self.partitions
            .iter()
            .filter(|p| {
                self.dependencies
                    .iter()
                    .find(|(name, _)| name == &p.name)
                    .is_none_or(|(_, deps)| deps.is_empty())
            })
            .collect()
    }

    /// Get partitions that depend on the given partition.
    #[must_use]
    pub fn dependents(&self, partition_name: &str) -> Vec<&str> {
        self.dependencies
            .iter()
            .filter_map(|(name, deps)| {
                if deps.iter().any(|d| d == partition_name) {
                    Some(name.as_str())
                } else {
                    None
                }
            })
            .collect()
    }

    /// Get dependencies of a partition.
    #[must_use]
    pub fn get_dependencies(&self, partition_name: &str) -> Option<&[String]> {
        self.dependencies
            .iter()
            .find(|(name, _)| name == partition_name)
            .map(|(_, deps)| deps.as_slice())
    }

    /// Add a partition to the plan.
    pub fn add_partition(&mut self, partition: PlanPartition, depends_on: Vec<String>) {
        let name = partition.name.clone();
        self.partitions.push(partition);
        self.dependencies.push((name, depends_on));
    }

    /// Get a topologically sorted execution order.
    ///
    /// Returns partition names in an order where all dependencies are satisfied.
    #[must_use]
    pub fn execution_order(&self) -> Vec<&str> {
        let mut order = Vec::with_capacity(self.partitions.len());
        let mut executed: std::collections::HashSet<&str> = std::collections::HashSet::new();
        let mut remaining: Vec<&str> = self.partitions.iter().map(|p| p.name.as_str()).collect();

        while !remaining.is_empty() {
            let ready_idx = remaining.iter().position(|name| {
                self.get_dependencies(name)
                    .is_none_or(|deps| deps.iter().all(|d| executed.contains(d.as_str())))
            });

            match ready_idx {
                Some(idx) => {
                    let name = remaining.remove(idx);
                    order.push(name);
                    executed.insert(name);
                }
                None => {
                    // Circular dependency detected - return what we have
                    break;
                }
            }
        }

        order
    }

    /// Total estimated compute cost across all partitions.
    #[must_use]
    pub fn total_estimated_cost(&self) -> u64 {
        self.partitions.iter().map(|p| p.estimated_cost).sum()
    }

    /// Total estimated memory across all partitions.
    #[must_use]
    pub fn total_estimated_memory(&self) -> u64 {
        self.partitions.iter().map(|p| p.estimated_memory).sum()
    }
}

impl Default for PartitionedPlan {
    fn default() -> Self {
        Self::new()
    }
}

impl PlanPartition {
    /// Create a new partition.
    #[must_use]
    pub fn new(name: impl Into<String>, content_id: [u8; 32], ir_bytes: Vec<u8>) -> Self {
        Self {
            name: name.into(),
            content_id,
            ir_bytes,
            inputs: Vec::new(),
            outputs: Vec::new(),
            estimated_cost: 0,
            estimated_memory: 0,
        }
    }

    /// Set cost estimate.
    #[must_use]
    pub fn with_cost(mut self, cost: u64) -> Self {
        self.estimated_cost = cost;
        self
    }

    /// Set memory estimate.
    #[must_use]
    pub fn with_memory(mut self, memory: u64) -> Self {
        self.estimated_memory = memory;
        self
    }

    /// Add an input.
    pub fn add_input(&mut self, io: PartitionIO) {
        self.inputs.push(io);
    }

    /// Add an output.
    pub fn add_output(&mut self, io: PartitionIO) {
        self.outputs.push(io);
    }

    /// Get content ID as hex string.
    #[must_use]
    pub fn content_id_hex(&self) -> String {
        self.content_id
            .iter()
            .map(|b| format!("{:02x}", b))
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_kernel_id() {
        assert_ne!(KernelId::GEMM_STANDARD, KernelId::GEMM_STRASSEN);
        assert_eq!(KernelId::GEMM_STANDARD.0, 0x0101);
        assert_eq!(KernelId::GEMM_STANDARD.category(), 0x01);
        assert_eq!(KernelId::GEMM_STANDARD.index(), 0x01);
        assert_eq!(KernelId::CONV_DIRECT.category(), 0x02);
        assert_eq!(KernelId::ELEM_ADD.category(), 0x03);
        assert_eq!(KernelId::ACT_RELU.category(), 0x04);
        assert!(!KernelId::GEMM_STANDARD.is_dynamic());
        assert!(KernelId::DYNAMIC_BASE.is_dynamic());
    }

    #[test]
    fn test_tile_params() {
        let avx2 = TileParams::avx2();
        assert_eq!(avx2.tile_m, 72);
        assert_eq!(avx2.micro_n, 16);

        let neon = TileParams::neon();
        assert_eq!(neon.tile_m, 64);
        assert_eq!(neon.micro_n, 8);
    }

    #[test]
    fn test_workspace_layout() {
        let mut layout = WorkspaceLayout::new();

        let off1 = layout.add_region("scratch", 1024, 64);
        assert_eq!(off1, 0);

        let off2 = layout.add_region("temp", 512, 32);
        assert_eq!(off2, 1024); // Aligned to 32

        assert_eq!(layout.total_size, 1024 + 512);
        assert_eq!(layout.alignment, 64);
    }

    #[test]
    fn test_epilogue_chain() {
        let mut chain = EpilogueChain::new();
        assert!(chain.is_empty());

        chain.push(EpilogueOp::BiasAdd { offset: 0 });
        chain.push(EpilogueOp::ReLU);
        assert_eq!(chain.len(), 2);

        chain.push(EpilogueOp::BiasAddConst {
            offset: 0,
            stride: 1,
            channel_dim: 0,
        });
        assert_eq!(chain.len(), 3);
    }

    #[test]
    fn test_thread_partition_sequential() {
        let part = ThreadPartition::sequential();
        assert_eq!(part.num_threads, 1);
        assert_eq!(part.work_ranges.len(), 1);
    }

    #[test]
    fn test_thread_partition_parallel() {
        let part = ThreadPartition::parallel(4, 1000);
        assert_eq!(part.num_threads, 4);
        assert_eq!(part.work_ranges.len(), 4);

        // Check ranges cover all work
        assert_eq!(part.work_ranges[0].start, 0);
        assert_eq!(part.work_ranges[3].end, 1000);
    }

    #[test]
    fn test_backend_plan_creation() {
        let plan = BackendPlan::new(BackendType::Cpu);
        assert_eq!(plan.backend_type, BackendType::Cpu);
        assert_eq!(plan.num_ops(), 0);
        assert_eq!(plan.workspace_size(), 0);
    }

    #[test]
    fn backend_plan_uses_canonical_lookup_tables() {
        let plan = BackendPlan::new(BackendType::Cpu);
        let tables = plan.lookup_tables();
        assert_eq!(
            tables.packed_table as *const _, &PACKED_TABLE as *const _,
            "plan should reference the canonical packed table"
        );
        assert_eq!(
            tables.byte_meta_table as *const _, &BYTE_META_TABLE as *const _,
            "plan should reference the canonical categorical metadata"
        );
    }

    #[test]
    fn test_workspace_handle_null() {
        let handle = WorkspaceHandle::null();
        assert!(handle.is_null());
        assert_eq!(handle.total_size(), 0);
    }

    #[test]
    fn test_serializable_backend_plan_roundtrip() {
        // Create a plan
        let mut plan = BackendPlan::new(BackendType::Cpu);
        plan.tile_params = TileParams::avx2();
        plan.layout_metadata.num_inputs = 2;
        plan.layout_metadata.num_outputs = 1;
        plan.workspace_layout.add_region("scratch", 1024, 64);
        plan.ops.push(PlanOp {
            kernel_id: KernelId::GEMM_STANDARD,
            kernel_idx: 0,
            params: KernelParams::default(),
            epilogue: EpilogueChain::single(EpilogueOp::ReLU),
            partition: ThreadPartition::sequential(),
            input_refs: vec![BufferRef::Input(0), BufferRef::Input(1)],
            output_refs: vec![BufferRef::Output(0)],
        });

        // Convert to serializable
        let serializable = plan.to_serializable();
        assert_eq!(serializable.version, PLAN_FORMAT_VERSION);
        assert_eq!(serializable.backend_type, BackendType::Cpu);
        assert_eq!(serializable.ops.len(), 1);

        // Serialize to bytes using rkyv
        let bytes = rkyv::to_bytes::<rkyv::rancor::Error>(&serializable).unwrap();

        // Deserialize back
        let deserialized: SerializableBackendPlan =
            rkyv::from_bytes::<SerializableBackendPlan, rkyv::rancor::Error>(&bytes).unwrap();

        // Verify
        assert_eq!(deserialized.version, PLAN_FORMAT_VERSION);
        assert_eq!(deserialized.backend_type, BackendType::Cpu);
        assert_eq!(deserialized.tile_params, TileParams::avx2());
        assert_eq!(deserialized.ops.len(), 1);
        assert_eq!(deserialized.ops[0].kernel_id, KernelId::GEMM_STANDARD);
    }

    #[test]
    fn test_serializable_to_backend_plan() {
        // Create a serializable plan directly
        let serializable = SerializableBackendPlan {
            version: PLAN_FORMAT_VERSION,
            backend_type: BackendType::Cpu,
            kernel_info: SerializableKernelInfo {
                gemm_kernels: [KernelId::GEMM_STANDARD; 4],
                conv_kernels: [KernelId::CONV_DIRECT; 8],
                elementwise_binary_kernels: [KernelId::ELEM_ADD; 8],
                activation_kernels: [
                    KernelId::ACT_RELU,
                    KernelId::ACT_SIGMOID,
                    KernelId::ACT_TANH,
                    KernelId::ACT_GELU,
                    KernelId::ACT_SILU,
                    KernelId::ACT_MISH,
                    KernelId::ACT_SOFTPLUS,
                    KernelId::ACT_LEAKY_RELU,
                    KernelId::ACT_RELU_U8,
                    KernelId::ACT_SIGMOID_U8,
                    KernelId::ACT_TANH_U8,
                    KernelId::ACT_GELU_U8,
                    KernelId::ACT_SILU_U8,
                    KernelId::ACT_FUSED_SIGMOID_RELU_U8,
                    KernelId::ACT_FUSED_SIGMOID_TANH_U8,
                    KernelId::ACT_FUSED_SIGMOID_TANH_RELU_U8,
                ],
                transcendental_kernels: [KernelId::TRANS_EXP; 11],
                reduce_kernels: [KernelId::REDUCE_SUM; 8],
                tensor_ops_kernels: [KernelId::TENSOR_GATHER; 16],
                normalization_kernels: [KernelId::NORM_BATCH; 8],
                loss_kernels: [KernelId::LOSS_MSE; 4],
                comparison_kernels: [KernelId::CMP_LESS; 8],
                bitwise_kernels: [KernelId::BIT_AND; 8],
                linalg_kernels: [KernelId::LINALG_DOT; 8],
                pooling_kernels: [KernelId::POOL_MAX; 4],
                metadata_kernels: [KernelId::GEMM_STANDARD; 4],
                simd_capability: 0,
            },
            tile_params: TileParams::default(),
            layout_metadata: LayoutMetadata {
                num_inputs: 1,
                num_outputs: 1,
                input_sizes: vec![256],
                output_sizes: vec![256],
                input_shapes: vec![[1, 1, 16, 16]],
                output_shapes: vec![[1, 1, 16, 16]],
                output_shape_exprs: vec![None],
            },
            workspace_layout: WorkspaceLayout::new(),
            epilogue_chain: EpilogueChain::new(),
            thread_partition: ThreadPartition::sequential(),
            ops: vec![],
            constant_data: Vec::new(),
        };

        // Convert to BackendPlan
        let plan = serializable.into_backend_plan().unwrap();
        assert_eq!(plan.backend_type, BackendType::Cpu);
        assert_eq!(plan.layout_metadata.num_inputs, 1);
        assert_eq!(plan.layout_metadata.num_outputs, 1);
        assert_eq!(plan.num_ops(), 0);
    }

    // ========================================================================
    // DYNAMIC KERNEL TABLE TESTS
    // ========================================================================

    fn dummy_kernel(
        _inputs: &[*const u8],
        _outputs: &[*mut u8],
        _params: &KernelParams,
        _tables: &LookupTables,
    ) -> Result<(), BackendError> {
        Ok(())
    }

    fn another_kernel(
        _inputs: &[*const u8],
        _outputs: &[*mut u8],
        _params: &KernelParams,
        _tables: &LookupTables,
    ) -> Result<(), BackendError> {
        Ok(())
    }

    #[test]
    fn test_dynamic_kernel_table_new() {
        let table = DynamicKernelTable::new();
        assert_eq!(table.count(), 0);
    }

    #[test]
    fn test_dynamic_kernel_table_register() {
        let table = DynamicKernelTable::new();

        let id1 = table.register(dummy_kernel);
        assert!(id1.is_dynamic());
        assert_eq!(id1.0, KernelId::DYNAMIC_BASE.0);
        assert_eq!(table.count(), 1);

        let id2 = table.register(another_kernel);
        assert!(id2.is_dynamic());
        assert_eq!(id2.0, KernelId::DYNAMIC_BASE.0 + 1);
        assert_eq!(table.count(), 2);
    }

    #[test]
    fn test_dynamic_kernel_table_get() {
        let table = DynamicKernelTable::new();
        let id = table.register(dummy_kernel);

        // Should find registered kernel
        assert!(table.get(id).is_some());

        // Should not find unregistered kernel
        assert!(table.get(KernelId(0x1100)).is_none());

        // Should not find static kernels
        assert!(table.get(KernelId::GEMM_STANDARD).is_none());
    }

    #[test]
    fn test_dynamic_kernel_table_unregister() {
        let table = DynamicKernelTable::new();
        let id = table.register(dummy_kernel);

        assert_eq!(table.count(), 1);
        assert!(table.unregister(id));
        assert_eq!(table.count(), 0);
        assert!(table.get(id).is_none());

        // Second unregister should fail
        assert!(!table.unregister(id));

        // Can't unregister static kernels
        assert!(!table.unregister(KernelId::GEMM_STANDARD));
    }

    #[test]
    fn test_dynamic_kernel_table_register_with_id() {
        let table = DynamicKernelTable::new();

        // Register with specific ID
        let specific_id = KernelId(0x1050);
        assert!(table.register_with_id(specific_id, dummy_kernel));
        assert_eq!(table.count(), 1);
        assert!(table.get(specific_id).is_some());

        // Can't register same ID twice
        assert!(!table.register_with_id(specific_id, another_kernel));

        // Can't register static IDs
        assert!(!table.register_with_id(KernelId::GEMM_STANDARD, dummy_kernel));
    }

    #[test]
    fn test_dynamic_kernel_table_list_ids() {
        let table = DynamicKernelTable::new();

        table.register(dummy_kernel);
        table.register(another_kernel);

        let ids = table.list_ids();
        assert_eq!(ids.len(), 2);
        assert!(ids.iter().all(|id| id.is_dynamic()));
    }

    #[test]
    fn test_dynamic_kernel_table_clear() {
        let table = DynamicKernelTable::new();

        table.register(dummy_kernel);
        table.register(another_kernel);
        assert_eq!(table.count(), 2);

        table.clear();
        assert_eq!(table.count(), 0);
    }

    #[test]
    fn test_dynamic_kernel_table_debug() {
        let table = DynamicKernelTable::new();
        table.register(dummy_kernel);

        let debug = format!("{:?}", table);
        assert!(debug.contains("DynamicKernelTable"));
        assert!(debug.contains("count"));
    }

    #[test]
    fn test_workspace_region_serialization() {
        // Create a WorkspaceRegion with known values
        let region = WorkspaceRegion {
            name: "workspace_16".to_string(),
            offset: 58195968,
            size: 16777216, // 16MB
            alignment: 64,
            size_expr: None,
        };

        // Serialize
        let bytes =
            rkyv::to_bytes::<rkyv::rancor::Error>(&region).expect("serialization should succeed");

        // Deserialize
        let mut aligned: rkyv::util::AlignedVec<16> = rkyv::util::AlignedVec::new();
        aligned.extend_from_slice(&bytes);
        let deserialized: WorkspaceRegion =
            rkyv::from_bytes::<WorkspaceRegion, rkyv::rancor::Error>(&aligned)
                .expect("deserialization should succeed");

        // Verify values match
        assert_eq!(deserialized.name, region.name);
        assert_eq!(
            deserialized.offset, region.offset,
            "offset mismatch: expected {}, got {}",
            region.offset, deserialized.offset
        );
        assert_eq!(
            deserialized.size,
            region.size,
            "size mismatch: expected {} bytes, got {} bytes ({}× reduction)",
            region.size,
            deserialized.size,
            region.size / deserialized.size.max(1)
        );
        assert_eq!(deserialized.alignment, region.alignment);
    }

    #[test]
    fn test_workspace_layout_serialization() {
        // Create a WorkspaceLayout with a 16MB region
        let mut layout = WorkspaceLayout::new();
        layout.add_region("workspace_16", 16777216, 64);

        // Serialize
        let bytes =
            rkyv::to_bytes::<rkyv::rancor::Error>(&layout).expect("serialization should succeed");

        // Deserialize
        let mut aligned: rkyv::util::AlignedVec<16> = rkyv::util::AlignedVec::new();
        aligned.extend_from_slice(&bytes);
        let deserialized: WorkspaceLayout =
            rkyv::from_bytes::<WorkspaceLayout, rkyv::rancor::Error>(&aligned)
                .expect("deserialization should succeed");

        // Verify values match
        assert_eq!(
            deserialized.total_size, layout.total_size,
            "total_size mismatch: expected {}, got {}",
            layout.total_size, deserialized.total_size
        );
        assert_eq!(deserialized.alignment, layout.alignment);
        assert_eq!(deserialized.regions.len(), layout.regions.len());

        // Check first region
        if let Some(region) = deserialized.regions.first() {
            let original = layout.regions.first().unwrap();
            assert_eq!(region.name, original.name);
            assert_eq!(region.offset, original.offset);
            assert_eq!(
                region.size,
                original.size,
                "region size mismatch: expected {} bytes, got {} bytes ({}× reduction)",
                original.size,
                region.size,
                original.size / region.size.max(1)
            );
            assert_eq!(region.alignment, original.alignment);
        }
    }
}
