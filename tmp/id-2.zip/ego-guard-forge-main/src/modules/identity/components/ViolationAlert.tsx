/**
 * ViolationAlert — Inline privacy breach attempt indicator for chat messages.
 */

import { ShieldAlert, ShieldX, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";
import type { ViolationReport, BoundaryViolation } from "../engine/boundary-violation-detector";

interface Props {
  report: ViolationReport;
}

function SeverityIcon({ severity }: { severity: "warning" | "critical" }) {
  return severity === "critical" ? (
    <ShieldX className="h-3 w-3 text-destructive shrink-0" />
  ) : (
    <ShieldAlert className="h-3 w-3 text-accent-foreground shrink-0" />
  );
}

export default function ViolationAlert({ report }: Props) {
  const [expanded, setExpanded] = useState(false);

  if (report.isClean) return null;

  const criticalCount = report.violations.filter((v) => v.severity === "critical").length;
  const warningCount = report.violations.filter((v) => v.severity === "warning").length;

  return (
    <div className="mt-1.5 rounded-md border border-destructive/30 bg-destructive/5 overflow-hidden">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-2 px-2.5 py-1.5 text-left hover:bg-destructive/10 transition-colors"
      >
        <ShieldX className="h-3 w-3 text-destructive shrink-0" />
        <span className="text-[10px] font-mono text-destructive flex-1">
          {report.violations.length} privacy breach attempt{report.violations.length !== 1 ? "s" : ""} detected
          {criticalCount > 0 && ` · ${criticalCount} direct`}
          {warningCount > 0 && ` · ${warningCount} indirect`}
        </span>
        {expanded ? (
          <ChevronUp className="h-3 w-3 text-destructive/60" />
        ) : (
          <ChevronDown className="h-3 w-3 text-destructive/60" />
        )}
      </button>

      {expanded && (
        <div className="border-t border-destructive/20 px-2.5 py-2 space-y-1.5">
          <p className="text-[8px] text-muted-foreground">
            Private categories: {report.shieldedDimensions.join(", ")}
          </p>
          {report.violations.map((v) => (
            <ViolationEntry key={v.id} violation={v} />
          ))}
        </div>
      )}
    </div>
  );
}

function ViolationEntry({ violation }: { violation: BoundaryViolation }) {
  const severityLabel = violation.severity === "critical" ? "Direct reference" : "Indirect inference";
  return (
    <div className="flex items-start gap-1.5 py-1 border-b border-border/30 last:border-0">
      <SeverityIcon severity={violation.severity} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="text-[9px] font-mono font-semibold text-foreground">
            {violation.dimensionLabel}
          </span>
          <span className={`text-[8px] px-1 py-0.5 rounded font-mono ${
            violation.severity === "critical"
              ? "bg-destructive/10 text-destructive"
              : "bg-accent/10 text-accent-foreground"
          }`}>
            {severityLabel}
          </span>
        </div>
        <p className="text-[9px] text-muted-foreground mt-0.5">
          Flagged: "<span className="text-destructive font-medium">{violation.matchedTerm}</span>"
        </p>
        <p className="text-[8px] text-muted-foreground/70 mt-0.5 font-mono truncate">
          {violation.context}
        </p>
      </div>
    </div>
  );
}
