/**
 * MobileBottomNav — PWA-optimized bottom navigation bar.
 * Only visible on mobile (< md breakpoint). Mirrors core sidebar items.
 */

import { useNavigate, useLocation } from "react-router-dom";
import { Home, Fingerprint } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface NavItem {
  label: string;
  icon: React.ElementType;
  path: string;
}

const NAV_ITEMS: NavItem[] = [
  { label: "Home", icon: Home, path: "/" },
  { label: "My Space", icon: Fingerprint, path: "/identity" },
];

export default function MobileBottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { profile } = useAuth();

  const isActive = (path: string) =>
    path === "/"
      ? location.pathname === "/"
      : path !== "#" && location.pathname.startsWith(path.split("#")[0]);

  return (
    <nav
      className="fixed bottom-0 inset-x-0 z-50 md:hidden border-t border-border/50 backdrop-blur-xl"
      style={{
        background: "hsl(var(--background) / 0.92)",
        paddingBottom: "env(safe-area-inset-bottom, 0px)",
      }}
    >
      <div className="flex items-stretch justify-around h-14">
        {NAV_ITEMS.map((item) => {
          const active = isActive(item.path);
          return (
            <button
              key={item.label}
              onClick={() => item.path !== "#" && navigate(item.path)}
              className="flex-1 flex flex-col items-center justify-center gap-0.5 transition-colors duration-200"
              style={{
                color: active
                  ? "hsl(var(--primary))"
                  : "hsl(var(--muted-foreground) / 0.5)",
              }}
            >
              {/* Show avatar for My Space if logged in */}
              {item.label === "My Space" && profile?.avatarUrl ? (
                <img
                  src={profile.avatarUrl}
                  alt=""
                  className="w-5 h-5 rounded-full object-cover"
                  style={{
                    border: active ? "1.5px solid hsl(var(--primary))" : "1.5px solid transparent",
                  }}
                />
              ) : (
                <item.icon className="w-5 h-5" strokeWidth={1.5} />
              )}
              <span className="text-[10px] font-medium leading-none">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
