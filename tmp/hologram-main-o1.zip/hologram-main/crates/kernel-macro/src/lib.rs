//! Procedural macros for hologram kernel development.
//!
//! Simplifies creating external kernels by auto-generating VTable boilerplate.

use proc_macro::TokenStream;
use quote::quote;
use syn::{parse_macro_input, ItemFn, ItemStruct};

/// Define a hologram kernel with automatic VTable generation.
///
/// # Example
///
/// ```rust
/// use hologram_kernel_macro::hologram_kernel;
///
/// #[hologram_kernel]
/// struct MyKernel;
///
/// #[hologram_kernel_impl]
/// impl MyKernel {
///     unsafe fn matmul(
///         a: *const f32, b: *const f32, c: *mut f32,
///         m: usize, k: usize, n: usize
///     ) -> i32 {
///         // Your optimized implementation
///         0
///     }
/// }
/// ```
#[proc_macro_attribute]
pub fn hologram_kernel(_attr: TokenStream, item: TokenStream) -> TokenStream {
    let input = parse_macro_input!(item as ItemStruct);

    let expanded = quote! {
        #input

        const KERNEL_MAGIC: u64 = 0x484F4C4F5F4B4552;
        const KERNEL_ABI_VERSION: u64 = 1;

        #[repr(C)]
        pub struct KernelVTable {
            pub magic: u64,
            pub version: u64,
            pub matmul: Option<unsafe extern "C" fn(*const f32, *const f32, *mut f32, usize, usize, usize) -> i32>,
            pub batch_matmul: Option<unsafe extern "C" fn(*const f32, *const f32, *mut f32, usize, usize, usize, usize) -> i32>,
            pub reserved: [Option<unsafe extern "C" fn()>; 16],
        }

        static mut VTABLE: KernelVTable = KernelVTable {
            magic: KERNEL_MAGIC,
            version: KERNEL_ABI_VERSION,
            matmul: None,
            batch_matmul: None,
            reserved: [None; 16],
        };

        #[no_mangle]
        pub extern "C" fn hologram_kernel_vtable() -> *const KernelVTable {
            unsafe { &VTABLE as *const _ }
        }
    };

    TokenStream::from(expanded)
}

/// Register a kernel implementation function.
///
/// Automatically wraps your function with `#[no_mangle]` and registers it in the VTable.
#[proc_macro_attribute]
pub fn kernel_fn(attr: TokenStream, item: TokenStream) -> TokenStream {
    let _ = attr;
    let input = parse_macro_input!(item as ItemFn);
    let fn_name = &input.sig.ident;
    let fn_name_str = fn_name.to_string();

    // Determine which VTable slot based on function name
    let vtable_slot = if fn_name_str.contains("matmul") && !fn_name_str.contains("batch") {
        quote! { matmul }
    } else if fn_name_str.contains("batch_matmul") {
        quote! { batch_matmul }
    } else {
        return syn::Error::new_spanned(
            fn_name,
            "Function name must contain 'matmul' or 'batch_matmul'",
        )
        .to_compile_error()
        .into();
    };

    let expanded = quote! {
        #[no_mangle]
        #input

        #[used]
        #[cfg_attr(target_os = "linux", link_section = ".init_array")]
        #[cfg_attr(target_os = "macos", link_section = "__DATA,__mod_init_func")]
        static REGISTER: unsafe extern "C" fn() = {
            unsafe extern "C" fn register() {
                VTABLE.#vtable_slot = Some(#fn_name);
            }
            register
        };
    };

    TokenStream::from(expanded)
}
