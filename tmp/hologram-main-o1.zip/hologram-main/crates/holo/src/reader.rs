//! Bundle readers for HOLB format.
//!
//! This module provides readers for parsing `.holb` files with
//! support for both V1 and V2 formats.

// Allow casts in this module since we're working with file format offsets
// that are designed for 64-bit but safe for practical file sizes.
#![allow(clippy::cast_possible_truncation)]

use crate::error::HoloError;
use crate::format::{crc32, detect_holb_version, HolbHeader, HolbHeaderV2};
use crate::layer_header::{LayerHeader, LayerHeaderSection};
use crate::section::{deserialize_sections_table, SectionTableEntry};
use crate::Result;

// Import trait for `from_bytes` method
use crate::traits::FromEmbeddedSection as _;

/// Reader for unified bundles (HOLB V1/V2 format).
///
/// Provides zero-copy access to graph data, weights, and sections
/// in `.holb` files.
///
/// # Example
///
/// ```rust,no_run
/// use hologram_holo::reader::HolbReader;
///
/// let data: Vec<u8> = std::fs::read("model.holb").unwrap();
/// let reader = HolbReader::from_bytes(&data).unwrap();
///
/// println!("Version: {}", reader.version());
/// println!("Graph size: {} bytes", reader.graph().len());
///
/// if reader.has_sections() {
///     for entry in reader.sections() {
///         println!("Section: {}", entry.id);
///     }
/// }
/// ```
pub struct HolbReader<'a> {
    data: &'a [u8],
    version: u32,
    graph_offset: u64,
    graph_size: u64,
    weights_offset: u64,
    weights_size: u64,
    graph_checksum: u32,
    weights_checksum: u32,
    sections: Vec<SectionTableEntry>,
}

impl<'a> HolbReader<'a> {
    /// Create a reader from raw bytes.
    ///
    /// Automatically detects V1 or V2 format based on version field.
    ///
    /// # Errors
    /// Returns error if the data is not a valid HOLB bundle.
    pub fn from_bytes(data: &'a [u8]) -> Result<Self> {
        let version = detect_holb_version(data)?;

        match version {
            1 => Self::from_v1(data),
            2 => Self::from_v2(data),
            _ => Err(HoloError::unsupported_version(version)),
        }
    }

    /// Parse V1 format (no sections).
    fn from_v1(data: &'a [u8]) -> Result<Self> {
        let header = HolbHeader::from_bytes(data)?;
        header.validate()?;

        Ok(Self {
            data,
            version: 1,
            graph_offset: header.graph_offset,
            graph_size: header.graph_size,
            weights_offset: header.weights_offset,
            weights_size: header.weights_size,
            graph_checksum: header.graph_checksum,
            weights_checksum: header.weights_checksum,
            sections: Vec::new(),
        })
    }

    /// Parse V2 format (with sections).
    fn from_v2(data: &'a [u8]) -> Result<Self> {
        let header = HolbHeaderV2::from_bytes(data)?;
        header.validate()?;

        // Parse sections table if present
        let sections = if header.sections_count > 0 {
            let table_start = header.sections_table_offset as usize;
            let table_data = &data[table_start..];
            deserialize_sections_table(table_data, header.sections_count as usize)?
        } else {
            Vec::new()
        };

        Ok(Self {
            data,
            version: 2,
            graph_offset: header.graph_offset,
            graph_size: header.graph_size,
            weights_offset: header.weights_offset,
            weights_size: header.weights_size,
            graph_checksum: header.graph_checksum,
            weights_checksum: header.weights_checksum,
            sections,
        })
    }

    /// Get the format version (1 or 2).
    #[must_use]
    pub const fn version(&self) -> u32 {
        self.version
    }

    /// Get the graph (`BackendPlan`) data.
    ///
    /// Returns a slice into the underlying buffer (zero-copy).
    #[must_use]
    pub fn graph(&self) -> &'a [u8] {
        let start = self.graph_offset as usize;
        let end = start + self.graph_size as usize;
        &self.data[start..end]
    }

    /// Get the weights data.
    ///
    /// Returns a slice into the underlying buffer (zero-copy).
    /// Returns an empty slice if no weights are present.
    #[must_use]
    pub fn weights(&self) -> &'a [u8] {
        if self.weights_size == 0 {
            return &[];
        }
        let start = self.weights_offset as usize;
        let end = start + self.weights_size as usize;
        &self.data[start..end]
    }

    /// Check if the bundle has weights.
    #[must_use]
    pub const fn has_weights(&self) -> bool {
        self.weights_size > 0
    }

    /// Check if the bundle has sections (V2 format).
    #[must_use]
    pub fn has_sections(&self) -> bool {
        !self.sections.is_empty()
    }

    /// Get the number of sections.
    #[must_use]
    pub fn sections_count(&self) -> usize {
        self.sections.len()
    }

    /// Get all section entries.
    #[must_use]
    pub fn sections(&self) -> &[SectionTableEntry] {
        &self.sections
    }

    /// Get a section by ID.
    ///
    /// Returns the section data as a slice (zero-copy).
    #[must_use]
    pub fn get_section(&self, id: &str) -> Option<&'a [u8]> {
        let entry = self.sections.iter().find(|e| e.id == id)?;
        let start = entry.offset as usize;
        let end = start + entry.size as usize;
        Some(&self.data[start..end])
    }

    /// Get a section entry by ID.
    #[must_use]
    pub fn get_section_entry(&self, id: &str) -> Option<&SectionTableEntry> {
        self.sections.iter().find(|e| e.id == id)
    }

    /// Verify the graph checksum.
    #[must_use]
    pub fn verify_graph_checksum(&self) -> bool {
        let graph = self.graph();
        crc32(graph) == self.graph_checksum
    }

    /// Verify the weights checksum.
    ///
    /// Returns `true` if no weights are present.
    #[must_use]
    pub fn verify_weights_checksum(&self) -> bool {
        if self.weights_size == 0 {
            return true;
        }
        let weights = self.weights();
        crc32(weights) == self.weights_checksum
    }

    /// Verify a section's checksum.
    ///
    /// Returns `None` if the section doesn't exist.
    #[must_use]
    pub fn verify_section_checksum(&self, id: &str) -> Option<bool> {
        let entry = self.sections.iter().find(|e| e.id == id)?;
        let data = self.get_section(id)?;
        Some(crc32(data) == entry.checksum)
    }

    /// Verify all checksums (graph, weights, and all sections).
    #[must_use]
    pub fn verify_all_checksums(&self) -> bool {
        if !self.verify_graph_checksum() {
            return false;
        }
        if !self.verify_weights_checksum() {
            return false;
        }
        for entry in &self.sections {
            let start = entry.offset as usize;
            let end = start + entry.size as usize;
            if end > self.data.len() {
                return false;
            }
            let data = &self.data[start..end];
            if crc32(data) != entry.checksum {
                return false;
            }
        }
        true
    }

    /// Get the layer header section if present.
    ///
    /// Returns `Ok(None)` if no layer header section exists.
    /// Returns `Err` if the section exists but cannot be deserialized.
    pub fn layer_header(&self) -> Result<Option<LayerHeader>> {
        let Some(data) = self.get_section(LayerHeaderSection::SECTION_ID) else {
            return Ok(None);
        };
        let section = LayerHeaderSection::from_bytes(data)?;
        Ok(Some(section.into_header()))
    }

    // ========================================================================
    // Weight Index Methods
    // ========================================================================

    /// Get the weight index section if present.
    ///
    /// Returns `Ok(None)` if no weight index section exists.
    /// Returns `Err` if the section exists but cannot be deserialized.
    pub fn weight_index(&self) -> Result<Option<crate::weight_index::WeightIndexSection>> {
        use crate::traits::FromEmbeddedSection;

        let Some(data) = self.get_section(crate::weight_index::WeightIndexSection::SECTION_ID)
        else {
            return Ok(None);
        };
        let section = crate::weight_index::WeightIndexSection::from_bytes(data)?;
        Ok(Some(section))
    }

    /// Check if weights are compressed.
    ///
    /// Returns `false` if no weight index exists or weights are uncompressed.
    #[must_use]
    pub fn is_weights_compressed(&self) -> bool {
        self.weight_index()
            .ok()
            .flatten()
            .is_some_and(|idx| idx.is_compressed())
    }

    /// Get tensor metadata by name.
    ///
    /// Returns `Ok(None)` if no weight index exists or tensor is not found.
    pub fn get_tensor_metadata(
        &self,
        name: &str,
    ) -> Result<Option<crate::weight_types::TensorMetadata>> {
        let Some(index) = self.weight_index()? else {
            return Ok(None);
        };
        Ok(index.get_tensor(name).cloned())
    }

    /// Get all tensor names from the weight index.
    ///
    /// Returns an empty Vec if no weight index exists.
    pub fn tensor_names(&self) -> Result<Vec<String>> {
        let Some(index) = self.weight_index()? else {
            return Ok(Vec::new());
        };
        Ok(index.tensor_names().into_iter().map(String::from).collect())
    }

    /// Get tensor bytes zero-copy (uncompressed weights only).
    ///
    /// Returns `Ok(None)` if no weight index exists or tensor is not found.
    /// Returns `Err` if weights are compressed (use `decompress_tensor` instead).
    pub fn get_tensor(&self, name: &str) -> Result<Option<&'a [u8]>> {
        let Some(index) = self.weight_index()? else {
            return Ok(None);
        };

        // Check if compressed
        if index.is_compressed() {
            return Err(HoloError::compressed_weights_require_decompression());
        }

        let Some(tensor) = index.get_tensor(name) else {
            return Ok(None);
        };

        let weights = self.weights();
        let start = tensor.offset as usize;
        let end = start + tensor.size as usize;

        if end > weights.len() {
            return Err(HoloError::tensor_bounds_invalid(
                &tensor.name,
                start,
                tensor.size as usize,
                weights.len(),
            ));
        }

        Ok(Some(&weights[start..end]))
    }

    /// Decompress and return a specific tensor's bytes.
    ///
    /// For uncompressed weights, this copies the tensor data.
    /// Returns `Ok(None)` if no weight index exists or tensor is not found.
    pub fn decompress_tensor(&self, name: &str) -> Result<Option<Vec<u8>>> {
        let Some(index) = self.weight_index()? else {
            return Ok(None);
        };

        let Some(tensor) = index.get_tensor(name) else {
            return Ok(None);
        };

        let weights = self.weights();

        match &index.compression {
            Some(comp) if comp.algorithm != crate::compression::CompressionAlgorithm::None => {
                // Decompress full weights, then extract tensor
                let decompressed = crate::compression::decompress_weights(weights, comp)?;
                let start = tensor.offset as usize;
                let end = start + tensor.size as usize;

                if end > decompressed.len() {
                    return Err(HoloError::tensor_bounds_invalid(
                        &tensor.name,
                        start,
                        tensor.size as usize,
                        decompressed.len(),
                    ));
                }

                Ok(Some(decompressed[start..end].to_vec()))
            }
            _ => {
                // No compression - just copy
                let start = tensor.offset as usize;
                let end = start + tensor.size as usize;

                if end > weights.len() {
                    return Err(HoloError::tensor_bounds_invalid(
                        &tensor.name,
                        start,
                        tensor.size as usize,
                        weights.len(),
                    ));
                }

                Ok(Some(weights[start..end].to_vec()))
            }
        }
    }

    /// Decompress all weights.
    ///
    /// For uncompressed weights, this copies the entire weights blob.
    pub fn decompress_weights(&self) -> Result<Vec<u8>> {
        let weights = self.weights();

        let index = self.weight_index()?;
        match index.and_then(|i| i.compression) {
            Some(comp) if comp.algorithm != crate::compression::CompressionAlgorithm::None => {
                crate::compression::decompress_weights(weights, &comp)
            }
            _ => Ok(weights.to_vec()),
        }
    }

    /// Verify a specific tensor's checksum.
    ///
    /// Returns `Ok(None)` if no weight index exists or tensor is not found.
    pub fn verify_tensor_checksum(&self, name: &str) -> Result<Option<bool>> {
        let Some(index) = self.weight_index()? else {
            return Ok(None);
        };

        let Some(tensor) = index.get_tensor(name) else {
            return Ok(None);
        };

        // For compressed weights, need to decompress first
        let data = if index.is_compressed() {
            match self.decompress_tensor(name)? {
                Some(d) => d,
                None => return Ok(None),
            }
        } else {
            match self.get_tensor(name)? {
                Some(d) => d.to_vec(),
                None => return Ok(None),
            }
        };

        Ok(Some(crc32(&data) == tensor.checksum))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::writer::HolbWriter;

    #[test]
    fn test_reader_v1_graph_only() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1, 2, 3, 4, 5]);

        let bundle = writer.build().unwrap();
        let reader = HolbReader::from_bytes(&bundle).unwrap();

        assert_eq!(reader.version(), 1);
        assert_eq!(reader.graph(), &[1, 2, 3, 4, 5]);
        assert!(!reader.has_weights());
        assert!(!reader.has_sections());
    }

    #[test]
    fn test_reader_v1_with_weights() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1, 2, 3]);
        writer.set_weights(&[10, 20, 30, 40]);

        let bundle = writer.build().unwrap();
        let reader = HolbReader::from_bytes(&bundle).unwrap();

        assert_eq!(reader.version(), 1);
        assert_eq!(reader.graph(), &[1, 2, 3]);
        assert!(reader.has_weights());
        assert_eq!(reader.weights(), &[10, 20, 30, 40]);
    }

    #[test]
    fn test_reader_v2_with_sections() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1, 2, 3, 4]);
        writer.add_raw_section("vocab", "text/plain", b"hello");
        writer.add_raw_section("config", "application/json", b"{}");

        let bundle = writer.build().unwrap();
        let reader = HolbReader::from_bytes(&bundle).unwrap();

        assert_eq!(reader.version(), 2);
        assert!(reader.has_sections());
        assert_eq!(reader.sections_count(), 2);

        let vocab = reader.get_section("vocab").unwrap();
        assert_eq!(vocab, b"hello");

        let config = reader.get_section("config").unwrap();
        assert_eq!(config, b"{}");

        let missing = reader.get_section("missing");
        assert!(missing.is_none());
    }

    #[test]
    fn test_reader_v2_with_weights_and_sections() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1, 2]);
        writer.add_raw_section("data", "application/octet-stream", &[100, 200]);
        writer.set_weights(&[50, 60, 70]);

        let bundle = writer.build().unwrap();
        let reader = HolbReader::from_bytes(&bundle).unwrap();

        assert_eq!(reader.version(), 2);
        assert!(reader.has_sections());
        assert!(reader.has_weights());

        assert_eq!(reader.graph(), &[1, 2]);
        assert_eq!(reader.weights(), &[50, 60, 70]);
        assert_eq!(reader.get_section("data").unwrap(), &[100, 200]);
    }

    #[test]
    fn test_reader_verify_checksums() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1, 2, 3]);
        writer.set_weights(&[4, 5, 6]);
        writer.add_raw_section("test", "text/plain", b"data");

        let bundle = writer.build().unwrap();
        let reader = HolbReader::from_bytes(&bundle).unwrap();

        assert!(reader.verify_graph_checksum());
        assert!(reader.verify_weights_checksum());
        assert!(reader.verify_section_checksum("test").unwrap());
        assert!(reader.verify_all_checksums());
    }

    #[test]
    fn test_reader_section_entries() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1]);
        writer.add_raw_section("vocab", "text/plain", b"tokens");

        let bundle = writer.build().unwrap();
        let reader = HolbReader::from_bytes(&bundle).unwrap();

        let entry = reader.get_section_entry("vocab").unwrap();
        assert_eq!(entry.id, "vocab");
        assert_eq!(entry.content_type, "text/plain");
        assert_eq!(entry.size, 6); // "tokens"
    }

    #[test]
    fn test_reader_invalid_magic() {
        let bad_data = vec![b'J', b'U', b'N', b'K', 1, 0, 0, 0];
        let result = HolbReader::from_bytes(&bad_data);
        assert!(result.is_err());
    }

    #[test]
    fn test_reader_unsupported_version() {
        let mut data = vec![0u8; 64];
        data[0..4].copy_from_slice(b"HOLB");
        data[4..8].copy_from_slice(&99u32.to_le_bytes()); // Invalid version

        let result = HolbReader::from_bytes(&data);
        assert!(result.is_err());
    }

    #[test]
    fn test_reader_empty_weights() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1, 2, 3]);

        let bundle = writer.build().unwrap();
        let reader = HolbReader::from_bytes(&bundle).unwrap();

        assert!(!reader.has_weights());
        assert!(reader.weights().is_empty());
        assert!(reader.verify_weights_checksum()); // Should return true for empty
    }

    #[test]
    fn test_reader_sections_list() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1]);
        writer.add_raw_section("a", "x", b"1");
        writer.add_raw_section("b", "y", b"2");
        writer.add_raw_section("c", "z", b"3");

        let bundle = writer.build().unwrap();
        let reader = HolbReader::from_bytes(&bundle).unwrap();

        let sections = reader.sections();
        assert_eq!(sections.len(), 3);
        assert_eq!(sections[0].id, "a");
        assert_eq!(sections[1].id, "b");
        assert_eq!(sections[2].id, "c");
    }

    #[test]
    fn test_reader_verify_section_checksum_missing() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1]);

        let bundle = writer.build().unwrap();
        let reader = HolbReader::from_bytes(&bundle).unwrap();

        assert!(reader.verify_section_checksum("missing").is_none());
    }
}
