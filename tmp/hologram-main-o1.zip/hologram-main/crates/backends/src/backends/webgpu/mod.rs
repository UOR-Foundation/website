//! WebGPU backend implementation (skeleton).
//!
//! This module provides a skeleton WebGPU backend for cross-platform GPU execution.
//! The actual WebGPU implementation is planned for a future sprint.
//!
//! # Architecture
//!
//! The WebGPU backend will:
//! - Work across browsers (Chrome, Firefox, Safari) and native (wgpu)
//! - Use WGSL shaders for compute pipelines
//! - Allocate GPUBuffer for data storage
//! - Execute ISA operations as WebGPU compute dispatches
//!
//! # WebGPU vs Other GPU Backends
//!
//! | Feature | CUDA | Metal | WebGPU |
//! |---------|------|-------|--------|
//! | Platform | NVIDIA only | Apple only | Cross-platform |
//! | Language | CUDA C/PTX | MSL | WGSL |
//! | Browser | No | No | Yes |
//! | Native | Yes | Yes | Yes (via wgpu) |
//!
//! # Current Status
//!
//! This is a skeleton implementation. All methods return `NotImplemented` errors.
//! The structure demonstrates the intended API for WebGPU execution.
//!
//! # Usage (Conceptual)
//!
//! ```rust,ignore
//! use hologram_backend::{Backend, webgpu::WebGpuBackend};
//!
//! // In browser (via wasm-bindgen)
//! let backend = WebGpuBackend::new().await?;
//!
//! // In native (via wgpu)
//! let backend = WebGpuBackend::new_native()?;
//!
//! backend.execute_plan(&plan, &[&input], &mut [&mut output])?;
//! ```
//!
//! # WGSL Shader Generation
//!
//! ISA operations will be compiled to WGSL compute shaders:
//!
//! ```wgsl
//! @group(0) @binding(0) var<storage, read> input: array<f32>;
//! @group(0) @binding(1) var<storage, read_write> output: array<f32>;
//!
//! @compute @workgroup_size(256)
//! fn main(@builtin(global_invocation_id) id: vec3<u32>) {
//!     let idx = id.x;
//!     output[idx] = max(input[idx], 0.0); // ReLU
//! }
//! ```

use hologram_holo::BackendPlan;

use super::gpu::{GpuBackend, GpuBuffer, GpuDevice};
use super::Backend;
use crate::types::{BackendCapabilities, BackendError, BackendType, Result};

/// WebGPU backend for cross-platform GPU execution (skeleton).
///
/// This backend will execute ISA plans using WebGPU, which works both
/// in browsers (via the WebGPU API) and natively (via wgpu-rs).
///
/// Currently a skeleton with stub implementations.
pub struct WebGpuBackend {
    capabilities: BackendCapabilities,
    current_device: Option<GpuDevice>,
}

impl WebGpuBackend {
    /// Create a new WebGPU backend.
    ///
    /// # Errors
    ///
    /// Returns error if WebGPU is not available (currently always succeeds
    /// as this is a skeleton).
    ///
    /// # Note
    ///
    /// In a real implementation, this would be async since WebGPU
    /// device/adapter acquisition is asynchronous.
    pub fn new() -> Result<Self> {
        Ok(Self {
            capabilities: BackendCapabilities {
                backend_type: BackendType::WebGpu,
                vector_width: 1,          // WebGPU compute shaders, not SIMD lanes
                l1_cache_size: 16 * 1024, // Varies by GPU
                l2_cache_size: 4 * 1024 * 1024, // Varies by GPU
                has_fma: true,            // Most GPUs support FMA
                has_sha: false,           // No hardware SHA in WebGPU
                has_aes: false,           // No hardware AES in WebGPU
            },
            current_device: None,
        })
    }

    /// Check if WebGPU is available on this system.
    ///
    /// # Returns
    ///
    /// Currently always returns `false` (skeleton implementation).
    /// In a real implementation, would check for WebGPU support.
    #[must_use]
    pub fn is_available() -> bool {
        // Skeleton: would check for WebGPU/wgpu availability
        // Browser: navigator.gpu !== undefined
        // Native: wgpu::Instance::new() succeeds
        false
    }

    /// Get the WGSL shader limits for the current device.
    ///
    /// WebGPU has various limits that affect shader generation:
    /// - `max_compute_workgroup_size_x`: Typically 256-1024
    /// - `max_storage_buffer_binding_size`: Typically 128MB-2GB
    /// - `max_buffer_size`: Typically 256MB-2GB
    #[must_use]
    pub fn shader_limits(&self) -> WebGpuLimits {
        WebGpuLimits::default()
    }
}

impl Default for WebGpuBackend {
    fn default() -> Self {
        Self::new().expect("WebGPU backend creation should not fail in skeleton")
    }
}

impl Backend for WebGpuBackend {
    fn backend_type(&self) -> BackendType {
        BackendType::WebGpu
    }

    fn execute_plan(
        &self,
        _plan: &BackendPlan,
        _inputs: &[&[u8]],
        _outputs: &mut [&mut [u8]],
    ) -> Result<()> {
        Err(BackendError::NotImplemented {
            feature: "WebGPU plan execution".into(),
        })
    }

    fn execute_plan_with_layers(
        &self,
        _plan: &BackendPlan,
        _inputs: &[&[u8]],
        _outputs: &mut [&mut [u8]],
        _layer_executor: super::LayerExecutorFn<'_>,
    ) -> Result<()> {
        Err(BackendError::NotImplemented {
            feature: "WebGPU plan execution with layers".into(),
        })
    }

    fn capabilities(&self) -> &BackendCapabilities {
        &self.capabilities
    }
}

impl GpuBackend for WebGpuBackend {
    fn enumerate_devices(&self) -> Result<Vec<GpuDevice>> {
        // Skeleton: would call wgpu::Instance::enumerate_adapters()
        Err(BackendError::NotImplemented {
            feature: "WebGPU device enumeration".into(),
        })
    }

    fn select_device(&mut self, _device_index: u32) -> Result<()> {
        Err(BackendError::NotImplemented {
            feature: "WebGPU device selection".into(),
        })
    }

    fn current_device(&self) -> Option<&GpuDevice> {
        self.current_device.as_ref()
    }

    fn allocate(&mut self, _size: usize) -> Result<GpuBuffer> {
        // Skeleton: would call device.create_buffer()
        Err(BackendError::NotImplemented {
            feature: "WebGPU buffer allocation".into(),
        })
    }

    fn free(&mut self, _buffer: GpuBuffer) -> Result<()> {
        // Skeleton: WebGPU buffers are reference-counted
        Err(BackendError::NotImplemented {
            feature: "WebGPU buffer free".into(),
        })
    }

    fn upload(&mut self, _dst: GpuBuffer, _src: &[u8]) -> Result<()> {
        // Skeleton: would call queue.write_buffer()
        Err(BackendError::NotImplemented {
            feature: "WebGPU buffer upload".into(),
        })
    }

    fn download(&self, _src: GpuBuffer, _dst: &mut [u8]) -> Result<()> {
        // Skeleton: would use buffer.map_async() + get_mapped_range()
        Err(BackendError::NotImplemented {
            feature: "WebGPU buffer download".into(),
        })
    }

    fn synchronize(&self) -> Result<()> {
        // Skeleton: would call device.poll(Maintain::Wait)
        Err(BackendError::NotImplemented {
            feature: "WebGPU synchronization".into(),
        })
    }
}

/// WebGPU shader and device limits.
///
/// These limits affect how ISA operations are compiled to WGSL shaders
/// and how buffers are allocated.
#[derive(Debug, Clone, Copy)]
pub struct WebGpuLimits {
    /// Maximum workgroup size in X dimension (typically 256-1024)
    pub max_workgroup_size_x: u32,
    /// Maximum workgroup size in Y dimension
    pub max_workgroup_size_y: u32,
    /// Maximum workgroup size in Z dimension
    pub max_workgroup_size_z: u32,
    /// Maximum total invocations per workgroup
    pub max_workgroup_invocations: u32,
    /// Maximum storage buffer binding size in bytes
    pub max_storage_buffer_size: u64,
    /// Maximum uniform buffer binding size in bytes
    pub max_uniform_buffer_size: u32,
    /// Maximum buffer size in bytes
    pub max_buffer_size: u64,
    /// Maximum compute workgroups per dimension
    pub max_workgroups_per_dimension: u32,
}

impl Default for WebGpuLimits {
    fn default() -> Self {
        // Conservative defaults based on WebGPU spec minimums
        Self {
            max_workgroup_size_x: 256,
            max_workgroup_size_y: 256,
            max_workgroup_size_z: 64,
            max_workgroup_invocations: 256,
            max_storage_buffer_size: 128 * 1024 * 1024, // 128 MB
            max_uniform_buffer_size: 64 * 1024,         // 64 KB
            max_buffer_size: 256 * 1024 * 1024,         // 256 MB
            max_workgroups_per_dimension: 65535,
        }
    }
}

impl WebGpuLimits {
    /// Check if a buffer size fits within WebGPU limits.
    #[must_use]
    pub fn buffer_fits(&self, size: usize) -> bool {
        size as u64 <= self.max_buffer_size
    }

    /// Calculate optimal workgroup size for a given element count.
    ///
    /// Returns `(workgroup_size, num_workgroups)` for a 1D dispatch.
    #[must_use]
    #[allow(clippy::cast_possible_truncation)] // Intentional: WebGPU element counts fit in u32
    pub fn optimal_dispatch_1d(&self, element_count: usize) -> (u32, u32) {
        let workgroup_size = self.max_workgroup_size_x.min(256);
        let element_count_u32 = element_count as u32;
        let num_workgroups = element_count_u32.div_ceil(workgroup_size);
        (
            workgroup_size,
            num_workgroups.min(self.max_workgroups_per_dimension),
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_webgpu_backend_creation() {
        let backend = WebGpuBackend::new().unwrap();
        assert_eq!(backend.backend_type(), BackendType::WebGpu);
    }

    #[test]
    fn test_webgpu_backend_default() {
        let backend = WebGpuBackend::default();
        assert_eq!(backend.backend_type(), BackendType::WebGpu);
    }

    #[test]
    fn test_webgpu_is_available() {
        // Skeleton always returns false
        assert!(!WebGpuBackend::is_available());
    }

    #[test]
    fn test_webgpu_capabilities() {
        let backend = WebGpuBackend::new().unwrap();
        let caps = backend.capabilities();
        assert_eq!(caps.backend_type, BackendType::WebGpu);
        assert!(caps.has_fma); // Most GPUs support FMA
    }

    #[test]
    fn test_webgpu_shader_limits() {
        let backend = WebGpuBackend::new().unwrap();
        let limits = backend.shader_limits();

        assert!(limits.max_workgroup_size_x >= 256);
        assert!(limits.max_storage_buffer_size >= 128 * 1024 * 1024);
    }

    #[test]
    fn test_webgpu_execute_returns_not_implemented() {
        use hologram_holo::PlanMetadata;

        let backend = WebGpuBackend::new().unwrap();
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        let result = backend.execute_plan(&plan, &[], &mut []);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_webgpu_enumerate_returns_not_implemented() {
        let backend = WebGpuBackend::new().unwrap();
        let result = backend.enumerate_devices();
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_webgpu_select_device_returns_not_implemented() {
        let mut backend = WebGpuBackend::new().unwrap();
        let result = backend.select_device(0);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_webgpu_current_device_initially_none() {
        let backend = WebGpuBackend::new().unwrap();
        assert!(backend.current_device().is_none());
    }

    #[test]
    fn test_webgpu_allocate_returns_not_implemented() {
        let mut backend = WebGpuBackend::new().unwrap();
        let result = backend.allocate(1024);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_webgpu_free_returns_not_implemented() {
        let mut backend = WebGpuBackend::new().unwrap();
        let buffer = GpuBuffer {
            handle: 0,
            size: 1024,
        };
        let result = backend.free(buffer);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_webgpu_upload_returns_not_implemented() {
        let mut backend = WebGpuBackend::new().unwrap();
        let buffer = GpuBuffer {
            handle: 0,
            size: 1024,
        };
        let data = [0u8; 1024];
        let result = backend.upload(buffer, &data);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_webgpu_download_returns_not_implemented() {
        let backend = WebGpuBackend::new().unwrap();
        let buffer = GpuBuffer {
            handle: 0,
            size: 1024,
        };
        let mut data = [0u8; 1024];
        let result = backend.download(buffer, &mut data);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_webgpu_synchronize_returns_not_implemented() {
        let backend = WebGpuBackend::new().unwrap();
        let result = backend.synchronize();
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_webgpu_limits_default() {
        let limits = WebGpuLimits::default();

        // Check spec minimums
        assert!(limits.max_workgroup_size_x >= 256);
        assert!(limits.max_workgroup_invocations >= 256);
        assert!(limits.max_uniform_buffer_size >= 64 * 1024);
    }

    #[test]
    #[allow(clippy::cast_possible_truncation)] // Test values are small enough
    fn test_webgpu_limits_buffer_fits() {
        let limits = WebGpuLimits::default();

        // Small buffer should fit
        assert!(limits.buffer_fits(1024));

        // Buffer at limit should fit
        let max_buffer = limits.max_buffer_size as usize;
        assert!(limits.buffer_fits(max_buffer));

        // Buffer over limit should not fit
        assert!(!limits.buffer_fits(max_buffer.saturating_add(1)));
    }

    #[test]
    fn test_webgpu_optimal_dispatch_1d() {
        let limits = WebGpuLimits::default();

        // Small count
        let (wg_size, num_wg) = limits.optimal_dispatch_1d(100);
        assert_eq!(wg_size, 256);
        assert_eq!(num_wg, 1);

        // Larger count
        let (wg_size, num_wg) = limits.optimal_dispatch_1d(1000);
        assert_eq!(wg_size, 256);
        assert_eq!(num_wg, 4); // 1000 / 256 = 3.9, rounded up = 4

        // Exact multiple
        let (wg_size, num_wg) = limits.optimal_dispatch_1d(512);
        assert_eq!(wg_size, 256);
        assert_eq!(num_wg, 2);
    }
}
