//! Execution context for tracking runtime state during graph execution.
//!
//! This module provides [`ExecutionContext`] which centralizes all runtime
//! state tracking in a single cohesive structure. This replaces scattered
//! state like `workspace_tensor_sizes`, `shape_registry`, etc.
//!
//! # Design Benefits
//!
//! - **Single Source of Truth**: All tensor metadata in one place
//! - **Unified API**: Query tensor info regardless of buffer type
//! - **Better Debugging**: Easy to inspect full execution state
//! - **Type Safety**: BufferLocation enum prevents confusion
//!
//! # Example
//!
//! ```rust,ignore
//! use hologram_backend::core::context::{ExecutionContext, BufferLocation};
//!
//! let mut ctx = ExecutionContext::new();
//!
//! // Register tensor after operation
//! ctx.register_tensor(
//!     BufferLocation::Workspace(5),
//!     512,  // element_count
//!     Some(vec![1, 512, 1, 1]),  // shape
//!     DataType::Float32,
//! );
//!
//! // Query tensor metadata
//! if let Some(meta) = ctx.get_tensor(&BufferLocation::Workspace(5)) {
//!     println!("Tensor has {} elements", meta.element_count);
//! }
//! ```

use rustc_hash::FxHashMap;

/// Identifies a specific tensor by its storage location.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum BufferLocation {
    /// Input tensor with given index (0, 1, 2, ...)
    Input(usize),
    /// Workspace slot with given ID
    Workspace(usize),
    /// Output tensor with given index (0, 1, 2, ...)
    Output(usize),
    /// Constant buffer (typically read-only)
    Constant(usize),
    /// External constant buffer
    ExternalConstant(usize),
}

impl BufferLocation {
    /// Returns a human-readable string for debugging.
    pub fn display(&self) -> String {
        match self {
            BufferLocation::Input(id) => format!("Input({})", id),
            BufferLocation::Workspace(slot) => format!("Workspace({})", slot),
            BufferLocation::Output(id) => format!("Output({})", id),
            BufferLocation::Constant(id) => format!("Constant({})", id),
            BufferLocation::ExternalConstant(id) => format!("ExternalConstant({})", id),
        }
    }
}

/// Data type of a tensor.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DataType {
    /// 32-bit floating point (f32, 4 bytes per element)
    Float32,
    /// 16-bit floating point (f16, 2 bytes per element)
    Float16,
    /// 64-bit signed integer (i64, 8 bytes per element)
    Int64,
    /// 32-bit signed integer (i32, 4 bytes per element)
    Int32,
    /// 8-bit signed integer (i8, 1 byte per element)
    Int8,
    /// 8-bit unsigned integer (u8, 1 byte per element)
    UInt8,
    /// Boolean type (1 byte per element)
    Bool,
}

impl DataType {
    /// Returns the size in bytes of one element of this type.
    pub fn size_bytes(&self) -> usize {
        match self {
            DataType::Float32 => 4,
            DataType::Float16 => 2,
            DataType::Int64 => 8,
            DataType::Int32 => 4,
            DataType::Int8 => 1,
            DataType::UInt8 => 1,
            DataType::Bool => 1,
        }
    }
}

/// Metadata about a tensor at a specific point in execution.
#[derive(Debug, Clone)]
pub struct TensorMetadata {
    /// Total number of elements in the tensor.
    pub element_count: usize,

    /// Shape of the tensor (e.g., [batch, channels, height, width]).
    /// May be None if shape is not tracked.
    pub shape: Option<Vec<usize>>,

    /// Data type of tensor elements.
    pub dtype: DataType,

    /// Operation index that produced this tensor (for debugging).
    pub produced_by_op: Option<usize>,
}

impl TensorMetadata {
    /// Creates new tensor metadata.
    pub fn new(
        element_count: usize,
        shape: Option<Vec<usize>>,
        dtype: DataType,
    ) -> Self {
        Self {
            element_count,
            shape,
            dtype,
            produced_by_op: None,
        }
    }

    /// Creates metadata with producer operation tracking.
    pub fn with_producer(
        element_count: usize,
        shape: Option<Vec<usize>>,
        dtype: DataType,
        produced_by_op: usize,
    ) -> Self {
        Self {
            element_count,
            shape,
            dtype,
            produced_by_op: Some(produced_by_op),
        }
    }

    /// Returns the total size in bytes of this tensor.
    pub fn size_bytes(&self) -> usize {
        self.element_count * self.dtype.size_bytes()
    }
}

/// Execution context tracking all runtime state during graph execution.
///
/// This is the single source of truth for:
/// - Tensor element counts (actual runtime sizes, not allocation sizes)
/// - Tensor shapes (for debugging and validation)
/// - Data types
/// - Producer operation tracking
///
/// Replaces scattered state like:
/// - `workspace_tensor_sizes: FxHashMap<usize, usize>`
/// - `shape_registry: FxHashMap<usize, Vec<usize>>`
/// - Various other tracking maps
pub struct ExecutionContext {
    /// Map from buffer location to tensor metadata.
    tensors: FxHashMap<BufferLocation, TensorMetadata>,

    /// Current operation index being executed (for debugging).
    current_op_index: Option<usize>,
}

impl ExecutionContext {
    /// Creates a new empty execution context.
    pub fn new() -> Self {
        Self {
            tensors: FxHashMap::default(),
            current_op_index: None,
        }
    }

    /// Sets the current operation index (for tracking producers).
    pub fn set_current_op(&mut self, op_index: usize) {
        self.current_op_index = Some(op_index);
    }

    /// Clears the current operation index.
    pub fn clear_current_op(&mut self) {
        self.current_op_index = None;
    }

    /// Registers a tensor in the context.
    ///
    /// This should be called after an operation writes to a buffer.
    pub fn register_tensor(
        &mut self,
        location: BufferLocation,
        element_count: usize,
        shape: Option<Vec<usize>>,
        dtype: DataType,
    ) {
        let metadata = if let Some(op_idx) = self.current_op_index {
            TensorMetadata::with_producer(element_count, shape, dtype, op_idx)
        } else {
            TensorMetadata::new(element_count, shape, dtype)
        };

        self.tensors.insert(location, metadata);
    }

    /// Gets metadata for a tensor at the given location.
    pub fn get_tensor(&self, location: &BufferLocation) -> Option<&TensorMetadata> {
        self.tensors.get(location)
    }

    /// Gets the element count for a tensor, or None if not tracked.
    pub fn get_element_count(&self, location: &BufferLocation) -> Option<usize> {
        self.tensors.get(location).map(|meta| meta.element_count)
    }

    /// Gets the shape for a tensor, or None if not tracked.
    pub fn get_shape(&self, location: &BufferLocation) -> Option<&[usize]> {
        self.tensors
            .get(location)
            .and_then(|meta| meta.shape.as_deref())
    }

    /// Registers an input tensor shape (called at graph entry).
    pub fn register_input(
        &mut self,
        input_id: usize,
        shape: Vec<usize>,
        dtype: DataType,
    ) {
        let element_count = shape.iter().product();
        self.register_tensor(
            BufferLocation::Input(input_id),
            element_count,
            Some(shape),
            dtype,
        );
    }

    /// Builds a predecessor elements array for dim resolution.
    ///
    /// Given a list of input buffer references, returns a vector where
    /// each entry contains the element count of the corresponding input.
    ///
    /// This is used for resolving `DimExpr::PredecessorElementsDiv`.
    pub fn build_predecessor_elements(
        &self,
        input_refs: &[crate::plan::BufferRef],
    ) -> Vec<usize> {
        input_refs
            .iter()
            .map(|buffer_ref| {
                match buffer_ref {
                    crate::plan::BufferRef::Input(id) => {
                        let location = BufferLocation::Input(*id);
                        self.get_element_count(&location).unwrap_or(0)
                    }
                    crate::plan::BufferRef::Workspace(slot) => {
                        let location = BufferLocation::Workspace(*slot);
                        self.get_element_count(&location).unwrap_or(0)
                    }
                    crate::plan::BufferRef::Constant { size, .. } => {
                        // Constants: size is in bytes, divide by 4 for f32 element count
                        size / 4
                    }
                    crate::plan::BufferRef::ExternalConstant { size, .. } => {
                        // External constants: size is in bytes, divide by 4 for f32 element count
                        size / 4
                    }
                    crate::plan::BufferRef::Output(id) => {
                        // Outputs don't have predecessor sizes (they're outputs, not inputs)
                        let location = BufferLocation::Output(*id);
                        self.get_element_count(&location).unwrap_or(0)
                    }
                }
            })
            .collect()
    }

    /// Clears all tracked tensors (useful for resetting between executions).
    pub fn clear(&mut self) {
        self.tensors.clear();
        self.current_op_index = None;
    }

    /// Returns the number of tracked tensors.
    pub fn num_tensors(&self) -> usize {
        self.tensors.len()
    }

    /// Dumps all tracked tensors for debugging.
    pub fn dump_state(&self) -> String {
        let mut output = String::new();
        output.push_str("=== Execution Context State ===\n");

        if let Some(op_idx) = self.current_op_index {
            output.push_str(&format!("Current operation: OP[{}]\n", op_idx));
        }

        output.push_str(&format!("Tracked tensors: {}\n\n", self.tensors.len()));

        // Group by location type for cleaner output
        let mut inputs: Vec<_> = self.tensors.iter()
            .filter(|(loc, _)| matches!(loc, BufferLocation::Input(_)))
            .collect();
        inputs.sort_by_key(|(loc, _)| match loc {
            BufferLocation::Input(id) => *id,
            _ => 0,
        });

        let mut workspace: Vec<_> = self.tensors.iter()
            .filter(|(loc, _)| matches!(loc, BufferLocation::Workspace(_)))
            .collect();
        workspace.sort_by_key(|(loc, _)| match loc {
            BufferLocation::Workspace(slot) => *slot,
            _ => 0,
        });

        let mut outputs: Vec<_> = self.tensors.iter()
            .filter(|(loc, _)| matches!(loc, BufferLocation::Output(_)))
            .collect();
        outputs.sort_by_key(|(loc, _)| match loc {
            BufferLocation::Output(id) => *id,
            _ => 0,
        });

        if !inputs.is_empty() {
            output.push_str("Inputs:\n");
            for (loc, meta) in inputs {
                output.push_str(&format!(
                    "  {} - {} elements, shape={:?}, dtype={:?}\n",
                    loc.display(), meta.element_count, meta.shape, meta.dtype
                ));
            }
            output.push('\n');
        }

        if !workspace.is_empty() {
            output.push_str("Workspace:\n");
            for (loc, meta) in workspace {
                let producer = meta.produced_by_op
                    .map(|op| format!("OP[{}]", op))
                    .unwrap_or_else(|| "unknown".to_string());
                output.push_str(&format!(
                    "  {} - {} elements, shape={:?}, produced by {}\n",
                    loc.display(), meta.element_count, meta.shape, producer
                ));
            }
            output.push('\n');
        }

        if !outputs.is_empty() {
            output.push_str("Outputs:\n");
            for (loc, meta) in outputs {
                output.push_str(&format!(
                    "  {} - {} elements, shape={:?}\n",
                    loc.display(), meta.element_count, meta.shape
                ));
            }
        }

        output
    }
}

impl Default for ExecutionContext {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_buffer_location_display() {
        assert_eq!(BufferLocation::Input(0).display(), "Input(0)");
        assert_eq!(BufferLocation::Workspace(42).display(), "Workspace(42)");
        assert_eq!(BufferLocation::Output(1).display(), "Output(1)");
        assert_eq!(BufferLocation::Constant(5).display(), "Constant(5)");
    }

    #[test]
    fn test_data_type_size() {
        assert_eq!(DataType::Float32.size_bytes(), 4);
        assert_eq!(DataType::Float16.size_bytes(), 2);
        assert_eq!(DataType::Int64.size_bytes(), 8);
        assert_eq!(DataType::Int32.size_bytes(), 4);
        assert_eq!(DataType::Int8.size_bytes(), 1);
        assert_eq!(DataType::UInt8.size_bytes(), 1);
        assert_eq!(DataType::Bool.size_bytes(), 1);
    }

    #[test]
    fn test_tensor_metadata_size_bytes() {
        let meta = TensorMetadata::new(
            100,
            Some(vec![10, 10]),
            DataType::Float32,
        );
        assert_eq!(meta.size_bytes(), 400); // 100 elements * 4 bytes
    }

    #[test]
    fn test_execution_context_register_and_query() {
        let mut ctx = ExecutionContext::new();

        // Register a tensor
        ctx.register_tensor(
            BufferLocation::Workspace(5),
            512,
            Some(vec![1, 512, 1, 1]),
            DataType::Float32,
        );

        // Query it back
        let meta = ctx.get_tensor(&BufferLocation::Workspace(5)).unwrap();
        assert_eq!(meta.element_count, 512);
        assert_eq!(meta.shape.as_ref().unwrap(), &vec![1, 512, 1, 1]);
        assert_eq!(meta.dtype, DataType::Float32);
    }

    #[test]
    fn test_execution_context_with_producer() {
        let mut ctx = ExecutionContext::new();

        ctx.set_current_op(42);
        ctx.register_tensor(
            BufferLocation::Workspace(5),
            512,
            Some(vec![512]),
            DataType::Float32,
        );

        let meta = ctx.get_tensor(&BufferLocation::Workspace(5)).unwrap();
        assert_eq!(meta.produced_by_op, Some(42));
    }

    #[test]
    fn test_execution_context_get_element_count() {
        let mut ctx = ExecutionContext::new();

        ctx.register_tensor(
            BufferLocation::Workspace(7),
            262144,
            Some(vec![512, 512]),
            DataType::Float32,
        );

        assert_eq!(
            ctx.get_element_count(&BufferLocation::Workspace(7)),
            Some(262144)
        );
        assert_eq!(
            ctx.get_element_count(&BufferLocation::Workspace(99)),
            None
        );
    }

    #[test]
    fn test_execution_context_register_input() {
        let mut ctx = ExecutionContext::new();

        ctx.register_input(0, vec![1, 512], DataType::Int64);

        let meta = ctx.get_tensor(&BufferLocation::Input(0)).unwrap();
        assert_eq!(meta.element_count, 512); // 1 * 512
        assert_eq!(meta.shape.as_ref().unwrap(), &vec![1, 512]);
        assert_eq!(meta.dtype, DataType::Int64);
    }

    #[test]
    fn test_execution_context_clear() {
        let mut ctx = ExecutionContext::new();

        ctx.register_tensor(
            BufferLocation::Workspace(5),
            512,
            Some(vec![512]),
            DataType::Float32,
        );
        assert_eq!(ctx.num_tensors(), 1);

        ctx.clear();
        assert_eq!(ctx.num_tensors(), 0);
        assert!(ctx.get_tensor(&BufferLocation::Workspace(5)).is_none());
    }

    #[test]
    fn test_dump_state_formatting() {
        let mut ctx = ExecutionContext::new();

        ctx.register_input(0, vec![1, 512], DataType::Int64);

        ctx.set_current_op(6);
        ctx.register_tensor(
            BufferLocation::Workspace(5),
            512,
            Some(vec![512]),
            DataType::Float32,
        );

        let dump = ctx.dump_state();

        // Should contain key information
        assert!(dump.contains("Execution Context State"));
        assert!(dump.contains("Current operation: OP[6]"));
        assert!(dump.contains("Inputs:"));
        assert!(dump.contains("Input(0)"));
        assert!(dump.contains("Workspace:"));
        assert!(dump.contains("Workspace(5)"));
        assert!(dump.contains("produced by OP[6]"));
    }
}
