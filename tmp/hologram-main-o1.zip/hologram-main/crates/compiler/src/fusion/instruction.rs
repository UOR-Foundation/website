//! Instruction fusion pass (TASK-327).
//!
//! Detects producer→consumer pairs that can be replaced by a single fused
//! ISA instruction, eliminating intermediate buffers and dispatch overhead.
//!
//! Patterns detected:
//! - `MatMul -> Relu` → `MatMulRelu` (single dispatch, `ReLU` applied in writeback)
//! - `Add -> Sigmoid` → `AddSigmoid` (single pass: add + sigmoid per element)

use crate::graph::{CompileGraph, OpKind};

/// Fuse eligible instruction pairs into single fused operations.
///
/// Runs all instruction-level fusion patterns:
/// 1. `MatMul { m, k, n } -> Relu` becomes `MatMulRelu { m, k, n }`
/// 2. `Add -> Sigmoid` becomes `AddSigmoid`
pub fn instruction_fusion(graph: &mut CompileGraph) {
    let pairs = find_fusable_pairs(graph);

    for (first, second, fused_op) in pairs {
        if graph.get_node(first).is_none() || graph.get_node(second).is_none() {
            continue;
        }
        fuse_pair(graph, first, second, fused_op);
    }
}

/// Find all fusable instruction pairs.
///
/// A pair `(A, B)` is fusable when:
/// - A has exactly one successor (B)
/// - B has exactly one predecessor (A)
/// - The pair matches a known fusion pattern
fn find_fusable_pairs(graph: &CompileGraph) -> Vec<(u32, u32, OpKind)> {
    let mut pairs = Vec::new();

    for (id, node) in graph.nodes() {
        // Producer must have exactly one consumer
        let succs = graph.successors(id);
        if succs.len() != 1 {
            continue;
        }

        let next_id = succs[0];
        let Some(next_node) = graph.get_node(next_id) else {
            continue;
        };

        // Consumer must have exactly one producer from this pattern
        // (it may have other predecessors for binary ops like Add)
        match (&node.op, &next_node.op) {
            // MatMul -> Relu → MatMulRelu
            (OpKind::MatMul { m, k, n }, OpKind::Relu) => {
                let next_preds = graph.predecessors(next_id);
                if next_preds.len() == 1 && next_preds[0] == id {
                    pairs.push((
                        id,
                        next_id,
                        OpKind::MatMulRelu {
                            m: *m,
                            k: *k,
                            n: *n,
                        },
                    ));
                }
            }
            // Add -> Sigmoid → AddSigmoid
            (OpKind::Add, OpKind::Sigmoid) => {
                let next_preds = graph.predecessors(next_id);
                if next_preds.len() == 1 && next_preds[0] == id {
                    pairs.push((id, next_id, OpKind::AddSigmoid));
                }
            }
            _ => {}
        }
    }

    pairs
}

/// Replace a producer→consumer pair with a single fused operation.
///
/// The consumer node's op is replaced with the fused op, its predecessors
/// are rewired to the producer's predecessors, and the producer is removed.
fn fuse_pair(graph: &mut CompileGraph, first: u32, second: u32, fused_op: OpKind) {
    let first_preds = graph.predecessors(first);
    let name = format!(
        "fused:{:?}->{:?}",
        graph.get_node(first).unwrap().op,
        graph.get_node(second).unwrap().op
    );

    // Replace consumer's op with fused variant
    if let Some(node) = graph.get_node_mut(second) {
        node.op = fused_op;
        node.name = Some(name);
    }

    // Rewire: consumer's predecessor changes from first to first's predecessors
    for &pred in &first_preds {
        graph.replace_predecessor(second, first, pred);
    }

    // Remove the producer node
    graph.remove_node(first);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpNode, OperationGraph};

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    #[test]
    fn test_matmul_relu_fuses() {
        // Input(A) -> MatMul -> Relu -> Output
        // Input(B) --^
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32),
                OpNode::new(1, OpKind::Input, vec![4, 8], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul { m: 2, k: 4, n: 8 },
                    vec![2, 8],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Relu, vec![2, 8], DType::F32),
                OpNode::new(4, OpKind::Output, vec![2, 8], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3), (3, 4)],
        );

        let before = graph.topo_order().len();
        instruction_fusion(&mut graph);
        let after = graph.topo_order().len();

        // One node removed (MatMul), Relu becomes MatMulRelu
        assert_eq!(after, before - 1);

        let fused = graph.get_node(3).unwrap();
        assert_eq!(fused.op, OpKind::MatMulRelu { m: 2, k: 4, n: 8 });
    }

    #[test]
    fn test_add_sigmoid_fuses() {
        // Input(A) -> Add -> Sigmoid -> Output
        // Input(B) --^
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![1, 16], DType::F32),
                OpNode::new(1, OpKind::Input, vec![1, 16], DType::F32),
                OpNode::new(2, OpKind::Add, vec![1, 16], DType::F32),
                OpNode::new(3, OpKind::Sigmoid, vec![1, 16], DType::F32),
                OpNode::new(4, OpKind::Output, vec![1, 16], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3), (3, 4)],
        );

        let before = graph.topo_order().len();
        instruction_fusion(&mut graph);
        let after = graph.topo_order().len();

        assert_eq!(after, before - 1);

        let fused = graph.get_node(3).unwrap();
        assert_eq!(fused.op, OpKind::AddSigmoid);
    }

    #[test]
    fn test_multi_consumer_prevents_fusion() {
        // Input(A) -> MatMul -> Relu -> Output
        // Input(B) --^    \--> Output2
        // MatMul has 2 consumers, should NOT fuse
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32),
                OpNode::new(1, OpKind::Input, vec![4, 8], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul { m: 2, k: 4, n: 8 },
                    vec![2, 8],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Relu, vec![2, 8], DType::F32),
                OpNode::new(4, OpKind::Output, vec![2, 8], DType::F32),
                OpNode::new(5, OpKind::Output, vec![2, 8], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3), (3, 4), (2, 5)],
        );

        let before = graph.topo_order().len();
        instruction_fusion(&mut graph);
        assert_eq!(graph.topo_order().len(), before);
    }

    #[test]
    fn test_no_pattern_no_fusion() {
        // Input -> MatMul -> Sigmoid -> Output (not a fusable pattern)
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32),
                OpNode::new(1, OpKind::Input, vec![4, 8], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul { m: 2, k: 4, n: 8 },
                    vec![2, 8],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Sigmoid, vec![2, 8], DType::F32),
                OpNode::new(4, OpKind::Output, vec![2, 8], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3), (3, 4)],
        );

        let before = graph.topo_order().len();
        instruction_fusion(&mut graph);
        assert_eq!(graph.topo_order().len(), before);
    }

    #[test]
    fn test_empty_graph() {
        let mut graph = make_graph(vec![], vec![]);
        instruction_fusion(&mut graph);
        assert_eq!(graph.node_count(), 0);
    }
}
