import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useWasm, BOUNDARY_SIZE, R, WasmModule } from '../hooks/useWasm';
import { BoundaryWrapper, getBoundaryGrid, encodeStringToBoundary, decodeStringFromBoundary, getBoundaryStats, MutationType, createMutation } from '../services/wasmBoundary';
import { Grid3X3, Play, RotateCcw, Zap, Hash, Type, AlertCircle, Loader2, Timer, BarChart3 } from 'lucide-react';

// Benchmark result interface
interface BenchmarkResult {
  name: string;
  operations: number;
  totalMs: number;
  opsPerSec: number;
  avgNs: number;
}

// Run a benchmark and return results
function runBenchmark(
  name: string,
  iterations: number,
  fn: () => void
): BenchmarkResult {
  // Warmup
  for (let i = 0; i < Math.min(100, iterations / 10); i++) {
    fn();
  }

  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    fn();
  }
  const end = performance.now();

  const totalMs = end - start;
  const opsPerSec = (iterations / totalMs) * 1000;
  const avgNs = (totalMs / iterations) * 1_000_000;

  return { name, operations: iterations, totalMs, opsPerSec, avgNs };
}

// All benchmark functions
function runAllBenchmarks(wasm: WasmModule): BenchmarkResult[] {
  const results: BenchmarkResult[] = [];

  // 1. Cell creation
  results.push(runBenchmark('Cell creation', 100_000, () => {
    const cell = new wasm.Cell(Math.floor(Math.random() * BOUNDARY_SIZE));
    cell.free();
  }));

  // 2. Cell navigation (next/prev)
  const navCell = new wasm.Cell(0);
  results.push(runBenchmark('Cell.next()', 100_000, () => {
    const next = navCell.next();
    next.free();
  }));
  navCell.free();

  // 3. Cell offset
  const offsetCell = new wasm.Cell(6000);
  results.push(runBenchmark('Cell.offset()', 100_000, () => {
    const off = offsetCell.offset(Math.floor(Math.random() * 1000) - 500);
    off.free();
  }));
  offsetCell.free();

  // 4. Cell distance
  const cellA = new wasm.Cell(1000);
  const cellB = new wasm.Cell(8000);
  results.push(runBenchmark('Cell.distanceTo()', 100_000, () => {
    cellA.distanceTo(cellB);
  }));
  cellA.free();
  cellB.free();

  // 5. Res96 creation
  results.push(runBenchmark('Res96 creation', 100_000, () => {
    const res = new wasm.Res96(Math.floor(Math.random() * 96));
    res.free();
  }));

  // 6. Res96 arithmetic
  const res1 = new wasm.Res96(42);
  const res2 = new wasm.Res96(37);
  results.push(runBenchmark('Res96.add()', 100_000, () => {
    const sum = res1.add(res2);
    sum.free();
  }));

  results.push(runBenchmark('Res96.mul()', 100_000, () => {
    const prod = res1.mul(res2);
    prod.free();
  }));
  res1.free();
  res2.free();

  // 7. Boundary creation
  results.push(runBenchmark('ToroidalBoundary.newZero()', 1_000, () => {
    const b = wasm.ToroidalBoundary.newZero();
    b.free();
  }));

  // 8. Boundary get/set
  const boundary = wasm.ToroidalBoundary.newZero();
  const getCell = new wasm.Cell(5000);
  results.push(runBenchmark('Boundary.get()', 50_000, () => {
    const val = boundary.get(getCell);
    val.free();
  }));

  const setVal = new wasm.Res96(50);
  results.push(runBenchmark('Boundary.set()', 50_000, () => {
    boundary.set(getCell, setVal);
  }));
  setVal.free();
  getCell.free();

  // 9. Single mutation application
  results.push(runBenchmark('applyMutation (Set)', 10_000, () => {
    const mutation = wasm.MutationFactory.set(
      Math.floor(Math.random() * BOUNDARY_SIZE),
      Math.floor(Math.random() * 96)
    );
    boundary.applyMutation(mutation);
  }));

  results.push(runBenchmark('applyMutation (Add)', 10_000, () => {
    const mutation = wasm.MutationFactory.add(
      Math.floor(Math.random() * BOUNDARY_SIZE),
      Math.floor(Math.random() * 96)
    );
    boundary.applyMutation(mutation);
  }));

  // 10. Batch mutations (100 ops per batch)
  results.push(runBenchmark('applyBatch (100 mutations)', 1_000, () => {
    const mutations: string[] = [];
    for (let i = 0; i < 100; i++) {
      mutations.push(wasm.MutationFactory.set(
        Math.floor(Math.random() * BOUNDARY_SIZE),
        Math.floor(Math.random() * 96)
      ));
    }
    const batch = JSON.stringify(mutations.map(m => JSON.parse(m)));
    boundary.applyBatch(batch);
  }));

  // 11. Serialization
  results.push(runBenchmark('toUint8Array()', 1_000, () => {
    boundary.toUint8Array();
  }));

  const serialized = boundary.toUint8Array();
  results.push(runBenchmark('fromUint8Array()', 1_000, () => {
    const b = wasm.ToroidalBoundary.fromUint8Array(serialized);
    b.free();
  }));

  // 12. Budget calculation
  results.push(runBenchmark('totalBudget()', 10_000, () => {
    boundary.totalBudget();
  }));

  results.push(runBenchmark('signedBudget()', 10_000, () => {
    boundary.signedBudget();
  }));

  boundary.free();

  return results;
}

const GRID_SIZE = 16; // 16x16 = 256 cells visible
const CELL_DISPLAY_SIZE = 24;

const BoundaryDemo: React.FC = () => {
  const { module: wasm, loading, error, reload } = useWasm();

  const [boundary, setBoundary] = useState<BoundaryWrapper | null>(null);
  const [viewOffset, setViewOffset] = useState(0);
  const [inputText, setInputText] = useState('Hello, Categorical X!');
  const [selectedMutation, setSelectedMutation] = useState<MutationType>('set');
  const [mutationArgs, setMutationArgs] = useState<string>('0, 42');
  const [stats, setStats] = useState<{ totalBudget: bigint; signedBudget: bigint; nonZeroCount: number } | null>(null);
  const [benchmarkResults, setBenchmarkResults] = useState<BenchmarkResult[] | null>(null);
  const [benchmarkRunning, setBenchmarkRunning] = useState(false);

  // Initialize boundary when WASM loads
  useEffect(() => {
    if (wasm && !boundary) {
      const b = BoundaryWrapper.zero(wasm);
      setBoundary(b);
    }
  }, [wasm, boundary]);

  // Update stats when boundary changes
  const updateStats = useCallback(() => {
    if (boundary) {
      const s = getBoundaryStats(boundary);
      setStats({
        totalBudget: s.totalBudget,
        signedBudget: s.signedBudget,
        nonZeroCount: s.nonZeroCount
      });
    }
  }, [boundary]);

  useEffect(() => {
    updateStats();
  }, [updateStats]);

  // Get current grid view
  const grid = useMemo(() => {
    if (!boundary) return [];
    return getBoundaryGrid(boundary, viewOffset, GRID_SIZE, GRID_SIZE);
  }, [boundary, viewOffset]);

  const handleEncode = useCallback(() => {
    if (!wasm || !boundary) return;
    encodeStringToBoundary(wasm, boundary, inputText, viewOffset);
    updateStats();
    setBoundary(boundary); // Trigger re-render
  }, [wasm, boundary, inputText, viewOffset, updateStats]);

  const handleDecode = useCallback(() => {
    if (!boundary) return;
    const decoded = decodeStringFromBoundary(boundary, viewOffset, inputText.length || 20);
    setInputText(decoded);
  }, [boundary, viewOffset, inputText.length]);

  const handleClear = useCallback(() => {
    if (wasm) {
      boundary?.free();
      const b = BoundaryWrapper.zero(wasm);
      setBoundary(b);
      updateStats();
    }
  }, [wasm, boundary, updateStats]);

  const handleApplyMutation = useCallback(() => {
    if (!boundary) return;
    try {
      const args = mutationArgs.split(',').map(s => parseInt(s.trim(), 10));
      boundary.apply(selectedMutation, ...args);
      updateStats();
      setBoundary(boundary); // Trigger re-render
    } catch (e) {
      console.error('Mutation error:', e);
    }
  }, [boundary, selectedMutation, mutationArgs, updateStats]);

  const handleRandomFill = useCallback(() => {
    if (!boundary) return;
    const mutations = [];
    for (let i = 0; i < 100; i++) {
      const cell = Math.floor(Math.random() * BOUNDARY_SIZE);
      const value = Math.floor(Math.random() * R);
      mutations.push({ type: 'set' as MutationType, args: [cell, value] });
    }
    boundary.applyBatch(mutations);
    updateStats();
    setBoundary(boundary);
  }, [boundary, updateStats]);

  const handleRunBenchmarks = useCallback(() => {
    if (!wasm) return;
    setBenchmarkRunning(true);
    setBenchmarkResults(null);

    // Run benchmarks in a setTimeout to allow UI to update
    setTimeout(() => {
      const results = runAllBenchmarks(wasm);
      setBenchmarkResults(results);
      setBenchmarkRunning(false);
    }, 50);
  }, [wasm]);

  // Color mapping for cell values
  const getCellColor = (value: number): string => {
    if (value === 0) return 'bg-slate-900';
    const hue = (value / R) * 240; // Blue to cyan range
    const lightness = 30 + (value / R) * 40;
    return `hsl(${hue}, 70%, ${lightness}%)`;
  };

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="w-12 h-12 text-blue-400 animate-spin mx-auto" />
          <p className="text-slate-400">Loading WASM module...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center space-y-4 max-w-md">
          <AlertCircle className="w-12 h-12 text-red-400 mx-auto" />
          <p className="text-red-400 font-semibold">Failed to load WASM module</p>
          <p className="text-slate-400 text-sm">{error}</p>
          <button
            onClick={reload}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-y-auto">
      <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-lg">
        <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
          <Grid3X3 className="w-6 h-6 text-purple-400" />
          Toroidal Boundary (WASM)
        </h2>
        <p className="text-slate-400 mb-4">
          Interactive visualization of the 12,288-cell toroidal boundary substrate using Rust/WASM bindings.
          Each cell holds a Res96 value (0-95).
        </p>

        {/* Stats Bar */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <div className="bg-slate-900 p-3 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-500 block">Total Budget</span>
            <span className="text-lg font-mono text-blue-400">{stats?.totalBudget.toString() ?? '0'}</span>
          </div>
          <div className="bg-slate-900 p-3 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-500 block">Signed Budget</span>
            <span className="text-lg font-mono text-emerald-400">{stats?.signedBudget.toString() ?? '0'}</span>
          </div>
          <div className="bg-slate-900 p-3 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-500 block">Non-Zero Cells</span>
            <span className="text-lg font-mono text-purple-400">{stats?.nonZeroCount ?? 0}</span>
          </div>
          <div className="bg-slate-900 p-3 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-500 block">View Offset</span>
            <span className="text-lg font-mono text-yellow-400">{viewOffset}</span>
          </div>
        </div>

        {/* Grid Visualization */}
        <div className="bg-slate-900 rounded-lg p-4 border border-slate-700 mb-6">
          <div className="flex justify-between items-center mb-3">
            <span className="text-sm text-slate-400">Cell Grid (16×16 = 256 cells)</span>
            <div className="flex gap-2">
              <button
                onClick={() => setViewOffset(Math.max(0, viewOffset - 256))}
                className="px-3 py-1 bg-slate-700 hover:bg-slate-600 text-white text-sm rounded"
              >
                ← Prev
              </button>
              <input
                type="number"
                value={viewOffset}
                onChange={(e) => setViewOffset(Math.max(0, Math.min(BOUNDARY_SIZE - 256, parseInt(e.target.value) || 0)))}
                className="w-24 px-2 py-1 bg-slate-800 border border-slate-600 rounded text-white text-sm text-center"
              />
              <button
                onClick={() => setViewOffset(Math.min(BOUNDARY_SIZE - 256, viewOffset + 256))}
                className="px-3 py-1 bg-slate-700 hover:bg-slate-600 text-white text-sm rounded"
              >
                Next →
              </button>
            </div>
          </div>

          <div
            className="grid gap-px bg-slate-700 rounded overflow-hidden"
            style={{
              gridTemplateColumns: `repeat(${GRID_SIZE}, ${CELL_DISPLAY_SIZE}px)`,
              width: 'fit-content',
              margin: '0 auto'
            }}
          >
            {grid.flat().map((value, idx) => {
              const cellIndex = viewOffset + idx;
              return (
                <div
                  key={idx}
                  className="flex items-center justify-center text-xs font-mono transition-colors cursor-pointer hover:ring-2 hover:ring-blue-400"
                  style={{
                    width: CELL_DISPLAY_SIZE,
                    height: CELL_DISPLAY_SIZE,
                    backgroundColor: value === 0 ? '#0f172a' : `hsl(${(value / R) * 240}, 70%, ${30 + (value / R) * 40}%)`
                  }}
                  title={`Cell ${cellIndex}: ${value}`}
                  onClick={() => {
                    setMutationArgs(`${cellIndex}, ${(value + 1) % R}`);
                    setSelectedMutation('set');
                  }}
                >
                  {value > 0 && <span className="text-white/80">{value}</span>}
                </div>
              );
            })}
          </div>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* String Encoding */}
          <div className="bg-slate-900 rounded-lg p-4 border border-slate-700">
            <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
              <Type className="w-5 h-5 text-blue-400" />
              String Encoding
            </h3>
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full h-20 bg-slate-800 border border-slate-600 rounded-lg p-3 text-white font-mono text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none mb-3"
              placeholder="Enter text to encode into boundary..."
            />
            <div className="flex gap-2">
              <button
                onClick={handleEncode}
                className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4" />
                Encode to Boundary
              </button>
              <button
                onClick={handleDecode}
                className="flex-1 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Hash className="w-4 h-4" />
                Decode from Boundary
              </button>
            </div>
          </div>

          {/* Mutations */}
          <div className="bg-slate-900 rounded-lg p-4 border border-slate-700">
            <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              Apply Mutation
            </h3>
            <div className="flex gap-2 mb-3">
              <select
                value={selectedMutation}
                onChange={(e) => setSelectedMutation(e.target.value as MutationType)}
                className="flex-1 bg-slate-800 border border-slate-600 rounded-lg p-2 text-white focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="set">Set(cell, value)</option>
                <option value="add">Add(cell, delta)</option>
                <option value="mirror">Mirror(cell)</option>
                <option value="swap">Swap(cell1, cell2)</option>
                <option value="mul">Mul(cell, scalar)</option>
                <option value="bitwiseNot">BitwiseNot(cell)</option>
                <option value="shiftLeft">ShiftLeft(cell, amount)</option>
                <option value="shiftRight">ShiftRight(cell, amount)</option>
              </select>
            </div>
            <input
              type="text"
              value={mutationArgs}
              onChange={(e) => setMutationArgs(e.target.value)}
              className="w-full bg-slate-800 border border-slate-600 rounded-lg p-2 text-white font-mono text-sm focus:ring-2 focus:ring-blue-500 outline-none mb-3"
              placeholder="Arguments (comma-separated)"
            />
            <div className="flex gap-2">
              <button
                onClick={handleApplyMutation}
                className="flex-1 px-4 py-2 bg-yellow-600 hover:bg-yellow-500 text-white font-medium rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Zap className="w-4 h-4" />
                Apply Mutation
              </button>
              <button
                onClick={handleRandomFill}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-medium rounded-lg transition-colors"
                title="Fill 100 random cells"
              >
                Random
              </button>
              <button
                onClick={handleClear}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white font-medium rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Clear
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Info Panel */}
      <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
        <h3 className="text-lg font-semibold text-white mb-3">About the Toroidal Boundary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-slate-400">
          <div>
            <h4 className="text-white font-medium mb-1">Structure</h4>
            <p>12,288 cells arranged in a toroidal (wrap-around) topology. Cell addresses are computed modulo BOUNDARY_SIZE.</p>
          </div>
          <div>
            <h4 className="text-white font-medium mb-1">Values</h4>
            <p>Each cell holds a Res96 value (0-95), representing an element of the mod-96 residue ring aligned with printable ASCII.</p>
          </div>
          <div>
            <h4 className="text-white font-medium mb-1">Mutations</h4>
            <p>17 atomic mutation types available: arithmetic, bitwise, indexed, and indirect operations for computation on the substrate.</p>
          </div>
        </div>
      </div>

      {/* Benchmark Panel */}
      <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <Timer className="w-5 h-5 text-orange-400" />
            WASM Performance Benchmarks
          </h3>
          <button
            onClick={handleRunBenchmarks}
            disabled={benchmarkRunning}
            className="px-4 py-2 bg-orange-600 hover:bg-orange-500 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-medium rounded-lg transition-colors flex items-center gap-2"
          >
            {benchmarkRunning ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Running...
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Run Benchmarks
              </>
            )}
          </button>
        </div>

        {benchmarkResults ? (
          <div className="space-y-4">
            {/* Summary Stats */}
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-700">
                <span className="text-xs text-slate-500 block">Total Operations</span>
                <span className="text-lg font-mono text-blue-400">
                  {benchmarkResults.reduce((sum, r) => sum + r.operations, 0).toLocaleString()}
                </span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-700">
                <span className="text-xs text-slate-500 block">Total Time</span>
                <span className="text-lg font-mono text-emerald-400">
                  {benchmarkResults.reduce((sum, r) => sum + r.totalMs, 0).toFixed(1)} ms
                </span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-700">
                <span className="text-xs text-slate-500 block">Fastest Op</span>
                <span className="text-lg font-mono text-purple-400">
                  {Math.min(...benchmarkResults.map(r => r.avgNs)).toFixed(0)} ns
                </span>
              </div>
            </div>

            {/* Results Table */}
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-700">
                <thead className="bg-slate-900">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Operation</th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-slate-400 uppercase tracking-wider">Iterations</th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-slate-400 uppercase tracking-wider">Total (ms)</th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-slate-400 uppercase tracking-wider">Ops/sec</th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-slate-400 uppercase tracking-wider">Avg (ns)</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Performance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700">
                  {benchmarkResults.map((result, idx) => {
                    const maxOps = Math.max(...benchmarkResults.map(r => r.opsPerSec));
                    const barWidth = (result.opsPerSec / maxOps) * 100;
                    return (
                      <tr key={idx} className="hover:bg-slate-700/50">
                        <td className="px-4 py-3 text-sm text-white font-mono">{result.name}</td>
                        <td className="px-4 py-3 text-sm text-slate-300 text-right font-mono">{result.operations.toLocaleString()}</td>
                        <td className="px-4 py-3 text-sm text-slate-300 text-right font-mono">{result.totalMs.toFixed(2)}</td>
                        <td className="px-4 py-3 text-sm text-emerald-400 text-right font-mono">
                          {result.opsPerSec >= 1_000_000
                            ? `${(result.opsPerSec / 1_000_000).toFixed(2)}M`
                            : result.opsPerSec >= 1_000
                            ? `${(result.opsPerSec / 1_000).toFixed(1)}K`
                            : result.opsPerSec.toFixed(0)}
                        </td>
                        <td className="px-4 py-3 text-sm text-purple-400 text-right font-mono">
                          {result.avgNs >= 1_000_000
                            ? `${(result.avgNs / 1_000_000).toFixed(2)}ms`
                            : result.avgNs >= 1_000
                            ? `${(result.avgNs / 1_000).toFixed(1)}µs`
                            : `${result.avgNs.toFixed(0)}ns`}
                        </td>
                        <td className="px-4 py-3 w-32">
                          <div className="h-3 bg-slate-700 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full transition-all"
                              style={{ width: `${barWidth}%` }}
                            />
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Legend */}
            <p className="text-xs text-slate-500 mt-2">
              Performance bar shows relative ops/sec. Higher is better. Results include WASM-JS boundary crossing overhead.
            </p>
          </div>
        ) : (
          <div className="text-center py-8 text-slate-500">
            <BarChart3 className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>Click "Run Benchmarks" to measure WASM performance</p>
            <p className="text-xs mt-1">Tests Cell, Res96, ToroidalBoundary, mutations, and serialization</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BoundaryDemo;
