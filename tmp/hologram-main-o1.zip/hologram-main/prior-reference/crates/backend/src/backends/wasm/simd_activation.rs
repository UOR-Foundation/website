//! WASM SIMD128 activation support.
//!
//! This module provides SIMD-accelerated activation lookups specifically
//! optimized for WebAssembly's SIMD128 instruction set.
//!
//! # Performance
//!
//! WASM SIMD128 provides 16 parallel lookups per instruction using
//! `i8x16_swizzle`, which is the WASM equivalent of ARM's `vtbl` instruction.
//!
//! | Operation | Throughput |
//! |-----------|------------|
//! | Scalar lookup | ~4 cycles/element |
//! | SIMD128 batch | ~0.5 cycles/element |
//!
//! # Example
//!
//! ```ignore
//! use hologram_backend::backends::wasm::simd_activation::WasmSimdActivation;
//! use hologram_backend::plan::activation_table_id;
//!
//! let mut activation = WasmSimdActivation::new();
//! activation.preload_standard();
//!
//! let input = [128u8; 64];
//! let mut output = [0u8; 64];
//! activation.apply_batch(activation_table_id::SIGMOID, &input, &mut output);
//! ```

use crate::core::gpu_textures::{get_activation_table, table_id};
use crate::plan::activation_table_id;
use rustc_hash::FxHashMap;

/// WASM SIMD activation processor.
///
/// Provides SIMD128-accelerated batch activation lookups for WebAssembly.
pub struct WasmSimdActivation {
    /// Cached activation tables for fast lookup.
    tables: FxHashMap<u32, [u8; 256]>,
}

impl Default for WasmSimdActivation {
    fn default() -> Self {
        Self::new()
    }
}

impl WasmSimdActivation {
    /// Create a new WASM SIMD activation processor.
    pub fn new() -> Self {
        Self {
            tables: FxHashMap::default(),
        }
    }

    /// Preload standard activation tables.
    pub fn preload_standard(&mut self) {
        self.ensure_loaded(activation_table_id::SIGMOID);
        self.ensure_loaded(activation_table_id::TANH);
        self.ensure_loaded(activation_table_id::RELU);
        self.ensure_loaded(activation_table_id::GELU);
        self.ensure_loaded(activation_table_id::SILU);
        self.ensure_loaded(table_id::SIGMOID_INVERSE);
        self.ensure_loaded(table_id::TANH_INVERSE);
    }

    /// Ensure a specific table is loaded into the cache.
    pub fn ensure_loaded(&mut self, table_id: u32) -> bool {
        if self.tables.contains_key(&table_id) {
            return true;
        }

        if let Some(table) = get_activation_table(table_id) {
            let mut cached = [0u8; 256];
            cached.copy_from_slice(table);
            self.tables.insert(table_id, cached);
            true
        } else {
            false
        }
    }

    /// Apply activation to a batch using WASM SIMD128 when available.
    ///
    /// Falls back to scalar processing when SIMD is not available.
    #[inline]
    pub fn apply_batch(&self, table_id: u32, input: &[u8], output: &mut [u8]) -> bool {
        let Some(table) = self.tables.get(&table_id) else {
            return false;
        };

        #[cfg(all(target_arch = "wasm32", target_feature = "simd128"))]
        {
            unsafe { self.apply_batch_simd128(table, input, output) };
            return true;
        }

        #[cfg(not(all(target_arch = "wasm32", target_feature = "simd128")))]
        {
            self.apply_batch_scalar(table, input, output);
            true
        }
    }

    /// Apply activation in-place.
    #[inline]
    pub fn apply_inplace(&self, table_id: u32, data: &mut [u8]) -> bool {
        let Some(table) = self.tables.get(&table_id) else {
            return false;
        };

        #[cfg(all(target_arch = "wasm32", target_feature = "simd128"))]
        {
            unsafe { self.apply_inplace_simd128(table, data) };
            return true;
        }

        #[cfg(not(all(target_arch = "wasm32", target_feature = "simd128")))]
        {
            self.apply_inplace_scalar(table, data);
            true
        }
    }

    /// WASM SIMD128 batch processing using i8x16_swizzle.
    ///
    /// For 256-byte tables, we split into 16 chunks of 16 bytes each
    /// and use the high nibble to select the chunk.
    #[cfg(all(target_arch = "wasm32", target_feature = "simd128"))]
    #[target_feature(enable = "simd128")]
    unsafe fn apply_batch_simd128(&self, table: &[u8; 256], input: &[u8], output: &mut [u8]) {
        use std::arch::wasm32::*;

        // Load table as 16 v128 chunks (16 bytes each = 256 bytes total)
        let mut table_chunks = [v128_load(std::ptr::null()); 16];
        for (i, chunk) in table_chunks.iter_mut().enumerate() {
            *chunk = v128_load(table.as_ptr().add(i * 16) as *const v128);
        }

        let low_mask = i8x16_splat(0x0F);

        // Process 16 bytes at a time
        let chunks = input.chunks_exact(16);
        let remainder = chunks.remainder();

        for (chunk, out_chunk) in chunks.zip(output.chunks_exact_mut(16)) {
            let indices = v128_load(chunk.as_ptr() as *const v128);

            // Extract low and high nibbles
            let low_nibble = v128_and(indices, low_mask);
            let high_nibble = v128_and(u8x16_shr(indices, 4), low_mask);

            // For each of the 16 possible high nibble values, do a swizzle
            // and blend based on which indices have that high nibble
            let mut result = i8x16_splat(0);

            for i in 0..16 {
                let chunk_mask = i8x16_eq(high_nibble, i8x16_splat(i as i8));
                let chunk_result = i8x16_swizzle(table_chunks[i], low_nibble);
                result = v128_bitselect(chunk_result, result, chunk_mask);
            }

            v128_store(out_chunk.as_mut_ptr() as *mut v128, result);
        }

        // Handle remainder with scalar
        let remainder_start = input.len() - remainder.len();
        for (i, &byte) in remainder.iter().enumerate() {
            output[remainder_start + i] = table[byte as usize];
        }
    }

    /// WASM SIMD128 in-place processing.
    #[cfg(all(target_arch = "wasm32", target_feature = "simd128"))]
    #[target_feature(enable = "simd128")]
    unsafe fn apply_inplace_simd128(&self, table: &[u8; 256], data: &mut [u8]) {
        use std::arch::wasm32::*;

        // Load table as 16 v128 chunks
        let mut table_chunks = [v128_load(std::ptr::null()); 16];
        for (i, chunk) in table_chunks.iter_mut().enumerate() {
            *chunk = v128_load(table.as_ptr().add(i * 16) as *const v128);
        }

        let low_mask = i8x16_splat(0x0F);

        // Process 16 bytes at a time
        let chunks = data.chunks_exact_mut(16);
        let len = data.len();
        let remainder_len = len % 16;

        for chunk in chunks {
            let indices = v128_load(chunk.as_ptr() as *const v128);

            let low_nibble = v128_and(indices, low_mask);
            let high_nibble = v128_and(u8x16_shr(indices, 4), low_mask);

            let mut result = i8x16_splat(0);

            for i in 0..16 {
                let chunk_mask = i8x16_eq(high_nibble, i8x16_splat(i as i8));
                let chunk_result = i8x16_swizzle(table_chunks[i], low_nibble);
                result = v128_bitselect(chunk_result, result, chunk_mask);
            }

            v128_store(chunk.as_mut_ptr() as *mut v128, result);
        }

        // Handle remainder with scalar
        if remainder_len > 0 {
            let remainder_start = len - remainder_len;
            for i in remainder_start..len {
                data[i] = table[data[i] as usize];
            }
        }
    }

    /// Scalar batch processing fallback.
    #[inline]
    fn apply_batch_scalar(&self, table: &[u8; 256], input: &[u8], output: &mut [u8]) {
        for (inp, out) in input.iter().zip(output.iter_mut()) {
            *out = table[*inp as usize];
        }
    }

    /// Scalar in-place processing fallback.
    #[inline]
    fn apply_inplace_scalar(&self, table: &[u8; 256], data: &mut [u8]) {
        for byte in data.iter_mut() {
            *byte = table[*byte as usize];
        }
    }

    /// Check if a table is loaded.
    pub fn is_loaded(&self, table_id: u32) -> bool {
        self.tables.contains_key(&table_id)
    }

    /// Check if WASM SIMD128 is available.
    pub fn simd128_available() -> bool {
        cfg!(all(target_arch = "wasm32", target_feature = "simd128"))
    }
}

/// Global WASM activation processor with thread-local storage.
pub mod global {
    use super::*;
    use std::cell::RefCell;

    thread_local! {
        static PROCESSOR: RefCell<WasmSimdActivation> = RefCell::new({
            let mut p = WasmSimdActivation::new();
            p.preload_standard();
            p
        });
    }

    /// Apply activation to batch using global processor.
    #[inline]
    pub fn apply_activation(table_id: u32, input: &[u8], output: &mut [u8]) -> bool {
        PROCESSOR.with(|p| p.borrow().apply_batch(table_id, input, output))
    }

    /// Apply activation in-place using global processor.
    #[inline]
    pub fn apply_activation_inplace(table_id: u32, data: &mut [u8]) -> bool {
        PROCESSOR.with(|p| p.borrow().apply_inplace(table_id, data))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_wasm_simd_new() {
        let activation = WasmSimdActivation::new();
        assert!(!activation.is_loaded(activation_table_id::SIGMOID));
    }

    #[test]
    fn test_wasm_simd_preload() {
        let mut activation = WasmSimdActivation::new();
        activation.preload_standard();

        assert!(activation.is_loaded(activation_table_id::SIGMOID));
        assert!(activation.is_loaded(activation_table_id::TANH));
        assert!(activation.is_loaded(activation_table_id::RELU));
    }

    #[test]
    fn test_wasm_simd_batch() {
        let mut activation = WasmSimdActivation::new();
        activation.preload_standard();

        let input: Vec<u8> = (0..256).map(|i| i as u8).collect();
        let mut output = vec![0u8; 256];

        let result = activation.apply_batch(activation_table_id::SIGMOID, &input, &mut output);
        assert!(result);

        // Output should be different from input
        assert_ne!(input, output);
    }

    #[test]
    fn test_wasm_simd_inplace() {
        let mut activation = WasmSimdActivation::new();
        activation.preload_standard();

        let mut data: Vec<u8> = (0..100).map(|i| (i * 2) as u8).collect();
        let original = data.clone();

        let result = activation.apply_inplace(activation_table_id::RELU, &mut data);
        assert!(result);

        // Data should be modified
        assert_ne!(data, original);
    }

    #[test]
    fn test_wasm_simd_unknown_table() {
        let activation = WasmSimdActivation::new();

        let input = [128u8; 10];
        let mut output = [0u8; 10];

        // Unknown table should return false
        assert!(!activation.apply_batch(9999, &input, &mut output));
    }

    #[test]
    fn test_global_processor() {
        let input = vec![128u8; 100];
        let mut output = vec![0u8; 100];

        assert!(global::apply_activation(
            activation_table_id::SIGMOID,
            &input,
            &mut output
        ));
    }
}
