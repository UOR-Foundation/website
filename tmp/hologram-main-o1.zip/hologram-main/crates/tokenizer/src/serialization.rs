//! Serialization format for compiled tokenizers.
//!
//! Defines a compact binary format for embedding tokenizers in .holo files.
//! The format is designed for zero-copy deserialization and memory mapping.

// Allow dead code for now - serialization is work-in-progress
#![allow(dead_code)]

use crate::{
    NormalizerConfig, NormalizerStep, PrefixTrie, Result, SpecialTokens, TokenizerError, Vocabulary,
};

/// Magic number for tokenizer files.
const MAGIC: u32 = 0x544F4B45; // "TOKE"

/// Current format version.
const VERSION: u32 = 1;

/// Serialized tokenizer header.
#[derive(Debug, Clone)]
pub struct TokenizerHeader {
    /// Magic number.
    pub magic: u32,
    /// Format version.
    pub version: u32,
    /// Vocabulary size.
    pub vocab_size: u32,
    /// Maximum token length in characters.
    pub max_token_len: u32,
    /// Special tokens.
    pub special_tokens: SpecialTokens,
    /// Normalization flags.
    pub normalize_flags: u32,
}

/// Serialize a tokenizer to bytes.
pub fn serialize_tokenizer(
    vocab: &Vocabulary,
    trie: &PrefixTrie,
    normalizer: &NormalizerConfig,
) -> Result<Vec<u8>> {
    let mut buffer = Vec::new();

    // Header
    let normalize_flags = encode_normalizer_flags(normalizer);
    let max_token_len = vocab
        .iter()
        .map(|(token, _, _)| token.chars().count())
        .max()
        .unwrap_or(0) as u32;

    buffer.extend_from_slice(&MAGIC.to_le_bytes());
    buffer.extend_from_slice(&VERSION.to_le_bytes());
    buffer.extend_from_slice(&(vocab.size as u32).to_le_bytes());
    buffer.extend_from_slice(&max_token_len.to_le_bytes());
    buffer.extend_from_slice(&vocab.special_tokens.pad.to_le_bytes());
    buffer.extend_from_slice(&vocab.special_tokens.eos.to_le_bytes());
    buffer.extend_from_slice(&vocab.special_tokens.unk.to_le_bytes());
    buffer.extend_from_slice(&vocab.special_tokens.bos.unwrap_or(u32::MAX).to_le_bytes());
    buffer.extend_from_slice(&normalize_flags.to_le_bytes());

    // Vocabulary entries: [id: u32, score: f32, token_len: u16, token_bytes: ...]
    let mut vocab_data = Vec::new();
    for (token, id, score) in vocab.iter() {
        let token_bytes = token.as_bytes();
        vocab_data.extend_from_slice(&id.to_le_bytes());
        vocab_data.extend_from_slice(&score.to_le_bytes());
        vocab_data.extend_from_slice(&(token_bytes.len() as u16).to_le_bytes());
        vocab_data.extend_from_slice(token_bytes);
    }

    // Write vocab section
    buffer.extend_from_slice(&(vocab_data.len() as u32).to_le_bytes());
    buffer.extend_from_slice(&vocab_data);

    // Trie serialization
    let trie_data = serialize_trie(trie)?;
    buffer.extend_from_slice(&(trie_data.len() as u32).to_le_bytes());
    buffer.extend_from_slice(&trie_data);

    Ok(buffer)
}

/// Deserialize a tokenizer from bytes.
pub fn deserialize_tokenizer(data: &[u8]) -> Result<(Vocabulary, PrefixTrie, NormalizerConfig)> {
    if data.len() < 36 {
        return Err(TokenizerError::Serialization("Data too short".to_string()));
    }

    let mut pos = 0;

    // Read header
    let magic = read_u32(data, &mut pos)?;
    if magic != MAGIC {
        return Err(TokenizerError::Serialization(format!(
            "Invalid magic: expected 0x{:08X}, got 0x{:08X}",
            MAGIC, magic
        )));
    }

    let version = read_u32(data, &mut pos)?;
    if version != VERSION {
        return Err(TokenizerError::Serialization(format!(
            "Unsupported version: {}",
            version
        )));
    }

    let vocab_size = read_u32(data, &mut pos)?;
    let _max_token_len = read_u32(data, &mut pos)?;
    let pad = read_u32(data, &mut pos)?;
    let eos = read_u32(data, &mut pos)?;
    let unk = read_u32(data, &mut pos)?;
    let bos_raw = read_u32(data, &mut pos)?;
    let bos = if bos_raw == u32::MAX {
        None
    } else {
        Some(bos_raw)
    };
    let normalize_flags = read_u32(data, &mut pos)?;

    let special_tokens = SpecialTokens { pad, eos, unk, bos };
    let normalizer = decode_normalizer_flags(normalize_flags);

    // Read vocabulary
    let vocab_len = read_u32(data, &mut pos)? as usize;
    if pos + vocab_len > data.len() {
        return Err(TokenizerError::Serialization(
            "Vocab data truncated".to_string(),
        ));
    }

    let vocab_data = &data[pos..pos + vocab_len];
    pos += vocab_len;

    let mut entries = Vec::with_capacity(vocab_size as usize);
    let mut vocab_pos = 0;
    while vocab_pos < vocab_data.len() {
        let id = u32::from_le_bytes(vocab_data[vocab_pos..vocab_pos + 4].try_into().unwrap());
        vocab_pos += 4;
        let score = f32::from_le_bytes(vocab_data[vocab_pos..vocab_pos + 4].try_into().unwrap());
        vocab_pos += 4;
        let token_len =
            u16::from_le_bytes(vocab_data[vocab_pos..vocab_pos + 2].try_into().unwrap()) as usize;
        vocab_pos += 2;
        let token = String::from_utf8(vocab_data[vocab_pos..vocab_pos + token_len].to_vec())
            .map_err(|e| TokenizerError::Serialization(e.to_string()))?;
        vocab_pos += token_len;

        entries.push(crate::VocabEntry {
            token,
            id,
            score,
            is_special: id == pad || id == eos || id == unk || Some(id) == bos,
        });
    }

    let vocab = Vocabulary::new(entries, special_tokens);

    // Read trie section length (but we rebuild from vocab instead of deserializing)
    let trie_len = read_u32(data, &mut pos)? as usize;
    if pos + trie_len > data.len() {
        return Err(TokenizerError::Serialization(
            "Trie data truncated".to_string(),
        ));
    }
    // Skip trie data - we rebuild from vocabulary
    // This is more robust than deserializing a complex tree structure

    // Rebuild trie from vocabulary
    // All non-special tokens go into the trie for lookup
    let trie = PrefixTrie::from_vocab(vocab.iter());

    Ok((vocab, trie, normalizer))
}

/// Serialize a trie to bytes.
fn serialize_trie(trie: &PrefixTrie) -> Result<Vec<u8>> {
    // Simple serialization: flatten trie to list of (token, id, score) entries
    // and rebuild on load. More compact formats possible but this is clear.
    let mut buffer = Vec::new();
    serialize_trie_node(trie, &[], &mut buffer)?;
    Ok(buffer)
}

fn serialize_trie_node(_trie: &PrefixTrie, _prefix: &[u32], _buffer: &mut Vec<u8>) -> Result<()> {
    // For each node with a token, write: [prefix_len: u16, prefix: [u32...], id: u32, score: f32]
    // This is a placeholder - the actual trie structure is more complex

    // Since PrefixTrie fields are private, we need a different approach.
    // For now, serialize as vocabulary entries (rebuild trie on load).
    Ok(())
}

/// Deserialize a trie from bytes.
fn deserialize_trie(_data: &[u8]) -> Result<PrefixTrie> {
    // For now, return empty trie - actual implementation would parse the data
    Ok(PrefixTrie::new())
}

fn read_u32(data: &[u8], pos: &mut usize) -> Result<u32> {
    if *pos + 4 > data.len() {
        return Err(TokenizerError::Serialization(
            "Unexpected end of data".to_string(),
        ));
    }
    let value = u32::from_le_bytes(data[*pos..*pos + 4].try_into().unwrap());
    *pos += 4;
    Ok(value)
}

/// Encode normalizer config to flags.
fn encode_normalizer_flags(config: &NormalizerConfig) -> u32 {
    let mut flags = 0u32;
    for step in &config.steps {
        flags |= match step {
            NormalizerStep::Lowercase => 1 << 0,
            NormalizerStep::Nfkc => 1 << 1,
            NormalizerStep::Nfc => 1 << 2,
            NormalizerStep::ReplaceWhitespace => 1 << 3,
            NormalizerStep::CollapseWhitespace => 1 << 4,
            NormalizerStep::StripAccents => 1 << 5,
            NormalizerStep::SpaceToUnderscore => 1 << 6,
            NormalizerStep::PrependUnderscore => 1 << 7,
        };
    }
    flags
}

/// Decode normalizer flags to config.
fn decode_normalizer_flags(flags: u32) -> NormalizerConfig {
    let mut steps = Vec::new();

    // Order matters - apply in standard order
    if flags & (1 << 1) != 0 {
        steps.push(NormalizerStep::Nfkc);
    }
    if flags & (1 << 2) != 0 {
        steps.push(NormalizerStep::Nfc);
    }
    if flags & (1 << 0) != 0 {
        steps.push(NormalizerStep::Lowercase);
    }
    if flags & (1 << 5) != 0 {
        steps.push(NormalizerStep::StripAccents);
    }
    if flags & (1 << 3) != 0 {
        steps.push(NormalizerStep::ReplaceWhitespace);
    }
    if flags & (1 << 4) != 0 {
        steps.push(NormalizerStep::CollapseWhitespace);
    }
    if flags & (1 << 6) != 0 {
        steps.push(NormalizerStep::SpaceToUnderscore);
    }
    if flags & (1 << 7) != 0 {
        steps.push(NormalizerStep::PrependUnderscore);
    }

    NormalizerConfig { steps }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::VocabEntry;

    fn sample_vocab() -> Vocabulary {
        let entries = vec![
            VocabEntry {
                token: "<pad>".to_string(),
                id: 0,
                score: 0.0,
                is_special: true,
            },
            VocabEntry {
                token: "</s>".to_string(),
                id: 1,
                score: 0.0,
                is_special: true,
            },
            VocabEntry {
                token: "hello".to_string(),
                id: 2,
                score: -1.0,
                is_special: false,
            },
        ];
        Vocabulary::new(entries, SpecialTokens::default())
    }

    #[test]
    fn test_encode_decode_normalizer_flags() {
        let config = NormalizerConfig {
            steps: vec![
                NormalizerStep::Nfkc,
                NormalizerStep::Lowercase,
                NormalizerStep::SpaceToUnderscore,
            ],
        };

        let flags = encode_normalizer_flags(&config);
        assert!(flags & (1 << 0) != 0); // Lowercase
        assert!(flags & (1 << 1) != 0); // Nfkc
        assert!(flags & (1 << 6) != 0); // SpaceToUnderscore

        let decoded = decode_normalizer_flags(flags);
        assert!(decoded.steps.contains(&NormalizerStep::Nfkc));
        assert!(decoded.steps.contains(&NormalizerStep::Lowercase));
        assert!(decoded.steps.contains(&NormalizerStep::SpaceToUnderscore));
    }

    #[test]
    fn test_serialize_header() {
        let vocab = sample_vocab();
        let trie = PrefixTrie::new();
        let normalizer = NormalizerConfig::default();

        let data = serialize_tokenizer(&vocab, &trie, &normalizer).unwrap();

        // Check magic
        let magic = u32::from_le_bytes(data[0..4].try_into().unwrap());
        assert_eq!(magic, MAGIC);

        // Check version
        let version = u32::from_le_bytes(data[4..8].try_into().unwrap());
        assert_eq!(version, VERSION);

        // Check vocab size
        let vocab_size = u32::from_le_bytes(data[8..12].try_into().unwrap());
        assert_eq!(vocab_size, 3);
    }

    #[test]
    fn test_roundtrip() {
        let vocab = sample_vocab();
        let trie = PrefixTrie::new();
        let normalizer = NormalizerConfig {
            steps: vec![NormalizerStep::Lowercase, NormalizerStep::Nfkc],
        };

        let data = serialize_tokenizer(&vocab, &trie, &normalizer).unwrap();
        let (loaded_vocab, _loaded_trie, loaded_normalizer) = deserialize_tokenizer(&data).unwrap();

        assert_eq!(loaded_vocab.size, vocab.size);
        assert_eq!(loaded_vocab.get_id("hello"), Some(2));
        assert_eq!(loaded_vocab.special_tokens.pad, 0);
        assert!(loaded_normalizer.steps.contains(&NormalizerStep::Lowercase));
    }

    #[test]
    fn test_invalid_magic() {
        let data = vec![0u8; 36];
        let result = deserialize_tokenizer(&data);
        assert!(matches!(result, Err(TokenizerError::Serialization(_))));
    }

    #[test]
    fn test_truncated_data() {
        let result = deserialize_tokenizer(&[0u8; 10]);
        assert!(matches!(result, Err(TokenizerError::Serialization(_))));
    }

    #[test]
    fn test_roundtrip_trie_functionality() {
        // Create vocab with real tokens for tokenization
        let entries = vec![
            VocabEntry {
                token: "<pad>".to_string(),
                id: 0,
                score: 0.0,
                is_special: true,
            },
            VocabEntry {
                token: "</s>".to_string(),
                id: 1,
                score: 0.0,
                is_special: true,
            },
            VocabEntry {
                token: "<unk>".to_string(),
                id: 2,
                score: -100.0,
                is_special: true,
            },
            VocabEntry {
                token: "▁hello".to_string(),
                id: 3,
                score: -1.0,
                is_special: false,
            },
            VocabEntry {
                token: "▁world".to_string(),
                id: 4,
                score: -1.5,
                is_special: false,
            },
            VocabEntry {
                token: "▁".to_string(),
                id: 5,
                score: -0.5,
                is_special: false,
            },
            VocabEntry {
                token: "h".to_string(),
                id: 6,
                score: -2.0,
                is_special: false,
            },
            VocabEntry {
                token: "e".to_string(),
                id: 7,
                score: -2.0,
                is_special: false,
            },
            VocabEntry {
                token: "l".to_string(),
                id: 8,
                score: -2.0,
                is_special: false,
            },
            VocabEntry {
                token: "o".to_string(),
                id: 9,
                score: -2.0,
                is_special: false,
            },
        ];
        let special = SpecialTokens {
            pad: 0,
            eos: 1,
            unk: 2,
            bos: None,
        };
        let vocab = Vocabulary::new(entries, special);

        // Build trie from vocab
        let trie = PrefixTrie::from_vocab(vocab.iter());

        let normalizer = NormalizerConfig::default();

        // Serialize
        let data = serialize_tokenizer(&vocab, &trie, &normalizer).unwrap();

        // Deserialize
        let (loaded_vocab, loaded_trie, _loaded_normalizer) = deserialize_tokenizer(&data).unwrap();

        // Verify vocab
        assert_eq!(loaded_vocab.size, vocab.size);
        assert_eq!(loaded_vocab.get_id("▁hello"), Some(3));

        // Verify trie functionality - find matches for "▁hello"
        let input: Vec<u32> = "▁hello".chars().map(|c| c as u32).collect();
        let matches = loaded_trie.find_matches(&input);

        // Should find "▁" (id=5) and "▁hello" (id=3)
        assert!(!matches.is_empty(), "Trie should find matches");

        let match_ids: Vec<u32> = matches.iter().map(|m| m.token_id).collect();
        assert!(match_ids.contains(&5), "Should find ▁ token");
        assert!(match_ids.contains(&3), "Should find ▁hello token");
    }
}
