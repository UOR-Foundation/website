//! Archive format definitions for .holb and .holo files.
//!
//! This module defines the binary format structures for Hologram archives:
//! - `.holb` - HOLB (Hologram Unified Bundle): Single model with embedded weights
//! - `.holo` - HOLM (Hologram Pipeline Bundle): Multi-model pipeline with index
//!
//! # Header Versions
//!
//! - HOLB V1 (48 bytes): Basic header without sections
//! - HOLB V2 (80 bytes): Extended header with sections table support
//! - HOLM (64 bytes): Pipeline header with model index

// Allow casts in this module since we're working with file format offsets
// that are designed for 64-bit but safe for practical file sizes.
#![allow(clippy::cast_possible_truncation)]

use rkyv::{Archive, Deserialize, Serialize};

use crate::error::HoloError;
use crate::Result;

/// Magic bytes for HOLB (Hologram Unified Bundle)
/// File extension: .holb
pub const HOLB_MAGIC: &[u8; 4] = b"HOLB";

/// Magic bytes for HOLM (Hologram Pipeline Bundle)
/// File extension: .holo
pub const HOLM_MAGIC: &[u8; 4] = b"HOLM";

/// Page size for memory alignment (4KB).
/// Weights and sections are aligned to page boundaries for efficient mmap access.
pub const PAGE_SIZE: usize = 4096;

/// Size of HOLB V1 header in bytes.
pub const HOLB_HEADER_SIZE_V1: usize = 48;

/// Size of HOLB V2 header in bytes (with sections support).
pub const HOLB_HEADER_SIZE_V2: usize = 80;

/// Size of HOLM header in bytes.
pub const HOLM_HEADER_SIZE: usize = 64;

/// HOLB V1 header (single model bundle, 48 bytes)
///
/// Layout:
/// ```text
/// [HOLB header: 48 bytes]
/// [`BackendPlan`: variable]
/// [Weights: page-aligned at 4KB]
/// ```
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct HolbHeader {
    /// Magic bytes ("HOLB")
    pub magic: [u8; 4],

    /// Format version (1 for V1 header)
    pub version: u32,

    /// Offset to `BackendPlan` data
    pub graph_offset: u64,

    /// Size of `BackendPlan` in bytes
    pub graph_size: u64,

    /// Offset to weights/constants (page-aligned at 4KB)
    pub weights_offset: u64,

    /// Size of weights in bytes
    pub weights_size: u64,

    /// CRC32 checksum of `BackendPlan`
    pub graph_checksum: u32,

    /// CRC32 checksum of weights
    pub weights_checksum: u32,
}

/// HOLB V2 header (single model bundle with sections, 80 bytes)
///
/// Layout:
/// ```text
/// [HOLB header: 80 bytes]
/// [`BackendPlan`: variable]
/// [Padding to 4KB boundary]
/// [Sections table: variable, page-aligned]
/// [Sections data: concatenated]
/// [Padding to 4KB boundary]
/// [Weights: page-aligned]
/// ```
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct HolbHeaderV2 {
    /// Magic bytes ("HOLB")
    pub magic: [u8; 4],

    /// Format version (2 for V2 header)
    pub version: u32,

    /// Header flags (reserved for future use)
    pub flags: u32,

    /// Reserved for alignment (internal use)
    pub(crate) _reserved1: u32,

    /// Offset to `BackendPlan` data
    pub graph_offset: u64,

    /// Size of `BackendPlan` in bytes
    pub graph_size: u64,

    /// Offset to weights/constants (page-aligned at 4KB)
    pub weights_offset: u64,

    /// Size of weights in bytes
    pub weights_size: u64,

    /// CRC32 checksum of `BackendPlan`
    pub graph_checksum: u32,

    /// CRC32 checksum of weights
    pub weights_checksum: u32,

    /// Offset to sections table (page-aligned)
    pub sections_table_offset: u64,

    /// Number of sections in the table
    pub sections_count: u32,

    /// Reserved for future use (internal use)
    pub(crate) _reserved2: u32,
}

/// HOLM header (multi-model pipeline bundle, 64 bytes)
///
/// Layout:
/// ```text
/// [HOLM header: 64 bytes]
/// [Model index: variable]
/// [Padding to 4KB boundary]
/// [Model 0 data (HOLB bundle)]
/// [Padding to 4KB boundary]
/// [Model 1 data (HOLB bundle)]
/// ...
/// ```
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct HolmHeader {
    /// Magic bytes ("HOLM")
    pub magic: [u8; 4],

    /// Format version (currently 1)
    pub version: u32,

    /// Header flags (reserved for future use)
    pub flags: u32,

    /// Number of models in pipeline
    pub model_count: u32,

    /// Offset to model index table
    pub index_offset: u64,

    /// Size of model index in bytes
    pub index_size: u64,

    /// Offset to first model data (page-aligned)
    pub models_offset: u64,

    /// Total size of all model data
    pub models_total_size: u64,

    /// CRC32 checksum of the index
    pub index_checksum: u32,

    /// Reserved for future use (internal use)
    pub(crate) _reserved: u32,
}

/// Model index entry in HOLM bundle (for rkyv serialization)
#[derive(Debug, Clone, PartialEq, Eq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct ModelIndexEntry {
    /// Model name/identifier
    pub name: String,

    /// Content hash (SHA-256) for integrity verification
    pub layer_id: [u8; 32],

    /// Offset in file to model data
    pub offset: u64,

    /// Size of model data in bytes
    pub size: u64,

    /// CRC32 checksum of model data
    pub checksum: u32,
}

/// Pipeline model entry for manual serialization.
///
/// This structure is used for the model index in HOLM bundles.
/// Unlike `ModelIndexEntry`, this is serialized manually for precise control.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PipelineModelEntry {
    /// Model name (UTF-8)
    pub name: String,

    /// Offset in file to model data (page-aligned)
    pub offset: u64,

    /// Size of model data in bytes
    pub size: u64,

    /// CRC32 checksum of model data
    pub checksum: u32,
}

impl HolbHeader {
    /// Create a new HOLB V1 header with default values.
    #[must_use]
    pub const fn new() -> Self {
        Self {
            magic: *HOLB_MAGIC,
            version: 1,
            graph_offset: HOLB_HEADER_SIZE_V1 as u64,
            graph_size: 0,
            weights_offset: 0,
            weights_size: 0,
            graph_checksum: 0,
            weights_checksum: 0,
        }
    }

    /// Verify magic bytes match HOLB format.
    #[must_use]
    pub const fn is_valid(&self) -> bool {
        self.magic[0] == HOLB_MAGIC[0]
            && self.magic[1] == HOLB_MAGIC[1]
            && self.magic[2] == HOLB_MAGIC[2]
            && self.magic[3] == HOLB_MAGIC[3]
    }

    /// Get the size of the header in bytes.
    #[must_use]
    pub const fn header_size() -> usize {
        HOLB_HEADER_SIZE_V1
    }

    /// Serialize header to bytes.
    #[must_use]
    pub fn to_bytes(&self) -> [u8; HOLB_HEADER_SIZE_V1] {
        let mut buf = [0u8; HOLB_HEADER_SIZE_V1];
        buf[0..4].copy_from_slice(&self.magic);
        buf[4..8].copy_from_slice(&self.version.to_le_bytes());
        buf[8..16].copy_from_slice(&self.graph_offset.to_le_bytes());
        buf[16..24].copy_from_slice(&self.graph_size.to_le_bytes());
        buf[24..32].copy_from_slice(&self.weights_offset.to_le_bytes());
        buf[32..40].copy_from_slice(&self.weights_size.to_le_bytes());
        buf[40..44].copy_from_slice(&self.graph_checksum.to_le_bytes());
        buf[44..48].copy_from_slice(&self.weights_checksum.to_le_bytes());
        buf
    }

    /// Deserialize header from bytes.
    ///
    /// # Errors
    /// Returns error if buffer is too small or magic bytes are invalid.
    pub fn from_bytes(buf: &[u8]) -> Result<Self> {
        if buf.len() < HOLB_HEADER_SIZE_V1 {
            return Err(HoloError::Other(format!(
                "Buffer too small: expected {HOLB_HEADER_SIZE_V1}, got {}",
                buf.len()
            )));
        }

        let magic: [u8; 4] = buf[0..4].try_into().unwrap();
        let header = Self {
            magic,
            version: u32::from_le_bytes(buf[4..8].try_into().unwrap()),
            graph_offset: u64::from_le_bytes(buf[8..16].try_into().unwrap()),
            graph_size: u64::from_le_bytes(buf[16..24].try_into().unwrap()),
            weights_offset: u64::from_le_bytes(buf[24..32].try_into().unwrap()),
            weights_size: u64::from_le_bytes(buf[32..40].try_into().unwrap()),
            graph_checksum: u32::from_le_bytes(buf[40..44].try_into().unwrap()),
            weights_checksum: u32::from_le_bytes(buf[44..48].try_into().unwrap()),
        };

        if !header.is_valid() {
            return Err(HoloError::invalid_magic(HOLB_MAGIC, &magic));
        }

        Ok(header)
    }

    /// Validate header fields for consistency.
    ///
    /// # Errors
    /// Returns error if header fields are invalid.
    pub fn validate(&self) -> Result<()> {
        if !self.is_valid() {
            return Err(HoloError::invalid_magic(HOLB_MAGIC, &self.magic));
        }
        if self.version != 1 {
            return Err(HoloError::Other(format!(
                "Unsupported version: expected 1, got {}",
                self.version
            )));
        }
        Ok(())
    }

    /// Calculate page-aligned weights offset given graph size.
    #[must_use]
    pub const fn calculate_weights_offset(graph_size: u64) -> u64 {
        let data_end = HOLB_HEADER_SIZE_V1 as u64 + graph_size;
        align_to_page(data_end)
    }
}

impl Default for HolbHeader {
    fn default() -> Self {
        Self::new()
    }
}

impl HolbHeaderV2 {
    /// Create a new HOLB V2 header with default values.
    #[must_use]
    pub const fn new() -> Self {
        Self {
            magic: *HOLB_MAGIC,
            version: 2,
            flags: 0,
            _reserved1: 0,
            graph_offset: HOLB_HEADER_SIZE_V2 as u64,
            graph_size: 0,
            weights_offset: 0,
            weights_size: 0,
            graph_checksum: 0,
            weights_checksum: 0,
            sections_table_offset: 0,
            sections_count: 0,
            _reserved2: 0,
        }
    }

    /// Verify magic bytes match HOLB format.
    #[must_use]
    pub const fn is_valid(&self) -> bool {
        self.magic[0] == HOLB_MAGIC[0]
            && self.magic[1] == HOLB_MAGIC[1]
            && self.magic[2] == HOLB_MAGIC[2]
            && self.magic[3] == HOLB_MAGIC[3]
    }

    /// Get the size of the header in bytes.
    #[must_use]
    pub const fn header_size() -> usize {
        HOLB_HEADER_SIZE_V2
    }

    /// Check if this header has sections.
    #[must_use]
    pub const fn has_sections(&self) -> bool {
        self.sections_count > 0
    }

    /// Serialize header to bytes.
    #[must_use]
    pub fn to_bytes(&self) -> [u8; HOLB_HEADER_SIZE_V2] {
        let mut buf = [0u8; HOLB_HEADER_SIZE_V2];
        buf[0..4].copy_from_slice(&self.magic);
        buf[4..8].copy_from_slice(&self.version.to_le_bytes());
        buf[8..12].copy_from_slice(&self.flags.to_le_bytes());
        buf[12..16].copy_from_slice(&self._reserved1.to_le_bytes());
        buf[16..24].copy_from_slice(&self.graph_offset.to_le_bytes());
        buf[24..32].copy_from_slice(&self.graph_size.to_le_bytes());
        buf[32..40].copy_from_slice(&self.weights_offset.to_le_bytes());
        buf[40..48].copy_from_slice(&self.weights_size.to_le_bytes());
        buf[48..52].copy_from_slice(&self.graph_checksum.to_le_bytes());
        buf[52..56].copy_from_slice(&self.weights_checksum.to_le_bytes());
        buf[56..64].copy_from_slice(&self.sections_table_offset.to_le_bytes());
        buf[64..68].copy_from_slice(&self.sections_count.to_le_bytes());
        buf[68..72].copy_from_slice(&self._reserved2.to_le_bytes());
        // Remaining 8 bytes are padding (72..80)
        buf
    }

    /// Deserialize header from bytes.
    ///
    /// # Errors
    /// Returns error if buffer is too small or magic bytes are invalid.
    pub fn from_bytes(buf: &[u8]) -> Result<Self> {
        if buf.len() < HOLB_HEADER_SIZE_V2 {
            return Err(HoloError::Other(format!(
                "Buffer too small: expected {HOLB_HEADER_SIZE_V2}, got {}",
                buf.len()
            )));
        }

        let magic: [u8; 4] = buf[0..4].try_into().unwrap();
        let header = Self {
            magic,
            version: u32::from_le_bytes(buf[4..8].try_into().unwrap()),
            flags: u32::from_le_bytes(buf[8..12].try_into().unwrap()),
            _reserved1: u32::from_le_bytes(buf[12..16].try_into().unwrap()),
            graph_offset: u64::from_le_bytes(buf[16..24].try_into().unwrap()),
            graph_size: u64::from_le_bytes(buf[24..32].try_into().unwrap()),
            weights_offset: u64::from_le_bytes(buf[32..40].try_into().unwrap()),
            weights_size: u64::from_le_bytes(buf[40..48].try_into().unwrap()),
            graph_checksum: u32::from_le_bytes(buf[48..52].try_into().unwrap()),
            weights_checksum: u32::from_le_bytes(buf[52..56].try_into().unwrap()),
            sections_table_offset: u64::from_le_bytes(buf[56..64].try_into().unwrap()),
            sections_count: u32::from_le_bytes(buf[64..68].try_into().unwrap()),
            _reserved2: u32::from_le_bytes(buf[68..72].try_into().unwrap()),
        };

        if !header.is_valid() {
            return Err(HoloError::invalid_magic(HOLB_MAGIC, &magic));
        }

        Ok(header)
    }

    /// Validate header fields for consistency.
    ///
    /// # Errors
    /// Returns error if header fields are invalid.
    pub fn validate(&self) -> Result<()> {
        if !self.is_valid() {
            return Err(HoloError::invalid_magic(HOLB_MAGIC, &self.magic));
        }
        if self.version != 2 {
            return Err(HoloError::Other(format!(
                "Unsupported version: expected 2, got {}",
                self.version
            )));
        }
        Ok(())
    }

    /// Calculate page-aligned weights offset given graph and sections sizes.
    #[must_use]
    pub const fn calculate_weights_offset(graph_size: u64, sections_size: u64) -> u64 {
        let data_end = HOLB_HEADER_SIZE_V2 as u64 + graph_size + sections_size;
        align_to_page(data_end)
    }
}

impl Default for HolbHeaderV2 {
    fn default() -> Self {
        Self::new()
    }
}

impl HolmHeader {
    /// Create a new HOLM header with default values.
    #[must_use]
    pub const fn new() -> Self {
        Self {
            magic: *HOLM_MAGIC,
            version: 1,
            flags: 0,
            model_count: 0,
            index_offset: HOLM_HEADER_SIZE as u64,
            index_size: 0,
            models_offset: 0,
            models_total_size: 0,
            index_checksum: 0,
            _reserved: 0,
        }
    }

    /// Verify magic bytes match HOLM format.
    #[must_use]
    pub const fn is_valid(&self) -> bool {
        self.magic[0] == HOLM_MAGIC[0]
            && self.magic[1] == HOLM_MAGIC[1]
            && self.magic[2] == HOLM_MAGIC[2]
            && self.magic[3] == HOLM_MAGIC[3]
    }

    /// Get the size of the header in bytes.
    #[must_use]
    pub const fn header_size() -> usize {
        HOLM_HEADER_SIZE
    }

    /// Serialize header to bytes.
    #[must_use]
    pub fn to_bytes(&self) -> [u8; HOLM_HEADER_SIZE] {
        let mut buf = [0u8; HOLM_HEADER_SIZE];
        buf[0..4].copy_from_slice(&self.magic);
        buf[4..8].copy_from_slice(&self.version.to_le_bytes());
        buf[8..12].copy_from_slice(&self.flags.to_le_bytes());
        buf[12..16].copy_from_slice(&self.model_count.to_le_bytes());
        buf[16..24].copy_from_slice(&self.index_offset.to_le_bytes());
        buf[24..32].copy_from_slice(&self.index_size.to_le_bytes());
        buf[32..40].copy_from_slice(&self.models_offset.to_le_bytes());
        buf[40..48].copy_from_slice(&self.models_total_size.to_le_bytes());
        buf[48..52].copy_from_slice(&self.index_checksum.to_le_bytes());
        buf[52..56].copy_from_slice(&self._reserved.to_le_bytes());
        // Remaining 8 bytes are padding (56..64)
        buf
    }

    /// Deserialize header from bytes.
    ///
    /// # Errors
    /// Returns error if buffer is too small or magic bytes are invalid.
    pub fn from_bytes(buf: &[u8]) -> Result<Self> {
        if buf.len() < HOLM_HEADER_SIZE {
            return Err(HoloError::Other(format!(
                "Buffer too small: expected {HOLM_HEADER_SIZE}, got {}",
                buf.len()
            )));
        }

        let magic: [u8; 4] = buf[0..4].try_into().unwrap();
        let header = Self {
            magic,
            version: u32::from_le_bytes(buf[4..8].try_into().unwrap()),
            flags: u32::from_le_bytes(buf[8..12].try_into().unwrap()),
            model_count: u32::from_le_bytes(buf[12..16].try_into().unwrap()),
            index_offset: u64::from_le_bytes(buf[16..24].try_into().unwrap()),
            index_size: u64::from_le_bytes(buf[24..32].try_into().unwrap()),
            models_offset: u64::from_le_bytes(buf[32..40].try_into().unwrap()),
            models_total_size: u64::from_le_bytes(buf[40..48].try_into().unwrap()),
            index_checksum: u32::from_le_bytes(buf[48..52].try_into().unwrap()),
            _reserved: u32::from_le_bytes(buf[52..56].try_into().unwrap()),
        };

        if !header.is_valid() {
            return Err(HoloError::invalid_magic(HOLM_MAGIC, &magic));
        }

        Ok(header)
    }

    /// Validate header fields for consistency.
    ///
    /// # Errors
    /// Returns error if header fields are invalid.
    pub fn validate(&self) -> Result<()> {
        if !self.is_valid() {
            return Err(HoloError::invalid_magic(HOLM_MAGIC, &self.magic));
        }
        if self.version != 1 {
            return Err(HoloError::Other(format!(
                "Unsupported version: expected 1, got {}",
                self.version
            )));
        }
        if self.model_count == 0 {
            return Err(HoloError::Other(String::from("No models in pipeline")));
        }
        Ok(())
    }

    /// Calculate page-aligned models offset given index size.
    #[must_use]
    pub const fn calculate_models_offset(index_size: u64) -> u64 {
        let data_end = HOLM_HEADER_SIZE as u64 + index_size;
        align_to_page(data_end)
    }
}

impl Default for HolmHeader {
    fn default() -> Self {
        Self::new()
    }
}

impl PipelineModelEntry {
    /// Create a new pipeline model entry.
    #[must_use]
    pub fn new(name: impl Into<String>, offset: u64, size: u64, checksum: u32) -> Self {
        Self {
            name: name.into(),
            offset,
            size,
            checksum,
        }
    }

    /// Serialize entry to bytes (length-prefixed name + fields).
    #[must_use]
    pub fn to_bytes(&self) -> Vec<u8> {
        let name_bytes = self.name.as_bytes();
        let name_len = name_bytes.len() as u16;
        let mut buf = Vec::with_capacity(2 + name_bytes.len() + 20);

        buf.extend_from_slice(&name_len.to_le_bytes());
        buf.extend_from_slice(name_bytes);
        buf.extend_from_slice(&self.offset.to_le_bytes());
        buf.extend_from_slice(&self.size.to_le_bytes());
        buf.extend_from_slice(&self.checksum.to_le_bytes());

        buf
    }

    /// Deserialize entry from bytes.
    ///
    /// Returns the entry and number of bytes consumed.
    ///
    /// # Errors
    /// Returns error if buffer is truncated or UTF-8 is invalid.
    pub fn from_bytes(buf: &[u8]) -> Result<(Self, usize)> {
        if buf.len() < 2 {
            return Err(HoloError::Other(String::from(
                "Buffer too small for name length",
            )));
        }

        let name_len = u16::from_le_bytes(buf[0..2].try_into().unwrap()) as usize;
        let min_size = 2 + name_len + 20; // name_len + name + offset(8) + size(8) + checksum(4)

        if buf.len() < min_size {
            return Err(HoloError::Other(format!(
                "Buffer too small: expected {min_size}, got {}",
                buf.len()
            )));
        }

        let name = std::str::from_utf8(&buf[2..2 + name_len])
            .map_err(|e| HoloError::Other(format!("Invalid UTF-8 in name: {e}")))?
            .to_string();

        let offset_start = 2 + name_len;
        let entry = Self {
            name,
            offset: u64::from_le_bytes(buf[offset_start..offset_start + 8].try_into().unwrap()),
            size: u64::from_le_bytes(buf[offset_start + 8..offset_start + 16].try_into().unwrap()),
            checksum: u32::from_le_bytes(
                buf[offset_start + 16..offset_start + 20]
                    .try_into()
                    .unwrap(),
            ),
        };

        Ok((entry, min_size))
    }

    /// Get serialized size of this entry.
    #[must_use]
    pub fn serialized_size(&self) -> usize {
        2 + self.name.len() + 20
    }
}

/// Align a value up to the next page boundary.
#[must_use]
pub const fn align_to_page(value: u64) -> u64 {
    let page = PAGE_SIZE as u64;
    (value + page - 1) & !(page - 1)
}

/// Detect HOLB header version from buffer.
///
/// # Errors
/// Returns error if buffer is too small or magic is invalid.
pub fn detect_holb_version(buf: &[u8]) -> Result<u32> {
    if buf.len() < 8 {
        return Err(HoloError::Other(String::from(
            "Buffer too small for version detection",
        )));
    }

    let magic = &buf[0..4];
    if magic != HOLB_MAGIC {
        return Err(HoloError::invalid_magic(HOLB_MAGIC, magic));
    }

    Ok(u32::from_le_bytes(buf[4..8].try_into().unwrap()))
}

/// CRC32 lookup table (IEEE polynomial).
const CRC32_TABLE: [u32; 256] = generate_crc32_table();

/// Generate CRC32 lookup table at compile time.
const fn generate_crc32_table() -> [u32; 256] {
    let mut table = [0u32; 256];
    let mut i = 0;
    while i < 256 {
        let mut crc = i;
        let mut j = 0;
        while j < 8 {
            if crc & 1 == 1 {
                crc = (crc >> 1) ^ 0xEDB8_8320;
            } else {
                crc >>= 1;
            }
            j += 1;
        }
        table[i as usize] = crc;
        i += 1;
    }
    table
}

/// Compute CRC32 checksum of data.
///
/// Uses the IEEE polynomial (same as zlib/gzip).
#[must_use]
pub fn crc32(data: &[u8]) -> u32 {
    let mut crc = 0xFFFF_FFFF_u32;
    for &byte in data {
        let index = ((crc ^ u32::from(byte)) & 0xFF) as usize;
        crc = (crc >> 8) ^ CRC32_TABLE[index];
    }
    !crc
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_holb_header_v1_size() {
        assert_eq!(HOLB_HEADER_SIZE_V1, 48);
        // Ensure header struct fits the declared size
        let size = std::mem::size_of::<HolbHeader>();
        assert!(
            size <= HOLB_HEADER_SIZE_V1,
            "HolbHeader is {size} bytes, should be <= 48"
        );
    }

    #[test]
    fn test_holb_header_v2_size() {
        assert_eq!(HOLB_HEADER_SIZE_V2, 80);
        let size = std::mem::size_of::<HolbHeaderV2>();
        assert!(
            size <= HOLB_HEADER_SIZE_V2,
            "HolbHeaderV2 is {size} bytes, should be <= 80"
        );
    }

    #[test]
    fn test_holm_header_size() {
        assert_eq!(HOLM_HEADER_SIZE, 64);
        let size = std::mem::size_of::<HolmHeader>();
        assert!(
            size <= HOLM_HEADER_SIZE,
            "HolmHeader is {size} bytes, should be <= 64"
        );
    }

    #[test]
    fn test_holb_magic_validation() {
        let mut header = HolbHeader::new();
        assert!(header.is_valid());

        header.magic = *b"JUNK";
        assert!(!header.is_valid());
    }

    #[test]
    fn test_holb_v2_magic_validation() {
        let mut header = HolbHeaderV2::new();
        assert!(header.is_valid());

        header.magic = *b"JUNK";
        assert!(!header.is_valid());
    }

    #[test]
    fn test_holm_magic_validation() {
        let mut header = HolmHeader::new();
        assert!(header.is_valid());

        header.magic = *b"JUNK";
        assert!(!header.is_valid());
    }

    #[test]
    fn test_holb_default() {
        let header = HolbHeader::default();
        assert_eq!(header.magic, *HOLB_MAGIC);
        assert_eq!(header.version, 1);
        assert_eq!(header.graph_offset, HOLB_HEADER_SIZE_V1 as u64);
        assert!(header.is_valid());
    }

    #[test]
    fn test_holb_v2_default() {
        let header = HolbHeaderV2::default();
        assert_eq!(header.magic, *HOLB_MAGIC);
        assert_eq!(header.version, 2);
        assert_eq!(header.graph_offset, HOLB_HEADER_SIZE_V2 as u64);
        assert!(!header.has_sections());
        assert!(header.is_valid());
    }

    #[test]
    fn test_holm_default() {
        let header = HolmHeader::default();
        assert_eq!(header.magic, *HOLM_MAGIC);
        assert_eq!(header.version, 1);
        assert_eq!(header.index_offset, HOLM_HEADER_SIZE as u64);
        assert!(header.is_valid());
    }

    #[test]
    fn test_holb_v1_roundtrip() {
        let mut header = HolbHeader::new();
        header.graph_size = 1024;
        header.weights_offset = 4096;
        header.weights_size = 2048;
        header.graph_checksum = 0xDEAD_BEEF;
        header.weights_checksum = 0xCAFE_BABE;

        let bytes = header.to_bytes();
        assert_eq!(bytes.len(), HOLB_HEADER_SIZE_V1);

        let parsed = HolbHeader::from_bytes(&bytes).unwrap();
        assert_eq!(parsed, header);
    }

    #[test]
    fn test_holb_v2_roundtrip() {
        let mut header = HolbHeaderV2::new();
        header.graph_size = 1024;
        header.sections_table_offset = 4096;
        header.sections_count = 5;
        header.weights_offset = 8192;
        header.weights_size = 2048;
        header.graph_checksum = 0xDEAD_BEEF;
        header.weights_checksum = 0xCAFE_BABE;

        let bytes = header.to_bytes();
        assert_eq!(bytes.len(), HOLB_HEADER_SIZE_V2);

        let parsed = HolbHeaderV2::from_bytes(&bytes).unwrap();
        assert_eq!(parsed, header);
        assert!(parsed.has_sections());
    }

    #[test]
    fn test_holm_header_roundtrip() {
        let mut header = HolmHeader::new();
        header.model_count = 3;
        header.index_size = 256;
        header.models_offset = 4096;
        header.models_total_size = 65536;
        header.index_checksum = 0x1234_5678;

        let bytes = header.to_bytes();
        assert_eq!(bytes.len(), HOLM_HEADER_SIZE);

        let parsed = HolmHeader::from_bytes(&bytes).unwrap();
        assert_eq!(parsed, header);
    }

    #[test]
    fn test_pipeline_model_entry_roundtrip() {
        let entry = PipelineModelEntry::new("test-model", 4096, 1024, 0xDEAD_BEEF);
        let bytes = entry.to_bytes();
        let (parsed, consumed) = PipelineModelEntry::from_bytes(&bytes).unwrap();

        assert_eq!(parsed, entry);
        assert_eq!(consumed, entry.serialized_size());
    }

    #[test]
    fn test_pipeline_model_entry_serialized_size() {
        let entry = PipelineModelEntry::new("hello", 0, 0, 0);
        // 2 (name_len) + 5 (name) + 8 (offset) + 8 (size) + 4 (checksum) = 27
        assert_eq!(entry.serialized_size(), 27);
    }

    #[test]
    fn test_model_index_entry() {
        let entry = ModelIndexEntry {
            name: String::from("test-model"),
            layer_id: [0u8; 32],
            offset: 4096,
            size: 1024,
            checksum: 0xDEAD_BEEF,
        };

        assert_eq!(entry.name, "test-model");
        assert_eq!(entry.offset, 4096);
        assert_eq!(entry.size, 1024);
        assert_eq!(entry.checksum, 0xDEAD_BEEF);
    }

    #[test]
    fn test_align_to_page() {
        assert_eq!(align_to_page(0), 0);
        assert_eq!(align_to_page(1), PAGE_SIZE as u64);
        assert_eq!(align_to_page(4095), PAGE_SIZE as u64);
        assert_eq!(align_to_page(4096), PAGE_SIZE as u64);
        assert_eq!(align_to_page(4097), 2 * PAGE_SIZE as u64);
        assert_eq!(align_to_page(8192), 2 * PAGE_SIZE as u64);
    }

    #[test]
    fn test_calculate_weights_offset_v1() {
        // Header (48) + graph (100) = 148 -> align to 4096
        assert_eq!(HolbHeader::calculate_weights_offset(100), 4096);
        // Header (48) + graph (4000) = 4048 -> align to 4096
        assert_eq!(HolbHeader::calculate_weights_offset(4000), 4096);
        // Header (48) + graph (4048) = 4096 -> align to 4096
        assert_eq!(HolbHeader::calculate_weights_offset(4048), 4096);
        // Header (48) + graph (4049) = 4097 -> align to 8192
        assert_eq!(HolbHeader::calculate_weights_offset(4049), 8192);
    }

    #[test]
    fn test_calculate_weights_offset_v2() {
        // Header (80) + graph (100) + sections (100) = 280 -> align to 4096
        assert_eq!(HolbHeaderV2::calculate_weights_offset(100, 100), 4096);
    }

    #[test]
    fn test_calculate_models_offset() {
        // Header (64) + index (100) = 164 -> align to 4096
        assert_eq!(HolmHeader::calculate_models_offset(100), 4096);
    }

    #[test]
    fn test_detect_holb_version() {
        let mut buf = [0u8; 8];
        buf[0..4].copy_from_slice(HOLB_MAGIC);
        buf[4..8].copy_from_slice(&1u32.to_le_bytes());
        assert_eq!(detect_holb_version(&buf).unwrap(), 1);

        buf[4..8].copy_from_slice(&2u32.to_le_bytes());
        assert_eq!(detect_holb_version(&buf).unwrap(), 2);
    }

    #[test]
    fn test_detect_holb_version_invalid_magic() {
        let buf = [b'J', b'U', b'N', b'K', 1, 0, 0, 0];
        assert!(detect_holb_version(&buf).is_err());
    }

    #[test]
    fn test_holb_validate() {
        let header = HolbHeader::new();
        assert!(header.validate().is_ok());

        let mut bad_header = HolbHeader::new();
        bad_header.version = 99;
        assert!(bad_header.validate().is_err());
    }

    #[test]
    fn test_holb_v2_validate() {
        let header = HolbHeaderV2::new();
        assert!(header.validate().is_ok());

        let mut bad_header = HolbHeaderV2::new();
        bad_header.version = 1; // Wrong version for V2
        assert!(bad_header.validate().is_err());
    }

    #[test]
    fn test_holm_validate() {
        let mut header = HolmHeader::new();
        header.model_count = 1;
        assert!(header.validate().is_ok());

        let empty_header = HolmHeader::new();
        assert!(empty_header.validate().is_err()); // model_count == 0
    }

    #[test]
    fn test_from_bytes_too_small() {
        let small_buf = [0u8; 10];
        assert!(HolbHeader::from_bytes(&small_buf).is_err());
        assert!(HolbHeaderV2::from_bytes(&small_buf).is_err());
        assert!(HolmHeader::from_bytes(&small_buf).is_err());
    }

    #[test]
    fn test_pipeline_entry_from_bytes_truncated() {
        let buf = [0u8; 5]; // Too small
        assert!(PipelineModelEntry::from_bytes(&buf).is_err());
    }

    #[test]
    fn test_crc32() {
        // Empty data
        assert_eq!(crc32(&[]), 0);

        // Known test vectors
        assert_eq!(crc32(b"123456789"), 0xCBF4_3926);

        // Consistency check
        let data = b"Hello, World!";
        let checksum1 = crc32(data);
        let checksum2 = crc32(data);
        assert_eq!(checksum1, checksum2);
        assert_ne!(checksum1, 0);
    }

    #[test]
    fn test_crc32_table_generated() {
        // Verify table was generated at compile time
        assert_ne!(CRC32_TABLE[1], 0);
        assert_ne!(CRC32_TABLE[255], 0);
    }

    // ========================================================================
    // Edge Case Tests (TASK-179)
    // ========================================================================

    // --- detect_holb_version() edge cases ---

    #[test]
    fn test_detect_holb_version_empty_buffer() {
        let buf: [u8; 0] = [];
        let result = detect_holb_version(&buf);
        assert!(result.is_err());
        let err_msg = result.unwrap_err().to_string();
        assert!(err_msg.contains("too small"));
    }

    #[test]
    fn test_detect_holb_version_truncated_buffers() {
        // Test all truncation points from 1 to 7 bytes
        for size in 1..8 {
            let mut buf = vec![0u8; size];
            if size >= 4 {
                buf[0..4].copy_from_slice(HOLB_MAGIC);
            }
            let result = detect_holb_version(&buf);
            assert!(result.is_err(), "Expected error for buffer size {size}");
        }
    }

    #[test]
    fn test_detect_holb_version_exactly_8_bytes() {
        let mut buf = [0u8; 8];
        buf[0..4].copy_from_slice(HOLB_MAGIC);
        buf[4..8].copy_from_slice(&42u32.to_le_bytes());
        let result = detect_holb_version(&buf);
        assert_eq!(result.unwrap(), 42);
    }

    #[test]
    fn test_detect_holb_version_various_invalid_magic() {
        let test_cases: &[&[u8; 4]] = &[
            b"\x00\x00\x00\x00", // null bytes
            b"\xFF\xFF\xFF\xFF", // all 0xFF
            b"HOLM",             // wrong format (HOLM not HOLB)
            b"holb",             // lowercase
            b"HOL\x00",          // partial magic with null
            b"HULB",             // one character off
        ];

        for magic in test_cases {
            let mut buf = [0u8; 8];
            buf[0..4].copy_from_slice(*magic);
            buf[4..8].copy_from_slice(&1u32.to_le_bytes());
            let result = detect_holb_version(&buf);
            assert!(result.is_err(), "Expected error for magic {magic:?}");
        }
    }

    #[test]
    fn test_detect_holb_version_max_version() {
        let mut buf = [0u8; 8];
        buf[0..4].copy_from_slice(HOLB_MAGIC);
        buf[4..8].copy_from_slice(&u32::MAX.to_le_bytes());
        let result = detect_holb_version(&buf);
        assert_eq!(result.unwrap(), u32::MAX);
    }

    #[test]
    fn test_detect_holb_version_with_extra_data() {
        // Buffer larger than needed
        let mut buf = [0u8; 1024];
        buf[0..4].copy_from_slice(HOLB_MAGIC);
        buf[4..8].copy_from_slice(&3u32.to_le_bytes());
        let result = detect_holb_version(&buf);
        assert_eq!(result.unwrap(), 3);
    }

    // --- align_to_page() edge cases ---

    #[test]
    fn test_align_to_page_exact_boundaries() {
        // Values that are exactly on page boundaries
        for multiple in 0..10 {
            let boundary = multiple * PAGE_SIZE as u64;
            assert_eq!(
                align_to_page(boundary),
                boundary,
                "Value {boundary} should stay at boundary"
            );
        }
    }

    #[test]
    fn test_align_to_page_just_over_boundary() {
        for multiple in 0..10 {
            let boundary = multiple * PAGE_SIZE as u64;
            let next_boundary = (multiple + 1) * PAGE_SIZE as u64;
            if boundary > 0 {
                // Just over the boundary should round up
                assert_eq!(
                    align_to_page(boundary + 1),
                    next_boundary,
                    "Value {boundary} + 1 should round up to {next_boundary}"
                );
            }
        }
    }

    #[test]
    fn test_align_to_page_just_under_boundary() {
        for multiple in 1..10 {
            let boundary = multiple * PAGE_SIZE as u64;
            // Just under the boundary should round up to it
            assert_eq!(
                align_to_page(boundary - 1),
                boundary,
                "Value {boundary} - 1 should round up to {boundary}"
            );
        }
    }

    #[test]
    fn test_align_to_page_large_values() {
        // Test with values near u64::MAX that won't overflow
        let large_aligned = u64::MAX - (u64::MAX % PAGE_SIZE as u64);
        // This value is already aligned
        let test_val = large_aligned - PAGE_SIZE as u64;
        assert_eq!(align_to_page(test_val), test_val);
    }

    #[test]
    fn test_align_to_page_mid_page() {
        // Middle of a page
        assert_eq!(align_to_page(2048), PAGE_SIZE as u64);
        assert_eq!(align_to_page(6144), 2 * PAGE_SIZE as u64); // 6144 = 4096 + 2048
    }

    // --- crc32() edge cases ---

    #[test]
    fn test_crc32_single_byte() {
        // Each byte value should produce a unique non-zero checksum
        let checksums: Vec<u32> = (0u8..=255).map(|b| crc32(&[b])).collect();

        // Verify uniqueness (no collisions for single bytes)
        let mut sorted = checksums.clone();
        sorted.sort_unstable();
        sorted.dedup();
        assert_eq!(sorted.len(), 256, "Single-byte CRCs should be unique");
    }

    #[test]
    fn test_crc32_all_zeros() {
        let zeros = vec![0u8; 1024];
        let checksum = crc32(&zeros);
        // Should be non-zero and consistent
        assert_ne!(checksum, 0);
        assert_eq!(crc32(&zeros), checksum);
    }

    #[test]
    fn test_crc32_all_ones() {
        let ones = vec![0xFF; 1024];
        let checksum = crc32(&ones);
        // Should be non-zero and consistent
        assert_ne!(checksum, 0);
        assert_eq!(crc32(&ones), checksum);
    }

    #[test]
    fn test_crc32_incremental_pattern() {
        let pattern: Vec<u8> = (0..=255).collect();
        let checksum = crc32(&pattern);
        // Should be non-zero
        assert_ne!(checksum, 0);

        // Same pattern twice should give different result
        let double: Vec<u8> = pattern.iter().chain(pattern.iter()).copied().collect();
        assert_ne!(crc32(&double), checksum);
    }

    #[test]
    fn test_crc32_large_data() {
        // 1 MB of data
        let large = vec![0xAB; 1024 * 1024];
        let checksum = crc32(&large);
        assert_ne!(checksum, 0);
        // Verify consistency
        assert_eq!(crc32(&large), checksum);
    }

    #[test]
    fn test_crc32_order_matters() {
        let a = crc32(&[1, 2, 3, 4]);
        let b = crc32(&[4, 3, 2, 1]);
        assert_ne!(a, b, "CRC should be order-dependent");
    }

    // --- Header from_bytes edge cases ---

    #[test]
    fn test_holb_from_bytes_exactly_minimum() {
        // Exactly 48 bytes (minimum for V1)
        let header = HolbHeader::new();
        let bytes = header.to_bytes();
        assert_eq!(bytes.len(), HOLB_HEADER_SIZE_V1);
        let parsed = HolbHeader::from_bytes(&bytes).unwrap();
        assert_eq!(parsed, header);
    }

    #[test]
    fn test_holb_v2_from_bytes_exactly_minimum() {
        // Exactly 80 bytes (minimum for V2)
        let header = HolbHeaderV2::new();
        let bytes = header.to_bytes();
        assert_eq!(bytes.len(), HOLB_HEADER_SIZE_V2);
        let parsed = HolbHeaderV2::from_bytes(&bytes).unwrap();
        assert_eq!(parsed, header);
    }

    #[test]
    fn test_holm_from_bytes_exactly_minimum() {
        // Exactly 64 bytes (minimum for HOLM)
        let header = HolmHeader::new();
        let bytes = header.to_bytes();
        assert_eq!(bytes.len(), HOLM_HEADER_SIZE);
        let parsed = HolmHeader::from_bytes(&bytes).unwrap();
        assert_eq!(parsed, header);
    }

    #[test]
    fn test_header_from_bytes_truncated_at_various_points() {
        let header = HolbHeader::new();
        let bytes = header.to_bytes();

        // Test truncation at every point
        for i in 0..HOLB_HEADER_SIZE_V1 {
            let truncated = &bytes[..i];
            let result = HolbHeader::from_bytes(truncated);
            assert!(
                result.is_err(),
                "Should fail with {i} bytes (need {HOLB_HEADER_SIZE_V1})"
            );
        }
    }

    #[test]
    fn test_header_v2_from_bytes_truncated_at_various_points() {
        let header = HolbHeaderV2::new();
        let bytes = header.to_bytes();

        for i in 0..HOLB_HEADER_SIZE_V2 {
            let truncated = &bytes[..i];
            let result = HolbHeaderV2::from_bytes(truncated);
            assert!(
                result.is_err(),
                "V2 should fail with {i} bytes (need {HOLB_HEADER_SIZE_V2})"
            );
        }
    }

    #[test]
    fn test_holm_from_bytes_truncated_at_various_points() {
        let header = HolmHeader::new();
        let bytes = header.to_bytes();

        for i in 0..HOLM_HEADER_SIZE {
            let truncated = &bytes[..i];
            let result = HolmHeader::from_bytes(truncated);
            assert!(
                result.is_err(),
                "HOLM should fail with {i} bytes (need {HOLM_HEADER_SIZE})"
            );
        }
    }

    #[test]
    fn test_header_with_max_values() {
        let mut header = HolbHeader::new();
        header.graph_offset = u64::MAX;
        header.graph_size = u64::MAX;
        header.weights_offset = u64::MAX;
        header.weights_size = u64::MAX;
        header.graph_checksum = u32::MAX;
        header.weights_checksum = u32::MAX;

        let bytes = header.to_bytes();
        let parsed = HolbHeader::from_bytes(&bytes).unwrap();
        assert_eq!(parsed.graph_offset, u64::MAX);
        assert_eq!(parsed.graph_size, u64::MAX);
        assert_eq!(parsed.weights_offset, u64::MAX);
        assert_eq!(parsed.weights_size, u64::MAX);
        assert_eq!(parsed.graph_checksum, u32::MAX);
        assert_eq!(parsed.weights_checksum, u32::MAX);
    }

    #[test]
    fn test_header_with_zero_values() {
        let mut header = HolbHeader::new();
        header.graph_offset = 0;
        header.graph_size = 0;
        header.weights_offset = 0;
        header.weights_size = 0;
        header.graph_checksum = 0;
        header.weights_checksum = 0;

        let bytes = header.to_bytes();
        let parsed = HolbHeader::from_bytes(&bytes).unwrap();
        assert_eq!(parsed.graph_offset, 0);
        assert_eq!(parsed.graph_size, 0);
    }

    #[test]
    fn test_header_from_bytes_corrupted_magic_mid_buffer() {
        let mut header = HolbHeader::new();
        header.graph_size = 1024;
        let mut bytes = header.to_bytes();
        // Corrupt just one byte of magic
        bytes[2] = 0xFF;
        let result = HolbHeader::from_bytes(&bytes);
        assert!(result.is_err());
    }

    // --- PipelineModelEntry edge cases ---

    #[test]
    fn test_pipeline_entry_empty_name() {
        let entry = PipelineModelEntry::new("", 4096, 1024, 0xDEAD_BEEF);
        let bytes = entry.to_bytes();
        let (parsed, consumed) = PipelineModelEntry::from_bytes(&bytes).unwrap();

        assert_eq!(parsed.name, "");
        assert_eq!(consumed, entry.serialized_size());
        assert_eq!(entry.serialized_size(), 2 + 20); // name_len + name + fields
    }

    #[test]
    fn test_pipeline_entry_long_name() {
        let long_name = "a".repeat(1000);
        let entry = PipelineModelEntry::new(&long_name, 4096, 1024, 0xDEAD_BEEF);
        let bytes = entry.to_bytes();
        let (parsed, consumed) = PipelineModelEntry::from_bytes(&bytes).unwrap();

        assert_eq!(parsed.name, long_name);
        assert_eq!(consumed, entry.serialized_size());
    }

    #[test]
    fn test_pipeline_entry_max_name_length() {
        // Maximum u16 length
        let max_name = "x".repeat(u16::MAX as usize);
        let entry = PipelineModelEntry::new(&max_name, 0, 0, 0);
        let bytes = entry.to_bytes();
        let (parsed, _) = PipelineModelEntry::from_bytes(&bytes).unwrap();
        assert_eq!(parsed.name.len(), u16::MAX as usize);
    }

    #[test]
    fn test_pipeline_entry_unicode_name() {
        let unicode_name = "模型-αβγ-🚀";
        let entry = PipelineModelEntry::new(unicode_name, 4096, 1024, 0);
        let bytes = entry.to_bytes();
        let (parsed, _) = PipelineModelEntry::from_bytes(&bytes).unwrap();
        assert_eq!(parsed.name, unicode_name);
    }

    #[test]
    fn test_pipeline_entry_truncated_name_length_only() {
        // Only 1 byte when we need 2 for name length
        let buf = [0u8; 1];
        let result = PipelineModelEntry::from_bytes(&buf);
        assert!(result.is_err());
    }

    #[test]
    fn test_pipeline_entry_truncated_after_name_length() {
        // Has name length but no name
        let buf = [5u8, 0]; // name_len = 5, but no name bytes
        let result = PipelineModelEntry::from_bytes(&buf);
        assert!(result.is_err());
    }

    #[test]
    fn test_pipeline_entry_truncated_in_name() {
        // Has partial name
        let mut buf = vec![5u8, 0]; // name_len = 5
        buf.extend_from_slice(b"abc"); // only 3 of 5 bytes
        let result = PipelineModelEntry::from_bytes(&buf);
        assert!(result.is_err());
    }

    #[test]
    fn test_pipeline_entry_truncated_after_name() {
        // Has full name but no offset/size/checksum
        let mut buf = vec![3u8, 0]; // name_len = 3
        buf.extend_from_slice(b"abc"); // full name
                                       // Missing: offset(8) + size(8) + checksum(4) = 20 bytes
        let result = PipelineModelEntry::from_bytes(&buf);
        assert!(result.is_err());
    }

    #[test]
    fn test_pipeline_entry_max_offset_size_checksum() {
        let entry = PipelineModelEntry::new("test", u64::MAX, u64::MAX, u32::MAX);
        let bytes = entry.to_bytes();
        let (parsed, _) = PipelineModelEntry::from_bytes(&bytes).unwrap();

        assert_eq!(parsed.offset, u64::MAX);
        assert_eq!(parsed.size, u64::MAX);
        assert_eq!(parsed.checksum, u32::MAX);
    }

    // --- Header validation edge cases ---

    #[test]
    fn test_holb_validate_invalid_magic() {
        let mut header = HolbHeader::new();
        header.magic = *b"JUNK";
        let result = header.validate();
        assert!(result.is_err());
    }

    #[test]
    fn test_holb_v2_validate_wrong_version() {
        let mut header = HolbHeaderV2::new();
        header.version = 1; // V2 should have version 2
        let result = header.validate();
        assert!(result.is_err());
    }

    #[test]
    fn test_holm_validate_zero_models() {
        let header = HolmHeader::new(); // model_count = 0
        let result = header.validate();
        assert!(result.is_err());
    }

    #[test]
    fn test_holm_validate_wrong_version() {
        let mut header = HolmHeader::new();
        header.model_count = 1;
        header.version = 99;
        let result = header.validate();
        assert!(result.is_err());
    }

    // --- Offset calculation edge cases ---

    #[test]
    fn test_calculate_weights_offset_v1_zero_graph() {
        // Header (48) + graph (0) = 48 -> align to 4096
        assert_eq!(HolbHeader::calculate_weights_offset(0), 4096);
    }

    #[test]
    fn test_calculate_weights_offset_v1_exact_page() {
        // Header (48) + graph (4048) = 4096 -> should align to 4096
        assert_eq!(HolbHeader::calculate_weights_offset(4048), 4096);
    }

    #[test]
    fn test_calculate_weights_offset_v2_zero_sizes() {
        // Header (80) + graph (0) + sections (0) = 80 -> align to 4096
        assert_eq!(HolbHeaderV2::calculate_weights_offset(0, 0), 4096);
    }

    #[test]
    fn test_calculate_models_offset_zero_index() {
        // Header (64) + index (0) = 64 -> align to 4096
        assert_eq!(HolmHeader::calculate_models_offset(0), 4096);
    }

    #[test]
    fn test_calculate_models_offset_large_index() {
        // Header (64) + index (10000) = 10064 -> align to 12288 (3 * 4096)
        assert_eq!(HolmHeader::calculate_models_offset(10000), 12288);
    }

    // --- Serialization boundary tests ---

    #[test]
    fn test_header_bytes_boundary_alignment() {
        // Verify that serialized headers have correct byte boundaries
        let v1 = HolbHeader::new();
        let v1_bytes = v1.to_bytes();
        // Magic at 0-4, version at 4-8, etc.
        assert_eq!(&v1_bytes[0..4], HOLB_MAGIC);
        assert_eq!(u32::from_le_bytes(v1_bytes[4..8].try_into().unwrap()), 1);

        let v2 = HolbHeaderV2::new();
        let v2_bytes = v2.to_bytes();
        assert_eq!(&v2_bytes[0..4], HOLB_MAGIC);
        assert_eq!(u32::from_le_bytes(v2_bytes[4..8].try_into().unwrap()), 2);

        let holm = HolmHeader::new();
        let holm_bytes = holm.to_bytes();
        assert_eq!(&holm_bytes[0..4], HOLM_MAGIC);
        assert_eq!(u32::from_le_bytes(holm_bytes[4..8].try_into().unwrap()), 1);
    }

    #[test]
    fn test_header_static_sizes() {
        // Ensure header sizes are as documented
        assert_eq!(HolbHeader::header_size(), 48);
        assert_eq!(HolbHeaderV2::header_size(), 80);
        assert_eq!(HolmHeader::header_size(), 64);
    }

    #[test]
    fn test_v2_has_sections_boundary() {
        let mut header = HolbHeaderV2::new();
        assert!(!header.has_sections());

        header.sections_count = 1;
        assert!(header.has_sections());

        header.sections_count = u32::MAX;
        assert!(header.has_sections());
    }
}
