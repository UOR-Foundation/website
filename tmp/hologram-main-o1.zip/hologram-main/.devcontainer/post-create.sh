#!/bin/bash
set -e

echo "Running post-create setup for hologram..."

cd /workspace

# Install/update Claude Code CLI to latest
echo "Installing Claude Code CLI (native mode)..."
curl -fsSL https://claude.ai/install.sh | bash
export PATH="/home/vscode/.claude/bin:$PATH"
claude --version || echo "Warning: Claude Code CLI not available"

# Set up Claude Code global commands and permissions
echo "Setting up Claude Code commands and permissions..."
mkdir -p ~/.claude/commands

# Global safety permissions (ask before destructive ops / sensitive reads)
if [ ! -f ~/.claude/settings.json ]; then
  cat > ~/.claude/settings.json << 'SETTINGS'
{
  "permissions": {
    "ask": [
      "Bash(rm -rf:*)",
      "Bash(rm -fr:*)",
      "Bash(sudo:*)",
      "Bash(chmod 777:*)",
      "Bash(git push --force:*)",
      "Bash(git push -f:*)",
      "Bash(git reset --hard:*)",
      "Bash(git clean -fd:*)",
      "Bash(npm publish:*)",
      "Bash(eval:*)",
      "Read(.env)",
      "Read(.env.*)",
      "Read(**/.env)",
      "Read(**/.env.*)",
      "Read(~/.ssh/**)",
      "Read(~/.aws/**)",
      "Read(**/*credential*)",
      "Read(**/*secret*)",
      "Read(**/*.pem)",
      "Read(**/*.key)"
    ]
  }
}
SETTINGS
fi

# Download slash commands from gists
GISTS=(
  "commit-smart:d4b3870178667475b08e1f48d6cdbc30"
  "transfer-context:e4be0e8750343d9cbafdaab88366115c"
  "debug:6833c01f597c82912af5aca4e3467a35"
  "refactor:cd321a0ada16963867ad8984f44922cf"
  "update-claudemd:916e4f2cbcd96f487b2845edaed469a3"
  "setup-repo:e402188c89aab94de61df3da1c10d6ca"
  "setup-claude-code:3f6b6ccdc1f24911cfdec78dbc334547"
)

for entry in "${GISTS[@]}"; do
  name="${entry%%:*}"
  gist_id="${entry##*:}"
  if [ ! -f ~/.claude/commands/"${name}.md" ]; then
    curl -sfL "https://gist.githubusercontent.com/SilenNaihin/${gist_id}/raw" \
      -o ~/.claude/commands/"${name}.md" \
      && echo "  Installed /$(echo "$name")" \
      || echo "  Warning: failed to download ${name}"
  fi
done

# Install Python tools for FFI bindings (UniFFI auto-formats generated code)
echo "Installing Python tools for FFI bindings..."
pip3 install --break-system-packages --user yapf black 2>/dev/null || \
  pip3 install --user yapf black 2>/dev/null || \
  echo "Warning: Could not install Python formatters (yapf, black)"

# Configure git hooks
echo "Configuring git hooks..."
git config core.hooksPath .githooks

# Ensure toolchain components are installed
echo "Installing Rust toolchain components..."
rustup component add rustfmt clippy rust-analyzer

# Install cargo-watch for development
echo "Installing cargo-watch..."
cargo install cargo-watch 2>/dev/null || echo "Warning: Could not install cargo-watch"

# Cache Rust dependencies
echo "Caching Rust dependencies..."
cargo fetch --locked 2>/dev/null || cargo fetch

# Verify workspace compiles
echo "Verifying workspace compiles..."
cargo check

echo ""
echo "Post-create setup complete!"
echo "  Claude Code commands: $(ls ~/.claude/commands/*.md 2>/dev/null | wc -l) installed"
echo "  Git hooks: $(git config core.hooksPath)"
echo ""
echo "Ready to develop!"
