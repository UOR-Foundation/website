//! Thread partitioning (Stage 6).
//!
//! This module partitions work across threads with static assignment:
//! - Builds parallel levels (nodes within a level have no dependencies)
//! - Assigns thread IDs based on work balance
//! - Respects `parallel_threshold` to avoid overhead on small tasks

mod decompose;
mod schedule;

use crate::graph::CompileGraph;
use crate::pipeline::{ExecutionSchedule, ParallelLevel};
pub use decompose::{
    choose_matmul_strategy, decompose_matmuls, generate_matmul_blocks, matmul_cost,
    should_decompose, DecomposeConfig, MatMulBlock, MatMulStrategy,
};
pub use schedule::{build_parallel_levels, critical_path_length, parallelism_ratio};

/// Partition work across threads with static assignment.
///
/// This function:
/// 1. Builds parallel levels from the dependency graph
/// 2. Filters levels to only include nodes exceeding the parallel threshold
/// 3. Assigns thread IDs to nodes for load balancing
/// 4. Records assignments in the graph nodes
///
/// # Arguments
///
/// * `graph` - The compile graph to partition
/// * `parallel_threshold` - Minimum element count to warrant parallelization
///
/// # Returns
///
/// An `ExecutionSchedule` with parallel levels for runtime execution.
pub fn partition_threads(graph: &mut CompileGraph, parallel_threshold: usize) -> ExecutionSchedule {
    // Collect node info for level building
    let node_ids: Vec<u32> = graph.nodes().map(|(id, _)| id).collect();
    let edges = graph.edges();

    if node_ids.is_empty() {
        return ExecutionSchedule::default();
    }

    // Build parallel levels
    let raw_levels = build_parallel_levels(&node_ids, &edges);

    // Filter and process levels based on threshold
    let levels: Vec<ParallelLevel> = raw_levels
        .into_iter()
        .map(|level| filter_level_by_threshold(graph, level, parallel_threshold))
        .collect();

    // Assign thread IDs to nodes
    assign_thread_ids(graph, &levels);

    ExecutionSchedule { levels }
}

/// Filter a parallel level based on the parallel threshold.
///
/// Nodes with fewer elements than the threshold are kept but marked
/// as sequential (`thread_id` = 0). Nodes exceeding the threshold get
/// assigned to different threads for parallel execution.
fn filter_level_by_threshold(
    graph: &CompileGraph,
    level: ParallelLevel,
    parallel_threshold: usize,
) -> ParallelLevel {
    // For now, we keep all nodes in the level but filter will be
    // used for thread assignment decisions
    let filtered_ids: Vec<u32> = level
        .node_ids
        .into_iter()
        .filter(|&id| {
            graph.get_node(id).is_some_and(|node| {
                let element_count: usize = node.shape.iter().product();
                // Keep nodes that are worth parallelizing or are large enough
                element_count >= parallel_threshold || is_expensive_op(&node.op)
            })
        })
        .collect();

    ParallelLevel {
        node_ids: filtered_ids,
    }
}

/// Check if an operation is expensive enough to always include.
fn is_expensive_op(op: &crate::graph::OpKind) -> bool {
    matches!(
        op,
        crate::graph::OpKind::MatMul { .. }
            | crate::graph::OpKind::Softmax { .. }
            | crate::graph::OpKind::CallLayer { .. }
    )
}

/// Assign thread IDs to nodes based on their level and position.
///
/// Nodes in the same level can run in parallel, so they get different
/// thread IDs. The assignment uses round-robin within each level.
fn assign_thread_ids(graph: &mut CompileGraph, levels: &[ParallelLevel]) {
    // Maximum threads (could be configurable)
    let max_threads = 8usize;

    for level in levels {
        for (idx, &node_id) in level.node_ids.iter().enumerate() {
            if let Some(node) = graph.get_node_mut(node_id) {
                // Round-robin thread assignment within level
                #[allow(clippy::cast_possible_truncation)]
                let thread_id = (idx % max_threads) as u32;
                node.thread_id = Some(thread_id);
            }
        }
    }
}

/// Get the total number of parallel levels.
#[must_use]
pub fn level_count(schedule: &ExecutionSchedule) -> usize {
    schedule.levels.len()
}

/// Get the maximum width (parallelism) across all levels.
#[must_use]
pub fn max_parallelism(schedule: &ExecutionSchedule) -> usize {
    schedule
        .levels
        .iter()
        .map(|level| level.node_ids.len())
        .max()
        .unwrap_or(0)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpKind, OpNode, OperationGraph};

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    #[test]
    fn test_partition_threads_empty_graph() {
        let mut graph = make_graph(vec![], vec![]);
        let schedule = partition_threads(&mut graph, 4096);
        assert!(schedule.levels.is_empty());
    }

    #[test]
    fn test_partition_threads_single_node() {
        let mut graph = make_graph(
            vec![OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32)],
            vec![],
        );

        let schedule = partition_threads(&mut graph, 1024);
        assert_eq!(level_count(&schedule), 1);
    }

    #[test]
    fn test_partition_threads_linear_chain() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64, 64], DType::F32),
                OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3)],
        );

        let schedule = partition_threads(&mut graph, 1024);

        // Linear chain = 4 levels, one node each
        assert_eq!(level_count(&schedule), 4);
        assert_eq!(max_parallelism(&schedule), 1);
    }

    #[test]
    fn test_partition_threads_parallel_nodes() {
        // Input -> [Relu, Sigmoid, Tanh] -> Add -> Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64, 64], DType::F32),
                OpNode::new(3, OpKind::Tanh, vec![64, 64], DType::F32),
                OpNode::new(4, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(5, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (0, 2), (0, 3), (1, 4), (2, 4), (3, 4), (4, 5)],
        );

        let schedule = partition_threads(&mut graph, 1024);

        // Should have parallel level with 3 nodes
        assert!(max_parallelism(&schedule) >= 3);
    }

    #[test]
    fn test_partition_threads_assigns_thread_ids() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64, 64], DType::F32),
                OpNode::new(3, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(4, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (0, 2), (1, 3), (2, 3), (3, 4)],
        );

        partition_threads(&mut graph, 1024);

        // Check that parallel nodes have different thread IDs
        let relu_thread = graph.get_node(1).and_then(|n| n.thread_id);
        let sigmoid_thread = graph.get_node(2).and_then(|n| n.thread_id);

        // Both should have thread IDs assigned
        assert!(relu_thread.is_some());
        assert!(sigmoid_thread.is_some());

        // They should have different thread IDs since they're parallel
        assert_ne!(relu_thread, sigmoid_thread);
    }

    #[test]
    fn test_partition_threads_respects_threshold() {
        // Small tensors below threshold
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![4, 4], DType::F32), // 16 elements
                OpNode::new(1, OpKind::Relu, vec![4, 4], DType::F32),
                OpNode::new(2, OpKind::Output, vec![4, 4], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let schedule = partition_threads(&mut graph, 1024); // Threshold = 1024

        // Nodes below threshold should be filtered out
        // Only Input is kept (as a source node type)
        let total_nodes: usize = schedule.levels.iter().map(|l| l.node_ids.len()).sum();
        assert!(total_nodes < 3); // Some nodes filtered
    }

    #[test]
    fn test_partition_threads_matmul_always_included() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![4, 4], DType::F32),
                OpNode::new(1, OpKind::Input, vec![4, 4], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul { m: 4, k: 4, n: 4 },
                    vec![4, 4],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Output, vec![4, 4], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        let schedule = partition_threads(&mut graph, 10000); // Very high threshold

        // MatMul should still be included even with high threshold
        let has_matmul = schedule
            .levels
            .iter()
            .any(|level| level.node_ids.contains(&2));
        assert!(has_matmul);
    }

    #[test]
    fn test_partition_threads_diamond_pattern() {
        //     Input(0)
        //      / \
        //   Relu  Sigmoid
        //      \ /
        //      Add
        //       |
        //    Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![1024], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![1024], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![1024], DType::F32),
                OpNode::new(3, OpKind::Add, vec![1024], DType::F32),
                OpNode::new(4, OpKind::Output, vec![1024], DType::F32),
            ],
            vec![(0, 1), (0, 2), (1, 3), (2, 3), (3, 4)],
        );

        let schedule = partition_threads(&mut graph, 512);

        // Should have at least one level with 2 parallel nodes (Relu and Sigmoid)
        let has_parallel_level = schedule
            .levels
            .iter()
            .any(|level| level.node_ids.len() >= 2);
        assert!(has_parallel_level);
    }

    #[test]
    fn test_level_count() {
        let schedule = ExecutionSchedule {
            levels: vec![
                ParallelLevel { node_ids: vec![0] },
                ParallelLevel {
                    node_ids: vec![1, 2],
                },
                ParallelLevel { node_ids: vec![3] },
            ],
        };

        assert_eq!(level_count(&schedule), 3);
    }

    #[test]
    fn test_max_parallelism() {
        let schedule = ExecutionSchedule {
            levels: vec![
                ParallelLevel { node_ids: vec![0] },
                ParallelLevel {
                    node_ids: vec![1, 2, 3, 4],
                },
                ParallelLevel { node_ids: vec![5] },
            ],
        };

        assert_eq!(max_parallelism(&schedule), 4);
    }

    #[test]
    fn test_partition_threads_complex_dag() {
        //       Input(0)
        //      /   |   \
        //     R(1) S(2) T(3)
        //       \  |  /
        //        Add(4)
        //         |
        //       Relu(5)
        //         |
        //      Output(6)
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2048], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![2048], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![2048], DType::F32),
                OpNode::new(3, OpKind::Tanh, vec![2048], DType::F32),
                OpNode::new(4, OpKind::Add, vec![2048], DType::F32),
                OpNode::new(5, OpKind::Relu, vec![2048], DType::F32),
                OpNode::new(6, OpKind::Output, vec![2048], DType::F32),
            ],
            vec![
                (0, 1),
                (0, 2),
                (0, 3),
                (1, 4),
                (2, 4),
                (3, 4),
                (4, 5),
                (5, 6),
            ],
        );

        let schedule = partition_threads(&mut graph, 1024);

        // Should have levels for: Input, [R,S,T], Add, Relu, Output
        assert!(level_count(&schedule) >= 4);
        assert!(max_parallelism(&schedule) >= 3);
    }

    #[test]
    fn test_thread_id_round_robin() {
        // Create many parallel nodes to test round-robin
        let mut nodes = vec![OpNode::new(0, OpKind::Input, vec![4096], DType::F32)];
        let mut edges = Vec::new();

        // Add 16 parallel Relu nodes
        for i in 1..=16 {
            nodes.push(OpNode::new(i, OpKind::Relu, vec![4096], DType::F32));
            edges.push((0, i));
        }

        // Add sink node
        nodes.push(OpNode::new(17, OpKind::Output, vec![4096], DType::F32));
        for i in 1..=16 {
            edges.push((i, 17));
        }

        let mut graph = make_graph(nodes, edges);
        partition_threads(&mut graph, 1024);

        // Check that thread IDs wrap around (max_threads = 8)
        let thread_ids: Vec<u32> = (1..=16)
            .filter_map(|i| graph.get_node(i).and_then(|n| n.thread_id))
            .collect();

        // Should have some IDs in 0..8 range
        assert!(thread_ids.iter().all(|&id| id < 8));
        // Should have multiple different IDs
        let unique_ids: std::collections::HashSet<_> = thread_ids.iter().collect();
        assert!(unique_ids.len() > 1);
    }
}
