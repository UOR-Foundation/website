//! HTTP range-based constant provider.
//!
//! This provider fetches constant bytes via HTTP range requests and caches
//! chunks locally to avoid repeated network roundtrips. Enable with
//! `--features const-provider-http`.

use crate::core::const_provider::{ConstChunk, ConstProvider};
use crate::error::{BackendError, BackendResult};
use std::collections::{HashMap, VecDeque};
use std::io::Read;
use std::sync::{Arc, Mutex};
use ureq::Agent;

struct LruCache {
    map: HashMap<usize, Arc<Vec<u8>>>,
    order: VecDeque<usize>,
    bytes: usize,
    cap: usize,
}

impl LruCache {
    fn new(cap: usize) -> Self {
        Self {
            map: HashMap::new(),
            order: VecDeque::new(),
            bytes: 0,
            cap,
        }
    }

    fn get(&mut self, key: usize) -> Option<Arc<Vec<u8>>> {
        if let Some(val) = self.map.get(&key) {
            self.order.retain(|k| *k != key);
            self.order.push_back(key);
            return Some(val.clone());
        }
        None
    }

    fn insert(&mut self, key: usize, val: Arc<Vec<u8>>) {
        if self.map.contains_key(&key) {
            return;
        }
        self.bytes = self.bytes.saturating_add(val.len());
        self.order.push_back(key);
        self.map.insert(key, val);
        while self.bytes > self.cap {
            if let Some(evict) = self.order.pop_front() {
                if let Some(v) = self.map.remove(&evict) {
                    self.bytes = self.bytes.saturating_sub(v.len());
                }
            } else {
                break;
            }
        }
    }
}

/// HTTP-backed constant provider using Range requests.
pub struct HttpConstProvider {
    url: String,
    len: usize,
    chunk_size: usize,
    cache: Mutex<LruCache>,
    client: Agent,
}

impl HttpConstProvider {
    /// Discover the content length via HEAD or GET and construct the provider.
    pub fn new(
        url: impl Into<String>,
        chunk_size: usize,
        max_cached_bytes: usize,
    ) -> BackendResult<Self> {
        let url = url.into();
        let client = Agent::new();
        let len = Self::content_length(&client, &url)?;
        let chunk = chunk_size.max(4096);
        let cache_cap = max_cached_bytes.max(chunk);
        Ok(Self {
            url,
            len,
            chunk_size: chunk,
            cache: Mutex::new(LruCache::new(cache_cap)),
            client,
        })
    }

    fn content_length(client: &Agent, url: &str) -> BackendResult<usize> {
        let head = client.head(url).call();
        let resp = match head {
            Ok(resp) => resp,
            Err(_) => client.get(url).call().map_err(|e| {
                BackendError::buffer(format!("HTTP const provider GET failed: {e}"))
            })?,
        };
        let len_hdr = resp
            .header("Content-Length")
            .ok_or_else(|| BackendError::buffer("missing Content-Length"))?;
        len_hdr
            .parse::<usize>()
            .map_err(|e| BackendError::buffer(format!("invalid Content-Length: {e}")))
    }

    fn fetch_chunk(&self, start: usize) -> BackendResult<Arc<Vec<u8>>> {
        if start >= self.len {
            return Err(BackendError::buffer("offset past end of HTTP object"));
        }
        let end = start
            .saturating_add(self.chunk_size)
            .min(self.len)
            .saturating_sub(1);
        let range = format!("bytes={start}-{end}");
        let resp = self
            .client
            .get(&self.url)
            .set("Range", &range)
            .call()
            .map_err(|e| BackendError::buffer(format!("HTTP range request failed: {e}")))?;
        if !(resp.status() == 206 || resp.status() == 200) {
            return Err(BackendError::buffer(format!(
                "unexpected HTTP status {} for Range {}",
                resp.status(),
                range
            )));
        }
        let mut reader = resp.into_reader();
        let mut buf = Vec::with_capacity(self.chunk_size);
        reader
            .read_to_end(&mut buf)
            .map_err(|e| BackendError::buffer(format!("failed to read HTTP body: {e}")))?;
        if buf.is_empty() {
            return Err(BackendError::buffer("empty HTTP chunk"));
        }
        Ok(Arc::new(buf))
    }
}

impl ConstProvider for HttpConstProvider {
    fn len(&self) -> usize {
        self.len
    }

    fn read_at<'a>(&'a self, offset: usize, len: usize) -> BackendResult<ConstChunk<'a>> {
        if len > self.chunk_size {
            return Err(BackendError::buffer(format!(
                "HttpConstProvider request too large: {} > chunk_size {}",
                len, self.chunk_size
            )));
        }
        let chunk_start = (offset / self.chunk_size) * self.chunk_size;
        {
            let mut cache = self.cache.lock().expect("HTTP cache poisoned");
            if cache.get(chunk_start).is_none() {
                drop(cache);
                let fresh = self.fetch_chunk(chunk_start)?;
                let mut cache = self.cache.lock().expect("HTTP cache poisoned");
                cache.insert(chunk_start, fresh);
            }
        }
        let entry = {
            let mut cache = self.cache.lock().expect("HTTP cache poisoned");
            cache
                .get(chunk_start)
                .ok_or_else(|| BackendError::buffer("missing cached HTTP chunk"))?
        };
        let local_offset = offset - chunk_start;
        let end = local_offset
            .checked_add(len)
            .ok_or_else(|| BackendError::buffer("offset overflow"))?;
        if end > entry.len() {
            return Err(BackendError::buffer("HTTP chunk slice out of bounds"));
        }
        let ptr = unsafe { entry.as_ptr().add(local_offset) };
        let data = unsafe { std::slice::from_raw_parts(ptr, len) };
        Ok(ConstChunk { data })
    }
}
