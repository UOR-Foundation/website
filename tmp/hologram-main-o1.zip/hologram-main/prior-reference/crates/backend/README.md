# hologram-backend

**Backend trait system and implementations for Hologram**

## Overview

`hologram-backend` provides the backend abstraction layer with comprehensive support for execution planning and hardware-optimized kernels. It defines core traits and implements the CPU backend as a reference, with optional GPU backends (Metal, CUDA, WebGPU) available via feature flags.

The crate provides a "write-once, run-anywhere" model where code compiles to ISA once and executes on any available backend through the unified trait interface.

## Architecture

```
┌────────────────────────────────────────────────────────────────┐
│                       BackendPlan                               │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────────────┐   │
│  │  PlanOp[]   │ │ KernelTable │ │   WorkspaceLayout       │   │
│  │  (ops)      │ │ (kernels)   │ │   (pre-allocated)       │   │
│  └─────────────┘ └─────────────┘ └─────────────────────────┘   │
└──────────────────────────┬─────────────────────────────────────┘
                           │
                           ▼
┌────────────────────────────────────────────────────────────────┐
│                     PlanExecutor                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  execute() → O(1) dispatch → kernel execution            │   │
│  │  (no decisions at runtime, all resolved at compile)      │   │
│  └─────────────────────────────────────────────────────────┘   │
└──────────────────────────┬─────────────────────────────────────┘
                           │
                           ▼
┌────────────────────────────────────────────────────────────────┐
│                   CPU Backend (SIMD Dispatch)                   │
├────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌────────────────────────────────────────────────────────┐    │
│  │  Static Kernel Table (OnceLock - detected once)         │    │
│  │  ├── SimdCapability (AVX-512/AVX2/NEON/Scalar)         │    │
│  │  └── TileConfig (MR×NR, MC×NC×KC)                      │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐            │
│  │  AVX-512    │  │    AVX2     │  │    NEON     │            │
│  │  8×32 μker  │  │   6×16 μker │  │   4×8 μker  │            │
│  │  64B/cycle  │  │  32B/cycle  │  │  16B/cycle  │            │
│  └─────────────┘  └─────────────┘  └─────────────┘            │
│                                                                 │
└────────────────────────────────────────────────────────────────┘
```

## Features

- **BackendPlan**: Immutable, fully-resolved execution plans with pre-selected kernels
- **PlanExecutor**: Zero-allocation plan execution with pre-allocated workspace
- **Static Kernel Table**: One-time SIMD detection at process start, no per-call branching
- **Epilogue Fusion**: Post-ops (bias, activation, scale) compiled into kernel chains
- **Thread Partitioning**: Static work assignment at compile time
- **Layout Planning**: Tensor layouts with packing stages for cache efficiency
- **Transform Cache**: Pre-computed weight transforms (Winograd, etc.)

## Key Types

| Type | Description |
|------|-------------|
| `ProgramBackend` | Core trait for ISA program execution and buffer management |
| `ComputeBackend` | Trait for SIMD-accelerated matmul/conv operations |
| `BackendPlan` | Immutable execution plan with pre-selected kernels |
| `PlanExecutor` | Zero-overhead plan executor |
| `KernelTable` | Static table of kernel functions |
| `KernelId` | Unique identifier for kernel selection |
| `EpilogueChain` | Fused post-operation sequence |
| `ThreadPartition` | Static work distribution across threads |
| `TensorLayout` | NCHW tensor metadata with strides |
| `BackendCapabilities` | Static capability query for planning |

## Backend Implementation Contract

- **ProgramBackend (required)**: `backend_type`, `execute_program`, `allocate_buffer`, `free_buffer`, `copy_to_buffer`, `copy_from_buffer`, `buffer_size`, `synchronize`, `get_buffer_ptr`.
- **ComputeBackend (defaults available)**: `fma_scalar_crt_batch`, `vector_add`, `vector_mul`, `matmul`, `batch_matmul`, `conv2d`, `depthwise_conv2d`, `pointwise_conv`, `grouped_conv2d`, `aspect_aware_matmul`.
- **Shared implementations**: `hologram_backend::common_ops` provides CPU-based fallbacks for every compute method using only the `ProgramBackend` buffer APIs. Implement a correct backend by wiring buffer management first, then override compute calls with hardware-specific kernels for performance.
- **Minimal bring-up flow**: implement `ProgramBackend`, rely on `ComputeBackend` defaults (or call `common_ops` from your impl), add optimized overrides incrementally.

## Usage

### Basic Backend Usage

```rust
use hologram_backend::{create_best_backend, ProgramBackend, LaunchConfig};

// Create the best available backend
let mut backend = create_best_backend();

// Allocate a buffer
let handle = backend.allocate_buffer(1024).unwrap();

// Copy data to the buffer
let data = vec![1u8, 2, 3, 4];
backend.copy_to_buffer(handle, &data).unwrap();

// Read data back
let mut output = vec![0u8; 4];
backend.copy_from_buffer(handle, &mut output).unwrap();

// Clean up
backend.free_buffer(handle).unwrap();
```

### Plan Execution (Zero-Overhead)

```rust
use hologram_backend::{PlanExecutor, BackendPlan, ExecutorBuilder};

// Plans are created by the compiler (hologram-compiler)
let plan: BackendPlan = /* compiled plan */;

// Create executor with pre-allocated workspace
let mut executor = ExecutorBuilder::new()
    .with_plan(&plan)
    .build()
    .unwrap();

// Execute with zero runtime decisions
executor.execute(&plan, &mut backend).unwrap();

// Get execution statistics
let stats = executor.stats();
println!("Kernel calls: {}", stats.kernel_calls);
println!("Total time: {:?}", stats.total_time);
```

### Compute Operations

```rust
use hologram_backend::{ComputeBackend, MatMulParams, Conv2DParams, TensorLayout};
use hologram_isa::Type;

// Matrix multiplication
let params = MatMulParams {
    m: 1024,
    n: 1024,
    k: 512,
    alpha: 1.0,
    beta: 0.0,
    trans_a: false,
    trans_b: false,
};
backend.matmul(&a_layout, &b_layout, &mut c_layout, &params)?;

// 2D Convolution
let conv_params = Conv2DParams {
    batch: 1,
    in_channels: 64,
    out_channels: 128,
    in_height: 224,
    in_width: 224,
    kernel_h: 3,
    kernel_w: 3,
    stride_h: 1,
    stride_w: 1,
    padding_h: 1,
    padding_w: 1,
    dilation_h: 1,
    dilation_w: 1,
    groups: 1,
};
backend.conv2d(&input, &filter, &mut output, &conv_params)?;
```

### Tiling Configuration

```rust
// CPU backend auto-selects optimal tile sizes based on SIMD level:

// AVX-512: MR=8, NR=32, MC=96, NC=256, KC=384
// AVX2:    MR=6, NR=16, MC=72, NC=256, KC=512
// NEON:    MR=4, NR=8,  MC=64, NC=128, KC=512
// Scalar:  MR=1, NR=4,  MC=64, NC=64,  KC=256

// Tile meanings:
// - MR×NR: Register-blocked micro-kernel
// - MC×NC: L2 cache-friendly macro-tile
// - KC: K-dimension tile for L1 efficiency
```

## Modules

| Module | Purpose |
|--------|---------|
| `traits` | `ProgramBackend`, `ComputeBackend` trait definitions |
| `cpu/` | CPU backend with SIMD dispatch |
| `plan` | `BackendPlan`, `KernelTable`, `PlanOp` |
| `executor` | `PlanExecutor`, `BatchExecutor` |
| `capabilities` | `BackendCapabilities` for compile-time planning |
| `layout` | `LayoutContract`, `LayoutPlanner`, packing stages |
| `epilogue` | Epilogue fusion: bias, activation, scale |
| `threading` | `ThreadPartitioner`, static work assignment |
| `transform_cache` | Pre-computed transforms (Winograd, etc.) |
| `view` | `TensorView` for tensor-level operations |
| `metal/` | Metal GPU backend (macOS) |
| `cuda/` | CUDA GPU backend (NVIDIA) |
| `webgpu/` | WebGPU backend (cross-platform) |
| `wasm/` | WebAssembly backend (deterministic sandbox) |

## Feature Flags

| Feature | Description | Default |
|---------|-------------|---------|
| `cpu` | CPU backend with SIMD | Yes |
| `wasm` | Deterministic WebAssembly backend | Yes (target-dependent) |
| `parallel` | Rayon parallel execution | Yes |
| `blas` | ndarray for BLAS operations | Yes |
| `fft` | rustfft for FFT-based convolution | Yes |
| `metal` | Apple Metal GPU backend | No |
| `cuda` | NVIDIA CUDA GPU backend | No |
| `webgpu` | WebGPU cross-platform GPU | No |
| `all-backends` | Enable all GPU backends | No |
| `alloc-tracking` | Track allocations for no-alloc tests | No |

## Dependencies

**Internal:**
- `hologram-common` - Shared primitives
- `hologram-core` - Buffer management
- `hologram-ir` - Intermediate representation
- `hologram-isa` - Instruction set
- `hologram-lookup` - Lookup primitives

**External:**
- `rustc-hash` - FxHashMap for zero-overhead hashing
- `parking_lot` - Efficient synchronization
- `rkyv` - Zero-copy serialization
- `rayon` (optional) - Parallel execution
- `ndarray` (optional) - BLAS operations
- `rustfft` (optional) - FFT convolution
- `wgpu` (optional) - WebGPU
- `metal` (optional) - Apple Metal
- `cudarc` (optional) - CUDA

## Performance

### Zero-Overhead Execution

```
Compile Time:  IR Graph → Fusion → Kernel Selection → BackendPlan
Runtime:       BackendPlan → O(1) dispatch → Kernel execution
                            (no decisions)
```

### Tiling Strategy

| SIMD Level | Micro (MR×NR) | Macro (MC×NC) | K-Tile |
|------------|---------------|---------------|--------|
| AVX-512 | 8×32 | 96×256 | 384 |
| AVX2 | 6×16 | 72×256 | 512 |
| NEON | 4×8 | 64×128 | 512 |
| SSE4.2 | 4×8 | 64×128 | 256 |
| Scalar | 1×4 | 64×64 | 256 |

### Memory Bandwidth Target

- Target: ~50GB/s memory bandwidth utilization
- Achieved through cache blocking and SIMD vectorization
- Zero allocation in kernel hot paths

## See Also

- [hologram-core](../core/README.md) - Buffer management, Executor
- [hologram-isa](../isa/README.md) - Instruction set for programs
- [hologram-compiler](../compiler/README.md) - Compiles to BackendPlan
- [Spec: 06-backend-crate.md](../../specs/plans/06-backend-crate.md)
