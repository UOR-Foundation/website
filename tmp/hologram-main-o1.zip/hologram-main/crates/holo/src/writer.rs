//! Bundle writers for HOLB format.
//!
//! This module provides writers for creating `.holb` files with
//! support for sections (V2 format).

// Allow casts in this module since we're working with file format offsets
// that are designed for 64-bit but safe for practical file sizes.
#![allow(clippy::cast_possible_truncation)]

use std::fs::File;
use std::io::Write;
use std::path::Path;

use crate::error::HoloError;
use crate::format::{
    align_to_page, crc32, HolbHeader, HolbHeaderV2, HOLB_HEADER_SIZE_V1, HOLB_HEADER_SIZE_V2,
};
use crate::layer_header::{LayerHeader, LayerHeaderSection};
use crate::section::{sections_table_size, serialize_sections_table, SectionTableEntry};
use crate::traits::EmbeddableSection;
use crate::Result;

/// Writer for unified bundles (HOLB V1/V2 format).
///
/// Creates `.holb` files containing a graph (`BackendPlan`), optional
/// sections, and optional weights. If sections are added, the V2 format
/// is used automatically.
///
/// # Example
///
/// ```rust
/// use hologram_holo::writer::HolbWriter;
///
/// let mut writer = HolbWriter::new();
/// writer.set_graph(&[1, 2, 3, 4]); // BackendPlan bytes
/// writer.set_weights(&[5, 6, 7, 8]); // Weights/constants
/// let bundle = writer.build().unwrap();
/// ```
pub struct HolbWriter {
    graph_data: Vec<u8>,
    weights_data: Vec<u8>,
    sections: Vec<(SectionTableEntry, Vec<u8>)>,
}

impl HolbWriter {
    /// Create a new HOLB writer.
    #[must_use]
    pub fn new() -> Self {
        Self {
            graph_data: Vec::new(),
            weights_data: Vec::new(),
            sections: Vec::new(),
        }
    }

    /// Set the graph data (`BackendPlan` serialized bytes).
    pub fn set_graph(&mut self, data: &[u8]) {
        self.graph_data = data.to_vec();
    }

    /// Set the weights/constants data.
    pub fn set_weights(&mut self, data: &[u8]) {
        self.weights_data = data.to_vec();
    }

    /// Set weights with tensor index for partial loading.
    ///
    /// This embeds a `WeightIndexSection` alongside the weights, enabling
    /// partial loading of specific tensors by name.
    ///
    /// # Errors
    ///
    /// Returns error if tensor metadata is invalid (overlapping, out of bounds).
    pub fn set_indexed_weights(
        &mut self,
        weights: &[u8],
        tensors: &[crate::weight_types::TensorMetadata],
    ) -> Result<()> {
        Self::validate_tensor_index(weights.len(), tensors)?;
        self.weights_data = weights.to_vec();

        let index = crate::weight_index::WeightIndexSection::with_tensors(tensors.to_vec());
        self.add_section(&index);
        Ok(())
    }

    /// Set weights with compression.
    ///
    /// Compresses the weights and adds compression metadata to the index.
    ///
    /// # Errors
    ///
    /// Returns error if compression fails or the compression feature is not enabled.
    #[cfg(feature = "compression")]
    pub fn set_compressed_weights(
        &mut self,
        weights: &[u8],
        algorithm: crate::compression::CompressionAlgorithm,
        level: i32,
    ) -> Result<()> {
        let (compressed, metadata) =
            crate::compression::compress_with_metadata(weights, algorithm, level)?;

        self.weights_data = compressed;

        let mut index = crate::weight_index::WeightIndexSection::new();
        index.set_compression(metadata);
        self.add_section(&index);
        Ok(())
    }

    /// Set weights with both tensor index and compression.
    ///
    /// Compresses the weights and embeds both the tensor index and
    /// compression metadata.
    ///
    /// # Errors
    ///
    /// Returns error if tensor metadata is invalid or compression fails.
    #[cfg(feature = "compression")]
    pub fn set_indexed_compressed_weights(
        &mut self,
        weights: &[u8],
        tensors: &[crate::weight_types::TensorMetadata],
        algorithm: crate::compression::CompressionAlgorithm,
        level: i32,
    ) -> Result<()> {
        Self::validate_tensor_index(weights.len(), tensors)?;

        let (compressed, compression_metadata) =
            crate::compression::compress_with_metadata(weights, algorithm, level)?;

        self.weights_data = compressed;

        let mut index = crate::weight_index::WeightIndexSection::with_tensors(tensors.to_vec());
        index.set_compression(compression_metadata);
        self.add_section(&index);
        Ok(())
    }

    fn validate_tensor_index(
        total_size: usize,
        tensors: &[crate::weight_types::TensorMetadata],
    ) -> Result<()> {
        // Check no tensor extends beyond weights blob
        for tensor in tensors {
            if tensor.end_offset() > total_size as u64 {
                return Err(HoloError::tensor_bounds_invalid(
                    &tensor.name,
                    tensor.offset as usize,
                    tensor.size as usize,
                    total_size,
                ));
            }
        }

        // Check for overlapping tensors
        let mut sorted: Vec<_> = tensors.iter().collect();
        sorted.sort_by_key(|t| t.offset);

        for window in sorted.windows(2) {
            let a = window[0];
            let b = window[1];
            if a.end_offset() > b.offset {
                return Err(HoloError::overlapping_tensors(&a.name, &b.name));
            }
        }

        Ok(())
    }

    /// Add a section from an `EmbeddableSection` implementor.
    ///
    /// Adding sections automatically uses the V2 format.
    pub fn add_section(&mut self, section: &dyn EmbeddableSection) {
        let data = section.to_bytes();
        let entry = SectionTableEntry::new(
            section.section_id(),
            section.content_type(),
            section.version(),
            0, // Offset will be calculated during build
            data.len() as u64,
            crc32(&data),
        );
        self.sections.push((entry, data));
    }

    /// Add a raw section with explicit metadata.
    pub fn add_raw_section(&mut self, id: &str, content_type: &str, data: &[u8]) {
        let entry = SectionTableEntry::new(
            id,
            content_type,
            1,
            0, // Offset will be calculated during build
            data.len() as u64,
            crc32(data),
        );
        self.sections.push((entry, data.to_vec()));
    }

    /// Check if any sections have been added.
    #[must_use]
    pub fn has_sections(&self) -> bool {
        !self.sections.is_empty()
    }

    /// Set the layer header for multi-layer execution.
    ///
    /// This embeds a `LayerHeader` as a section in the bundle, enabling
    /// multi-layer execution with proper offsets and entrypoint chains.
    ///
    /// Adding a layer header automatically uses the V2 format.
    pub fn set_layer_header(&mut self, header: LayerHeader) {
        let section = LayerHeaderSection::new(header);
        self.add_section(&section);
    }

    /// Build the bundle and return the bytes.
    ///
    /// # Errors
    /// Returns error if the bundle cannot be built (e.g., no graph data).
    pub fn build(&mut self) -> Result<Vec<u8>> {
        if self.graph_data.is_empty() {
            return Err(HoloError::EmptyBundle);
        }

        Ok(if self.sections.is_empty() {
            self.build_v1()
        } else {
            self.build_v2()
        })
    }

    /// Build V1 format (no sections).
    fn build_v1(&self) -> Vec<u8> {
        let graph_checksum = crc32(&self.graph_data);
        let weights_checksum = if self.weights_data.is_empty() {
            0
        } else {
            crc32(&self.weights_data)
        };

        let weights_offset = if self.weights_data.is_empty() {
            0
        } else {
            align_to_page(HOLB_HEADER_SIZE_V1 as u64 + self.graph_data.len() as u64)
        };

        let header = HolbHeader {
            magic: *crate::HOLB_MAGIC,
            version: 1,
            graph_offset: HOLB_HEADER_SIZE_V1 as u64,
            graph_size: self.graph_data.len() as u64,
            weights_offset,
            weights_size: self.weights_data.len() as u64,
            graph_checksum,
            weights_checksum,
        };

        let total_size = if self.weights_data.is_empty() {
            HOLB_HEADER_SIZE_V1 + self.graph_data.len()
        } else {
            weights_offset as usize + self.weights_data.len()
        };

        let mut buf = vec![0u8; total_size];

        // Write header
        buf[..HOLB_HEADER_SIZE_V1].copy_from_slice(&header.to_bytes());

        // Write graph
        buf[HOLB_HEADER_SIZE_V1..HOLB_HEADER_SIZE_V1 + self.graph_data.len()]
            .copy_from_slice(&self.graph_data);

        // Write weights (if any)
        if !self.weights_data.is_empty() {
            buf[weights_offset as usize..weights_offset as usize + self.weights_data.len()]
                .copy_from_slice(&self.weights_data);
        }

        buf
    }

    /// Build V2 format (with sections).
    fn build_v2(&mut self) -> Vec<u8> {
        // Calculate layout
        let graph_offset = HOLB_HEADER_SIZE_V2 as u64;
        let graph_end = graph_offset + self.graph_data.len() as u64;

        // Sections table comes after graph, page-aligned
        let sections_table_offset = align_to_page(graph_end);

        // Calculate section data offsets
        // Section data comes right after section table
        let mut section_entries: Vec<SectionTableEntry> =
            self.sections.iter().map(|(e, _)| e.clone()).collect();
        let table_size = sections_table_size(&section_entries);
        let mut section_data_offset = sections_table_offset + table_size as u64;

        for (i, (_, data)) in self.sections.iter().enumerate() {
            section_entries[i].offset = section_data_offset;
            section_data_offset += data.len() as u64;
        }

        // Weights come after sections, page-aligned
        let weights_offset = if self.weights_data.is_empty() {
            0
        } else {
            align_to_page(section_data_offset)
        };

        // Calculate checksums
        let graph_checksum = crc32(&self.graph_data);
        let weights_checksum = if self.weights_data.is_empty() {
            0
        } else {
            crc32(&self.weights_data)
        };

        let header = HolbHeaderV2 {
            magic: *crate::HOLB_MAGIC,
            version: 2,
            flags: 0,
            _reserved1: 0,
            graph_offset,
            graph_size: self.graph_data.len() as u64,
            weights_offset,
            weights_size: self.weights_data.len() as u64,
            graph_checksum,
            weights_checksum,
            sections_table_offset,
            sections_count: self.sections.len() as u32,
            _reserved2: 0,
        };

        // Calculate total size
        let total_size = if self.weights_data.is_empty() {
            section_data_offset as usize
        } else {
            weights_offset as usize + self.weights_data.len()
        };

        let mut buf = vec![0u8; total_size];

        // Write header
        buf[..HOLB_HEADER_SIZE_V2].copy_from_slice(&header.to_bytes());

        // Write graph
        buf[graph_offset as usize..graph_offset as usize + self.graph_data.len()]
            .copy_from_slice(&self.graph_data);

        // Write sections table
        let table_bytes = serialize_sections_table(&section_entries);
        buf[sections_table_offset as usize..sections_table_offset as usize + table_bytes.len()]
            .copy_from_slice(&table_bytes);

        // Write section data
        for (entry, data) in section_entries
            .iter()
            .zip(self.sections.iter().map(|(_, d)| d))
        {
            buf[entry.offset as usize..entry.offset as usize + data.len()].copy_from_slice(data);
        }

        // Write weights (if any)
        if !self.weights_data.is_empty() {
            buf[weights_offset as usize..weights_offset as usize + self.weights_data.len()]
                .copy_from_slice(&self.weights_data);
        }

        buf
    }

    /// Write the bundle to a file.
    ///
    /// # Errors
    /// Returns error if file cannot be written.
    pub fn write_to_file(&mut self, path: impl AsRef<Path>) -> Result<()> {
        let data = self.build()?;
        let mut file = File::create(path)?;
        file.write_all(&data)?;
        Ok(())
    }
}

impl Default for HolbWriter {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::format::{HolbHeader, HolbHeaderV2, PAGE_SIZE};

    #[test]
    fn test_writer_new() {
        let writer = HolbWriter::new();
        assert!(!writer.has_sections());
    }

    #[test]
    fn test_writer_empty_bundle() {
        let mut writer = HolbWriter::new();
        assert!(writer.build().is_err());
    }

    #[test]
    fn test_writer_v1_graph_only() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1, 2, 3, 4, 5]);

        let bundle = writer.build().unwrap();

        // Parse and verify header
        let header = HolbHeader::from_bytes(&bundle).unwrap();
        assert_eq!(header.version, 1);
        assert_eq!(header.graph_size, 5);
        assert_eq!(header.weights_size, 0);
        assert_eq!(header.graph_offset, HOLB_HEADER_SIZE_V1 as u64);

        // Verify graph data
        let graph = &bundle[header.graph_offset as usize..][..header.graph_size as usize];
        assert_eq!(graph, &[1, 2, 3, 4, 5]);

        // Verify checksum
        assert_eq!(header.graph_checksum, crc32(&[1, 2, 3, 4, 5]));
    }

    #[test]
    fn test_writer_v1_with_weights() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1, 2, 3]);
        writer.set_weights(&[10, 20, 30, 40]);

        let bundle = writer.build().unwrap();

        let header = HolbHeader::from_bytes(&bundle).unwrap();
        assert_eq!(header.version, 1);
        assert_eq!(header.graph_size, 3);
        assert_eq!(header.weights_size, 4);

        // Weights should be page-aligned
        assert_eq!(header.weights_offset % PAGE_SIZE as u64, 0);
        assert!(header.weights_offset >= HOLB_HEADER_SIZE_V1 as u64 + header.graph_size);

        // Verify weights data
        let weights = &bundle[header.weights_offset as usize..][..header.weights_size as usize];
        assert_eq!(weights, &[10, 20, 30, 40]);

        // Verify checksum
        assert_eq!(header.weights_checksum, crc32(&[10, 20, 30, 40]));
    }

    #[test]
    fn test_writer_v2_with_sections() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1, 2, 3, 4]);
        writer.add_raw_section("test_section", "text/plain", b"hello");

        assert!(writer.has_sections());

        let bundle = writer.build().unwrap();

        // Should be V2
        let header = HolbHeaderV2::from_bytes(&bundle).unwrap();
        assert_eq!(header.version, 2);
        assert_eq!(header.sections_count, 1);
        assert!(header.has_sections());

        // Verify graph
        let graph = &bundle[header.graph_offset as usize..][..header.graph_size as usize];
        assert_eq!(graph, &[1, 2, 3, 4]);
    }

    #[test]
    fn test_writer_v2_multiple_sections() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1, 2]);
        writer.add_raw_section("section1", "text/plain", b"data1");
        writer.add_raw_section("section2", "application/json", b"data2");
        writer.add_raw_section("section3", "application/octet-stream", b"data3");

        let bundle = writer.build().unwrap();

        let header = HolbHeaderV2::from_bytes(&bundle).unwrap();
        assert_eq!(header.sections_count, 3);
    }

    #[test]
    fn test_writer_v2_with_weights() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1, 2, 3]);
        writer.add_raw_section("vocab", "text/plain", b"token1\ntoken2");
        writer.set_weights(&[100, 200]);

        let bundle = writer.build().unwrap();

        let header = HolbHeaderV2::from_bytes(&bundle).unwrap();
        assert_eq!(header.version, 2);
        assert!(header.weights_size > 0);

        // Weights should be page-aligned
        assert_eq!(header.weights_offset % PAGE_SIZE as u64, 0);

        // Verify weights data
        let weights = &bundle[header.weights_offset as usize..][..header.weights_size as usize];
        assert_eq!(weights, &[100, 200]);
    }

    #[derive(Clone)]
    struct TestSection {
        data: Vec<u8>,
    }

    impl EmbeddableSection for TestSection {
        fn section_id(&self) -> &'static str {
            "test"
        }

        fn to_bytes(&self) -> Vec<u8> {
            self.data.clone()
        }

        fn content_type(&self) -> &'static str {
            "application/x-test"
        }

        fn version(&self) -> u32 {
            2
        }
    }

    #[test]
    fn test_writer_add_section_trait() {
        let mut writer = HolbWriter::new();
        writer.set_graph(&[1]);

        let section = TestSection {
            data: vec![10, 20, 30],
        };
        writer.add_section(&section);

        let bundle = writer.build().unwrap();

        let header = HolbHeaderV2::from_bytes(&bundle).unwrap();
        assert_eq!(header.sections_count, 1);
    }

    #[test]
    fn test_writer_default() {
        let writer = HolbWriter::default();
        assert!(!writer.has_sections());
    }
}
