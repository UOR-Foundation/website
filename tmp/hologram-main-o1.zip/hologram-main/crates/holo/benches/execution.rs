//! Benchmarks for end-to-end compiled graph execution.
//!
//! Tests the full pipeline performance:
//! 1. Graph compilation
//! 2. Plan execution
//!
//! These benchmarks measure realistic workload performance.

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use hologram_backend::backends::cpu::CpuBackend;
use hologram_backend::backends::Backend;
use hologram_compiler::{compile, CompilerConfig, DType, OpKind, OpNode, OperationGraph};

// ============================================================================
// Helper Functions
// ============================================================================

/// Convert f32 slice to byte buffer.
fn f32_to_bytes(data: &[f32]) -> Vec<u8> {
    data.iter().flat_map(|f| f.to_ne_bytes()).collect()
}

/// Create an add graph of specified size.
fn create_add_graph(size: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![size], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![size], DType::F32);
    let add = OpNode::new(2, OpKind::Add, vec![size], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![size], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(add);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("result", 3);

    graph
}

/// Create an activation chain graph (relu -> sigmoid -> tanh).
fn create_activation_chain_graph(size: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![size], DType::F32);
    let relu = OpNode::new(1, OpKind::Relu, vec![size], DType::F32);
    let sigmoid = OpNode::new(2, OpKind::Sigmoid, vec![size], DType::F32);
    let tanh = OpNode::new(3, OpKind::Tanh, vec![size], DType::F32);
    let output = OpNode::new(4, OpKind::Output, vec![size], DType::F32);

    graph.add_node(input);
    graph.add_node(relu);
    graph.add_node(sigmoid);
    graph.add_node(tanh);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph.add_edge(3, 4);

    graph.add_input("x", 0);
    graph.add_output("y", 4);

    graph
}

/// Create a deep chain graph (N sequential ReLU operations).
fn create_deep_chain_graph(size: usize, depth: u32) -> OperationGraph {
    let mut graph = OperationGraph::new();

    // Input
    let input = OpNode::new(0, OpKind::Input, vec![size], DType::F32);
    graph.add_node(input);
    graph.add_input("x", 0);

    // Chain of ReLU nodes
    for i in 1..=depth {
        let relu = OpNode::new(i, OpKind::Relu, vec![size], DType::F32);
        graph.add_node(relu);
        graph.add_edge(i - 1, i);
    }

    // Output
    let output = OpNode::new(depth + 1, OpKind::Output, vec![size], DType::F32);
    graph.add_node(output);
    graph.add_edge(depth, depth + 1);
    graph.add_output("y", depth + 1);

    graph
}

/// Create a MatMul graph (A * B).
fn create_matmul_graph(m: usize, k: usize, n: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![m, k], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![k, n], DType::F32);
    let matmul = OpNode::new(2, OpKind::MatMul { m, k, n }, vec![m, n], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![m, n], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(matmul);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("A", 0);
    graph.add_input("B", 1);
    graph.add_output("result", 3);

    graph
}

// ============================================================================
// Compilation Benchmarks
// ============================================================================

fn bench_compilation(c: &mut Criterion) {
    let mut group = c.benchmark_group("compilation");

    // Add graphs of different sizes
    for size in [64, 256, 1024, 4096] {
        let graph = create_add_graph(size);
        group.throughput(Throughput::Elements(size as u64));

        group.bench_with_input(BenchmarkId::new("add", size), &graph, |b, graph| {
            let config = CompilerConfig::default();
            b.iter(|| compile(black_box(graph), &config).unwrap());
        });
    }

    // Activation chain graphs
    for size in [256, 1024, 4096] {
        let graph = create_activation_chain_graph(size);
        group.throughput(Throughput::Elements(size as u64));

        group.bench_with_input(
            BenchmarkId::new("activation_chain", size),
            &graph,
            |b, graph| {
                let config = CompilerConfig::default();
                b.iter(|| compile(black_box(graph), &config).unwrap());
            },
        );
    }

    // Deep chains (many operations)
    for depth in [5, 10, 20] {
        let graph = create_deep_chain_graph(256, depth);

        group.bench_with_input(BenchmarkId::new("deep_chain", depth), &graph, |b, graph| {
            let config = CompilerConfig::default();
            b.iter(|| compile(black_box(graph), &config).unwrap());
        });
    }

    group.finish();
}

// ============================================================================
// Execution Benchmarks
// ============================================================================

fn bench_execute(c: &mut Criterion) {
    let mut group = c.benchmark_group("execute");

    // Add graphs of different sizes
    for size in [256, 1024, 4096, 16384] {
        let graph = create_add_graph(size);
        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).expect("compilation failed");

        // Prepare test data
        let a_data: Vec<f32> = (0..size).map(|i| i as f32).collect();
        let b_data: Vec<f32> = (0..size).map(|i| (size - i) as f32).collect();
        let a = f32_to_bytes(&a_data);
        let b = f32_to_bytes(&b_data);

        let backend = CpuBackend::new();

        group.throughput(Throughput::Elements(size as u64));

        group.bench_with_input(BenchmarkId::new("add", size), &size, |bench, _| {
            let inputs: &[&[u8]] = &[&a, &b];
            let mut output = vec![0u8; size * 4];

            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend
                    .execute_plan(black_box(&plan), black_box(inputs), outputs)
                    .unwrap();
            });
        });
    }

    group.finish();
}

// ============================================================================
// Activation Chain Benchmarks
// ============================================================================

fn bench_activation_chain(c: &mut Criterion) {
    let mut group = c.benchmark_group("activation_chain");

    for size in [256, 1024, 4096, 16384] {
        let graph = create_activation_chain_graph(size);
        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).expect("compilation failed");

        // Prepare test data
        let x_data: Vec<f32> = (0..size)
            .map(|i| (i as f32 - size as f32 / 2.0) / 100.0)
            .collect();
        let x = f32_to_bytes(&x_data);

        let backend = CpuBackend::new();

        group.throughput(Throughput::Elements(size as u64));

        group.bench_with_input(BenchmarkId::from_parameter(size), &size, |bench, _| {
            let inputs: &[&[u8]] = &[&x];
            let mut output = vec![0u8; size * 4];

            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend
                    .execute_plan(black_box(&plan), black_box(inputs), outputs)
                    .unwrap();
            });
        });
    }

    group.finish();
}

// ============================================================================
// Deep Chain Benchmarks
// ============================================================================

fn bench_deep_chain(c: &mut Criterion) {
    let mut group = c.benchmark_group("deep_chain");

    for depth in [5, 10, 20, 50] {
        let size = 1024;
        let graph = create_deep_chain_graph(size, depth);
        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).expect("compilation failed");

        // Prepare test data
        let x_data: Vec<f32> = (0..size).map(|i| i as f32 - 512.0).collect();
        let x = f32_to_bytes(&x_data);

        let backend = CpuBackend::new();

        group.bench_with_input(BenchmarkId::from_parameter(depth), &depth, |bench, _| {
            let inputs: &[&[u8]] = &[&x];
            let mut output = vec![0u8; size * 4];

            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend
                    .execute_plan(black_box(&plan), black_box(inputs), outputs)
                    .unwrap();
            });
        });
    }

    group.finish();
}

// ============================================================================
// MatMul Benchmarks
// ============================================================================

fn bench_matmul(c: &mut Criterion) {
    let mut group = c.benchmark_group("matmul");

    for size in [16, 32, 64, 128] {
        let graph = create_matmul_graph(size, size, size);
        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).expect("compilation failed");

        // Prepare test data (identity-like matrices for verification)
        let a_data: Vec<f32> = (0..size * size)
            .map(|i| (i % (size + 1) == 0) as i32 as f32)
            .collect();
        let b_data: Vec<f32> = (0..size * size)
            .map(|i| (i % (size + 1) == 0) as i32 as f32)
            .collect();
        let a = f32_to_bytes(&a_data);
        let b = f32_to_bytes(&b_data);

        let backend = CpuBackend::new();

        // Throughput in FLOPS (2*m*n*k for matmul)
        let flops = 2 * size * size * size;
        group.throughput(Throughput::Elements(flops as u64));

        group.bench_with_input(
            BenchmarkId::new("square", format!("{size}x{size}")),
            &size,
            |bench, _| {
                let inputs: &[&[u8]] = &[&a, &b];
                let mut output = vec![0u8; size * size * 4];

                bench.iter(|| {
                    let outputs: &mut [&mut [u8]] = &mut [&mut output];
                    backend
                        .execute_plan(black_box(&plan), black_box(inputs), outputs)
                        .unwrap();
                });
            },
        );
    }

    group.finish();
}

// ============================================================================
// Criterion Groups
// ============================================================================

criterion_group!(
    benches,
    bench_compilation,
    bench_execute,
    bench_activation_chain,
    bench_deep_chain,
    bench_matmul,
);
criterion_main!(benches);
