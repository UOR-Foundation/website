//! Allocation tracking allocator for testing zero-allocation guarantees.
//!
//! This module provides a custom global allocator that tracks allocation
//! counts and bytes. It's used in tests to verify that hot paths don't
//! allocate memory.
//!
//! # Usage
//!
//! Enable the `alloc-tracking` feature and use `#[global_allocator]` in tests:
//!
//! ```ignore
//! #![cfg(feature = "alloc-tracking")]
//!
//! use hologram_backend::alloc_tracker::{TrackingAllocator, reset_counts, get_counts};
//!
//! #[global_allocator]
//! static GLOBAL: TrackingAllocator = TrackingAllocator;
//!
//! #[test]
//! fn test_no_alloc() {
//!     reset_counts();
//!     // ... perform operations ...
//!     let (count, bytes) = get_counts();
//!     assert_eq!(count, 0, "Unexpected allocations");
//! }
//! ```

use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering};

/// Global counter for allocation operations.
pub static ALLOC_COUNT: AtomicUsize = AtomicUsize::new(0);

/// Global counter for total bytes allocated.
pub static ALLOC_BYTES: AtomicUsize = AtomicUsize::new(0);

/// A global allocator that tracks allocation counts and bytes.
///
/// This allocator wraps the system allocator and increments counters
/// on each allocation. Use [`reset_counts`] before a test section and
/// [`get_counts`] after to verify zero allocations.
pub struct TrackingAllocator;

unsafe impl GlobalAlloc for TrackingAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        ALLOC_COUNT.fetch_add(1, Ordering::Relaxed);
        ALLOC_BYTES.fetch_add(layout.size(), Ordering::Relaxed);
        // SAFETY: Delegating to the system allocator with valid layout
        System.alloc(layout)
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        // SAFETY: Delegating to the system allocator with valid ptr and layout
        System.dealloc(ptr, layout)
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        ALLOC_COUNT.fetch_add(1, Ordering::Relaxed);
        ALLOC_BYTES.fetch_add(layout.size(), Ordering::Relaxed);
        // SAFETY: Delegating to the system allocator with valid layout
        System.alloc_zeroed(layout)
    }

    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        ALLOC_COUNT.fetch_add(1, Ordering::Relaxed);
        // Only count the increase in allocation
        if new_size > layout.size() {
            ALLOC_BYTES.fetch_add(new_size - layout.size(), Ordering::Relaxed);
        }
        // SAFETY: Delegating to the system allocator with valid inputs
        System.realloc(ptr, layout, new_size)
    }
}

/// Reset all allocation counters to zero.
///
/// Call this at the start of a test section to begin tracking allocations.
pub fn reset_counts() {
    ALLOC_COUNT.store(0, Ordering::SeqCst);
    ALLOC_BYTES.store(0, Ordering::SeqCst);
}

/// Get the current allocation counts.
///
/// Returns a tuple of (allocation_count, total_bytes_allocated).
pub fn get_counts() -> (usize, usize) {
    (
        ALLOC_COUNT.load(Ordering::SeqCst),
        ALLOC_BYTES.load(Ordering::SeqCst),
    )
}

/// RAII guard that resets counts on creation and checks for zero allocations on drop.
///
/// # Panics
///
/// Panics on drop if any allocations occurred during the guard's lifetime.
pub struct NoAllocGuard {
    context: &'static str,
}

impl NoAllocGuard {
    /// Create a new guard, resetting allocation counts.
    ///
    /// # Arguments
    ///
    /// * `context` - Description of what's being tested (used in panic message)
    pub fn new(context: &'static str) -> Self {
        reset_counts();
        Self { context }
    }
}

impl Drop for NoAllocGuard {
    fn drop(&mut self) {
        let (count, bytes) = get_counts();
        if count > 0 {
            panic!(
                "NoAllocGuard({}): {} allocations totaling {} bytes occurred",
                self.context, count, bytes
            );
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_reset_and_get_counts() {
        // Set some initial values
        ALLOC_COUNT.store(100, Ordering::SeqCst);
        ALLOC_BYTES.store(1000, Ordering::SeqCst);

        // Reset
        reset_counts();

        // Verify reset
        let (count, bytes) = get_counts();
        assert_eq!(count, 0);
        assert_eq!(bytes, 0);
    }

    #[test]
    fn test_tracking_allocator_exists() {
        // Just verify the type exists and can be instantiated
        let _allocator = TrackingAllocator;
    }
}
