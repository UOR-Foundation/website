//! Backend detection utilities.
//!
//! This module provides functions for detecting and creating backends
//! at runtime based on available features and hardware.

use crate::backends::cpu::CpuBackend;
use crate::{BackendError, BackendType, ProgramBackend};

/// Detect the best available backend for this system.
///
/// Returns the backend type in order of preference:
/// 1. WASM (on wasm32 target)
/// 2. Metal (on macOS with metal feature)
/// 3. CUDA (with cuda feature)
/// 4. WebGPU (with webgpu feature)
/// 5. CPU (always available)
#[must_use]
pub fn detect_best_backend() -> BackendType {
    // Wasm builds run inside a sandboxed runtime; prefer Wasm backend there.
    #[cfg(target_arch = "wasm32")]
    {
        BackendType::Wasm
    }

    // Non-WASM targets: Priority is Metal > CUDA > WebGPU > CPU
    #[cfg(not(target_arch = "wasm32"))]
    {
        #[cfg(all(target_os = "macos", feature = "metal"))]
        return BackendType::Metal;

        #[cfg(all(not(all(target_os = "macos", feature = "metal")), feature = "cuda"))]
        return BackendType::Cuda;

        #[cfg(all(
            not(all(target_os = "macos", feature = "metal")),
            not(feature = "cuda"),
            feature = "webgpu"
        ))]
        return BackendType::WebGpu;

        #[cfg(all(
            not(target_arch = "wasm32"),
            not(all(target_os = "macos", feature = "metal")),
            not(feature = "cuda"),
            not(feature = "webgpu")
        ))]
        BackendType::Cpu
    }
}

/// Create the best available backend.
pub fn create_best_backend() -> Box<dyn ProgramBackend> {
    match detect_best_backend() {
        BackendType::Cpu => Box::new(CpuBackend::new()),
        #[cfg(feature = "wasm")]
        BackendType::Wasm => Box::new(crate::backends::wasm::WasmBackend::new()),
        #[cfg(all(target_os = "macos", feature = "metal"))]
        BackendType::Metal => Box::new(crate::backends::metal::MetalBackend::new()),
        #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
        BackendType::Cuda => Box::new(crate::backends::cuda::CudaBackend::new()),
        #[cfg(feature = "webgpu")]
        BackendType::WebGpu => Box::new(crate::backends::webgpu::WebGpuBackend::new()),
        _ => Box::new(CpuBackend::new()),
    }
}

/// Create a specific backend by type.
pub fn create_backend(backend_type: BackendType) -> Result<Box<dyn ProgramBackend>, BackendError> {
    match backend_type {
        BackendType::Cpu => Ok(Box::new(CpuBackend::new())),
        #[cfg(feature = "wasm")]
        BackendType::Wasm => Ok(Box::new(crate::backends::wasm::WasmBackend::new())),
        #[cfg(all(target_os = "macos", feature = "metal"))]
        BackendType::Metal => Ok(Box::new(crate::backends::metal::MetalBackend::new())),
        #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
        BackendType::Cuda => Ok(Box::new(crate::backends::cuda::CudaBackend::new())),
        #[cfg(feature = "webgpu")]
        BackendType::WebGpu => Ok(Box::new(crate::backends::webgpu::WebGpuBackend::new())),
        #[cfg(not(all(target_os = "macos", feature = "metal")))]
        BackendType::Metal => Err(BackendError::Unsupported(
            "Metal backend not available (requires macOS with metal feature)".into(),
        )),
        #[cfg(not(all(any(target_os = "linux", target_os = "windows"), feature = "cuda")))]
        BackendType::Cuda => Err(BackendError::Unsupported(
            "CUDA backend not available (requires Linux/Windows with cuda feature)".into(),
        )),
        #[cfg(not(feature = "webgpu"))]
        BackendType::WebGpu => Err(BackendError::Unsupported(
            "WebGPU backend not compiled".into(),
        )),
        #[cfg(not(feature = "wasm"))]
        BackendType::Wasm => Err(BackendError::Unsupported(
            "Wasm backend not compiled".into(),
        )),
        BackendType::Custom(name) => Err(BackendError::Unsupported(format!(
            "Custom backend '{}' not registered",
            name
        ))),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_detect_best_backend() {
        let backend = detect_best_backend();
        // The best backend depends on enabled features
        #[cfg(target_arch = "wasm32")]
        assert_eq!(backend, BackendType::Wasm);

        #[cfg(all(target_os = "macos", feature = "metal"))]
        assert_eq!(backend, BackendType::Metal);

        #[cfg(all(not(all(target_os = "macos", feature = "metal")), feature = "cuda"))]
        assert_eq!(backend, BackendType::Cuda);

        #[cfg(all(
            not(all(target_os = "macos", feature = "metal")),
            not(feature = "cuda"),
            feature = "webgpu"
        ))]
        assert_eq!(backend, BackendType::WebGpu);

        #[cfg(all(
            not(all(target_os = "macos", feature = "metal")),
            not(feature = "cuda"),
            not(feature = "webgpu")
        ))]
        assert_eq!(backend, BackendType::Cpu);
    }

    #[test]
    fn test_create_best_backend() {
        let backend = create_best_backend();
        let expected = detect_best_backend();
        assert_eq!(backend.backend_type(), expected);
    }

    #[test]
    fn test_create_cpu_backend() {
        let backend = create_backend(BackendType::Cpu);
        assert!(backend.is_ok());
        assert_eq!(backend.unwrap().backend_type(), BackendType::Cpu);
    }

    #[test]
    fn test_create_unavailable_backend() {
        #[cfg(not(feature = "metal"))]
        {
            let result = create_backend(BackendType::Metal);
            assert!(result.is_err());
        }
    }

    #[test]
    fn test_detect_returns_available_backend() {
        let backend_type = detect_best_backend();
        // Whatever we detect should be available
        assert!(backend_type.is_available() || matches!(backend_type, BackendType::Custom(_)));
    }

    #[test]
    fn test_create_backend_returns_correct_type() {
        let backend = create_backend(BackendType::Cpu).unwrap();
        assert_eq!(backend.backend_type(), BackendType::Cpu);
    }
}
