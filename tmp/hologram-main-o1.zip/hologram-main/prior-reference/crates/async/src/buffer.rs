//! Async buffer operations.
//!
//! This module provides async wrappers for buffer operations.

use crate::executor::AsyncExecutor;
use crate::Result;
use hologram_core::Buffer;
use std::marker::PhantomData;

/// Async buffer wrapper that provides async operations on a buffer.
///
/// This is a thin wrapper around Buffer<T> that works with AsyncExecutor.
pub struct AsyncBuffer<T: Copy + Send + 'static> {
    buffer: Buffer<T>,
    executor: AsyncExecutor,
    _marker: PhantomData<T>,
}

impl<T: Copy + Send + 'static> AsyncBuffer<T> {
    /// Create a new async buffer wrapper.
    pub fn new(buffer: Buffer<T>, executor: AsyncExecutor) -> Self {
        Self {
            buffer,
            executor,
            _marker: PhantomData,
        }
    }

    /// Get the underlying buffer.
    pub fn inner(&self) -> &Buffer<T> {
        &self.buffer
    }

    /// Get the underlying buffer handle.
    pub fn buffer(&self) -> Buffer<T> {
        self.buffer
    }

    /// Get the number of elements in the buffer.
    pub fn len(&self) -> usize {
        self.buffer.len()
    }

    /// Check if the buffer is empty.
    pub fn is_empty(&self) -> bool {
        self.buffer.is_empty()
    }

    /// Get the size of the buffer in bytes.
    pub fn size_bytes(&self) -> usize {
        self.buffer.size_bytes()
    }

    /// Copy data from a slice to the buffer asynchronously.
    pub async fn copy_from_slice(&self, data: Vec<T>) -> Result<()> {
        self.executor.copy_to_buffer(&self.buffer, data).await
    }

    /// Read the buffer contents into a new vector asynchronously.
    pub async fn to_vec(&self) -> Result<Vec<T>> {
        self.executor.read_buffer(&self.buffer).await
    }

    /// Fill the buffer with a constant value asynchronously.
    pub async fn fill(&self, value: T) -> Result<()> {
        self.executor.fill_buffer(&self.buffer, value).await
    }

    /// Free the buffer asynchronously.
    pub async fn free(self) -> Result<()> {
        self.executor.free(self.buffer).await
    }

    /// Get the executor associated with this buffer.
    pub fn executor(&self) -> &AsyncExecutor {
        &self.executor
    }
}

impl<T: Copy + Send + 'static> Clone for AsyncBuffer<T> {
    fn clone(&self) -> Self {
        Self {
            buffer: self.buffer,
            executor: self.executor.clone(),
            _marker: PhantomData,
        }
    }
}

/// Extension trait for creating async buffers from an executor.
pub trait AsyncBufferExt {
    /// Allocate a new async buffer.
    fn allocate_async<T: Copy + Send + 'static>(
        &self,
        count: usize,
    ) -> impl std::future::Future<Output = Result<AsyncBuffer<T>>> + Send;
}

impl AsyncBufferExt for AsyncExecutor {
    async fn allocate_async<T: Copy + Send + 'static>(
        &self,
        count: usize,
    ) -> Result<AsyncBuffer<T>> {
        let buffer = self.allocate::<T>(count).await?;
        Ok(AsyncBuffer::new(buffer, self.clone()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_core::BackendType;

    #[tokio::test]
    async fn test_async_buffer_new() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let buffer = exec.allocate::<f32>(100).await.unwrap();
        let async_buf = AsyncBuffer::new(buffer, exec);
        assert_eq!(async_buf.len(), 100);
    }

    #[tokio::test]
    async fn test_async_buffer_allocate_ext() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let async_buf = exec.allocate_async::<f32>(100).await.unwrap();
        assert_eq!(async_buf.len(), 100);
    }

    #[tokio::test]
    async fn test_async_buffer_size_bytes() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let async_buf = exec.allocate_async::<f32>(100).await.unwrap();
        assert_eq!(async_buf.size_bytes(), 100 * std::mem::size_of::<f32>());
    }

    #[tokio::test]
    async fn test_async_buffer_is_empty() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let async_buf = exec.allocate_async::<f32>(0).await.unwrap();
        assert!(async_buf.is_empty());

        let async_buf2 = exec.allocate_async::<f32>(10).await.unwrap();
        assert!(!async_buf2.is_empty());
    }

    #[tokio::test]
    async fn test_async_buffer_copy_and_read() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let async_buf = exec.allocate_async::<i32>(4).await.unwrap();

        let data = vec![10, 20, 30, 40];
        async_buf.copy_from_slice(data.clone()).await.unwrap();

        let result = async_buf.to_vec().await.unwrap();
        assert_eq!(result, data);
    }

    #[tokio::test]
    async fn test_async_buffer_fill() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let async_buf = exec.allocate_async::<u16>(5).await.unwrap();

        async_buf.fill(0xABCD).await.unwrap();

        let result = async_buf.to_vec().await.unwrap();
        assert_eq!(result, vec![0xABCDu16; 5]);
    }

    #[tokio::test]
    async fn test_async_buffer_free() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let async_buf = exec.allocate_async::<f64>(10).await.unwrap();
        let result = async_buf.free().await;
        assert!(result.is_ok());
    }

    #[tokio::test]
    async fn test_async_buffer_clone() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let async_buf1 = exec.allocate_async::<f32>(10).await.unwrap();
        let async_buf2 = async_buf1.clone();

        assert_eq!(async_buf1.len(), async_buf2.len());
        assert_eq!(async_buf1.buffer().handle(), async_buf2.buffer().handle());
    }

    #[tokio::test]
    async fn test_async_buffer_inner() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let async_buf = exec.allocate_async::<f32>(10).await.unwrap();
        let inner = async_buf.inner();
        assert_eq!(inner.len(), 10);
    }

    #[tokio::test]
    async fn test_async_buffer_executor() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let async_buf = exec.allocate_async::<f32>(10).await.unwrap();
        assert_eq!(async_buf.executor().backend_type(), BackendType::Cpu);
    }
}
