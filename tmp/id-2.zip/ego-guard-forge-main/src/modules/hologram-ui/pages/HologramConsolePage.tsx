/**
 * HologramConsolePage — The main Hologram OS console/home screen.
 * Shows the modular grid with quick access to subsystems.
 */

import { useState } from "react";
import { Fingerprint, Shield, Key, Cpu, Globe, Database, Music, Eye, Code, Layers, UserPlus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import HologramLogo from "@/modules/hologram-ui/components/HologramLogo";
import ClaimIdentityDialog from "@/modules/identity/components/ClaimIdentityDialog";

interface ModuleCard {
  label: string;
  icon: React.ElementType;
  path: string;
  description: string;
  namespace: string;
  status: "active" | "stub" | "planned";
}

const MODULES: ModuleCard[] = [
  { label: "Identity", icon: Fingerprint, path: "/identity", description: "Your digital identity — trust, privacy, and control", namespace: "u:", status: "active" },
  { label: "Trust Graph", icon: Shield, path: "/identity", description: "See who trusts you and how your trust score grows over time", namespace: "cert:", status: "active" },
  { label: "Privacy", icon: Key, path: "/identity", description: "Control what data you share and with whom", namespace: "u:", status: "active" },
  { label: "Compute", icon: Cpu, path: "#", description: "Virtual compute infrastructure for distributed processing", namespace: "op:", status: "stub" },
  { label: "Web", icon: Globe, path: "#", description: "Browse and interact with the web through Hologram", namespace: "resolver:", status: "stub" },
  { label: "Memory", icon: Database, path: "#", description: "Persistent storage for your data and application state", namespace: "state:", status: "stub" },
  { label: "Audio", icon: Music, path: "#", description: "Audio processing and ambient sound analysis", namespace: "audio:", status: "stub" },
  { label: "Observable", icon: Eye, path: "#", description: "Monitor and visualize system metrics in real time", namespace: "observable:", status: "stub" },
  { label: "Code Nexus", icon: Code, path: "#", description: "Navigate your codebase through a semantic knowledge graph", namespace: "type:", status: "stub" },
  { label: "Morphism", icon: Layers, path: "#", description: "Transform data structures while preserving meaning", namespace: "morphism:", status: "stub" },
];

export default function HologramConsolePage() {
  const navigate = useNavigate();
  const [claimOpen, setClaimOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <ClaimIdentityDialog open={claimOpen} onOpenChange={setClaimOpen} />
      {/* Hero header */}
      <div className="px-8 pt-12 pb-8">
        <div className="flex items-center gap-4 mb-2">
          <HologramLogo size={40} color="hsl(38, 25%, 80%)" />
          <div>
            <h1 className="text-2xl font-display text-foreground tracking-tight">Hologram OS</h1>
            <p className="text-sm text-muted-foreground">Your personal supercomputer — modular and extensible</p>
          </div>
        </div>

        <div className="mt-6 flex items-center gap-3">
          <span className="text-xs font-mono text-muted-foreground px-2.5 py-1 rounded-md bg-muted">
            v2.0.0
          </span>
          <span className="text-xs text-muted-foreground">
            {MODULES.filter(m => m.status === "active").length} active · {MODULES.filter(m => m.status === "stub").length} stubs
          </span>
          <button
            onClick={() => setClaimOpen(true)}
            className="ml-auto inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
          >
            <UserPlus size={16} />
            Claim Identity
          </button>
        </div>
      </div>

      {/* Module Grid */}
      <div className="px-8 pb-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {MODULES.map((mod) => {
            const Icon = mod.icon;
            const isClickable = mod.status === "active";
            return (
              <button
                key={mod.label}
                onClick={() => isClickable && navigate(mod.path)}
                disabled={!isClickable}
                className={`group text-left rounded-xl border p-4 transition-all duration-200 ${
                  isClickable
                    ? "border-border bg-card hover:border-primary/40 hover:bg-card/80 cursor-pointer"
                    : "border-border/50 bg-muted/30 cursor-default opacity-60"
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${
                    isClickable ? "bg-primary/15" : "bg-muted"
                  }`}>
                    <Icon className={`h-4.5 w-4.5 ${isClickable ? "text-primary" : "text-muted-foreground"}`} strokeWidth={1.5} />
                  </div>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                    mod.status === "active"
                      ? "bg-primary/15 text-primary"
                      : "bg-muted text-muted-foreground"
                  }`}>
                    {mod.namespace}
                  </span>
                </div>

                <h3 className={`text-sm font-semibold mb-1 ${isClickable ? "text-foreground" : "text-muted-foreground"}`}>
                  {mod.label}
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">
                  {mod.description}
                </p>

                {mod.status === "stub" && (
                  <span className="mt-2 inline-block text-[10px] text-text-dim font-mono">
                    Coming soon
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Sign back in */}
        <div className="text-center pt-6 pb-2">
          <button
            onClick={() => navigate("/identity/create")}
            className="text-xs text-muted-foreground/50 hover:text-muted-foreground transition-colors"
          >
            Already have an identity? <span className="underline underline-offset-2">Sign back in</span>
          </button>
        </div>
      </div>
    </div>
  );
}
