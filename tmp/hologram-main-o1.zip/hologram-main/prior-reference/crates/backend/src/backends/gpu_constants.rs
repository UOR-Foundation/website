//! Shared constants for GPU backends.
//!
//! These constants are used by CUDA, Metal, and WebGPU backends for tiled matrix
//! multiplication and other GPU-optimized operations.
//!
//! **NOTE:** GPU shader sources (CUDA PTX, Metal MSL, WebGPU WGSL) define their own
//! copies of these constants. When changing values here, ensure the shader sources
//! are updated to match.

/// Tile size for tiled matrix multiplication kernels.
///
/// This value must match the workgroup/block size defined in GPU shader sources:
/// - CUDA: `TILE_SIZE` in matmul_tiled kernel
/// - Metal: `TILE_SIZE` in matmul_tiled shader
/// - WebGPU: `TILE_SIZE` in tiled_matmul shader
pub const GPU_TILE_SIZE: u32 = 16;

/// Minimum work size threshold for using tiled matmul instead of naive.
///
/// Below this threshold (m * n * k < threshold), the synchronization overhead
/// of tiled matmul exceeds its computational benefits. Naive matmul is faster
/// for small matrices.
///
/// The threshold of 4096 corresponds to matrices where one dimension is 16
/// (matching the tile size), making tiling beneficial.
pub const TILED_MATMUL_THRESHOLD: u32 = 4096;
