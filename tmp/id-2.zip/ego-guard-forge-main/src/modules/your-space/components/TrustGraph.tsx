// Re-export components that belong to the your-space module
// In the main repo, these files will live directly in your-space/components/
export { default } from "@/modules/identity/components/TrustGraph";
