//! WebAssembly backend implementation.
//!
//! This backend is designed for deterministic, sandboxed execution in wasm
//! environments. It reuses the ISA interpreter from the CPU backend for
//! program execution and the shared `common_ops` fallbacks for compute APIs.
//!
//! # SIMD Activation Support
//!
//! When compiled with `target_feature = "simd128"`, this backend provides
//! WASM SIMD128-accelerated activation lookups via the `simd_activation` module.

pub mod simd_activation;

pub use simd_activation::WasmSimdActivation;

use crate::backends::cpu::Interpreter;
use crate::{
    BackendError, BackendType, BufferHandle, ComputeBackend, LaunchConfig, ProgramBackend,
};
use hologram_isa::Program;
use parking_lot::{Mutex, RwLock};
use rustc_hash::FxHashMap;
use std::sync::atomic::{AtomicU64, Ordering};

/// WebAssembly backend with in-memory buffer management.
pub struct WasmBackend {
    buffers: RwLock<FxHashMap<u64, Vec<u8>>>,
    next_handle: AtomicU64,
    interpreter: Mutex<Interpreter>,
}

impl WasmBackend {
    /// Create a new Wasm backend.
    #[must_use]
    pub fn new() -> Self {
        Self {
            buffers: RwLock::new(FxHashMap::default()),
            next_handle: AtomicU64::new(0),
            interpreter: Mutex::new(Interpreter::new()),
        }
    }

    /// Check if the Wasm backend is available in this build/target.
    #[must_use]
    pub const fn is_available() -> bool {
        cfg!(target_arch = "wasm32")
    }

    fn next_buffer_handle(&self) -> BufferHandle {
        let id = self.next_handle.fetch_add(1, Ordering::Relaxed);
        BufferHandle::new(id)
    }
}

impl Default for WasmBackend {
    fn default() -> Self {
        Self::new()
    }
}

impl ProgramBackend for WasmBackend {
    fn backend_type(&self) -> BackendType {
        BackendType::Wasm
    }

    fn lookup_tables(&self) -> crate::plan::LookupTables {
        crate::plan::LookupTables::default()
    }

    fn execute_program(
        &self,
        program: &Program,
        _config: &LaunchConfig,
    ) -> Result<(), BackendError> {
        if program.instructions().is_empty() {
            return Ok(());
        }

        let mut buffers = self.buffers.write();
        let mut interpreter = self.interpreter.lock();
        interpreter.execute_with_tables(program, &mut buffers, None, &self.lookup_tables())
    }

    fn allocate_buffer(&self, size: usize) -> Result<BufferHandle, BackendError> {
        let handle = self.next_buffer_handle();
        let mut buffers = self.buffers.write();
        buffers.insert(handle.id(), vec![0u8; size]);
        Ok(handle)
    }

    fn free_buffer(&self, handle: BufferHandle) -> Result<(), BackendError> {
        let mut buffers = self.buffers.write();
        buffers
            .remove(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;
        Ok(())
    }

    fn copy_to_buffer(&self, handle: BufferHandle, data: &[u8]) -> Result<(), BackendError> {
        let mut buffers = self.buffers.write();
        let buffer = buffers
            .get_mut(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;
        if data.len() > buffer.len() {
            return Err(BackendError::buffer("Data exceeds buffer size"));
        }
        buffer[..data.len()].copy_from_slice(data);
        Ok(())
    }

    fn copy_from_buffer(&self, handle: BufferHandle, data: &mut [u8]) -> Result<(), BackendError> {
        let buffers = self.buffers.read();
        let buffer = buffers
            .get(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;
        if data.len() > buffer.len() {
            return Err(BackendError::buffer("Request exceeds buffer size"));
        }
        data.copy_from_slice(&buffer[..data.len()]);
        Ok(())
    }

    fn buffer_size(&self, handle: BufferHandle) -> Result<usize, BackendError> {
        let buffers = self.buffers.read();
        buffers
            .get(&handle.id())
            .map(|b| b.len())
            .ok_or(BackendError::InvalidHandle(handle))
    }

    fn synchronize(&self) -> Result<(), BackendError> {
        // All operations are synchronous for the wasm backend.
        Ok(())
    }

    fn get_buffer_ptr(&self, handle: BufferHandle) -> Option<*mut u8> {
        let buffers = self.buffers.read();
        buffers.get(&handle.id()).map(|v| v.as_ptr() as *mut u8)
    }
}

impl ComputeBackend for WasmBackend {}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::MatMulParams;
    use hologram_isa::{Address, Instruction, Program, Register, Type};

    #[test]
    fn test_wasm_backend_new() {
        let backend = WasmBackend::new();
        assert_eq!(backend.backend_type(), BackendType::Wasm);
    }

    #[test]
    fn test_buffer_lifecycle() {
        let backend = WasmBackend::new();
        let handle = backend.allocate_buffer(16).unwrap();
        assert_eq!(backend.buffer_size(handle).unwrap(), 16);
        backend.free_buffer(handle).unwrap();
        assert!(backend.buffer_size(handle).is_err());
    }

    #[test]
    fn test_copy_roundtrip() {
        let backend = WasmBackend::new();
        let handle = backend.allocate_buffer(4).unwrap();
        let data = [1u8, 2, 3, 4];
        backend.copy_to_buffer(handle, &data).unwrap();
        let mut out = [0u8; 4];
        backend.copy_from_buffer(handle, &mut out).unwrap();
        assert_eq!(out, data);
    }

    #[test]
    fn test_execute_program_add() {
        let backend = WasmBackend::new();
        let buffer = backend.allocate_buffer(4).unwrap();
        let mut program = Program::new();
        program.push(Instruction::MovImm {
            ty: Type::I32,
            dst: Register::R0,
            value: 2,
        });
        program.push(Instruction::MovImm {
            ty: Type::I32,
            dst: Register::R1,
            value: 3,
        });
        program.push(Instruction::Add {
            ty: Type::I32,
            dst: Register::R2,
            lhs: Register::R0,
            rhs: Register::R1,
        });
        program.push(Instruction::Stg {
            ty: Type::I32,
            dst: Address::Buffer {
                handle: buffer.id() as u8,
                offset: 0,
            },
            src: Register::R2,
        });
        program.push(Instruction::Exit);

        backend
            .execute_program(&program, &LaunchConfig::default())
            .unwrap();
        let mut out = [0u8; 4];
        backend.copy_from_buffer(buffer, &mut out).unwrap();
        assert_eq!(i32::from_le_bytes(out), 5);
    }

    #[test]
    fn test_compute_default_path() {
        let backend = WasmBackend::new();
        let a = backend.allocate_buffer(16).unwrap();
        let b = backend.allocate_buffer(16).unwrap();
        let c = backend.allocate_buffer(16).unwrap();

        // Initialize A and B as 2x2 matrices
        let a_vals = [1f32, 2.0, 3.0, 4.0];
        let b_vals = [5f32, 6.0, 7.0, 8.0];
        let a_bytes: Vec<u8> = a_vals.iter().flat_map(|v| v.to_le_bytes()).collect();
        let b_bytes: Vec<u8> = b_vals.iter().flat_map(|v| v.to_le_bytes()).collect();
        backend.copy_to_buffer(a, &a_bytes).unwrap();
        backend.copy_to_buffer(b, &b_bytes).unwrap();
        backend.copy_to_buffer(c, &[0u8; 16]).unwrap();

        let params = MatMulParams::new(2, 2, 2, Type::F32);
        // Uses default ComputeBackend impl (common_ops)
        ComputeBackend::matmul(&backend, c, a, b, &params).unwrap();

        let mut out_bytes = [0u8; 16];
        backend.copy_from_buffer(c, &mut out_bytes).unwrap();
        let out: Vec<f32> = out_bytes
            .chunks_exact(4)
            .map(|chunk| f32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]))
            .collect();
        assert_eq!(out, vec![19.0, 22.0, 43.0, 50.0]);
    }
}
