//! Marker traits for data-first type guarantees.
//!
//! This module provides compile-time guarantees for zero-copy hot paths:
//!
//! - [`ZeroCopyPath`]: Marker for types safe in allocation-free paths
//! - [`NoCopy`]: Wrapper preventing accidental `.clone()` in hot paths
//! - [`BufferView`]: Lifetime-bounded view of buffer data
//!
//! # Design Philosophy
//!
//! These markers enforce the zero-copy contract at compile time:
//! 1. Hot-path types must be `Copy` (stack-only, no heap)
//! 2. Types that allocate are wrapped in `NoCopy` to make allocation visible
//! 3. Buffer access is lifetime-bounded to prevent use-after-free

use std::marker::PhantomData;

// ============================================================================
// ZERO-COPY PATH MARKER
// ============================================================================

/// Marker trait for types safe to use in zero-allocation hot paths.
///
/// Types implementing this trait guarantee:
/// 1. No heap allocation in their methods
/// 2. `Copy` semantics (stack-only)
/// 3. Fixed size known at compile time
///
/// # Safety
///
/// This trait is unsafe to implement because incorrect implementation
/// can violate zero-copy guarantees in performance-critical paths.
///
/// # Example
///
/// ```ignore
/// // Safe types for hot paths
/// unsafe impl ZeroCopyPath for BufferHandle {}
/// unsafe impl ZeroCopyPath for KernelId {}
///
/// // NOT safe - Vec allocates
/// // unsafe impl ZeroCopyPath for Vec<u8> {} // Don't do this!
/// ```
pub unsafe trait ZeroCopyPath: Copy + Send + Sync + Sized {}

// Implement for primitives
unsafe impl ZeroCopyPath for u8 {}
unsafe impl ZeroCopyPath for u16 {}
unsafe impl ZeroCopyPath for u32 {}
unsafe impl ZeroCopyPath for u64 {}
unsafe impl ZeroCopyPath for usize {}
unsafe impl ZeroCopyPath for i8 {}
unsafe impl ZeroCopyPath for i16 {}
unsafe impl ZeroCopyPath for i32 {}
unsafe impl ZeroCopyPath for i64 {}
unsafe impl ZeroCopyPath for isize {}
unsafe impl ZeroCopyPath for f32 {}
unsafe impl ZeroCopyPath for f64 {}
unsafe impl ZeroCopyPath for bool {}

// Implement for tuples of ZeroCopyPath types
unsafe impl<A: ZeroCopyPath, B: ZeroCopyPath> ZeroCopyPath for (A, B) {}
unsafe impl<A: ZeroCopyPath, B: ZeroCopyPath, C: ZeroCopyPath> ZeroCopyPath for (A, B, C) {}

// Implement for arrays of ZeroCopyPath types
unsafe impl<T: ZeroCopyPath, const N: usize> ZeroCopyPath for [T; N] {}

// Implement for Option of ZeroCopyPath types (when inner is Copy)
unsafe impl<T: ZeroCopyPath> ZeroCopyPath for Option<T> {}

// ============================================================================
// NO-COPY WRAPPER
// ============================================================================

/// Wrapper for types that must not be cloned in hot paths.
///
/// Use this to wrap types where `.clone()` would allocate or violate
/// the zero-copy contract. The wrapper intentionally does NOT implement
/// `Clone`, making any allocation attempt a compile error.
///
/// # Example
///
/// ```ignore
/// // Wrap a Vec to prevent accidental cloning
/// let data = NoCopy::new(vec![1, 2, 3]);
///
/// // This won't compile - NoCopy doesn't implement Clone
/// // let copy = data.clone();
///
/// // Explicit access shows intent
/// let inner: &Vec<i32> = data.get();
///
/// // Explicit consume - makes allocation visible at call site
/// let owned: Vec<i32> = data.into_inner();
/// ```
#[derive(Debug)]
pub struct NoCopy<T>(T);

impl<T> NoCopy<T> {
    /// Create a new NoCopy wrapper.
    #[inline]
    pub const fn new(value: T) -> Self {
        Self(value)
    }

    /// Get a reference to the inner value.
    #[inline]
    pub fn get(&self) -> &T {
        &self.0
    }

    /// Get a mutable reference to the inner value.
    #[inline]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.0
    }

    /// Consume the wrapper and return the inner value.
    ///
    /// This makes the allocation/ownership transfer visible at the call site.
    #[inline]
    pub fn into_inner(self) -> T {
        self.0
    }
}

// Intentionally NOT implementing Clone - that's the point!

impl<T: Default> Default for NoCopy<T> {
    fn default() -> Self {
        Self::new(T::default())
    }
}

// ============================================================================
// BUFFER VIEW
// ============================================================================

/// A borrowed view of buffer data that cannot outlive the executor.
///
/// This type prevents use-after-free by tying the lifetime to the source
/// (typically the executor or workspace). The data cannot be accessed
/// after the source is dropped.
///
/// # Safety
///
/// The view holds a raw pointer but is safe because:
/// 1. Lifetime `'a` ensures the source outlives the view
/// 2. Length is validated at construction
/// 3. No mutation through the view (read-only)
///
/// # Example
///
/// ```ignore
/// // Get a lifetime-bounded view from executor
/// let view: BufferView<'_> = executor.view_buffer(handle)?;
///
/// // Access as slice - safe because lifetime is tied to executor
/// let data: &[u8] = view.as_slice();
///
/// // Can't outlive executor
/// // drop(executor);
/// // let _ = view.as_slice(); // Compile error!
/// ```
pub struct BufferView<'a> {
    ptr: *const u8,
    len: usize,
    _marker: PhantomData<&'a ()>,
}

impl<'a> BufferView<'a> {
    /// Create a new buffer view.
    ///
    /// # Safety
    ///
    /// The caller must ensure:
    /// 1. `ptr` points to valid memory for `len` bytes
    /// 2. The memory remains valid for lifetime `'a`
    /// 3. No mutable references exist to the memory
    #[inline]
    pub unsafe fn new(ptr: *const u8, len: usize) -> Self {
        Self {
            ptr,
            len,
            _marker: PhantomData,
        }
    }

    /// Access the buffer data as a slice.
    ///
    /// The returned slice's lifetime is bounded by the view's lifetime,
    /// which is in turn bounded by the source's lifetime.
    #[inline]
    pub fn as_slice(&self) -> &'a [u8] {
        // SAFETY: Constructor ensures ptr/len are valid for lifetime 'a
        unsafe { std::slice::from_raw_parts(self.ptr, self.len) }
    }

    /// Get the length of the buffer in bytes.
    #[inline]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Check if the buffer is empty.
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    /// Get the raw pointer (for FFI or unsafe operations).
    #[inline]
    pub fn as_ptr(&self) -> *const u8 {
        self.ptr
    }
}

// BufferView is Send/Sync if the underlying data would be
unsafe impl Send for BufferView<'_> {}
unsafe impl Sync for BufferView<'_> {}

// ============================================================================
// CONST ASSERTIONS
// ============================================================================

/// Compile-time assertion that a type fits within a cache line (64 bytes).
///
/// Use this to verify hot-path types don't span cache lines, which would
/// cause performance degradation.
#[macro_export]
macro_rules! assert_cache_friendly {
    ($t:ty) => {
        const _: () = assert!(
            std::mem::size_of::<$t>() <= 64,
            concat!(stringify!($t), " exceeds cache line size (64 bytes)")
        );
    };
}

/// Compile-time assertion that a type implements ZeroCopyPath.
///
/// This is useful in generic contexts to enforce the zero-copy contract.
#[macro_export]
macro_rules! assert_zero_copy {
    ($t:ty) => {
        const _: fn() = || {
            fn assert_impl<T: $crate::core::markers::ZeroCopyPath>() {}
            assert_impl::<$t>();
        };
    };
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_no_copy_basic() {
        let data = NoCopy::new(vec![1, 2, 3]);
        assert_eq!(data.get(), &vec![1, 2, 3]);

        let inner = data.into_inner();
        assert_eq!(inner, vec![1, 2, 3]);
    }

    #[test]
    fn test_no_copy_mut() {
        let mut data = NoCopy::new(vec![1, 2, 3]);
        data.get_mut().push(4);
        assert_eq!(data.get(), &vec![1, 2, 3, 4]);
    }

    #[test]
    fn test_buffer_view() {
        let data = [1u8, 2, 3, 4, 5];
        let view = unsafe { BufferView::new(data.as_ptr(), data.len()) };

        assert_eq!(view.len(), 5);
        assert!(!view.is_empty());
        assert_eq!(view.as_slice(), &[1, 2, 3, 4, 5]);
    }

    #[test]
    fn test_buffer_view_empty() {
        let view = unsafe { BufferView::new(std::ptr::null(), 0) };
        assert!(view.is_empty());
        assert_eq!(view.len(), 0);
    }

    #[test]
    fn test_zero_copy_primitives() {
        fn assert_zero_copy<T: ZeroCopyPath>() {}

        assert_zero_copy::<u8>();
        assert_zero_copy::<u64>();
        assert_zero_copy::<f32>();
        assert_zero_copy::<(u32, u32)>();
        assert_zero_copy::<[u8; 16]>();
        assert_zero_copy::<Option<u64>>();
    }
}
