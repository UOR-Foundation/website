//! Section table definitions for V2 bundles.
//!
//! This module provides the data structures and serialization functions
//! for the sections table in HOLB V2 bundles. Each section is described
//! by a `SectionTableEntry` containing metadata and location information.

// Allow casts in this module since we're working with file format offsets
// that are designed for 64-bit but safe for practical file sizes.
#![allow(clippy::cast_possible_truncation)]

use crate::error::HoloError;
use crate::Result;

/// Entry in the sections table describing a single section.
///
/// The sections table is a serialized list of these entries, located
/// at the `sections_table_offset` specified in the V2 header.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SectionTableEntry {
    /// Unique section identifier (e.g., "vocabulary")
    pub id: String,

    /// MIME content type (e.g., "application/json")
    pub content_type: String,

    /// Section format version
    pub version: u32,

    /// Offset in file to section data
    pub offset: u64,

    /// Size of section data in bytes
    pub size: u64,

    /// CRC32 checksum of section data
    pub checksum: u32,
}

impl SectionTableEntry {
    /// Create a new section table entry.
    #[must_use]
    pub fn new(
        id: impl Into<String>,
        content_type: impl Into<String>,
        version: u32,
        offset: u64,
        size: u64,
        checksum: u32,
    ) -> Self {
        Self {
            id: id.into(),
            content_type: content_type.into(),
            version,
            offset,
            size,
            checksum,
        }
    }

    /// Serialize entry to bytes.
    ///
    /// Format:
    /// - `id_len: u16` (little-endian)
    /// - `id: [u8; id_len]` (UTF-8)
    /// - `content_type_len: u16` (little-endian)
    /// - `content_type: [u8; content_type_len]` (UTF-8)
    /// - `version: u32` (little-endian)
    /// - `offset: u64` (little-endian)
    /// - `size: u64` (little-endian)
    /// - `checksum: u32` (little-endian)
    #[must_use]
    pub fn to_bytes(&self) -> Vec<u8> {
        let id_bytes = self.id.as_bytes();
        let ct_bytes = self.content_type.as_bytes();
        let id_len = id_bytes.len() as u16;
        let ct_len = ct_bytes.len() as u16;

        let mut buf = Vec::with_capacity(self.serialized_size());

        buf.extend_from_slice(&id_len.to_le_bytes());
        buf.extend_from_slice(id_bytes);
        buf.extend_from_slice(&ct_len.to_le_bytes());
        buf.extend_from_slice(ct_bytes);
        buf.extend_from_slice(&self.version.to_le_bytes());
        buf.extend_from_slice(&self.offset.to_le_bytes());
        buf.extend_from_slice(&self.size.to_le_bytes());
        buf.extend_from_slice(&self.checksum.to_le_bytes());

        buf
    }

    /// Deserialize entry from bytes.
    ///
    /// Returns the entry and number of bytes consumed.
    ///
    /// # Errors
    /// Returns error if buffer is truncated or contains invalid UTF-8.
    pub fn from_bytes(buf: &[u8]) -> Result<(Self, usize)> {
        // Minimum size: 2 (id_len) + 2 (ct_len) + 4 (version) + 8 (offset) + 8 (size) + 4 (checksum) = 28
        if buf.len() < 4 {
            return Err(HoloError::table_truncated(4, buf.len()));
        }

        let id_len = u16::from_le_bytes(buf[0..2].try_into().unwrap()) as usize;
        let id_end = 2 + id_len;

        if buf.len() < id_end + 2 {
            return Err(HoloError::table_truncated(id_end + 2, buf.len()));
        }

        let id = std::str::from_utf8(&buf[2..id_end])
            .map_err(|e| HoloError::Other(format!("Invalid UTF-8 in section ID: {e}")))?
            .to_string();

        let ct_len = u16::from_le_bytes(buf[id_end..id_end + 2].try_into().unwrap()) as usize;
        let ct_end = id_end + 2 + ct_len;

        if buf.len() < ct_end + 24 {
            return Err(HoloError::table_truncated(ct_end + 24, buf.len()));
        }

        let content_type = std::str::from_utf8(&buf[id_end + 2..ct_end])
            .map_err(|e| HoloError::Other(format!("Invalid UTF-8 in content type: {e}")))?
            .to_string();

        let entry = Self {
            id,
            content_type,
            version: u32::from_le_bytes(buf[ct_end..ct_end + 4].try_into().unwrap()),
            offset: u64::from_le_bytes(buf[ct_end + 4..ct_end + 12].try_into().unwrap()),
            size: u64::from_le_bytes(buf[ct_end + 12..ct_end + 20].try_into().unwrap()),
            checksum: u32::from_le_bytes(buf[ct_end + 20..ct_end + 24].try_into().unwrap()),
        };

        let consumed = ct_end + 24;
        Ok((entry, consumed))
    }

    /// Get the serialized size of this entry in bytes.
    #[must_use]
    pub fn serialized_size(&self) -> usize {
        // id_len(2) + id + ct_len(2) + ct + version(4) + offset(8) + size(8) + checksum(4)
        2 + self.id.len() + 2 + self.content_type.len() + 24
    }
}

/// Serialize a list of section table entries to bytes.
///
/// The sections are serialized sequentially without any header.
/// Use the return length as `sections_count` in the V2 header.
#[must_use]
pub fn serialize_sections_table(entries: &[SectionTableEntry]) -> Vec<u8> {
    let total_size: usize = entries.iter().map(SectionTableEntry::serialized_size).sum();
    let mut buf = Vec::with_capacity(total_size);

    for entry in entries {
        buf.extend_from_slice(&entry.to_bytes());
    }

    buf
}

/// Deserialize section table entries from bytes.
///
/// # Arguments
/// * `bytes` - Raw section table data
/// * `count` - Number of entries to parse
///
/// # Errors
/// Returns error if data is truncated or contains invalid entries.
pub fn deserialize_sections_table(bytes: &[u8], count: usize) -> Result<Vec<SectionTableEntry>> {
    let mut entries = Vec::with_capacity(count);
    let mut offset = 0;

    for _ in 0..count {
        if offset >= bytes.len() {
            return Err(HoloError::table_truncated(offset + 1, bytes.len()));
        }

        let (entry, consumed) = SectionTableEntry::from_bytes(&bytes[offset..])?;
        entries.push(entry);
        offset += consumed;
    }

    Ok(entries)
}

/// Calculate total serialized size for a list of entries.
#[must_use]
pub fn sections_table_size(entries: &[SectionTableEntry]) -> usize {
    entries.iter().map(SectionTableEntry::serialized_size).sum()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_section_entry_new() {
        let entry = SectionTableEntry::new("vocab", "text/plain", 1, 4096, 1024, 0xDEAD_BEEF);

        assert_eq!(entry.id, "vocab");
        assert_eq!(entry.content_type, "text/plain");
        assert_eq!(entry.version, 1);
        assert_eq!(entry.offset, 4096);
        assert_eq!(entry.size, 1024);
        assert_eq!(entry.checksum, 0xDEAD_BEEF);
    }

    #[test]
    fn test_section_entry_roundtrip() {
        let entry =
            SectionTableEntry::new("vocabulary", "application/json", 2, 8192, 2048, 0xCAFE_BABE);

        let bytes = entry.to_bytes();
        let (parsed, consumed) = SectionTableEntry::from_bytes(&bytes).unwrap();

        assert_eq!(parsed, entry);
        assert_eq!(consumed, entry.serialized_size());
    }

    #[test]
    fn test_section_entry_serialized_size() {
        let entry = SectionTableEntry::new("test", "text/plain", 1, 0, 0, 0);
        // id_len(2) + "test"(4) + ct_len(2) + "text/plain"(10) + version(4) + offset(8) + size(8) + checksum(4)
        // = 2 + 4 + 2 + 10 + 24 = 42
        assert_eq!(entry.serialized_size(), 42);
    }

    #[test]
    fn test_serialize_sections_table() {
        let entries = vec![
            SectionTableEntry::new("a", "x", 1, 100, 10, 1),
            SectionTableEntry::new("bb", "yy", 2, 200, 20, 2),
        ];

        let bytes = serialize_sections_table(&entries);
        let expected_size = entries[0].serialized_size() + entries[1].serialized_size();
        assert_eq!(bytes.len(), expected_size);
    }

    #[test]
    fn test_deserialize_sections_table() {
        let entries = vec![
            SectionTableEntry::new("vocab", "text/plain", 1, 4096, 1024, 0xAAAA_AAAA),
            SectionTableEntry::new("config", "application/json", 1, 8192, 512, 0xBBBB_BBBB),
            SectionTableEntry::new(
                "model",
                "application/octet-stream",
                3,
                12288,
                65536,
                0xCCCC_CCCC,
            ),
        ];

        let bytes = serialize_sections_table(&entries);
        let parsed = deserialize_sections_table(&bytes, entries.len()).unwrap();

        assert_eq!(parsed, entries);
    }

    #[test]
    fn test_sections_table_size() {
        let entries = vec![
            SectionTableEntry::new("a", "b", 1, 0, 0, 0),
            SectionTableEntry::new("cc", "dd", 1, 0, 0, 0),
        ];

        let size = sections_table_size(&entries);
        let bytes = serialize_sections_table(&entries);
        assert_eq!(size, bytes.len());
    }

    #[test]
    fn test_empty_sections_table() {
        let entries: Vec<SectionTableEntry> = vec![];
        let bytes = serialize_sections_table(&entries);
        assert!(bytes.is_empty());

        let parsed = deserialize_sections_table(&[], 0).unwrap();
        assert!(parsed.is_empty());
    }

    #[test]
    fn test_section_entry_unicode() {
        let entry = SectionTableEntry::new("日本語", "text/plain; charset=utf-8", 1, 0, 0, 0);

        let bytes = entry.to_bytes();
        let (parsed, _) = SectionTableEntry::from_bytes(&bytes).unwrap();

        assert_eq!(parsed.id, "日本語");
        assert_eq!(parsed.content_type, "text/plain; charset=utf-8");
    }

    #[test]
    fn test_from_bytes_truncated() {
        let small_buf = [0u8; 3];
        assert!(SectionTableEntry::from_bytes(&small_buf).is_err());
    }

    #[test]
    fn test_from_bytes_truncated_content_type() {
        // Valid id_len and id, but truncated content type
        let mut buf = vec![];
        buf.extend_from_slice(&2u16.to_le_bytes()); // id_len = 2
        buf.extend_from_slice(b"ab"); // id
        buf.extend_from_slice(&100u16.to_le_bytes()); // ct_len = 100 (too large)

        assert!(SectionTableEntry::from_bytes(&buf).is_err());
    }

    #[test]
    fn test_deserialize_count_mismatch() {
        let entries = vec![SectionTableEntry::new("a", "b", 1, 0, 0, 0)];
        let bytes = serialize_sections_table(&entries);

        // Try to parse 2 entries when only 1 exists
        assert!(deserialize_sections_table(&bytes, 2).is_err());
    }
}
