/**
 * EditProfileDialog — Inline editing for display name, handle, and bio.
 * Saves directly to the database on confirm.
 */

import { useState } from "react";
import { X, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface EditProfileDialogProps {
  open: boolean;
  onClose: () => void;
  displayName: string;
  handle: string;
  bio?: string;
  onSaved: (updates: { displayName: string; handle: string; bio: string }) => void;
}

export function EditProfileDialog({
  open,
  onClose,
  displayName,
  handle,
  bio,
  onSaved,
}: EditProfileDialogProps) {
  const [name, setName] = useState(displayName);
  const [handleVal, setHandleVal] = useState(handle);
  const [bioVal, setBioVal] = useState(bio || "");
  const [saving, setSaving] = useState(false);

  if (!open) return null;

  const handleSave = async () => {
    if (!name.trim()) {
      toast({ title: "Display name cannot be empty", variant: "destructive" });
      return;
    }
    if (!handleVal.trim()) {
      toast({ title: "Handle cannot be empty", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast({ title: "Please sign in first", variant: "destructive" });
        return;
      }

      const { error } = await supabase
        .from("profiles")
        .update({
          display_name: name.trim(),
          handle: handleVal.trim(),
        })
        .eq("user_id", session.user.id);

      if (error) throw error;

      onSaved({
        displayName: name.trim(),
        handle: handleVal.trim(),
        bio: bioVal.trim(),
      });
      toast({ title: "Profile updated" });
      onClose();
    } catch (err: any) {
      console.error("Profile update error:", err);
      toast({ title: "Failed to update profile", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-background/80 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />

      {/* Dialog */}
      <div className="relative w-full max-w-lg mx-4 rounded-2xl border border-border/20 bg-card shadow-2xl animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between px-7 py-5 border-b border-border/15">
          <h2 className="text-xl font-display text-foreground">Edit profile</h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-muted-foreground/50 hover:text-foreground hover:bg-muted/20 transition-all duration-300"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form */}
        <div className="px-7 py-6 space-y-5">
          {/* Display name */}
          <div>
            <label className="block text-sm tracking-[0.15em] uppercase text-muted-foreground/50 mb-2">
              Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={50}
              className="w-full px-4 py-3 rounded-xl bg-background border border-border/20 text-foreground text-lg
                focus:outline-none focus:border-primary/40 focus:ring-1 focus:ring-primary/20
                transition-all duration-300 placeholder:text-muted-foreground/30"
              placeholder="Your display name"
            />
          </div>

          {/* Handle */}
          <div>
            <label className="block text-sm tracking-[0.15em] uppercase text-muted-foreground/50 mb-2">
              Handle
            </label>
            <input
              type="text"
              value={handleVal}
              onChange={(e) => setHandleVal(e.target.value)}
              maxLength={30}
              className="w-full px-4 py-3 rounded-xl bg-background border border-border/20 text-foreground text-lg font-mono
                focus:outline-none focus:border-primary/40 focus:ring-1 focus:ring-primary/20
                transition-all duration-300 placeholder:text-muted-foreground/30"
              placeholder="@yourhandle"
            />
          </div>

          {/* Bio */}
          <div>
            <label className="block text-sm tracking-[0.15em] uppercase text-muted-foreground/50 mb-2">
              Bio
            </label>
            <textarea
              value={bioVal}
              onChange={(e) => setBioVal(e.target.value)}
              maxLength={160}
              rows={3}
              className="w-full px-4 py-3 rounded-xl bg-background border border-border/20 text-foreground text-base leading-relaxed resize-none
                focus:outline-none focus:border-primary/40 focus:ring-1 focus:ring-primary/20
                transition-all duration-300 placeholder:text-muted-foreground/30"
              placeholder="Tell people about yourself..."
            />
            <p className="text-xs text-muted-foreground/30 mt-1.5 text-right">
              {bioVal.length}/160
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-7 py-5 border-t border-border/15">
          <p className="text-xs text-muted-foreground/30">
            Only you can see this · Private
          </p>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-5 py-2.5 rounded-full text-sm text-muted-foreground/60 hover:text-foreground transition-colors duration-300"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-6 py-2.5 rounded-full bg-primary text-primary-foreground text-sm font-medium
                hover:bg-primary/90 disabled:opacity-50 transition-all duration-300
                flex items-center gap-2"
            >
              {saving && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              Save
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
