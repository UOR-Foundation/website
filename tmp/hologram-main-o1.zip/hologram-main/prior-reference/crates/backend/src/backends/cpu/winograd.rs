//! Winograd convolution for 3x3 kernels.
//!
//! This module implements Winograd convolution using the F(2,3) algorithm,
//! which produces 2x2 output tiles from 4x4 input tiles with 3x3 kernels.
//!
//! # Algorithm Overview
//!
//! Winograd convolution replaces multiplications with additions by using:
//! 1. **Input transform**: V = BT @ d @ B (4x4 input tile → 4x4 transformed)
//! 2. **Filter transform**: U = G @ g @ GT (3x3 filter → 4x4 transformed, done once)
//! 3. **Element-wise multiply**: M = U ⊙ V (per element, per channel)
//! 4. **Output transform**: Y = AT @ M @ A (4x4 → 2x2 output)
//!
//! # Performance
//!
//! - F(2,3): 16 multiplications vs 36 (9×4) for direct conv → 2.25x arithmetic reduction
//! - With SIMD batching: 4-6x end-to-end speedup for large feature maps

use crate::transform_cache::PrepackedFilter;

/// F(2,3) Winograd input transform matrix B^T (4x4).
///
/// Transforms a 4x4 input tile to the Winograd domain.
/// Applied as: V = B^T @ d @ B
#[rustfmt::skip]
const BT_F23: [[f32; 4]; 4] = [
    [ 1.0,  0.0, -1.0,  0.0],
    [ 0.0,  1.0,  1.0,  0.0],
    [ 0.0, -1.0,  1.0,  0.0],
    [ 0.0,  1.0,  0.0, -1.0],
];

/// F(2,3) Winograd input transform matrix B (4x4, = B^T transpose).
#[rustfmt::skip]
const B_F23: [[f32; 4]; 4] = [
    [ 1.0,  0.0,  0.0,  0.0],
    [ 0.0,  1.0, -1.0,  1.0],
    [-1.0,  1.0,  1.0,  0.0],
    [ 0.0,  0.0,  0.0, -1.0],
];

/// F(2,3) Winograd output transform matrix A^T (2x4).
///
/// Transforms from Winograd domain back to spatial domain.
/// Applied as: Y = A^T @ M @ A
#[rustfmt::skip]
const AT_F23: [[f32; 4]; 2] = [
    [1.0,  1.0,  1.0,  0.0],
    [0.0,  1.0, -1.0, -1.0],
];

/// F(2,3) Winograd output transform matrix A (4x2, = A^T transpose).
#[rustfmt::skip]
const A_F23: [[f32; 2]; 4] = [
    [1.0, 0.0],
    [1.0, 1.0],
    [1.0, -1.0],
    [0.0, -1.0],
];

// ============================================================================
// OPTIMIZED WINOGRAD CONSTANTS
// ============================================================================

/// Minimum total work (tiles * out_channels) to enable parallelization.
/// Matches the threshold used in grouped.rs for consistency.
const PARALLEL_THRESHOLD: usize = 4096;

/// Maximum tiles to cache in V_cache before processing.
/// Sized to fit V_cache in L2 cache with typical channel counts:
/// 64 tiles * 128 channels * 16 floats * 4 bytes = 512KB
const MAX_CACHED_TILES: usize = 64;

/// Apply input transform: V = B^T @ d @ B for a 4x4 tile.
///
/// # Arguments
/// * `tile` - 4x4 input tile
///
/// # Returns
/// 4x4 transformed tile in Winograd domain
#[inline]
fn input_transform_f23(tile: &[[f32; 4]; 4]) -> [[f32; 4]; 4] {
    // Step 1: temp = B^T @ d
    let mut temp = [[0.0f32; 4]; 4];
    for i in 0..4 {
        for j in 0..4 {
            temp[i][j] = BT_F23[i][0] * tile[0][j]
                + BT_F23[i][1] * tile[1][j]
                + BT_F23[i][2] * tile[2][j]
                + BT_F23[i][3] * tile[3][j];
        }
    }

    // Step 2: result = temp @ B
    let mut result = [[0.0f32; 4]; 4];
    for i in 0..4 {
        for j in 0..4 {
            result[i][j] = temp[i][0] * B_F23[0][j]
                + temp[i][1] * B_F23[1][j]
                + temp[i][2] * B_F23[2][j]
                + temp[i][3] * B_F23[3][j];
        }
    }

    result
}

/// Apply output transform: Y = A^T @ M @ A for a 4x4 tile.
///
/// # Arguments
/// * `m` - 4x4 tile in Winograd domain (after element-wise multiply)
///
/// # Returns
/// 2x2 output tile in spatial domain
#[inline]
fn output_transform_f23(m: &[[f32; 4]; 4]) -> [[f32; 2]; 2] {
    // Step 1: temp = A^T @ M
    let mut temp = [[0.0f32; 4]; 2];
    for i in 0..2 {
        for j in 0..4 {
            temp[i][j] = AT_F23[i][0] * m[0][j]
                + AT_F23[i][1] * m[1][j]
                + AT_F23[i][2] * m[2][j]
                + AT_F23[i][3] * m[3][j];
        }
    }

    // Step 2: result = temp @ A
    let mut result = [[0.0f32; 2]; 2];
    for i in 0..2 {
        for j in 0..2 {
            result[i][j] = temp[i][0] * A_F23[0][j]
                + temp[i][1] * A_F23[1][j]
                + temp[i][2] * A_F23[2][j]
                + temp[i][3] * A_F23[3][j];
        }
    }

    result
}

/// Extract a 4x4 tile from the input tensor with padding handling.
///
/// # Arguments
/// * `input` - Input tensor [C, H, W]
/// * `c` - Channel index
/// * `h_start` - Starting height (can be negative for padding)
/// * `w_start` - Starting width (can be negative for padding)
/// * `in_h` - Input height
/// * `in_w` - Input width
/// * `in_hw` - Precomputed in_h * in_w
///
/// # Returns
/// 4x4 tile with zero-padding for out-of-bounds positions
#[inline]
fn extract_tile(
    input: &[f32],
    c: usize,
    h_start: isize,
    w_start: isize,
    in_h: usize,
    in_w: usize,
    in_hw: usize,
) -> [[f32; 4]; 4] {
    let mut tile = [[0.0f32; 4]; 4];
    let channel_offset = c * in_hw;

    for (ti, tile_row) in tile.iter_mut().enumerate() {
        let h = h_start + ti as isize;
        if h >= 0 && h < in_h as isize {
            for (tj, tile_val) in tile_row.iter_mut().enumerate() {
                let w = w_start + tj as isize;
                if w >= 0 && w < in_w as isize {
                    *tile_val = input[channel_offset + h as usize * in_w + w as usize];
                }
            }
        }
    }

    tile
}

/// Winograd F(2,3) convolution for 3x3 kernels with stride 1.
///
/// This function performs convolution using the Winograd algorithm, which
/// trades multiplications for additions to achieve ~2.25x arithmetic reduction.
///
/// # Arguments
/// * `output` - Output tensor [N, C_out, H_out, W_out]
/// * `input` - Input tensor [N, C_in, H_in, W_in]
/// * `prepacked_filter` - Pre-transformed filter from TransformCache
/// * `bias` - Optional bias [C_out]
/// * `batch` - Batch size
/// * `in_channels` - Number of input channels
/// * `in_height` - Input height
/// * `in_width` - Input width
/// * `out_channels` - Number of output channels
/// * `out_height` - Output height
/// * `out_width` - Output width
/// * `pad_h` - Padding height
/// * `pad_w` - Padding width
///
/// # Panics
/// Panics if the prepacked filter doesn't have tile_size 4 (F(2,3) variant).
#[allow(clippy::too_many_arguments)]
pub fn winograd_conv2d_f23(
    output: &mut [f32],
    input: &[f32],
    prepacked_filter: &PrepackedFilter,
    bias: Option<&[f32]>,
    batch: usize,
    in_channels: usize,
    in_height: usize,
    in_width: usize,
    out_channels: usize,
    out_height: usize,
    out_width: usize,
    pad_h: usize,
    pad_w: usize,
) {
    assert_eq!(prepacked_filter.tile_size, 4, "F(2,3) requires tile_size 4");
    assert_eq!(prepacked_filter.out_channels, out_channels);
    assert_eq!(prepacked_filter.in_channels, in_channels);

    let in_hw = in_height * in_width;
    let in_chw = in_channels * in_hw;
    let out_hw = out_height * out_width;
    let out_chw = out_channels * out_hw;

    // Number of 2x2 output tiles
    let tiles_h = out_height.div_ceil(2);
    let tiles_w = out_width.div_ceil(2);
    let num_tiles = tiles_h * tiles_w;

    // Pre-transformed filter data: [out_channels, in_channels, 4, 4]
    let filter_data = prepacked_filter.as_slice();

    for n in 0..batch {
        let input_batch = &input[n * in_chw..];
        let output_batch = &mut output[n * out_chw..];

        // Process each output channel
        for oc in 0..out_channels {
            // Accumulator for this output channel's tiles
            // We'll process all tiles for this output channel
            let mut tile_accum = vec![[[0.0f32; 4]; 4]; num_tiles];

            // Accumulate contributions from all input channels
            for ic in 0..in_channels {
                // Get the transformed filter for this (oc, ic) pair
                let filter_offset = (oc * in_channels + ic) * 16;

                // Process each tile (flattened loop)
                for (tile_idx, tile_acc) in tile_accum.iter_mut().enumerate() {
                    let th = tile_idx / tiles_w;
                    let tw = tile_idx % tiles_w;

                    // Input tile position (accounting for padding)
                    let h_start = (th * 2) as isize - pad_h as isize;
                    let w_start = (tw * 2) as isize - pad_w as isize;

                    // Extract and transform input tile
                    let d = extract_tile(
                        input_batch,
                        ic,
                        h_start,
                        w_start,
                        in_height,
                        in_width,
                        in_hw,
                    );
                    let v = input_transform_f23(&d);

                    // Element-wise multiply and accumulate
                    for i in 0..4 {
                        for j in 0..4 {
                            tile_acc[i][j] += filter_data[filter_offset + i * 4 + j] * v[i][j];
                        }
                    }
                }
            }

            // Transform accumulated tiles back to spatial domain and write output
            for (tile_idx, tile_acc) in tile_accum.iter().enumerate() {
                let th = tile_idx / tiles_w;
                let tw = tile_idx % tiles_w;

                // Output transform
                let y = output_transform_f23(tile_acc);

                // Write 2x2 output tile (with bounds checking for edge tiles)
                let oh_base = th * 2;
                let ow_base = tw * 2;

                for (ti, y_row) in y.iter().enumerate() {
                    let oh = oh_base + ti;
                    if oh < out_height {
                        for (tj, &y_val) in y_row.iter().enumerate() {
                            let ow = ow_base + tj;
                            if ow < out_width {
                                let out_idx = oc * out_hw + oh * out_width + ow;
                                let mut val = y_val;

                                // Add bias if present
                                if let Some(b) = bias {
                                    val += b[oc];
                                }

                                output_batch[out_idx] = val;
                            }
                        }
                    }
                }
            }
        }
    }
}

/// Check if Winograd convolution is applicable and beneficial.
///
/// Winograd is beneficial for:
/// - 3x3 kernels
/// - Stride 1
/// - No dilation (or dilation 1)
/// - Sufficiently large output (overhead threshold)
#[inline]
#[allow(clippy::too_many_arguments)]
pub fn should_use_winograd(
    kernel_h: usize,
    kernel_w: usize,
    stride_h: usize,
    stride_w: usize,
    dilation_h: usize,
    dilation_w: usize,
    out_height: usize,
    out_width: usize,
) -> bool {
    kernel_h == 3
        && kernel_w == 3
        && stride_h == 1
        && stride_w == 1
        && dilation_h <= 1
        && dilation_w <= 1
        && out_height * out_width >= 16 // Overhead threshold
}

/// Reconstruct a `PrepackedFilter` from raw bytes stored in `BackendPlan.constant_data`.
///
/// This function converts pre-transformed Winograd filter data back into a usable
/// `PrepackedFilter` struct. The data must have been created by `finalize_with_weights()`
/// in the compiler pipeline.
///
/// # Arguments
/// * `data` - Raw bytes containing little-endian f32 values
/// * `out_channels` - Number of output channels (filters)
/// * `in_channels` - Number of input channels
/// * `variant` - Winograd variant (F23 or F43)
///
/// # Returns
/// A `PrepackedFilter` ready for use in Winograd convolution.
///
/// # Panics
/// Panics if the data size doesn't match the expected size for the given dimensions.
///
/// # Example
/// ```rust,ignore
/// let offset = params.extra[6];
/// let size = params.extra[7];
/// let data = &plan.constant_data[offset..offset + size];
///
/// let filter = prepacked_filter_from_bytes(
///     data,
///     params.extra[0], // out_channels
///     params.extra[1], // in_channels
///     WinogradVariant::F23,
/// );
/// ```
pub fn prepacked_filter_from_bytes(
    data: &[u8],
    out_channels: usize,
    in_channels: usize,
    variant: crate::layout::WinogradVariant,
) -> PrepackedFilter {
    use crate::layout::WinogradVariant;

    let tile_size = match variant {
        WinogradVariant::F23 => 4,
        WinogradVariant::F43 => 6,
    };

    let expected_elements = out_channels * in_channels * tile_size * tile_size;
    let expected_bytes = expected_elements * 4; // sizeof(f32)

    assert_eq!(
        data.len(),
        expected_bytes,
        "Data size mismatch: expected {} bytes, got {}",
        expected_bytes,
        data.len()
    );

    // Convert bytes to f32 vector
    let float_data: Vec<f32> = data
        .chunks_exact(4)
        .map(|chunk| {
            let bytes: [u8; 4] = chunk.try_into().unwrap();
            f32::from_le_bytes(bytes)
        })
        .collect();

    PrepackedFilter {
        data: float_data,
        out_channels,
        in_channels,
        variant,
        tile_size,
    }
}

/// Create a reference view of prepacked filter data without copying.
///
/// This is a zero-copy version that returns a slice view of the data
/// for read-only access. Use this when you need temporary access without
/// allocation overhead.
///
/// # Safety
/// The returned slice borrows from the input data slice. Ensure the
/// input data outlives any use of the returned slice.
#[inline]
pub fn prepacked_filter_data_view(
    data: &[u8],
    out_channels: usize,
    in_channels: usize,
    variant: crate::layout::WinogradVariant,
) -> &[f32] {
    use crate::layout::WinogradVariant;

    let tile_size = match variant {
        WinogradVariant::F23 => 4,
        WinogradVariant::F43 => 6,
    };

    let expected_elements = out_channels * in_channels * tile_size * tile_size;
    let expected_bytes = expected_elements * 4;

    assert_eq!(
        data.len(),
        expected_bytes,
        "Data size mismatch: expected {} bytes, got {}",
        expected_bytes,
        data.len()
    );

    // SAFETY: We've verified the size is correct and f32 has alignment 4.
    // The slice is valid for the lifetime of the input data.
    unsafe { std::slice::from_raw_parts(data.as_ptr() as *const f32, expected_elements) }
}

// ============================================================================
// SIMD-OPTIMIZED WINOGRAD IMPLEMENTATION
// ============================================================================

#[cfg(target_arch = "x86_64")]
use core::arch::x86_64::*;

#[cfg(target_arch = "aarch64")]
use core::arch::aarch64::*;

/// SIMD-optimized input transform: V = B^T @ d @ B for a 4x4 tile.
///
/// Uses AVX2 on x86_64 or NEON on aarch64 to process rows in parallel.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2", enable = "fma")]
#[inline]
unsafe fn input_transform_f23_avx2(tile: &[[f32; 4]; 4]) -> [[f32; 4]; 4] {
    // Load tile rows into SIMD registers (only need lower 4 floats)
    let d0 = _mm_loadu_ps(tile[0].as_ptr());
    let d1 = _mm_loadu_ps(tile[1].as_ptr());
    let d2 = _mm_loadu_ps(tile[2].as_ptr());
    let d3 = _mm_loadu_ps(tile[3].as_ptr());

    // B^T @ d: Apply B^T row by row
    // BT[0] = [1, 0, -1, 0]  => d0 - d2
    // BT[1] = [0, 1, 1, 0]   => d1 + d2
    // BT[2] = [0, -1, 1, 0]  => -d1 + d2
    // BT[3] = [0, 1, 0, -1]  => d1 - d3
    let t0 = _mm_sub_ps(d0, d2);
    let t1 = _mm_add_ps(d1, d2);
    let t2 = _mm_sub_ps(d2, d1);
    let t3 = _mm_sub_ps(d1, d3);

    // Now apply @ B (transpose of B^T):
    // For each row, compute: temp[i][0]*B[0][j] + temp[i][1]*B[1][j] + ...
    // B[0] = [1, 0, 0, 0], B[1] = [0, 1, -1, 1], B[2] = [-1, 1, 1, 0], B[3] = [0, 0, 0, -1]
    //
    // result[i][0] = t[i][0] - t[i][2]
    // result[i][1] = t[i][1] + t[i][2]
    // result[i][2] = t[i][2] - t[i][1]
    // result[i][3] = t[i][1] - t[i][3]

    // Transpose to work column-wise, then apply B
    // Using shuffle/unpack pattern for 4x4 transpose
    let tmp0 = _mm_unpacklo_ps(t0, t1);
    let tmp1 = _mm_unpacklo_ps(t2, t3);
    let tmp2 = _mm_unpackhi_ps(t0, t1);
    let tmp3 = _mm_unpackhi_ps(t2, t3);

    let col0 = _mm_movelh_ps(tmp0, tmp1);
    let col1 = _mm_movehl_ps(tmp1, tmp0);
    let col2 = _mm_movelh_ps(tmp2, tmp3);
    let col3 = _mm_movehl_ps(tmp3, tmp2);

    // Apply B columnwise (same operations as before but on columns)
    let r0 = _mm_sub_ps(col0, col2);
    let r1 = _mm_add_ps(col1, col2);
    let r2 = _mm_sub_ps(col2, col1);
    let r3 = _mm_sub_ps(col1, col3);

    // Transpose back
    let tmp0 = _mm_unpacklo_ps(r0, r1);
    let tmp1 = _mm_unpacklo_ps(r2, r3);
    let tmp2 = _mm_unpackhi_ps(r0, r1);
    let tmp3 = _mm_unpackhi_ps(r2, r3);

    let out0 = _mm_movelh_ps(tmp0, tmp1);
    let out1 = _mm_movehl_ps(tmp1, tmp0);
    let out2 = _mm_movelh_ps(tmp2, tmp3);
    let out3 = _mm_movehl_ps(tmp3, tmp2);

    let mut result = [[0.0f32; 4]; 4];
    _mm_storeu_ps(result[0].as_mut_ptr(), out0);
    _mm_storeu_ps(result[1].as_mut_ptr(), out1);
    _mm_storeu_ps(result[2].as_mut_ptr(), out2);
    _mm_storeu_ps(result[3].as_mut_ptr(), out3);

    result
}

/// SIMD-optimized output transform: Y = A^T @ M @ A for a 4x4 tile.
///
/// Produces 2x2 output from 4x4 Winograd domain tile.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2", enable = "fma")]
#[inline]
unsafe fn output_transform_f23_avx2(m: &[[f32; 4]; 4]) -> [[f32; 2]; 2] {
    // Load rows
    let m0 = _mm_loadu_ps(m[0].as_ptr());
    let m1 = _mm_loadu_ps(m[1].as_ptr());
    let m2 = _mm_loadu_ps(m[2].as_ptr());
    let m3 = _mm_loadu_ps(m[3].as_ptr());

    // A^T @ M: Apply A^T row by row
    // AT[0] = [1, 1, 1, 0]  => m0 + m1 + m2
    // AT[1] = [0, 1, -1, -1] => m1 - m2 - m3
    let t0 = _mm_add_ps(_mm_add_ps(m0, m1), m2);
    let t1 = _mm_sub_ps(_mm_sub_ps(m1, m2), m3);

    // Now apply @ A (columns):
    // A[0] = [1, 0], A[1] = [1, 1], A[2] = [1, -1], A[3] = [0, -1]
    // result[i][0] = t[i][0] + t[i][1] + t[i][2]
    // result[i][1] = t[i][1] - t[i][2] - t[i][3]

    // Extract individual elements for final 2x2
    let t0_arr = [
        _mm_cvtss_f32(t0),
        _mm_cvtss_f32(_mm_shuffle_ps(t0, t0, 0x55)),
        _mm_cvtss_f32(_mm_shuffle_ps(t0, t0, 0xAA)),
        _mm_cvtss_f32(_mm_shuffle_ps(t0, t0, 0xFF)),
    ];
    let t1_arr = [
        _mm_cvtss_f32(t1),
        _mm_cvtss_f32(_mm_shuffle_ps(t1, t1, 0x55)),
        _mm_cvtss_f32(_mm_shuffle_ps(t1, t1, 0xAA)),
        _mm_cvtss_f32(_mm_shuffle_ps(t1, t1, 0xFF)),
    ];

    [
        [
            t0_arr[0] + t0_arr[1] + t0_arr[2],
            t0_arr[1] - t0_arr[2] - t0_arr[3],
        ],
        [
            t1_arr[0] + t1_arr[1] + t1_arr[2],
            t1_arr[1] - t1_arr[2] - t1_arr[3],
        ],
    ]
}

/// SIMD-optimized element-wise multiply and accumulate for 4x4 tiles.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2", enable = "fma")]
#[inline]
unsafe fn multiply_accumulate_f23_avx2(
    accum: &mut [[f32; 4]; 4],
    u: &[[f32; 4]; 4],
    v: &[[f32; 4]; 4],
) {
    // Process all 16 elements using FMA
    for i in 0..4 {
        let a = _mm_loadu_ps(accum[i].as_ptr());
        let u_vec = _mm_loadu_ps(u[i].as_ptr());
        let v_vec = _mm_loadu_ps(v[i].as_ptr());
        let result = _mm_fmadd_ps(u_vec, v_vec, a);
        _mm_storeu_ps(accum[i].as_mut_ptr(), result);
    }
}

/// NEON-optimized input transform for aarch64.
#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn input_transform_f23_neon(tile: &[[f32; 4]; 4]) -> [[f32; 4]; 4] {
    // Load tile rows
    let d0 = vld1q_f32(tile[0].as_ptr());
    let d1 = vld1q_f32(tile[1].as_ptr());
    let d2 = vld1q_f32(tile[2].as_ptr());
    let d3 = vld1q_f32(tile[3].as_ptr());

    // B^T @ d
    let t0 = vsubq_f32(d0, d2);
    let t1 = vaddq_f32(d1, d2);
    let t2 = vsubq_f32(d2, d1);
    let t3 = vsubq_f32(d1, d3);

    // Transpose using NEON intrinsics
    let tmp01_lo = vzip1q_f32(t0, t1);
    let tmp01_hi = vzip2q_f32(t0, t1);
    let tmp23_lo = vzip1q_f32(t2, t3);
    let tmp23_hi = vzip2q_f32(t2, t3);

    let col0 = vcombine_f32(vget_low_f32(tmp01_lo), vget_low_f32(tmp23_lo));
    let col1 = vcombine_f32(vget_high_f32(tmp01_lo), vget_high_f32(tmp23_lo));
    let col2 = vcombine_f32(vget_low_f32(tmp01_hi), vget_low_f32(tmp23_hi));
    let col3 = vcombine_f32(vget_high_f32(tmp01_hi), vget_high_f32(tmp23_hi));

    // @ B
    let r0 = vsubq_f32(col0, col2);
    let r1 = vaddq_f32(col1, col2);
    let r2 = vsubq_f32(col2, col1);
    let r3 = vsubq_f32(col1, col3);

    // Transpose back
    let tmp01_lo = vzip1q_f32(r0, r1);
    let tmp01_hi = vzip2q_f32(r0, r1);
    let tmp23_lo = vzip1q_f32(r2, r3);
    let tmp23_hi = vzip2q_f32(r2, r3);

    let out0 = vcombine_f32(vget_low_f32(tmp01_lo), vget_low_f32(tmp23_lo));
    let out1 = vcombine_f32(vget_high_f32(tmp01_lo), vget_high_f32(tmp23_lo));
    let out2 = vcombine_f32(vget_low_f32(tmp01_hi), vget_low_f32(tmp23_hi));
    let out3 = vcombine_f32(vget_high_f32(tmp01_hi), vget_high_f32(tmp23_hi));

    let mut result = [[0.0f32; 4]; 4];
    vst1q_f32(result[0].as_mut_ptr(), out0);
    vst1q_f32(result[1].as_mut_ptr(), out1);
    vst1q_f32(result[2].as_mut_ptr(), out2);
    vst1q_f32(result[3].as_mut_ptr(), out3);

    result
}

/// NEON-optimized output transform for aarch64.
#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn output_transform_f23_neon(m: &[[f32; 4]; 4]) -> [[f32; 2]; 2] {
    let m0 = vld1q_f32(m[0].as_ptr());
    let m1 = vld1q_f32(m[1].as_ptr());
    let m2 = vld1q_f32(m[2].as_ptr());
    let m3 = vld1q_f32(m[3].as_ptr());

    // A^T @ M
    let t0 = vaddq_f32(vaddq_f32(m0, m1), m2);
    let t1 = vsubq_f32(vsubq_f32(m1, m2), m3);

    // Extract and compute final 2x2
    let t0_arr: [f32; 4] = std::mem::transmute(t0);
    let t1_arr: [f32; 4] = std::mem::transmute(t1);

    [
        [
            t0_arr[0] + t0_arr[1] + t0_arr[2],
            t0_arr[1] - t0_arr[2] - t0_arr[3],
        ],
        [
            t1_arr[0] + t1_arr[1] + t1_arr[2],
            t1_arr[1] - t1_arr[2] - t1_arr[3],
        ],
    ]
}

/// NEON-optimized multiply-accumulate for aarch64.
#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn multiply_accumulate_f23_neon(
    accum: &mut [[f32; 4]; 4],
    u: &[[f32; 4]; 4],
    v: &[[f32; 4]; 4],
) {
    for i in 0..4 {
        let a = vld1q_f32(accum[i].as_ptr());
        let u_vec = vld1q_f32(u[i].as_ptr());
        let v_vec = vld1q_f32(v[i].as_ptr());
        let result = vfmaq_f32(a, u_vec, v_vec);
        vst1q_f32(accum[i].as_mut_ptr(), result);
    }
}

/// SIMD-optimized Winograd F(2,3) convolution.
///
/// This version uses AVX2/NEON for the transforms and accumulation,
/// providing significant speedup over the scalar implementation.
#[allow(clippy::too_many_arguments)]
pub fn winograd_conv2d_f23_simd(
    output: &mut [f32],
    input: &[f32],
    prepacked_filter: &PrepackedFilter,
    bias: Option<&[f32]>,
    batch: usize,
    in_channels: usize,
    in_height: usize,
    in_width: usize,
    out_channels: usize,
    out_height: usize,
    out_width: usize,
    pad_h: usize,
    pad_w: usize,
) {
    #[cfg(target_arch = "x86_64")]
    {
        if is_x86_feature_detected!("avx2") && is_x86_feature_detected!("fma") {
            unsafe {
                winograd_conv2d_f23_avx2(
                    output,
                    input,
                    prepacked_filter,
                    bias,
                    batch,
                    in_channels,
                    in_height,
                    in_width,
                    out_channels,
                    out_height,
                    out_width,
                    pad_h,
                    pad_w,
                );
            }
            return;
        }
    }

    #[cfg(target_arch = "aarch64")]
    {
        unsafe {
            winograd_conv2d_f23_neon(
                output,
                input,
                prepacked_filter,
                bias,
                batch,
                in_channels,
                in_height,
                in_width,
                out_channels,
                out_height,
                out_width,
                pad_h,
                pad_w,
            );
        }
        return;
    }

    // Fallback to scalar implementation
    #[allow(unreachable_code)]
    winograd_conv2d_f23(
        output,
        input,
        prepacked_filter,
        bias,
        batch,
        in_channels,
        in_height,
        in_width,
        out_channels,
        out_height,
        out_width,
        pad_h,
        pad_w,
    );
}

/// AVX2-optimized Winograd convolution implementation.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2", enable = "fma")]
#[allow(clippy::too_many_arguments)]
unsafe fn winograd_conv2d_f23_avx2(
    output: &mut [f32],
    input: &[f32],
    prepacked_filter: &PrepackedFilter,
    bias: Option<&[f32]>,
    batch: usize,
    in_channels: usize,
    in_height: usize,
    in_width: usize,
    out_channels: usize,
    out_height: usize,
    out_width: usize,
    pad_h: usize,
    pad_w: usize,
) {
    assert_eq!(prepacked_filter.tile_size, 4, "F(2,3) requires tile_size 4");

    let in_hw = in_height * in_width;
    let in_chw = in_channels * in_hw;
    let out_hw = out_height * out_width;
    let out_chw = out_channels * out_hw;

    let tiles_h = out_height.div_ceil(2);
    let tiles_w = out_width.div_ceil(2);
    let num_tiles = tiles_h * tiles_w;

    let filter_data = prepacked_filter.as_slice();

    for n in 0..batch {
        let input_batch = &input[n * in_chw..];
        let output_batch = &mut output[n * out_chw..];

        // Process output channels
        for oc in 0..out_channels {
            // Stack-allocated tile accumulators (avoid heap allocation)
            // For large num_tiles, we process in chunks
            const MAX_TILES_STACK: usize = 256;
            let mut tile_accum_storage = [[[0.0f32; 4]; 4]; MAX_TILES_STACK];

            // Process tiles in chunks if necessary
            for tile_chunk_start in (0..num_tiles).step_by(MAX_TILES_STACK) {
                let chunk_end = (tile_chunk_start + MAX_TILES_STACK).min(num_tiles);
                let chunk_size = chunk_end - tile_chunk_start;

                // Zero the accumulators for this chunk
                for accum in tile_accum_storage.iter_mut().take(chunk_size) {
                    *accum = [[0.0f32; 4]; 4];
                }

                // Accumulate over input channels
                for ic in 0..in_channels {
                    let filter_offset = (oc * in_channels + ic) * 16;
                    let u: [[f32; 4]; 4] = [
                        [
                            filter_data[filter_offset],
                            filter_data[filter_offset + 1],
                            filter_data[filter_offset + 2],
                            filter_data[filter_offset + 3],
                        ],
                        [
                            filter_data[filter_offset + 4],
                            filter_data[filter_offset + 5],
                            filter_data[filter_offset + 6],
                            filter_data[filter_offset + 7],
                        ],
                        [
                            filter_data[filter_offset + 8],
                            filter_data[filter_offset + 9],
                            filter_data[filter_offset + 10],
                            filter_data[filter_offset + 11],
                        ],
                        [
                            filter_data[filter_offset + 12],
                            filter_data[filter_offset + 13],
                            filter_data[filter_offset + 14],
                            filter_data[filter_offset + 15],
                        ],
                    ];

                    // Process tiles in this chunk
                    for (local_idx, global_idx) in (tile_chunk_start..chunk_end).enumerate() {
                        let th = global_idx / tiles_w;
                        let tw = global_idx % tiles_w;

                        let h_start = (th * 2) as isize - pad_h as isize;
                        let w_start = (tw * 2) as isize - pad_w as isize;

                        let d = extract_tile(
                            input_batch,
                            ic,
                            h_start,
                            w_start,
                            in_height,
                            in_width,
                            in_hw,
                        );

                        // SIMD input transform
                        let v = input_transform_f23_avx2(&d);

                        // SIMD multiply-accumulate
                        multiply_accumulate_f23_avx2(&mut tile_accum_storage[local_idx], &u, &v);
                    }
                }

                // Transform and write output for this chunk
                for (local_idx, global_idx) in (tile_chunk_start..chunk_end).enumerate() {
                    let th = global_idx / tiles_w;
                    let tw = global_idx % tiles_w;

                    // SIMD output transform
                    let y = output_transform_f23_avx2(&tile_accum_storage[local_idx]);

                    let oh_base = th * 2;
                    let ow_base = tw * 2;

                    for (ti, y_row) in y.iter().enumerate() {
                        let oh = oh_base + ti;
                        if oh < out_height {
                            for (tj, &y_val) in y_row.iter().enumerate() {
                                let ow = ow_base + tj;
                                if ow < out_width {
                                    let out_idx = oc * out_hw + oh * out_width + ow;
                                    let mut val = y_val;
                                    if let Some(b) = bias {
                                        val += b[oc];
                                    }
                                    output_batch[out_idx] = val;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// NEON-optimized Winograd convolution implementation.
#[cfg(target_arch = "aarch64")]
#[allow(clippy::too_many_arguments)]
unsafe fn winograd_conv2d_f23_neon(
    output: &mut [f32],
    input: &[f32],
    prepacked_filter: &PrepackedFilter,
    bias: Option<&[f32]>,
    batch: usize,
    in_channels: usize,
    in_height: usize,
    in_width: usize,
    out_channels: usize,
    out_height: usize,
    out_width: usize,
    pad_h: usize,
    pad_w: usize,
) {
    assert_eq!(prepacked_filter.tile_size, 4, "F(2,3) requires tile_size 4");

    let in_hw = in_height * in_width;
    let in_chw = in_channels * in_hw;
    let out_hw = out_height * out_width;
    let out_chw = out_channels * out_hw;

    let tiles_h = out_height.div_ceil(2);
    let tiles_w = out_width.div_ceil(2);
    let num_tiles = tiles_h * tiles_w;

    let filter_data = prepacked_filter.as_slice();

    for n in 0..batch {
        let input_batch = &input[n * in_chw..];
        let output_batch = &mut output[n * out_chw..];

        for oc in 0..out_channels {
            const MAX_TILES_STACK: usize = 256;
            let mut tile_accum_storage = [[[0.0f32; 4]; 4]; MAX_TILES_STACK];

            for tile_chunk_start in (0..num_tiles).step_by(MAX_TILES_STACK) {
                let chunk_end = (tile_chunk_start + MAX_TILES_STACK).min(num_tiles);
                let chunk_size = chunk_end - tile_chunk_start;

                for accum in tile_accum_storage.iter_mut().take(chunk_size) {
                    *accum = [[0.0f32; 4]; 4];
                }

                for ic in 0..in_channels {
                    let filter_offset = (oc * in_channels + ic) * 16;
                    let u: [[f32; 4]; 4] = [
                        [
                            filter_data[filter_offset],
                            filter_data[filter_offset + 1],
                            filter_data[filter_offset + 2],
                            filter_data[filter_offset + 3],
                        ],
                        [
                            filter_data[filter_offset + 4],
                            filter_data[filter_offset + 5],
                            filter_data[filter_offset + 6],
                            filter_data[filter_offset + 7],
                        ],
                        [
                            filter_data[filter_offset + 8],
                            filter_data[filter_offset + 9],
                            filter_data[filter_offset + 10],
                            filter_data[filter_offset + 11],
                        ],
                        [
                            filter_data[filter_offset + 12],
                            filter_data[filter_offset + 13],
                            filter_data[filter_offset + 14],
                            filter_data[filter_offset + 15],
                        ],
                    ];

                    for (local_idx, global_idx) in (tile_chunk_start..chunk_end).enumerate() {
                        let th = global_idx / tiles_w;
                        let tw = global_idx % tiles_w;

                        let h_start = (th * 2) as isize - pad_h as isize;
                        let w_start = (tw * 2) as isize - pad_w as isize;

                        let d = extract_tile(
                            input_batch,
                            ic,
                            h_start,
                            w_start,
                            in_height,
                            in_width,
                            in_hw,
                        );

                        let v = input_transform_f23_neon(&d);
                        multiply_accumulate_f23_neon(&mut tile_accum_storage[local_idx], &u, &v);
                    }
                }

                for (local_idx, global_idx) in (tile_chunk_start..chunk_end).enumerate() {
                    let th = global_idx / tiles_w;
                    let tw = global_idx % tiles_w;

                    let y = output_transform_f23_neon(&tile_accum_storage[local_idx]);

                    let oh_base = th * 2;
                    let ow_base = tw * 2;

                    for (ti, y_row) in y.iter().enumerate() {
                        let oh = oh_base + ti;
                        if oh < out_height {
                            for (tj, &y_val) in y_row.iter().enumerate() {
                                let ow = ow_base + tj;
                                if ow < out_width {
                                    let out_idx = oc * out_hw + oh * out_width + ow;
                                    let mut val = y_val;
                                    if let Some(b) = bias {
                                        val += b[oc];
                                    }
                                    output_batch[out_idx] = val;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// OPTIMIZED WINOGRAD WITH CACHED INPUT TRANSFORMS
// ============================================================================

/// Optimized Winograd F(2,3) convolution with cached input transforms.
///
/// This implementation addresses the key inefficiency in the original algorithm:
/// input transforms are computed once per (tile, input_channel) pair and reused
/// across all output channels, providing up to OC× speedup for the transform phase.
///
/// # Algorithm
/// 1. **Phase 1**: Compute V_cache[tile][ic] = input_transform(tile, ic) once
/// 2. **Phase 2**: For each output channel, accumulate M += U[oc][ic] * V_cache[tile][ic]
///
/// # Performance
/// - Eliminates redundant input transforms (was: OC × IC × tiles, now: IC × tiles)
/// - Uses Rayon parallelization for large workloads (>4096 total ops)
/// - Stack-allocated accumulators to avoid heap allocation in hot path
#[allow(clippy::too_many_arguments)]
pub fn winograd_conv2d_f23_optimized(
    output: &mut [f32],
    input: &[f32],
    prepacked_filter: &PrepackedFilter,
    bias: Option<&[f32]>,
    batch: usize,
    in_channels: usize,
    in_height: usize,
    in_width: usize,
    out_channels: usize,
    out_height: usize,
    out_width: usize,
    pad_h: usize,
    pad_w: usize,
) {
    let tiles_h = out_height.div_ceil(2);
    let tiles_w = out_width.div_ceil(2);
    let num_tiles = tiles_h * tiles_w;
    let total_work = num_tiles * out_channels;

    // Select implementation based on work size
    #[cfg(feature = "parallel")]
    if total_work >= PARALLEL_THRESHOLD && out_channels >= 4 {
        winograd_conv2d_f23_parallel(
            output,
            input,
            prepacked_filter,
            bias,
            batch,
            in_channels,
            in_height,
            in_width,
            out_channels,
            out_height,
            out_width,
            pad_h,
            pad_w,
        );
        return;
    }

    // Sequential path with cached transforms
    winograd_conv2d_f23_cached_sequential(
        output,
        input,
        prepacked_filter,
        bias,
        batch,
        in_channels,
        in_height,
        in_width,
        out_channels,
        out_height,
        out_width,
        pad_h,
        pad_w,
    );
}

/// Sequential Winograd with cached input transforms.
///
/// Caches input transforms in V_cache to avoid redundant computation across
/// output channels. Processes tiles in chunks to fit L2 cache.
#[allow(clippy::too_many_arguments)]
fn winograd_conv2d_f23_cached_sequential(
    output: &mut [f32],
    input: &[f32],
    prepacked_filter: &PrepackedFilter,
    bias: Option<&[f32]>,
    batch: usize,
    in_channels: usize,
    in_height: usize,
    in_width: usize,
    out_channels: usize,
    out_height: usize,
    out_width: usize,
    pad_h: usize,
    pad_w: usize,
) {
    assert_eq!(prepacked_filter.tile_size, 4, "F(2,3) requires tile_size 4");

    let in_hw = in_height * in_width;
    let in_chw = in_channels * in_hw;
    let out_hw = out_height * out_width;
    let out_chw = out_channels * out_hw;

    let tiles_h = out_height.div_ceil(2);
    let tiles_w = out_width.div_ceil(2);
    let num_tiles = tiles_h * tiles_w;

    let filter_data = prepacked_filter.as_slice();

    // Pre-allocate V_cache for tile chunks
    // Layout: v_cache[local_tile * in_channels + ic] = transformed tile
    let chunk_size = MAX_CACHED_TILES.min(num_tiles);
    let v_cache_len = chunk_size * in_channels;
    let mut v_cache: Vec<[[f32; 4]; 4]> = vec![[[0.0; 4]; 4]; v_cache_len];

    for n in 0..batch {
        let input_batch = &input[n * in_chw..];
        let output_batch = &mut output[n * out_chw..];

        // Process tiles in cache-friendly chunks
        for tile_chunk_start in (0..num_tiles).step_by(chunk_size) {
            let tile_chunk_end = (tile_chunk_start + chunk_size).min(num_tiles);
            let tiles_in_chunk = tile_chunk_end - tile_chunk_start;

            // PHASE 1: Compute input transforms for this chunk (all input channels)
            // This is computed ONCE and reused for ALL output channels
            for local_tile in 0..tiles_in_chunk {
                let global_tile = tile_chunk_start + local_tile;
                let th = global_tile / tiles_w;
                let tw = global_tile % tiles_w;
                let h_start = (th * 2) as isize - pad_h as isize;
                let w_start = (tw * 2) as isize - pad_w as isize;

                for ic in 0..in_channels {
                    let d = extract_tile(
                        input_batch,
                        ic,
                        h_start,
                        w_start,
                        in_height,
                        in_width,
                        in_hw,
                    );

                    // Store in V_cache
                    let cache_idx = local_tile * in_channels + ic;
                    v_cache[cache_idx] = input_transform_f23(&d);
                }
            }

            // PHASE 2: Process all output channels using cached V
            for oc in 0..out_channels {
                let bias_val = bias.map(|b| b[oc]).unwrap_or(0.0);

                for local_tile in 0..tiles_in_chunk {
                    // Stack-allocated accumulator (no heap allocation)
                    let mut m_accum = [[0.0f32; 4]; 4];

                    // Accumulate over input channels using CACHED transforms
                    for ic in 0..in_channels {
                        let filter_offset = (oc * in_channels + ic) * 16;
                        let cache_idx = local_tile * in_channels + ic;
                        let v = &v_cache[cache_idx];

                        // Element-wise multiply-accumulate
                        for i in 0..4 {
                            for j in 0..4 {
                                m_accum[i][j] += filter_data[filter_offset + i * 4 + j] * v[i][j];
                            }
                        }
                    }

                    // Output transform
                    let y = output_transform_f23(&m_accum);

                    // Write output
                    let global_tile = tile_chunk_start + local_tile;
                    let th = global_tile / tiles_w;
                    let tw = global_tile % tiles_w;
                    let oh_base = th * 2;
                    let ow_base = tw * 2;

                    for (ti, y_row) in y.iter().enumerate() {
                        let oh = oh_base + ti;
                        if oh < out_height {
                            for (tj, &y_val) in y_row.iter().enumerate() {
                                let ow = ow_base + tj;
                                if ow < out_width {
                                    let out_idx = oc * out_hw + oh * out_width + ow;
                                    output_batch[out_idx] = y_val + bias_val;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// Parallel Winograd convolution using Rayon.
///
/// Parallelizes over output channels since:
/// 1. Each output channel is independent after V_cache is computed
/// 2. Output channels are typically large (64-512) providing good parallelism
/// 3. Follows the parallel pattern from grouped.rs
#[cfg(feature = "parallel")]
#[allow(clippy::too_many_arguments)]
fn winograd_conv2d_f23_parallel(
    output: &mut [f32],
    input: &[f32],
    prepacked_filter: &PrepackedFilter,
    bias: Option<&[f32]>,
    batch: usize,
    in_channels: usize,
    in_height: usize,
    in_width: usize,
    out_channels: usize,
    out_height: usize,
    out_width: usize,
    pad_h: usize,
    pad_w: usize,
) {
    use rayon::prelude::*;

    assert_eq!(prepacked_filter.tile_size, 4, "F(2,3) requires tile_size 4");

    let in_hw = in_height * in_width;
    let in_chw = in_channels * in_hw;
    let out_hw = out_height * out_width;
    let out_chw = out_channels * out_hw;

    let tiles_h = out_height.div_ceil(2);
    let tiles_w = out_width.div_ceil(2);
    let num_tiles = tiles_h * tiles_w;

    let filter_data = prepacked_filter.as_slice();

    for n in 0..batch {
        let input_batch = &input[n * in_chw..];

        // PHASE 1: Build V_cache (sequential, shared across parallel phase)
        // Layout: v_cache[tile_idx * in_channels + ic]
        let v_cache: Vec<[[f32; 4]; 4]> = (0..num_tiles)
            .flat_map(|tile_idx| {
                let th = tile_idx / tiles_w;
                let tw = tile_idx % tiles_w;
                let h_start = (th * 2) as isize - pad_h as isize;
                let w_start = (tw * 2) as isize - pad_w as isize;

                (0..in_channels).map(move |ic| {
                    let d = extract_tile(
                        input_batch,
                        ic,
                        h_start,
                        w_start,
                        in_height,
                        in_width,
                        in_hw,
                    );
                    input_transform_f23(&d)
                })
            })
            .collect();

        // PHASE 2: Parallel over output channels
        let oc_results: Vec<Vec<f32>> = (0..out_channels)
            .into_par_iter()
            .map(|oc| {
                let mut oc_output = vec![0.0f32; out_hw];
                let bias_val = bias.map(|b| b[oc]).unwrap_or(0.0);

                for tile_idx in 0..num_tiles {
                    let mut m_accum = [[0.0f32; 4]; 4];

                    // Accumulate over input channels using cached transforms
                    for ic in 0..in_channels {
                        let filter_offset = (oc * in_channels + ic) * 16;
                        let v_idx = tile_idx * in_channels + ic;
                        let v = &v_cache[v_idx];

                        for i in 0..4 {
                            for j in 0..4 {
                                m_accum[i][j] += filter_data[filter_offset + i * 4 + j] * v[i][j];
                            }
                        }
                    }

                    // Output transform
                    let y = output_transform_f23(&m_accum);

                    // Write to local output buffer
                    let th = tile_idx / tiles_w;
                    let tw = tile_idx % tiles_w;
                    let oh_base = th * 2;
                    let ow_base = tw * 2;

                    for (ti, y_row) in y.iter().enumerate() {
                        let oh = oh_base + ti;
                        if oh < out_height {
                            for (tj, &y_val) in y_row.iter().enumerate() {
                                let ow = ow_base + tj;
                                if ow < out_width {
                                    oc_output[oh * out_width + ow] = y_val + bias_val;
                                }
                            }
                        }
                    }
                }

                oc_output
            })
            .collect();

        // Copy results to output
        let output_batch = &mut output[n * out_chw..];
        for (oc, oc_data) in oc_results.into_iter().enumerate() {
            let dst_offset = oc * out_hw;
            output_batch[dst_offset..dst_offset + out_hw].copy_from_slice(&oc_data);
        }
    }
}

/// Fallback for non-parallel builds.
#[cfg(not(feature = "parallel"))]
#[allow(clippy::too_many_arguments)]
fn winograd_conv2d_f23_parallel(
    output: &mut [f32],
    input: &[f32],
    prepacked_filter: &PrepackedFilter,
    bias: Option<&[f32]>,
    batch: usize,
    in_channels: usize,
    in_height: usize,
    in_width: usize,
    out_channels: usize,
    out_height: usize,
    out_width: usize,
    pad_h: usize,
    pad_w: usize,
) {
    winograd_conv2d_f23_cached_sequential(
        output,
        input,
        prepacked_filter,
        bias,
        batch,
        in_channels,
        in_height,
        in_width,
        out_channels,
        out_height,
        out_width,
        pad_h,
        pad_w,
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::layout::WinogradVariant;
    use crate::transform_cache::TransformCache;

    #[test]
    fn test_input_transform() {
        // Simple identity-like test
        let tile = [
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ];

        let transformed = input_transform_f23(&tile);

        // Verify dimensions
        assert_eq!(transformed.len(), 4);
        assert_eq!(transformed[0].len(), 4);

        // The transform should produce non-zero values
        let sum: f32 = transformed.iter().flatten().map(|x| x.abs()).sum();
        assert!(sum > 0.0);
    }

    #[test]
    fn test_output_transform() {
        // Test with known values
        let m = [
            [4.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
        ];

        let output = output_transform_f23(&m);

        // Verify dimensions
        assert_eq!(output.len(), 2);
        assert_eq!(output[0].len(), 2);

        // Check that output is valid
        assert!(!output[0][0].is_nan());
    }

    #[test]
    fn test_extract_tile_no_padding() {
        // 4x4 input, extract full tile
        let input: Vec<f32> = (0..16).map(|x| x as f32).collect();
        let tile = extract_tile(&input, 0, 0, 0, 4, 4, 16);

        assert_eq!(tile[0][0], 0.0);
        assert_eq!(tile[0][1], 1.0);
        assert_eq!(tile[1][0], 4.0);
        assert_eq!(tile[3][3], 15.0);
    }

    #[test]
    fn test_extract_tile_with_padding() {
        // 4x4 input, extract tile starting at (-1, -1)
        let input: Vec<f32> = (0..16).map(|x| x as f32).collect();
        let tile = extract_tile(&input, 0, -1, -1, 4, 4, 16);

        // Out of bounds positions should be zero
        assert_eq!(tile[0][0], 0.0);
        assert_eq!(tile[0][1], 0.0);
        assert_eq!(tile[1][0], 0.0);
        // In-bounds positions should have values
        assert_eq!(tile[1][1], 0.0); // input[0][0] = 0
        assert_eq!(tile[1][2], 1.0); // input[0][1] = 1
        assert_eq!(tile[2][1], 4.0); // input[1][0] = 4
    }

    #[test]
    fn test_should_use_winograd() {
        // Should use Winograd
        assert!(should_use_winograd(3, 3, 1, 1, 1, 1, 8, 8));
        assert!(should_use_winograd(3, 3, 1, 1, 0, 0, 4, 4));

        // Should NOT use Winograd
        assert!(!should_use_winograd(5, 5, 1, 1, 1, 1, 8, 8)); // Not 3x3
        assert!(!should_use_winograd(3, 3, 2, 2, 1, 1, 8, 8)); // Not stride 1
        assert!(!should_use_winograd(3, 3, 1, 1, 2, 2, 8, 8)); // Has dilation
        assert!(!should_use_winograd(3, 3, 1, 1, 1, 1, 2, 2)); // Too small
    }

    #[test]
    fn test_winograd_conv2d_identity() {
        // Test with identity-like kernel (center = 1, rest = 0)
        let mut cache = TransformCache::new();

        // 3x3 filter: identity-ish (only center is 1)
        let filter = vec![
            0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, // Single 3x3 filter
        ];

        cache.add_winograd_filter(
            crate::transform_cache::FilterId(0),
            &filter,
            [1, 1, 3, 3],
            WinogradVariant::F23,
        );

        let prepacked = cache
            .get_winograd_filter(crate::transform_cache::FilterId(0))
            .unwrap();

        // 4x4 input (minimum for one 2x2 output tile with padding)
        let input: Vec<f32> = (0..16).map(|x| x as f32).collect();
        let mut output = vec![0.0f32; 4]; // 2x2 output

        winograd_conv2d_f23(
            &mut output,
            &input,
            prepacked,
            None,
            1, // batch
            1, // in_channels
            4, // in_height
            4, // in_width
            1, // out_channels
            2, // out_height
            2, // out_width
            0, // pad_h
            0, // pad_w
        );

        // With identity kernel (center=1), output should match center of each 3x3 window
        // Window at (0,0)-(2,2): center = input[1][1] = 5
        // Window at (0,1)-(2,3): center = input[1][2] = 6
        // Window at (1,0)-(3,2): center = input[2][1] = 9
        // Window at (1,1)-(3,3): center = input[2][2] = 10
        assert!(
            (output[0] - 5.0).abs() < 0.1,
            "Expected 5.0, got {}",
            output[0]
        );
        assert!(
            (output[1] - 6.0).abs() < 0.1,
            "Expected 6.0, got {}",
            output[1]
        );
        assert!(
            (output[2] - 9.0).abs() < 0.1,
            "Expected 9.0, got {}",
            output[2]
        );
        assert!(
            (output[3] - 10.0).abs() < 0.1,
            "Expected 10.0, got {}",
            output[3]
        );
    }

    #[test]
    fn test_winograd_conv2d_with_bias() {
        let mut cache = TransformCache::new();

        let filter = vec![0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0];

        cache.add_winograd_filter(
            crate::transform_cache::FilterId(0),
            &filter,
            [1, 1, 3, 3],
            WinogradVariant::F23,
        );

        let prepacked = cache
            .get_winograd_filter(crate::transform_cache::FilterId(0))
            .unwrap();

        let input: Vec<f32> = (0..16).map(|x| x as f32).collect();
        let bias = vec![100.0];
        let mut output = vec![0.0f32; 4];

        winograd_conv2d_f23(
            &mut output,
            &input,
            prepacked,
            Some(&bias),
            1,
            1,
            4,
            4,
            1,
            2,
            2,
            0,
            0,
        );

        // Each output should have bias added
        assert!(
            (output[0] - 105.0).abs() < 0.1,
            "Expected 105.0, got {}",
            output[0]
        );
    }

    #[test]
    fn test_winograd_vs_direct_conv() {
        // Compare Winograd output with direct convolution
        let mut cache = TransformCache::new();

        // Random-ish 3x3 filter
        let filter = vec![1.0, 2.0, 1.0, 0.0, 0.0, 0.0, -1.0, -2.0, -1.0]; // Sobel-like

        cache.add_winograd_filter(
            crate::transform_cache::FilterId(0),
            &filter,
            [1, 1, 3, 3],
            WinogradVariant::F23,
        );

        let prepacked = cache
            .get_winograd_filter(crate::transform_cache::FilterId(0))
            .unwrap();

        // 6x6 input for 4x4 output
        let input: Vec<f32> = (0..36).map(|x| (x % 10) as f32).collect();
        let mut winograd_output = vec![0.0f32; 16]; // 4x4 output
        let mut direct_output = [0.0f32; 16];

        // Winograd convolution
        winograd_conv2d_f23(
            &mut winograd_output,
            &input,
            prepacked,
            None,
            1,
            1,
            6,
            6,
            1,
            4,
            4,
            0,
            0,
        );

        // Direct convolution for comparison
        for oh in 0..4 {
            for ow in 0..4 {
                let mut sum = 0.0f32;
                for kh in 0..3 {
                    for kw in 0..3 {
                        let ih = oh + kh;
                        let iw = ow + kw;
                        sum += input[ih * 6 + iw] * filter[kh * 3 + kw];
                    }
                }
                direct_output[oh * 4 + ow] = sum;
            }
        }

        // Compare outputs (allow small numerical differences)
        for i in 0..16 {
            assert!(
                (winograd_output[i] - direct_output[i]).abs() < 0.5,
                "Mismatch at {}: winograd={}, direct={}",
                i,
                winograd_output[i],
                direct_output[i]
            );
        }
    }

    #[test]
    fn test_winograd_multi_channel() {
        let mut cache = TransformCache::new();

        // 2 input channels, 2 output channels
        let filter = vec![
            // OC=0, IC=0
            1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, // OC=0, IC=1
            0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, // OC=1, IC=0
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, // OC=1, IC=1
            1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
        ];

        cache.add_winograd_filter(
            crate::transform_cache::FilterId(0),
            &filter,
            [2, 2, 3, 3],
            WinogradVariant::F23,
        );

        let prepacked = cache
            .get_winograd_filter(crate::transform_cache::FilterId(0))
            .unwrap();

        // 2-channel 4x4 input
        let mut input = vec![0.0f32; 2 * 16];
        // Channel 0: sequential
        for (i, item) in input.iter_mut().enumerate().take(16) {
            *item = i as f32;
        }
        // Channel 1: reversed
        for (i, item) in input.iter_mut().enumerate().take(32).skip(16) {
            *item = (31 - i) as f32;
        }

        let mut output = vec![0.0f32; 2 * 4]; // 2 output channels, 2x2 each

        winograd_conv2d_f23(
            &mut output,
            &input,
            prepacked,
            None,
            1,
            2, // in_channels
            4,
            4,
            2, // out_channels
            2,
            2,
            0,
            0,
        );

        // Verify output is not zero (multi-channel accumulation works)
        let total: f32 = output.iter().sum();
        assert!(total.abs() > 0.0, "Multi-channel output should not be zero");
    }

    #[test]
    fn test_prepacked_filter_from_bytes_roundtrip() {
        let mut cache = TransformCache::new();

        // Create a 3x3 filter: 2 output channels, 2 input channels
        let filter: Vec<f32> = (0..36).map(|x| x as f32 * 0.1).collect();

        cache.add_winograd_filter(
            crate::transform_cache::FilterId(0),
            &filter,
            [2, 2, 3, 3],
            WinogradVariant::F23,
        );

        let prepacked = cache
            .get_winograd_filter(crate::transform_cache::FilterId(0))
            .unwrap();

        // Convert to bytes (simulating what finalize_with_weights does)
        let bytes: Vec<u8> = prepacked
            .as_slice()
            .iter()
            .flat_map(|&f| f.to_le_bytes())
            .collect();

        // Reconstruct from bytes
        let reconstructed = prepacked_filter_from_bytes(&bytes, 2, 2, WinogradVariant::F23);

        // Verify reconstruction matches original
        assert_eq!(reconstructed.out_channels, prepacked.out_channels);
        assert_eq!(reconstructed.in_channels, prepacked.in_channels);
        assert_eq!(reconstructed.tile_size, prepacked.tile_size);
        assert_eq!(reconstructed.data.len(), prepacked.data.len());

        // Verify data values match
        for (a, b) in reconstructed.data.iter().zip(prepacked.data.iter()) {
            assert!((a - b).abs() < 1e-6, "Data mismatch: {} vs {}", a, b);
        }
    }

    #[test]
    fn test_prepacked_filter_data_view() {
        let mut cache = TransformCache::new();

        let filter: Vec<f32> = (0..9).map(|x| x as f32).collect();

        cache.add_winograd_filter(
            crate::transform_cache::FilterId(0),
            &filter,
            [1, 1, 3, 3],
            WinogradVariant::F23,
        );

        let prepacked = cache
            .get_winograd_filter(crate::transform_cache::FilterId(0))
            .unwrap();

        // Convert to bytes
        let bytes: Vec<u8> = prepacked
            .as_slice()
            .iter()
            .flat_map(|&f| f.to_le_bytes())
            .collect();

        // Get zero-copy view
        let view = prepacked_filter_data_view(&bytes, 1, 1, WinogradVariant::F23);

        // Verify view matches original
        assert_eq!(view.len(), prepacked.data.len());
        for (a, b) in view.iter().zip(prepacked.data.iter()) {
            assert!((a - b).abs() < 1e-6, "View mismatch: {} vs {}", a, b);
        }
    }

    #[test]
    fn test_winograd_simd_matches_scalar() {
        let mut cache = TransformCache::new();

        // Random-ish 3x3 filter
        let filter = vec![
            0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, // oc=0, ic=0
            0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, // oc=0, ic=1
            0.2, 0.4, 0.6, 0.8, 1.0, 0.8, 0.6, 0.4, 0.2, // oc=1, ic=0
            0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, // oc=1, ic=1
        ];

        cache.add_winograd_filter(
            crate::transform_cache::FilterId(0),
            &filter,
            [2, 2, 3, 3],
            WinogradVariant::F23,
        );

        let prepacked = cache
            .get_winograd_filter(crate::transform_cache::FilterId(0))
            .unwrap();

        // 8x8 input with 2 channels
        let input: Vec<f32> = (0..(2 * 8 * 8)).map(|i| (i % 17) as f32 * 0.1).collect();

        // Output: 2 channels, 8x8 (with padding 1)
        let mut output_scalar = vec![0.0f32; 2 * 8 * 8];
        let mut output_simd = vec![0.0f32; 2 * 8 * 8];

        // Run scalar version
        winograd_conv2d_f23(
            &mut output_scalar,
            &input,
            prepacked,
            None,
            1, // batch
            2, // in_channels
            8, // in_height
            8, // in_width
            2, // out_channels
            8, // out_height
            8, // out_width
            1, // pad_h
            1, // pad_w
        );

        // Run SIMD version
        winograd_conv2d_f23_simd(
            &mut output_simd,
            &input,
            prepacked,
            None,
            1, // batch
            2, // in_channels
            8, // in_height
            8, // in_width
            2, // out_channels
            8, // out_height
            8, // out_width
            1, // pad_h
            1, // pad_w
        );

        // Compare outputs
        for i in 0..output_scalar.len() {
            assert!(
                (output_scalar[i] - output_simd[i]).abs() < 1e-4,
                "Mismatch at index {}: scalar={}, simd={}",
                i,
                output_scalar[i],
                output_simd[i]
            );
        }
    }

    #[test]
    fn test_winograd_optimized_matches_scalar() {
        let mut cache = TransformCache::new();

        // Realistic case: 32 output channels, 16 input channels
        // This tests the V_cache optimization where input transforms
        // should only be computed once per (tile, ic) pair
        let filter: Vec<f32> = (0..(32 * 16 * 9))
            .map(|x| ((x % 17) as f32 - 8.0) * 0.1)
            .collect();

        cache.add_winograd_filter(
            crate::transform_cache::FilterId(0),
            &filter,
            [32, 16, 3, 3],
            WinogradVariant::F23,
        );
        let prepacked = cache
            .get_winograd_filter(crate::transform_cache::FilterId(0))
            .unwrap();

        // 14x14 input -> 14x14 output with padding
        let input: Vec<f32> = (0..(16 * 14 * 14))
            .map(|x| ((x % 23) as f32) * 0.05)
            .collect();

        let mut output_scalar = vec![0.0f32; 32 * 14 * 14];
        let mut output_optimized = vec![0.0f32; 32 * 14 * 14];

        // Run scalar version
        winograd_conv2d_f23(
            &mut output_scalar,
            &input,
            prepacked,
            None,
            1,  // batch
            16, // in_channels
            14, // in_height
            14, // in_width
            32, // out_channels
            14, // out_height
            14, // out_width
            1,  // pad_h
            1,  // pad_w
        );

        // Run optimized version
        winograd_conv2d_f23_optimized(
            &mut output_optimized,
            &input,
            prepacked,
            None,
            1,  // batch
            16, // in_channels
            14, // in_height
            14, // in_width
            32, // out_channels
            14, // out_height
            14, // out_width
            1,  // pad_h
            1,  // pad_w
        );

        // Compare outputs
        for i in 0..output_scalar.len() {
            assert!(
                (output_scalar[i] - output_optimized[i]).abs() < 1e-4,
                "Mismatch at index {}: scalar={}, optimized={}",
                i,
                output_scalar[i],
                output_optimized[i]
            );
        }
    }

    #[test]
    fn test_winograd_optimized_with_bias() {
        let mut cache = TransformCache::new();

        let filter: Vec<f32> = (0..(8 * 4 * 9))
            .map(|x| ((x % 11) as f32 - 5.0) * 0.1)
            .collect();

        cache.add_winograd_filter(
            crate::transform_cache::FilterId(0),
            &filter,
            [8, 4, 3, 3],
            WinogradVariant::F23,
        );
        let prepacked = cache
            .get_winograd_filter(crate::transform_cache::FilterId(0))
            .unwrap();

        let input: Vec<f32> = (0..(4 * 8 * 8)).map(|x| (x % 13) as f32 * 0.1).collect();
        let bias: Vec<f32> = (0..8).map(|x| x as f32 * 0.5).collect();

        let mut output_scalar = vec![0.0f32; 8 * 8 * 8];
        let mut output_optimized = vec![0.0f32; 8 * 8 * 8];

        // Run scalar version with bias
        winograd_conv2d_f23(
            &mut output_scalar,
            &input,
            prepacked,
            Some(&bias),
            1,
            4,
            8,
            8,
            8,
            8,
            8,
            1,
            1,
        );

        // Run optimized version with bias
        winograd_conv2d_f23_optimized(
            &mut output_optimized,
            &input,
            prepacked,
            Some(&bias),
            1,
            4,
            8,
            8,
            8,
            8,
            8,
            1,
            1,
        );

        // Compare outputs
        for i in 0..output_scalar.len() {
            assert!(
                (output_scalar[i] - output_optimized[i]).abs() < 1e-4,
                "Mismatch at index {}: scalar={}, optimized={}",
                i,
                output_scalar[i],
                output_optimized[i]
            );
        }
    }

    #[test]
    fn test_winograd_optimized_large_channels() {
        // Test with larger channel counts to verify parallel path works
        let mut cache = TransformCache::new();

        // 64 output channels, 64 input channels - should trigger parallel path
        let filter: Vec<f32> = (0..(64 * 64 * 9))
            .map(|x| ((x % 19) as f32 - 9.0) * 0.05)
            .collect();

        cache.add_winograd_filter(
            crate::transform_cache::FilterId(0),
            &filter,
            [64, 64, 3, 3],
            WinogradVariant::F23,
        );
        let prepacked = cache
            .get_winograd_filter(crate::transform_cache::FilterId(0))
            .unwrap();

        // 28x28 input (typical ResNet size)
        let input: Vec<f32> = (0..(64 * 28 * 28))
            .map(|x| ((x % 31) as f32) * 0.02)
            .collect();

        let mut output_scalar = vec![0.0f32; 64 * 28 * 28];
        let mut output_optimized = vec![0.0f32; 64 * 28 * 28];

        // Run scalar version
        winograd_conv2d_f23(
            &mut output_scalar,
            &input,
            prepacked,
            None,
            1,
            64,
            28,
            28,
            64,
            28,
            28,
            1,
            1,
        );

        // Run optimized version (will use parallel path if available)
        winograd_conv2d_f23_optimized(
            &mut output_optimized,
            &input,
            prepacked,
            None,
            1,
            64,
            28,
            28,
            64,
            28,
            28,
            1,
            1,
        );

        // Compare outputs
        for i in 0..output_scalar.len() {
            assert!(
                (output_scalar[i] - output_optimized[i]).abs() < 1e-3,
                "Mismatch at index {}: scalar={}, optimized={}",
                i,
                output_scalar[i],
                output_optimized[i]
            );
        }
    }
}
