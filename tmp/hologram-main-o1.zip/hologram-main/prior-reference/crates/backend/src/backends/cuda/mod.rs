//! CUDA backend implementation (NVIDIA GPUs).
//!
//! This module provides the CUDA GPU backend for NVIDIA GPUs using cudarc.
//! Only available on Linux/Windows with the `cuda` feature enabled.

mod gpu;
pub mod textures;

pub use gpu::CudaBackend;
pub use textures::{CudaActivationTextures, CudaTextureHandle};
