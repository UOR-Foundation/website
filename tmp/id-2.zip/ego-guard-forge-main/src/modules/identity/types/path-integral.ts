/**
 * Path Integral Types — Structured Graph Traversal
 * ══════════════════════════════════════════════════
 *
 * Models sovereignty value as a path integral through a bounded topology:
 *   T_∫(π) = 1 + β · ∫_π F(γ) dγ
 *
 * Replaces the V4 additive sum T(π) = 1 + β · Σ f(e) · g(n_e)
 * with a structured graph where:
 *   - Nodes are verification checkpoints (dimension vertices)
 *   - Edges carry conditional value density
 *   - Feedback loops revise value on failed verification
 *   - The graph constrains the path (bounded reasoning)
 *
 * Pure data. No classes. No side effects.
 *
 * @module identity/types/path-integral
 */

import type { SovereigntyDimensionId, EdgeState } from "../types";

// ── Graph Topology ──────────────────────────────────────────────────────────

/** Verification status at a checkpoint node. */
export type VerificationStatus =
  | "unverified"      // not yet checked
  | "verified"        // proof confirmed at boundary
  | "failed"          // verification failed, triggers feedback
  | "reverified";     // passed after feedback revision

/** A node in the sovereignty value graph — each dimension vertex is a checkpoint. */
export interface ValueNode {
  readonly id: SovereigntyDimensionId;
  readonly label: string;
  readonly verificationStatus: VerificationStatus;
  readonly checkpointValue: number;      // value confirmed at this boundary node (0–1)
  readonly feedbackCount: number;        // how many times this node triggered feedback
  readonly lastVerifiedAt: number;       // timestamp of last verification
}

/** A directed edge in the value graph between adjacent dimension nodes. */
export interface ValueEdge {
  readonly id: string;
  readonly from: SovereigntyDimensionId;
  readonly to: SovereigntyDimensionId;
  readonly valueDensity: number;         // F(γ) — value per unit path length (0–1)
  readonly edgeCount: number;            // how many of the 16 boundary edges are non-shielded
  readonly totalEdges: number;           // always 16
  readonly dominantState: EdgeState;     // most common state among the 16 edges
  readonly feedbackWeight: number;       // revision factor from failed checks (0–1, 1 = no feedback)
  readonly isActive: boolean;            // whether this path segment carries value
}

// ── Path Traversal ──────────────────────────────────────────────────────────

/** A single step in a sovereignty path traversal. */
export interface PathStep {
  readonly fromNode: SovereigntyDimensionId;
  readonly toNode: SovereigntyDimensionId;
  readonly edgeId: string;
  readonly valueDensity: number;         // F(γ) at this segment
  readonly cumulativeValue: number;      // running integral up to this step
  readonly verified: boolean;            // checkpoint passed at toNode
  readonly feedbackApplied: boolean;     // feedback loop triggered
}

/** The complete sovereignty value graph. */
export interface SovereigntyValueGraph {
  readonly identityId: string;
  readonly nodes: readonly ValueNode[];
  readonly edges: readonly ValueEdge[];
  readonly totalNodes: number;           // always 6
  readonly totalEdges: number;           // always 6 (adjacent pairs on torus)
  readonly timestamp: number;
}

/** Result of computing the path integral T_∫(π). */
export interface PathIntegralResult {
  readonly identityId: string;
  readonly integralValue: number;        // T_∫(π) = 1 + β · ∫_π F(γ) dγ
  readonly rawIntegral: number;          // ∫_π F(γ) dγ (before β scaling)
  readonly beta: number;                 // scaling factor β
  readonly path: readonly PathStep[];    // the traversal path
  readonly verifiedCheckpoints: number;  // how many nodes passed verification
  readonly feedbackLoops: number;        // how many feedback revisions occurred
  readonly boundaryUtilization: number;  // fraction of boundary edges active (0–1)
  readonly timestamp: number;
}

/** Configuration for the path integral computation. */
export interface PathIntegralConfig {
  readonly beta: number;                 // scaling factor (default 0.5)
  readonly feedbackDecay: number;        // how much feedback reduces value (default 0.7)
  readonly verificationThreshold: number; // min disclosure ratio to pass checkpoint (default 0.25)
  readonly maxFeedbackIterations: number; // cap on feedback loops (default 3)
}
