#!/usr/bin/env node
/**
 * Example Node.js program using UOR WASM bindings (TypeScript)
 *
 * Build:
 *   just ffi-wasm-node
 *
 * Compile and run:
 *   npx tsc --outDir dist examples/javascript/example-node.ts
 *   node dist/examples/javascript/example-node.js
 */

import * as uor from '../../bindings/wasm/nodejs/uor_ffi.js';

function assert(condition: boolean, message: string): asserts condition {
    if (!condition) {
        throw new Error(`Assertion failed: ${message}`);
    }
}

function assertEqual<T>(actual: T, expected: T, message: string): void {
    if (actual !== expected) {
        throw new Error(`${message} (expected ${expected}, got ${actual})`);
    }
}

async function main(): Promise<void> {
    console.log('=== UOR WASM (Node.js) Bindings Example ===\n');

    // Test constants
    console.log('Constants:');
    const brailleBase = uor.braille_base();
    console.log(`  Braille Base: U+${brailleBase.toString(16).toUpperCase().padStart(4, '0')}`);
    assertEqual(brailleBase, 0x2800, 'braille_base should be 0x2800');

    const brailleMax = uor.braille_max();
    console.log(`  Braille Max:  U+${brailleMax.toString(16).toUpperCase().padStart(4, '0')}`);
    assertEqual(brailleMax, 0x28FF, 'braille_max should be 0x28FF');

    const triadic = uor.triadic_constant();
    console.log(`  Triadic (T):  ${triadic}`);
    assertEqual(triadic, 3, 'triadic_constant should be 3');

    const octave = uor.octave_constant();
    console.log(`  Octave (O):   ${octave}`);
    assertEqual(octave, 8, 'octave_constant should be 8');

    const stateTaxons = uor.state_taxons();
    console.log(`  State Taxons: ${stateTaxons}`);
    assertEqual(stateTaxons, 624, 'state_taxons should be 624');

    const stateBits = uor.state_bits();
    console.log(`  State Bits:   ${stateBits}\n`);
    assertEqual(stateBits, 4992, 'state_bits should be 4992');

    // Test taxon operations
    console.log('Taxon Operations:');
    const testByte: number = 42;

    const braille: string = uor.wasm_byte_to_braille(testByte);
    console.log(`  Byte ${testByte} -> Braille: ${braille}`);
    assert(braille.length > 0, 'braille string should not be empty');

    const codepoint: number = uor.wasm_byte_to_codepoint(testByte);
    console.log(`  Byte ${testByte} -> Codepoint: U+${codepoint.toString(16).toUpperCase().padStart(4, '0')}`);
    assert(codepoint >= 0x2800 && codepoint <= 0x28FF, 'codepoint should be in Braille range');
    assertEqual(codepoint, 0x2800 + testByte, 'codepoint should be base + byte');

    const domain: number = uor.wasm_byte_to_domain(testByte);
    console.log(`  Byte ${testByte} -> Domain: ${domain}`);
    assert(domain >= 0 && domain <= 2, 'domain should be 0, 1, or 2');

    const rank: number = uor.wasm_byte_rank(testByte);
    console.log(`  Byte ${testByte} -> Rank: ${rank}\n`);
    assert(rank >= 0 && rank < 96, 'rank should be in range [0, 96)');

    // Test ring operations
    console.log('Ring Operations:');
    const succ: number = uor.wasm_byte_succ(testByte);
    console.log(`  Byte ${testByte} -> Successor: ${succ}`);
    assertEqual(succ, 43, 'succ(42) should be 43');

    const pred: number = uor.wasm_byte_pred(testByte);
    console.log(`  Byte ${testByte} -> Predecessor: ${pred}`);
    assertEqual(pred, 41, 'pred(42) should be 41');

    const neg: number = uor.wasm_byte_not(testByte);
    console.log(`  Byte ${testByte} -> NOT: ${neg}\n`);
    assert(neg >= 0 && neg <= 255, 'NOT result should be a valid byte');

    // Test view operations
    console.log('View Operations:');

    // Create identity view
    const identity = new uor.WasmView();
    console.log('  Created identity view');

    // Apply to single byte
    let result: number = identity.apply(testByte);
    console.log(`  Identity(${testByte}) = ${result}`);
    assertEqual(result, testByte, 'identity should preserve value');

    // Check if bijective
    let isBij: boolean = identity.isBijective();
    assert(isBij, 'identity view should be bijective');

    // Create constant view
    const constant = uor.WasmView.constant(99);
    result = constant.apply(testByte);
    console.log(`  Constant(${testByte}) = ${result}`);
    assertEqual(result, 99, 'constant(99) should always return 99');

    // Check if bijective
    isBij = constant.isBijective();
    console.log(`  Constant view is bijective: ${isBij}`);

    // Test view composition
    const composed = identity.then(identity);
    result = composed.apply(testByte);
    console.log(`  Identity.then(Identity)(${testByte}) = ${result}`);
    assertEqual(result, testByte, 'identity.then(identity) should preserve value');

    // Test view on array
    console.log('\n  Applying identity view to array...');
    const inputArray = new Uint8Array([0, 1, 2, 3, 4, 5, 6, 7]);
    const outputArray: Uint8Array = identity.applySlice(inputArray);
    console.log(`  Input:  [${Array.from(inputArray).join(', ')}]`);
    console.log(`  Output: [${Array.from(outputArray).join(', ')}]`);

    // Verify array results
    for (let i = 0; i < inputArray.length; i++) {
        assertEqual(outputArray[i], inputArray[i], `identity should preserve array value at index ${i}`);
    }

    // Cleanup
    identity.free();
    constant.free();
    composed.free();

    console.log('\n=== All tests passed! ===');
}

main().catch(console.error);
