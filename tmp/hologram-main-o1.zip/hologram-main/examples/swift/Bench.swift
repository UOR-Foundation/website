/**
 * Swift FFI Benchmarks
 *
 * Measures FFI call overhead and throughput
 *
 * Build:
 *   just ffi-swift
 *
 * Compile and run:
 *   swiftc -I bindings/swift -L target/release -luor_ffi Bench.swift -o bench
 *   LD_LIBRARY_PATH=target/release ./bench
 */

import Foundation

let ITERATIONS = 1_000_000
let WARMUP_ITERATIONS = 100_000

func benchFunction(name: String, iterations: Int = ITERATIONS, fn: () -> Void) -> Double {
    // Warmup
    for _ in 0..<WARMUP_ITERATIONS {
        fn()
    }

    // Benchmark
    let start = DispatchTime.now()
    for _ in 0..<iterations {
        fn()
    }
    let end = DispatchTime.now()

    let totalNs = Double(end.uptimeNanoseconds - start.uptimeNanoseconds)
    let perCallNs = totalNs / Double(iterations)
    let callsPerSecM = 1000.0 / perCallNs

    print(String(format: "  %-30s: %8.2f ns/call  (%7.2f M calls/sec)", name, perCallNs, callsPerSecM))
    return perCallNs
}

func formatNumber(_ num: Int) -> String {
    let formatter = NumberFormatter()
    formatter.numberStyle = .decimal
    return formatter.string(from: NSNumber(value: num)) ?? "\(num)"
}

func main() {
    print("=== UOR Swift FFI Benchmarks ===\n")
    print("Target: < 10 ns per call")
    print("Iterations: \(formatNumber(ITERATIONS)) (after \(formatNumber(WARMUP_ITERATIONS)) warmup)\n")

    // Taxon Operations
    print("Taxon Operations:")
    benchFunction(name: "byte_to_braille") { _ = byteToBraille(value: 42) }
    benchFunction(name: "byte_to_codepoint") { _ = byteToCodepoint(value: 42) }
    benchFunction(name: "byte_to_domain") { _ = byteToDomain(value: 42) }
    benchFunction(name: "byte_rank") { _ = byteRank(value: 42) }

    // Ring Operations
    print("\nRing Operations:")
    benchFunction(name: "byte_succ") { _ = byteSucc(value: 42) }
    benchFunction(name: "byte_pred") { _ = bytePred(value: 42) }
    benchFunction(name: "byte_not") { _ = byteNot(value: 42) }

    // View Operations
    print("\nView Operations:")
    let identity = FfiView.identity()
    benchFunction(name: "view_apply") { _ = identity.apply(byteValue: 42) }

    // Batch Operations
    print("\nBatch Operations:")
    let data = Data((0..<1024).map { UInt8($0 % 256) })
    let batchIterations = ITERATIONS / 100

    let batchNs = benchFunction(name: "view_apply_slice (1KB)", iterations: batchIterations) {
        _ = identity.applySlice(input: data)
    }

    let throughputMb = (1024.0 / batchNs) * 1000.0
    print(String(format: "  Throughput: %.2f MB/sec", throughputMb))

    print("\n=== Benchmarks Complete ===")
}

main()
