
-- Function to derive deterministic UOR ID from auth user_id
CREATE OR REPLACE FUNCTION public.derive_uor_id(p_user_id uuid)
RETURNS text
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT 'uor:' || encode(extensions.digest(p_user_id::text || ':uor-identity-v1', 'sha256'), 'hex')
$$;

-- Add uor_id column to profiles (deterministic, unique, derived from user_id)
ALTER TABLE public.profiles
ADD COLUMN uor_id text UNIQUE GENERATED ALWAYS AS (public.derive_uor_id(user_id)) STORED;

-- Create identity_ceremonies table for genesis + future ceremonies
CREATE TABLE public.identity_ceremonies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  ceremony_type text NOT NULL DEFAULT 'genesis',
  uor_id text NOT NULL,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.identity_ceremonies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own ceremonies"
ON public.identity_ceremonies FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own ceremonies"
ON public.identity_ceremonies FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE INDEX idx_ceremonies_user_id ON public.identity_ceremonies(user_id);
CREATE INDEX idx_ceremonies_uor_id ON public.identity_ceremonies(uor_id);
