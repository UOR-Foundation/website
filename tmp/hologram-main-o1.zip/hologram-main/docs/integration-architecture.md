# Integration Architecture

This document describes how the Hologram framework's three layers integrate: the JSON-LD specification, the UOR core library, and the backend execution system.

## Overview

Hologram operates through three complementary abstraction layers:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    SPECIFICATION LAYER                               │
│  descriptors/hologram.jsonld → crates/codec/ (build-time codegen)   │
│  • Axioms (U, D, T, O)                                              │
│  • Cayley-Dickson tower (9 levels)                                  │
│  • Numeral systems → Generated codec types                          │
└─────────────────────────────────────────────────────────────────────┘
                                 ↓
┌─────────────────────────────────────────────────────────────────────┐
│                       CORE LAYER (uor crate)                         │
│  • Constants: T=3, O=8, B=32, R=96                                  │
│  • Types: Taxon, Domain, Res96, Word*, Cell, ToroidalBoundary       │
│  • Microcode: 5 primitives → all operations                         │
│  • Wavefront: UorState (624 taxons), Zen3Executor                   │
└─────────────────────────────────────────────────────────────────────┘
                                 ↓
┌─────────────────────────────────────────────────────────────────────┐
│                   EXECUTION LAYER (backends crate)                   │
│  • ISA: Encode, Decode, MatMul, Sigmoid, etc.                       │
│  • Backends: CPU (AVX2, NEON), WASM, CUDA, Metal                    │
│  • MicrocodePrimitives<W> trait unifies all backends                │
└─────────────────────────────────────────────────────────────────────┘
```

## 1. JSON-LD → Codec Generation

### The Specification (hologram.jsonld)

The `descriptors/hologram.jsonld` file is the mathematical specification of the entire framework. It defines:

**Foundational Axioms**:
```
U = 1  (Unity)           - Terminal object cardinality
D = 2  (Duality)         - Morphism structure arity
T = U + D = 3 (Triality) - Minimum cyclic composition
O = D^T = 8  (Octonion)  - Maximum normed division algebra dimension
```

**Derived Constants**:
```
B = 2^(O-T) = 32         - Binary depth
R = T × B = 96           - Resonance modulus
BYTE_CARDINALITY = 2^O = 256
BOUNDARY_SIZE = R × 128 = 12,288 cells
```

**Numeral Systems** (generate codecs):
- `cxs:numerals/systems/binary` → `Binary` (base-2, passthrough)
- `cxs:numerals/systems/decimal` → `Decimal` (base-10)
- `cxs:numerals/systems/hexadecimal` → `Hexadecimal` (base-16)
- `cxs:numerals/systems/mod96crt` → `Mod96Crt` (mixed radix [32, 3])
- `cxs:numerals/systems/continuedFraction` → `ContinuedFraction` (non-positional)

### Build-Time Code Generation

The `crates/codec/build.rs` script parses JSON-LD at compile time:

1. Scans `descriptors/*.jsonld` files
2. Extracts nodes with `@type` containing `NumeralSystem`, `PositionalSystem`, `MixedRadixSystem`, or `NonPositionalSystem`
3. Generates Rust structs implementing the `Codec` trait
4. Outputs to `$OUT_DIR/generated.rs`

**Generated Code Example** (for Mod96Crt):
```rust
/// Mod-96 CRT
///
/// JSON-LD ID: `cxs:numerals/systems/mod96crt`
#[derive(Debug, Clone, Copy, Default)]
pub struct Mod96Crt;

impl crate::Codec for Mod96Crt {
    fn id(&self) -> &'static str { "cxs:numerals/systems/mod96crt" }
    fn name(&self) -> &'static str { "Mod96Crt" }
    fn scale_factor(&self) -> crate::ScaleFactor {
        crate::ScaleFactor { radix: 32, arbitrary: true, max_precision_bits: None }
    }
    fn encode(&self, input: &[u8]) -> Result<Vec<u8>, CodecError> {
        crate::generated::encode_mixed_radix(input, &[32, 3])
    }
    fn decode(&self, input: &[u8]) -> Result<Vec<u8>, CodecError> {
        crate::generated::decode_mixed_radix(input, &[32, 3])
    }
}
```

### Adding New Codecs

To add a new codec:

1. Add a numeral system definition to `hologram.jsonld`:
```json
{
  "@id": "cxs:numerals/systems/base36",
  "@type": ["NumeralSystem", "PositionalSystem"],
  "hasRadix": 36,
  "label": "Base36"
}
```

2. Rebuild the codec crate:
```bash
cargo build -p hologram-codec
```

3. The new `Base36` struct is automatically generated and available via `all_codecs()`.

## 2. Codec-ISA Integration

### ISA Instructions

The ISA includes two codec-related instructions:

```rust
/// Encode buffer using a codec.
Encode {
    dst: u32,       // Destination buffer index
    src: u32,       // Source buffer index (binary)
    codec_id: u16,  // 0=Binary, 1=Decimal, 2=Hex, 3=Mod96Crt, 4=ContFrac
    count: usize,   // Number of input bytes
}

/// Decode buffer using a codec.
Decode {
    dst: u32,       // Destination buffer index (binary)
    src: u32,       // Source buffer index (encoded)
    codec_id: u16,  // Codec identifier
    count: usize,   // Number of output bytes expected
}
```

### CodecRegistry

Backends access codecs via a registry:

```rust
pub struct CodecRegistry {
    codecs: Vec<Box<dyn Codec>>,
}

impl CodecRegistry {
    pub fn new() -> Self {
        Self { codecs: all_codecs() }
    }

    pub fn get(&self, id: u16) -> Option<&dyn Codec> {
        self.codecs.get(id as usize).map(|c| c.as_ref())
    }
}
```

### Use Cases

1. **Mod-96 CRT for Torus Operations**:
   - Encode values to `[value mod 32, value mod 3]` representation
   - Perform residue arithmetic independently (Chinese Remainder Theorem)
   - Reconstruct result via CRT

2. **Decimal I/O**:
   - Accept decimal string input from users
   - Encode to binary for computation
   - Decode back to decimal for display

3. **Hex/Base64 for APIs**:
   - Standard encoding at system boundaries
   - Zero-copy when possible (binary passthrough)

## 3. UOR Core Layer

### Mathematical Foundation

The UOR crate provides zero-dependency implementations of the axiom-derived types:

```rust
// crates/uor/src/core/constants.rs
pub const T: usize = 3;              // Triality
pub const O: usize = 8;              // Octonion dimension
pub const B: usize = 1 << (O - T);   // Binary depth = 32
pub const R: usize = T * B;          // Resonance modulus = 96
pub const BYTE_CARDINALITY: usize = 1 << O;  // 256
pub const BOUNDARY_SIZE: usize = R * 128;    // 12,288
```

### Core Types

| Type | Purpose | Size |
|------|---------|------|
| `Taxon` | Byte with Braille bijection (U+2800-U+28FF) | 1 byte |
| `Domain` | Triadic partition (Theta/Psi/Delta, mod 3) | - |
| `Res96` | Ring arithmetic modulo R=96 | 1 byte |
| `Word2/4/8/32` | Compound taxon types (tower levels) | 2-32 bytes |
| `Cell` | Torus address (0-12287) | 2 bytes |
| `ToroidalBoundary` | 12,288-cell torus substrate | 12 KB |

### Microcode Primitives

All operations derive from 5 primitives:

```rust
pub trait MicrocodePrimitives<W: MicrocodeWord> {
    fn bnot(&self, a: W) -> W;           // Bitwise NOT
    fn neg(&self, a: W) -> W;            // Two's complement negation
    fn xor(&self, a: W, b: W) -> W;      // Bitwise XOR
    fn and(&self, a: W, b: W) -> W;      // Bitwise AND
    fn or(&self, a: W, b: W) -> W;       // Bitwise OR
}
```

**Critical Identity**: `neg(bnot(x)) = x + 1`

This means increment/decrement, and thus all integer arithmetic, derives from the two involutions.

### Derived Operations

| Operation | Microcode | Complexity |
|-----------|-----------|------------|
| `inc(a)` | `neg(bnot(a))` | 2 ops |
| `dec(a)` | `bnot(neg(a))` | 2 ops |
| `add(a, b)` | Kogge-Stone parallel prefix | ~160 ops |
| `sub(a, b)` | `add(a, neg(b))` | ~161 ops |
| `eq(a, b)` | `not(is_nonzero(xor(a, b)))` | ~4 ops |

## 4. Microcode → Backend Bridge

### Trait Hierarchy

```
MicrocodeWord          -- Word type requirements (ONES, ZEROS, BITS)
    ↓
MicrocodePrimitives    -- 5 fundamental operations
    ↓
MicrocodeOps           -- Derived operations (blanket impl)
```

Any type implementing `MicrocodePrimitives<W>` automatically gains all derived operations.

### Backend Implementation

Each backend variant implements the primitives with hardware-specific instructions:

```rust
// x86_64 AVX2 backend
impl MicrocodePrimitives<[u32; 8]> for Avx2Backend {
    fn xor(&self, a: [u32; 8], b: [u32; 8]) -> [u32; 8] {
        unsafe { _mm256_xor_si256(a.into(), b.into()).into() }
    }
    // ... other primitives
}

// WASM SIMD128 backend
impl MicrocodePrimitives<[u32; 4]> for WasmSimd128Backend {
    fn xor(&self, a: [u32; 4], b: [u32; 4]) -> [u32; 4] {
        v128_xor(a.into(), b.into()).into()
    }
}
```

### Native Overrides

For performance-critical operations, backends can use native hardware instructions instead of microcode synthesis:

```rust
pub enum NativeOverride {
    Add,           // vpaddd (AVX2), vadd (NEON)
    Sub,           // vpsubd (AVX2), vsub (NEON)
    Mul,           // vpmulld (AVX2), vmul (NEON)
    Sha256Round,   // sha256rnds2 (SHA-NI)
    AesRound,      // aesenc (AES-NI)
    AesRoundDec,   // aesdec (AES-NI)
    PopCount,      // popcnt
    LeadingZeros,  // lzcnt
    TrailingZeros, // tzcnt
}
```

## 5. Wavefront vs ISA Execution

### Two Execution Models

The framework provides two complementary execution models:

| Aspect | Wavefront | ISA |
|--------|-----------|-----|
| **Data Model** | `UorState` (624 taxons, 4992 bits) | Byte buffers |
| **Entry Point** | `Zen3Executor::step()` | `Backend::execute_plan()` |
| **Residence** | CPU registers only | Memory + cache |
| **Operations** | Single-cycle wavefront | Multi-instruction sequences |
| **Use Case** | Crypto, torus manipulation | Neural networks, tensors |

### When to Use Wavefront

Use `uor::arch` executors for:
- **SHA-256 rounds**: `sha256rnds2` via SHA-NI
- **AES rounds**: `aesenc`/`aesdec` via AES-NI
- **Direct torus manipulation**: All 624 taxons in registers
- **Maximum throughput**: All CPU ports fire per cycle

```rust
use uor::arch::Zen3AsmExecutor;
use uor::isa::{UorStep, Wavefront};

let executor = Zen3AsmExecutor::new();
let mut state = UorState::zero();
let wf = Wavefront::all_xor();

// Single-cycle wavefront execution
unsafe { executor.step(&mut state, &wf); }
```

### When to Use ISA

Use `hologram-backend` for:
- **Compiled models**: `.holb` files from the compiler
- **Large tensors**: Data exceeds register capacity
- **Standard operations**: MatMul, Conv2d, Softmax
- **Multi-backend**: Same plan runs on CPU, GPU, WASM

```rust
use hologram_backend::cpu::CpuBackend;
use hologram_holo::HoloLoader;

let backend = CpuBackend::new();
let plan = HoloLoader::load("model.holb")?.plan();

backend.execute_plan(&plan, &[&input], &mut [&mut output])?;
```

## 6. Integration Examples

### Example 1: End-to-End MatMul Flow

```
TensorBuilder::matmul()
    ↓
OperationGraph with OpKind::MatMul { m, k, n }
    ↓
Compiler Stage 3: Select AVX2 micro-kernel
    ↓
BackendPlan with IsaInstruction::MatMul
    ↓
CpuBackend: Execute using MicrocodePrimitives
    ↓
Result buffer
```

### Example 2: Codec Encode/Decode

```rust
// Create a plan with encode/decode
let mut graph = OperationGraph::new();
let input = graph.add_node(OpNode::new(0, OpKind::Input, vec![8], DType::U8));
let encoded = graph.add_node(OpNode::new(1, OpKind::Encode { codec_id: 3 }, vec![16], DType::U8));
let decoded = graph.add_node(OpNode::new(2, OpKind::Decode { codec_id: 3 }, vec![8], DType::U8));
graph.add_edge(0, 1);
graph.add_edge(1, 2);

// Compile and execute
let plan = compile(&graph, &config)?;
let input_data = vec![50u8];  // Will become [18, 2] in CRT
let mut output = vec![0u8; 8];
backend.execute_plan(&plan, &[&input_data], &mut [&mut output])?;

assert_eq!(output[0], 50);  // Roundtrip preserved
```

### Example 3: Wavefront Crypto

```rust
use uor::arch::Zen3AsmExecutor;
use uor::wavefront::sha256;

let executor = Zen3AsmExecutor::new();
let mut state = UorState::zero();

// Load message block into YMM registers
state.ymm[0..2].copy_from_slice(&message_block);

// Execute SHA-256 rounds (wavefront operations)
for round in 0..64 {
    let wf = sha256::round_wavefront(round);
    unsafe { executor.step(&mut state, &wf); }
}

// Extract hash from registers
let hash = state.ymm[0..1].to_bytes();
```

## 7. Adding New Integrations

### To Add a New Codec

1. Define in `hologram.jsonld`
2. Rebuild codec crate
3. Use via `Encode`/`Decode` ISA instructions

### To Add a New ISA Instruction

1. Add variant to `IsaInstruction` enum in `crates/holo/src/instruction.rs`
2. Add `OpKind` variant in `crates/compiler/src/graph/node.rs`
3. Implement emit logic in `crates/compiler/src/assemble.rs`
4. Implement handler in each backend (`cpu`, `wasm`, `cuda`, `metal`)
5. Add tests

### To Add a New Backend

1. Create module in `crates/backends/src/backends/`
2. Implement `Backend` trait
3. Implement `MicrocodePrimitives<W>` for relevant word types
4. Register native overrides for hardware-accelerated ops
5. Add to `BackendVariant` enum

## Summary

The three layers provide complementary capabilities:

- **Specification** (JSON-LD): Mathematical definitions, type generation
- **Core** (UOR): Zero-dependency types, microcode primitives, wavefront execution
- **Execution** (Backends): ISA implementation, hardware optimization, codec integration

The codec system bridges specification and execution by generating Rust types from JSON-LD and providing ISA instructions for runtime encoding/decoding.
