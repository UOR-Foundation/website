//! Security infrastructure for orchestration.
//!
//! This module provides layered security for the orchestration layer:
//!
//! 1. **Ed25519 Identity**: Cryptographic cluster identity for signing operations
//! 2. **Worker Tokens**: Signed authorization tokens for workers
//! 3. **mTLS** (optional): Certificate-based mutual authentication

#[cfg(feature = "security")]
mod identity;
#[cfg(feature = "security")]
mod token;

#[cfg(feature = "mtls")]
pub mod mtls;

#[cfg(feature = "security")]
pub use identity::ClusterIdentity;
#[cfg(feature = "security")]
pub use token::{TokenVerifyResult, WorkerToken};

use crate::error::{OrchestrateError, Result};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::time::Duration;

/// Security configuration for orchestration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityConfig {
    /// Path to cluster identity file (Ed25519 keypair).
    pub identity_path: PathBuf,
    /// Path to cluster CA directory (for mTLS).
    pub ca_path: PathBuf,
    /// Key rotation interval in seconds.
    pub key_rotation_interval_secs: u64,
    /// Token validity duration in seconds.
    pub token_validity_secs: u64,
    /// Certificate validity duration in seconds.
    pub cert_validity_secs: u64,
    /// Require mTLS for all connections.
    pub require_mtls: bool,
    /// Require Ed25519 tokens.
    pub require_tokens: bool,
}

impl Default for SecurityConfig {
    fn default() -> Self {
        Self {
            identity_path: PathBuf::from("/etc/hologram/cluster.key"),
            ca_path: PathBuf::from("/etc/hologram/ca"),
            key_rotation_interval_secs: 24 * 60 * 60, // 24 hours
            token_validity_secs: 60 * 60,             // 1 hour
            cert_validity_secs: 60 * 60,              // 1 hour
            require_mtls: true,
            require_tokens: true,
        }
    }
}

impl SecurityConfig {
    /// Create a new security config with default settings.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Load security config from a directory.
    pub fn load(path: impl Into<PathBuf>) -> Result<Self> {
        let path = path.into();
        let config_path = path.join("security.json");

        if config_path.exists() {
            let content = std::fs::read_to_string(&config_path)?;
            serde_json::from_str(&content)
                .map_err(|e| OrchestrateError::serialization(e.to_string()))
        } else {
            Ok(Self {
                identity_path: path.join("cluster.key"),
                ca_path: path.join("ca"),
                ..Self::default()
            })
        }
    }

    /// Save security config to a file.
    pub fn save(&self, path: impl Into<PathBuf>) -> Result<()> {
        let path = path.into();
        let content = serde_json::to_string_pretty(self)
            .map_err(|e| OrchestrateError::serialization(e.to_string()))?;
        std::fs::write(path, content)?;
        Ok(())
    }

    /// Set the identity path.
    #[must_use]
    pub fn with_identity_path(mut self, path: impl Into<PathBuf>) -> Self {
        self.identity_path = path.into();
        self
    }

    /// Set the CA path.
    #[must_use]
    pub fn with_ca_path(mut self, path: impl Into<PathBuf>) -> Self {
        self.ca_path = path.into();
        self
    }

    /// Set the key rotation interval.
    #[must_use]
    pub fn with_key_rotation_interval(mut self, interval: Duration) -> Self {
        self.key_rotation_interval_secs = interval.as_secs();
        self
    }

    /// Set the token validity duration.
    #[must_use]
    pub fn with_token_validity(mut self, validity: Duration) -> Self {
        self.token_validity_secs = validity.as_secs();
        self
    }

    /// Set the certificate validity duration.
    #[must_use]
    pub fn with_cert_validity(mut self, validity: Duration) -> Self {
        self.cert_validity_secs = validity.as_secs();
        self
    }

    /// Set whether to require mTLS.
    #[must_use]
    pub const fn with_require_mtls(mut self, require: bool) -> Self {
        self.require_mtls = require;
        self
    }

    /// Set whether to require tokens.
    #[must_use]
    pub const fn with_require_tokens(mut self, require: bool) -> Self {
        self.require_tokens = require;
        self
    }

    /// Get the key rotation interval as a Duration.
    #[must_use]
    pub const fn key_rotation_interval(&self) -> Duration {
        Duration::from_secs(self.key_rotation_interval_secs)
    }

    /// Get the token validity as a Duration.
    #[must_use]
    pub const fn token_validity(&self) -> Duration {
        Duration::from_secs(self.token_validity_secs)
    }

    /// Get the certificate validity as a Duration.
    #[must_use]
    pub const fn cert_validity(&self) -> Duration {
        Duration::from_secs(self.cert_validity_secs)
    }

    /// Get the path to the CA certificate.
    #[must_use]
    pub fn ca_cert_path(&self) -> PathBuf {
        self.ca_path.join("ca.crt")
    }

    /// Get the path to the CA private key.
    #[must_use]
    pub fn ca_key_path(&self) -> PathBuf {
        self.ca_path.join("ca.key")
    }

    /// Get the path to the cluster public key.
    #[must_use]
    pub fn cluster_pub_path(&self) -> PathBuf {
        self.identity_path.with_extension("pub")
    }

    /// Check if the cluster has been initialized.
    #[must_use]
    pub fn is_initialized(&self) -> bool {
        self.identity_path.exists() && self.ca_cert_path().exists() && self.ca_key_path().exists()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_security_config_default() {
        let config = SecurityConfig::default();
        assert!(config.require_mtls);
        assert!(config.require_tokens);
        assert_eq!(config.token_validity(), Duration::from_secs(3600));
    }

    #[test]
    fn test_security_config_builder() {
        let config = SecurityConfig::new()
            .with_identity_path("/tmp/test.key")
            .with_ca_path("/tmp/ca")
            .with_token_validity(Duration::from_secs(1800))
            .with_require_mtls(false);

        assert_eq!(config.identity_path, PathBuf::from("/tmp/test.key"));
        assert_eq!(config.ca_path, PathBuf::from("/tmp/ca"));
        assert_eq!(config.token_validity(), Duration::from_secs(1800));
        assert!(!config.require_mtls);
    }

    #[test]
    fn test_security_config_paths() {
        let config = SecurityConfig::new().with_ca_path("/etc/hologram/ca");

        assert_eq!(
            config.ca_cert_path(),
            PathBuf::from("/etc/hologram/ca/ca.crt")
        );
        assert_eq!(
            config.ca_key_path(),
            PathBuf::from("/etc/hologram/ca/ca.key")
        );
    }

    #[test]
    fn test_security_config_serialization() {
        let config = SecurityConfig::default();
        let json = serde_json::to_string(&config).unwrap();
        let parsed: SecurityConfig = serde_json::from_str(&json).unwrap();

        assert_eq!(config.token_validity_secs, parsed.token_validity_secs);
        assert_eq!(config.require_mtls, parsed.require_mtls);
    }

    // ========================================================================
    // Additional edge case tests
    // ========================================================================

    #[test]
    fn test_security_config_key_rotation_interval() {
        let config = SecurityConfig::new().with_key_rotation_interval(Duration::from_secs(3600));
        assert_eq!(config.key_rotation_interval(), Duration::from_secs(3600));
    }

    #[test]
    fn test_security_config_cert_validity() {
        let config = SecurityConfig::new().with_cert_validity(Duration::from_secs(7200));
        assert_eq!(config.cert_validity(), Duration::from_secs(7200));
    }

    #[test]
    fn test_security_config_require_tokens() {
        let config = SecurityConfig::new().with_require_tokens(false);
        assert!(!config.require_tokens);
    }

    #[test]
    fn test_security_config_cluster_pub_path() {
        let config = SecurityConfig::new().with_identity_path("/etc/test/cluster.key");
        assert_eq!(
            config.cluster_pub_path(),
            PathBuf::from("/etc/test/cluster.pub")
        );
    }

    #[test]
    fn test_security_config_is_initialized() {
        // With non-existent paths, should return false
        let config = SecurityConfig::new()
            .with_identity_path("/nonexistent/path.key")
            .with_ca_path("/nonexistent/ca");
        assert!(!config.is_initialized());
    }

    #[test]
    fn test_security_config_load_nonexistent() {
        // Loading from a non-existent directory should use defaults
        let result = SecurityConfig::load("/nonexistent/path");
        // Should succeed with default paths
        assert!(result.is_ok());
        let config = result.unwrap();
        assert_eq!(
            config.identity_path,
            PathBuf::from("/nonexistent/path/cluster.key")
        );
    }
}
