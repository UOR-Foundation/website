use criterion::{black_box, criterion_group, criterion_main, Criterion, Throughput};

fn bench_parse(c: &mut Criterion) {
    let mut group = c.benchmark_group("parse");
    let query = "query { byte(value: 42) { stratum, curvature, domain, rank, orbit_class, torus { page, offset } } }";
    group.throughput(Throughput::Elements(1));

    group.bench_function("byte_all_fields", |b| {
        b.iter(|| hologram_query::parse(black_box(query)).unwrap());
    });

    group.bench_function("simple", |b| {
        b.iter(|| {
            hologram_query::parse(black_box("query { byte(value: 42) { stratum } }")).unwrap()
        });
    });

    group.finish();
}

fn bench_resolve(c: &mut Criterion) {
    let mut group = c.benchmark_group("resolve");
    group.throughput(Throughput::Elements(1));

    let doc_single = hologram_query::parse("query { byte(value: 42) { stratum } }").unwrap();
    group.bench_function("single_field", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_single)).unwrap());
    });

    let doc_all = hologram_query::parse(
        "query { byte(value: 42) { stratum, curvature, domain, rank, orbit_class, torus { page, offset } } }",
    ).unwrap();
    group.bench_function("all_byte_fields", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_all)).unwrap());
    });

    let doc_ring = hologram_query::parse("query { ring(value: 50) { add(other: 10) } }").unwrap();
    group.bench_function("ring_param", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_ring)).unwrap());
    });

    group.finish();
}

fn bench_translate(c: &mut Criterion) {
    let mut group = c.benchmark_group("translate");
    group.throughput(Throughput::Elements(1));

    let doc = hologram_query::parse(
        "mutation { translate(domain: byte, value: 42, op: add, by: 10) { stratum, curvature } }",
    )
    .unwrap();
    group.bench_function("byte_translate", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc)).unwrap());
    });

    group.finish();
}

fn bench_end_to_end(c: &mut Criterion) {
    let mut group = c.benchmark_group("end_to_end");
    group.throughput(Throughput::Elements(1));

    group.bench_function("parse_and_execute", |b| {
        let q = "query { byte(value: 42) { stratum, curvature, domain } }";
        b.iter(|| {
            let doc = hologram_query::parse(black_box(q)).unwrap();
            hologram_query::execute(&doc).unwrap()
        });
    });

    group.finish();
}

fn bench_range_query(c: &mut Criterion) {
    let mut group = c.benchmark_group("range_query");
    group.throughput(Throughput::Elements(256));

    let doc_full =
        hologram_query::parse("query { byteRange(from: 0, to: 255) { stratum, curvature } }")
            .unwrap();
    group.bench_function("full_256_2_fields", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_full)).unwrap());
    });

    let doc_small =
        hologram_query::parse("query { byteRange(from: 0, to: 7) { stratum } }").unwrap();
    group.throughput(Throughput::Elements(8));
    group.bench_function("8_values_1_field", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_small)).unwrap());
    });

    group.finish();
}

fn bench_pipeline(c: &mut Criterion) {
    let mut group = c.benchmark_group("pipeline");
    group.throughput(Throughput::Elements(1));

    let doc = hologram_query::parse(
        "mutation { pipeline(value: 42) { add(by: 10) { stratum }, sigmoid { stratum }, mul(by: 3) { stratum } } }",
    )
    .unwrap();
    group.bench_function("3_step", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc)).unwrap());
    });

    let doc_single =
        hologram_query::parse("mutation { pipeline(value: 128) { sigmoid { stratum } } }").unwrap();
    group.bench_function("1_step_activation", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_single)).unwrap());
    });

    group.finish();
}

fn bench_compose(c: &mut Criterion) {
    let mut group = c.benchmark_group("compose");
    group.throughput(Throughput::Elements(1));

    // Composed chain (should use pre-composed table)
    let doc_composed = hologram_query::parse(
        "mutation { chain(value: 128, transforms: [sigmoid, tanh, relu]) { stratum } }",
    )
    .unwrap();
    group.bench_function("composed_3_step", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_composed)).unwrap());
    });

    // Sequential pipeline for comparison
    let doc_seq = hologram_query::parse(
        "mutation { pipeline(value: 128) { sigmoid { stratum }, tanh { stratum }, relu { stratum } } }",
    )
    .unwrap();
    group.bench_function("sequential_3_step", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_seq)).unwrap());
    });

    group.finish();
}

fn bench_translate_where(c: &mut Criterion) {
    let mut group = c.benchmark_group("translate_where");
    group.throughput(Throughput::Elements(256));

    let doc_no_filter = hologram_query::parse(
        "mutation { translateWhere(from: 0, to: 255, op: add, by: 1) { stratum } }",
    )
    .unwrap();
    group.bench_function("full_range_no_filter", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_no_filter)).unwrap());
    });

    let doc_filtered = hologram_query::parse(
        "mutation { translateWhere(from: 0, to: 255, op: add, by: 1, where: \"stratum == 4\") { stratum } }",
    )
    .unwrap();
    group.bench_function("full_range_stratum_filter", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_filtered)).unwrap());
    });

    group.finish();
}

fn bench_ndjson(c: &mut Criterion) {
    let mut group = c.benchmark_group("ndjson");
    group.throughput(Throughput::Elements(256));

    let doc = hologram_query::parse("query { byteRange(from: 0, to: 255) { stratum, curvature } }")
        .unwrap();
    group.bench_function("format_256_rows", |b| {
        let rows = hologram_query::execute_rows(&doc).unwrap();
        b.iter(|| hologram_query::to_ndjson(black_box(&rows)));
    });

    group.finish();
}

fn bench_observable(c: &mut Criterion) {
    let mut group = c.benchmark_group("observable");

    // Short path (10 elements)
    let doc_short = hologram_query::parse(
        "query { observable(path: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], quantum: 8) { winding, total_variation } }",
    ).unwrap();
    group.throughput(Throughput::Elements(10));
    group.bench_function("winding_tv_10", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_short)).unwrap());
    });

    // Medium path (100 elements)
    let path_100: String = (0..100)
        .map(|i| i.to_string())
        .collect::<Vec<_>>()
        .join(", ");
    let doc_100 = hologram_query::parse(&format!(
        "query {{ observable(path: [{path_100}], quantum: 8) {{ winding, total_variation }} }}"
    ))
    .unwrap();
    group.throughput(Throughput::Elements(100));
    group.bench_function("winding_tv_100", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_100)).unwrap());
    });

    // Large path (1000 elements)
    let path_1000: String = (0..1000)
        .map(|i| i.to_string())
        .collect::<Vec<_>>()
        .join(", ");
    let doc_1000 = hologram_query::parse(&format!(
        "query {{ observable(path: [{path_1000}], quantum: 8) {{ winding, total_variation }} }}"
    ))
    .unwrap();
    group.throughput(Throughput::Elements(1000));
    group.bench_function("winding_tv_1000", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_1000)).unwrap());
    });

    // Cascade spectrum benchmark
    let doc_cascade = hologram_query::parse(
        "query { observable(path: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], quantum: 8) { cascade_spectrum } }",
    ).unwrap();
    group.throughput(Throughput::Elements(10));
    group.bench_function("cascade_spectrum_10", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_cascade)).unwrap());
    });

    // All fields
    let doc_all = hologram_query::parse(
        "query { observable(path: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], quantum: 8) { winding, total_variation, cascade_spectrum } }",
    ).unwrap();
    group.throughput(Throughput::Elements(10));
    group.bench_function("all_fields_10", |b| {
        b.iter(|| hologram_query::execute(black_box(&doc_all)).unwrap());
    });

    group.finish();
}

criterion_group!(
    benches,
    bench_parse,
    bench_resolve,
    bench_translate,
    bench_end_to_end,
    bench_range_query,
    bench_pipeline,
    bench_compose,
    bench_translate_where,
    bench_ndjson,
    bench_observable,
);
criterion_main!(benches);
