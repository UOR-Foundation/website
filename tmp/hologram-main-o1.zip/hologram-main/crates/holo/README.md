# hologram-holo

Format parsing and serialization for `.holo` archive formats with zero-copy deserialization.

## Overview

This crate provides readers and writers for two archive formats:
- `.holb` (HOLB) - Single model bundle with embedded weights
- `.holo` (HOLM) - Multi-model pipeline with index

All formats support memory-mapping and zero-copy access via `rkyv`.

## Weight Handling

The crate provides advanced weight handling capabilities:

### Weight Index

The `WeightIndexSection` enables partial loading of specific tensors without reading the entire weights blob.

```rust
use hologram_holo::{HolbWriter, TensorMetadata, WeightDType};

// Create tensor metadata
let tensors = vec![
    TensorMetadata::builder()
        .name("encoder.weight")
        .shape(vec![768, 512])
        .dtype(WeightDType::F32)
        .offset(0)
        .size(768 * 512 * 4)
        .checksum(crc32_value)
        .build()?,
    TensorMetadata::builder()
        .name("decoder.weight")
        .shape(vec![512, 768])
        .dtype(WeightDType::F32)
        .offset(768 * 512 * 4)
        .size(512 * 768 * 4)
        .checksum(crc32_value)
        .build()?,
];

// Write bundle with indexed weights
let mut writer = HolbWriter::new();
writer.set_graph(&graph_bytes);
writer.set_indexed_weights(&weights_blob, &tensors)?;
let bundle = writer.build()?;
```

Reading specific tensors:

```rust
use hologram_holo::HolbReader;

let reader = HolbReader::from_bytes(&bundle)?;

// Get tensor metadata
if let Some(meta) = reader.get_tensor_metadata("encoder.weight")? {
    println!("Shape: {:?}", meta.shape);
    println!("DType: {:?}", meta.dtype);
}

// Get tensor bytes (zero-copy for uncompressed)
if let Some(data) = reader.get_tensor("encoder.weight")? {
    // Use tensor data
}

// List all tensor names
let names = reader.tensor_names()?;
```

### Tensor Metadata

Each tensor has rich metadata:

```rust
use hologram_holo::{TensorMetadata, WeightDType, QuantizationParams};

let tensor = TensorMetadata::builder()
    .name("layer.0.attention.weight")
    .shape(vec![768, 768])           // Shape (negative = symbolic dims)
    .dtype(WeightDType::I8)           // Data type
    .offset(0)                        // Offset in weights blob
    .size(768 * 768)                  // Size in bytes
    .quantization(QuantizationParams::symmetric_per_tensor(0.01))
    .checksum(0xDEADBEEF)
    .build()?;
```

Supported data types (`WeightDType`):
- `F32`, `F64`, `F16`, `BF16` - Floating point
- `I8`, `U8`, `I16`, `I32`, `I64` - Integer
- `I4` - 4-bit packed (2 elements per byte)

### Quantization

Quantization parameters support various schemes:

```rust
use hologram_holo::{QuantizationParams, QuantizationScheme};

// Per-tensor symmetric (single scale, zero_point=0)
let params = QuantizationParams::symmetric_per_tensor(0.01);

// Per-tensor asymmetric (scale + zero_point)
let params = QuantizationParams::asymmetric_per_tensor(0.01, 128);

// Per-channel (one scale per output channel)
let params = QuantizationParams::per_channel(
    vec![0.01, 0.02, 0.03],  // scales
    vec![0, 0, 0],            // zero_points
    true,                     // symmetric
);

// Group-wise (e.g., GPTQ, AWQ)
let params = QuantizationParams::group_wise(
    scales,
    zero_points,
    128,  // group_size
);

// With calibration range
let params = params.with_range(-1.0, 1.0);
```

### Compression (Feature-Gated)

Enable the `compression` feature for zstd/lz4 support:

```toml
[dependencies]
hologram-holo = { version = "0.1", features = ["compression"] }
```

Writing compressed weights:

```rust
use hologram_holo::{HolbWriter, CompressionAlgorithm};

let mut writer = HolbWriter::new();
writer.set_graph(&graph_bytes);

// Compress with zstd (level 3)
writer.set_compressed_weights(
    &weights_blob,
    CompressionAlgorithm::Zstd,
    3,
)?;

// Or with both index and compression
writer.set_indexed_compressed_weights(
    &weights_blob,
    &tensors,
    CompressionAlgorithm::Zstd,
    3,
)?;
```

Reading compressed weights:

```rust
use hologram_holo::HolbReader;

let reader = HolbReader::from_bytes(&bundle)?;

// Check if compressed
if reader.is_weights_compressed() {
    // Decompress all weights
    let decompressed = reader.decompress_weights()?;

    // Or decompress specific tensor
    if let Some(data) = reader.decompress_tensor("encoder.weight")? {
        // Use decompressed tensor
    }
}
```

Supported algorithms:
- `CompressionAlgorithm::None` - No compression (default)
- `CompressionAlgorithm::Zstd` - Zstandard (good balance)
- `CompressionAlgorithm::Lz4` - LZ4 (faster, lower ratio)

## File Format

### HOLB V1 (48-byte header)

```
[Header: 48 bytes]
[BackendPlan: variable]
[Padding to 4KB]
[Weights: page-aligned]
```

### HOLB V2 (80-byte header)

Used when sections are present (weight index, layer header, etc.):

```
[Header: 80 bytes]
[BackendPlan: variable]
[Padding to 4KB]
[Sections table: variable]
[Sections data: concatenated]
[Padding to 4KB]
[Weights: page-aligned]
```

### Sections

Sections are extensible metadata embedded in V2 bundles:

| Section | ID | Purpose |
|---------|-----|---------|
| `LayerHeaderSection` | `layer_header` | Multi-layer execution metadata |
| `WeightIndexSection` | `weight_index` | Tensor index + compression metadata |

Custom sections can be added by implementing `EmbeddableSection`:

```rust
use hologram_holo::{EmbeddableSection, FromEmbeddedSection, Result};

struct MySection {
    data: Vec<u8>,
}

impl EmbeddableSection for MySection {
    fn section_id(&self) -> &'static str { "my_section" }
    fn to_bytes(&self) -> Vec<u8> { self.data.clone() }
    fn content_type(&self) -> &'static str { "application/octet-stream" }
    fn version(&self) -> u32 { 1 }
}

impl FromEmbeddedSection for MySection {
    const SECTION_ID: &'static str = "my_section";
    fn from_bytes(bytes: &[u8]) -> Result<Self> {
        Ok(Self { data: bytes.to_vec() })
    }
}
```

## Zero-Copy Access

When memory-mapped, weights and tensors can be accessed without copying:

```rust
use hologram_holo::{HoloLoader, HolbReader};

// Load with mmap
let loaded = HoloLoader::load("model.holb")?;

// Access plan (zero-copy)
let plan = loaded.plan();

// Or read from bytes slice
let reader = HolbReader::from_bytes(&data)?;

// Zero-copy tensor access (uncompressed only)
let tensor_data: &[u8] = reader.get_tensor("weight")?.unwrap();
```

## Features

| Feature | Default | Description |
|---------|---------|-------------|
| `async` | Yes | Async file operations via Tokio |
| `compression` | No | zstd/lz4 compression support |

## License

MIT OR Apache-2.0
