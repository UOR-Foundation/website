//! Metric and trace exporters.
//!
//! This module provides various exporters for outputting telemetry data:
//! - [`console`]: Pretty-printed console output
//! - [`json`]: JSON-formatted log output
//! - `otlp`: OpenTelemetry Protocol export (feature-gated, requires `otlp` feature)

pub mod console;
pub mod json;

#[cfg(feature = "otlp")]
pub mod otlp;

use crate::metrics::{HistogramSummary, MetricsRegistry};

/// Trait for metric exporters.
pub trait MetricExporter {
    /// Export all metrics from the given registry.
    fn export(&self, registry: &MetricsRegistry) -> String;
}

/// Export format for metrics.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExportFormat {
    /// Pretty-printed console output.
    Console,
    /// JSON output.
    Json,
}

/// Export metrics using the specified format.
#[must_use]
pub fn export_metrics(registry: &MetricsRegistry, format: ExportFormat) -> String {
    match format {
        ExportFormat::Console => console::ConsoleExporter.export(registry),
        ExportFormat::Json => json::JsonExporter.export(registry),
    }
}

/// Format a histogram summary for display.
#[must_use]
pub fn format_histogram_summary(summary: &HistogramSummary) -> String {
    if summary.is_empty() {
        return "empty".to_string();
    }
    format!(
        "count={}, min={:.3}, max={:.3}, mean={:.3}, p50={:.3}, p95={:.3}, p99={:.3}",
        summary.count,
        summary.min,
        summary.max,
        summary.mean,
        summary.p50,
        summary.p95,
        summary.p99
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_export_format() {
        let registry = MetricsRegistry::new();
        registry.increment("test_counter", 5);
        registry.record("test_histogram", 10.0);

        let console_output = export_metrics(&registry, ExportFormat::Console);
        assert!(console_output.contains("test_counter"));

        let json_output = export_metrics(&registry, ExportFormat::Json);
        assert!(json_output.contains("test_counter"));
    }

    #[test]
    fn test_format_histogram_summary_empty() {
        let summary = HistogramSummary::default();
        assert_eq!(format_histogram_summary(&summary), "empty");
    }

    #[test]
    fn test_format_histogram_summary() {
        let summary = HistogramSummary {
            count: 100,
            sum: 5050.0,
            mean: 50.5,
            min: 1.0,
            max: 100.0,
            p50: 50.0,
            p95: 95.0,
            p99: 99.0,
        };

        let formatted = format_histogram_summary(&summary);
        assert!(formatted.contains("count=100"));
        assert!(formatted.contains("min=1.000"));
        assert!(formatted.contains("max=100.000"));
    }

    #[test]
    fn test_export_format_equality() {
        assert_eq!(ExportFormat::Console, ExportFormat::Console);
        assert_ne!(ExportFormat::Console, ExportFormat::Json);
    }
}
