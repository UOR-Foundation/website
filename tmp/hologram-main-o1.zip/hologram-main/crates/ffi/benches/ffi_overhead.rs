use criterion::{black_box, criterion_group, criterion_main, Criterion, Throughput};
use uor_ffi::{
    byte_not,
    byte_pred,
    byte_rank,
    byte_succ,
    byte_to_braille,
    byte_to_codepoint,
    byte_to_domain,
    curvature_q0,
    curvature_q1,
    relu_lut,
    sigmoid_lut,
    // LUT functions
    stratum_q0,
    stratum_q1,
    FfiDatum16,
    FfiDatum16Proof,
    // Types
    FfiView,
    FfiWord2,
    FfiWord4,
};

/// Benchmark FFI call overhead
///
/// Target: < 10 ns per call
fn bench_ffi_overhead(c: &mut Criterion) {
    let mut group = c.benchmark_group("ffi_overhead");
    group.throughput(Throughput::Elements(1));

    // Taxon operations
    group.bench_function("byte_to_braille", |b| {
        b.iter(|| {
            black_box(byte_to_braille(black_box(42)));
        });
    });

    group.bench_function("byte_to_codepoint", |b| {
        b.iter(|| {
            black_box(byte_to_codepoint(black_box(42)));
        });
    });

    group.bench_function("byte_to_domain", |b| {
        b.iter(|| {
            black_box(byte_to_domain(black_box(42)));
        });
    });

    group.bench_function("byte_rank", |b| {
        b.iter(|| {
            black_box(byte_rank(black_box(42)));
        });
    });

    // Ring operations
    group.bench_function("byte_succ", |b| {
        b.iter(|| {
            black_box(byte_succ(black_box(42)));
        });
    });

    group.bench_function("byte_pred", |b| {
        b.iter(|| {
            black_box(byte_pred(black_box(42)));
        });
    });

    group.bench_function("byte_not", |b| {
        b.iter(|| {
            black_box(byte_not(black_box(42)));
        });
    });

    group.finish();
}

/// Benchmark View operations
fn bench_view_operations(c: &mut Criterion) {
    let mut group = c.benchmark_group("view_operations");
    group.throughput(Throughput::Elements(1));

    let view = FfiView::identity();

    group.bench_function("view_apply", |b| {
        b.iter(|| {
            black_box(view.apply(black_box(42)));
        });
    });

    group.bench_function("view_is_bijective", |b| {
        b.iter(|| {
            black_box(view.is_bijective());
        });
    });

    group.finish();
}

/// Benchmark View bulk operations
fn bench_view_bulk(c: &mut Criterion) {
    let mut group = c.benchmark_group("view_bulk");

    let view = FfiView::identity();

    group.throughput(Throughput::Bytes(1024));
    group.bench_function("view_apply_slice_1kb", |b| {
        b.iter(|| {
            let data = vec![42u8; 1024];
            black_box(view.apply_slice(black_box(data)));
        });
    });

    group.finish();
}

/// Benchmark LUT operations
fn bench_lut_operations(c: &mut Criterion) {
    let mut group = c.benchmark_group("lut_operations");
    group.throughput(Throughput::Elements(1));

    group.bench_function("stratum_q0", |b| {
        b.iter(|| black_box(stratum_q0(black_box(42))));
    });

    group.bench_function("curvature_q0", |b| {
        b.iter(|| black_box(curvature_q0(black_box(42))));
    });

    group.bench_function("sigmoid_lut", |b| {
        b.iter(|| black_box(sigmoid_lut(black_box(42))));
    });

    group.bench_function("relu_lut", |b| {
        b.iter(|| black_box(relu_lut(black_box(42))));
    });

    group.bench_function("stratum_q1", |b| {
        b.iter(|| black_box(stratum_q1(black_box(0x1234))));
    });

    group.bench_function("curvature_q1", |b| {
        b.iter(|| black_box(curvature_q1(black_box(0x1234))));
    });

    group.finish();
}

/// Benchmark Word type operations
fn bench_word_operations(c: &mut Criterion) {
    let mut group = c.benchmark_group("word_operations");
    group.throughput(Throughput::Elements(1));

    group.bench_function("word2_new", |b| {
        b.iter(|| black_box(FfiWord2::new(black_box(0x1234))));
    });

    group.bench_function("word4_new", |b| {
        b.iter(|| black_box(FfiWord4::new(black_box(0xDEADBEEF))));
    });

    let w2 = FfiWord2::new(0x1234);
    group.bench_function("word2_taxon", |b| {
        b.iter(|| black_box(w2.taxon(black_box(0))));
    });

    group.finish();
}

/// Benchmark Datum16 operations
fn bench_datum_operations(c: &mut Criterion) {
    let mut group = c.benchmark_group("datum_operations");
    group.throughput(Throughput::Elements(1));

    group.bench_function("datum16_new", |b| {
        b.iter(|| black_box(FfiDatum16::new(black_box(0x1234))));
    });

    let d = FfiDatum16::new(0x1234);
    group.bench_function("datum16_stratum", |b| {
        b.iter(|| black_box(d.stratum()));
    });

    group.bench_function("datum16_curvature", |b| {
        b.iter(|| black_box(d.curvature()));
    });

    group.bench_function("datum16_proof_new", |b| {
        b.iter(|| black_box(FfiDatum16Proof::from_datum(black_box(0x1234))));
    });

    let p = FfiDatum16Proof::from_datum(0x1234);
    group.bench_function("datum16_proof_verify", |b| {
        b.iter(|| black_box(p.is_valid()));
    });

    group.finish();
}

criterion_group!(
    benches,
    bench_ffi_overhead,
    bench_view_operations,
    bench_view_bulk,
    bench_lut_operations,
    bench_word_operations,
    bench_datum_operations,
);
criterion_main!(benches);
