//! Shuffle operations: shuffle, permute, broadcast.
//!
//! Portable implementations with no heap allocation.
//!
//! ```
//! use prism::state::State;
//! use prism::ops::shuffle;
//!
//! let s = State::from_bytes(&[1, 2, 3]);
//! let b = shuffle::broadcast(&s, 0);
//! assert!(b.as_bytes().iter().all(|&v| v == 1));
//! ```

use crate::ops::{ConformanceTargets, Operation};
use crate::state::State;

const SHUFFLE_TARGETS: ConformanceTargets = ConformanceTargets {
    minimum: 5,
    optimal: 3,
    theoretical: 1,
};

/// Rearrange bytes according to an index table.
///
/// `result[i] = state[indices[i]]` for each position.
///
/// ```
/// use prism::state::State;
/// use prism::ops::shuffle::shuffle;
///
/// let s = State::from_bytes(&[10, 20, 30]);
/// let mut idx = [0u8; State::LEN];
/// idx[0] = 2; // result[0] = state[2] = 30
/// idx[1] = 0; // result[1] = state[0] = 10
/// let r = shuffle(&s, &idx);
/// assert_eq!(r.as_bytes()[0], 30);
/// assert_eq!(r.as_bytes()[1], 10);
/// ```
#[inline]
#[must_use]
pub fn shuffle(state: &State, indices: &[u8; State::LEN]) -> State {
    let mut result = State::zeros();
    let src = state.as_bytes();
    let out = result.as_bytes_mut();
    for i in 0..State::LEN {
        let idx = indices[i] as usize;
        out[i] = if idx < State::LEN { src[idx] } else { 0 };
    }
    result
}

/// Permute bytes by index table (semantic alias for [`shuffle`]).
///
/// Identical to `shuffle`, but conveys the intent of a bijective
/// rearrangement.
///
/// ```
/// use prism::state::State;
/// use prism::ops::shuffle::permute;
///
/// // Create state with first 3 bytes set
/// let s = State::from_bytes(&[5, 6, 7]);
/// // All indices point to byte 0
/// let idx = [0u8; State::LEN];
/// let r = permute(&s, &idx);
/// // All bytes become the value at index 0 (5)
/// assert!(r.as_bytes().iter().all(|&b| b == 5));
/// ```
#[inline]
#[must_use]
pub fn permute(state: &State, indices: &[u8; State::LEN]) -> State {
    shuffle(state, indices)
}

/// Broadcast a single byte to all positions.
///
/// The byte at `index` is copied to every position. If `index >= State::LEN`,
/// all bytes are set to zero.
///
/// ```
/// use prism::state::State;
/// use prism::ops::shuffle::broadcast;
///
/// let s = State::from_bytes(&[42]);
/// let b = broadcast(&s, 0);
/// assert!(b.as_bytes().iter().all(|&v| v == 42));
/// ```
#[inline]
#[must_use]
pub fn broadcast(state: &State, index: usize) -> State {
    let val = if index < State::LEN {
        state.as_bytes()[index]
    } else {
        0
    };
    let mut result = State::zeros();
    for b in result.as_bytes_mut() {
        *b = val;
    }
    result
}

/// Shuffle operation type (implements [`Operation`]).
///
/// Wraps a fixed index table.
pub struct ShuffleOp {
    /// Index table for the shuffle.
    pub indices: [u8; State::LEN],
}

impl Operation for ShuffleOp {
    const NAME: &'static str = "shuffle";
    const TARGETS: ConformanceTargets = SHUFFLE_TARGETS;
    fn apply(&self, state: State) -> State {
        shuffle(&state, &self.indices)
    }
}

/// Broadcast operation type (implements [`Operation`]).
///
/// Wraps a fixed source index.
pub struct BroadcastOp(pub usize);

impl Operation for BroadcastOp {
    const NAME: &'static str = "broadcast";
    const TARGETS: ConformanceTargets = SHUFFLE_TARGETS;
    fn apply(&self, state: State) -> State {
        broadcast(&state, self.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[allow(clippy::cast_possible_truncation)]
    fn identity_indices() -> [u8; State::LEN] {
        let mut idx = [0u8; State::LEN];
        for (i, item) in idx.iter_mut().enumerate().take(State::LEN) {
            *item = i as u8; // Safe: LEN = 624, max index 623 fits in u8
        }
        idx
    }

    #[test]
    fn test_shuffle_identity() {
        let s = State::from_bytes(&[0xAB; 624]);
        let idx = identity_indices();
        assert_eq!(shuffle(&s, &idx), s);
    }

    #[test]
    #[allow(clippy::cast_possible_truncation)]
    fn test_shuffle_reverse() {
        let data: Vec<u8> = (0..State::LEN).map(|i| i as u8).collect();
        let s = State::from_bytes(&data);
        let mut idx = [0u8; State::LEN];
        // Reverse the first 256 bytes only (indices are u8, max 255)
        for (i, item) in idx.iter_mut().enumerate().take(256) {
            *item = (255 - i) as u8;
        }
        let r = shuffle(&s, &idx);
        assert_eq!(r.as_bytes()[0], 255);
        assert_eq!(r.as_bytes()[255], 0);
    }

    #[test]
    fn test_shuffle_out_of_bounds() {
        let s = State::from_bytes(&[0xFF; 624]);
        // Indices all 0xFF (255) — valid since 255 < 624
        let idx = [0xFF; State::LEN];
        let r = shuffle(&s, &idx);
        assert!(r.as_bytes().iter().all(|&b| b == 0xFF));
    }

    #[test]
    fn test_permute_is_shuffle() {
        let s = State::from_bytes(&[1, 2, 3, 4, 5]);
        let idx = identity_indices();
        assert_eq!(permute(&s, &idx), shuffle(&s, &idx));
    }

    #[test]
    fn test_broadcast_first_byte() {
        let s = State::from_bytes(&[42, 0, 0]);
        let b = broadcast(&s, 0);
        assert!(b.as_bytes().iter().all(|&v| v == 42));
    }

    #[test]
    fn test_broadcast_middle_byte() {
        let mut s = State::zeros();
        s.as_bytes_mut()[100] = 77;
        let b = broadcast(&s, 100);
        assert!(b.as_bytes().iter().all(|&v| v == 77));
    }

    #[test]
    fn test_broadcast_out_of_bounds() {
        let s = State::ones();
        let b = broadcast(&s, State::LEN + 10);
        assert!(b.as_bytes().iter().all(|&v| v == 0));
    }

    #[test]
    fn test_shuffle_op_trait() {
        let op = ShuffleOp {
            indices: identity_indices(),
        };
        let s = State::from_bytes(&[0xCD; 624]);
        assert_eq!(op.apply(s), s);
        assert_eq!(ShuffleOp::NAME, "shuffle");
    }

    #[test]
    fn test_broadcast_op_trait() {
        let s = State::from_bytes(&[99]);
        let op = BroadcastOp(0);
        let b = op.apply(s);
        assert!(b.as_bytes().iter().all(|&v| v == 99));
        assert_eq!(BroadcastOp::NAME, "broadcast");
    }
}
