//! .holb file writer for serializing BackendPlan.

use std::io::Write;
use std::path::Path;

use hologram_holo::{BackendPlan, HolbHeader, HOLB_MAGIC};
use rkyv::ser::{serializers::AllocSerializer, Serializer};

use crate::error::{CliError, CliResult};

/// Page size for weight alignment (4KB).
const PAGE_SIZE: usize = 4096;

/// Write a BackendPlan to a .holb file.
pub fn write_holb(plan: &BackendPlan, path: &Path) -> CliResult<()> {
    // Serialize the plan with rkyv
    let mut serializer = AllocSerializer::<4096>::default();
    serializer
        .serialize_value(plan)
        .map_err(|e| CliError::CompilationFailed(format!("failed to serialize plan: {e}")))?;
    let plan_bytes = serializer.into_serializer().into_inner();

    // Calculate header
    let header_size = HolbHeader::header_size();
    let graph_offset = header_size as u64;
    let graph_size = plan_bytes.len() as u64;

    // Calculate padding to align weights to page boundary
    let weights_start = header_size + plan_bytes.len();
    let weights_offset_aligned = weights_start.next_multiple_of(PAGE_SIZE);
    let padding_needed = weights_offset_aligned - weights_start;

    let weights_offset = weights_offset_aligned as u64;
    let weights_size = plan.constants.len() as u64;

    // Calculate checksums
    let graph_checksum = crc32fast::hash(&plan_bytes);
    let weights_checksum = crc32fast::hash(&plan.constants);

    // Build header
    let header = HolbHeader {
        magic: *HOLB_MAGIC,
        version: 1,
        graph_offset,
        graph_size,
        weights_offset,
        weights_size,
        graph_checksum,
        weights_checksum,
    };

    // Write to file
    let mut file = std::fs::File::create(path)?;

    // Write header as raw bytes
    let header_bytes: &[u8] = unsafe {
        std::slice::from_raw_parts(
            &header as *const HolbHeader as *const u8,
            std::mem::size_of::<HolbHeader>(),
        )
    };
    file.write_all(header_bytes)?;

    // Pad header to full header_size if needed
    let header_actual = std::mem::size_of::<HolbHeader>();
    if header_actual < header_size {
        file.write_all(&vec![0u8; header_size - header_actual])?;
    }

    // Write plan bytes
    file.write_all(&plan_bytes)?;

    // Write padding
    if padding_needed > 0 {
        file.write_all(&vec![0u8; padding_needed])?;
    }

    // Write weights/constants (if any)
    if !plan.constants.is_empty() {
        file.write_all(&plan.constants)?;
    }

    file.flush()?;

    Ok(())
}

/// Get file statistics for a .holb file.
pub struct HolbStats {
    /// Total file size in bytes.
    pub total_size: usize,
    /// Graph/plan size in bytes.
    pub graph_size: usize,
    /// Weights size in bytes.
    pub weights_size: usize,
    /// Number of instructions.
    pub instruction_count: usize,
    /// Number of buffers.
    pub buffer_count: usize,
}

impl HolbStats {
    /// Create stats from a BackendPlan.
    pub fn from_plan(plan: &BackendPlan, total_size: usize) -> Self {
        Self {
            total_size,
            graph_size: total_size - plan.constants.len(),
            weights_size: plan.constants.len(),
            instruction_count: plan.instructions.len(),
            buffer_count: plan.buffers.len(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_holo::PlanMetadata;
    use tempfile::tempdir;

    #[test]
    fn test_write_empty_plan() {
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        let dir = tempdir().unwrap();
        let path = dir.path().join("test.holb");

        write_holb(&plan, &path).unwrap();

        // Verify file exists and has correct magic bytes
        let bytes = std::fs::read(&path).unwrap();
        assert!(bytes.len() >= 4);
        assert_eq!(&bytes[0..4], b"HOLB");
    }

    #[test]
    fn test_write_plan_with_constants() {
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![1, 2, 3, 4, 5, 6, 7, 8],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        let dir = tempdir().unwrap();
        let path = dir.path().join("test_with_constants.holb");

        write_holb(&plan, &path).unwrap();

        let bytes = std::fs::read(&path).unwrap();
        assert!(bytes.len() >= 4);
        assert_eq!(&bytes[0..4], b"HOLB");
        // Weights should be at the end after page alignment
        assert!(bytes.len() >= 8);
    }
}
