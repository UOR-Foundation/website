//! Message transport layer.

use super::protocol::{Message, PeerId};
use dashmap::DashMap;
use parking_lot::Mutex;
use std::collections::HashMap;
use std::sync::Arc;
use thiserror::Error;

#[cfg(feature = "async")]
use tokio::sync::{mpsc, oneshot};

/// Transport error.
#[derive(Debug, Error)]
pub enum TransportError {
    /// Peer not found.
    #[error("peer not found: {0}")]
    PeerNotFound(String),

    /// Peer disconnected.
    #[error("peer disconnected: {0}")]
    PeerDisconnected(String),

    /// Request timeout.
    #[error("request timeout")]
    Timeout,

    /// Request cancelled.
    #[error("request cancelled")]
    RequestCancelled,

    /// Channel error.
    #[error("channel error: {0}")]
    ChannelError(String),
}

/// In-process message bus for routing messages between peers.
#[cfg(feature = "async")]
pub struct MessageBus {
    /// Peer endpoints.
    endpoints: DashMap<PeerId, mpsc::Sender<Message>>,
    /// Pending requests (request_id -> response sender).
    pending_requests: Arc<Mutex<HashMap<u64, oneshot::Sender<Message>>>>,
    /// Next request ID.
    next_request_id: std::sync::atomic::AtomicU64,
}

#[cfg(feature = "async")]
impl MessageBus {
    /// Create a new message bus.
    #[must_use]
    pub fn new() -> Self {
        Self {
            endpoints: DashMap::new(),
            pending_requests: Arc::new(Mutex::new(HashMap::new())),
            next_request_id: std::sync::atomic::AtomicU64::new(1),
        }
    }

    /// Register a peer endpoint.
    ///
    /// Returns a receiver for incoming messages.
    pub fn register(&self, peer_id: PeerId) -> mpsc::Receiver<Message> {
        let (tx, rx) = mpsc::channel(256);
        self.endpoints.insert(peer_id, tx);
        rx
    }

    /// Unregister a peer endpoint.
    pub fn unregister(&self, peer_id: &PeerId) {
        self.endpoints.remove(peer_id);
    }

    /// Check if a peer is registered.
    #[must_use]
    pub fn is_registered(&self, peer_id: &PeerId) -> bool {
        self.endpoints.contains_key(peer_id)
    }

    /// Get the number of registered peers.
    #[must_use]
    pub fn peer_count(&self) -> usize {
        self.endpoints.len()
    }

    /// Send a message to a peer.
    pub async fn send(&self, to: PeerId, msg: Message) -> Result<(), TransportError> {
        let sender = self
            .endpoints
            .get(&to)
            .ok_or_else(|| TransportError::PeerNotFound(to.to_hex()))?;

        sender
            .send(msg)
            .await
            .map_err(|_| TransportError::PeerDisconnected(to.to_hex()))
    }

    /// Send a request and wait for a response.
    pub async fn request(
        &self,
        to: PeerId,
        msg: Message,
        timeout: std::time::Duration,
    ) -> Result<Message, TransportError> {
        // Extract request ID from message
        let request_id = Self::extract_request_id(&msg);

        // Create response channel
        let (tx, rx) = oneshot::channel();
        self.pending_requests.lock().insert(request_id, tx);

        // Send the message
        if let Err(e) = self.send(to, msg).await {
            self.pending_requests.lock().remove(&request_id);
            return Err(e);
        }

        // Wait for response with timeout
        match tokio::time::timeout(timeout, rx).await {
            Ok(Ok(response)) => Ok(response),
            Ok(Err(_)) => {
                self.pending_requests.lock().remove(&request_id);
                Err(TransportError::RequestCancelled)
            }
            Err(_) => {
                self.pending_requests.lock().remove(&request_id);
                Err(TransportError::Timeout)
            }
        }
    }

    /// Complete a pending request with a response.
    pub fn respond(&self, request_id: u64, response: Message) {
        if let Some(sender) = self.pending_requests.lock().remove(&request_id) {
            let _ = sender.send(response);
        }
    }

    /// Generate a new request ID.
    #[must_use]
    pub fn next_request_id(&self) -> u64 {
        self.next_request_id
            .fetch_add(1, std::sync::atomic::Ordering::SeqCst)
    }

    /// Extract request ID from a message.
    fn extract_request_id(msg: &Message) -> u64 {
        // Try to parse as content request
        if let Some(req) = msg.parse_content_request() {
            return req.request_id;
        }

        // Try to parse as content response
        if let Some(resp) = msg.parse_content_response() {
            return resp.request_id;
        }

        // Use sequence number as fallback
        msg.seq
    }
}

#[cfg(feature = "async")]
impl Default for MessageBus {
    fn default() -> Self {
        Self::new()
    }
}

/// Synchronous message bus (without async feature).
#[cfg(not(feature = "async"))]
pub struct MessageBus {
    /// Placeholder for non-async builds.
    _private: (),
}

#[cfg(not(feature = "async"))]
impl MessageBus {
    /// Create a new message bus (placeholder).
    #[must_use]
    pub fn new() -> Self {
        Self { _private: () }
    }
}

#[cfg(not(feature = "async"))]
impl Default for MessageBus {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_transport_error_display() {
        let err = TransportError::PeerNotFound("abc".to_string());
        assert!(err.to_string().contains("abc"));

        let err = TransportError::Timeout;
        assert!(err.to_string().contains("timeout"));
    }

    #[cfg(feature = "async")]
    #[tokio::test]
    async fn test_message_bus_register() {
        let bus = MessageBus::new();
        let peer_id = PeerId::random();

        let _rx = bus.register(peer_id);
        assert!(bus.is_registered(&peer_id));
        assert_eq!(bus.peer_count(), 1);

        bus.unregister(&peer_id);
        assert!(!bus.is_registered(&peer_id));
        assert_eq!(bus.peer_count(), 0);
    }

    #[cfg(feature = "async")]
    #[tokio::test]
    async fn test_message_bus_send() {
        let bus = MessageBus::new();
        let peer1 = PeerId::random();
        let peer2 = PeerId::random();

        let mut rx = bus.register(peer2);
        bus.register(peer1);

        let msg = Message::ping(peer1, 1);
        bus.send(peer2, msg.clone()).await.unwrap();

        let received = rx.recv().await.unwrap();
        assert_eq!(received.source, peer1);
        assert_eq!(received.seq, 1);
    }

    #[cfg(feature = "async")]
    #[tokio::test]
    async fn test_message_bus_send_not_found() {
        let bus = MessageBus::new();
        let peer = PeerId::random();

        let msg = Message::ping(peer, 1);
        let result = bus.send(peer, msg).await;

        assert!(matches!(result, Err(TransportError::PeerNotFound(_))));
    }

    #[cfg(feature = "async")]
    #[test]
    fn test_next_request_id() {
        let bus = MessageBus::new();
        let id1 = bus.next_request_id();
        let id2 = bus.next_request_id();
        assert_ne!(id1, id2);
        assert_eq!(id2, id1 + 1);
    }
}
