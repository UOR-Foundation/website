//! Epilogue fusion and kernel integration.
//!
//! This module provides tools for building and applying epilogue chains
//! that fuse post-operations (activation, bias, scale) into kernel writeback.
//!
//! # Design Principles
//!
//! - **Zero-Cost Abstraction**: Epilogue ops are inlined into kernel writeback
//! - **Compile-Time Resolution**: All decisions made at plan creation
//! - **No Branching**: Fixed chain applied uniformly to all outputs
//!
//! # Example
//!
//! ```rust,ignore
//! use hologram_backend::epilogue::{EpilogueBuilder, EpilogueApply};
//! use hologram_backend::plan::EpilogueChain;
//!
//! // Build an epilogue chain
//! let chain = EpilogueBuilder::new()
//!     .bias(bias_offset)
//!     .relu()
//!     .build();
//!
//! // Apply inline to output values
//! let output = EpilogueApply::apply_chain(&chain, value);
//! ```

use crate::plan::{ActivationTables, EpilogueChain, EpilogueOp, LookupTables};

/// Builder for constructing epilogue chains.
///
/// Provides a fluent API for building common epilogue patterns.
#[derive(Debug, Clone, Default)]
pub struct EpilogueBuilder {
    chain: EpilogueChain,
}

impl EpilogueBuilder {
    /// Create a new empty builder.
    pub fn new() -> Self {
        Self::default()
    }

    /// Add a bias addition operation.
    pub fn bias(mut self, offset: usize) -> Self {
        self.chain.push(EpilogueOp::BiasAdd { offset });
        self
    }

    /// Add ReLU activation.
    pub fn relu(mut self) -> Self {
        self.chain.push(EpilogueOp::ReLU);
        self
    }

    /// Add Sigmoid activation.
    pub fn sigmoid(mut self) -> Self {
        self.chain.push(EpilogueOp::Sigmoid);
        self
    }

    /// Add Tanh activation.
    pub fn tanh(mut self) -> Self {
        self.chain.push(EpilogueOp::Tanh);
        self
    }

    /// Add GELU activation.
    pub fn gelu(mut self) -> Self {
        self.chain.push(EpilogueOp::GELU);
        self
    }

    /// Add a scale operation.
    pub fn scale(mut self, alpha: f32) -> Self {
        self.chain.push(EpilogueOp::Scale { alpha });
        self
    }

    /// Add a clamp operation.
    pub fn clamp(mut self, min: f32, max: f32) -> Self {
        self.chain.push(EpilogueOp::Clamp { min, max });
        self
    }

    /// Add a custom lookup table activation.
    pub fn custom_table(mut self, table_id: u32) -> Self {
        self.chain.push(EpilogueOp::CustomTable { table_id });
        self
    }

    /// Add ReLU6 (clamp to [0, 6]).
    pub fn relu6(mut self) -> Self {
        self.chain.push(EpilogueOp::ReLU);
        self.chain.push(EpilogueOp::Clamp { min: 0.0, max: 6.0 });
        self
    }

    /// Add LeakyReLU (scale for negative values).
    ///
    /// LeakyReLU: f(x) = x if x >= 0, alpha * x if x < 0
    pub fn leaky_relu(mut self, alpha: f32) -> Self {
        self.chain.push(EpilogueOp::LeakyReLU { alpha });
        self
    }

    /// Add the common Conv-BN-ReLU pattern.
    pub fn conv_bn_relu(self, bias_offset: usize, scale: f32) -> Self {
        self.bias(bias_offset).scale(scale).relu()
    }

    /// Build the final epilogue chain.
    pub fn build(self) -> EpilogueChain {
        self.chain
    }

    /// Check if any operations have been added.
    pub fn is_empty(&self) -> bool {
        self.chain.is_empty()
    }
}

/// Inline application of epilogue operations.
///
/// Provides element-wise application functions for each epilogue operation,
/// designed to be inlined into kernel writeback loops.
pub struct EpilogueApply;

impl EpilogueApply {
    /// Apply an entire epilogue chain to a single value.
    ///
    /// This function is designed to be inlined by the compiler.
    #[inline(always)]
    pub fn apply_chain(chain: &EpilogueChain, mut value: f32) -> f32 {
        for op in &chain.ops {
            value = Self::apply_op(op, value, std::ptr::null());
        }
        value
    }

    /// Apply an entire epilogue chain with workspace access.
    ///
    /// The workspace pointer allows BiasAdd to fetch bias values.
    ///
    /// # Safety
    /// The caller must ensure that `workspace` is valid for reads at the offsets
    /// specified by any `BiasAdd` operations in the chain, plus `index`.
    #[inline(always)]
    pub unsafe fn apply_chain_with_workspace(
        chain: &EpilogueChain,
        mut value: f32,
        workspace: *const f32,
        index: usize,
    ) -> f32 {
        for op in &chain.ops {
            value = Self::apply_op_indexed(op, value, workspace, index);
        }
        value
    }

    /// Apply an entire epilogue chain with workspace and lookup table access.
    ///
    /// This version supports `CustomTable` operations via lookup table access.
    ///
    /// # Safety
    /// The caller must ensure that `workspace` is valid for reads at the offsets
    /// specified by any `BiasAdd` operations in the chain, plus `index`.
    #[inline(always)]
    pub unsafe fn apply_chain_with_tables(
        chain: &EpilogueChain,
        mut value: f32,
        workspace: *const f32,
        index: usize,
        tables: &LookupTables,
    ) -> f32 {
        for op in &chain.ops {
            value =
                Self::apply_op_with_tables(op, value, workspace, index, &tables.activation_tables);
        }
        value
    }

    /// Apply a single epilogue operation with lookup table access.
    ///
    /// This version supports `CustomTable` operations via activation table lookup.
    ///
    /// # Safety
    /// The caller must ensure that `workspace` is valid for reads at the offsets
    /// specified by any `BiasAdd` operations, plus `index`.
    #[inline(always)]
    pub unsafe fn apply_op_with_tables(
        op: &EpilogueOp,
        value: f32,
        workspace: *const f32,
        index: usize,
        activation_tables: &ActivationTables,
    ) -> f32 {
        match op {
            EpilogueOp::None => value,
            EpilogueOp::BiasAdd { offset } => {
                if !workspace.is_null() {
                    let bias = *workspace.add(*offset + index);
                    value + bias
                } else {
                    value
                }
            }
            EpilogueOp::BiasAddConst {
                offset,
                stride,
                channel_dim,
            } => {
                let base = workspace.add(*offset);
                let bias_idx = if *channel_dim > 0 {
                    (index % *channel_dim) * *stride
                } else {
                    index * *stride
                };
                let bias = *base.add(bias_idx);
                value + bias
            }
            EpilogueOp::ReLU => Self::relu(value),
            EpilogueOp::Sigmoid => Self::sigmoid(value),
            EpilogueOp::SiLU => Self::silu(value),
            EpilogueOp::Tanh => Self::tanh(value),
            EpilogueOp::GELU => Self::gelu(value),
            EpilogueOp::Scale { alpha } => value * alpha,
            EpilogueOp::Clamp { min, max } => value.clamp(*min, *max),
            EpilogueOp::LeakyReLU { alpha } => Self::leaky_relu(value, *alpha),
            EpilogueOp::CustomTable { table_id } => {
                // Apply activation via lookup table
                activation_tables.apply_f32(*table_id, value)
            }
        }
    }

    /// Apply a single epilogue operation.
    #[inline(always)]
    pub fn apply_op(op: &EpilogueOp, value: f32, _workspace: *const f32) -> f32 {
        match op {
            EpilogueOp::None => value,
            EpilogueOp::BiasAdd { offset: _ } => {
                // Bias requires index - use apply_op_indexed for full functionality
                value
            }
            EpilogueOp::BiasAddConst { .. } => value, // needs indexed access
            EpilogueOp::ReLU => Self::relu(value),
            EpilogueOp::Sigmoid => Self::sigmoid(value),
            EpilogueOp::SiLU => Self::silu(value),
            EpilogueOp::Tanh => Self::tanh(value),
            EpilogueOp::GELU => Self::gelu(value),
            EpilogueOp::Scale { alpha } => value * alpha,
            EpilogueOp::Clamp { min, max } => value.clamp(*min, *max),
            EpilogueOp::LeakyReLU { alpha } => Self::leaky_relu(value, *alpha),
            EpilogueOp::CustomTable { table_id: _ } => {
                // Custom tables need separate handling
                value
            }
        }
    }

    /// Apply an epilogue operation with indexed access to workspace.
    ///
    /// # Safety
    /// The caller must ensure that `workspace` is valid for reads at offset + index
    /// when `op` is `BiasAdd` and workspace is non-null.
    #[inline(always)]
    pub unsafe fn apply_op_indexed(
        op: &EpilogueOp,
        value: f32,
        workspace: *const f32,
        index: usize,
    ) -> f32 {
        match op {
            EpilogueOp::None => value,
            EpilogueOp::BiasAdd { offset } => {
                if !workspace.is_null() {
                    let bias = *workspace.add(*offset + index);
                    value + bias
                } else {
                    value
                }
            }
            EpilogueOp::BiasAddConst {
                offset,
                stride,
                channel_dim,
            } => {
                // Bias values live in plan.constant_data; caller must pass a pointer to it.
                let base = workspace.add(*offset);
                let bias_idx = if *channel_dim > 0 {
                    (index % *channel_dim) * *stride
                } else {
                    index * *stride
                };
                let bias = *base.add(bias_idx);
                value + bias
            }
            EpilogueOp::ReLU => Self::relu(value),
            EpilogueOp::Sigmoid => Self::sigmoid(value),
            EpilogueOp::SiLU => Self::silu(value),
            EpilogueOp::Tanh => Self::tanh(value),
            EpilogueOp::GELU => Self::gelu(value),
            EpilogueOp::Scale { alpha } => value * alpha,
            EpilogueOp::Clamp { min, max } => value.clamp(*min, *max),
            EpilogueOp::LeakyReLU { alpha } => Self::leaky_relu(value, *alpha),
            EpilogueOp::CustomTable { table_id: _ } => value,
        }
    }

    /// ReLU activation: max(0, x)
    #[inline(always)]
    pub fn relu(x: f32) -> f32 {
        x.max(0.0)
    }

    /// LeakyReLU activation: x if x >= 0, alpha * x if x < 0
    #[inline(always)]
    pub fn leaky_relu(x: f32, alpha: f32) -> f32 {
        if x >= 0.0 {
            x
        } else {
            alpha * x
        }
    }

    /// SiLU activation: x * sigmoid(x)
    #[inline(always)]
    pub fn silu(x: f32) -> f32 {
        x / (1.0 + (-x).exp())
    }

    /// Sigmoid activation: 1 / (1 + exp(-x))
    #[inline(always)]
    pub fn sigmoid(x: f32) -> f32 {
        1.0 / (1.0 + (-x).exp())
    }

    /// Tanh activation
    #[inline(always)]
    pub fn tanh(x: f32) -> f32 {
        x.tanh()
    }

    /// GELU activation (approximate): 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
    #[inline(always)]
    pub fn gelu(x: f32) -> f32 {
        const SQRT_2_OVER_PI: f32 = 0.797_884_6;
        const COEFF: f32 = 0.044715;

        let inner = SQRT_2_OVER_PI * (x + COEFF * x * x * x);
        0.5 * x * (1.0 + inner.tanh())
    }

    /// Swish activation: x * sigmoid(x)
    #[inline(always)]
    pub fn swish(x: f32) -> f32 {
        x * Self::sigmoid(x)
    }

    /// Softplus activation: log(1 + exp(x))
    #[inline(always)]
    pub fn softplus(x: f32) -> f32 {
        if x > 20.0 {
            x // Avoid overflow
        } else {
            (1.0 + x.exp()).ln()
        }
    }

    /// ELU activation: x if x > 0 else alpha * (exp(x) - 1)
    #[inline(always)]
    pub fn elu(x: f32, alpha: f32) -> f32 {
        if x > 0.0 {
            x
        } else {
            alpha * (x.exp() - 1.0)
        }
    }
}

/// Batch application of epilogue chains to arrays.
///
/// Provides vectorized application functions for processing entire
/// output buffers efficiently.
pub struct EpilogueBatch;

impl EpilogueBatch {
    /// Apply epilogue chain to an entire output buffer in-place.
    pub fn apply_inplace(chain: &EpilogueChain, output: &mut [f32]) {
        for value in output.iter_mut() {
            *value = EpilogueApply::apply_chain(chain, *value);
        }
    }

    /// Apply epilogue chain with bias from a separate buffer.
    pub fn apply_with_bias(chain: &EpilogueChain, output: &mut [f32], bias: &[f32]) {
        debug_assert!(
            bias.len() >= output.len()
                || chain
                    .ops
                    .iter()
                    .all(|op| !matches!(op, EpilogueOp::BiasAdd { .. })),
            "Bias buffer too small for output"
        );

        for (i, value) in output.iter_mut().enumerate() {
            let bias_val = if i < bias.len() { bias[i] } else { 0.0 };
            *value = apply_chain_with_bias(chain, *value, bias_val);
        }
    }

    /// Apply epilogue chain to output with custom stride.
    pub fn apply_strided(chain: &EpilogueChain, output: &mut [f32], count: usize, stride: usize) {
        for i in 0..count {
            let idx = i * stride;
            if idx < output.len() {
                output[idx] = EpilogueApply::apply_chain(chain, output[idx]);
            }
        }
    }

    /// Apply epilogue chain to a 2D output buffer (row-major).
    pub fn apply_2d(chain: &EpilogueChain, output: &mut [f32], rows: usize, cols: usize) {
        debug_assert!(output.len() >= rows * cols, "Output buffer too small");

        for row in 0..rows {
            for col in 0..cols {
                let idx = row * cols + col;
                output[idx] = EpilogueApply::apply_chain(chain, output[idx]);
            }
        }
    }
}

/// Apply epilogue chain with explicit bias value.
#[inline(always)]
fn apply_chain_with_bias(chain: &EpilogueChain, mut value: f32, bias: f32) -> f32 {
    for op in &chain.ops {
        value = match op {
            EpilogueOp::BiasAdd { offset: _ } => value + bias,
            _ => EpilogueApply::apply_op(op, value, std::ptr::null()),
        };
    }
    value
}

/// Metadata about an epilogue chain for optimization decisions.
#[derive(Debug, Clone, Copy)]
pub struct EpilogueMetadata {
    /// Number of operations in the chain.
    pub op_count: usize,
    /// Whether the chain contains bias addition.
    pub has_bias: bool,
    /// Whether the chain contains any activation.
    pub has_activation: bool,
    /// Whether the chain is identity (no-op).
    pub is_identity: bool,
    /// Estimated FLOP count per element.
    pub flops_per_element: usize,
}

impl EpilogueMetadata {
    /// Analyze an epilogue chain and compute metadata.
    pub fn analyze(chain: &EpilogueChain) -> Self {
        let mut has_bias = false;
        let mut has_activation = false;
        let mut flops = 0usize;

        for op in &chain.ops {
            match op {
                EpilogueOp::None => {}
                EpilogueOp::BiasAdd { .. } => {
                    has_bias = true;
                    flops += 1;
                }
                EpilogueOp::BiasAddConst { .. } => {
                    has_bias = true;
                    flops += 1;
                }
                EpilogueOp::ReLU => {
                    has_activation = true;
                    flops += 1;
                }
                EpilogueOp::Sigmoid => {
                    has_activation = true;
                    flops += 10; // exp + div
                }
                EpilogueOp::SiLU => {
                    has_activation = true;
                    flops += 12; // exp + mul/div
                }
                EpilogueOp::Tanh => {
                    has_activation = true;
                    flops += 10;
                }
                EpilogueOp::GELU => {
                    has_activation = true;
                    flops += 15; // polynomial + tanh
                }
                EpilogueOp::Scale { .. } => {
                    flops += 1;
                }
                EpilogueOp::Clamp { .. } => {
                    flops += 2;
                }
                EpilogueOp::LeakyReLU { .. } => {
                    has_activation = true;
                    flops += 2; // comparison + multiply
                }
                EpilogueOp::CustomTable { .. } => {
                    has_activation = true;
                    flops += 1; // Table lookup
                }
            }
        }

        let is_identity = chain.ops.is_empty()
            || (chain.ops.len() == 1 && matches!(chain.ops[0], EpilogueOp::None));

        Self {
            op_count: chain.ops.len(),
            has_bias,
            has_activation,
            is_identity,
            flops_per_element: flops,
        }
    }

    /// Check if the epilogue is cheap enough to fuse.
    ///
    /// Returns true if the epilogue overhead is less than the fusion benefit.
    pub fn should_fuse(&self, output_elements: usize) -> bool {
        // Fusion is beneficial if:
        // 1. Not identity (nothing to fuse)
        // 2. FLOP overhead is small relative to output size
        // 3. Memory traffic saved > epilogue compute cost

        if self.is_identity {
            return false;
        }

        // Rough heuristic: fuse if epilogue FLOPs < 20% of memory bandwidth cost
        let memory_cost = output_elements * 2; // Read + write
        let epilogue_cost = output_elements * self.flops_per_element;

        epilogue_cost < memory_cost / 5
    }
}

/// Pre-built common epilogue chains.
pub mod common {
    use super::*;

    /// Empty epilogue (identity).
    pub fn identity() -> EpilogueChain {
        EpilogueChain::new()
    }

    /// Bias only.
    pub fn bias(offset: usize) -> EpilogueChain {
        EpilogueBuilder::new().bias(offset).build()
    }

    /// ReLU only.
    pub fn relu() -> EpilogueChain {
        EpilogueBuilder::new().relu().build()
    }

    /// Bias + ReLU (common in CNNs).
    pub fn bias_relu(offset: usize) -> EpilogueChain {
        EpilogueBuilder::new().bias(offset).relu().build()
    }

    /// Bias + Sigmoid.
    pub fn bias_sigmoid(offset: usize) -> EpilogueChain {
        EpilogueBuilder::new().bias(offset).sigmoid().build()
    }

    /// Bias + GELU (common in Transformers).
    pub fn bias_gelu(offset: usize) -> EpilogueChain {
        EpilogueBuilder::new().bias(offset).gelu().build()
    }

    /// Scale + Bias (linear layer output).
    pub fn scale_bias(alpha: f32, offset: usize) -> EpilogueChain {
        EpilogueBuilder::new().scale(alpha).bias(offset).build()
    }

    /// ReLU6 (MobileNet).
    pub fn relu6() -> EpilogueChain {
        EpilogueBuilder::new().relu6().build()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_epilogue_builder_new() {
        let chain = EpilogueBuilder::new().build();
        assert!(chain.is_empty());
    }

    #[test]
    fn test_epilogue_builder_relu() {
        let chain = EpilogueBuilder::new().relu().build();
        assert_eq!(chain.len(), 1);
        assert!(matches!(chain.ops[0], EpilogueOp::ReLU));
    }

    #[test]
    fn test_epilogue_builder_chain() {
        let chain = EpilogueBuilder::new().bias(0).relu().scale(2.0).build();

        assert_eq!(chain.len(), 3);
        assert!(matches!(chain.ops[0], EpilogueOp::BiasAdd { offset: 0 }));
        assert!(matches!(chain.ops[1], EpilogueOp::ReLU));
        assert!(matches!(chain.ops[2], EpilogueOp::Scale { alpha } if alpha == 2.0));
    }

    #[test]
    fn test_epilogue_apply_relu() {
        assert_eq!(EpilogueApply::relu(5.0), 5.0);
        assert_eq!(EpilogueApply::relu(-5.0), 0.0);
        assert_eq!(EpilogueApply::relu(0.0), 0.0);
    }

    #[test]
    fn test_epilogue_apply_sigmoid() {
        let result = EpilogueApply::sigmoid(0.0);
        assert!((result - 0.5).abs() < 0.001);

        // Large positive -> ~1
        assert!(EpilogueApply::sigmoid(10.0) > 0.99);

        // Large negative -> ~0
        assert!(EpilogueApply::sigmoid(-10.0) < 0.01);
    }

    #[test]
    fn test_epilogue_apply_tanh() {
        assert!((EpilogueApply::tanh(0.0)).abs() < 0.001);
        assert!(EpilogueApply::tanh(10.0) > 0.99);
        assert!(EpilogueApply::tanh(-10.0) < -0.99);
    }

    #[test]
    fn test_epilogue_apply_gelu() {
        // GELU(0) ≈ 0
        assert!(EpilogueApply::gelu(0.0).abs() < 0.001);

        // GELU(x) ≈ x for large positive x
        let x = 5.0;
        assert!((EpilogueApply::gelu(x) - x).abs() < 0.1);

        // GELU(x) ≈ 0 for large negative x
        assert!(EpilogueApply::gelu(-5.0).abs() < 0.01);
    }

    #[test]
    fn test_epilogue_apply_chain() {
        let chain = EpilogueBuilder::new().scale(2.0).relu().build();

        // 3.0 * 2.0 = 6.0, relu(6.0) = 6.0
        assert_eq!(EpilogueApply::apply_chain(&chain, 3.0), 6.0);

        // -3.0 * 2.0 = -6.0, relu(-6.0) = 0.0
        assert_eq!(EpilogueApply::apply_chain(&chain, -3.0), 0.0);
    }

    #[test]
    fn test_epilogue_batch_inplace() {
        let chain = EpilogueBuilder::new().relu().build();
        let mut output = vec![-1.0, 0.0, 1.0, 2.0];

        EpilogueBatch::apply_inplace(&chain, &mut output);

        assert_eq!(output, vec![0.0, 0.0, 1.0, 2.0]);
    }

    #[test]
    fn test_epilogue_metadata_analyze() {
        let chain = EpilogueBuilder::new().bias(0).relu().build();

        let meta = EpilogueMetadata::analyze(&chain);

        assert_eq!(meta.op_count, 2);
        assert!(meta.has_bias);
        assert!(meta.has_activation);
        assert!(!meta.is_identity);
    }

    #[test]
    fn test_epilogue_metadata_identity() {
        let chain = EpilogueChain::new();
        let meta = EpilogueMetadata::analyze(&chain);

        assert!(meta.is_identity);
        assert_eq!(meta.op_count, 0);
    }

    #[test]
    fn test_common_epilogues() {
        let identity = common::identity();
        assert!(identity.is_empty());

        let relu = common::relu();
        assert_eq!(relu.len(), 1);

        let bias_relu = common::bias_relu(0);
        assert_eq!(bias_relu.len(), 2);
    }

    #[test]
    fn test_relu6() {
        let chain = EpilogueBuilder::new().relu6().build();
        assert_eq!(chain.len(), 2);

        // Test application
        assert_eq!(EpilogueApply::apply_chain(&chain, -1.0), 0.0);
        assert_eq!(EpilogueApply::apply_chain(&chain, 3.0), 3.0);
        assert_eq!(EpilogueApply::apply_chain(&chain, 10.0), 6.0);
    }

    #[test]
    fn test_clamp() {
        let chain = EpilogueBuilder::new().clamp(-1.0, 1.0).build();

        assert_eq!(EpilogueApply::apply_chain(&chain, 0.5), 0.5);
        assert_eq!(EpilogueApply::apply_chain(&chain, 2.0), 1.0);
        assert_eq!(EpilogueApply::apply_chain(&chain, -2.0), -1.0);
    }

    #[test]
    fn test_swish() {
        // Swish(0) = 0 * sigmoid(0) = 0 * 0.5 = 0
        assert!(EpilogueApply::swish(0.0).abs() < 0.001);

        // Swish(x) ≈ x for large positive x
        assert!(EpilogueApply::swish(10.0) > 9.9);
    }

    #[test]
    fn test_elu() {
        // ELU(x) = x for x > 0
        assert_eq!(EpilogueApply::elu(5.0, 1.0), 5.0);

        // ELU(0) = 0
        assert_eq!(EpilogueApply::elu(0.0, 1.0), 0.0);

        // ELU(x) = alpha * (exp(x) - 1) for x < 0
        let elu_neg = EpilogueApply::elu(-1.0, 1.0);
        assert!(elu_neg < 0.0);
        assert!(elu_neg > -1.0);
    }

    #[test]
    fn test_softplus() {
        // softplus(0) = ln(2) ≈ 0.693
        let result = EpilogueApply::softplus(0.0);
        assert!((result - 0.693).abs() < 0.01);

        // softplus(x) ≈ x for large x
        assert!((EpilogueApply::softplus(100.0) - 100.0).abs() < 0.01);
    }

    #[test]
    fn test_batch_strided() {
        let chain = EpilogueBuilder::new().scale(2.0).build();
        let mut output = vec![1.0, 0.0, 2.0, 0.0, 3.0, 0.0];

        EpilogueBatch::apply_strided(&chain, &mut output, 3, 2);

        assert_eq!(output, vec![2.0, 0.0, 4.0, 0.0, 6.0, 0.0]);
    }

    #[test]
    fn test_should_fuse() {
        let heavy_chain = EpilogueBuilder::new().sigmoid().gelu().tanh().build();
        let meta = EpilogueMetadata::analyze(&heavy_chain);

        // Heavy chain might not be worth fusing for small outputs
        let small_output = 64;
        let large_output = 1_000_000;

        // Heuristic may vary, just test it doesn't panic
        let _ = meta.should_fuse(small_output);
        let _ = meta.should_fuse(large_output);
    }

    #[test]
    fn test_custom_table_sigmoid() {
        use crate::plan::activation_table_id;

        let tables = LookupTables::default();
        let chain = EpilogueBuilder::new()
            .custom_table(activation_table_id::SIGMOID)
            .build();

        // Test that CustomTable applies sigmoid via lookup
        // Input 0.5 should map to approximately sigmoid(0.0) = 0.5
        let result = unsafe {
            EpilogueApply::apply_chain_with_tables(&chain, 0.5, std::ptr::null(), 0, &tables)
        };

        // sigmoid(0) ≈ 0.5, so input 0.5 (mapped to index 127-128) should give ~0.5
        assert!(result > 0.4 && result < 0.6, "Result was {}", result);
    }

    #[test]
    fn test_custom_table_relu() {
        use crate::plan::activation_table_id;

        let tables = LookupTables::default();
        let chain = EpilogueBuilder::new()
            .custom_table(activation_table_id::RELU)
            .build();

        // Input near 0 should be near 0 (ReLU with zero point at 128)
        let result_low = unsafe {
            EpilogueApply::apply_chain_with_tables(&chain, 0.1, std::ptr::null(), 0, &tables)
        };

        // Input near 1 should pass through
        let result_high = unsafe {
            EpilogueApply::apply_chain_with_tables(&chain, 0.9, std::ptr::null(), 0, &tables)
        };

        // Low values should be clamped low (ReLU-like behavior)
        // High values should be preserved
        assert!(
            result_high > result_low,
            "High {} vs Low {}",
            result_high,
            result_low
        );
    }

    #[test]
    fn test_activation_tables_get() {
        use crate::plan::activation_table_id;

        let tables = ActivationTables::default();

        // Known table IDs should return Some
        assert!(tables.get(activation_table_id::SIGMOID).is_some());
        assert!(tables.get(activation_table_id::TANH).is_some());
        assert!(tables.get(activation_table_id::RELU).is_some());
        assert!(tables.get(activation_table_id::GELU).is_some());
        assert!(tables.get(activation_table_id::SILU).is_some());

        // Unknown table ID should return None
        assert!(tables.get(999).is_none());
    }

    #[test]
    fn test_activation_tables_apply_f32() {
        use crate::plan::activation_table_id;

        let tables = ActivationTables::default();

        // Test sigmoid at midpoint
        let sigmoid_mid = tables.apply_f32(activation_table_id::SIGMOID, 0.5);
        // Should be approximately 0.5 (since sigmoid(0) = 0.5)
        assert!(sigmoid_mid > 0.45 && sigmoid_mid < 0.55);

        // Test unknown table returns unchanged value
        let unchanged = tables.apply_f32(999, 0.75);
        assert!((unchanged - 0.75).abs() < 0.001);
    }
}
