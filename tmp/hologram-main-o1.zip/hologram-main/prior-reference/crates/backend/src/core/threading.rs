//! Static thread partitioning for parallel execution.
//!
//! This module provides [`ThreadPartitioner`] for computing compile-time
//! thread partitions. All thread assignments are determined at plan creation,
//! enabling zero-overhead dispatch at runtime.
//!
//! # Design Principles
//!
//! - **Static Assignment**: Work ranges pre-computed at compile time
//! - **No Work Stealing**: Deterministic execution for predictable performance
//! - **Nested Parallelism Prevention**: Budget parallelism at fusion region level
//! - **Cache-Aware**: Partitions respect cache line boundaries
//!
//! # Example
//!
//! ```rust,ignore
//! use hologram_backend::threading::{ThreadPartitioner, PartitionRequest};
//!
//! let partitioner = ThreadPartitioner::new(8); // 8 cores
//!
//! // Compute partition for a 1024x1024 matrix operation
//! let request = PartitionRequest::matmul(1024, 1024, 1024);
//! let partition = partitioner.compute_partition(&request);
//!
//! println!("Using {} threads", partition.num_threads);
//! for range in &partition.work_ranges {
//!     println!("Thread {}: rows {}..{}", range.thread_id, range.start, range.end);
//! }
//! ```

use crate::plan::{PartitionStrategy, ThreadPartition, WorkRange};

/// Minimum work size per thread to avoid parallelism overhead.
const MIN_WORK_PER_THREAD: usize = 4096;

/// Minimum number of rows per thread for row partitioning.
const MIN_ROWS_PER_THREAD: usize = 16;

/// Cache line size in bytes.
const CACHE_LINE_SIZE: usize = 64;

/// Request for computing a thread partition.
#[derive(Debug, Clone)]
pub struct PartitionRequest {
    /// Total work items.
    pub total_work: usize,
    /// Preferred partition dimension (rows, tiles, etc).
    pub partition_dim: PartitionDimension,
    /// Element size for cache line alignment.
    pub element_size: usize,
    /// Estimated FLOPs per work item (for load balancing).
    pub flops_per_item: usize,
    /// Whether the operation is memory-bound.
    pub memory_bound: bool,
}

/// Dimension to partition.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PartitionDimension {
    /// Partition by rows (M dimension).
    Rows(usize),
    /// Partition by tiles.
    Tiles(usize),
    /// Partition by Winograd tiles.
    WinogradTiles(usize),
    /// Partition by output channels.
    OutputChannels(usize),
    /// Generic work items.
    WorkItems(usize),
}

impl PartitionRequest {
    /// Create a request for MatMul partitioning.
    pub fn matmul(m: usize, k: usize, n: usize) -> Self {
        let total_work = m * k * n;
        let flops_per_row = 2 * k * n;

        Self {
            total_work,
            partition_dim: PartitionDimension::Rows(m),
            element_size: 4, // Assume f32
            flops_per_item: flops_per_row,
            memory_bound: k * n < 1024, // Small K*N is memory-bound
        }
    }

    /// Create a request for Conv2D partitioning.
    pub fn conv2d(
        out_h: usize,
        out_w: usize,
        filters: usize,
        kernel_size: usize,
        channels: usize,
    ) -> Self {
        let total_work = out_h * out_w * filters;
        let flops_per_output = 2 * kernel_size * kernel_size * channels;

        Self {
            total_work,
            partition_dim: PartitionDimension::OutputChannels(filters),
            element_size: 4,
            flops_per_item: flops_per_output,
            memory_bound: false,
        }
    }

    /// Create a request for Winograd Conv2D partitioning.
    pub fn winograd(tiles_h: usize, tiles_w: usize, filters: usize) -> Self {
        let num_tiles = tiles_h * tiles_w;
        let total_work = num_tiles * filters;

        Self {
            total_work,
            partition_dim: PartitionDimension::WinogradTiles(num_tiles),
            element_size: 4,
            flops_per_item: 36 * filters, // Approximate for F(2,3)
            memory_bound: false,
        }
    }

    /// Create a request for tile-based partitioning.
    pub fn tiled(num_tiles: usize, work_per_tile: usize) -> Self {
        Self {
            total_work: num_tiles * work_per_tile,
            partition_dim: PartitionDimension::Tiles(num_tiles),
            element_size: 4,
            flops_per_item: work_per_tile,
            memory_bound: false,
        }
    }

    /// Create a generic work item request.
    pub fn generic(total_items: usize, work_per_item: usize) -> Self {
        Self {
            total_work: total_items * work_per_item,
            partition_dim: PartitionDimension::WorkItems(total_items),
            element_size: 4,
            flops_per_item: work_per_item,
            memory_bound: work_per_item < 100,
        }
    }
}

/// Computes static thread partitions at compile time.
///
/// The partitioner determines optimal thread counts and work assignments
/// based on operation characteristics and hardware capabilities.
#[derive(Debug, Clone)]
pub struct ThreadPartitioner {
    /// Maximum number of threads to use.
    max_threads: usize,
    /// Minimum work per thread threshold.
    min_work_threshold: usize,
    /// Whether to align partitions to cache lines.
    cache_align: bool,
}

impl ThreadPartitioner {
    /// Create a new partitioner with the specified thread limit.
    pub fn new(max_threads: usize) -> Self {
        Self {
            max_threads,
            min_work_threshold: MIN_WORK_PER_THREAD,
            cache_align: true,
        }
    }

    /// Create a partitioner using available CPU threads.
    pub fn auto() -> Self {
        let max_threads = std::thread::available_parallelism()
            .map(|p| p.get())
            .unwrap_or(1);
        Self::new(max_threads)
    }

    /// Set the minimum work threshold per thread.
    pub fn with_min_work(mut self, threshold: usize) -> Self {
        self.min_work_threshold = threshold;
        self
    }

    /// Enable or disable cache line alignment.
    pub fn with_cache_align(mut self, align: bool) -> Self {
        self.cache_align = align;
        self
    }

    /// Compute a thread partition for the given request.
    pub fn compute_partition(&self, request: &PartitionRequest) -> ThreadPartition {
        // Check if parallelism is worthwhile
        if request.total_work < self.min_work_threshold {
            return ThreadPartition::sequential();
        }

        // Determine optimal thread count
        let max_useful_threads = self.max_useful_threads(request);
        let num_threads = max_useful_threads.min(self.max_threads);

        if num_threads <= 1 {
            return ThreadPartition::sequential();
        }

        // Compute work ranges based on partition dimension
        let (strategy, work_ranges) = self.compute_ranges(request, num_threads);

        ThreadPartition {
            strategy: Some(strategy),
            num_threads,
            work_ranges,
        }
    }

    /// Compute the maximum useful thread count for this operation.
    fn max_useful_threads(&self, request: &PartitionRequest) -> usize {
        // For memory-bound ops, limit parallelism to avoid bandwidth saturation
        if request.memory_bound {
            return 4.min(self.max_threads);
        }

        // Get the partition dimension count
        let partition_count = match request.partition_dim {
            PartitionDimension::Rows(n)
            | PartitionDimension::Tiles(n)
            | PartitionDimension::WinogradTiles(n)
            | PartitionDimension::OutputChannels(n)
            | PartitionDimension::WorkItems(n) => n,
        };

        // Need at least MIN_ROWS_PER_THREAD per thread
        let by_rows = partition_count / MIN_ROWS_PER_THREAD;

        // Need at least min_work_threshold FLOPs per thread
        let by_work = request.total_work / self.min_work_threshold;

        by_rows.min(by_work).max(1)
    }

    /// Compute work ranges for the given thread count.
    fn compute_ranges(
        &self,
        request: &PartitionRequest,
        num_threads: usize,
    ) -> (PartitionStrategy, Vec<WorkRange>) {
        match request.partition_dim {
            PartitionDimension::Rows(rows) => {
                self.partition_by_rows(rows, num_threads, request.element_size)
            }
            PartitionDimension::Tiles(tiles) => self.partition_by_tiles(tiles, num_threads),
            PartitionDimension::WinogradTiles(tiles) => {
                self.partition_winograd_tiles(tiles, num_threads)
            }
            PartitionDimension::OutputChannels(channels) => {
                self.partition_by_channels(channels, num_threads)
            }
            PartitionDimension::WorkItems(items) => self.partition_generic(items, num_threads),
        }
    }

    /// Partition by rows with optional cache line alignment.
    fn partition_by_rows(
        &self,
        rows: usize,
        num_threads: usize,
        element_size: usize,
    ) -> (PartitionStrategy, Vec<WorkRange>) {
        let base_rows_per_thread = rows / num_threads;
        let mut rows_per_thread = base_rows_per_thread;

        // Align to cache line if requested
        if self.cache_align && element_size > 0 {
            let elements_per_line = CACHE_LINE_SIZE / element_size;
            if elements_per_line > 0 && rows_per_thread > elements_per_line {
                rows_per_thread = (rows_per_thread / elements_per_line) * elements_per_line;
                if rows_per_thread == 0 {
                    rows_per_thread = base_rows_per_thread;
                }
            }
        }

        let mut ranges = Vec::with_capacity(num_threads);
        let mut start = 0;

        for thread_id in 0..num_threads {
            let end = if thread_id == num_threads - 1 {
                rows // Last thread takes remainder
            } else {
                (start + rows_per_thread).min(rows)
            };

            ranges.push(WorkRange {
                thread_id,
                start,
                end,
            });

            start = end;
        }

        let strategy = PartitionStrategy::BlockRows { rows_per_thread };
        (strategy, ranges)
    }

    /// Partition by tiles (for tiled operations).
    fn partition_by_tiles(
        &self,
        tiles: usize,
        num_threads: usize,
    ) -> (PartitionStrategy, Vec<WorkRange>) {
        let tiles_per_thread = tiles.div_ceil(num_threads);

        let ranges: Vec<WorkRange> = (0..num_threads)
            .map(|thread_id| {
                let start = thread_id * tiles_per_thread;
                let end = ((thread_id + 1) * tiles_per_thread).min(tiles);
                WorkRange {
                    thread_id,
                    start,
                    end,
                }
            })
            .filter(|r| r.start < r.end)
            .collect();

        let strategy = PartitionStrategy::BlockTiles { tiles_per_thread };
        (strategy, ranges)
    }

    /// Partition Winograd tiles for balanced load.
    fn partition_winograd_tiles(
        &self,
        tiles: usize,
        num_threads: usize,
    ) -> (PartitionStrategy, Vec<WorkRange>) {
        // Winograd tiles have uniform work, partition evenly
        let tiles_per_thread = tiles.div_ceil(num_threads);

        let ranges: Vec<WorkRange> = (0..num_threads)
            .map(|thread_id| {
                let start = thread_id * tiles_per_thread;
                let end = ((thread_id + 1) * tiles_per_thread).min(tiles);
                WorkRange {
                    thread_id,
                    start,
                    end,
                }
            })
            .filter(|r| r.start < r.end)
            .collect();

        let strategy = PartitionStrategy::WinogradTiles {
            tiles_per_thread,
            total_tiles: tiles,
        };
        (strategy, ranges)
    }

    /// Partition by output channels.
    fn partition_by_channels(
        &self,
        channels: usize,
        num_threads: usize,
    ) -> (PartitionStrategy, Vec<WorkRange>) {
        let channels_per_thread = channels.div_ceil(num_threads);

        let ranges: Vec<WorkRange> = (0..num_threads)
            .map(|thread_id| {
                let start = thread_id * channels_per_thread;
                let end = ((thread_id + 1) * channels_per_thread).min(channels);
                WorkRange {
                    thread_id,
                    start,
                    end,
                }
            })
            .filter(|r| r.start < r.end)
            .collect();

        // Use BlockTiles strategy for channels
        let strategy = PartitionStrategy::BlockTiles {
            tiles_per_thread: channels_per_thread,
        };
        (strategy, ranges)
    }

    /// Generic partition for arbitrary work items.
    fn partition_generic(
        &self,
        items: usize,
        num_threads: usize,
    ) -> (PartitionStrategy, Vec<WorkRange>) {
        let items_per_thread = items.div_ceil(num_threads);

        let ranges: Vec<WorkRange> = (0..num_threads)
            .map(|thread_id| {
                let start = thread_id * items_per_thread;
                let end = ((thread_id + 1) * items_per_thread).min(items);
                WorkRange {
                    thread_id,
                    start,
                    end,
                }
            })
            .filter(|r| r.start < r.end)
            .collect();

        let strategy = PartitionStrategy::BlockRows {
            rows_per_thread: items_per_thread,
        };
        (strategy, ranges)
    }

    /// Compute partition for a fused operation region.
    ///
    /// Fusion regions share a thread partition to prevent nested parallelism.
    pub fn compute_fused_partition(&self, requests: &[PartitionRequest]) -> ThreadPartition {
        if requests.is_empty() {
            return ThreadPartition::sequential();
        }

        // Use the dominant (largest) operation for partitioning
        let dominant = requests.iter().max_by_key(|r| r.total_work).unwrap();

        // Limit threads for fused regions to reduce synchronization overhead
        let fused_max_threads = (self.max_threads / 2).max(1);
        let partitioner = Self::new(fused_max_threads);

        partitioner.compute_partition(dominant)
    }
}

impl Default for ThreadPartitioner {
    fn default() -> Self {
        Self::auto()
    }
}

/// Helper for computing partitions for common operations.
pub struct PartitionBuilder {
    partitioner: ThreadPartitioner,
}

impl PartitionBuilder {
    /// Create a new partition builder.
    pub fn new() -> Self {
        Self {
            partitioner: ThreadPartitioner::auto(),
        }
    }

    /// Create with specific thread count.
    pub fn with_threads(num_threads: usize) -> Self {
        Self {
            partitioner: ThreadPartitioner::new(num_threads),
        }
    }

    /// Compute partition for MatMul.
    pub fn for_matmul(&self, m: usize, k: usize, n: usize) -> ThreadPartition {
        let request = PartitionRequest::matmul(m, k, n);
        self.partitioner.compute_partition(&request)
    }

    /// Compute partition for Conv2D.
    pub fn for_conv2d(
        &self,
        out_h: usize,
        out_w: usize,
        filters: usize,
        kernel_size: usize,
        channels: usize,
    ) -> ThreadPartition {
        let request = PartitionRequest::conv2d(out_h, out_w, filters, kernel_size, channels);
        self.partitioner.compute_partition(&request)
    }

    /// Compute partition for Winograd.
    pub fn for_winograd(&self, tiles_h: usize, tiles_w: usize, filters: usize) -> ThreadPartition {
        let request = PartitionRequest::winograd(tiles_h, tiles_w, filters);
        self.partitioner.compute_partition(&request)
    }
}

impl Default for PartitionBuilder {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_partitioner_new() {
        let partitioner = ThreadPartitioner::new(8);
        assert_eq!(partitioner.max_threads, 8);
    }

    #[test]
    fn test_partitioner_auto() {
        let partitioner = ThreadPartitioner::auto();
        assert!(partitioner.max_threads >= 1);
    }

    #[test]
    fn test_sequential_for_small_work() {
        let partitioner = ThreadPartitioner::new(8);
        let request = PartitionRequest::generic(100, 1); // Only 100 items

        let partition = partitioner.compute_partition(&request);

        assert_eq!(partition.num_threads, 1);
        assert!(matches!(
            partition.strategy,
            Some(PartitionStrategy::Sequential)
        ));
    }

    #[test]
    fn test_parallel_for_large_work() {
        let partitioner = ThreadPartitioner::new(4);
        let request = PartitionRequest::matmul(1024, 1024, 1024);

        let partition = partitioner.compute_partition(&request);

        assert!(partition.num_threads > 1);
        assert!(!partition.work_ranges.is_empty());
    }

    #[test]
    fn test_work_ranges_cover_all() {
        let partitioner = ThreadPartitioner::new(4).with_cache_align(false);
        let request = PartitionRequest::matmul(100, 100, 100);

        let partition = partitioner.compute_partition(&request);

        if partition.num_threads > 1 {
            // Verify ranges cover all rows
            let total_covered: usize = partition.work_ranges.iter().map(|r| r.end - r.start).sum();

            // For rows = 100, partitioned by rows
            assert!(total_covered <= 100);

            // Verify no gaps
            let mut last_end = 0;
            for range in &partition.work_ranges {
                assert_eq!(range.start, last_end);
                last_end = range.end;
            }
        }
    }

    #[test]
    fn test_partition_request_matmul() {
        let request = PartitionRequest::matmul(64, 64, 64);

        assert_eq!(request.total_work, 64 * 64 * 64);
        assert!(matches!(
            request.partition_dim,
            PartitionDimension::Rows(64)
        ));
    }

    #[test]
    fn test_partition_request_conv2d() {
        let request = PartitionRequest::conv2d(32, 32, 64, 3, 128);

        assert_eq!(request.total_work, 32 * 32 * 64);
        assert!(matches!(
            request.partition_dim,
            PartitionDimension::OutputChannels(64)
        ));
    }

    #[test]
    fn test_partition_request_winograd() {
        let request = PartitionRequest::winograd(16, 16, 64);

        assert_eq!(request.total_work, 256 * 64);
        assert!(matches!(
            request.partition_dim,
            PartitionDimension::WinogradTiles(256)
        ));
    }

    #[test]
    fn test_memory_bound_limits_threads() {
        let partitioner = ThreadPartitioner::new(16);

        // Memory-bound operation
        let request = PartitionRequest {
            total_work: 1_000_000,
            partition_dim: PartitionDimension::Rows(1000),
            element_size: 4,
            flops_per_item: 100,
            memory_bound: true,
        };

        let partition = partitioner.compute_partition(&request);

        // Should limit to 4 threads for memory-bound ops
        assert!(partition.num_threads <= 4);
    }

    #[test]
    fn test_cache_alignment() {
        let partitioner = ThreadPartitioner::new(4).with_cache_align(true);
        let request = PartitionRequest::matmul(1024, 1024, 1024);

        let partition = partitioner.compute_partition(&request);

        if partition.num_threads > 1 {
            // All ranges except the last should be cache-aligned
            for range in partition
                .work_ranges
                .iter()
                .take(partition.work_ranges.len() - 1)
            {
                let size = range.end - range.start;
                // Size should be divisible by elements per cache line (16 for f32)
                // or at least > 0
                assert!(size > 0);
            }
        }
    }

    #[test]
    fn test_fused_partition() {
        let partitioner = ThreadPartitioner::new(8);

        let requests = vec![
            PartitionRequest::matmul(1024, 1024, 1024),
            PartitionRequest::generic(1024, 10),
        ];

        let partition = partitioner.compute_fused_partition(&requests);

        // Should use fewer threads for fused regions
        assert!(partition.num_threads <= 4);
    }

    #[test]
    fn test_partition_builder() {
        let builder = PartitionBuilder::with_threads(4);

        let partition = builder.for_matmul(1024, 1024, 1024);
        assert!(partition.num_threads <= 4);

        let partition = builder.for_conv2d(56, 56, 256, 3, 64);
        assert!(partition.num_threads <= 4);

        let partition = builder.for_winograd(32, 32, 128);
        assert!(partition.num_threads <= 4);
    }

    #[test]
    fn test_thread_ids_sequential() {
        let partitioner = ThreadPartitioner::new(4).with_cache_align(false);
        let request = PartitionRequest::matmul(1024, 1024, 1024);

        let partition = partitioner.compute_partition(&request);

        for (i, range) in partition.work_ranges.iter().enumerate() {
            assert_eq!(range.thread_id, i);
        }
    }

    #[test]
    fn test_winograd_tiles_partition() {
        let partitioner = ThreadPartitioner::new(4);
        let request = PartitionRequest::winograd(32, 32, 64);

        let partition = partitioner.compute_partition(&request);

        if partition.num_threads > 1 {
            assert!(matches!(
                partition.strategy,
                Some(PartitionStrategy::WinogradTiles { .. })
            ));
        }
    }

    #[test]
    fn test_with_min_work() {
        let partitioner = ThreadPartitioner::new(8).with_min_work(100_000);

        // Small work should still be sequential with high threshold
        let request = PartitionRequest::generic(1000, 10);
        let partition = partitioner.compute_partition(&request);

        assert_eq!(partition.num_threads, 1);
    }

    #[test]
    fn test_default_partition_builder() {
        let builder = PartitionBuilder::default();
        let partition = builder.for_matmul(64, 64, 64);

        // Should work without panicking
        assert!(partition.num_threads >= 1);
    }
}
