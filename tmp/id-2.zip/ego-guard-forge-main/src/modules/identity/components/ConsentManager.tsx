/**
 * ConsentManager — Privacy consent controls with sovereignty edge indicators.
 */

import { Eye, EyeOff, Clock, Check, X, Shield } from "lucide-react";
import type { PrivacyConsent, ConsentStatus, SovereigntySurface } from "../types";
import { edgeCountForDataCategory, DATA_CATEGORY_EDGE_MAP } from "../engine";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface Props {
  readonly consents: readonly PrivacyConsent[];
  readonly surface: SovereigntySurface;
  readonly onUpdate: (id: string, status: "granted" | "denied") => void;
}

const STATUS_ICON: Record<ConsentStatus, typeof Check> = {
  granted: Check,
  denied: X,
  pending: Clock,
  expired: Clock,
};

const STATUS_STYLE: Record<ConsentStatus, string> = {
  granted: "text-primary",
  denied: "text-destructive",
  pending: "text-gold-muted",
  expired: "text-text-dim",
};

export default function ConsentManager({ consents, surface, onUpdate }: Props) {
  return (
    <div className="rounded-lg border border-border bg-card p-6 animate-fade-in" style={{ animationDelay: "0.3s" }}>
      <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
        Data Consent
      </h3>

      <div className="space-y-3">
        {consents.map((consent) => {
          const StatusIcon = STATUS_ICON[consent.status];
          const affectedEdges = edgeCountForDataCategory(surface, consent.category);
          return (
            <div key={consent.id} className="rounded-md bg-muted p-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-xs px-1.5 py-0.5 rounded bg-accent/30 text-accent-foreground font-mono capitalize">
                      {consent.category}
                    </span>
                    <span className={`flex items-center gap-1 text-xs ${STATUS_STYLE[consent.status]}`}>
                      <StatusIcon className="h-3 w-3" />
                      {consent.status}
                    </span>
                    {affectedEdges > 0 && (
                      <TooltipProvider delayDuration={200}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                             <span className="flex items-center gap-1 text-[10px] text-muted-foreground bg-muted-foreground/10 px-1.5 py-0.5 rounded-full cursor-help">
                              <Shield className="h-2.5 w-2.5" />
                              {affectedEdges} data point{affectedEdges !== 1 ? "s" : ""}
                            </span>
                          </TooltipTrigger>
                          <TooltipContent side="bottom" className="text-xs">
                            <p className="font-semibold mb-1">Affected dimensions:</p>
                            <p className="capitalize">
                              {(DATA_CATEGORY_EDGE_MAP[consent.category] ?? []).join(" · ")}
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    )}
                  </div>
                  <p className="text-sm text-foreground">{consent.purpose}</p>
                </div>

                <div className="flex gap-1 shrink-0">
                  <button
                    onClick={() => onUpdate(consent.id, "granted")}
                    className={`p-1.5 rounded transition-colors ${
                      consent.status === "granted"
                        ? "bg-primary/20 text-primary"
                        : "hover:bg-primary/10 text-text-dim"
                    }`}
                    title="Grant"
                  >
                    <Eye className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => onUpdate(consent.id, "denied")}
                    className={`p-1.5 rounded transition-colors ${
                      consent.status === "denied"
                        ? "bg-destructive/20 text-destructive"
                        : "hover:bg-destructive/10 text-text-dim"
                    }`}
                    title="Deny"
                  >
                    <EyeOff className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}