//! Encrypted constant provider wrapper.
//!
//! This wrapper decrypts data on demand using a simple XOR mask and caches the
//! decrypted chunks. It keeps the zero-copy surface area while avoiding
//! materializing full buffers.

use crate::core::const_provider::{ConstChunk, ConstProvider};
use crate::error::{BackendError, BackendResult};
use std::collections::{HashMap, VecDeque};
use std::sync::{Arc, Mutex};

struct LruCache {
    map: HashMap<usize, Arc<Vec<u8>>>,
    order: VecDeque<usize>,
    bytes: usize,
    cap: usize,
}

impl LruCache {
    fn new(cap: usize) -> Self {
        Self {
            map: HashMap::new(),
            order: VecDeque::new(),
            bytes: 0,
            cap,
        }
    }

    fn get(&mut self, key: usize) -> Option<Arc<Vec<u8>>> {
        if let Some(val) = self.map.get(&key) {
            self.order.retain(|k| *k != key);
            self.order.push_back(key);
            return Some(val.clone());
        }
        None
    }

    fn insert(&mut self, key: usize, val: Arc<Vec<u8>>) {
        if self.map.contains_key(&key) {
            return;
        }
        self.bytes = self.bytes.saturating_add(val.len());
        self.order.push_back(key);
        self.map.insert(key, val);
        while self.bytes > self.cap {
            if let Some(evict) = self.order.pop_front() {
                if let Some(v) = self.map.remove(&evict) {
                    self.bytes = self.bytes.saturating_sub(v.len());
                }
            } else {
                break;
            }
        }
    }
}

/// XOR-decrypting provider that wraps another provider.
pub struct XorEncryptedConstProvider<P: ConstProvider> {
    inner: P,
    key: Arc<Vec<u8>>,
    chunk_size: usize,
    cache: Mutex<LruCache>,
}

impl<P: ConstProvider> XorEncryptedConstProvider<P> {
    /// Create a new encrypted provider. `key` should be a non-empty byte mask.
    pub fn new(
        inner: P,
        key: Vec<u8>,
        chunk_size: usize,
        max_cached_bytes: usize,
    ) -> BackendResult<Self> {
        if key.is_empty() {
            return Err(BackendError::buffer("encryption key must not be empty"));
        }
        let chunk = chunk_size.max(4096);
        let cache_cap = max_cached_bytes.max(chunk);
        Ok(Self {
            inner,
            key: Arc::new(key),
            chunk_size: chunk,
            cache: Mutex::new(LruCache::new(cache_cap)),
        })
    }

    fn decrypt_chunk(&self, chunk_start: usize) -> BackendResult<Arc<Vec<u8>>> {
        let remaining = self
            .len()
            .checked_sub(chunk_start)
            .ok_or_else(|| BackendError::buffer("offset past end of encrypted source"))?;
        let want = remaining.min(self.chunk_size);
        let data = self.inner.read_at(chunk_start, want)?;
        let mut out = Vec::with_capacity(want);
        for (i, byte) in data.data.iter().enumerate() {
            let key_byte = self.key[i % self.key.len()];
            out.push(byte ^ key_byte);
        }
        Ok(Arc::new(out))
    }
}

impl<P: ConstProvider> ConstProvider for XorEncryptedConstProvider<P> {
    fn len(&self) -> usize {
        self.inner.len()
    }

    fn read_at<'a>(&'a self, offset: usize, len: usize) -> BackendResult<ConstChunk<'a>> {
        if len > self.chunk_size {
            return Err(BackendError::buffer(format!(
                "XorEncryptedConstProvider request too large: {} > chunk_size {}",
                len, self.chunk_size
            )));
        }
        let chunk_start = (offset / self.chunk_size) * self.chunk_size;
        {
            let mut cache = self.cache.lock().expect("encrypted cache poisoned");
            if cache.get(chunk_start).is_none() {
                drop(cache);
                let fresh = self.decrypt_chunk(chunk_start)?;
                let mut cache = self.cache.lock().expect("encrypted cache poisoned");
                cache.insert(chunk_start, fresh);
            }
        }
        let entry = {
            let mut cache = self.cache.lock().expect("encrypted cache poisoned");
            cache
                .get(chunk_start)
                .ok_or_else(|| BackendError::buffer("missing decrypted chunk"))?
        };
        let local_offset = offset - chunk_start;
        let end = local_offset
            .checked_add(len)
            .ok_or_else(|| BackendError::buffer("offset overflow"))?;
        if end > entry.len() {
            return Err(BackendError::buffer("decrypted chunk slice out of bounds"));
        }
        let ptr = unsafe { entry.as_ptr().add(local_offset) };
        let data = unsafe { std::slice::from_raw_parts(ptr, len) };
        Ok(ConstChunk { data })
    }
}
