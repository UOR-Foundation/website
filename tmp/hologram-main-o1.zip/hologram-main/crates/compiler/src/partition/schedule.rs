//! Parallel level scheduling.
//!
//! This module builds parallel execution levels from a dependency graph.
//! Nodes within the same level have no dependencies on each other and
//! can execute concurrently.

use crate::pipeline::ParallelLevel;
use std::collections::{HashMap, HashSet, VecDeque};

/// Build parallel levels from a dependency graph.
///
/// Uses a modified topological sort to group nodes into levels where:
/// - Level 0 contains nodes with no dependencies
/// - Level N contains nodes whose dependencies are all in levels < N
/// - Nodes within a level can execute in parallel
///
/// # Arguments
///
/// * `node_ids` - All node IDs in the graph
/// * `edges` - Directed edges as (source, target) pairs
///
/// # Returns
///
/// A vector of parallel levels, ordered from first to last execution.
#[must_use]
pub fn build_parallel_levels(node_ids: &[u32], edges: &[(u32, u32)]) -> Vec<ParallelLevel> {
    if node_ids.is_empty() {
        return Vec::new();
    }

    // Build adjacency lists and compute in-degrees
    let mut in_degree: HashMap<u32, usize> = node_ids.iter().map(|&id| (id, 0)).collect();
    let mut successors: HashMap<u32, Vec<u32>> =
        node_ids.iter().map(|&id| (id, Vec::new())).collect();

    for &(src, dst) in edges {
        if let Some(degree) = in_degree.get_mut(&dst) {
            *degree += 1;
        }
        if let Some(succs) = successors.get_mut(&src) {
            succs.push(dst);
        }
    }

    // BFS-style level assignment
    let mut levels = Vec::new();
    let mut remaining: HashSet<u32> = node_ids.iter().copied().collect();

    while !remaining.is_empty() {
        // Find all nodes with in-degree 0 among remaining nodes
        let ready: Vec<u32> = remaining
            .iter()
            .filter(|&&id| in_degree.get(&id).copied().unwrap_or(0) == 0)
            .copied()
            .collect();

        if ready.is_empty() {
            // No progress possible - cycle detected or invalid graph
            break;
        }

        // Add this level
        levels.push(ParallelLevel {
            node_ids: ready.clone(),
        });

        // Remove ready nodes and update in-degrees
        for id in &ready {
            remaining.remove(id);
            if let Some(succs) = successors.get(id) {
                for &succ in succs {
                    if let Some(degree) = in_degree.get_mut(&succ) {
                        *degree = degree.saturating_sub(1);
                    }
                }
            }
        }
    }

    levels
}

/// Compute the critical path length through the DAG.
///
/// The critical path is the longest chain of dependent operations.
/// This determines the minimum execution time regardless of parallelism.
#[must_use]
pub fn critical_path_length(node_ids: &[u32], edges: &[(u32, u32)]) -> usize {
    if node_ids.is_empty() {
        return 0;
    }

    // Build predecessor lists
    let mut predecessors: HashMap<u32, Vec<u32>> =
        node_ids.iter().map(|&id| (id, Vec::new())).collect();
    let mut in_degree: HashMap<u32, usize> = node_ids.iter().map(|&id| (id, 0)).collect();

    for &(src, dst) in edges {
        if let Some(preds) = predecessors.get_mut(&dst) {
            preds.push(src);
        }
        if let Some(degree) = in_degree.get_mut(&dst) {
            *degree += 1;
        }
    }

    // Compute longest path to each node using dynamic programming
    let mut longest_path: HashMap<u32, usize> = HashMap::new();
    let mut queue: VecDeque<u32> = node_ids
        .iter()
        .filter(|&&id| in_degree.get(&id).copied().unwrap_or(0) == 0)
        .copied()
        .collect();

    // Initialize source nodes with path length 1
    for &id in &queue {
        longest_path.insert(id, 1);
    }

    // Process in topological order
    let mut remaining_in_degree = in_degree.clone();
    while let Some(id) = queue.pop_front() {
        let current_len = longest_path.get(&id).copied().unwrap_or(1);

        // Update successors
        for &(src, dst) in edges {
            if src == id {
                let new_len = current_len + 1;
                let entry = longest_path.entry(dst).or_insert(0);
                *entry = (*entry).max(new_len);

                // Decrement in-degree and add to queue if ready
                if let Some(degree) = remaining_in_degree.get_mut(&dst) {
                    *degree = degree.saturating_sub(1);
                    if *degree == 0 {
                        queue.push_back(dst);
                    }
                }
            }
        }
    }

    longest_path.values().copied().max().unwrap_or(0)
}

/// Estimate parallelism as the ratio of total work to critical path.
///
/// A value of 1.0 means no parallelism (linear chain).
/// Higher values indicate more opportunity for parallel execution.
#[must_use]
pub fn parallelism_ratio(node_ids: &[u32], edges: &[(u32, u32)]) -> f64 {
    let total_nodes = node_ids.len();
    let critical_len = critical_path_length(node_ids, edges);

    if critical_len == 0 {
        return 0.0;
    }

    #[allow(clippy::cast_precision_loss)]
    {
        total_nodes as f64 / critical_len as f64
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_build_parallel_levels_empty() {
        let levels = build_parallel_levels(&[], &[]);
        assert!(levels.is_empty());
    }

    #[test]
    fn test_build_parallel_levels_single_node() {
        let levels = build_parallel_levels(&[0], &[]);
        assert_eq!(levels.len(), 1);
        assert_eq!(levels[0].node_ids, vec![0]);
    }

    #[test]
    fn test_build_parallel_levels_linear_chain() {
        // 0 -> 1 -> 2 -> 3
        let nodes = vec![0, 1, 2, 3];
        let edges = vec![(0, 1), (1, 2), (2, 3)];

        let levels = build_parallel_levels(&nodes, &edges);

        // Each node should be in its own level
        assert_eq!(levels.len(), 4);
        assert_eq!(levels[0].node_ids, vec![0]);
        assert_eq!(levels[1].node_ids, vec![1]);
        assert_eq!(levels[2].node_ids, vec![2]);
        assert_eq!(levels[3].node_ids, vec![3]);
    }

    #[test]
    fn test_build_parallel_levels_parallel_nodes() {
        // 0 -> [1, 2, 3] -> 4
        let nodes = vec![0, 1, 2, 3, 4];
        let edges = vec![(0, 1), (0, 2), (0, 3), (1, 4), (2, 4), (3, 4)];

        let levels = build_parallel_levels(&nodes, &edges);

        assert_eq!(levels.len(), 3);
        assert_eq!(levels[0].node_ids, vec![0]);
        // Level 1 should have nodes 1, 2, 3 in some order
        assert_eq!(levels[1].node_ids.len(), 3);
        assert!(levels[1].node_ids.contains(&1));
        assert!(levels[1].node_ids.contains(&2));
        assert!(levels[1].node_ids.contains(&3));
        assert_eq!(levels[2].node_ids, vec![4]);
    }

    #[test]
    fn test_build_parallel_levels_diamond() {
        //     0
        //    / \
        //   1   2
        //    \ /
        //     3
        let nodes = vec![0, 1, 2, 3];
        let edges = vec![(0, 1), (0, 2), (1, 3), (2, 3)];

        let levels = build_parallel_levels(&nodes, &edges);

        assert_eq!(levels.len(), 3);
        assert_eq!(levels[0].node_ids, vec![0]);
        assert_eq!(levels[1].node_ids.len(), 2);
        assert!(levels[1].node_ids.contains(&1));
        assert!(levels[1].node_ids.contains(&2));
        assert_eq!(levels[2].node_ids, vec![3]);
    }

    #[test]
    fn test_build_parallel_levels_multiple_sources() {
        // [0, 1] -> 2
        let nodes = vec![0, 1, 2];
        let edges = vec![(0, 2), (1, 2)];

        let levels = build_parallel_levels(&nodes, &edges);

        assert_eq!(levels.len(), 2);
        // Level 0 should have both 0 and 1
        assert_eq!(levels[0].node_ids.len(), 2);
        assert!(levels[0].node_ids.contains(&0));
        assert!(levels[0].node_ids.contains(&1));
        assert_eq!(levels[1].node_ids, vec![2]);
    }

    #[test]
    fn test_build_parallel_levels_complex_dag() {
        //     0
        //    /|\
        //   1 2 3
        //   |/| |
        //   4 5 |
        //    \|/
        //     6
        let nodes = vec![0, 1, 2, 3, 4, 5, 6];
        let edges = vec![
            (0, 1),
            (0, 2),
            (0, 3),
            (1, 4),
            (2, 4),
            (2, 5),
            (3, 6),
            (4, 6),
            (5, 6),
        ];

        let levels = build_parallel_levels(&nodes, &edges);

        // Level 0: [0]
        // Level 1: [1, 2, 3]
        // Level 2: [4, 5]
        // Level 3: [6]
        assert_eq!(levels.len(), 4);
        assert_eq!(levels[0].node_ids, vec![0]);
        assert_eq!(levels[1].node_ids.len(), 3);
        assert_eq!(levels[2].node_ids.len(), 2);
        assert_eq!(levels[3].node_ids, vec![6]);
    }

    #[test]
    fn test_critical_path_empty() {
        assert_eq!(critical_path_length(&[], &[]), 0);
    }

    #[test]
    fn test_critical_path_single_node() {
        assert_eq!(critical_path_length(&[0], &[]), 1);
    }

    #[test]
    fn test_critical_path_linear_chain() {
        // 0 -> 1 -> 2 -> 3
        let nodes = vec![0, 1, 2, 3];
        let edges = vec![(0, 1), (1, 2), (2, 3)];
        assert_eq!(critical_path_length(&nodes, &edges), 4);
    }

    #[test]
    fn test_critical_path_parallel() {
        // 0 -> [1, 2, 3] -> 4
        let nodes = vec![0, 1, 2, 3, 4];
        let edges = vec![(0, 1), (0, 2), (0, 3), (1, 4), (2, 4), (3, 4)];
        // Critical path: 0 -> 1 -> 4 (or any of the middle nodes)
        assert_eq!(critical_path_length(&nodes, &edges), 3);
    }

    #[test]
    fn test_parallelism_ratio_linear() {
        let nodes = vec![0, 1, 2, 3];
        let edges = vec![(0, 1), (1, 2), (2, 3)];
        let ratio = parallelism_ratio(&nodes, &edges);
        assert!((ratio - 1.0).abs() < 0.01); // Should be ~1.0 for linear
    }

    #[test]
    fn test_parallelism_ratio_parallel() {
        // 0 -> [1, 2, 3] -> 4
        let nodes = vec![0, 1, 2, 3, 4];
        let edges = vec![(0, 1), (0, 2), (0, 3), (1, 4), (2, 4), (3, 4)];
        let ratio = parallelism_ratio(&nodes, &edges);
        // 5 nodes, critical path = 3, ratio = 5/3 ≈ 1.67
        assert!(ratio > 1.5);
    }
}
