//! Compilation throughput benchmarks.
//!
//! Performance targets:
//! - `compile_small_graph` (10 nodes): < 1ms
//! - `compile_large_graph` (1000 nodes): < 100ms
//! - Individual pass benchmarks for profiling

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use hologram_backend::backends::cpu::CpuBackend;
use hologram_backend::Backend;
use hologram_compiler::{
    compile, convert_ir, validate_graph, CompilerConfig, ConstantData, DType, OpKind, OpNode,
    OperationGraph,
};

/// Create a linear chain graph with N nodes.
/// Structure: Input -> Op1 -> Op2 -> ... -> OpN -> Output
fn make_linear_chain(n: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();

    // Input node
    graph.add_node(OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32));

    // Middle nodes (alternating Relu/Sigmoid)
    for i in 1..n - 1 {
        let op = if i % 2 == 1 {
            OpKind::Relu
        } else {
            OpKind::Sigmoid
        };
        #[allow(clippy::cast_possible_truncation)]
        graph.add_node(OpNode::new(i as u32, op, vec![64, 64], DType::F32));
        #[allow(clippy::cast_possible_truncation)]
        graph.add_edge((i - 1) as u32, i as u32);
    }

    // Output node
    #[allow(clippy::cast_possible_truncation)]
    let out_id = (n - 1) as u32;
    graph.add_node(OpNode::new(
        out_id,
        OpKind::Output,
        vec![64, 64],
        DType::F32,
    ));
    #[allow(clippy::cast_possible_truncation)]
    graph.add_edge((n - 2) as u32, out_id);

    graph
}

/// Create a wide parallel graph with N parallel branches.
/// Structure: Input -> [Branch1, Branch2, ..., BranchN] -> Add -> Output
fn make_parallel_graph(branches: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();

    // Input node
    graph.add_node(OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32));

    // Parallel branches (each is Relu)
    for i in 0..branches {
        #[allow(clippy::cast_possible_truncation)]
        let id = (i + 1) as u32;
        graph.add_node(OpNode::new(id, OpKind::Relu, vec![64, 64], DType::F32));
        graph.add_edge(0, id);
    }

    // Merge node (Add)
    #[allow(clippy::cast_possible_truncation)]
    let merge_id = (branches + 1) as u32;
    graph.add_node(OpNode::new(merge_id, OpKind::Add, vec![64, 64], DType::F32));
    for i in 0..branches {
        #[allow(clippy::cast_possible_truncation)]
        graph.add_edge((i + 1) as u32, merge_id);
    }

    // Output node
    let out_id = merge_id + 1;
    graph.add_node(OpNode::new(
        out_id,
        OpKind::Output,
        vec![64, 64],
        DType::F32,
    ));
    graph.add_edge(merge_id, out_id);

    graph
}

/// Create a graph with `MatMul` operations.
fn make_matmul_chain(n: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();
    let mut node_id = 0u32;

    // First two inputs for the first MatMul
    graph.add_node(OpNode::new(
        node_id,
        OpKind::Input,
        vec![64, 128],
        DType::F32,
    ));
    node_id += 1;
    graph.add_node(OpNode::new(
        node_id,
        OpKind::Input,
        vec![128, 64],
        DType::F32,
    ));
    node_id += 1;

    // Chain of MatMuls
    for i in 0..n {
        let m = 64;
        let k = if i == 0 { 128 } else { 64 };
        let n_dim = 64;

        graph.add_node(OpNode::new(
            node_id,
            OpKind::MatMul { m, k, n: n_dim },
            vec![m, n_dim],
            DType::F32,
        ));

        if i == 0 {
            graph.add_edge(0, node_id);
            graph.add_edge(1, node_id);
        } else {
            graph.add_edge(node_id - 1, node_id);
            // Need another input for the second operand
            let input_id = node_id + 1;
            graph.add_node(OpNode::new(
                input_id,
                OpKind::Input,
                vec![64, 64],
                DType::F32,
            ));
            graph.add_edge(input_id, node_id);
            node_id = input_id;
        }
        node_id += 1;
    }

    // Output
    graph.add_node(OpNode::new(
        node_id,
        OpKind::Output,
        vec![64, 64],
        DType::F32,
    ));
    graph.add_edge(node_id - 1, node_id);

    graph
}

fn bench_compile_empty_graph(c: &mut Criterion) {
    let graph = OperationGraph::new();
    let config = CompilerConfig::default();

    c.bench_function("compile_empty_graph", |b| {
        b.iter(|| compile(black_box(&graph), black_box(&config)));
    });
}

fn bench_compile_small_graph(c: &mut Criterion) {
    let mut group = c.benchmark_group("compile_small");
    group.throughput(Throughput::Elements(10));

    let graph = make_linear_chain(10);
    let config = CompilerConfig::default();

    group.bench_function("10_nodes", |b| {
        b.iter(|| compile(black_box(&graph), black_box(&config)));
    });

    group.finish();
}

fn bench_compile_medium_graph(c: &mut Criterion) {
    let mut group = c.benchmark_group("compile_medium");
    group.throughput(Throughput::Elements(100));

    let graph = make_linear_chain(100);
    let config = CompilerConfig::default();

    group.bench_function("100_nodes", |b| {
        b.iter(|| compile(black_box(&graph), black_box(&config)));
    });

    group.finish();
}

fn bench_compile_large_graph(c: &mut Criterion) {
    let mut group = c.benchmark_group("compile_large");
    group.throughput(Throughput::Elements(1000));
    group.sample_size(10); // Fewer samples for large graphs

    let graph = make_linear_chain(1000);
    let config = CompilerConfig::default();

    group.bench_function("1000_nodes", |b| {
        b.iter(|| compile(black_box(&graph), black_box(&config)));
    });

    group.finish();
}

fn bench_compile_scaling(c: &mut Criterion) {
    let mut group = c.benchmark_group("compile_scaling");

    for size in [10, 50, 100, 200, 500] {
        let graph = make_linear_chain(size);
        let config = CompilerConfig::default();

        group.throughput(Throughput::Elements(size as u64));
        group.bench_with_input(BenchmarkId::from_parameter(size), &size, |b, _| {
            b.iter(|| compile(black_box(&graph), black_box(&config)));
        });
    }

    group.finish();
}

fn bench_compile_parallel_graph(c: &mut Criterion) {
    let mut group = c.benchmark_group("compile_parallel");

    for branches in [4, 8, 16, 32] {
        let graph = make_parallel_graph(branches);
        let config = CompilerConfig::default();

        group.throughput(Throughput::Elements((branches + 3) as u64));
        group.bench_with_input(BenchmarkId::from_parameter(branches), &branches, |b, _| {
            b.iter(|| compile(black_box(&graph), black_box(&config)));
        });
    }

    group.finish();
}

fn bench_compile_matmul_chain(c: &mut Criterion) {
    let mut group = c.benchmark_group("compile_matmul");

    for matmuls in [1, 2, 4, 8] {
        let graph = make_matmul_chain(matmuls);
        let config = CompilerConfig::default();

        group.bench_with_input(BenchmarkId::from_parameter(matmuls), &matmuls, |b, _| {
            b.iter(|| compile(black_box(&graph), black_box(&config)));
        });
    }

    group.finish();
}

fn bench_individual_passes(c: &mut Criterion) {
    let mut group = c.benchmark_group("individual_passes");

    let graph = make_linear_chain(100);
    let config = CompilerConfig::default();

    // Validation pass
    group.bench_function("validate", |b| {
        b.iter(|| validate_graph(black_box(&graph)));
    });

    // IR conversion pass
    group.bench_function("convert_ir", |b| {
        b.iter(|| convert_ir(black_box(&graph)));
    });

    // Full compilation for comparison
    group.bench_function("full_compile", |b| {
        b.iter(|| compile(black_box(&graph), black_box(&config)));
    });

    group.finish();
}

fn bench_opt_levels(c: &mut Criterion) {
    let mut group = c.benchmark_group("opt_levels");

    let graph = make_linear_chain(100);

    for opt_level in 0..=3 {
        let config = CompilerConfig {
            opt_level,
            ..Default::default()
        };

        group.bench_with_input(
            BenchmarkId::from_parameter(format!("O{opt_level}")),
            &opt_level,
            |b, _| {
                b.iter(|| compile(black_box(&graph), black_box(&config)));
            },
        );
    }

    group.finish();
}

/// Create a graph with broadcasting Add operations.
/// Structure: Input1, Input2 -> Add -> ... (n branches with broadcasting)
fn make_broadcast_graph(n: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();
    let mut node_id = 0u32;

    // For each branch, create [32, 512] + [512] -> [32, 512] pattern
    for i in 0..n {
        let input1_id = node_id;
        let input2_id = node_id + 1;
        let add_id = node_id + 2;

        // Input 1: [32, 512]
        graph.add_node(OpNode::new(
            input1_id,
            OpKind::Input,
            vec![32, 512],
            DType::F32,
        ));
        // Input 2: [512] (broadcasts with [32, 512])
        graph.add_node(OpNode::new(input2_id, OpKind::Input, vec![512], DType::F32));
        // Add with broadcasting
        graph.add_node(OpNode::new(add_id, OpKind::Add, vec![32, 512], DType::F32));

        graph.add_edge(input1_id, add_id);
        graph.add_edge(input2_id, add_id);

        // Connect to output on last iteration
        if i == n - 1 {
            let out_id = add_id + 1;
            graph.add_node(OpNode::new(
                out_id,
                OpKind::Output,
                vec![32, 512],
                DType::F32,
            ));
            graph.add_edge(add_id, out_id);
        }

        node_id += 3;
    }

    graph
}

fn bench_validate_broadcast(c: &mut Criterion) {
    let mut group = c.benchmark_group("validate_broadcast");

    for size in [10, 50, 100] {
        let graph = make_broadcast_graph(size);

        group.throughput(Throughput::Elements(size as u64));
        group.bench_with_input(
            BenchmarkId::from_parameter(format!("{size}_broadcast_ops")),
            &size,
            |b, _| {
                b.iter(|| validate_graph(black_box(&graph)));
            },
        );
    }

    group.finish();
}

/// Create a graph with constant data of specified float count.
/// Structure: Input -> Mul(Constant) -> Add(Constant) -> Output
fn make_constants_graph(floats_per_constant: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();

    // Input node: [floats_per_constant]
    graph.add_node(OpNode::new(
        0,
        OpKind::Input,
        vec![floats_per_constant],
        DType::F32,
    ));
    graph.add_input("input", 0);

    // Weight constant: [floats_per_constant]
    graph.add_node(OpNode::new(
        1,
        OpKind::Constant,
        vec![floats_per_constant],
        DType::F32,
    ));
    let weights: Vec<f32> = (0..floats_per_constant)
        .map(|i| (i as f32) * 0.01)
        .collect();
    graph.add_constant_for_node(1, ConstantData::F32(weights));

    // Bias constant: [floats_per_constant]
    graph.add_node(OpNode::new(
        2,
        OpKind::Constant,
        vec![floats_per_constant],
        DType::F32,
    ));
    let bias: Vec<f32> = (0..floats_per_constant)
        .map(|i| (i as f32) * 0.001)
        .collect();
    graph.add_constant_for_node(2, ConstantData::F32(bias));

    // Mul: input * weights
    graph.add_node(OpNode::new(
        3,
        OpKind::Mul,
        vec![floats_per_constant],
        DType::F32,
    ));
    graph.add_edge(0, 3);
    graph.add_edge(1, 3);

    // Add: mul_result + bias
    graph.add_node(OpNode::new(
        4,
        OpKind::Add,
        vec![floats_per_constant],
        DType::F32,
    ));
    graph.add_edge(3, 4);
    graph.add_edge(2, 4);

    // Output
    graph.add_node(OpNode::new(
        5,
        OpKind::Output,
        vec![floats_per_constant],
        DType::F32,
    ));
    graph.add_edge(4, 5);
    graph.add_output("output", 5);

    graph
}

fn bench_compile_with_constants(c: &mut Criterion) {
    let mut group = c.benchmark_group("compile_constants");

    // Test with various constant sizes: 1K, 64K, 256K floats
    // (4KB, 256KB, 1MB of constant data per constant)
    for (name, floats) in [("1K", 1024), ("64K", 65536), ("256K", 262144)] {
        let graph = make_constants_graph(floats);
        let config = CompilerConfig::default();

        // Throughput in bytes (2 constants * floats * 4 bytes)
        group.throughput(Throughput::Bytes((2 * floats * 4) as u64));
        group.bench_with_input(BenchmarkId::from_parameter(name), &floats, |b, _| {
            b.iter(|| compile(black_box(&graph), black_box(&config)));
        });
    }

    group.finish();
}

/// Benchmark to verify constant data is actually included in plan.
fn bench_constants_in_plan(c: &mut Criterion) {
    let mut group = c.benchmark_group("constants_verification");

    let floats = 65536; // 64K floats = 256KB per constant
    let graph = make_constants_graph(floats);
    let config = CompilerConfig::default();

    group.bench_function("64K_floats_roundtrip", |b| {
        b.iter(|| {
            let plan = compile(black_box(&graph), black_box(&config)).unwrap();
            // Verify constants are properly embedded
            assert!(!plan.constants.is_empty());
            black_box(plan)
        });
    });

    group.finish();
}

// ---------------------------------------------------------------------------
// SHA-256 pipeline benchmarks
// ---------------------------------------------------------------------------

/// SHA-256 graph: Input(80) -> Sha256 -> Output(32).
fn make_sha256_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![80], DType::U8));
    graph.sha256(1, 0, 80);
    graph.add_node(OpNode::new(2, OpKind::Output, vec![32], DType::U8));
    graph.add_edge(1, 2);
    graph.add_input("header", 0);
    graph.add_output("hash", 2);
    graph
}

/// SHA-256 chain graph: Input(80) -> Sha256 -> Sha256 -> Output(32).
fn make_sha256_chain_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![80], DType::U8));
    graph.sha256(1, 0, 80);
    graph.sha256(2, 1, 32);
    graph.add_node(OpNode::new(3, OpKind::Output, vec![32], DType::U8));
    graph.add_edge(2, 3);
    graph.add_input("header", 0);
    graph.add_output("hash", 3);
    graph
}

fn bench_sha256_compile(c: &mut Criterion) {
    let mut group = c.benchmark_group("sha256_compile");
    group.throughput(Throughput::Elements(1));

    let config = CompilerConfig::default();

    group.bench_function("single", |b| {
        let graph = make_sha256_graph();
        b.iter(|| compile(black_box(&graph), black_box(&config)));
    });

    group.bench_function("chain_with_fusion", |b| {
        let graph = make_sha256_chain_graph();
        b.iter(|| compile(black_box(&graph), black_box(&config)));
    });

    group.finish();
}

fn bench_sha256_e2e(c: &mut Criterion) {
    let mut group = c.benchmark_group("sha256_e2e");
    group.throughput(Throughput::Bytes(80));

    let config = CompilerConfig::default();
    let backend = CpuBackend::new();
    let header = [0xABu8; 80];

    group.bench_function("compile_and_execute", |b| {
        let graph = make_sha256_graph();
        b.iter(|| {
            let plan = compile(black_box(&graph), black_box(&config)).unwrap();
            let mut output = [0u8; 32];
            backend
                .execute_plan(&plan, &[&header], &mut [&mut output[..]])
                .unwrap();
            black_box(output)
        });
    });

    group.bench_function("execute_only", |b| {
        let graph = make_sha256_graph();
        let plan = compile(&graph, &config).unwrap();
        b.iter(|| {
            let mut output = [0u8; 32];
            backend
                .execute_plan(black_box(&plan), &[&header], &mut [&mut output[..]])
                .unwrap();
            black_box(output)
        });
    });

    group.finish();
}

criterion_group!(
    benches,
    bench_compile_empty_graph,
    bench_compile_small_graph,
    bench_compile_medium_graph,
    bench_compile_large_graph,
    bench_compile_scaling,
    bench_compile_parallel_graph,
    bench_compile_matmul_chain,
    bench_individual_passes,
    bench_opt_levels,
    bench_validate_broadcast,
    bench_compile_with_constants,
    bench_constants_in_plan,
    bench_sha256_compile,
    bench_sha256_e2e,
);
criterion_main!(benches);
