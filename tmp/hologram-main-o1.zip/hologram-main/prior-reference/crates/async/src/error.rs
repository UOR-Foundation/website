//! Async error types.

use std::fmt;

/// Errors that can occur during async operations.
#[derive(Debug)]
pub enum AsyncError {
    /// Runtime creation failed.
    RuntimeCreation(String),
    /// IO error.
    Io(std::io::Error),
    /// Task join error.
    TaskJoin(String),
    /// Timeout error.
    Timeout,
    /// Other error.
    Other(String),
}

impl fmt::Display for AsyncError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RuntimeCreation(msg) => write!(f, "Runtime creation failed: {}", msg),
            Self::Io(e) => write!(f, "IO error: {}", e),
            Self::TaskJoin(msg) => write!(f, "Task join error: {}", msg),
            Self::Timeout => write!(f, "Operation timed out"),
            Self::Other(msg) => write!(f, "{}", msg),
        }
    }
}

impl std::error::Error for AsyncError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Io(e) => Some(e),
            _ => None,
        }
    }
}

impl From<std::io::Error> for AsyncError {
    fn from(err: std::io::Error) -> Self {
        Self::Io(err)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_error_display() {
        let err = AsyncError::Timeout;
        assert_eq!(format!("{}", err), "Operation timed out");
    }

    #[test]
    fn test_io_conversion() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "not found");
        let err: AsyncError = io_err.into();
        assert!(matches!(err, AsyncError::Io(_)));
    }
}
