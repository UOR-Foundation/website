//! Derivation chain structure.
//!
//! A derivation chain is an ordered sequence of derivation steps that
//! documents how a computation proceeds from input to output.

use serde::{Deserialize, Serialize};

/// A complete derivation chain documenting a computation.
///
/// Each chain has a unique identifier, a label, and a sequence of steps
/// that record the computation's progress.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DerivationChain {
    /// Unique identifier for this derivation (IRI format).
    pub id: String,

    /// Human-readable label.
    pub label: String,

    /// Description of what this derivation proves.
    pub description: String,

    /// The ordered sequence of derivation steps.
    pub steps: Vec<DerivationStep>,

    /// Timestamp when this derivation was created (ISO 8601).
    pub timestamp: String,
}

impl DerivationChain {
    /// Create a new derivation chain.
    pub fn new(id: impl Into<String>, label: impl Into<String>) -> Self {
        Self {
            id: id.into(),
            label: label.into(),
            description: String::new(),
            steps: Vec::new(),
            timestamp: String::new(),
        }
    }

    /// Set the description.
    pub fn with_description(mut self, desc: impl Into<String>) -> Self {
        self.description = desc.into();
        self
    }

    /// Set the timestamp.
    pub fn with_timestamp(mut self, ts: impl Into<String>) -> Self {
        self.timestamp = ts.into();
        self
    }

    /// Add a step to the derivation.
    pub fn add_step(&mut self, step: DerivationStep) {
        self.steps.push(step);
    }

    /// Get the number of steps.
    pub fn step_count(&self) -> usize {
        self.steps.len()
    }
}

/// A single step in a derivation chain.
///
/// Each step documents one operation in the derivation, including
/// its kind, inputs, outputs, and any assertions.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DerivationStep {
    /// Step index (0-based).
    pub index: usize,

    /// Human-readable label for this step.
    pub label: String,

    /// The kind of operation performed.
    pub kind: StepKind,

    /// Input values for this step.
    pub input: serde_json::Value,

    /// Output values from this step.
    pub output: serde_json::Value,

    /// Assertions made at this step (things we claim to be true).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub assertion: Option<String>,

    /// Justification for this step (why it's valid).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub justification: Option<String>,
}

impl DerivationStep {
    /// Create a new derivation step.
    pub fn new(index: usize, label: impl Into<String>, kind: StepKind) -> Self {
        Self {
            index,
            label: label.into(),
            kind,
            input: serde_json::Value::Null,
            output: serde_json::Value::Null,
            assertion: None,
            justification: None,
        }
    }

    /// Set the input.
    pub fn with_input(mut self, input: serde_json::Value) -> Self {
        self.input = input;
        self
    }

    /// Set the output.
    pub fn with_output(mut self, output: serde_json::Value) -> Self {
        self.output = output;
        self
    }

    /// Set an assertion.
    pub fn with_assertion(mut self, assertion: impl Into<String>) -> Self {
        self.assertion = Some(assertion.into());
        self
    }

    /// Set a justification.
    pub fn with_justification(mut self, justification: impl Into<String>) -> Self {
        self.justification = Some(justification.into());
        self
    }
}

/// The kind of operation performed in a derivation step.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum StepKind {
    /// Type declaration (stating what kind of value we have).
    TypeDeclaration,

    /// Quantum level selection (choosing the ring size).
    QuantumSelection,

    /// Step prediction (computing expected steps for factors).
    StepPrediction,

    /// Orbit generation (generating the dihedral orbit).
    OrbitGeneration,

    /// Coordinate reading (reading a factor from coordinates).
    CoordinateReading,

    /// Factor completion (computing the second factor).
    FactorCompletion,

    /// Certificate emission (final proof certificate).
    CertificateEmission,

    /// GCD computation.
    Gcd,

    /// Integer division.
    IntegerDivision,

    /// Generic computation step.
    Compute,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_derivation_chain_creation() {
        let chain = DerivationChain::new(
            "https://uor.foundation/derivation/test/1",
            "Test Derivation",
        )
        .with_description("A test derivation chain")
        .with_timestamp("2026-02-05T00:00:00Z");

        assert_eq!(chain.id, "https://uor.foundation/derivation/test/1");
        assert_eq!(chain.label, "Test Derivation");
        assert_eq!(chain.step_count(), 0);
    }

    #[test]
    fn test_derivation_step_creation() {
        let step = DerivationStep::new(0, "Type Declaration", StepKind::TypeDeclaration)
            .with_input(serde_json::json!({"value": 10403}))
            .with_output(serde_json::json!({"type": "semiprime", "value": 10403}))
            .with_assertion("N is an odd semiprime");

        assert_eq!(step.index, 0);
        assert_eq!(step.kind, StepKind::TypeDeclaration);
        assert!(step.assertion.is_some());
    }

    #[test]
    fn test_add_steps_to_chain() {
        let mut chain = DerivationChain::new("test", "Test");

        chain.add_step(DerivationStep::new(0, "Step 0", StepKind::TypeDeclaration));
        chain.add_step(DerivationStep::new(1, "Step 1", StepKind::QuantumSelection));

        assert_eq!(chain.step_count(), 2);
        assert_eq!(chain.steps[0].index, 0);
        assert_eq!(chain.steps[1].index, 1);
    }
}
