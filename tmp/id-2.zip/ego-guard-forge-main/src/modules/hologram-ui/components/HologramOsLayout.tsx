/**
 * HologramOsLayout — The main Hologram OS desktop shell.
 * Sidebar (desktop) + bottom nav (mobile) + content area.
 */

import { type ReactNode } from "react";
import DesktopOsSidebar from "./DesktopOsSidebar";
import MobileBottomNav from "./MobileBottomNav";

interface HologramOsLayoutProps {
  children: ReactNode;
}

export default function HologramOsLayout({ children }: HologramOsLayoutProps) {
  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Desktop sidebar — hidden on mobile */}
      <div className="hidden md:block">
        <DesktopOsSidebar bgMode="dark" />
      </div>
      <main className="flex-1 overflow-y-auto pb-16 md:pb-0">
        {children}
      </main>
      {/* Mobile bottom nav */}
      <MobileBottomNav />
    </div>
  );
}
