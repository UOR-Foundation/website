// Pull in the build-time generated query types.
include!(concat!(env!("OUT_DIR"), "/generated_query.rs"));
