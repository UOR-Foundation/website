//! Tracing middleware for backends.
//!
//! This module provides middleware that wraps backends with tracing instrumentation.
//! It is designed to work with the hologram-backend crate when that becomes available.

use std::time::{Duration, Instant};

use crate::metrics::MetricsRegistry;

/// Configuration for middleware tracing.
#[derive(Debug, Clone)]
pub struct MiddlewareConfig {
    /// Name for identifying this middleware instance in traces.
    pub name: String,
    /// Whether to record execution times.
    pub record_timings: bool,
    /// Whether to count executions.
    pub count_executions: bool,
}

impl Default for MiddlewareConfig {
    fn default() -> Self {
        Self {
            name: "middleware".to_string(),
            record_timings: true,
            count_executions: true,
        }
    }
}

impl MiddlewareConfig {
    /// Create a new middleware configuration with the given name.
    #[must_use]
    pub fn new(name: impl Into<String>) -> Self {
        Self {
            name: name.into(),
            ..Default::default()
        }
    }

    /// Set whether to record execution timings.
    #[must_use]
    pub fn record_timings(mut self, enabled: bool) -> Self {
        self.record_timings = enabled;
        self
    }

    /// Set whether to count executions.
    #[must_use]
    pub fn count_executions(mut self, enabled: bool) -> Self {
        self.count_executions = enabled;
        self
    }
}

/// A tracing context for middleware operations.
///
/// This can be used to wrap any operation with timing and counting.
pub struct TracingContext {
    config: MiddlewareConfig,
    registry: &'static MetricsRegistry,
}

impl TracingContext {
    /// Create a new tracing context.
    #[must_use]
    pub fn new(config: MiddlewareConfig) -> Self {
        Self {
            config,
            registry: MetricsRegistry::global(),
        }
    }

    /// Execute a closure with tracing.
    ///
    /// This will:
    /// - Record the execution time if `record_timings` is enabled
    /// - Increment the execution counter if `count_executions` is enabled
    ///
    /// # Example
    ///
    /// ```rust
    /// use hologram_telemetry::middleware::{TracingContext, MiddlewareConfig};
    ///
    /// let ctx = TracingContext::new(MiddlewareConfig::new("my_operation"));
    /// let result = ctx.trace("operation", || {
    ///     // ... do work ...
    ///     42
    /// });
    /// ```
    pub fn trace<F, R>(&self, operation: &'static str, f: F) -> R
    where
        F: FnOnce() -> R,
    {
        let start = Instant::now();
        let result = f();
        let duration = start.elapsed();

        if self.config.record_timings {
            let metric_name = self.timing_metric_name(operation);
            // We need to leak the string to get a 'static lifetime
            // This is acceptable for metric names which are typically fixed
            let metric_name: &'static str = Box::leak(metric_name.into_boxed_str());
            self.registry.record_duration(metric_name, duration);
        }

        if self.config.count_executions {
            let metric_name = self.counter_metric_name(operation);
            let metric_name: &'static str = Box::leak(metric_name.into_boxed_str());
            self.registry.increment(metric_name, 1);
        }

        result
    }

    /// Get the timing metric name for an operation.
    #[must_use]
    pub fn timing_metric_name(&self, operation: &str) -> String {
        format!("hologram.{}.{}_ms", self.config.name, operation)
    }

    /// Get the counter metric name for an operation.
    #[must_use]
    pub fn counter_metric_name(&self, operation: &str) -> String {
        format!("hologram.{}.{}_total", self.config.name, operation)
    }
}

/// A timing guard that records duration when dropped.
pub struct TimingGuard {
    start: Instant,
    metric_name: &'static str,
    registry: &'static MetricsRegistry,
}

impl TimingGuard {
    /// Create a new timing guard.
    #[must_use]
    pub fn new(metric_name: &'static str) -> Self {
        Self {
            start: Instant::now(),
            metric_name,
            registry: MetricsRegistry::global(),
        }
    }

    /// Get the elapsed time since creation.
    #[must_use]
    pub fn elapsed(&self) -> Duration {
        self.start.elapsed()
    }
}

impl Drop for TimingGuard {
    fn drop(&mut self) {
        self.registry
            .record_duration(self.metric_name, self.start.elapsed());
    }
}

/// Helper trait for adding tracing to any type.
pub trait Traceable {
    /// The result type after tracing.
    type Output;

    /// Execute with tracing and return the result.
    fn traced(self) -> Self::Output;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_middleware_config_default() {
        let config = MiddlewareConfig::default();
        assert_eq!(config.name, "middleware");
        assert!(config.record_timings);
        assert!(config.count_executions);
    }

    #[test]
    fn test_middleware_config_new() {
        let config = MiddlewareConfig::new("test");
        assert_eq!(config.name, "test");
    }

    #[test]
    fn test_middleware_config_builder() {
        let config = MiddlewareConfig::new("test")
            .record_timings(false)
            .count_executions(false);

        assert!(!config.record_timings);
        assert!(!config.count_executions);
    }

    #[test]
    fn test_tracing_context_trace() {
        let ctx = TracingContext::new(MiddlewareConfig::new("test_ctx"));
        let result = ctx.trace("operation", || 42);
        assert_eq!(result, 42);
    }

    #[test]
    fn test_tracing_context_metric_names() {
        let ctx = TracingContext::new(MiddlewareConfig::new("backend"));
        assert_eq!(
            ctx.timing_metric_name("execute"),
            "hologram.backend.execute_ms"
        );
        assert_eq!(
            ctx.counter_metric_name("execute"),
            "hologram.backend.execute_total"
        );
    }

    #[test]
    fn test_timing_guard() {
        let _guard = TimingGuard::new("test_guard_timing");
        std::thread::sleep(std::time::Duration::from_millis(1));
        // Guard records on drop
    }

    #[test]
    fn test_timing_guard_elapsed() {
        let guard = TimingGuard::new("test_elapsed");
        std::thread::sleep(std::time::Duration::from_millis(1));
        assert!(guard.elapsed() >= std::time::Duration::from_millis(1));
    }
}
