//! Query-layer code generation from shell AST.
//!
//! Transforms parsed [`Shell`] query constructs (`type`, `enum`, `transform`)
//! into Rust source code for:
//! - Resolver traits with per-field methods
//! - LUT-backed resolver implementations
//! - Serde-serializable DTO structs with `resolve()` constructors
//! - Enum types with discriminants
//! - `FieldValue` dynamic dispatch type for runtime query resolution
//! - `resolve_field()` / `resolve_param_field()` methods on DTOs
//! - `FIELDS` / `PARAM_FIELDS` constants for schema validation

use proc_macro2::{Ident, Span, TokenStream};
use quote::quote;

use crate::ast::*;
use crate::naming::to_pascal_case;

fn ident(s: &str) -> Ident {
    Ident::new(s, Span::call_site())
}

/// Map a shell `FieldType` to Rust parameter type tokens.
///
/// For `List(T)` this returns `&[T]` (borrowed slice) instead of `Vec<T>`,
/// since function parameters should take borrowed data.
fn param_type_tokens(ty: &FieldType) -> TokenStream {
    match ty {
        FieldType::List(inner) => {
            let inner_ty = type_tokens(inner);
            quote!(&[#inner_ty])
        }
        other => type_tokens(other),
    }
}

/// Map a shell `FieldType` to Rust type tokens (owned).
fn type_tokens(ty: &FieldType) -> TokenStream {
    match ty {
        FieldType::U8 => quote!(u8),
        FieldType::U16 => quote!(u16),
        FieldType::U32 => quote!(u32),
        FieldType::U64 => quote!(u64),
        FieldType::Usize => quote!(usize),
        FieldType::I32 => quote!(i32),
        FieldType::I64 => quote!(i64),
        FieldType::F32 => quote!(f32),
        FieldType::String => quote!(String),
        FieldType::Domain => quote!(u8),
        FieldType::List(inner) => {
            let inner_ty = type_tokens(inner);
            quote!(Vec<#inner_ty>)
        }
        FieldType::Named(n) => {
            let id = ident(n);
            quote!(#id)
        }
        _ => quote!(u8), // fallback for query layer
    }
}

// ============================================================================
// Resolver expression compilation
// ============================================================================

/// Convert a module path string (e.g., "uor::lut") to token segments.
fn module_path_tokens(path: &str) -> TokenStream {
    let segments: Vec<Ident> = path.split("::").map(ident).collect();
    quote!(#(#segments)::*)
}

/// Get the effective module path for a shell (defaults to "uor::lut").
fn effective_module_path(shell: &Shell) -> &str {
    shell.module_path.as_deref().unwrap_or("uor::lut")
}

/// Compile a `ResolverExpr` into a Rust expression calling the module's function.
fn resolver_call_tokens(expr: &ResolverExpr, mod_path: &str) -> TokenStream {
    let func = ident(&expr.function);
    let args: Vec<TokenStream> = expr
        .args
        .iter()
        .map(|a| expr_arg_tokens(a, mod_path))
        .collect();
    let mp = module_path_tokens(mod_path);
    quote!(#mp::#func(#(#args),*))
}

/// Compile a single resolver argument.
fn expr_arg_tokens(arg: &ExprArg, mod_path: &str) -> TokenStream {
    match arg {
        ExprArg::Param(name) => {
            let id = ident(name);
            quote!(#id)
        }
        ExprArg::Expr(e) => expr_tokens(e, mod_path),
    }
}

/// Compile a general expression.
fn expr_tokens(expr: &Expr, mod_path: &str) -> TokenStream {
    match expr {
        Expr::Param(name) => {
            let id = ident(name);
            quote!(#id)
        }
        Expr::Literal(n) => {
            let v = *n;
            quote!(#v)
        }
        Expr::BinOp(lhs, op, rhs) => {
            let l = expr_tokens(lhs, mod_path);
            let r = expr_tokens(rhs, mod_path);
            let op_token = match op {
                BinOp::Add => quote!(+),
                BinOp::Sub => quote!(-),
                BinOp::Mul => quote!(*),
                BinOp::Shr => quote!(>>),
                BinOp::Shl => quote!(<<),
                BinOp::BitAnd => quote!(&),
                BinOp::BitOr => quote!(|),
                BinOp::Mod => quote!(%),
            };
            quote!((#l #op_token #r))
        }
        Expr::Call(func, args) => {
            let f = ident(func);
            let a: Vec<TokenStream> = args.iter().map(|e| expr_tokens(e, mod_path)).collect();
            let mp = module_path_tokens(mod_path);
            quote!(#mp::#f(#(#a),*))
        }
    }
}

// ============================================================================
// Resolver trait generation
// ============================================================================

/// Collect all flat field definitions from a TypeDef (flattening nested children).
struct FlatField {
    method_name: String,
    args: Vec<(String, FieldType, Option<Constraint>)>,
    return_type: FieldType,
    resolver: ResolverExpr,
}

/// Flatten fields, prefixing nested children with parent name.
fn flatten_fields(fields: &[FieldDef], prefix: &str) -> Vec<FlatField> {
    let mut out = Vec::new();
    for f in fields {
        if f.children.is_empty() {
            let method = if prefix.is_empty() {
                f.name.clone()
            } else {
                format!("{prefix}_{}", f.name)
            };
            out.push(FlatField {
                method_name: method,
                args: f
                    .args
                    .iter()
                    .map(|a| (a.name.clone(), a.ty.clone(), a.constraint.clone()))
                    .collect(),
                return_type: f.return_type.clone(),
                resolver: f.resolver.clone(),
            });
        } else {
            out.extend(flatten_fields(&f.children, &f.name));
        }
    }
    out
}

/// Generate resolver traits for all `type` definitions in a shell.
///
/// For `type Byte(value: u8) { stratum: u8 = stratum_q0(value) }` generates:
/// ```text
/// pub trait ByteResolver {
///     fn stratum(&self, value: u8) -> u8;
/// }
/// ```
pub fn emit_resolver_traits(shell: &Shell) -> TokenStream {
    let mut out = TokenStream::new();

    for item in &shell.items {
        if let ShellItem::Type(td) = item {
            let trait_name = ident(&format!("{}Resolver", to_pascal_case(&td.name)));
            let root_params: Vec<TokenStream> = td
                .params
                .iter()
                .map(|p| {
                    let n = ident(&p.name);
                    let t = param_type_tokens(&p.ty);
                    quote!(#n: #t)
                })
                .collect();

            let flat = flatten_fields(&td.fields, "");
            let methods: Vec<TokenStream> = flat
                .iter()
                .map(|f| {
                    let method = ident(&f.method_name);
                    let ret = type_tokens(&f.return_type);
                    let extra_params: Vec<TokenStream> = f
                        .args
                        .iter()
                        .map(|(name, ty, _)| {
                            let n = ident(name);
                            let t = param_type_tokens(ty);
                            quote!(#n: #t)
                        })
                        .collect();
                    quote! {
                        fn #method(&self, #(#root_params),* #(, #extra_params)*) -> #ret;
                    }
                })
                .collect();

            out.extend(quote! {
                pub trait #trait_name {
                    #(#methods)*
                }
            });
        }
    }

    for item in &shell.items {
        if let ShellItem::Transform(td) = item {
            let trait_name = ident(&format!("{}Resolver", to_pascal_case(&td.name)));
            let ret_ty = type_tokens(&td.return_type);
            let param_defs: Vec<TokenStream> = td
                .params
                .iter()
                .map(|p| {
                    let n = ident(&p.name);
                    let t = type_tokens(&p.ty);
                    quote!(#n: #t)
                })
                .collect();

            let methods: Vec<TokenStream> = td
                .operations
                .iter()
                .map(|op| {
                    let method = ident(&op.name);
                    quote! {
                        fn #method(&self, input: u8, #(#param_defs),*) -> #ret_ty;
                    }
                })
                .collect();

            out.extend(quote! {
                pub trait #trait_name {
                    #(#methods)*
                }
            });
        }
    }

    out
}

// ============================================================================
// LUT resolver implementation generation
// ============================================================================

/// Generate LUT-backed resolver implementations.
///
/// For `type Byte(value: u8) { stratum: u8 = stratum_q0(value) }` generates:
/// ```text
/// pub struct LutByteResolver;
/// impl ByteResolver for LutByteResolver {
///     #[inline]
///     fn stratum(&self, value: u8) -> u8 { uor::lut::stratum_q0(value) }
/// }
/// ```
pub fn emit_resolver_impls(shell: &Shell) -> TokenStream {
    let mut out = TokenStream::new();

    let mod_path = effective_module_path(shell);

    for item in &shell.items {
        if let ShellItem::Type(td) = item {
            let pascal = to_pascal_case(&td.name);
            let trait_name = ident(&format!("{pascal}Resolver"));
            let struct_name = ident(&format!("Lut{pascal}Resolver"));
            let root_params: Vec<TokenStream> = td
                .params
                .iter()
                .map(|p| {
                    let n = ident(&p.name);
                    let t = param_type_tokens(&p.ty);
                    quote!(#n: #t)
                })
                .collect();

            // Wrap root params with mod constraints
            let root_wraps: Vec<TokenStream> = td
                .params
                .iter()
                .filter_map(|p| {
                    if let Some(Constraint::Mod(m)) = &p.constraint {
                        let n = ident(&p.name);
                        let modulus = *m as u8;
                        Some(quote! { let #n = #n % #modulus; })
                    } else {
                        None
                    }
                })
                .collect();

            let flat = flatten_fields(&td.fields, "");
            let methods: Vec<TokenStream> = flat
                .iter()
                .map(|f| {
                    let method = ident(&f.method_name);
                    let ret = type_tokens(&f.return_type);
                    let call = resolver_call_tokens(&f.resolver, mod_path);
                    let extra_params: Vec<TokenStream> = f
                        .args
                        .iter()
                        .map(|(name, ty, constraint)| {
                            let n = ident(name);
                            let t = param_type_tokens(ty);
                            let _ = constraint;
                            quote!(#n: #t)
                        })
                        .collect();
                    let constraint_wraps: Vec<TokenStream> = f
                        .args
                        .iter()
                        .filter_map(|(name, _, constraint)| {
                            if let Some(Constraint::Mod(m)) = constraint {
                                let n = ident(name);
                                let modulus = *m as u8;
                                Some(quote! { let #n = #n % #modulus; })
                            } else {
                                None
                            }
                        })
                        .collect();
                    let rw = &root_wraps;

                    quote! {
                        #[inline]
                        fn #method(&self, #(#root_params),* #(, #extra_params)*) -> #ret {
                            #(#rw)*
                            #(#constraint_wraps)*
                            #call
                        }
                    }
                })
                .collect();

            out.extend(quote! {
                pub struct #struct_name;

                impl #trait_name for #struct_name {
                    #(#methods)*
                }
            });
        }
    }

    for item in &shell.items {
        if let ShellItem::Transform(td) = item {
            let pascal = to_pascal_case(&td.name);
            let trait_name = ident(&format!("{pascal}Resolver"));
            let struct_name = ident(&format!("Lut{pascal}Resolver"));
            let ret_ty = type_tokens(&td.return_type);

            let param_defs: Vec<TokenStream> = td
                .params
                .iter()
                .map(|p| {
                    let n = ident(&p.name);
                    let t = type_tokens(&p.ty);
                    quote!(#n: #t)
                })
                .collect();

            let methods: Vec<TokenStream> = td
                .operations
                .iter()
                .map(|op| {
                    let method = ident(&op.name);
                    let call = resolver_call_tokens(&op.resolver, mod_path);
                    quote! {
                        #[inline]
                        fn #method(&self, input: u8, #(#param_defs),*) -> #ret_ty {
                            #call
                        }
                    }
                })
                .collect();

            out.extend(quote! {
                pub struct #struct_name;

                impl #trait_name for #struct_name {
                    #(#methods)*
                }
            });
        }
    }

    out
}

// ============================================================================
// DTO struct generation
// ============================================================================

/// Generate serde-serializable DTO structs with `resolve()` constructors.
///
/// For `type Byte(value: u8) { stratum: u8 = ..., torus { page: u8, offset: u8 } }`
/// generates:
/// ```text
/// #[derive(Debug, Clone, Serialize)]
/// pub struct ByteDto { pub value: u8, pub stratum: u8, pub torus: ByteTorusDto }
///
/// #[derive(Debug, Clone, Serialize)]
/// pub struct ByteTorusDto { pub page: u8, pub offset: u8 }
/// ```
pub fn emit_dtos(shell: &Shell) -> TokenStream {
    let mut out = TokenStream::new();
    let mod_path = effective_module_path(shell);

    for item in &shell.items {
        if let ShellItem::Type(td) = item {
            let pascal = to_pascal_case(&td.name);
            out.extend(emit_dto_for_type(td, &pascal, mod_path));
        }
    }

    out
}

/// Generate DTO struct(s) for a single TypeDef.
fn emit_dto_for_type(td: &TypeDef, pascal: &str, mod_path: &str) -> TokenStream {
    let mut out = TokenStream::new();

    // Generate nested DTO structs first
    for f in &td.fields {
        if !f.children.is_empty() {
            out.extend(emit_nested_dto(f, pascal));
        }
    }

    // Main DTO struct
    let dto_name = ident(&format!("{pascal}Dto"));
    let struct_name = ident(&format!("Lut{pascal}Resolver"));

    // Root params as struct fields (owned) and resolve() arguments (borrowed for lists)
    let root_param_fields: Vec<TokenStream> = td
        .params
        .iter()
        .map(|p| {
            let n = ident(&p.name);
            let t = type_tokens(&p.ty);
            quote!(pub #n: #t)
        })
        .collect();
    let root_param_args: Vec<TokenStream> = td
        .params
        .iter()
        .map(|p| {
            let n = ident(&p.name);
            let t = param_type_tokens(&p.ty);
            quote!(#n: #t)
        })
        .collect();

    // For struct init: list params need .to_vec(), others just use the name
    let resolve_root_fields: Vec<TokenStream> = td
        .params
        .iter()
        .map(|p| {
            let n = ident(&p.name);
            if matches!(p.ty, FieldType::List(_)) {
                quote!(#n: #n.to_vec())
            } else {
                quote!(#n)
            }
        })
        .collect();

    let mut field_defs: Vec<TokenStream> = root_param_fields;
    let mut resolve_fields: Vec<TokenStream> = Vec::new();

    for f in &td.fields {
        if f.children.is_empty() && f.args.is_empty() {
            let fname = ident(&f.name);
            let fty = type_tokens(&f.return_type);
            field_defs.push(quote!(pub #fname: #fty));
            let call = resolver_call_tokens(&f.resolver, mod_path);
            resolve_fields.push(quote!(#fname: #call));
        } else if !f.children.is_empty() {
            let fname = ident(&f.name);
            let nested_dto = ident(&format!("{pascal}{}Dto", to_pascal_case(&f.name)));
            field_defs.push(quote!(pub #fname: #nested_dto));

            let nested_fields: Vec<TokenStream> = f
                .children
                .iter()
                .filter(|c| c.args.is_empty())
                .map(|c| {
                    let cn = ident(&c.name);
                    let call = resolver_call_tokens(&c.resolver, mod_path);
                    quote!(#cn: #call)
                })
                .collect();

            resolve_fields.push(quote!(#fname: #nested_dto {
                #(#nested_fields),*
            }));
        }
        // Skip parameterized fields in DTO (they need arguments)
    }

    // Wrap root params with mod constraints
    let root_wraps: Vec<TokenStream> = td
        .params
        .iter()
        .filter_map(|p| {
            if let Some(Constraint::Mod(m)) = &p.constraint {
                let n = ident(&p.name);
                let modulus = *m as u8;
                Some(quote! { let #n = #n % #modulus; })
            } else {
                None
            }
        })
        .collect();

    out.extend(quote! {
        #[derive(Debug, Clone, serde::Serialize)]
        pub struct #dto_name {
            #(#field_defs),*
        }

        impl #dto_name {
            /// Resolve all fields for the given value using O(1) LUT lookups.
            #[allow(unused_variables)]
            pub fn resolve(#(#root_param_args),*) -> Self {
                #(#root_wraps)*
                let _r = #struct_name;
                Self {
                    #(#resolve_fields,)*
                    #(#resolve_root_fields),*
                }
            }
        }
    });

    out
}

/// Generate a nested DTO struct for a field with children.
fn emit_nested_dto(field: &FieldDef, parent_pascal: &str) -> TokenStream {
    let dto_name = ident(&format!(
        "{parent_pascal}{}Dto",
        to_pascal_case(&field.name)
    ));
    let field_defs: Vec<TokenStream> = field
        .children
        .iter()
        .filter(|c| c.args.is_empty())
        .map(|c| {
            let name = ident(&c.name);
            let ty = type_tokens(&c.return_type);
            quote!(pub #name: #ty)
        })
        .collect();

    quote! {
        #[derive(Debug, Clone, serde::Serialize)]
        pub struct #dto_name {
            #(#field_defs),*
        }
    }
}

// ============================================================================
// Enum generation
// ============================================================================

/// Generate Rust enums from `enum` definitions in a shell.
///
/// For `enum Domain { Theta = 0, Psi = 1, Delta = 2 }` generates:
/// ```text
/// #[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize)]
/// #[repr(u8)]
/// pub enum Domain { Theta = 0, Psi = 1, Delta = 2 }
/// ```
pub fn emit_enums(shell: &Shell) -> TokenStream {
    let mut out = TokenStream::new();

    for item in &shell.items {
        if let ShellItem::Enum(ed) = item {
            let name = ident(&ed.name);
            let variants: Vec<TokenStream> = ed
                .variants
                .iter()
                .map(|v| {
                    let vname = ident(&v.name);
                    if let Some(val) = v.value {
                        let lit = val as u8;
                        quote!(#vname = #lit)
                    } else {
                        quote!(#vname)
                    }
                })
                .collect();

            out.extend(quote! {
                #[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize)]
                #[repr(u8)]
                pub enum #name {
                    #(#variants),*
                }
            });
        }
    }

    out
}

// ============================================================================
// FieldValue type for runtime query dispatch
// ============================================================================

/// Map a `FieldType` to the corresponding `FieldValue` variant constructor.
fn field_value_wrap(ty: &FieldType, expr: TokenStream) -> TokenStream {
    match ty {
        FieldType::U8 | FieldType::Domain => quote!(FieldValue::U8(#expr)),
        FieldType::U16 => quote!(FieldValue::U16(#expr)),
        FieldType::U32 => quote!(FieldValue::U32(#expr)),
        FieldType::U64 => quote!(FieldValue::U64(#expr)),
        FieldType::Usize => quote!(FieldValue::Usize(#expr)),
        FieldType::I32 => quote!(FieldValue::I32(#expr)),
        FieldType::I64 => quote!(FieldValue::I64(#expr)),
        FieldType::F32 => quote!(FieldValue::F32(#expr)),
        FieldType::String => quote!(FieldValue::Str(#expr)),
        FieldType::List(_) => quote!(FieldValue::Json(serde_json::json!(#expr))),
        _ => quote!(FieldValue::U8(#expr)),
    }
}

/// Emit the `FieldValue` enum used by runtime query dispatch.
///
/// This is emitted once per build and provides a type-erased wrapper
/// for field resolution results, with `serde::Serialize` for JSON output.
pub fn emit_field_value_type() -> TokenStream {
    quote! {
        /// Dynamic field value for runtime query dispatch.
        #[derive(Debug, Clone, serde::Serialize)]
        #[serde(untagged)]
        pub enum FieldValue {
            U8(u8),
            U16(u16),
            U32(u32),
            U64(u64),
            I32(i32),
            I64(i64),
            F32(f32),
            Usize(usize),
            Str(String),
            /// Pre-serialized JSON for complex types (lists, nested objects).
            Json(serde_json::Value),
        }

        impl FieldValue {
            /// Extract as u8, if the variant is `U8`.
            pub fn as_u8(&self) -> Option<u8> {
                match self { FieldValue::U8(v) => Some(*v), _ => None }
            }
            /// Extract as i64 for delta computation.
            pub fn as_i64(&self) -> Option<i64> {
                match self {
                    FieldValue::U8(v) => Some(*v as i64),
                    FieldValue::U16(v) => Some(*v as i64),
                    FieldValue::U32(v) => Some(*v as i64),
                    FieldValue::U64(v) => Some(*v as i64),
                    FieldValue::Usize(v) => Some(*v as i64),
                    FieldValue::I32(v) => Some(*v as i64),
                    FieldValue::I64(v) => Some(*v),
                    _ => None,
                }
            }
        }
    }
}

// ============================================================================
// Field-level dispatch generation
// ============================================================================

/// Emit `resolve_field()` and `resolve_param_field()` methods on each DTO.
///
/// For `type Byte(value: u8) { stratum: u8 = stratum_q0(value), ... }` generates:
/// ```text
/// impl ByteDto {
///     pub fn resolve_field(value: u8, field: &str) -> Option<FieldValue> {
///         Some(match field {
///             "stratum" => FieldValue::U8(uor::lut::stratum_q0(value)),
///             _ => return None,
///         })
///     }
/// }
/// ```
pub fn emit_field_dispatch(shell: &Shell) -> TokenStream {
    let mut out = TokenStream::new();
    let mod_path = effective_module_path(shell);

    for item in &shell.items {
        if let ShellItem::Type(td) = item {
            let pascal = to_pascal_case(&td.name);
            let dto_name = ident(&format!("{pascal}Dto"));
            let root_params: Vec<TokenStream> = td
                .params
                .iter()
                .map(|p| {
                    let n = ident(&p.name);
                    let t = param_type_tokens(&p.ty);
                    quote!(#n: #t)
                })
                .collect();

            let root_wraps: Vec<TokenStream> = td
                .params
                .iter()
                .filter_map(|p| {
                    if let Some(Constraint::Mod(m)) = &p.constraint {
                        let n = ident(&p.name);
                        let modulus = *m as u8;
                        Some(quote! { let #n = #n % #modulus; })
                    } else {
                        None
                    }
                })
                .collect();

            let flat = flatten_fields(&td.fields, "");

            // Separate simple fields (no args) from parameterized fields
            let simple_arms: Vec<TokenStream> = flat
                .iter()
                .filter(|f| f.args.is_empty())
                .map(|f| {
                    let key = &f.method_name;
                    let call = resolver_call_tokens(&f.resolver, mod_path);
                    let wrapped = field_value_wrap(&f.return_type, call);
                    quote!(#key => #wrapped)
                })
                .collect();

            // Also add dot-notation for nested fields
            let nested_arms: Vec<TokenStream> = td
                .fields
                .iter()
                .filter(|f| !f.children.is_empty())
                .flat_map(|f| {
                    f.children.iter().filter(|c| c.args.is_empty()).map(|c| {
                        let key = format!("{}.{}", f.name, c.name);
                        let call = resolver_call_tokens(&c.resolver, mod_path);
                        let wrapped = field_value_wrap(&c.return_type, call);
                        quote!(#key => #wrapped)
                    })
                })
                .collect();

            if !simple_arms.is_empty() || !nested_arms.is_empty() {
                let rp = &root_params;
                let rw = &root_wraps;
                out.extend(quote! {
                    impl #dto_name {
                        /// Resolve a single field by name using O(1) LUT lookup.
                        pub fn resolve_field(#(#rp),*, field: &str) -> Option<FieldValue> {
                            #(#rw)*
                            Some(match field {
                                #(#simple_arms,)*
                                #(#nested_arms,)*
                                _ => return None,
                            })
                        }
                    }
                });
            }

            // Parameterized field dispatch (ring's add/sub/mul)
            let param_arms: Vec<TokenStream> = flat
                .iter()
                .filter(|f| !f.args.is_empty())
                .map(|f| {
                    let key = &f.method_name;
                    let call = resolver_call_tokens(&f.resolver, mod_path);
                    let wrapped = field_value_wrap(&f.return_type, call);
                    // Extract args from FieldValue slice
                    let arg_extracts: Vec<TokenStream> = f
                        .args
                        .iter()
                        .enumerate()
                        .map(|(i, (name, _ty, constraint))| {
                            let n = ident(name);
                            let wrap = if let Some(Constraint::Mod(m)) = constraint {
                                let modulus = *m as u8;
                                quote! { % #modulus }
                            } else {
                                TokenStream::new()
                            };
                            let accessor = if i == 0 {
                                quote! { args.first()? }
                            } else {
                                quote! { args.get(#i)? }
                            };
                            quote! { let #n = #accessor.as_u8()? #wrap; }
                        })
                        .collect();
                    quote! {
                        #key => {
                            #(#arg_extracts)*
                            #wrapped
                        }
                    }
                })
                .collect();

            if !param_arms.is_empty() {
                let rp = &root_params;
                let rw = &root_wraps;
                out.extend(quote! {
                    impl #dto_name {
                        /// Resolve a parameterized field by name with arguments.
                        pub fn resolve_param_field(
                            #(#rp),*,
                            field: &str,
                            args: &[FieldValue],
                        ) -> Option<FieldValue> {
                            #(#rw)*
                            Some(match field {
                                #(#param_arms,)*
                                _ => return None,
                            })
                        }
                    }
                });
            }
        }
    }

    out
}

// ============================================================================
// Field list constants
// ============================================================================

/// Emit `FIELDS` and `PARAM_FIELDS` constants on each DTO.
///
/// `FIELDS` lists all queryable field names (non-parameterized).
/// `PARAM_FIELDS` lists parameterized field names (require arguments).
pub fn emit_field_list(shell: &Shell) -> TokenStream {
    let mut out = TokenStream::new();

    for item in &shell.items {
        if let ShellItem::Type(td) = item {
            let pascal = to_pascal_case(&td.name);
            let dto_name = ident(&format!("{pascal}Dto"));
            let flat = flatten_fields(&td.fields, "");

            let mut simple_names: Vec<String> = flat
                .iter()
                .filter(|f| f.args.is_empty())
                .map(|f| f.method_name.clone())
                .collect();
            // Add dot-notation for nested fields
            for f in &td.fields {
                if !f.children.is_empty() {
                    for c in &f.children {
                        if c.args.is_empty() {
                            simple_names.push(format!("{}.{}", f.name, c.name));
                        }
                    }
                }
            }

            let param_names: Vec<String> = flat
                .iter()
                .filter(|f| !f.args.is_empty())
                .map(|f| f.method_name.clone())
                .collect();

            let simple_strs: Vec<&str> = simple_names.iter().map(|s| s.as_str()).collect();
            let param_strs: Vec<&str> = param_names.iter().map(|s| s.as_str()).collect();

            out.extend(quote! {
                impl #dto_name {
                    /// Non-parameterized queryable field names.
                    pub const FIELDS: &'static [&'static str] = &[#(#simple_strs),*];
                    /// Parameterized field names (require arguments).
                    pub const PARAM_FIELDS: &'static [&'static str] = &[#(#param_strs),*];
                }
            });
        }
    }

    out
}

// ============================================================================
// Combined generation
// ============================================================================

/// Generate all query-layer code for a shell in one call.
///
/// Combines enums, traits, impls, DTOs, field dispatch, and field lists.
/// Does **not** include `FieldValue` — call [`emit_field_value_type()`] once
/// before emitting code for multiple shells.
pub fn emit_all(shell: &Shell) -> TokenStream {
    let mut out = TokenStream::new();
    out.extend(emit_enums(shell));
    out.extend(emit_resolver_traits(shell));
    out.extend(emit_resolver_impls(shell));
    out.extend(emit_dtos(shell));
    out.extend(emit_field_dispatch(shell));
    out.extend(emit_field_list(shell));
    out
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parse::parse_shell;

    fn datum_shell() -> Shell {
        parse_shell(
            r#"
            shell datum {
                type Byte(value: u8) {
                    stratum:     u8 = stratum_q0(value)
                    curvature:   u8 = curvature_q0(value)
                    domain:      u8 = domain_q0(value)
                    torus {
                        page:   u8 = torus_page_q0(value)
                        offset: u8 = torus_offset_q0(value)
                    }
                }

                enum Domain {
                    Theta = 0,
                    Psi   = 1,
                    Delta = 2
                }
            }
        "#,
        )
        .unwrap()
    }

    fn ring_shell() -> Shell {
        parse_shell(
            r#"
            shell ring {
                type Element(value: u8 mod 96) {
                    add(other: u8 mod 96): u8 = ring_add_96(value, other)
                    sub(other: u8 mod 96): u8 = ring_sub_96(value, other)
                }

                transform Translate(by: u8 mod 96) -> u8 {
                    add = ring_add_96(input, by)
                    sub = ring_sub_96(input, by)
                }
            }
        "#,
        )
        .unwrap()
    }

    fn activation_shell() -> Shell {
        parse_shell(
            r#"
            shell activation {
                type Activation(value: u8) {
                    sigmoid: u8 = sigmoid_lut(value)
                    tanh:    u8 = tanh_lut(value)
                    relu:    u8 = relu_lut(value)
                }
            }
        "#,
        )
        .unwrap()
    }

    #[test]
    fn trait_has_expected_methods() {
        let shell = datum_shell();
        let code = emit_resolver_traits(&shell).to_string();
        assert!(code.contains("trait ByteResolver"));
        assert!(code.contains("fn stratum"));
        assert!(code.contains("fn curvature"));
        assert!(code.contains("fn domain"));
        assert!(code.contains("fn torus_page"));
        assert!(code.contains("fn torus_offset"));
    }

    #[test]
    fn trait_parameterized_fields() {
        let shell = ring_shell();
        let code = emit_resolver_traits(&shell).to_string();
        assert!(code.contains("trait ElementResolver"));
        assert!(code.contains("fn add"));
        assert!(code.contains("fn sub"));
        assert!(code.contains("other : u8"));
    }

    #[test]
    fn transform_trait() {
        let shell = ring_shell();
        let code = emit_resolver_traits(&shell).to_string();
        assert!(code.contains("trait TranslateResolver"));
        assert!(code.contains("fn add (& self , input : u8"));
        assert!(code.contains("fn sub (& self , input : u8"));
    }

    #[test]
    fn impl_calls_lut_functions() {
        let shell = datum_shell();
        let code = emit_resolver_impls(&shell).to_string();
        assert!(code.contains("LutByteResolver"));
        assert!(code.contains("impl ByteResolver for LutByteResolver"));
        assert!(code.contains("uor :: lut :: stratum_q0"));
        assert!(code.contains("uor :: lut :: torus_page_q0"));
    }

    #[test]
    fn impl_constraint_wrapping() {
        let shell = ring_shell();
        let code = emit_resolver_impls(&shell).to_string();
        assert!(code.contains("LutElementResolver"));
        // Mod constraint wrapping for both root and extra params
        assert!(code.contains("let value = value % 96"));
        assert!(code.contains("let other = other % 96"));
    }

    #[test]
    fn transform_impl() {
        let shell = ring_shell();
        let code = emit_resolver_impls(&shell).to_string();
        assert!(code.contains("LutTranslateResolver"));
        assert!(code.contains("impl TranslateResolver for LutTranslateResolver"));
        assert!(code.contains("uor :: lut :: ring_add_96"));
    }

    #[test]
    fn dto_struct_fields() {
        let shell = datum_shell();
        let code = emit_dtos(&shell).to_string();
        assert!(code.contains("pub struct ByteDto"));
        assert!(code.contains("pub value : u8"));
        assert!(code.contains("pub stratum : u8"));
        assert!(code.contains("pub curvature : u8"));
    }

    #[test]
    fn dto_nested_struct() {
        let shell = datum_shell();
        let code = emit_dtos(&shell).to_string();
        assert!(code.contains("pub struct ByteTorusDto"));
        assert!(code.contains("pub page : u8"));
        assert!(code.contains("pub offset : u8"));
        assert!(code.contains("pub torus : ByteTorusDto"));
    }

    #[test]
    fn dto_resolve_constructor() {
        let shell = datum_shell();
        let code = emit_dtos(&shell).to_string();
        assert!(code.contains("pub fn resolve"));
        assert!(code.contains("uor :: lut :: stratum_q0"));
    }

    #[test]
    fn dto_skips_parameterized_fields() {
        let shell = ring_shell();
        let code = emit_dtos(&shell).to_string();
        // ElementDto should exist but not include add/sub fields (they need args)
        assert!(code.contains("pub struct ElementDto"));
        // The DTO should only have the root value field
        assert!(code.contains("pub value : u8"));
    }

    #[test]
    fn enum_generation() {
        let shell = datum_shell();
        let code = emit_enums(&shell).to_string();
        assert!(code.contains("pub enum Domain"));
        assert!(code.contains("Theta = 0"));
        assert!(code.contains("Psi = 1"));
        assert!(code.contains("Delta = 2"));
        assert!(code.contains("Serialize"));
    }

    #[test]
    fn activation_trait_and_impl() {
        let shell = activation_shell();
        let code = emit_all(&shell).to_string();
        assert!(code.contains("trait ActivationResolver"));
        assert!(code.contains("LutActivationResolver"));
        assert!(code.contains("uor :: lut :: sigmoid_lut"));
        assert!(code.contains("uor :: lut :: tanh_lut"));
        assert!(code.contains("uor :: lut :: relu_lut"));
    }

    #[test]
    fn activation_dto() {
        let shell = activation_shell();
        let code = emit_dtos(&shell).to_string();
        assert!(code.contains("pub struct ActivationDto"));
        assert!(code.contains("pub sigmoid : u8"));
        assert!(code.contains("pub tanh : u8"));
        assert!(code.contains("pub relu : u8"));
    }

    #[test]
    fn emit_all_combines() {
        let shell = datum_shell();
        let code = emit_all(&shell).to_string();
        // Should contain all four categories
        assert!(code.contains("pub enum Domain"));
        assert!(code.contains("trait ByteResolver"));
        assert!(code.contains("LutByteResolver"));
        assert!(code.contains("pub struct ByteDto"));
    }

    #[test]
    fn real_datum_shell_parses_and_generates() {
        let input = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../descriptors/shells/datum.shell"
        ))
        .unwrap();
        let shell = parse_shell(&input).unwrap();
        let code = emit_all(&shell).to_string();
        assert!(code.contains("trait ByteResolver"));
        assert!(code.contains("fn orbit_class"));
        assert!(code.contains("pub enum Domain"));
    }

    #[test]
    fn real_ring_shell_parses_and_generates() {
        let input = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../descriptors/shells/ring.shell"
        ))
        .unwrap();
        let shell = parse_shell(&input).unwrap();
        let code = emit_all(&shell).to_string();
        assert!(code.contains("trait ElementResolver"));
        assert!(code.contains("trait TranslateResolver"));
        assert!(code.contains("uor :: lut :: byte_add"));
    }

    #[test]
    fn real_activation_shell_parses_and_generates() {
        let input = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../descriptors/shells/activation.shell"
        ))
        .unwrap();
        let shell = parse_shell(&input).unwrap();
        let code = emit_all(&shell).to_string();
        assert!(code.contains("trait ActivationResolver"));
        assert!(code.contains("fn gelu"));
        assert!(code.contains("fn silu"));
        assert!(code.contains("pub struct ActivationDto"));
    }

    // ================================================================
    // FieldValue, resolve_field, and FIELDS tests
    // ================================================================

    #[test]
    fn field_value_type_emitted() {
        let code = emit_field_value_type().to_string();
        assert!(code.contains("pub enum FieldValue"));
        assert!(code.contains("U8 (u8)"));
        assert!(code.contains("Str (String)"));
        assert!(code.contains("fn as_u8"));
        assert!(code.contains("fn as_i64"));
        assert!(code.contains("serde :: Serialize"));
    }

    #[test]
    fn field_dispatch_simple_fields() {
        let shell = datum_shell();
        let code = emit_field_dispatch(&shell).to_string();
        assert!(code.contains("fn resolve_field"));
        assert!(code.contains("\"stratum\" => FieldValue :: U8 (uor :: lut :: stratum_q0"));
        assert!(code.contains("\"curvature\" => FieldValue :: U8 (uor :: lut :: curvature_q0"));
        assert!(code.contains("\"domain\" => FieldValue :: U8 (uor :: lut :: domain_q0"));
    }

    #[test]
    fn field_dispatch_nested_dot_notation() {
        let shell = datum_shell();
        let code = emit_field_dispatch(&shell).to_string();
        // Flattened: torus_page, torus_offset
        assert!(code.contains("\"torus_page\" => FieldValue :: U8"));
        assert!(code.contains("\"torus_offset\" => FieldValue :: U8"));
        // Dot-notation: torus.page, torus.offset
        assert!(code.contains("\"torus.page\" => FieldValue :: U8"));
        assert!(code.contains("\"torus.offset\" => FieldValue :: U8"));
    }

    #[test]
    fn field_dispatch_parameterized() {
        let shell = ring_shell();
        let code = emit_field_dispatch(&shell).to_string();
        assert!(code.contains("fn resolve_param_field"));
        assert!(code.contains("args : & [FieldValue]"));
        assert!(code.contains("\"add\" =>"));
        assert!(code.contains("\"sub\" =>"));
        // Should extract arg and apply mod 96
        assert!(code.contains("as_u8 ()"));
        assert!(code.contains("% 96"));
    }

    #[test]
    fn field_list_simple() {
        let shell = datum_shell();
        let code = emit_field_list(&shell).to_string();
        assert!(code.contains("const FIELDS"));
        assert!(code.contains("\"stratum\""));
        assert!(code.contains("\"curvature\""));
        assert!(code.contains("\"domain\""));
        assert!(code.contains("\"torus_page\""));
        assert!(code.contains("\"torus.page\""));
    }

    #[test]
    fn field_list_param_fields() {
        let shell = ring_shell();
        let code = emit_field_list(&shell).to_string();
        assert!(code.contains("const PARAM_FIELDS"));
        assert!(code.contains("\"add\""));
        assert!(code.contains("\"sub\""));
    }

    #[test]
    fn field_dispatch_activation() {
        let shell = activation_shell();
        let code = emit_field_dispatch(&shell).to_string();
        assert!(code.contains("fn resolve_field"));
        assert!(code.contains("\"sigmoid\" => FieldValue :: U8"));
        assert!(code.contains("\"tanh\" => FieldValue :: U8"));
        assert!(code.contains("\"relu\" => FieldValue :: U8"));
    }

    #[test]
    fn emit_all_includes_field_dispatch() {
        let shell = datum_shell();
        let code = emit_all(&shell).to_string();
        assert!(code.contains("fn resolve_field"));
        assert!(code.contains("const FIELDS"));
        // FieldValue is emitted separately via emit_field_value_type()
        let fv = emit_field_value_type().to_string();
        assert!(fv.contains("pub enum FieldValue"));
    }

    // ================================================================
    // Observable shell (multi-param, custom module path)
    // ================================================================

    #[test]
    fn real_observable_shell_parses_and_generates() {
        let input = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../descriptors/shells/observable.shell"
        ))
        .unwrap();
        let shell = parse_shell(&input).unwrap();
        assert_eq!(shell.name, "observable");
        assert_eq!(shell.module_path.as_deref(), Some("uor::observable"));

        let code = emit_all(&shell).to_string();
        // Resolver trait with multi-param signature
        assert!(code.contains("trait PathResolver"));
        assert!(code.contains("fn winding"));
        assert!(code.contains("fn total_variation"));
        assert!(code.contains("fn cascade_spectrum"));
        // Uses uor::observable module path (not uor::lut)
        assert!(code.contains("uor :: observable :: winding_number"));
        assert!(code.contains("uor :: observable :: total_variation"));
        assert!(code.contains("uor :: observable :: cascade_spectrum"));
        // DTO struct
        assert!(code.contains("pub struct PathDto"));
        // i64 return type for winding
        assert!(code.contains("i64"));
        // List param generates &[u64] in resolver and Vec<u64> in struct
        assert!(code.contains("& [u64]"));
        assert!(code.contains("Vec < u64 >"));
    }
}
