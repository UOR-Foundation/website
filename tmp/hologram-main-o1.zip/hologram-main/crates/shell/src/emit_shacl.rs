//! SHACL code generation from parsed shapes.
//!
//! Transforms [`ShaclShape`] AST nodes into Rust source code:
//! - Typed DTO structs with serde derives
//! - `validate()` methods enforcing SHACL constraints
//! - `TryFrom<serde_json::Value>` implementations
//! - Enum types for `sh:in` constraints

use proc_macro2::{Ident, Span, TokenStream};
use quote::quote;

use crate::ast::{ShaclProperty, ShaclShape, XsdType};
use crate::naming::to_pascal_case;

// ============================================================================
// Configuration
// ============================================================================

/// Configuration for SHACL code emission.
#[derive(Debug, Clone, Default)]
pub struct EmitConfig {
    /// Shapes whose target class maps to an existing Rust type.
    /// These get a validator function instead of a new struct.
    pub existing_types: Vec<ExistingTypeMapping>,
}

/// Maps a SHACL target class to a pre-existing Rust type.
#[derive(Debug, Clone)]
pub struct ExistingTypeMapping {
    /// Target class local name (e.g., "Q1Datum").
    pub target_class: String,
    /// Rust type name (e.g., "Datum16").
    pub rust_type: String,
    /// Field mappings: (shacl_name, accessor).
    pub field_map: Vec<(String, FieldAccessor)>,
}

/// How to access a value on an existing Rust type.
#[derive(Debug, Clone)]
pub enum FieldAccessor {
    /// Direct field access: `value.field_name`
    Field(String),
    /// Method call: `value.method_name()`
    Method(String),
}

fn ident(s: &str) -> Ident {
    Ident::new(s, Span::call_site())
}

/// Generate tokens for accessing a value via a `FieldAccessor`.
fn accessor_tokens(accessor: &FieldAccessor) -> TokenStream {
    match accessor {
        FieldAccessor::Field(name) => {
            let id = ident(name);
            quote!(#id)
        }
        FieldAccessor::Method(name) => {
            let id = ident(name);
            quote!(#id())
        }
    }
}

// ============================================================================
// Type mapping
// ============================================================================

/// Map an XSD type to Rust type tokens.
fn xsd_to_rust_type(xsd: Option<XsdType>) -> TokenStream {
    match xsd {
        Some(XsdType::UnsignedShort) => quote!(u16),
        Some(XsdType::UnsignedByte) => quote!(u8),
        Some(XsdType::UnsignedInt) => quote!(u32),
        Some(XsdType::HexBinary) => quote!(String),
        Some(XsdType::String) | Some(XsdType::DateTime) => quote!(String),
        Some(XsdType::NonNegativeInteger) | Some(XsdType::PositiveInteger) => quote!(u64),
        Some(XsdType::Integer) => quote!(i64),
        Some(XsdType::Double) => quote!(f64),
        Some(XsdType::Boolean) => quote!(bool),
        None => quote!(serde_json::Value),
    }
}

/// Whether a property is required (minCount >= 1 and maxCount == 1).
fn is_required_single(prop: &ShaclProperty) -> bool {
    prop.min_count.unwrap_or(0) >= 1 && prop.max_count == Some(1)
}

/// Determine the Rust field type for a SHACL property.
fn field_type_tokens(prop: &ShaclProperty) -> TokenStream {
    let base = xsd_to_rust_type(prop.datatype);
    if is_required_single(prop) {
        base
    } else if prop.min_count.unwrap_or(0) >= 1 {
        // Required but no max — use base type (Value can represent arrays)
        base
    } else {
        quote!(Option<#base>)
    }
}

/// Check if a property has an `sh:in` constraint (generates an enum).
fn has_in_constraint(prop: &ShaclProperty) -> bool {
    prop.in_values.as_ref().is_some_and(|v| !v.is_empty())
}

// ============================================================================
// ShaclViolation preamble
// ============================================================================

/// Emit the `ShaclViolation` type (generated once).
fn emit_violation_type() -> TokenStream {
    quote! {
        /// A single SHACL constraint violation.
        #[derive(Debug, Clone, PartialEq)]
        pub struct ShaclViolation {
            /// The property that violated a constraint.
            pub property: &'static str,
            /// Human-readable description of the violation.
            pub message: String,
        }

        impl std::fmt::Display for ShaclViolation {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(f, "{}: {}", self.property, self.message)
            }
        }
    }
}

// ============================================================================
// Enum generation
// ============================================================================

/// Emit an enum for a property with `sh:in` constraint.
fn emit_enum(shape_name: &str, prop: &ShaclProperty) -> TokenStream {
    let values = match &prop.in_values {
        Some(v) => v,
        None => return quote!(),
    };

    let enum_name = ident(&format!(
        "{}{}",
        strip_shape_suffix(shape_name),
        to_pascal_case(&prop.name)
    ));

    let variants: Vec<TokenStream> = values
        .iter()
        .map(|v| {
            let variant = ident(&to_pascal_case(v));
            let lit = v.as_str();
            quote! {
                #[serde(rename = #lit)]
                #variant
            }
        })
        .collect();

    let from_str_arms: Vec<TokenStream> = values
        .iter()
        .map(|v| {
            let variant = ident(&to_pascal_case(v));
            let lit = v.as_str();
            quote!(#lit => Ok(#enum_name::#variant))
        })
        .collect();

    let display_arms: Vec<TokenStream> = values
        .iter()
        .map(|v| {
            let variant = ident(&to_pascal_case(v));
            let lit = v.as_str();
            quote!(#enum_name::#variant => write!(f, #lit))
        })
        .collect();

    quote! {
        #[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
        pub enum #enum_name {
            #(#variants),*
        }

        impl std::str::FromStr for #enum_name {
            type Err = String;
            fn from_str(s: &str) -> Result<Self, String> {
                match s {
                    #(#from_str_arms,)*
                    _ => Err(format!("unknown {}: {}", stringify!(#enum_name), s)),
                }
            }
        }

        impl std::fmt::Display for #enum_name {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                match self {
                    #(#display_arms),*
                }
            }
        }
    }
}

// ============================================================================
// Struct generation
// ============================================================================

/// Strip "Shape" suffix from shape name for struct naming.
fn strip_shape_suffix(name: &str) -> &str {
    name.strip_suffix("Shape").unwrap_or(name)
}

/// Get the snake_case Rust field name for a SHACL property.
fn rust_field_name(prop: &ShaclProperty) -> String {
    to_snake_case(&prop.name)
}

/// Whether a property name needs a serde rename (camelCase → snake_case).
fn needs_rename(prop: &ShaclProperty) -> bool {
    prop.name != rust_field_name(prop)
}

/// Emit a DTO struct for a shape.
fn emit_struct(shape: &ShaclShape) -> TokenStream {
    let struct_name = ident(&format!("{}Dto", strip_shape_suffix(&shape.name)));
    let doc = &shape.comment;

    let fields: Vec<TokenStream> = shape
        .properties
        .iter()
        .map(|prop| {
            let field_name = ident(&rust_field_name(prop));
            let field_ty = if has_in_constraint(prop) {
                let enum_name = ident(&format!(
                    "{}{}",
                    strip_shape_suffix(&shape.name),
                    to_pascal_case(&prop.name)
                ));
                quote!(#enum_name)
            } else {
                field_type_tokens(prop)
            };
            if needs_rename(prop) {
                let original = prop.name.as_str();
                quote! {
                    #[serde(rename = #original)]
                    pub #field_name: #field_ty
                }
            } else {
                quote!(pub #field_name: #field_ty)
            }
        })
        .collect();

    quote! {
        #[doc = #doc]
        #[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
        pub struct #struct_name {
            #(#fields),*
        }
    }
}

// ============================================================================
// Validate generation
// ============================================================================

/// Emit a single validation check for a property.
fn emit_property_validation(prop: &ShaclProperty) -> Vec<TokenStream> {
    let mut checks = Vec::new();
    let field = ident(&rust_field_name(prop));
    let name_lit = prop.name.as_str();

    // sh:in is enforced by the enum type — no runtime check needed
    if has_in_constraint(prop) {
        return checks;
    }

    // Positive integer check (must be > 0)
    if prop.datatype == Some(XsdType::PositiveInteger) {
        checks.push(quote! {
            if self.#field == 0 {
                violations.push(ShaclViolation {
                    property: #name_lit,
                    message: "must be a positive integer (> 0)".into(),
                });
            }
        });
    }

    // Range checks
    if let Some(min) = prop.min_inclusive {
        // Only emit if the minimum is meaningful for the type
        if min > 0 || prop.datatype == Some(XsdType::Integer) {
            checks.push(quote! {
                if (self.#field as i64) < #min {
                    violations.push(ShaclViolation {
                        property: #name_lit,
                        message: format!("must be >= {}", #min),
                    });
                }
            });
        }
    }

    if let Some(max) = prop.max_inclusive {
        checks.push(quote! {
            if (self.#field as i64) > #max {
                violations.push(ShaclViolation {
                    property: #name_lit,
                    message: format!("must be <= {}", #max),
                });
            }
        });
    }

    // String length checks (sh:minLength / sh:maxLength)
    if let Some(min_len) = prop.min_length {
        let min_len = min_len as usize;
        checks.push(quote! {
            if self.#field.len() < #min_len {
                violations.push(ShaclViolation {
                    property: #name_lit,
                    message: format!("length must be >= {}", #min_len),
                });
            }
        });
    }

    if let Some(max_len) = prop.max_length {
        let max_len = max_len as usize;
        checks.push(quote! {
            if self.#field.len() > #max_len {
                violations.push(ShaclViolation {
                    property: #name_lit,
                    message: format!("length must be <= {}", #max_len),
                });
            }
        });
    }

    checks
}

/// Emit a `validate()` method for a DTO struct.
fn emit_validate(shape: &ShaclShape) -> TokenStream {
    let struct_name = ident(&format!("{}Dto", strip_shape_suffix(&shape.name)));

    let all_checks: Vec<TokenStream> = shape
        .properties
        .iter()
        .flat_map(emit_property_validation)
        .collect();

    if all_checks.is_empty() {
        return quote! {
            impl #struct_name {
                /// Validate this instance against SHACL constraints.
                pub fn validate(&self) -> Result<(), Vec<ShaclViolation>> {
                    Ok(())
                }
            }
        };
    }

    quote! {
        impl #struct_name {
            /// Validate this instance against SHACL constraints.
            #[allow(clippy::possible_missing_else)]
            pub fn validate(&self) -> Result<(), Vec<ShaclViolation>> {
                let mut violations = Vec::new();
                #(#all_checks)*
                if violations.is_empty() { Ok(()) } else { Err(violations) }
            }
        }
    }
}

// ============================================================================
// TryFrom<serde_json::Value> generation
// ============================================================================

/// Emit a JSON field extraction expression for a property.
fn emit_field_extraction(prop: &ShaclProperty, prefix: &str) -> TokenStream {
    let field_name = ident(&rust_field_name(prop));
    let json_key = format!("{}{}", prefix, prop.name);

    if has_in_constraint(prop) {
        return quote! {
            let #field_name = obj.get(#json_key)
                .and_then(|v| v.as_str())
                .ok_or_else(|| format!("missing or invalid field: {}", #json_key))?
                .parse()
                .map_err(|e: String| e)?;
        };
    }

    match prop.datatype {
        Some(XsdType::UnsignedShort) => quote! {
            let #field_name = obj.get(#json_key)
                .and_then(|v| v.as_u64())
                .ok_or_else(|| format!("missing field: {}", #json_key))? as u16;
        },
        Some(XsdType::UnsignedByte) => quote! {
            let #field_name = obj.get(#json_key)
                .and_then(|v| v.as_u64())
                .ok_or_else(|| format!("missing field: {}", #json_key))? as u8;
        },
        Some(XsdType::UnsignedInt) => quote! {
            let #field_name = obj.get(#json_key)
                .and_then(|v| v.as_u64())
                .ok_or_else(|| format!("missing field: {}", #json_key))? as u32;
        },
        Some(XsdType::HexBinary) => quote! {
            let #field_name = obj.get(#json_key)
                .and_then(|v| v.as_str())
                .ok_or_else(|| format!("missing field: {}", #json_key))?
                .to_string();
        },
        Some(XsdType::NonNegativeInteger) | Some(XsdType::PositiveInteger) => quote! {
            let #field_name = obj.get(#json_key)
                .and_then(|v| v.as_u64())
                .ok_or_else(|| format!("missing field: {}", #json_key))?;
        },
        Some(XsdType::Integer) => quote! {
            let #field_name = obj.get(#json_key)
                .and_then(|v| v.as_i64())
                .ok_or_else(|| format!("missing field: {}", #json_key))?;
        },
        Some(XsdType::Double) => quote! {
            let #field_name = obj.get(#json_key)
                .and_then(|v| v.as_f64())
                .ok_or_else(|| format!("missing field: {}", #json_key))?;
        },
        Some(XsdType::Boolean) => quote! {
            let #field_name = obj.get(#json_key)
                .and_then(|v| v.as_bool())
                .ok_or_else(|| format!("missing field: {}", #json_key))?;
        },
        Some(XsdType::String) | Some(XsdType::DateTime) => quote! {
            let #field_name = obj.get(#json_key)
                .and_then(|v| v.as_str())
                .ok_or_else(|| format!("missing field: {}", #json_key))?
                .to_string();
        },
        None => quote! {
            let #field_name = obj.get(#json_key)
                .cloned()
                .unwrap_or(serde_json::Value::Null);
        },
    }
}

/// Emit `TryFrom<serde_json::Value>` for a DTO struct.
fn emit_try_from(shape: &ShaclShape, json_prefix: &str) -> TokenStream {
    let struct_name = ident(&format!("{}Dto", strip_shape_suffix(&shape.name)));

    let extractions: Vec<TokenStream> = shape
        .properties
        .iter()
        .map(|p| emit_field_extraction(p, json_prefix))
        .collect();

    let field_names: Vec<Ident> = shape
        .properties
        .iter()
        .map(|p| ident(&rust_field_name(p)))
        .collect();

    quote! {
        impl TryFrom<serde_json::Value> for #struct_name {
            type Error = String;

            fn try_from(value: serde_json::Value) -> Result<Self, String> {
                let obj = value.as_object()
                    .ok_or_else(|| "expected JSON object".to_string())?;
                #(#extractions)*
                Ok(Self { #(#field_names),* })
            }
        }

        impl TryFrom<&serde_json::Value> for #struct_name {
            type Error = String;

            fn try_from(value: &serde_json::Value) -> Result<Self, String> {
                let obj = value.as_object()
                    .ok_or_else(|| "expected JSON object".to_string())?;
                #(#extractions)*
                Ok(Self { #(#field_names),* })
            }
        }
    }
}

// ============================================================================
// Existing-type validator generation
// ============================================================================

/// Emit a freestanding validator for an existing type (e.g., Datum16).
fn emit_existing_type_validator(shape: &ShaclShape, mapping: &ExistingTypeMapping) -> TokenStream {
    let fn_name = ident(&format!(
        "validate_{}",
        to_snake_case(strip_shape_suffix(&shape.name))
    ));
    let rust_type = ident(&mapping.rust_type);

    let checks: Vec<TokenStream> = shape
        .properties
        .iter()
        .filter_map(|prop| {
            let accessor = mapping
                .field_map
                .iter()
                .find(|(n, _)| n == &prop.name)
                .map(|(_, a)| a)?;
            let access_expr = accessor_tokens(accessor);
            let name_lit = prop.name.as_str();

            let mut checks = Vec::new();

            if let Some(min) = prop.min_inclusive {
                if min > 0 {
                    checks.push(quote! {
                        if (value.#access_expr as i64) < #min {
                            violations.push(ShaclViolation {
                                property: #name_lit,
                                message: format!("must be >= {}", #min),
                            });
                        }
                    });
                }
            }

            if let Some(max) = prop.max_inclusive {
                checks.push(quote! {
                    if (value.#access_expr as i64) > #max {
                        violations.push(ShaclViolation {
                            property: #name_lit,
                            message: format!("must be <= {}", #max),
                        });
                    }
                });
            }

            if checks.is_empty() {
                None
            } else {
                Some(quote!(#(#checks)*))
            }
        })
        .collect();

    quote! {
        /// Validate an existing value against SHACL constraints.
        #[allow(clippy::possible_missing_else)]
        pub fn #fn_name(value: &#rust_type) -> Result<(), Vec<ShaclViolation>> {
            let mut violations = Vec::new();
            #(#checks)*
            if violations.is_empty() { Ok(()) } else { Err(violations) }
        }
    }
}

/// Convert PascalCase or mixed to snake_case.
fn to_snake_case(s: &str) -> String {
    let mut result = String::new();
    for (i, ch) in s.chars().enumerate() {
        if ch.is_uppercase() {
            if i > 0 {
                result.push('_');
            }
            result.push(ch.to_lowercase().next().unwrap());
        } else {
            result.push(ch);
        }
    }
    result
}

// ============================================================================
// Top-level emission
// ============================================================================

/// Derive the JSON-LD prefix for a shape based on its target class pattern.
fn json_prefix_for_shape(shape: &ShaclShape) -> &str {
    let name = shape.target_class.as_str();
    if name.starts_with("Q1") || name.starts_with("Datum") {
        "datum:"
    } else if name.contains("Derivation") || name.contains("Factorization") {
        "derivation:"
    } else if name.contains("Observable")
        || name.contains("Winding")
        || name.contains("Variation")
        || name.contains("Spectrum")
        || name.contains("Monodromy")
        || name.contains("Cascade")
    {
        "observable:"
    } else if name.contains("BlockHeader")
        || name.contains("MiningConfig")
        || name.contains("MiningResult")
    {
        "mining:"
    } else {
        ""
    }
}

/// Emit the `ShaclViolation` preamble (call once per output file).
pub fn emit_preamble() -> String {
    emit_violation_type().to_string()
}

/// Emit generated code for a list of SHACL shapes (without preamble).
pub fn emit_all(shapes: &[ShaclShape], config: &EmitConfig) -> String {
    let mut tokens = TokenStream::new();

    for shape in shapes {
        // Check if this shape maps to an existing type
        let existing = config
            .existing_types
            .iter()
            .find(|m| m.target_class == shape.target_class);

        if let Some(mapping) = existing {
            tokens.extend(emit_existing_type_validator(shape, mapping));
            continue;
        }

        // Emit enums for sh:in properties
        for prop in &shape.properties {
            if has_in_constraint(prop) {
                tokens.extend(emit_enum(&shape.name, prop));
            }
        }

        // Emit struct
        tokens.extend(emit_struct(shape));

        // Emit validate()
        tokens.extend(emit_validate(shape));

        // Emit TryFrom
        let prefix = json_prefix_for_shape(shape);
        tokens.extend(emit_try_from(shape, prefix));
    }

    tokens.to_string()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ast::ShaclProperty;

    fn make_simple_shape() -> ShaclShape {
        ShaclShape {
            name: "WindingNumberShape".into(),
            target_class: "WindingNumber".into(),
            label: "Winding Number Shape".into(),
            comment: "Validates WindingNumber observable".into(),
            properties: vec![ShaclProperty {
                name: "value".into(),
                path: "value".into(),
                datatype: Some(XsdType::Integer),
                min_count: Some(1),
                max_count: Some(1),
                min_inclusive: None,
                max_inclusive: None,
                in_values: None,
                min_length: None,
                max_length: None,
            }],
        }
    }

    fn make_range_shape() -> ShaclShape {
        ShaclShape {
            name: "TestShape".into(),
            target_class: "Test".into(),
            label: "Test".into(),
            comment: "Test shape".into(),
            properties: vec![ShaclProperty {
                name: "score".into(),
                path: "score".into(),
                datatype: Some(XsdType::UnsignedByte),
                min_count: Some(1),
                max_count: Some(1),
                min_inclusive: Some(1),
                max_inclusive: Some(100),
                in_values: None,
                min_length: None,
                max_length: None,
            }],
        }
    }

    fn make_enum_shape() -> ShaclShape {
        ShaclShape {
            name: "StepShape".into(),
            target_class: "Step".into(),
            label: "Step".into(),
            comment: "Step shape".into(),
            properties: vec![ShaclProperty {
                name: "kind".into(),
                path: "kind".into(),
                datatype: None,
                min_count: Some(1),
                max_count: Some(1),
                min_inclusive: None,
                max_inclusive: None,
                in_values: Some(vec!["alpha".into(), "beta".into()]),
                min_length: None,
                max_length: None,
            }],
        }
    }

    #[test]
    fn emit_simple_struct_contains_field() {
        let shape = make_simple_shape();
        let code = emit_struct(&shape).to_string();
        assert!(code.contains("WindingNumberDto"));
        assert!(code.contains("value"));
        assert!(code.contains("i64"));
    }

    #[test]
    fn emit_range_validation_checks() {
        let shape = make_range_shape();
        let code = emit_validate(&shape).to_string();
        assert!(code.contains("score"));
        assert!(code.contains("violations"));
    }

    #[test]
    fn emit_enum_from_in_values() {
        let shape = make_enum_shape();
        let prop = &shape.properties[0];
        let code = emit_enum(&shape.name, prop).to_string();
        assert!(code.contains("StepKind"));
        assert!(code.contains("Alpha"));
        assert!(code.contains("Beta"));
    }

    #[test]
    fn emit_preamble_produces_violation_type() {
        let code = emit_preamble();
        assert!(code.contains("ShaclViolation"));
        assert!(code.contains("property"));
        assert!(code.contains("message"));
    }

    #[test]
    fn strip_shape_suffix_works() {
        assert_eq!(strip_shape_suffix("Q1DatumShape"), "Q1Datum");
        assert_eq!(strip_shape_suffix("WindingNumberShape"), "WindingNumber");
        assert_eq!(strip_shape_suffix("NoSuffix"), "NoSuffix");
    }

    #[test]
    fn to_snake_case_works() {
        assert_eq!(to_snake_case("Q1Datum"), "q1_datum");
        assert_eq!(to_snake_case("WindingNumber"), "winding_number");
        assert_eq!(to_snake_case("DerivationStep"), "derivation_step");
    }
}
