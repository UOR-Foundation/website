//! In-memory schema store with indices for fast lookup.

use crate::error::{Result, ServerError};
use crate::schema::loader::LoadedSchemas;
use crate::schema::model::{
    CascadeEffect, Constant, DomainDto, GaugeLevel, GaugeTower, ListResponse, MutationPreview,
    SchemaEntity, SchemaInfo, TaxonDto,
};
use parking_lot::RwLock;
use std::collections::HashMap;

/// In-memory schema store.
pub struct SchemaStore {
    // Raw JSON values
    pub uor_context: serde_json::Value,
    pub uor_schema: serde_json::Value,
    pub hologram: serde_json::Value,

    // Indexed data
    taxons: Vec<TaxonDto>,
    taxons_by_value: HashMap<u8, usize>,
    taxons_by_domain: HashMap<String, Vec<usize>>,
    domains: Vec<DomainDto>,
    domains_by_name: HashMap<String, usize>,
    gauge_tower: GaugeTower,

    // Mutable state
    constants: RwLock<HashMap<String, Constant>>,
    original_constants: HashMap<String, Constant>,
}

impl SchemaStore {
    /// Create store from loaded schemas.
    pub fn new(loaded: LoadedSchemas) -> Self {
        let mut taxons_by_value = HashMap::new();
        let mut taxons_by_domain: HashMap<String, Vec<usize>> = HashMap::new();

        for (i, taxon) in loaded.taxons.iter().enumerate() {
            taxons_by_value.insert(taxon.value, i);
            taxons_by_domain
                .entry(taxon.domain.clone())
                .or_default()
                .push(i);
        }

        let mut domains_by_name = HashMap::new();
        for (i, domain) in loaded.domains.iter().enumerate() {
            domains_by_name.insert(domain.name.clone(), i);
        }

        let constants: HashMap<String, Constant> = loaded
            .constants
            .iter()
            .map(|c| (c.name.clone(), c.clone()))
            .collect();

        Self {
            uor_context: loaded.uor_context,
            uor_schema: loaded.uor_schema,
            hologram: loaded.hologram,
            taxons: loaded.taxons,
            taxons_by_value,
            taxons_by_domain,
            domains: loaded.domains,
            domains_by_name,
            gauge_tower: loaded.gauge_tower,
            original_constants: constants.clone(),
            constants: RwLock::new(constants),
        }
    }

    /// List all available schemas.
    pub fn list_schemas(&self) -> Vec<SchemaInfo> {
        vec![
            SchemaInfo {
                id: "uor".to_string(),
                name: "UOR Schema".to_string(),
                description: "Core UOR schema context".to_string(),
                entity_count: 3, // Taxon, Domain, Word
            },
            SchemaInfo {
                id: "uor-schema".to_string(),
                name: "UOR JSON Schema".to_string(),
                description: "JSON Schema validator for UOR types".to_string(),
                entity_count: 0,
            },
            SchemaInfo {
                id: "catalog".to_string(),
                name: "Taxon Catalog".to_string(),
                description: "Complete catalog of 256 taxons".to_string(),
                entity_count: 256,
            },
            SchemaInfo {
                id: "hologram".to_string(),
                name: "Hologram Ontology".to_string(),
                description: "Comprehensive categorical ontology".to_string(),
                entity_count: self
                    .hologram
                    .get("@graph")
                    .and_then(|g| g.as_array())
                    .map(|a| a.len())
                    .unwrap_or(0),
            },
        ]
    }

    /// Get schema by ID.
    pub fn get_schema(&self, id: &str) -> Result<&serde_json::Value> {
        match id {
            "uor" => Ok(&self.uor_context),
            "uor-schema" => Ok(&self.uor_schema),
            "hologram" => Ok(&self.hologram),
            _ => Err(ServerError::SchemaNotFound(id.to_string())),
        }
    }

    /// Get schema context.
    pub fn get_schema_context(&self, id: &str) -> Result<serde_json::Value> {
        let schema = self.get_schema(id)?;
        Ok(schema
            .get("@context")
            .cloned()
            .unwrap_or(serde_json::Value::Null))
    }

    /// Get schema graph entities.
    pub fn get_schema_graph(&self, id: &str) -> Result<Vec<SchemaEntity>> {
        let schema = self.get_schema(id)?;
        let graph = schema
            .get("@graph")
            .and_then(|g| g.as_array())
            .cloned()
            .unwrap_or_default();

        let entities: Vec<SchemaEntity> = graph
            .into_iter()
            .filter_map(|v| serde_json::from_value(v).ok())
            .collect();

        Ok(entities)
    }

    /// List all taxons with pagination.
    pub fn list_taxons(&self, offset: usize, limit: usize) -> ListResponse<TaxonDto> {
        let total = self.taxons.len();
        let items: Vec<TaxonDto> = self
            .taxons
            .iter()
            .skip(offset)
            .take(limit)
            .cloned()
            .collect();
        ListResponse::new(items, total, offset, limit)
    }

    /// Get taxon by value.
    pub fn get_taxon(&self, value: u8) -> Result<TaxonDto> {
        self.taxons_by_value
            .get(&value)
            .and_then(|&i| self.taxons.get(i))
            .cloned()
            .ok_or(ServerError::TaxonNotFound(value))
    }

    /// Get taxons by domain.
    pub fn get_taxons_by_domain(&self, domain: &str) -> Result<Vec<TaxonDto>> {
        let indices = self
            .taxons_by_domain
            .get(domain)
            .ok_or_else(|| ServerError::DomainNotFound(domain.to_string()))?;
        Ok(indices
            .iter()
            .filter_map(|&i| self.taxons.get(i).cloned())
            .collect())
    }

    /// List all domains.
    pub fn list_domains(&self) -> Vec<DomainDto> {
        self.domains.clone()
    }

    /// Get domain by name.
    pub fn get_domain(&self, name: &str) -> Result<DomainDto> {
        self.domains_by_name
            .get(name)
            .and_then(|&i| self.domains.get(i))
            .cloned()
            .ok_or_else(|| ServerError::DomainNotFound(name.to_string()))
    }

    /// List all constants.
    pub fn list_constants(&self) -> Vec<Constant> {
        self.constants.read().values().cloned().collect()
    }

    /// Get constant by name.
    pub fn get_constant(&self, name: &str) -> Result<Constant> {
        self.constants
            .read()
            .get(name)
            .cloned()
            .ok_or_else(|| ServerError::ConstantNotFound(name.to_string()))
    }

    /// Update a constant value.
    pub fn update_constant(&self, name: &str, new_value: i64) -> Result<MutationPreview> {
        let mut constants = self.constants.write();
        let constant = constants
            .get(name)
            .ok_or_else(|| ServerError::ConstantNotFound(name.to_string()))?;

        if !constant.is_mutable {
            return Err(ServerError::ImmutableConstant(name.to_string()));
        }

        let old_value = constant.value;
        let cascade = self.compute_cascade(name, new_value, &constants);

        // Apply mutation
        if let Some(c) = constants.get_mut(name) {
            c.value = new_value;
        }

        // Apply cascade effects
        for effect in &cascade {
            if let Some(c) = constants.get_mut(&effect.constant) {
                c.value = effect.new_value;
            }
        }

        Ok(MutationPreview {
            target: name.to_string(),
            old_value,
            new_value,
            cascade,
        })
    }

    /// Preview mutation without applying.
    pub fn preview_mutation(&self, name: &str, new_value: i64) -> Result<MutationPreview> {
        let constants = self.constants.read();
        let constant = constants
            .get(name)
            .ok_or_else(|| ServerError::ConstantNotFound(name.to_string()))?;

        if !constant.is_mutable {
            return Err(ServerError::ImmutableConstant(name.to_string()));
        }

        let old_value = constant.value;
        let cascade = self.compute_cascade(name, new_value, &constants);

        Ok(MutationPreview {
            target: name.to_string(),
            old_value,
            new_value,
            cascade,
        })
    }

    /// Reset all constants to original values.
    pub fn reset_constants(&self) {
        let mut constants = self.constants.write();
        *constants = self.original_constants.clone();
    }

    /// Compute cascade effects of a mutation.
    fn compute_cascade(
        &self,
        name: &str,
        new_value: i64,
        constants: &HashMap<String, Constant>,
    ) -> Vec<CascadeEffect> {
        let mut effects = Vec::new();

        // Create a temporary values map
        let mut values: HashMap<String, i64> = constants
            .iter()
            .map(|(k, c)| (k.clone(), c.value))
            .collect();
        values.insert(name.to_string(), new_value);

        // Helper to get value
        let get = |values: &HashMap<String, i64>, n: &str| *values.get(n).unwrap_or(&0);

        // Derivation order matters: T -> O -> B -> R
        let derivations = [
            ("T", "U + D"),
            ("O", "D^T"),
            ("B", "2^(O-T)"),
            ("R", "T * B"),
        ];

        for (derived_name, _formula) in derivations {
            if derived_name == name {
                continue; // Skip the one being mutated
            }
            if let Some(constant) = constants.get(derived_name) {
                if constant.is_mutable {
                    let computed = match derived_name {
                        "T" => get(&values, "U") + get(&values, "D"),
                        "O" => get(&values, "D").pow(get(&values, "T") as u32),
                        "B" => 2_i64.pow((get(&values, "O") - get(&values, "T")) as u32),
                        "R" => get(&values, "T") * get(&values, "B"),
                        _ => continue,
                    };
                    if computed != constant.value {
                        effects.push(CascadeEffect {
                            constant: derived_name.to_string(),
                            old_value: constant.value,
                            new_value: computed,
                        });
                        // Update values for subsequent derivations
                        values.insert(derived_name.to_string(), computed);
                    }
                }
            }
        }

        effects
    }

    /// Get the gauge tower.
    pub fn get_gauge_tower(&self) -> GaugeTower {
        self.gauge_tower.clone()
    }

    /// Get a specific gauge level.
    pub fn get_gauge_level(&self, index: usize) -> Result<GaugeLevel> {
        self.gauge_tower
            .levels
            .get(index)
            .cloned()
            .ok_or(ServerError::GaugeLevelNotFound(index))
    }
}
