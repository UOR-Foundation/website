//! Error types for the categorical-codec crate.

use std::fmt;

/// Errors that can occur during codec operations.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CodecError {
    /// Error during encoding.
    Encode { message: String },

    /// Error during decoding.
    Decode { message: String },

    /// Value exceeds precision limits.
    PrecisionOverflow { required: u64, max: u64 },

    /// Invalid input data.
    InvalidInput { message: String },
}

impl fmt::Display for CodecError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CodecError::Encode { message } => write!(f, "encoding error: {}", message),
            CodecError::Decode { message } => write!(f, "decoding error: {}", message),
            CodecError::PrecisionOverflow { required, max } => {
                write!(
                    f,
                    "precision overflow: value requires {} bits but max is {}",
                    required, max
                )
            }
            CodecError::InvalidInput { message } => write!(f, "invalid input: {}", message),
        }
    }
}

impl std::error::Error for CodecError {}

impl CodecError {
    /// Create an encoding error with the given message.
    #[must_use]
    pub fn encode(message: impl Into<String>) -> Self {
        Self::Encode {
            message: message.into(),
        }
    }

    /// Create a decoding error with the given message.
    #[must_use]
    pub fn decode(message: impl Into<String>) -> Self {
        Self::Decode {
            message: message.into(),
        }
    }

    /// Create an invalid input error with the given message.
    #[must_use]
    pub fn invalid_input(message: impl Into<String>) -> Self {
        Self::InvalidInput {
            message: message.into(),
        }
    }
}
