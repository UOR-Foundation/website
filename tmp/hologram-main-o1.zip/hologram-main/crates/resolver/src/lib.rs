//! SHA-256 Reversible Compression Resolver
//!
//! This crate implements the forward and inverse resolvers for the UOR
//! reversible compression scheme:
//!
//! - `compress()`: TypedDatum → CompressedReference
//! - `decompress()`: CompressedReference → TypedDatum (when entropy < 256 bits)
//!
//! The key insight: SHA-256 becomes reversible when type information constrains
//! the variety to fewer than 2^256 possible values.
//!
//! # Feasibility Thresholds
//!
//! | Effective Entropy H | Variety Size 2^H | Feasibility                |
//! |---------------------|------------------|----------------------------|
//! | < 40 bits           | < 10¹²           | Trivially feasible         |
//! | 40–80 bits          | 10¹² – 10²⁴      | Feasible with parallelism  |
//! | 80–128 bits         | 10²⁴ – 10³⁸      | Feasible with compute      |
//! | > 128 bits          | > 10³⁸           | Impractical                |
//!
//! # Generated Types
//!
//! Type metadata is generated from `uor-foundation.jsonld` at build time.
//! See the `generated` module for schema-derived constants.

use hologram_sha256::Sha256;
use std::fmt;
use thiserror::Error;

// Include generated code from build.rs
mod generated {
    include!(concat!(env!("OUT_DIR"), "/generated_types.rs"));
}

pub use generated::*;

/// A datum paired with its type declaration.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TypedDatum {
    /// The type declaration (e.g., "application/json", "text/plain;charset=utf-8").
    pub type_declaration: String,
    /// The raw datum bytes.
    pub data: Vec<u8>,
}

impl TypedDatum {
    /// Create a new typed datum.
    #[must_use]
    pub fn new(type_declaration: impl Into<String>, data: impl Into<Vec<u8>>) -> Self {
        Self {
            type_declaration: type_declaration.into(),
            data: data.into(),
        }
    }

    /// Get the size of the datum in bytes.
    #[must_use]
    pub fn size(&self) -> usize {
        self.data.len()
    }
}

/// A 256-bit SHA-256 digest.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct HashDigest(pub [u8; 32]);

impl HashDigest {
    /// Create a digest from raw bytes.
    #[must_use]
    pub const fn from_bytes(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }

    /// Get the digest as a byte slice.
    #[must_use]
    pub const fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }

    /// Convert to hex string.
    #[must_use]
    pub fn to_hex(&self) -> String {
        self.0.iter().map(|b| format!("{b:02x}")).collect()
    }
}

impl fmt::Display for HashDigest {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.to_hex())
    }
}

impl From<[u8; 32]> for HashDigest {
    fn from(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }
}

impl From<HashDigest> for [u8; 32] {
    fn from(digest: HashDigest) -> [u8; 32] {
        digest.0
    }
}

/// A compressed reference: type declaration + hash digest.
///
/// Sufficient to reconstruct the original datum when the type's
/// effective entropy is below 256 bits.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CompressedReference {
    /// The type declaration (serves as the decompressor model).
    pub type_declaration: String,
    /// The SHA-256 digest (serves as the residual instance selector).
    pub digest: HashDigest,
}

impl CompressedReference {
    /// Create a new compressed reference.
    #[must_use]
    pub fn new(type_declaration: impl Into<String>, digest: HashDigest) -> Self {
        Self {
            type_declaration: type_declaration.into(),
            digest,
        }
    }

    /// Get the size of the compressed reference in bytes.
    ///
    /// Size = type declaration length + 32 bytes for the digest.
    #[must_use]
    pub fn size(&self) -> usize {
        self.type_declaration.len() + 32
    }
}

/// Compression ratio observable.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct CompressionRatio {
    /// Original datum size in bytes.
    pub original_size: usize,
    /// Compressed reference size in bytes.
    pub compressed_size: usize,
    /// The ratio (original / compressed).
    pub ratio: f64,
}

impl CompressionRatio {
    /// Compute the compression ratio.
    #[must_use]
    pub fn compute(original_size: usize, compressed_size: usize) -> Self {
        let ratio = if compressed_size > 0 {
            original_size as f64 / compressed_size as f64
        } else {
            f64::INFINITY
        };
        Self {
            original_size,
            compressed_size,
            ratio,
        }
    }
}

impl fmt::Display for CompressionRatio {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{}:{} ({:.2}:1)",
            self.original_size, self.compressed_size, self.ratio
        )
    }
}

/// Result of a compression operation.
#[derive(Debug, Clone)]
pub struct CompressionResult {
    /// The compressed reference.
    pub reference: CompressedReference,
    /// The compression ratio observable.
    pub ratio: CompressionRatio,
}

/// A certificate attesting to a successful compression roundtrip.
///
/// This proves that `decompress(compress(datum)) == datum` for a specific
/// datum within a type variety.
#[derive(Debug, Clone)]
pub struct RoundtripCertificate {
    /// The original datum that was compressed and recovered.
    pub datum: TypedDatum,
    /// The compressed reference.
    pub reference: CompressedReference,
    /// The compression ratio achieved.
    pub ratio: CompressionRatio,
    /// The effective entropy of the type variety.
    pub effective_entropy: f64,
    /// Whether the roundtrip was verified.
    pub verified: bool,
}

impl RoundtripCertificate {
    /// Create a new certificate (unverified).
    fn new(
        datum: TypedDatum,
        reference: CompressedReference,
        ratio: CompressionRatio,
        effective_entropy: f64,
    ) -> Self {
        Self {
            datum,
            reference,
            ratio,
            effective_entropy,
            verified: false,
        }
    }

    /// Mark the certificate as verified.
    fn verify(mut self) -> Self {
        self.verified = true;
        self
    }
}

impl fmt::Display for RoundtripCertificate {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "RoundtripCertificate {{ type: {}, digest: {}, ratio: {}, entropy: {:.1} bits, verified: {} }}",
            self.datum.type_declaration,
            self.reference.digest,
            self.ratio,
            self.effective_entropy,
            self.verified
        )
    }
}

/// Perform a verified compression roundtrip.
///
/// Compresses the datum, then decompresses it using the variety, and verifies
/// that the result matches the original.
///
/// # Returns
///
/// A `RoundtripCertificate` if successful, or an error if:
/// - Entropy is too high for practical decompression
/// - The recovered datum doesn't match the original
///
/// # Example
///
/// ```
/// use hologram_resolver::{TypedDatum, ByteRangeVariety, roundtrip_verify};
///
/// let variety = ByteRangeVariety::single_byte(255);
/// let datum = TypedDatum::new("byte", vec![42]);
///
/// let cert = roundtrip_verify(&datum, &variety).unwrap();
/// assert!(cert.verified);
/// ```
pub fn roundtrip_verify<V: TypeVariety>(
    datum: &TypedDatum,
    variety: &V,
) -> Result<RoundtripCertificate, DecompressionError> {
    let entropy = variety.effective_entropy();

    // Compress
    let result = compress(datum);

    // Create initial certificate
    let cert = RoundtripCertificate::new(
        datum.clone(),
        result.reference.clone(),
        result.ratio,
        entropy,
    );

    // Decompress
    let recovered = decompress(&result.reference, variety)?;

    // Verify roundtrip
    if recovered.data == datum.data && recovered.type_declaration == datum.type_declaration {
        Ok(cert.verify())
    } else {
        Err(DecompressionError::NotFound {
            digest: result.reference.digest.to_hex(),
        })
    }
}

/// Compress a typed datum to a compressed reference.
///
/// This is the forward direction of the reversible compression resolver.
/// Always succeeds in O(n) time where n is the datum size.
///
/// # Example
///
/// ```
/// use hologram_resolver::{TypedDatum, compress};
///
/// let datum = TypedDatum::new("text/plain", b"hello world".to_vec());
/// let result = compress(&datum);
///
/// println!("Compressed: {}", result.reference.digest);
/// println!("Ratio: {}", result.ratio);
/// ```
#[must_use]
pub fn compress(datum: &TypedDatum) -> CompressionResult {
    // Compute SHA-256 of the data
    let hash = Sha256::digest(&datum.data);
    let digest = HashDigest::from_bytes(hash.into());

    // Create the compressed reference
    let reference = CompressedReference::new(&datum.type_declaration, digest);

    // Compute compression ratio
    let ratio = CompressionRatio::compute(datum.size(), reference.size());

    CompressionResult { reference, ratio }
}

// ============================================================================
// Decompression (Inverse Resolver)
// ============================================================================

/// Maximum effective entropy (in bits) for practical decompression.
///
/// Above this threshold, enumeration is impractical.
pub const MAX_PRACTICAL_ENTROPY: f64 = 128.0;

/// Maximum effective entropy (in bits) for trivial decompression.
///
/// Below this threshold, enumeration completes in seconds.
pub const TRIVIAL_ENTROPY_THRESHOLD: f64 = 40.0;

/// Error type for decompression operations.
#[derive(Debug, Error)]
pub enum DecompressionError {
    /// Entropy too high for practical enumeration.
    #[error("entropy too high: {entropy:.1} bits exceeds maximum {MAX_PRACTICAL_ENTROPY} bits")]
    EntropyTooHigh { entropy: f64 },

    /// No matching datum found in variety.
    #[error("no matching datum found for digest {digest}")]
    NotFound { digest: String },

    /// Invalid type variety (empty or malformed).
    #[error("invalid type variety: {reason}")]
    InvalidVariety { reason: String },
}

/// Enumeration strategy for hash inversion.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum EnumerationStrategy {
    /// Enumerate all members of the variety in order.
    #[default]
    ExhaustiveSequential,
    /// Use the type's grammar/schema to generate candidates.
    GrammarGuided,
    /// Use type constraints to prune the search space.
    ConstraintPropagation,
    /// Partition the variety across workers.
    ParallelPartition,
}

impl fmt::Display for EnumerationStrategy {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::ExhaustiveSequential => write!(f, "exhaustive_sequential"),
            Self::GrammarGuided => write!(f, "grammar_guided"),
            Self::ConstraintPropagation => write!(f, "constraint_propagation"),
            Self::ParallelPartition => write!(f, "parallel_partition"),
        }
    }
}

/// A type variety that can be enumerated for decompression.
///
/// Implement this trait for types that can generate all possible
/// values matching a type declaration.
pub trait TypeVariety {
    /// Iterator over all possible datum values for this type.
    type Iter: Iterator<Item = Vec<u8>>;

    /// Get the effective entropy of this type variety in bits.
    ///
    /// This is log₂ of the variety size.
    fn effective_entropy(&self) -> f64;

    /// Get the variety size (number of possible values).
    fn variety_size(&self) -> u64;

    /// Iterate over all possible values.
    fn enumerate(&self) -> Self::Iter;
}

/// A simple byte range variety for testing.
///
/// Represents all byte sequences of a fixed length with values in a range.
#[derive(Debug, Clone)]
pub struct ByteRangeVariety {
    /// Length of byte sequences.
    pub length: usize,
    /// Minimum value (inclusive).
    pub min: u8,
    /// Maximum value (inclusive).
    pub max: u8,
}

impl ByteRangeVariety {
    /// Create a new byte range variety.
    #[must_use]
    pub fn new(length: usize, min: u8, max: u8) -> Self {
        Self { length, min, max }
    }

    /// Create a variety for single bytes in range [0, max].
    #[must_use]
    pub fn single_byte(max: u8) -> Self {
        Self::new(1, 0, max)
    }
}

impl TypeVariety for ByteRangeVariety {
    type Iter = ByteRangeIterator;

    fn effective_entropy(&self) -> f64 {
        (self.variety_size() as f64).log2()
    }

    fn variety_size(&self) -> u64 {
        let range = (self.max as u64) - (self.min as u64) + 1;
        range.saturating_pow(self.length as u32)
    }

    fn enumerate(&self) -> Self::Iter {
        ByteRangeIterator {
            min: self.min,
            max: self.max,
            current: vec![self.min; self.length],
            done: false,
        }
    }
}

/// Iterator for `ByteRangeVariety`.
pub struct ByteRangeIterator {
    min: u8,
    max: u8,
    current: Vec<u8>,
    done: bool,
}

impl Iterator for ByteRangeIterator {
    type Item = Vec<u8>;

    fn next(&mut self) -> Option<Self::Item> {
        if self.done {
            return None;
        }

        let result = self.current.clone();

        // Increment with carry
        let mut carry = true;
        for byte in &mut self.current {
            if carry {
                if *byte < self.max {
                    *byte += 1;
                    carry = false;
                } else {
                    *byte = self.min;
                }
            }
        }

        if carry {
            self.done = true;
        }

        Some(result)
    }
}

/// Check if decompression is feasible for a given entropy.
#[must_use]
pub fn is_decompression_feasible(entropy: f64) -> bool {
    entropy <= MAX_PRACTICAL_ENTROPY
}

/// Check if decompression is trivial (fast) for a given entropy.
#[must_use]
pub fn is_decompression_trivial(entropy: f64) -> bool {
    entropy <= TRIVIAL_ENTROPY_THRESHOLD
}

/// Decompress a compressed reference back to a typed datum.
///
/// This is the inverse direction of the reversible compression resolver.
/// Requires enumerating the type variety to find the matching datum.
///
/// # Complexity
///
/// O(2^H) where H is the effective entropy of the type variety.
///
/// # Errors
///
/// - `EntropyTooHigh` if entropy exceeds `MAX_PRACTICAL_ENTROPY`
/// - `NotFound` if no datum in the variety matches the digest
/// - `InvalidVariety` if the variety is empty
///
/// # Example
///
/// ```
/// use hologram_resolver::{TypedDatum, compress, decompress, ByteRangeVariety};
///
/// // Create a small variety (single byte 0-255)
/// let variety = ByteRangeVariety::single_byte(255);
///
/// // Original datum
/// let original = TypedDatum::new("byte", vec![42]);
/// let compressed = compress(&original);
///
/// // Decompress
/// let recovered = decompress(&compressed.reference, &variety).unwrap();
/// assert_eq!(recovered.data, vec![42]);
/// ```
pub fn decompress<V: TypeVariety>(
    reference: &CompressedReference,
    variety: &V,
) -> Result<TypedDatum, DecompressionError> {
    let entropy = variety.effective_entropy();

    // Check entropy threshold
    if entropy > MAX_PRACTICAL_ENTROPY {
        return Err(DecompressionError::EntropyTooHigh { entropy });
    }

    // Check for empty variety
    if variety.variety_size() == 0 {
        return Err(DecompressionError::InvalidVariety {
            reason: "empty variety".to_string(),
        });
    }

    // Enumerate and find matching datum
    for candidate in variety.enumerate() {
        let hash = Sha256::digest(&candidate);
        let digest = HashDigest::from_bytes(hash.into());

        if digest == reference.digest {
            return Ok(TypedDatum::new(&reference.type_declaration, candidate));
        }
    }

    Err(DecompressionError::NotFound {
        digest: reference.digest.to_hex(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_typed_datum_creation() {
        let datum = TypedDatum::new("text/plain", b"hello".to_vec());
        assert_eq!(datum.type_declaration, "text/plain");
        assert_eq!(datum.data, b"hello");
        assert_eq!(datum.size(), 5);
    }

    #[test]
    fn test_hash_digest_display() {
        let digest = HashDigest::from_bytes([0xab; 32]);
        let hex = digest.to_hex();
        assert_eq!(hex.len(), 64);
        assert!(hex.chars().all(|c| c == 'a' || c == 'b'));
    }

    #[test]
    fn test_compressed_reference_size() {
        let digest = HashDigest::from_bytes([0; 32]);
        let reference = CompressedReference::new("text/plain", digest);
        // "text/plain" = 10 bytes + 32 bytes digest = 42 bytes
        assert_eq!(reference.size(), 42);
    }

    #[test]
    fn test_compress_basic() {
        let datum = TypedDatum::new("text/plain", b"hello world".to_vec());
        let result = compress(&datum);

        // Verify digest is computed
        assert_eq!(
            result.reference.digest.to_hex(),
            "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"
        );

        // Verify type is preserved
        assert_eq!(result.reference.type_declaration, "text/plain");

        // Verify ratio
        // Original: 11 bytes, Compressed: 10 + 32 = 42 bytes
        assert_eq!(result.ratio.original_size, 11);
        assert_eq!(result.ratio.compressed_size, 42);
    }

    #[test]
    fn test_compress_large_data() {
        // 1MB of data
        let data = vec![0xAB; 1_000_000];
        let datum = TypedDatum::new("application/octet-stream", data);
        let result = compress(&datum);

        // Original: 1,000,000 bytes
        // Compressed: 24 ("application/octet-stream") + 32 = 56 bytes
        assert_eq!(result.ratio.original_size, 1_000_000);
        assert_eq!(result.ratio.compressed_size, 56);

        // Ratio should be ~17857:1
        assert!(result.ratio.ratio > 17_000.0);
    }

    #[test]
    fn test_compression_ratio_display() {
        let ratio = CompressionRatio::compute(1_000_000, 56);
        let display = format!("{ratio}");
        assert!(display.contains("1000000:56"));
    }

    #[test]
    fn test_same_data_same_digest() {
        let datum1 = TypedDatum::new("text/plain", b"test".to_vec());
        let datum2 = TypedDatum::new("application/json", b"test".to_vec());

        let result1 = compress(&datum1);
        let result2 = compress(&datum2);

        // Same data = same digest
        assert_eq!(result1.reference.digest, result2.reference.digest);

        // Different types
        assert_ne!(
            result1.reference.type_declaration,
            result2.reference.type_declaration
        );
    }

    #[test]
    fn test_empty_data() {
        let datum = TypedDatum::new("text/plain", Vec::new());
        let result = compress(&datum);

        // SHA-256 of empty string
        assert_eq!(
            result.reference.digest.to_hex(),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
    }

    // Decompression tests

    #[test]
    fn test_byte_range_variety() {
        let variety = ByteRangeVariety::single_byte(255);
        assert_eq!(variety.variety_size(), 256);
        assert!((variety.effective_entropy() - 8.0).abs() < 0.001);
    }

    #[test]
    fn test_byte_range_enumerate() {
        let variety = ByteRangeVariety::single_byte(3);
        let values: Vec<_> = variety.enumerate().collect();
        assert_eq!(values.len(), 4);
        assert_eq!(values[0], vec![0]);
        assert_eq!(values[1], vec![1]);
        assert_eq!(values[2], vec![2]);
        assert_eq!(values[3], vec![3]);
    }

    #[test]
    fn test_decompress_single_byte() {
        let variety = ByteRangeVariety::single_byte(255);

        // Compress a single byte
        let original = TypedDatum::new("byte", vec![42]);
        let compressed = compress(&original);

        // Decompress
        let recovered = decompress(&compressed.reference, &variety).unwrap();
        assert_eq!(recovered.data, vec![42]);
        assert_eq!(recovered.type_declaration, "byte");
    }

    #[test]
    fn test_decompress_roundtrip() {
        let variety = ByteRangeVariety::new(2, 0, 15); // 16^2 = 256 values

        for a in 0..16u8 {
            for b in 0..16u8 {
                let original = TypedDatum::new("pair", vec![a, b]);
                let compressed = compress(&original);
                let recovered = decompress(&compressed.reference, &variety).unwrap();
                assert_eq!(recovered.data, original.data);
            }
        }
    }

    #[test]
    fn test_is_decompression_feasible() {
        assert!(is_decompression_feasible(40.0));
        assert!(is_decompression_feasible(128.0));
        assert!(!is_decompression_feasible(129.0));
    }

    #[test]
    fn test_is_decompression_trivial() {
        assert!(is_decompression_trivial(20.0));
        assert!(is_decompression_trivial(40.0));
        assert!(!is_decompression_trivial(41.0));
    }

    #[test]
    fn test_enumeration_strategy_display() {
        assert_eq!(
            EnumerationStrategy::ExhaustiveSequential.to_string(),
            "exhaustive_sequential"
        );
        assert_eq!(
            EnumerationStrategy::GrammarGuided.to_string(),
            "grammar_guided"
        );
    }

    // Generated code tests

    #[test]
    fn test_schema_types_generated() {
        // Verify types were found in schema using const assertions
        const _: () = {
            assert!(TYPED_DATUM_GENERATED, "TypedDatum not in schema");
            assert!(HASH_DIGEST_GENERATED, "HashDigest not in schema");
            assert!(
                COMPRESSED_REFERENCE_GENERATED,
                "CompressedReference not in schema"
            );
            assert!(
                EFFECTIVE_ENTROPY_GENERATED,
                "effectiveEntropy not in schema"
            );
        };
        // Runtime verification that test actually ran
        assert!(schema_complete());
    }

    #[test]
    fn test_hash_digest_constants() {
        const _: () = {
            assert!(HASH_DIGEST_BITS == 256, "Expected 256-bit hash digest");
            assert!(HASH_DIGEST_BYTES == 32, "Expected 32-byte hash digest");
        };
        // Runtime sanity check
        assert_eq!(std::mem::size_of::<HashDigest>(), HASH_DIGEST_BYTES);
    }

    #[test]
    fn test_schema_complete() {
        const _: () = assert!(schema_complete(), "Schema is incomplete");
        // Runtime verification that test ran
        let _ = schema_complete(); // Ensure function is evaluated
    }

    #[test]
    fn test_type_uris() {
        assert!(TYPED_DATUM_URI.contains("type/TypedDatum"));
        assert!(HASH_DIGEST_URI.contains("type/HashDigest"));
        assert!(COMPRESSED_REFERENCE_URI.contains("type/CompressedReference"));
    }

    // Roundtrip and certificate tests

    #[test]
    fn test_roundtrip_verify_single_byte() {
        let variety = ByteRangeVariety::single_byte(255);
        let datum = TypedDatum::new("byte", vec![42]);

        let cert = roundtrip_verify(&datum, &variety).unwrap();
        assert!(cert.verified);
        assert_eq!(cert.datum.data, vec![42]);
        assert!((cert.effective_entropy - 8.0).abs() < 0.001);
    }

    #[test]
    fn test_roundtrip_verify_all_single_bytes() {
        let variety = ByteRangeVariety::single_byte(255);

        for i in 0..=255u8 {
            let datum = TypedDatum::new("byte", vec![i]);
            let cert = roundtrip_verify(&datum, &variety).unwrap();
            assert!(cert.verified, "Failed for byte {}", i);
        }
    }

    #[test]
    fn test_certificate_display() {
        let variety = ByteRangeVariety::single_byte(255);
        let datum = TypedDatum::new("byte", vec![0]);
        let cert = roundtrip_verify(&datum, &variety).unwrap();

        let display = format!("{}", cert);
        assert!(display.contains("verified: true"));
        assert!(display.contains("entropy: 8.0 bits"));
    }

    #[test]
    fn test_roundtrip_preserves_type() {
        let variety = ByteRangeVariety::single_byte(255);
        let datum = TypedDatum::new("custom/type", vec![100]);

        let cert = roundtrip_verify(&datum, &variety).unwrap();
        assert_eq!(cert.datum.type_declaration, "custom/type");
        assert_eq!(cert.reference.type_declaration, "custom/type");
    }

    #[test]
    fn test_compression_ratio_in_certificate() {
        let variety = ByteRangeVariety::single_byte(255);
        let datum = TypedDatum::new("x", vec![1]); // 1 byte data, "x" = 1 byte type

        let cert = roundtrip_verify(&datum, &variety).unwrap();
        // Original: 1 byte, Compressed: 1 + 32 = 33 bytes
        assert_eq!(cert.ratio.original_size, 1);
        assert_eq!(cert.ratio.compressed_size, 33);
    }
}
