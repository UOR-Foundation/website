//! Server configuration.

use std::path::PathBuf;

/// Server configuration.
#[derive(Debug, Clone)]
pub struct Config {
    /// Port to listen on.
    pub port: u16,

    /// Path to uor.jsonld.
    pub uor_jsonld: PathBuf,

    /// Path to uor.schema.json.
    pub uor_schema: PathBuf,

    /// Path to taxon-catalog.json.
    pub taxon_catalog: PathBuf,

    /// Path to hologram.jsonld.
    pub hologram_jsonld: PathBuf,
}

impl Config {
    /// Create config with default paths relative to workspace root.
    pub fn new(port: u16, workspace_root: PathBuf) -> Self {
        Self {
            port,
            uor_jsonld: workspace_root.join("crates/uor/schema/uor.jsonld"),
            uor_schema: workspace_root.join("crates/uor/schema/uor.schema.json"),
            taxon_catalog: workspace_root.join("crates/uor/schema/taxon-catalog.json"),
            hologram_jsonld: workspace_root.join("descriptors/hologram.jsonld"),
        }
    }

    /// Create config from environment or defaults.
    pub fn from_env() -> Self {
        let port = std::env::var("SCHEMA_SERVER_PORT")
            .ok()
            .and_then(|p| p.parse().ok())
            .unwrap_or(3000);

        let workspace_root = std::env::var("WORKSPACE_ROOT")
            .map(PathBuf::from)
            .unwrap_or_else(|_| PathBuf::from("."));

        Self::new(port, workspace_root)
    }
}

impl Default for Config {
    fn default() -> Self {
        Self::from_env()
    }
}
