//! Plan execution engine.
//!
//! This module provides [`PlanExecutor`] for executing pre-compiled
//! [`BackendPlan`]s with O(1) dispatch overhead. The executor:
//!
//! - Manages workspace memory
//! - Coordinates buffer operations with backends
//! - Executes operations in topological order
//!
//! # Design Principles
//!
//! - **O(1) Dispatch**: No runtime decisions, just function pointer calls
//! - **Zero Allocation**: Workspace pre-allocated, no heap ops in hot path
//! - **Backend Agnostic**: Same executor interface for CPU, GPU, etc.
//!
//! # Example
//!
//! ```rust,ignore
//! use hologram_backend::executor::PlanExecutor;
//! use hologram_backend::plan::BackendPlan;
//!
//! // Create executor with pre-allocated workspace
//! let mut executor = PlanExecutor::new(plan, backend)?;
//!
//! // Execute with input/output buffers
//! executor.execute(&inputs, &mut outputs)?;
//! ```

use crate::backends::cpu::winograd::{prepacked_filter_from_bytes, winograd_conv2d_f23};
use crate::core::markers::BufferView;
use crate::error::{BackendError, BackendResult};
use crate::layout::WinogradVariant;
use crate::plan::{
    BackendPlan, BufferRef, DynamicWorkspaceHandle, KernelId, LookupTables, WorkspaceHandle,
    WorkspaceLayout,
};
use crate::traits::ProgramBackend;
use crate::BufferHandle;
use crate::{core::const_provider::ConstProvider, core::mapped_input::MappedInput};
use hologram_ir::DimExpr;
use rustc_hash::FxHashMap;
use std::path::Path;
use std::sync::Arc;

/// Sentinel value indicating no constant data for a kernel.
/// Matches the value used in hologram-compiler pipeline.
const NO_CONSTANT_DATA: usize = usize::MAX;

/// Winograd F(2,3) marker in KernelParams.extra[5].
const WINOGRAD_F23_MARKER: usize = 23;

/// Winograd F(4,3) marker in KernelParams.extra[5].
#[allow(dead_code)]
const WINOGRAD_F43_MARKER: usize = 43;

/// Default readahead window for sequential constant access.
/// Default readahead window for sequential constant access.
pub const DEFAULT_CONSTANT_READAHEAD: usize = 512 * 1024;

/// Execution statistics for profiling.
#[derive(Debug, Clone, Default)]
pub struct ExecutionStats {
    /// Total execution time in nanoseconds.
    pub total_ns: u64,
    /// Per-operation timings in nanoseconds.
    pub op_timings: Vec<u64>,
    /// Workspace bytes used.
    pub workspace_bytes: usize,
    /// Number of operations executed.
    pub ops_executed: usize,
}

impl ExecutionStats {
    /// Get total execution time as Duration.
    pub fn total_duration(&self) -> std::time::Duration {
        std::time::Duration::from_nanos(self.total_ns)
    }

    /// Get average time per operation in nanoseconds.
    pub fn avg_op_ns(&self) -> u64 {
        if self.ops_executed == 0 {
            0
        } else {
            self.total_ns / self.ops_executed as u64
        }
    }
}

/// Plan executor with pre-allocated workspace.
///
/// Executes a [`BackendPlan`] with minimal runtime overhead.
/// All decisions have been made at compile time; the executor
/// just sequences the pre-resolved operations.
///
/// # External Constants Support
///
/// The executor can optionally use memory-mapped external weights instead of
/// embedded `constant_data`. When `external_constants` is set, `BufferRef::Constant`
/// resolves against the mmap'd file instead of `plan.constant_data`. This enables
/// lazy loading of large model weights without loading them all into memory.
pub struct PlanExecutor {
    /// The execution plan.
    plan: BackendPlan,
    /// Pre-allocated workspace memory (static layout).
    workspace: Option<WorkspaceHandle>,
    /// Dynamic workspace that is resolved and allocated at runtime based on input shapes.
    /// When present, this takes precedence over the static `workspace` field.
    /// Used when the plan has dynamic workspace regions with size expressions.
    dynamic_workspace: Option<DynamicWorkspaceHandle>,
    /// Whether profiling is enabled.
    profiling: bool,
    /// Last execution statistics.
    last_stats: ExecutionStats,
    /// Runtime shape metadata for each buffer (keyed by buffer handle ID).
    /// Used by the Shape operation to extract tensor dimensions at runtime.
    shape_registry: FxHashMap<u64, Vec<usize>>,
    /// Runtime tracking of actual tensor element counts in workspace slots.
    /// Maps workspace_slot -> element_count. Updated after each operation writes to workspace.
    /// This is CRITICAL for DimExpr::PredecessorElementsDiv to get actual tensor sizes,
    /// not workspace region allocation sizes.
    workspace_tensor_sizes: FxHashMap<usize, usize>,
    /// Execution context for tracking all runtime state during graph execution.
    /// This is the single source of truth for tensor metadata (element counts, shapes, dtypes).
    /// Will eventually replace workspace_tensor_sizes and shape_registry.
    execution_context: crate::core::context::ExecutionContext,
    /// Cached resolved output shapes (computed once per input shape set).
    /// Each entry is (output_id, shape, size_bytes).
    /// None until first resolve_output_shapes() call; invalidated on shape changes.
    resolved_output_shapes: Option<Vec<(usize, Vec<usize>, usize)>>,
    /// Optional external constant data source (memory-mapped weights file).
    /// When present, `BufferRef::Constant` resolves against this instead of `plan.constant_data`.
    /// This enables lazy loading of large model weights.
    external_constants: Option<Arc<MappedInput>>,
    /// Optional pluggable constant provider (e.g., decompressed or remote).
    const_provider: Option<Arc<dyn ConstProvider>>,
    /// Base offset for external constants (used for bundle format).
    /// When loading from a unified bundle file, this offset points to where
    /// the weights section starts within the mmap'd file.
    constants_base_offset: usize,
    /// Access pattern hint for constants (controls mmap readahead).
    const_access_pattern: ConstantAccessPattern,
    /// Cached per-path mmap for BufferRef::ExternalConstant entries.
    external_constant_maps: FxHashMap<String, Arc<MappedInput>>,
}

/// Hint for constant access pattern to keep RSS bounded.
#[derive(Clone, Copy)]
pub enum ConstantAccessPattern {
    /// Random access, disable readahead.
    Random,
    /// Sequential access, prefetch a small window.
    Sequential {
        /// Bytes to prefetch ahead of the first constant offset.
        readahead_bytes: usize,
    },
}

impl PlanExecutor {
    fn map_external_constants(
        plan: &BackendPlan,
    ) -> BackendResult<FxHashMap<String, Arc<MappedInput>>> {
        let mut maps = FxHashMap::default();
        for op in &plan.ops {
            for buf_ref in op.input_refs.iter().chain(op.output_refs.iter()) {
                if let BufferRef::ExternalConstant { path, .. } = buf_ref {
                    if !maps.contains_key(path) {
                        let mmap = MappedInput::open(Path::new(path)).map_err(|e| {
                            BackendError::buffer(format!(
                                "Failed to mmap external constant '{}': {}",
                                path, e
                            ))
                        })?;
                        mmap.advise_random();
                        maps.insert(path.clone(), Arc::new(mmap));
                    }
                }
            }
        }
        Ok(maps)
    }

    fn validate_embedded_constants(plan: &BackendPlan) -> BackendResult<()> {
        let data_len = plan.constant_data.len();
        for (op_idx, op) in plan.ops.iter().enumerate() {
            for buf_ref in op.input_refs.iter().chain(op.output_refs.iter()) {
                if let BufferRef::Constant { offset, size } = buf_ref {
                    let end = offset.saturating_add(*size);
                    if end > data_len {
                        return Err(BackendError::buffer(format!(
                            "Constant reference out of bounds in op {}: offset {} size {} > data_len {}",
                            op_idx, offset, size, data_len
                        )));
                    }
                }
            }
        }
        Ok(())
    }

    /// Validate all constant buffer references against mmap bounds.
    ///
    /// This catches out-of-bounds references before execution, preventing SIGSEGV
    /// from accessing memory outside the mmap'd region.
    ///
    /// Note: We only validate bounds, not params.dims consistency, because params.dims
    /// layout is kernel-specific (e.g., for binary elementwise: dims[0]=output_size,
    /// dims[1]=second_input, dims[2]=first_input) and scalar broadcast is valid.
    fn validate_mmap_constants(
        plan: &BackendPlan,
        mmap_len: usize,
        base_offset: usize,
    ) -> BackendResult<()> {
        let available = mmap_len.saturating_sub(base_offset);

        for (op_idx, op) in plan.ops.iter().enumerate() {
            for buf_ref in op.input_refs.iter() {
                if let BufferRef::Constant { offset, size } = buf_ref {
                    // Check that the constant reference fits within available mmap space
                    let end = offset.saturating_add(*size);
                    if end > available {
                        return Err(BackendError::buffer(format!(
                            "Constant reference out of bounds in op {}: \
                             offset {} + size {} = {} exceeds available {} \
                             (mmap_len={}, base_offset={})",
                            op_idx, offset, size, end, available, mmap_len, base_offset
                        )));
                    }
                }
            }
        }
        Ok(())
    }

    fn apply_access_hint(pattern: ConstantAccessPattern, mmap: &MappedInput, base_offset: usize) {
        match pattern {
            ConstantAccessPattern::Random => mmap.advise_random(),
            ConstantAccessPattern::Sequential { readahead_bytes } => {
                mmap.advise_sequential();
                if readahead_bytes > 0 {
                    mmap.prefetch_range(base_offset, readahead_bytes);
                }
            }
        }
    }

    /// Create a new executor for the given plan.
    ///
    /// Allocates workspace memory based on the plan's requirements.
    /// For plans with dynamic workspace regions, allocation is deferred until
    /// input shapes are known (via `register_input_shape` or `preallocate_dynamic_workspace`).
    pub fn new(plan: BackendPlan, backend: &dyn ProgramBackend) -> BackendResult<Self> {
        Self::validate_embedded_constants(&plan)?;
        let external_constant_maps = Self::map_external_constants(&plan)?;

        // Check if workspace has dynamic regions - if so, defer allocation
        let workspace = if plan.workspace_layout.has_dynamic_regions() {
            // Dynamic workspace: defer allocation until input shapes are known
            tracing::info!(
                "Workspace has {} dynamic regions - deferring allocation until input shapes known",
                plan.workspace_layout.dynamic_region_count()
            );
            None
        } else if plan.workspace_layout.total_size > 0 {
            // Static workspace: allocate now
            tracing::info!(
                "Allocating static workspace: {} bytes",
                plan.workspace_layout.total_size
            );
            Some(Self::allocate_workspace(&plan.workspace_layout, backend)?)
        } else {
            tracing::warn!("No workspace required (total_size = 0)");
            None
        };
        let const_access_pattern = ConstantAccessPattern::Sequential {
            readahead_bytes: DEFAULT_CONSTANT_READAHEAD,
        };
        for mmap in external_constant_maps.values() {
            Self::apply_access_hint(const_access_pattern, mmap, 0);
        }

        Ok(Self {
            plan,
            workspace,
            dynamic_workspace: None,
            profiling: false,
            last_stats: ExecutionStats::default(),
            shape_registry: FxHashMap::default(),
            workspace_tensor_sizes: FxHashMap::default(),
            execution_context: crate::core::context::ExecutionContext::new(),
            resolved_output_shapes: None,
            external_constants: None,
            const_provider: None,
            constants_base_offset: 0,
            const_access_pattern,
            external_constant_maps,
        })
    }

    /// Create executor without workspace allocation.
    ///
    /// Useful when workspace is managed externally or not needed.
    pub fn without_workspace(plan: BackendPlan) -> Self {
        Self::validate_embedded_constants(&plan).expect("invalid constant references in plan");
        let external_constant_maps =
            Self::map_external_constants(&plan).expect("failed to mmap external constants");
        let const_access_pattern = ConstantAccessPattern::Sequential {
            readahead_bytes: DEFAULT_CONSTANT_READAHEAD,
        };
        for mmap in external_constant_maps.values() {
            Self::apply_access_hint(const_access_pattern, mmap, 0);
        }
        Self {
            plan,
            workspace: None,
            dynamic_workspace: None,
            profiling: false,
            last_stats: ExecutionStats::default(),
            shape_registry: FxHashMap::default(),
            workspace_tensor_sizes: FxHashMap::default(),
            execution_context: crate::core::context::ExecutionContext::new(),
            resolved_output_shapes: None,
            external_constants: None,
            const_provider: None,
            constants_base_offset: 0,
            const_access_pattern,
            external_constant_maps,
        }
    }

    /// Create executor with memory-mapped external constants.
    ///
    /// This enables lazy loading of large model weights. The weights file
    /// is memory-mapped, and the OS pages in data on demand when accessed.
    ///
    /// # Arguments
    ///
    /// * `plan` - The execution plan (constant_data may be empty)
    /// * `backend` - Backend for workspace allocation
    /// * `constants_path` - Path to the external constants/weights file
    ///
    /// # Example
    ///
    /// ```rust,ignore
    /// let executor = PlanExecutor::with_external_constants(
    ///     plan,
    ///     &*backend,
    ///     Path::new("model.weights"),
    /// )?;
    /// ```
    pub fn with_external_constants(
        plan: BackendPlan,
        backend: &dyn ProgramBackend,
        constants_path: &Path,
    ) -> BackendResult<Self> {
        Self::validate_embedded_constants(&plan)?;
        let external_constant_maps = Self::map_external_constants(&plan)?;
        // Memory-map the constants file
        let mapped = MappedInput::open(constants_path).map_err(|e| {
            BackendError::buffer(format!(
                "Failed to mmap constants file '{}': {}",
                constants_path.display(),
                e
            ))
        })?;

        // Advise random access pattern for weights (accessed by different kernels)
        mapped.advise_random();

        tracing::info!(
            "Loaded external constants: {} bytes from {}",
            mapped.len(),
            constants_path.display()
        );

        // Validate all constant references fit within mmap and match params.dims
        // base_offset is 0 for external constants files
        Self::validate_mmap_constants(&plan, mapped.len(), 0)?;

        // Allocate workspace if needed (defer for dynamic regions)
        let workspace = if plan.workspace_layout.has_dynamic_regions() {
            tracing::info!(
                "Workspace has {} dynamic regions - deferring allocation",
                plan.workspace_layout.dynamic_region_count()
            );
            None
        } else if plan.workspace_layout.total_size > 0 {
            tracing::info!(
                "Allocating static workspace: {} bytes",
                plan.workspace_layout.total_size
            );
            Some(Self::allocate_workspace(&plan.workspace_layout, backend)?)
        } else {
            None
        };

        let const_access_pattern = ConstantAccessPattern::Random;
        for mmap in external_constant_maps.values() {
            Self::apply_access_hint(const_access_pattern, mmap, 0);
        }
        let mapped_arc = Arc::new(mapped);
        Self::apply_access_hint(const_access_pattern, &mapped_arc, 0);

        Ok(Self {
            plan,
            workspace,
            dynamic_workspace: None,
            profiling: false,
            last_stats: ExecutionStats::default(),
            shape_registry: FxHashMap::default(),
            workspace_tensor_sizes: FxHashMap::default(),
            execution_context: crate::core::context::ExecutionContext::new(),
            resolved_output_shapes: None,
            external_constants: Some(mapped_arc),
            const_provider: None,
            constants_base_offset: 0,
            const_access_pattern,
            external_constant_maps,
        })
    }

    /// Create executor with memory-mapped constants at a specific offset.
    ///
    /// This is used for unified bundle files (HOLB format) where the weights
    /// section is embedded in the same file as the computation graph, at a
    /// page-aligned offset.
    ///
    /// # Arguments
    ///
    /// * `plan` - The execution plan (constant_data should be empty)
    /// * `backend` - Backend for workspace allocation
    /// * `mmap` - Arc to the memory-mapped file (kept alive by the executor)
    /// * `base_offset` - Offset to the weights section within the mmap
    ///
    /// # Example
    ///
    /// ```rust,ignore
    /// // Load unified bundle file
    /// let mmap = MappedInput::open("model.holo")?;
    /// let weights_offset = bundle_header.weights_offset as usize;
    ///
    /// let executor = PlanExecutor::with_mmap_constants_at_offset(
    ///     plan,
    ///     &*backend,
    ///     Arc::new(mmap),
    ///     weights_offset,
    /// )?;
    /// ```
    pub fn with_mmap_constants_at_offset(
        plan: BackendPlan,
        backend: &dyn ProgramBackend,
        mmap: Arc<MappedInput>,
        base_offset: usize,
    ) -> BackendResult<Self> {
        Self::validate_embedded_constants(&plan)?;
        let external_constant_maps = Self::map_external_constants(&plan)?;
        // Validate offset is within bounds
        if base_offset > mmap.len() {
            return Err(BackendError::buffer(format!(
                "Constants base offset {} exceeds mmap size {}",
                base_offset,
                mmap.len()
            )));
        }

        // Validate all constant references fit within mmap and match params.dims
        Self::validate_mmap_constants(&plan, mmap.len(), base_offset)?;

        let const_access_pattern = ConstantAccessPattern::Sequential {
            readahead_bytes: DEFAULT_CONSTANT_READAHEAD,
        };
        Self::apply_access_hint(const_access_pattern, &mmap, base_offset);
        for mapped in external_constant_maps.values() {
            Self::apply_access_hint(const_access_pattern, mapped, base_offset);
        }

        tracing::info!(
            "Using mmap'd constants: {} bytes total, base_offset={}",
            mmap.len(),
            base_offset
        );

        // Log first few constant offsets from the plan for debugging
        let mut constant_offsets: Vec<(usize, usize)> = Vec::new();
        for op in &plan.ops {
            for buf_ref in &op.input_refs {
                if let BufferRef::Constant { offset, size } = buf_ref {
                    if constant_offsets.len() < 5
                        && !constant_offsets.iter().any(|(o, _)| *o == *offset)
                    {
                        constant_offsets.push((*offset, *size));
                    }
                }
            }
        }
        if !constant_offsets.is_empty() {
            tracing::info!(
                "First constant refs in plan: {:?} (base_offset={}, mmap_size={})",
                constant_offsets,
                base_offset,
                mmap.len()
            );
        }

        // Allocate workspace if needed (defer for dynamic regions)
        let workspace = if plan.workspace_layout.has_dynamic_regions() {
            tracing::info!(
                "Workspace has {} dynamic regions - deferring allocation until input shapes known",
                plan.workspace_layout.dynamic_region_count()
            );
            None
        } else if plan.workspace_layout.total_size > 0 {
            tracing::info!(
                "Allocating static workspace: {} bytes ({} regions)",
                plan.workspace_layout.total_size,
                plan.workspace_layout.regions.len()
            );

            // Debug: check for any regions with offset >= total_size (only for static workspaces)
            for (idx, region) in plan.workspace_layout.regions.iter().enumerate() {
                let end = region.offset.saturating_add(region.size);
                if end > plan.workspace_layout.total_size {
                    tracing::error!(
                        "WORKSPACE BUG: Region {} '{}' extends beyond total_size! \
                         offset={} size={} end={} total_size={}",
                        idx,
                        region.name,
                        region.offset,
                        region.size,
                        end,
                        plan.workspace_layout.total_size
                    );
                }
            }

            Some(Self::allocate_workspace(&plan.workspace_layout, backend)?)
        } else {
            None
        };

        Ok(Self {
            plan,
            workspace,
            dynamic_workspace: None,
            profiling: false,
            last_stats: ExecutionStats::default(),
            shape_registry: FxHashMap::default(),
            workspace_tensor_sizes: FxHashMap::default(),
            execution_context: crate::core::context::ExecutionContext::new(),
            resolved_output_shapes: None,
            external_constants: Some(mmap),
            const_provider: None,
            constants_base_offset: base_offset,
            const_access_pattern,
            external_constant_maps,
        })
    }

    /// Create executor with a custom constant provider (e.g., streaming/decompressed).
    pub fn with_const_provider(
        plan: BackendPlan,
        backend: &dyn ProgramBackend,
        provider: Arc<dyn ConstProvider>,
        base_offset: usize,
    ) -> BackendResult<Self> {
        Self::validate_embedded_constants(&plan)?;

        // Allocate workspace if needed (defer for dynamic regions)
        let workspace = if plan.workspace_layout.has_dynamic_regions() {
            tracing::info!(
                "Workspace has {} dynamic regions - deferring allocation",
                plan.workspace_layout.dynamic_region_count()
            );
            None
        } else if plan.workspace_layout.total_size > 0 {
            tracing::info!(
                "Allocating static workspace: {} bytes",
                plan.workspace_layout.total_size
            );
            Some(Self::allocate_workspace(&plan.workspace_layout, backend)?)
        } else {
            None
        };

        Ok(Self {
            plan,
            workspace,
            dynamic_workspace: None,
            profiling: false,
            last_stats: ExecutionStats::default(),
            shape_registry: FxHashMap::default(),
            workspace_tensor_sizes: FxHashMap::default(),
            execution_context: crate::core::context::ExecutionContext::new(),
            resolved_output_shapes: None,
            external_constants: None,
            const_provider: Some(provider),
            constants_base_offset: base_offset,
            const_access_pattern: ConstantAccessPattern::Sequential {
                readahead_bytes: DEFAULT_CONSTANT_READAHEAD,
            },
            external_constant_maps: FxHashMap::default(),
        })
    }

    /// Enable or disable profiling.
    pub fn set_profiling(&mut self, enabled: bool) {
        self.profiling = enabled;
    }

    /// Hint how constants will be accessed; updates mmap advice accordingly.
    pub fn set_constant_access_pattern(&mut self, pattern: ConstantAccessPattern) {
        self.const_access_pattern = pattern;
        if let Some(mmap) = &self.external_constants {
            Self::apply_access_hint(pattern, mmap, self.constants_base_offset);
        }
        for mmap in self.external_constant_maps.values() {
            Self::apply_access_hint(pattern, mmap, self.constants_base_offset);
        }
    }

    /// Get the execution plan.
    pub fn plan(&self) -> &BackendPlan {
        &self.plan
    }

    /// Access canonical lookup tables (packed + metadata) for this plan.
    pub fn lookup_tables(&self) -> LookupTables {
        self.plan.lookup_tables()
    }

    /// Get the workspace handle.
    pub fn workspace(&self) -> Option<&WorkspaceHandle> {
        self.workspace.as_ref()
    }

    /// Get mutable workspace handle.
    pub fn workspace_mut(&mut self) -> Option<&mut WorkspaceHandle> {
        self.workspace.as_mut()
    }

    /// Register the shape of a buffer for runtime shape extraction.
    ///
    /// This is used by the Shape operation to extract tensor dimensions at runtime.
    /// Call this when providing input tensors so their shapes are available.
    ///
    /// Note: Registering a new shape invalidates the cached output shape resolution,
    /// causing the next `resolve_output_shapes()` call to recompute.
    pub fn register_shape(&mut self, handle: &BufferHandle, shape: Vec<usize>) {
        self.shape_registry.insert(handle.id(), shape.clone());
        self.resolved_output_shapes = None; // Invalidate cache

        // Also register in execution context (NEW centralized approach)
        // BufferHandle IDs map to input indices (0, 1, 2, ...)
        self.execution_context.register_input(
            handle.id() as usize,
            shape,
            crate::core::context::DataType::Float32, // TODO: track actual dtype from handle
        );

        // Check if we need to resolve dynamic workspace
        if self.plan.workspace_layout.has_dynamic_regions() {
            self.resolve_dynamic_workspace();
        }
    }

    /// Resolve and allocate dynamic workspace based on registered input shapes.
    ///
    /// This is called automatically when input shapes are registered and the plan
    /// has dynamic workspace regions. It resolves size expressions and allocates
    /// (or reallocates) workspace memory accordingly.
    ///
    /// For plans with only static workspace regions, this is a no-op.
    pub fn resolve_dynamic_workspace(&mut self) {
        // Only proceed if we have dynamic regions
        if !self.plan.workspace_layout.has_dynamic_regions() {
            return;
        }

        // Build input shapes array from registry
        let input_shapes = self.build_input_shapes_array();
        if input_shapes.is_empty() {
            tracing::debug!(
                "No input shapes registered yet, skipping dynamic workspace resolution"
            );
            return;
        }

        // Try to resolve and allocate
        match DynamicWorkspaceHandle::resolve_and_allocate(
            &self.plan.workspace_layout,
            &input_shapes,
        ) {
            Some(dws) => {
                let total_size = dws.total_size();
                tracing::info!(
                    "Resolved dynamic workspace: {} bytes ({} regions)",
                    total_size,
                    dws.layout().regions.len()
                );
                self.dynamic_workspace = Some(dws);
            }
            None => {
                tracing::warn!(
                    "Failed to resolve dynamic workspace from input shapes, using static workspace"
                );
            }
        }
    }

    /// Force reallocation of dynamic workspace with explicit shapes.
    ///
    /// Use this when you know the input shapes upfront and want to pre-allocate
    /// the workspace before execution.
    ///
    /// # Arguments
    /// * `input_shapes` - Array of input tensor shapes (up to 4 dimensions each)
    ///
    /// # Returns
    /// `true` if workspace was successfully resolved and allocated, `false` otherwise.
    pub fn preallocate_dynamic_workspace(&mut self, input_shapes: &[[usize; 4]]) -> bool {
        if !self.plan.workspace_layout.has_dynamic_regions() {
            tracing::debug!("No dynamic regions in workspace layout, skipping preallocation");
            return true; // Static workspace already allocated
        }

        match DynamicWorkspaceHandle::resolve_and_allocate(
            &self.plan.workspace_layout,
            input_shapes,
        ) {
            Some(dws) => {
                let total_size = dws.total_size();
                tracing::info!(
                    "Preallocated dynamic workspace: {} bytes ({} regions)",
                    total_size,
                    dws.layout().regions.len()
                );
                self.dynamic_workspace = Some(dws);
                true
            }
            None => {
                tracing::error!("Failed to preallocate dynamic workspace");
                false
            }
        }
    }

    /// Get the currently resolved dynamic workspace size, if any.
    pub fn dynamic_workspace_size(&self) -> Option<usize> {
        self.dynamic_workspace.as_ref().map(|dws| dws.total_size())
    }

    /// Check if this executor is using dynamic workspace.
    pub fn has_dynamic_workspace(&self) -> bool {
        self.dynamic_workspace.is_some()
    }

    /// Get the registered shape of a buffer.
    ///
    /// Returns `None` if the shape was not registered.
    pub fn get_shape(&self, handle: &BufferHandle) -> Option<&[usize]> {
        self.shape_registry.get(&handle.id()).map(|v| v.as_slice())
    }

    /// Clear all registered shapes.
    pub fn clear_shapes(&mut self) {
        self.shape_registry.clear();
        self.resolved_output_shapes = None; // Invalidate cache
    }

    /// Resolve output shapes from registered input shapes.
    ///
    /// Results are cached - first call computes, subsequent calls return cached data.
    /// Cache is invalidated when `register_shape()` or `clear_shapes()` is called.
    ///
    /// Returns slice of (output_id, resolved_shape, size_bytes).
    pub fn resolve_output_shapes(&mut self) -> BackendResult<&[(usize, Vec<usize>, usize)]> {
        if self.resolved_output_shapes.is_none() {
            self.resolved_output_shapes = Some(self.compute_output_shapes()?);
        }
        Ok(self.resolved_output_shapes.as_ref().unwrap())
    }

    /// Compute output shapes from shape expressions and registered input shapes.
    fn compute_output_shapes(&self) -> BackendResult<Vec<(usize, Vec<usize>, usize)>> {
        let mut results = Vec::new();
        let metadata = &self.plan.layout_metadata;

        for id in 0..metadata.num_outputs {
            let shape = if let Some(Some(exprs)) = metadata.output_shape_exprs.get(id) {
                // Dynamic shape - resolve from input shapes
                self.resolve_shape_exprs(exprs)?
            } else {
                // Static shape - use stored shape, removing leading 1s/0s
                let s = &metadata.output_shapes[id];
                s.iter()
                    .copied()
                    .skip_while(|&x| x == 1 || x == 0)
                    .collect()
            };

            let size_bytes = shape.iter().product::<usize>() * 4; // f32
            results.push((id, shape, size_bytes));
        }

        Ok(results)
    }

    /// Resolve a vector of dimension expressions to concrete values.
    fn resolve_shape_exprs(&self, exprs: &[DimExpr]) -> BackendResult<Vec<usize>> {
        exprs
            .iter()
            .map(|expr| self.resolve_dim_expr(expr))
            .collect()
    }

    /// Resolve a single dimension expression to a concrete value.
    fn resolve_dim_expr(&self, expr: &DimExpr) -> BackendResult<usize> {
        match expr {
            DimExpr::Static(n) => Ok(*n),
            DimExpr::InputRef {
                input_id,
                dim_index,
            } => {
                // Look up input shape from shape_registry by input_id
                // Input handles use their id as the key
                self.shape_registry
                    .get(&(*input_id as u64))
                    .and_then(|shape| shape.get(*dim_index).copied())
                    .ok_or_else(|| {
                        BackendError::invalid_config(format!(
                            "Shape for input {} dim {} not registered. \
                             Call register_shape() for all inputs before resolve_output_shapes().",
                            input_id, dim_index
                        ))
                    })
            }
            DimExpr::TotalElements { input_id } => {
                let shape = self
                    .shape_registry
                    .get(&(*input_id as u64))
                    .ok_or_else(|| {
                        BackendError::invalid_config(format!(
                            "Shape for input {} not registered.",
                            input_id
                        ))
                    })?;
                Ok(shape.iter().filter(|&&d| d > 0).product())
            }
            DimExpr::ProductOfDims {
                input_id_a,
                dim_a,
                input_id_b,
                dim_b,
            } => {
                let a = self
                    .shape_registry
                    .get(&(*input_id_a as u64))
                    .and_then(|s| s.get(*dim_a).copied())
                    .ok_or_else(|| {
                        BackendError::invalid_config(format!(
                            "Shape for input {} dim {} not registered.",
                            input_id_a, dim_a
                        ))
                    })?;
                let b = self
                    .shape_registry
                    .get(&(*input_id_b as u64))
                    .and_then(|s| s.get(*dim_b).copied())
                    .ok_or_else(|| {
                        BackendError::invalid_config(format!(
                            "Shape for input {} dim {} not registered.",
                            input_id_b, dim_b
                        ))
                    })?;
                Ok(a * b)
            }
            DimExpr::TotalElementsDiv { input_id, divisor } => {
                if *divisor == 0 {
                    return Err(BackendError::invalid_config(
                        "Division by zero in DimExpr".to_string(),
                    ));
                }
                let shape = self
                    .shape_registry
                    .get(&(*input_id as u64))
                    .ok_or_else(|| {
                        BackendError::invalid_config(format!(
                            "Shape for input {} not registered.",
                            input_id
                        ))
                    })?;
                let total: usize = shape.iter().filter(|&&d| d > 0).product();
                Ok(total / *divisor)
            }
            DimExpr::DimDiv {
                input_id,
                dim_index,
                divisor,
            } => {
                if *divisor == 0 {
                    return Err(BackendError::invalid_config(
                        "Division by zero in DimExpr".to_string(),
                    ));
                }
                let dim = self
                    .shape_registry
                    .get(&(*input_id as u64))
                    .and_then(|s| s.get(*dim_index).copied())
                    .ok_or_else(|| {
                        BackendError::invalid_config(format!(
                            "Shape for input {} dim {} not registered.",
                            input_id, dim_index
                        ))
                    })?;
                Ok(dim / *divisor)
            }
            DimExpr::PredecessorElementsDiv {
                predecessor_slot,
                divisor,
            } => {
                // This variant requires predecessor buffer sizes which are resolved
                // at a different level (in BackendPlan::execute_with_predecessors).
                // For shape resolution, this is not directly supported.
                Err(BackendError::invalid_config(format!(
                    "PredecessorElementsDiv (slot={}, divisor={}) cannot be resolved \
                     from shape registry. Use execute_with_predecessors() instead.",
                    predecessor_slot, divisor
                )))
            }
        }
    }

    /// Get the shape registry for read access.
    pub fn shape_registry(&self) -> &FxHashMap<u64, Vec<usize>> {
        &self.shape_registry
    }

    /// Get last execution statistics (only valid if profiling enabled).
    pub fn last_stats(&self) -> &ExecutionStats {
        &self.last_stats
    }

    /// Execute the plan with given input and output buffers.
    ///
    /// # Arguments
    /// * `inputs` - Input buffer handles
    /// * `outputs` - Output buffer handles (mutable)
    /// * `backend` - Backend to execute on
    ///
    /// # Returns
    /// Result indicating success or failure
    pub fn execute(
        &mut self,
        inputs: &[BufferHandle],
        outputs: &[BufferHandle],
        backend: &dyn ProgramBackend,
    ) -> BackendResult<()> {
        let start = if self.profiling {
            Some(std::time::Instant::now())
        } else {
            None
        };

        // Validate inputs/outputs match plan expectations
        self.validate_buffers(inputs, outputs)?;

        // Execute each operation in order
        let mut op_timings = if self.profiling {
            Vec::with_capacity(self.plan.ops.len())
        } else {
            Vec::new()
        };

        let num_ops = self.plan.ops.len();
        let trace_ops = std::env::var("HOLOGRAM_TRACE_OPS").is_ok();
        let trace_scope = std::env::var("HOLOGRAM_TRACE_SCOPE").ok();
        let trace_mask = std::env::var("HOLOGRAM_TRACE_MASK").is_ok()
            && trace_scope.as_deref() == Some("encoder");
        let trace_encoder_stats = std::env::var("HOLOGRAM_TRACE_ENCODER_STATS").is_ok()
            && trace_scope.as_deref() == Some("encoder");
        let mut encoder_gemm_count = 0usize;

        for i in 0..num_ops {
            let op_start = if self.profiling {
                Some(std::time::Instant::now())
            } else {
                None
            };

            // Resolve BufferRef to BufferHandle for this op.
            // BufferRef discriminant provides zero-overhead dispatch.
            let op_inputs: Vec<_> = self.plan.ops[i]
                .input_refs
                .iter()
                .filter_map(|buf_ref| self.resolve_buffer_ref(buf_ref, inputs, outputs))
                .collect();

            // Gather output buffers for this op
            let op_outputs: Vec<_> = self.plan.ops[i]
                .output_refs
                .iter()
                .enumerate()
                .filter_map(|(out_idx, buf_ref)| {
                    let handle = self.resolve_buffer_ref(buf_ref, inputs, outputs);
                    if i < 5 && handle.is_none() {
                        tracing::error!(
                            "OP[{}] output {} has BufferRef={:?} but resolve returned None",
                            i,
                            out_idx,
                            buf_ref
                        );
                    }
                    handle
                })
                .collect();

            if trace_ops {
                let op = &self.plan.ops[i];
                eprintln!(
                    "[hologram] OP[{}] kernel={:?} idx={} inputs={:?} outputs={:?} dims={:?} extra={:?}",
                    i,
                    op.kernel_id,
                    op.kernel_idx,
                    op.input_refs,
                    op.output_refs,
                    op.params.dims,
                    op.params.extra
                );
            } else if tracing::enabled!(tracing::Level::DEBUG) {
                let kernel_id = self.plan.ops[i].kernel_id;
                if (48..=60).contains(&i) {
                    tracing::debug!(
                        "OP[{}] kernel={:?} inputs={:?} outputs={:?}",
                        i,
                        kernel_id,
                        self.plan.ops[i].input_refs,
                        self.plan.ops[i].output_refs
                    );
                } else {
                    tracing::debug!("OP[{}] kernel={:?}", i, kernel_id);
                }
            }

            if trace_ops {
                self.validate_output_buffers(i)?;
            }

            if let Err(err) = self.execute_kernel(i, &op_inputs, &op_outputs, backend) {
                let op = &self.plan.ops[i];
                tracing::error!(
                    "Kernel execution failed at OP[{}] kernel={:?} idx={} inputs={} outputs={} dims={:?} extra={:?}: {:?}",
                    i,
                    op.kernel_id,
                    op.kernel_idx,
                    op.input_refs.len(),
                    op.output_refs.len(),
                    op.params.dims,
                    op.params.extra,
                    err
                );
                return Err(err);
            }

            if trace_mask {
                let op = &self.plan.ops[i];
                if is_attention_mask_kernel(op.kernel_id) && op.params.dims[0] <= 4096 {
                    for (out_idx, handle) in op_outputs.iter().enumerate() {
                        let buf_ref = op.output_refs.get(out_idx);
                        if let Ok(stats) =
                            self.sample_output_stats_for_ref(backend, buf_ref, *handle, 64)
                        {
                            eprintln!(
                                "[hologram][mask] op={} kernel={:?} out={} elems={} zeros={} ones={} neg_inf={} min={:.4e} max={:.4e} sample={:?}",
                                i,
                                op.kernel_id,
                                out_idx,
                                stats.count,
                                stats.zeros,
                                stats.ones,
                                stats.neg_inf,
                                stats.min,
                                stats.max,
                                stats.sample
                            );
                        }
                    }
                }
            }

            if trace_encoder_stats {
                let op = &self.plan.ops[i];
                let category = op.kernel_id.category();
                let log_activation = matches!(
                    category,
                    KernelId::CATEGORY_GEMM
                        | KernelId::CATEGORY_NORMALIZATION
                        | KernelId::CATEGORY_ACTIVATION
                        | KernelId::CATEGORY_REDUCE
                );
                if log_activation {
                    if category == KernelId::CATEGORY_GEMM {
                        encoder_gemm_count = encoder_gemm_count.saturating_add(1);
                    }
                    for (out_idx, handle) in op_outputs.iter().enumerate() {
                        let buf_ref = op.output_refs.get(out_idx);
                        if let Ok(stats) =
                            self.sample_output_stats_for_ref(backend, buf_ref, *handle, 512)
                        {
                            eprintln!(
                                "[hologram][encoder] op={} gemm_step={} kernel={:?} out={} elems={} nonzero={} min={:.4e} max={:.4e} mean={:.4e}",
                                i,
                                encoder_gemm_count,
                                op.kernel_id,
                                out_idx,
                                stats.count,
                                stats.nonzero,
                                stats.min,
                                stats.max,
                                stats.mean
                            );
                        }
                    }
                }
            }

            if let Some(start) = op_start {
                op_timings.push(start.elapsed().as_nanos() as u64);
            }
        }

        // Record statistics
        if let Some(start) = start {
            self.last_stats = ExecutionStats {
                total_ns: start.elapsed().as_nanos() as u64,
                op_timings,
                workspace_bytes: self.plan.workspace_layout.total_size as usize,
                ops_executed: self.plan.ops.len(),
            };
        }

        Ok(())
    }

    fn validate_output_buffers(&self, op_index: usize) -> BackendResult<()> {
        let op = self
            .plan
            .ops
            .get(op_index)
            .ok_or_else(|| BackendError::invalid_config("Invalid op index".to_string()))?;

        let category = op.kernel_id.category();
        let expected_bytes = match category {
            KernelId::CATEGORY_ELEMENTWISE_BINARY
            | KernelId::CATEGORY_ACTIVATION
            | KernelId::CATEGORY_TRANSCENDENTAL => {
                let elems = op.params.dims[0].max(1);
                elems
                    .checked_mul(std::mem::size_of::<f32>())
                    .ok_or_else(|| {
                        BackendError::invalid_config("Output size overflow".to_string())
                    })?
            }
            _ => return Ok(()),
        };

        for output in &op.output_refs {
            if let BufferRef::Workspace(slot) = output {
                let region = self
                    .plan
                    .workspace_layout
                    .regions
                    .get(*slot)
                    .ok_or_else(|| {
                        BackendError::invalid_config(format!(
                            "Workspace slot {} out of bounds ({} regions)",
                            slot,
                            self.plan.workspace_layout.regions.len()
                        ))
                    })?;
                if expected_bytes > (region.size as usize) {
                    let message = format!(
                        "Workspace overflow risk at OP[{}]: kernel={:?} expects {} bytes, region '{}' size {}",
                        op_index, op.kernel_id, expected_bytes, region.name, region.size
                    );
                    if std::env::var("HOLOGRAM_TRACE_OPS_STRICT").is_ok() {
                        return Err(BackendError::invalid_config(message));
                    }
                    eprintln!("[hologram][trace] {}", message);
                }
            }
        }

        Ok(())
    }

    /// Validate that kernel input/output sizes don't exceed allocated buffer sizes.
    ///
    /// This catches memory corruption bugs where params.dims[0] (or M*N for GEMM)
    /// exceeds the actual workspace region allocation. Such mismatches indicate
    /// a compiler bug in shape inference or buffer allocation.
    fn validate_kernel_output_sizes(
        &self,
        op_idx: usize,
        op: &crate::plan::PlanOp,
    ) -> BackendResult<()> {
        let category = op.kernel_id.category();

        // Calculate expected sizes in bytes based on kernel category
        let (expected_output_bytes, expected_input_bytes) = match category {
            KernelId::CATEGORY_GEMM => {
                // GEMM: C[M,N] = A[M,K] @ B[K,N]
                // Each input has a DIFFERENT size - we'll handle input validation separately
                let m = op.params.dims[0];
                let n = op.params.dims[2];
                let output = m
                    .checked_mul(n)
                    .and_then(|mn| mn.checked_mul(std::mem::size_of::<f32>()));
                // Return None for input to skip generic validation; we'll do per-input below
                (output, None)
            }
            KernelId::CATEGORY_ACTIVATION | KernelId::CATEGORY_TRANSCENDENTAL => {
                // Unary ops: input and output have same size = dims[0]
                let size = op.params.dims[0];
                let bytes = size.checked_mul(std::mem::size_of::<f32>());
                (bytes, bytes) // Input and output same size
            }
            KernelId::CATEGORY_ELEMENTWISE_BINARY => {
                // Binary ops: dims[0]=output, dims[1]=B size, dims[2]=A size
                // For broadcast operations, each input should be validated against its OWN size,
                // not against the max of both inputs.
                let output_size = op.params.dims[0];
                let output = output_size.checked_mul(std::mem::size_of::<f32>());
                // We'll handle input validation separately below for this category
                // Return None to skip the generic input validation
                (output, None)
            }
            KernelId::CATEGORY_TENSOR_OPS => {
                // dims[0] is the element count for these kernels
                let size = op.params.dims[0];
                let bytes = size.checked_mul(std::mem::size_of::<f32>());
                (bytes, bytes)
            }
            KernelId::CATEGORY_REDUCE => {
                // Reduce: input = outer * reduce * inner, output = outer * inner
                let outer = op.params.dims[0];
                let reduce = op.params.dims[1];
                let inner = op.params.dims[2];
                let output = outer
                    .checked_mul(inner)
                    .and_then(|sz| sz.checked_mul(std::mem::size_of::<f32>()));
                let input = outer
                    .checked_mul(reduce)
                    .and_then(|sz| sz.checked_mul(inner))
                    .and_then(|sz| sz.checked_mul(std::mem::size_of::<f32>()));
                (output, input)
            }
            KernelId::CATEGORY_NORMALIZATION => {
                // LayerNorm/RMSNorm: input = output = batch_size * hidden_size
                let batch = op.params.dims[0];
                let hidden = op.params.dims[1];
                let bytes = batch
                    .checked_mul(hidden)
                    .and_then(|sz| sz.checked_mul(std::mem::size_of::<f32>()));
                (bytes, bytes)
            }
            _ => return Ok(()), // Skip validation for other categories
        };

        // Validate output size
        if let Some(expected_bytes) = expected_output_bytes {
            if expected_bytes > 0 {
                for output_ref in &op.output_refs {
                    if let BufferRef::Workspace(slot) = output_ref {
                        // Use resolved dynamic workspace sizes if available, not static sizes
                        let (region_name, region_size) = if let Some(ref dws) =
                            self.dynamic_workspace
                        {
                            let resolved_region = dws.layout().regions.get(*slot).ok_or_else(|| {
                                BackendError::invalid_config(format!(
                                    "OP[{}] {:?}: output workspace slot {} out of bounds ({} resolved regions)",
                                    op_idx, op.kernel_id, slot, dws.layout().regions.len()
                                ))
                            })?;
                            (resolved_region.name.clone(), resolved_region.size)
                        } else {
                            let region = self.plan.workspace_layout.regions.get(*slot).ok_or_else(|| {
                                BackendError::invalid_config(format!(
                                    "OP[{}] {:?}: output workspace slot {} out of bounds ({} regions)",
                                    op_idx, op.kernel_id, slot, self.plan.workspace_layout.regions.len()
                                ))
                            })?;
                            (region.name.clone(), region.size as usize)
                        };

                        if expected_bytes > region_size {
                            return Err(BackendError::invalid_config(format!(
                                "OP[{}] {:?}: output size {} bytes exceeds workspace region '{}' \
                                 allocation of {} bytes. dims={:?}. \
                                 This indicates a compiler bug in shape inference or buffer allocation.",
                                op_idx, op.kernel_id, expected_bytes, region_name, region_size, op.params.dims
                            )));
                        }
                    }
                }
            }
        } else {
            return Err(BackendError::invalid_config(format!(
                "OP[{}] {:?}: output size overflow computing dims {:?}",
                op_idx, op.kernel_id, op.params.dims
            )));
        }

        // Validate input size (catches ReLU reading past input buffer bounds)
        if let Some(expected_bytes) = expected_input_bytes {
            if expected_bytes > 0 {
                for input_ref in &op.input_refs {
                    if let BufferRef::Workspace(slot) = input_ref {
                        // Use resolved dynamic workspace sizes if available, not static sizes
                        let (region_name, region_size) = if let Some(ref dws) =
                            self.dynamic_workspace
                        {
                            let resolved_region = dws.layout().regions.get(*slot).ok_or_else(|| {
                                BackendError::invalid_config(format!(
                                    "OP[{}] {:?}: input workspace slot {} out of bounds ({} resolved regions)",
                                    op_idx, op.kernel_id, slot, dws.layout().regions.len()
                                ))
                            })?;
                            (resolved_region.name.clone(), resolved_region.size)
                        } else {
                            let region = self.plan.workspace_layout.regions.get(*slot).ok_or_else(|| {
                                BackendError::invalid_config(format!(
                                    "OP[{}] {:?}: input workspace slot {} out of bounds ({} regions)",
                                    op_idx, op.kernel_id, slot, self.plan.workspace_layout.regions.len()
                                ))
                            })?;
                            (region.name.clone(), region.size as usize)
                        };

                        if expected_bytes > region_size {
                            return Err(BackendError::invalid_config(format!(
                                "OP[{}] {:?}: input size {} bytes exceeds workspace region '{}' \
                                 allocation of {} bytes. dims={:?}. \
                                 This indicates a compiler bug in shape inference or buffer allocation.",
                                op_idx, op.kernel_id, expected_bytes, region_name, region_size, op.params.dims
                            )));
                        }
                    }
                }
            }
        }

        // Special per-input validation for BinaryElementwise (handles broadcast correctly)
        // dims[2] = A size (first input), dims[1] = B size (second input)
        if category == KernelId::CATEGORY_ELEMENTWISE_BINARY {
            let input_sizes = [
                op.params.dims[2].checked_mul(std::mem::size_of::<f32>()), // A size
                op.params.dims[1].checked_mul(std::mem::size_of::<f32>()), // B size
            ];

            for (i, input_ref) in op.input_refs.iter().enumerate() {
                if let BufferRef::Workspace(slot) = input_ref {
                    let expected_bytes = input_sizes.get(i).and_then(|s| *s).unwrap_or(0);
                    if expected_bytes > 0 {
                        // Use resolved dynamic workspace sizes if available
                        let (region_name, region_size) = if let Some(ref dws) =
                            self.dynamic_workspace
                        {
                            let resolved_region = dws.layout().regions.get(*slot).ok_or_else(|| {
                                BackendError::invalid_config(format!(
                                    "OP[{}] {:?}: input[{}] workspace slot {} out of bounds ({} resolved regions)",
                                    op_idx, op.kernel_id, i, slot, dws.layout().regions.len()
                                ))
                            })?;
                            (resolved_region.name.clone(), resolved_region.size)
                        } else {
                            let region = self.plan.workspace_layout.regions.get(*slot).ok_or_else(|| {
                                BackendError::invalid_config(format!(
                                    "OP[{}] {:?}: input[{}] workspace slot {} out of bounds ({} regions)",
                                    op_idx, op.kernel_id, i, slot, self.plan.workspace_layout.regions.len()
                                ))
                            })?;
                            (region.name.clone(), region.size as usize)
                        };

                        if expected_bytes > region_size {
                            return Err(BackendError::invalid_config(format!(
                                "OP[{}] {:?}: input[{}] size {} bytes exceeds workspace region '{}' \
                                 allocation of {} bytes. dims={:?}. \
                                 This indicates a compiler bug in shape inference or buffer allocation.",
                                op_idx, op.kernel_id, i, expected_bytes, region_name, region_size, op.params.dims
                            )));
                        }
                    }
                }
            }
        }

        // Special per-input validation for GEMM (C[M,N] = A[M,K] @ B[K,N])
        // dims[0] = M, dims[1] = K, dims[2] = N
        if category == KernelId::CATEGORY_GEMM {
            let m = op.params.dims[0];
            let k = op.params.dims[1];
            let n = op.params.dims[2];
            let input_sizes = [
                m.checked_mul(k)
                    .and_then(|mk| mk.checked_mul(std::mem::size_of::<f32>())), // A[M,K]
                k.checked_mul(n)
                    .and_then(|kn| kn.checked_mul(std::mem::size_of::<f32>())), // B[K,N]
            ];

            for (i, input_ref) in op.input_refs.iter().enumerate() {
                if let BufferRef::Workspace(slot) = input_ref {
                    let expected_bytes = input_sizes.get(i).and_then(|s| *s).unwrap_or(0);
                    if expected_bytes > 0 {
                        // Use resolved dynamic workspace sizes if available
                        let (region_name, region_size) = if let Some(ref dws) =
                            self.dynamic_workspace
                        {
                            let resolved_region = dws.layout().regions.get(*slot).ok_or_else(|| {
                                BackendError::invalid_config(format!(
                                    "OP[{}] {:?}: input[{}] workspace slot {} out of bounds ({} resolved regions)",
                                    op_idx, op.kernel_id, i, slot, dws.layout().regions.len()
                                ))
                            })?;
                            (resolved_region.name.clone(), resolved_region.size)
                        } else {
                            let region = self.plan.workspace_layout.regions.get(*slot).ok_or_else(|| {
                                BackendError::invalid_config(format!(
                                    "OP[{}] {:?}: input[{}] workspace slot {} out of bounds ({} regions)",
                                    op_idx, op.kernel_id, i, slot, self.plan.workspace_layout.regions.len()
                                ))
                            })?;
                            (region.name.clone(), region.size as usize)
                        };

                        if expected_bytes > region_size {
                            return Err(BackendError::invalid_config(format!(
                                "OP[{}] {:?}: input[{}] size {} bytes ({}x{}={} elems) exceeds workspace region '{}' \
                                 allocation of {} bytes. dims=[M={}, K={}, N={}]. \
                                 This indicates a compiler bug in shape inference or buffer allocation.",
                                op_idx, op.kernel_id, i, expected_bytes,
                                if i == 0 { m } else { k }, if i == 0 { k } else { n },
                                expected_bytes / std::mem::size_of::<f32>(),
                                region_name, region_size, m, k, n
                            )));
                        }
                    }
                }
            }
        }

        Ok(())
    }

    fn sample_output_stats_for_ref(
        &self,
        backend: &dyn ProgramBackend,
        buf_ref: Option<&BufferRef>,
        handle: BufferHandle,
        max_elems: usize,
    ) -> Result<OutputSampleStats, BackendError> {
        if let Some(BufferRef::Workspace(slot)) = buf_ref {
            if let Some(ws) = self.workspace.as_ref() {
                let ptr = unsafe { ws.region_ptr(*slot) };
                if ptr.is_null() {
                    return Ok(OutputSampleStats::empty());
                }
                let size = self
                    .plan
                    .workspace_layout
                    .regions
                    .get(*slot)
                    .map(|region| region.size)
                    .unwrap_or(0);
                let bytes = unsafe { std::slice::from_raw_parts(ptr as *const u8, size as usize) };
                return sample_output_stats_from_bytes(bytes, max_elems);
            }
        }

        let size = backend.buffer_size(handle)?;
        let byte_len = size.min(max_elems.saturating_mul(std::mem::size_of::<f32>()));
        if byte_len < std::mem::size_of::<f32>() {
            return Ok(OutputSampleStats::empty());
        }
        let mut bytes = vec![0u8; byte_len];
        backend.copy_from_buffer(handle, &mut bytes)?;
        sample_output_stats_from_bytes(&bytes, max_elems)
    }

    /// Resolve a BufferRef to a BufferHandle.
    ///
    /// Uses match dispatch for zero-overhead buffer type resolution:
    /// - `Input(idx)`: index into inputs slice
    /// - `Output(idx)`: index into outputs slice
    /// - `Workspace(slot)`: creates handle from workspace pointer + slot offset
    #[inline]
    fn resolve_buffer_ref(
        &self,
        buf_ref: &BufferRef,
        inputs: &[BufferHandle],
        outputs: &[BufferHandle],
    ) -> Option<BufferHandle> {
        match buf_ref {
            BufferRef::Input(idx) => inputs.get(*idx).copied(),
            BufferRef::Output(idx) => outputs.get(*idx).copied(),
            BufferRef::Workspace(slot) => {
                // For workspace buffers, we create a handle from the workspace pointer
                // offset by the slot index. The slot represents a region in workspace.
                // Prefer dynamic workspace if available (resolved at runtime from input shapes).
                tracing::trace!("Resolving workspace slot {}", slot);
                if let Some(ref dws) = self.dynamic_workspace {
                    tracing::trace!("Using dynamic workspace for slot {}", slot);
                    let ptr = unsafe { dws.region_ptr(*slot) };
                    if ptr.is_null() {
                        let num_regions = dws.layout().regions.len();
                        tracing::error!(
                            "Dynamic workspace slot {} returned null pointer (layout has {} regions)",
                            slot, num_regions
                        );
                        None
                    } else {
                        if std::env::var("HOLOGRAM_TRACE_PTRS").is_ok() {
                            eprintln!(
                                "[hologram] Dynamic workspace slot {} => ptr={:p}, base={:p}, total_size={}",
                                slot, ptr, dws.base_ptr(), dws.total_size()
                            );
                        }
                        Some(BufferHandle::new(ptr as u64))
                    }
                } else {
                    // Fallback to static workspace
                    tracing::trace!("Using static workspace for slot {}", slot);
                    if self.workspace.is_none() {
                        tracing::error!("No static workspace available for slot {}", slot);
                        return None;
                    }
                    self.workspace.as_ref().and_then(|ws| {
                        let ptr = unsafe { ws.region_ptr(*slot) };
                        if ptr.is_null() {
                            tracing::error!(
                                "Static workspace slot {} returned null pointer",
                                slot
                            );
                            None
                        } else {
                            if std::env::var("HOLOGRAM_TRACE_PTRS").is_ok() {
                                eprintln!(
                                    "[hologram] Workspace slot {} => ptr={:p}, base={:p}, total_size={}",
                                    slot, ptr, ws.base_ptr(), ws.total_size()
                                );
                            }
                            Some(BufferHandle::new(ptr as u64))
                        }
                    })
                }
            }
            BufferRef::Constant { offset, size } => {
                // Zero-copy: return pointer directly into constant data source.
                // Use external mmap'd source if available, otherwise embedded constant_data.
                // For bundle format, constants_base_offset points to the weights section.
                let ptr = if let Some(mmap) = &self.external_constants {
                    // Add base offset (for bundle format) + weight offset
                    let mmap_slice = mmap.as_slice();
                    let mmap_len = mmap_slice.len();
                    let total_offset = self.constants_base_offset + *offset;
                    let end_offset = total_offset + *size;

                    // Bounds check: ensure we don't access outside mmap
                    if end_offset > mmap_len {
                        tracing::error!(
                            "BOUNDS ERROR: Constant access out of bounds! \
                             base_offset={}, const_offset={}, size={}, \
                             total_offset={}, end_offset={}, mmap_len={}",
                            self.constants_base_offset,
                            offset,
                            size,
                            total_offset,
                            end_offset,
                            mmap_len
                        );
                        return None;
                    }

                    mmap_slice.as_ptr().wrapping_add(total_offset)
                } else {
                    self.plan.constant_data.as_ptr().wrapping_add(*offset)
                };

                Some(BufferHandle::new(ptr as u64))
            }
            BufferRef::ExternalConstant { path, offset, size } => {
                if let Some(provider) = &self.const_provider {
                    let base = self
                        .constants_base_offset
                        .checked_add(*offset)
                        .unwrap_or(*offset);
                    match provider.read_at(base, *size) {
                        Ok(chunk) => {
                            let ptr = chunk.data.as_ptr();
                            return Some(BufferHandle::new(ptr as u64));
                        }
                        Err(err) => {
                            tracing::error!(
                                "ConstProvider failed for path {} offset {} size {}: {:?}",
                                path,
                                offset,
                                size,
                                err
                            );
                            return None;
                        }
                    }
                }
                let mmap = match self.external_constant_maps.get(path) {
                    Some(m) => m,
                    None => {
                        tracing::error!("No mmap found for external constant path {}", path);
                        return None;
                    }
                };
                let slice = mmap.as_slice();
                let end = offset.saturating_add(*size);
                if end > slice.len() {
                    tracing::error!(
                        "External constant out of bounds: path={} offset={} size={} len={}",
                        path,
                        offset,
                        size,
                        slice.len()
                    );
                    return None;
                }
                let ptr = slice.as_ptr().wrapping_add(*offset);
                Some(BufferHandle::new(ptr as u64))
            }
        }
    }

    /// Resolve BufferHandle to pointer, with workspace fallback.
    ///
    /// First tries backend lookup. If that fails, checks if the handle
    /// represents a workspace pointer and returns it directly.
    ///
    /// This handles the case where workspace-derived BufferHandles store
    /// the raw pointer as their ID, which the backend doesn't recognize.
    #[inline]
    fn resolve_handle_to_ptr(
        &self,
        handle: BufferHandle,
        backend: &dyn ProgramBackend,
    ) -> Option<*mut u8> {
        // Try backend lookup first (fast path for input/output buffers)
        if let Some(ptr) = backend.get_buffer_ptr(handle) {
            return Some(ptr);
        }

        let ptr = handle.id() as *mut u8;

        // Fallback 1: check if this is a workspace handle
        // Workspace handles store the raw pointer as handle ID
        if let Some(ws) = &self.workspace {
            if ws.contains_ptr(ptr as *const u8) {
                return Some(ptr);
            }
        }

        // Fallback 1b: check if this is a dynamic workspace handle
        if let Some(ref dws) = self.dynamic_workspace {
            let base = dws.base_ptr();
            let size = dws.total_size();
            let ptr_addr = ptr as usize;
            let base_addr = base as usize;
            if ptr_addr >= base_addr && ptr_addr < base_addr + size {
                return Some(ptr);
            }
        }

        // Fallback 2: check if this is an external constants handle (mmap'd)
        // External constants handles store pointer into the mmap'd file
        if let Some(mmap) = &self.external_constants {
            let slice = mmap.as_slice();
            let mmap_start = slice.as_ptr() as usize;
            let mmap_end = mmap_start + slice.len();
            let ptr_addr = ptr as usize;
            if ptr_addr >= mmap_start && ptr_addr < mmap_end {
                return Some(ptr);
            }
        }

        // Fallback 3: check if this is an embedded constant data handle
        // Constant handles store pointer into plan.constant_data as handle ID
        if !self.plan.constant_data.is_empty() {
            let const_start = self.plan.constant_data.as_ptr() as usize;
            let const_end = const_start + self.plan.constant_data.len();
            let ptr_addr = ptr as usize;
            if ptr_addr >= const_start && ptr_addr < const_end {
                return Some(ptr);
            }
        }

        None
    }

    /// Execute a single kernel from the plan.
    ///
    /// Dispatches to the appropriate kernel based on `kernel_id`.
    /// Uses the `KernelTable` function pointers for direct dispatch.
    /// Buffer handles are pre-resolved to actual data pointers before calling kernels.
    fn execute_kernel(
        &mut self,
        op_idx: usize,
        inputs: &[BufferHandle],
        outputs: &[BufferHandle],
        backend: &dyn ProgramBackend,
    ) -> BackendResult<()> {
        let op = &self.plan.ops[op_idx];

        // Get kernel function from table based on kernel category
        // Category is the upper byte of kernel_id (e.g., 0x01 for GEMM, 0x02 for Conv)
        let kernel_fn = match op.kernel_id.category() {
            KernelId::CATEGORY_NOOP => {
                // NOOP - return early, no actual kernel execution needed
                return Ok(());
            }
            KernelId::CATEGORY_GEMM => self.plan.kernel_table.gemm.get(op.kernel_idx).copied(),
            KernelId::CATEGORY_CONV => self.plan.kernel_table.conv.get(op.kernel_idx).copied(),
            KernelId::CATEGORY_ELEMENTWISE_BINARY => self
                .plan
                .kernel_table
                .elementwise_binary
                .get(op.kernel_idx)
                .copied(),
            KernelId::CATEGORY_ACTIVATION => self
                .plan
                .kernel_table
                .activation
                .get(op.kernel_idx)
                .copied(),
            KernelId::CATEGORY_TRANSCENDENTAL => self
                .plan
                .kernel_table
                .transcendental
                .get(op.kernel_idx)
                .copied(),
            KernelId::CATEGORY_REDUCE => self.plan.kernel_table.reduce.get(op.kernel_idx).copied(),
            KernelId::CATEGORY_TENSOR_OPS => self
                .plan
                .kernel_table
                .tensor_ops
                .get(op.kernel_idx)
                .copied(),
            KernelId::CATEGORY_NORMALIZATION => self
                .plan
                .kernel_table
                .normalization
                .get(op.kernel_idx)
                .copied(),
            KernelId::CATEGORY_LOSS => self.plan.kernel_table.loss.get(op.kernel_idx).copied(),
            KernelId::CATEGORY_COMPARISON => self
                .plan
                .kernel_table
                .comparison
                .get(op.kernel_idx)
                .copied(),
            KernelId::CATEGORY_BITWISE => {
                self.plan.kernel_table.bitwise.get(op.kernel_idx).copied()
            }
            KernelId::CATEGORY_LINALG => self.plan.kernel_table.linalg.get(op.kernel_idx).copied(),
            KernelId::CATEGORY_POOLING => {
                self.plan.kernel_table.pooling.get(op.kernel_idx).copied()
            }
            KernelId::CATEGORY_DYNAMIC_MIN..=0xFF if op.kernel_id.is_dynamic() => {
                // Dynamic kernel - look up in dynamic kernel table
                crate::plan::dynamic_kernel_table().get(op.kernel_id)
            }
            category => {
                return Err(BackendError::invalid_config(format!(
                    "Unknown kernel category 0x{:02X} for kernel_id {:?} at op {}",
                    category, op.kernel_id, op_idx
                )));
            }
        };

        let kernel_fn = kernel_fn.ok_or_else(|| {
            BackendError::invalid_config(format!(
                "Kernel index {} out of bounds for kernel_id {:?}",
                op.kernel_idx, op.kernel_id
            ))
        })?;

        // Resolve buffer handles to actual data pointers.
        // Uses workspace-aware resolution to handle both backend and workspace handles.
        if op_idx == 49 && tracing::enabled!(tracing::Level::DEBUG) {
            tracing::debug!("OP[49] resolving inputs: {:?}", inputs);
        }
        let input_ptrs: Vec<*const u8> = inputs
            .iter()
            .map(|&h| {
                self.resolve_handle_to_ptr(h, backend)
                    .map(|p| p as *const u8)
                    .ok_or(BackendError::InvalidHandle(h))
            })
            .collect::<Result<Vec<_>, _>>()?;
        if op_idx == 49 && tracing::enabled!(tracing::Level::DEBUG) {
            tracing::debug!("OP[49] input_ptrs resolved: {:?}", input_ptrs);
        }

        let output_ptrs: Vec<*mut u8> = outputs
            .iter()
            .map(|&h| {
                self.resolve_handle_to_ptr(h, backend)
                    .ok_or(BackendError::InvalidHandle(h))
            })
            .collect::<Result<Vec<_>, _>>()?;
        if op_idx == 49 && tracing::enabled!(tracing::Level::DEBUG) {
            tracing::debug!("OP[49] output_ptrs resolved: {:?}", output_ptrs);
            tracing::debug!("OP[49] calling kernel {:?}", op.kernel_id);
        }

        // Special handling for Winograd with cached filters
        // Check if we have pre-transformed filter data in constant_data
        let constant_offset = op.params.extra[6];
        if (op.kernel_id == KernelId::CONV_WINOGRAD_F23
            || op.kernel_id == KernelId::CONV_WINOGRAD_F43)
            && constant_offset != NO_CONSTANT_DATA
        {
            return self.execute_winograd_cached(op_idx, &input_ptrs, &output_ptrs);
        }

        // Log details for reduce operations to help debug SIGSEGV issues
        if op.kernel_id.category() == KernelId::CATEGORY_REDUCE {
            tracing::debug!(
                "OP[{}] Reduce kernel {:?}: dims={:?}, input_refs={:?}, output_refs={:?}",
                op_idx,
                op.kernel_id,
                op.params.dims,
                op.input_refs,
                op.output_refs
            );
        }

        // Log details for activation operations to help debug buffer size mismatches
        if op.kernel_id.category() == KernelId::CATEGORY_ACTIVATION {
            tracing::info!(
                "OP[{}] Activation {:?}: dims={:?}, input_refs={:?}, output_refs={:?}",
                op_idx,
                op.kernel_id,
                op.params.dims,
                op.input_refs,
                op.output_refs
            );
            // Note: Activations can legitimately have Input refs as inputs when they follow
            // view operations (Unsqueeze, Reshape, etc.) that have been remapped to Input buffers.
            // The compiler validates the graph structure; here we just validate buffer sizes.
        }

        // Resolve dim_exprs FIRST before validation so we validate against runtime sizes
        let resolved_params = if op.params.has_dynamic_dims() {
            if op.params.needs_predecessor_info() {
                // Build predecessor element counts as a DENSE array matching input_refs order
                // CRITICAL: predecessor_slot in DimExpr SHOULD be an INDEX into input_refs (0, 1, 2, ...),
                // but the compiler sometimes sets it to workspace slot ID (bug).
                // We handle both: build dense array AND create slot_to_index mapping for workaround.

                // NEW APPROACH: Use ExecutionContext to build predecessor elements
                // This uses the centralized tracking instead of scattered state
                let mut predecessor_elements = self.execution_context.build_predecessor_elements(&op.input_refs);

                // Fallback for untracked tensors (early operations before tracking starts)
                // If ExecutionContext returns 0 for a Workspace buffer, fall back to allocation size
                for (idx, r) in op.input_refs.iter().enumerate() {
                    if predecessor_elements[idx] == 0 {
                        if let BufferRef::Workspace(slot) = r {
                            let fallback_size = if let Some(ref dws) = self.dynamic_workspace {
                                dws.layout()
                                    .regions
                                    .get(*slot)
                                    .map(|region| region.size / 4)
                                    .unwrap_or(0)
                            } else {
                                self.plan
                                    .workspace_layout
                                    .regions
                                    .get(*slot)
                                    .map(|region| (region.size / 4) as usize)
                                    .unwrap_or(0)
                            };
                            if op_idx == 46 && fallback_size > 0 {
                                tracing::warn!(
                                    "OP[{}] predecessor[{}]=Workspace({}) -> NOT TRACKED, using fallback region size={} elements",
                                    op_idx, idx, slot, fallback_size
                                );
                            }
                            predecessor_elements[idx] = fallback_size;
                        } else if let BufferRef::Input(input_id) = r {
                            // Also handle Input buffers via shape registry if not in ExecutionContext yet
                            let input_size = self.shape_registry
                                .get(&(*input_id as u64))
                                .map(|shape| shape.iter().product::<usize>())
                                .unwrap_or(0);
                            predecessor_elements[idx] = input_size;
                        }
                    }
                }

                // For debugging/logging in OP[46], check the values
                if op_idx == 46 {
                    for (idx, r) in op.input_refs.iter().enumerate() {
                        if let BufferRef::Workspace(slot) = r {
                            tracing::warn!(
                                "OP[{}] predecessor[{}]=Workspace({}) -> final size={} elements",
                                op_idx, idx, slot, predecessor_elements[idx]
                            );
                        }
                    }
                }

                // Build slot_to_index mapping for workspace slots (needed for sparse array workaround)
                let mut slot_to_index: FxHashMap<usize, usize> = FxHashMap::default();
                for (idx, r) in op.input_refs.iter().enumerate() {
                    if let BufferRef::Workspace(slot) = r {
                        slot_to_index.insert(*slot, idx);
                    }
                }

                // WORKAROUND for compiler bug: Build SPARSE array to handle both semantics
                // - Indices 0..input_refs.len(): Dense array (correct semantic)
                // - Indices = workspace slot IDs: Sparse array (buggy semantic)
                // This way resolve_dims_with_predecessors works regardless of which semantic the compiler used.
                let max_slot_id = slot_to_index.keys().max().copied().unwrap_or(0);
                let sparse_size = (max_slot_id + 1).max(predecessor_elements.len());
                let mut predecessor_elements_sparse = vec![0usize; sparse_size];

                // Fill dense part (indices 0, 1, 2...)
                for (idx, &elem) in predecessor_elements.iter().enumerate() {
                    predecessor_elements_sparse[idx] = elem;
                }

                // Fill sparse part (workspace slot IDs)
                for (&slot, &idx) in &slot_to_index {
                    if slot < sparse_size {
                        predecessor_elements_sparse[slot] = predecessor_elements[idx];
                    }
                }

                let input_shapes = self.build_input_shapes_array();
                if op_idx == 46 || op_idx == 9 {
                    tracing::warn!(
                        "OP[{}] resolving dims with predecessor_elements_sparse[0..10]={:?}, op.params.dims={:?}, dim_exprs={:?}",
                        op_idx, &predecessor_elements_sparse[..10.min(sparse_size)],
                        op.params.dims, op.params.dim_exprs
                    );
                    // For OP[9], also show the relevant slot
                    if op_idx == 9 && sparse_size > 7 {
                        tracing::warn!(
                            "OP[{}] predecessor_elements_sparse[7]={} (Workspace 7)",
                            op_idx, predecessor_elements_sparse[7]
                        );
                    }
                }
                let resolved = op.params
                    .resolve_dims_with_predecessors(&input_shapes, &predecessor_elements_sparse);
                if op_idx == 46 || op_idx == 9 {
                    tracing::warn!(
                        "OP[{}] resolved_dims={:?}",
                        op_idx, resolved.dims
                    );
                }
                resolved
            } else {
                let input_shapes = self.build_input_shapes_array();
                op.params.resolve_dims(&input_shapes)
            }
        } else {
            op.params.clone()
        };

        // Validate input/output buffer sizes AFTER dimension resolution
        // Create a temporary op with resolved params for validation
        let op_for_validation = crate::plan::PlanOp {
            kernel_id: op.kernel_id,
            kernel_idx: op.kernel_idx,
            params: resolved_params.clone(),
            input_refs: op.input_refs.clone(),
            output_refs: op.output_refs.clone(),
            epilogue: op.epilogue.clone(),
            partition: op.partition.clone(),
        };
        self.validate_kernel_output_sizes(op_idx, &op_for_validation)?;

        // Execute the kernel with resolved pointers and params
        kernel_fn(
            &input_ptrs,
            &output_ptrs,
            &resolved_params,
            &self.plan.lookup_tables(),
        )?;

        if !op.epilogue.is_empty() {
            self.apply_epilogue(op, &output_ptrs)?;
        }

        // Track actual tensor sizes written to workspace slots.
        // CRITICAL: This enables DimExpr::PredecessorElementsDiv to use actual tensor sizes
        // instead of workspace region allocation sizes.
        // Different kernel categories use different formulas for output size (not just product of dims).
        let output_element_count = match op.kernel_id.category() {
            crate::plan::KernelId::CATEGORY_GEMM => {
                // GEMM: C[M,N] = A[M,K] @ B[K,N], output size = M * N
                let m = resolved_params.dims[0];
                let n = resolved_params.dims[2];
                m * n
            }
            crate::plan::KernelId::CATEGORY_ACTIVATION
            | crate::plan::KernelId::CATEGORY_TRANSCENDENTAL => {
                // Unary ops: output size = dims[0] (element count)
                resolved_params.dims[0]
            }
            crate::plan::KernelId::CATEGORY_ELEMENTWISE_BINARY => {
                // Binary ops: output size = dims[0]
                resolved_params.dims[0]
            }
            crate::plan::KernelId::CATEGORY_TENSOR_OPS => {
                // For most tensor ops, dims[0] is the element count
                // But for Gather operations, dims[3] holds the output total
                // Heuristic: if dims[3] > 0 and looks reasonable, use it; otherwise use dims[0]
                if resolved_params.dims[3] > 0 && resolved_params.dims[3] < 1_000_000_000 {
                    resolved_params.dims[3]
                } else {
                    resolved_params.dims[0]
                }
            }
            crate::plan::KernelId::CATEGORY_REDUCE => {
                // Reduce: output = outer * inner
                let outer = resolved_params.dims[0];
                let inner = resolved_params.dims[2];
                outer * inner
            }
            crate::plan::KernelId::CATEGORY_NORMALIZATION => {
                // LayerNorm/RMSNorm: output = batch * hidden
                let batch = resolved_params.dims[0];
                let hidden = resolved_params.dims[1];
                batch * hidden
            }
            _ => {
                // For other categories (Conv, Pooling, etc.), use dims[0] as default
                // or product if that makes more sense. For Gather (0x03xx kernel IDs),
                // dims[3] typically holds the output total.
                // Check if dims[3] looks like an output size (non-zero, reasonable value)
                if resolved_params.dims[3] > 0 && resolved_params.dims[3] < 1_000_000_000 {
                    resolved_params.dims[3]
                } else {
                    // Fallback: use dims[0]
                    resolved_params.dims[0]
                }
            }
        };

        // Track tensor metadata in execution context (NEW centralized approach)
        self.execution_context.set_current_op(op_idx);
        for output_ref in &op.output_refs {
            match output_ref {
                BufferRef::Workspace(slot) => {
                    if op_idx < 50 {
                        tracing::warn!(
                            "OP[{}] tracking: Workspace({}) <- {} elements (dims={:?}, category=0x{:02x})",
                            op_idx, slot, output_element_count, resolved_params.dims, op.kernel_id.category()
                        );
                    }
                    // Old approach (will be removed in later step)
                    self.workspace_tensor_sizes.insert(*slot, output_element_count);

                    // New approach: register in execution context
                    self.execution_context.register_tensor(
                        crate::core::context::BufferLocation::Workspace(*slot),
                        output_element_count,
                        Some(resolved_params.dims.to_vec()),
                        crate::core::context::DataType::Float32, // TODO: track actual dtype
                    );
                }
                BufferRef::Output(id) => {
                    // Track outputs as well
                    self.execution_context.register_tensor(
                        crate::core::context::BufferLocation::Output(*id),
                        output_element_count,
                        Some(resolved_params.dims.to_vec()),
                        crate::core::context::DataType::Float32,
                    );
                }
                _ => {}
            }
        }

        Ok(())
    }

    /// Build an array of input shapes for DimExpr resolution.
    ///
    /// Converts the `shape_registry` entries for model inputs into the format
    /// expected by `KernelParams::resolve_dims()`.
    fn build_input_shapes_array(&self) -> Vec<[usize; 4]> {
        (0..self.plan.layout_metadata.num_inputs)
            .map(|i| {
                self.shape_registry
                    .get(&(i as u64))
                    .map(|s| {
                        let mut arr = [1usize; 4];
                        for (j, &d) in s.iter().take(4).enumerate() {
                            arr[j] = d;
                        }
                        arr
                    })
                    .unwrap_or([1, 1, 1, 1])
            })
            .collect()
    }

    fn apply_epilogue(&self, op: &crate::plan::PlanOp, outputs: &[*mut u8]) -> BackendResult<()> {
        if outputs.is_empty() {
            return Ok(());
        }

        // Determine number of f32 elements to process; dims[3] carries output numel when set.
        let len = op.params.dims[3];
        if len == 0 {
            return Ok(());
        }

        let out_ptr = outputs[0] as *mut f32;
        let out_slice = unsafe { std::slice::from_raw_parts_mut(out_ptr, len) };

        // Bias constants live in either embedded constant_data or external mmap.
        let const_base = if let Some(mmap) = &self.external_constants {
            let ptr = mmap.as_slice().as_ptr();
            unsafe { ptr.add(self.constants_base_offset) as *const f32 }
        } else {
            self.plan.constant_data.as_ptr() as *const f32
        };

        let tables = self.plan.lookup_tables();

        for (i, v) in out_slice.iter_mut().enumerate() {
            // Safety: const_base points to valid constant data; epilogue indexing guarded by compiler offsets.
            *v = unsafe {
                crate::core::epilogue::EpilogueApply::apply_chain_with_tables(
                    &op.epilogue,
                    *v,
                    const_base,
                    i,
                    &tables,
                )
            };
        }

        Ok(())
    }

    /// Execute Winograd convolution with a cached (pre-transformed) filter.
    ///
    /// This path avoids the expensive filter transform by using pre-computed
    /// data from `plan.constant_data`. The filter was transformed at compile
    /// time by `finalize_with_weights()` in the compiler pipeline.
    ///
    /// # KernelParams Layout
    /// - `extra[0]`: out_channels (filters)
    /// - `extra[1]`: in_channels
    /// - `extra[2]`: input_height
    /// - `extra[3]`: input_width
    /// - `extra[4]`: stride
    /// - `extra[5]`: Winograd variant marker (F23=23, F43=43)
    /// - `extra[6]`: Offset into constant_data
    /// - `extra[7]`: Size of prepacked filter data in bytes
    fn execute_winograd_cached(
        &self,
        op_idx: usize,
        input_ptrs: &[*const u8],
        output_ptrs: &[*mut u8],
    ) -> BackendResult<()> {
        let op = &self.plan.ops[op_idx];
        let params = &op.params;

        // Extract convolution dimensions from params
        let out_channels = params.extra[0];
        let in_channels = params.extra[1];
        let in_height = params.extra[2];
        let in_width = params.extra[3];
        let _stride = params.extra[4];
        let winograd_marker = params.extra[5];
        let constant_offset = params.extra[6];
        let constant_size = params.extra[7];

        // Validate we have input and output buffers
        if input_ptrs.is_empty() || output_ptrs.is_empty() {
            return Err(BackendError::invalid_config(
                "Winograd kernel requires input and output buffers",
            ));
        }

        // Extract the prepacked filter from constant_data
        if constant_offset + constant_size > self.plan.constant_data.len() {
            return Err(BackendError::invalid_config(format!(
                "Constant data bounds error: offset {} + size {} > constant_data.len() {}",
                constant_offset,
                constant_size,
                self.plan.constant_data.len()
            )));
        }

        let filter_bytes =
            &self.plan.constant_data[constant_offset..constant_offset + constant_size];

        // Determine variant based on marker
        let variant = if winograd_marker == WINOGRAD_F23_MARKER {
            WinogradVariant::F23
        } else {
            WinogradVariant::F43
        };

        // Reconstruct the prepacked filter
        let prepacked =
            prepacked_filter_from_bytes(filter_bytes, out_channels, in_channels, variant);

        // Calculate output dimensions for Winograd F(2,3): stride=1, same padding assumed
        // Output size = input size for same padding with 3x3 kernel and stride 1
        let out_height = in_height; // Simplified: assumes same padding
        let out_width = in_width;

        // Create input and output slices
        let input_size = in_channels * in_height * in_width;
        let output_size = out_channels * out_height * out_width;

        let input = unsafe { std::slice::from_raw_parts(input_ptrs[0] as *const f32, input_size) };
        let output =
            unsafe { std::slice::from_raw_parts_mut(output_ptrs[0] as *mut f32, output_size) };

        // Execute Winograd convolution with cached filter
        // Note: Only F(2,3) is implemented currently
        if winograd_marker == WINOGRAD_F23_MARKER {
            winograd_conv2d_f23(
                output,
                input,
                &prepacked,
                None, // No bias for now
                1,    // batch_size = 1
                in_channels,
                in_height,
                in_width,
                out_channels,
                out_height,
                out_width,
                0, // pad_h
                0, // pad_w
            );
        } else {
            // F(4,3) not yet implemented, fallback to error
            return Err(BackendError::invalid_config(
                "Winograd F(4,3) with cached filters not yet implemented",
            ));
        }

        Ok(())
    }

    /// Validate that buffer counts match plan expectations.
    fn validate_buffers(
        &self,
        inputs: &[BufferHandle],
        outputs: &[BufferHandle],
    ) -> BackendResult<()> {
        // Find max input/output indices in ops by extracting from BufferRef
        let max_input = self
            .plan
            .ops
            .iter()
            .flat_map(|op| op.input_refs.iter().chain(op.output_refs.iter()))
            .filter_map(|buf_ref| match buf_ref {
                BufferRef::Input(idx) => Some(*idx),
                _ => None,
            })
            .max()
            .unwrap_or(0);

        let max_output = self
            .plan
            .ops
            .iter()
            .flat_map(|op| op.input_refs.iter().chain(op.output_refs.iter()))
            .filter_map(|buf_ref| match buf_ref {
                BufferRef::Output(idx) => Some(*idx),
                _ => None,
            })
            .max()
            .unwrap_or(0);

        if max_input > 0 && inputs.len() <= max_input {
            return Err(BackendError::invalid_config(format!(
                "Plan requires at least {} inputs, got {}",
                max_input + 1,
                inputs.len()
            )));
        }

        if max_output > 0 && outputs.len() <= max_output {
            return Err(BackendError::invalid_config(format!(
                "Plan requires at least {} outputs, got {}",
                max_output + 1,
                outputs.len()
            )));
        }

        Ok(())
    }

    /// Allocate workspace memory.
    ///
    /// Allocates aligned memory for workspace using the system allocator.
    /// The workspace is used for intermediate buffers during kernel execution.
    fn allocate_workspace(
        layout: &WorkspaceLayout,
        _backend: &dyn ProgramBackend,
    ) -> BackendResult<WorkspaceHandle> {
        if layout.total_size == 0 {
            return Ok(WorkspaceHandle::null());
        }

        let aligned_layout = std::alloc::Layout::from_size_align(
            layout.total_size as usize,
            (layout.alignment.max(1)) as usize,
        )
        .map_err(|_| BackendError::buffer("Invalid workspace layout"))?;

        let ptr = unsafe { std::alloc::alloc(aligned_layout) };
        if ptr.is_null() {
            return Err(BackendError::buffer("Failed to allocate workspace"));
        }

        Ok(unsafe { WorkspaceHandle::new(ptr, layout.clone()) })
    }

    /// Reset the executor for reuse.
    ///
    /// Clears statistics but keeps workspace allocation.
    pub fn reset(&mut self) {
        self.last_stats = ExecutionStats::default();
    }

    /// Get total workspace size in bytes.
    pub fn workspace_size(&self) -> usize {
        self.plan.workspace_layout.total_size as usize
    }

    /// Get number of operations in the plan.
    pub fn num_ops(&self) -> usize {
        self.plan.ops.len()
    }

    // ========================================================================
    // BufferView API - Lifetime-Bounded Buffer Access
    // ========================================================================

    /// Get a lifetime-bounded view of workspace memory.
    ///
    /// The returned `BufferView` cannot outlive `self`, preventing use-after-free
    /// errors when workspace is deallocated or reallocated.
    ///
    /// # Safety
    ///
    /// This method is safe because the returned view's lifetime is tied to `&self`,
    /// ensuring the workspace memory remains valid.
    pub fn workspace_view(&self) -> Option<BufferView<'_>> {
        self.workspace.as_ref().map(|ws| {
            // SAFETY: WorkspaceHandle's memory is valid for at least as long as `self`
            unsafe { BufferView::new(ws.base_ptr() as *const u8, ws.total_size()) }
        })
    }

    /// Get a lifetime-bounded view of constant data embedded in the plan.
    ///
    /// This provides zero-copy access to model weights and other constant data
    /// without exposing raw pointers.
    pub fn constant_view(&self) -> BufferView<'_> {
        // SAFETY: plan.constant_data is valid for at least as long as `self`
        unsafe {
            BufferView::new(
                self.plan.constant_data.as_ptr(),
                self.plan.constant_data.len(),
            )
        }
    }

    /// Get a lifetime-bounded view of a specific buffer reference.
    ///
    /// Resolves the `BufferRef` and returns a safe view into the underlying data.
    /// Returns `None` if the buffer reference cannot be resolved (e.g., dynamic
    /// workspace not yet allocated, or external constant not mapped).
    ///
    /// # Arguments
    ///
    /// * `buf_ref` - The buffer reference to resolve
    /// * `inputs` - Input buffers provided by the caller
    /// * `outputs` - Output buffers provided by the caller
    pub fn view_buffer<'a>(
        &'a self,
        buf_ref: &BufferRef,
        inputs: &'a [&'a [u8]],
        outputs: &'a [&'a [u8]],
    ) -> Option<BufferView<'a>> {
        match buf_ref {
            BufferRef::Input(idx) => {
                inputs.get(*idx).map(|slice| {
                    // SAFETY: Input slice lifetime is 'a, same as returned view
                    unsafe { BufferView::new(slice.as_ptr(), slice.len()) }
                })
            }
            BufferRef::Output(idx) => {
                outputs.get(*idx).map(|slice| {
                    // SAFETY: Output slice lifetime is 'a, same as returned view
                    unsafe { BufferView::new(slice.as_ptr(), slice.len()) }
                })
            }
            BufferRef::Workspace(slot) => {
                self.workspace.as_ref().and_then(|ws| {
                    let layout = &self.plan.workspace_layout;
                    layout.regions.get(*slot).map(|region| {
                        let offset = region.offset as usize;
                        let size = region.size as usize;
                        // SAFETY: Region bounds are validated at plan creation
                        unsafe { BufferView::new((ws.base_ptr() as *const u8).add(offset), size) }
                    })
                })
            }
            BufferRef::Constant { offset, size } => {
                let data = &self.plan.constant_data;
                if *offset + *size <= data.len() {
                    // SAFETY: Bounds checked above, constant_data lives as long as plan
                    Some(unsafe { BufferView::new(data.as_ptr().add(*offset), *size) })
                } else {
                    None
                }
            }
            BufferRef::ExternalConstant { path, offset, size } => {
                self.external_constant_maps.get(path).map(|mmap| {
                    let slice = mmap.as_slice();
                    // SAFETY: MappedInput is valid as long as executor holds the Arc
                    unsafe { BufferView::new(slice.as_ptr().add(*offset), *size) }
                })
            }
        }
    }
}

#[derive(Debug)]
struct OutputSampleStats {
    count: usize,
    nonzero: usize,
    zeros: usize,
    ones: usize,
    neg_inf: usize,
    min: f32,
    max: f32,
    mean: f32,
    sample: Vec<f32>,
}

impl OutputSampleStats {
    fn empty() -> Self {
        Self {
            count: 0,
            nonzero: 0,
            zeros: 0,
            ones: 0,
            neg_inf: 0,
            min: f32::INFINITY,
            max: f32::NEG_INFINITY,
            mean: 0.0,
            sample: Vec::new(),
        }
    }
}

fn is_attention_mask_kernel(kernel_id: KernelId) -> bool {
    matches!(
        kernel_id,
        KernelId::NOOP | KernelId::ELEM_SUB | KernelId::ELEM_MUL
    )
}

fn sample_output_stats_from_bytes(
    bytes: &[u8],
    max_elems: usize,
) -> Result<OutputSampleStats, BackendError> {
    if bytes.len() < std::mem::size_of::<f32>() {
        return Ok(OutputSampleStats::empty());
    }
    let byte_len = bytes
        .len()
        .min(max_elems.saturating_mul(std::mem::size_of::<f32>()));
    let mut min_val = f32::INFINITY;
    let mut max_val = f32::NEG_INFINITY;
    let mut sum = 0.0f64;
    let mut count = 0usize;
    let mut nonzero = 0usize;
    let mut zeros = 0usize;
    let mut ones = 0usize;
    let mut neg_inf = 0usize;
    let mut sample = Vec::new();

    for chunk in bytes[..byte_len].chunks_exact(4) {
        let value = f32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]);
        count += 1;
        if value != 0.0 {
            nonzero += 1;
        } else {
            zeros += 1;
        }
        if (value - 1.0).abs() <= f32::EPSILON {
            ones += 1;
        }
        if value.is_infinite() && value.is_sign_negative() {
            neg_inf += 1;
        }
        if value < min_val {
            min_val = value;
        }
        if value > max_val {
            max_val = value;
        }
        sum += value as f64;
        if sample.len() < 16 {
            sample.push(value);
        }
    }

    let mean = if count > 0 {
        (sum / count as f64) as f32
    } else {
        0.0
    };

    Ok(OutputSampleStats {
        count,
        nonzero,
        zeros,
        ones,
        neg_inf,
        min: if count > 0 { min_val } else { 0.0 },
        max: if count > 0 { max_val } else { 0.0 },
        mean,
        sample,
    })
}

/// Builder for creating plan executors with custom configuration.
#[derive(Debug, Clone)]
pub struct ExecutorBuilder {
    profiling: bool,
    validate: bool,
}

impl ExecutorBuilder {
    /// Create a new builder with default settings.
    pub fn new() -> Self {
        Self {
            profiling: false,
            validate: true,
        }
    }

    /// Enable profiling.
    pub fn with_profiling(mut self) -> Self {
        self.profiling = true;
        self
    }

    /// Disable input/output validation.
    pub fn without_validation(mut self) -> Self {
        self.validate = false;
        self
    }

    /// Build the executor.
    pub fn build(
        self,
        plan: BackendPlan,
        backend: &dyn ProgramBackend,
    ) -> BackendResult<PlanExecutor> {
        let mut executor = PlanExecutor::new(plan, backend)?;
        executor.set_profiling(self.profiling);
        Ok(executor)
    }
}

impl Default for ExecutorBuilder {
    fn default() -> Self {
        Self::new()
    }
}

/// Convenience function to execute a plan in one call.
///
/// Creates a temporary executor with workspace and executes the plan.
pub fn execute_plan(
    plan: BackendPlan,
    inputs: &[BufferHandle],
    outputs: &[BufferHandle],
    backend: &dyn ProgramBackend,
) -> BackendResult<()> {
    // Create temporary executor
    let mut executor = PlanExecutor::new(plan, backend)?;
    executor.execute(inputs, outputs, backend)
}

/// Batch executor for running multiple plans.
///
/// Useful for executing a sequence of plans that share resources.
pub struct BatchExecutor {
    executors: Vec<PlanExecutor>,
    current: usize,
}

impl BatchExecutor {
    /// Create a new batch executor.
    pub fn new() -> Self {
        Self {
            executors: Vec::new(),
            current: 0,
        }
    }

    /// Add a plan to the batch.
    pub fn add_plan(
        &mut self,
        plan: BackendPlan,
        backend: &dyn ProgramBackend,
    ) -> BackendResult<usize> {
        let idx = self.executors.len();
        let executor = PlanExecutor::new(plan, backend)?;
        self.executors.push(executor);
        Ok(idx)
    }

    /// Execute a specific plan by index.
    pub fn execute(
        &mut self,
        plan_idx: usize,
        inputs: &[BufferHandle],
        outputs: &[BufferHandle],
        backend: &dyn ProgramBackend,
    ) -> BackendResult<()> {
        let executor = self.executors.get_mut(plan_idx).ok_or_else(|| {
            BackendError::invalid_config(format!("Plan index {} not found", plan_idx))
        })?;

        executor.execute(inputs, outputs, backend)
    }

    /// Execute the next plan in sequence.
    pub fn execute_next(
        &mut self,
        inputs: &[BufferHandle],
        outputs: &[BufferHandle],
        backend: &dyn ProgramBackend,
    ) -> BackendResult<bool> {
        if self.current >= self.executors.len() {
            return Ok(false);
        }

        self.execute(self.current, inputs, outputs, backend)?;
        self.current += 1;
        Ok(true)
    }

    /// Reset to beginning of batch.
    pub fn reset(&mut self) {
        self.current = 0;
        for executor in &mut self.executors {
            executor.reset();
        }
    }

    /// Get number of plans in batch.
    pub fn len(&self) -> usize {
        self.executors.len()
    }

    /// Check if batch is empty.
    pub fn is_empty(&self) -> bool {
        self.executors.is_empty()
    }

    /// Get total workspace size across all plans.
    pub fn total_workspace_size(&self) -> usize {
        self.executors.iter().map(|e| e.workspace_size()).sum()
    }
}

impl Default for BatchExecutor {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[cfg(feature = "alloc-tracking")]
    use crate::alloc_tracker::TrackingAllocator;
    use crate::core::const_provider::ConstChunk;
    use crate::plan::{
        dynamic_kernel_table, EpilogueChain, KernelId, KernelParams, LookupTables, PlanOp,
        ThreadPartition, TileParams,
    };
    use crate::BackendType;
    use hologram_common::categorical::BYTE_META_TABLE;
    use hologram_lookup::PACKED_TABLE;
    use std::sync::atomic::{AtomicUsize, Ordering};

    #[cfg(feature = "alloc-tracking")]
    #[global_allocator]
    static GLOBAL: TrackingAllocator = TrackingAllocator;

    fn create_test_plan() -> BackendPlan {
        BackendPlan {
            backend_type: BackendType::Cpu,
            ops: vec![PlanOp {
                kernel_id: KernelId(1),
                kernel_idx: 0,
                params: KernelParams {
                    dims: [64, 64, 64, 0],
                    ..KernelParams::default()
                },
                epilogue: EpilogueChain::new(),
                partition: ThreadPartition::sequential(),
                input_refs: vec![BufferRef::Input(0), BufferRef::Input(1)],
                output_refs: vec![BufferRef::Output(0)],
            }],
            kernel_table: Default::default(),
            tile_params: TileParams::default(),
            layout_metadata: Default::default(),
            workspace_layout: crate::plan::WorkspaceLayout {
                total_size: 1024,
                alignment: 64,
                regions: vec![],
            },
            epilogue_chain: EpilogueChain::new(),
            thread_partition: ThreadPartition::sequential(),
            constant_data: Vec::new(),
            lookup_tables: LookupTables::default(),
        }
    }

    #[test]
    fn test_executor_without_workspace() {
        let plan = create_test_plan();
        let executor = PlanExecutor::without_workspace(plan);

        assert!(executor.workspace().is_none());
        assert_eq!(executor.num_ops(), 1);
    }

    #[test]
    fn test_execution_stats_default() {
        let stats = ExecutionStats::default();

        assert_eq!(stats.total_ns, 0);
        assert_eq!(stats.ops_executed, 0);
        assert_eq!(stats.avg_op_ns(), 0);
    }

    #[test]
    fn test_execution_stats_avg() {
        let stats = ExecutionStats {
            total_ns: 1000,
            op_timings: vec![200, 300, 500],
            workspace_bytes: 1024,
            ops_executed: 3,
        };

        assert_eq!(stats.avg_op_ns(), 333); // 1000 / 3
    }

    #[test]
    fn test_executor_builder_default() {
        let builder = ExecutorBuilder::default();
        assert!(!builder.profiling);
        assert!(builder.validate);
    }

    #[test]
    fn test_executor_builder_with_profiling() {
        let builder = ExecutorBuilder::new().with_profiling();
        assert!(builder.profiling);
    }

    #[test]
    fn test_batch_executor_new() {
        let batch = BatchExecutor::new();
        assert!(batch.is_empty());
        assert_eq!(batch.len(), 0);
    }

    #[test]
    fn test_batch_executor_reset() {
        let mut batch = BatchExecutor::new();
        batch.current = 5;
        batch.reset();
        assert_eq!(batch.current, 0);
    }

    #[test]
    fn test_executor_workspace_size() {
        let plan = create_test_plan();
        let executor = PlanExecutor::without_workspace(plan);

        assert_eq!(executor.workspace_size(), 1024);
    }

    #[test]
    fn test_executor_reset() {
        let plan = create_test_plan();
        let mut executor = PlanExecutor::without_workspace(plan);

        // Simulate some stats
        executor.last_stats = ExecutionStats {
            total_ns: 1000,
            op_timings: vec![1000],
            workspace_bytes: 1024,
            ops_executed: 1,
        };

        executor.reset();

        assert_eq!(executor.last_stats.total_ns, 0);
        assert_eq!(executor.last_stats.ops_executed, 0);
    }

    #[test]
    fn test_executor_profiling() {
        let plan = create_test_plan();
        let mut executor = PlanExecutor::without_workspace(plan);

        assert!(!executor.profiling);

        executor.set_profiling(true);
        assert!(executor.profiling);
    }

    #[test]
    fn test_validate_buffers_empty_ops() {
        let mut plan = create_test_plan();
        plan.ops.clear();

        let executor = PlanExecutor::without_workspace(plan);

        // Empty ops should validate with any buffers
        assert!(executor.validate_buffers(&[], &[]).is_ok());
    }

    #[test]
    fn test_stats_duration() {
        let stats = ExecutionStats {
            total_ns: 1_000_000, // 1ms
            op_timings: vec![],
            workspace_bytes: 0,
            ops_executed: 0,
        };

        let duration = stats.total_duration();
        assert_eq!(duration.as_micros(), 1000);
    }

    #[test]
    fn test_batch_total_workspace() {
        let batch = BatchExecutor::new();
        assert_eq!(batch.total_workspace_size(), 0);
    }

    #[test]
    fn test_executor_plan_access() {
        let plan = create_test_plan();
        let plan_ops_len = plan.ops.len();
        let executor = PlanExecutor::without_workspace(plan);

        assert_eq!(executor.plan().ops.len(), plan_ops_len);
    }

    #[test]
    fn executor_exposes_canonical_lookup_tables() {
        let plan = create_test_plan();
        let executor = PlanExecutor::without_workspace(plan);
        let tables = executor.lookup_tables();

        assert_eq!(tables.packed_table as *const _, &PACKED_TABLE as *const _);
        assert_eq!(
            tables.byte_meta_table as *const _,
            &BYTE_META_TABLE as *const _
        );
    }

    #[test]
    fn kernels_receive_plan_lookup_tables() {
        static SEEN: AtomicUsize = AtomicUsize::new(0);

        fn probe_kernel(
            _inputs: &[*const u8],
            _outputs: &[*mut u8],
            _params: &KernelParams,
            tables: &LookupTables,
        ) -> Result<(), BackendError> {
            SEEN.store(tables.packed_table as *const _ as usize, Ordering::SeqCst);
            Ok(())
        }

        let kernel_id = dynamic_kernel_table().register(probe_kernel);

        let mut plan = BackendPlan::new(BackendType::Cpu);
        plan.ops.push(PlanOp {
            kernel_id,
            kernel_idx: 0,
            params: KernelParams::default(),
            epilogue: EpilogueChain::new(),
            partition: ThreadPartition::sequential(),
            input_refs: Vec::new(),
            output_refs: Vec::new(),
        });

        let backend = crate::cpu::CpuBackend::new();
        let mut executor = PlanExecutor::without_workspace(plan.clone());
        executor.execute(&[], &[], &backend).unwrap();

        assert_eq!(
            SEEN.load(Ordering::SeqCst),
            plan.lookup_tables().packed_table as *const _ as usize
        );
    }

    #[test]
    fn lookup_tables_used_in_kernel_execution() {
        const fn custom_table() -> hologram_lookup::AlignedPackedTable {
            let mut table = hologram_lookup::AlignedPackedTable::new();
            let mut i = 0;
            while i < 256 {
                table.cells[i] = hologram_lookup::PackedCell::new(9, i as u8);
                i += 1;
            }
            table
        }
        static CUSTOM_TABLE: hologram_lookup::AlignedPackedTable = custom_table();

        fn write_cell_page(
            _inputs: &[*const u8],
            outputs: &[*mut u8],
            _params: &KernelParams,
            tables: &LookupTables,
        ) -> Result<(), BackendError> {
            if outputs.is_empty() {
                return Err(BackendError::invalid_config("output buffer missing"));
            }
            let page = tables.packed_table.cells[7].page();
            unsafe {
                let out = outputs[0];
                out.write(page);
            }
            Ok(())
        }

        let kernel_id = dynamic_kernel_table().register(write_cell_page);

        let mut plan = BackendPlan::new(BackendType::Cpu);
        plan.lookup_tables = LookupTables {
            packed_table: &CUSTOM_TABLE,
            byte_meta_table: &BYTE_META_TABLE,
            activation_tables: crate::plan::ActivationTables::default(),
        };
        plan.ops.push(PlanOp {
            kernel_id,
            kernel_idx: 0,
            params: KernelParams::default(),
            epilogue: EpilogueChain::new(),
            partition: ThreadPartition::sequential(),
            input_refs: Vec::new(),
            output_refs: vec![BufferRef::Output(0)],
        });

        let backend = crate::cpu::CpuBackend::new();
        let mut executor = PlanExecutor::without_workspace(plan);

        let out = backend.allocate_buffer(1).unwrap();
        let outputs = vec![out];
        executor.execute(&[], &outputs, &backend).unwrap();

        let mut data = [0u8; 1];
        backend.copy_from_buffer(outputs[0], &mut data).unwrap();
        assert_eq!(data[0], 9);
    }

    // ============================================================================
    // CONSTANT HANDLING TESTS
    // ============================================================================

    fn create_plan_with_constant() -> BackendPlan {
        // Create a plan with constant data
        let constant_bytes: Vec<u8> = [1.0f32, 2.0, 3.0, 4.0]
            .iter()
            .flat_map(|f| f.to_le_bytes())
            .collect();

        BackendPlan {
            backend_type: BackendType::Cpu,
            ops: vec![PlanOp {
                kernel_id: KernelId::NOOP, // NOOP kernel since we're just testing buffer resolution
                kernel_idx: 0,
                params: KernelParams::default(),
                epilogue: EpilogueChain::new(),
                partition: ThreadPartition::sequential(),
                input_refs: vec![
                    BufferRef::Input(0),
                    BufferRef::Constant {
                        offset: 0,
                        size: 16,
                    },
                ],
                output_refs: vec![BufferRef::Output(0)],
            }],
            kernel_table: Default::default(),
            tile_params: TileParams::default(),
            layout_metadata: Default::default(),
            workspace_layout: crate::plan::WorkspaceLayout {
                total_size: 0,
                alignment: 64,
                regions: vec![],
            },
            epilogue_chain: EpilogueChain::new(),
            thread_partition: ThreadPartition::sequential(),
            constant_data: constant_bytes,
            lookup_tables: LookupTables::default(),
        }
    }

    #[test]
    fn test_plan_with_constant_data() {
        let plan = create_plan_with_constant();

        // Verify constant_data is populated
        assert_eq!(plan.constant_data.len(), 16);

        // Verify we can interpret the data as f32
        let f32_data: Vec<f32> = plan
            .constant_data
            .chunks_exact(4)
            .map(|chunk| f32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]))
            .collect();
        assert_eq!(f32_data, vec![1.0, 2.0, 3.0, 4.0]);
    }

    #[test]
    fn test_executor_with_constant() {
        let plan = create_plan_with_constant();
        let executor = PlanExecutor::without_workspace(plan);

        // Verify the plan was stored correctly
        assert_eq!(executor.plan().constant_data.len(), 16);
        assert_eq!(executor.plan().ops.len(), 1);

        // Verify the op has a Constant input ref
        let op = &executor.plan().ops[0];
        let has_constant = op
            .input_refs
            .iter()
            .any(|r| matches!(r, BufferRef::Constant { .. }));
        assert!(has_constant, "Op should have a Constant input ref");
    }

    #[test]
    fn test_buffer_ref_constant_resolution() {
        let plan = create_plan_with_constant();
        let executor = PlanExecutor::without_workspace(plan);

        // Create mock input/output handles
        let input_handle = BufferHandle::new(0x1000);
        let output_handle = BufferHandle::new(0x2000);

        // Test resolving BufferRef::Constant
        let constant_ref = BufferRef::Constant {
            offset: 0,
            size: 16,
        };
        let resolved =
            executor.resolve_buffer_ref(&constant_ref, &[input_handle], &[output_handle]);

        // Should return a handle pointing to the constant data
        assert!(resolved.is_some());

        // The handle's ID should be the address of the constant data
        let expected_ptr = executor.plan().constant_data.as_ptr() as u64;
        assert_eq!(resolved.unwrap().id(), expected_ptr);
    }

    #[test]
    fn test_buffer_ref_constant_with_offset() {
        // Create a plan with constant data where we use an offset
        let constant_bytes: Vec<u8> = [1.0f32, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0]
            .iter()
            .flat_map(|f| f.to_le_bytes())
            .collect();

        let mut plan = create_plan_with_constant();
        plan.constant_data = constant_bytes;
        plan.ops[0].input_refs = vec![
            BufferRef::Input(0),
            BufferRef::Constant {
                offset: 16,
                size: 16,
            }, // Points to second half (5, 6, 7, 8)
        ];

        let executor = PlanExecutor::without_workspace(plan);

        // Test resolving with offset
        let constant_ref = BufferRef::Constant {
            offset: 16,
            size: 16,
        };
        let input_handle = BufferHandle::new(0x1000);
        let output_handle = BufferHandle::new(0x2000);
        let resolved =
            executor.resolve_buffer_ref(&constant_ref, &[input_handle], &[output_handle]);

        assert!(resolved.is_some());

        // The handle should point to offset 16 in constant_data
        let expected_ptr = executor.plan().constant_data.as_ptr().wrapping_add(16) as u64;
        assert_eq!(resolved.unwrap().id(), expected_ptr);
    }

    struct DummyConstProvider {
        data: Vec<u8>,
    }

    impl DummyConstProvider {
        fn new(data: Vec<u8>) -> Self {
            Self { data }
        }
    }

    impl ConstProvider for DummyConstProvider {
        fn len(&self) -> usize {
            self.data.len()
        }

        fn read_at<'a>(&'a self, offset: usize, len: usize) -> BackendResult<ConstChunk<'a>> {
            let end = offset + len;
            if end > self.data.len() {
                return Err(BackendError::buffer("oob"));
            }
            Ok(ConstChunk {
                data: &self.data[offset..end],
            })
        }
    }

    #[test]
    fn test_const_provider_external_constant() {
        use crate::core::const_provider::{ChunkedFileConstProvider, StreamingConstProvider};
        let plan = BackendPlan {
            backend_type: BackendType::Cpu,
            ops: vec![PlanOp {
                kernel_id: KernelId::NOOP,
                kernel_idx: 0,
                params: KernelParams::default(),
                epilogue: EpilogueChain::new(),
                partition: ThreadPartition::sequential(),
                input_refs: vec![BufferRef::ExternalConstant {
                    path: "ignored".to_string(),
                    offset: 1,
                    size: 2,
                }],
                output_refs: vec![],
            }],
            kernel_table: Default::default(),
            tile_params: TileParams::default(),
            layout_metadata: Default::default(),
            workspace_layout: crate::plan::WorkspaceLayout {
                total_size: 0,
                alignment: 64,
                regions: vec![],
            },
            epilogue_chain: EpilogueChain::new(),
            thread_partition: ThreadPartition::sequential(),
            constant_data: Vec::new(),
            lookup_tables: LookupTables::default(),
        };

        let provider = Arc::new(DummyConstProvider::new(vec![1, 9, 8, 7, 6]));
        let backend = crate::cpu::CpuBackend::new();
        let executor =
            PlanExecutor::with_const_provider(plan, &backend, provider, 0).expect("provider");

        let input_handle = BufferHandle::new(0);
        let resolved = executor
            .resolve_buffer_ref(
                &BufferRef::ExternalConstant {
                    path: "ignored".into(),
                    offset: 1,
                    size: 2,
                },
                &[input_handle],
                &[],
            )
            .expect("resolved");
        let mut buf = [0u8; 2];
        unsafe {
            std::ptr::copy_nonoverlapping(resolved.id() as *const u8, buf.as_mut_ptr(), 2);
        }
        assert_eq!(buf, [9, 8]);

        // Chunked provider respects cache budget
        let mut tmp = tempfile::NamedTempFile::new().unwrap();
        let big = vec![1u8; 256 * 1024];
        use std::io::Write;
        tmp.write_all(&big).unwrap();
        let chunk_provider =
            ChunkedFileConstProvider::open(tmp.path(), 64 * 1024, 96 * 1024).unwrap();
        let chunk_provider = Arc::new(chunk_provider);

        let plan = BackendPlan {
            backend_type: BackendType::Cpu,
            ops: vec![PlanOp {
                kernel_id: KernelId::NOOP,
                kernel_idx: 0,
                params: KernelParams::default(),
                epilogue: EpilogueChain::new(),
                partition: ThreadPartition::sequential(),
                input_refs: vec![BufferRef::ExternalConstant {
                    path: "ignored".to_string(),
                    offset: 32 * 1024,
                    size: 16,
                }],
                output_refs: vec![],
            }],
            kernel_table: Default::default(),
            tile_params: TileParams::default(),
            layout_metadata: Default::default(),
            workspace_layout: crate::plan::WorkspaceLayout {
                total_size: 0,
                alignment: 64,
                regions: vec![],
            },
            epilogue_chain: EpilogueChain::new(),
            thread_partition: ThreadPartition::sequential(),
            constant_data: Vec::new(),
            lookup_tables: LookupTables::default(),
        };

        let executor = PlanExecutor::with_const_provider(plan, &backend, chunk_provider.clone(), 0)
            .expect("chunked provider");
        let resolved = executor
            .resolve_buffer_ref(
                &BufferRef::ExternalConstant {
                    path: "ignored".into(),
                    offset: 32 * 1024,
                    size: 16,
                },
                &[],
                &[],
            )
            .expect("resolved");
        let mut buf = [0u8; 16];
        unsafe {
            std::ptr::copy_nonoverlapping(resolved.id() as *const u8, buf.as_mut_ptr(), 16);
        }
        assert_eq!(buf, [1u8; 16]);
        assert!(
            chunk_provider.cached_bytes() <= 96 * 1024,
            "cache budget exceeded"
        );

        // Streaming provider with bounded cache and custom fetcher
        let fetch_calls = Arc::new(std::sync::Mutex::new(0usize));
        let fetch_calls_clone = fetch_calls.clone();
        let streaming =
            StreamingConstProvider::new(128 * 1024, 32 * 1024, 64 * 1024, move |offset, len| {
                let mut calls = fetch_calls_clone.lock().unwrap();
                *calls += 1;
                // Return deterministic data
                let mut buf = vec![0u8; len];
                for (i, b) in buf.iter_mut().enumerate() {
                    *b = ((offset + i) & 0xFF) as u8;
                }
                Ok(buf)
            });
        let streaming = Arc::new(streaming);
        let plan = BackendPlan {
            backend_type: BackendType::Cpu,
            ops: vec![PlanOp {
                kernel_id: KernelId::NOOP,
                kernel_idx: 0,
                params: KernelParams::default(),
                epilogue: EpilogueChain::new(),
                partition: ThreadPartition::sequential(),
                input_refs: vec![BufferRef::ExternalConstant {
                    path: "ignored".to_string(),
                    offset: 4 * 1024,
                    size: 16,
                }],
                output_refs: vec![],
            }],
            kernel_table: Default::default(),
            tile_params: TileParams::default(),
            layout_metadata: Default::default(),
            workspace_layout: crate::plan::WorkspaceLayout {
                total_size: 0,
                alignment: 64,
                regions: vec![],
            },
            epilogue_chain: EpilogueChain::new(),
            thread_partition: ThreadPartition::sequential(),
            constant_data: Vec::new(),
            lookup_tables: LookupTables::default(),
        };
        let executor =
            PlanExecutor::with_const_provider(plan, &backend, streaming.clone(), 0).unwrap();
        let resolved = executor
            .resolve_buffer_ref(
                &BufferRef::ExternalConstant {
                    path: "ignored".into(),
                    offset: 4 * 1024,
                    size: 16,
                },
                &[],
                &[],
            )
            .expect("resolved");
        let mut buf = [0u8; 16];
        unsafe {
            std::ptr::copy_nonoverlapping(resolved.id() as *const u8, buf.as_mut_ptr(), 16);
        }
        assert_eq!(
            buf,
            [0u8, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
        );
        assert!(
            streaming.cached_bytes() <= 64 * 1024,
            "streaming cache should respect budget"
        );
        assert!(
            *fetch_calls.lock().unwrap() <= 1,
            "streaming provider should reuse cached chunk"
        );
    }

    #[cfg(feature = "alloc-tracking")]
    #[test]
    fn test_external_constant_memory_cap() {
        use std::io::Write;
        use tempfile::NamedTempFile;

        // Build a large external weight file.
        let mut tmp = NamedTempFile::new().unwrap();
        let big = vec![7u8; 8 * 1024 * 1024];
        tmp.write_all(&big).unwrap();
        let path = tmp.path().to_string_lossy().to_string();

        let plan = BackendPlan {
            backend_type: BackendType::Cpu,
            ops: vec![PlanOp {
                kernel_id: KernelId::NOOP,
                kernel_idx: 0,
                params: KernelParams::default(),
                epilogue: EpilogueChain::new(),
                partition: ThreadPartition::sequential(),
                input_refs: vec![BufferRef::ExternalConstant {
                    path: path.clone(),
                    offset: 0,
                    size: big.len(),
                }],
                output_refs: vec![],
            }],
            kernel_table: Default::default(),
            tile_params: TileParams::default(),
            layout_metadata: Default::default(),
            workspace_layout: crate::plan::WorkspaceLayout {
                total_size: 0,
                alignment: 64,
                regions: vec![],
            },
            epilogue_chain: EpilogueChain::new(),
            thread_partition: ThreadPartition::sequential(),
            constant_data: Vec::new(),
            lookup_tables: LookupTables::default(),
        };

        let executor = PlanExecutor::without_workspace(plan);

        // Ensure accessing the external constant does not allocate beyond a tiny cap.
        crate::alloc_tracker::reset_counts();
        let handle = executor
            .resolve_buffer_ref(
                &BufferRef::ExternalConstant {
                    path,
                    offset: 0,
                    size: 4,
                },
                &[],
                &[],
            )
            .expect("resolved external const");
        let mut buf = [0u8; 4];
        unsafe {
            std::ptr::copy_nonoverlapping(handle.id() as *const u8, buf.as_mut_ptr(), 4);
        }
        assert_eq!(buf, [7u8; 4]);
        let (allocs, bytes) = crate::alloc_tracker::get_counts();
        assert!(
            bytes <= 1024,
            "Expected <=1KB allocations during external constant access, got {} bytes across {} allocs",
            bytes,
            allocs
        );
    }

    #[test]
    fn test_buffer_ref_all_variants() {
        let plan = create_plan_with_constant();
        let executor = PlanExecutor::without_workspace(plan);

        let input_handle = BufferHandle::new(0x1000);
        let output_handle = BufferHandle::new(0x2000);

        // Test Input resolution
        let input_ref = BufferRef::Input(0);
        let resolved = executor.resolve_buffer_ref(&input_ref, &[input_handle], &[output_handle]);
        assert_eq!(resolved, Some(input_handle));

        // Test Output resolution
        let output_ref = BufferRef::Output(0);
        let resolved = executor.resolve_buffer_ref(&output_ref, &[input_handle], &[output_handle]);
        assert_eq!(resolved, Some(output_handle));

        // Test Constant resolution
        let constant_ref = BufferRef::Constant {
            offset: 0,
            size: 16,
        };
        let resolved =
            executor.resolve_buffer_ref(&constant_ref, &[input_handle], &[output_handle]);
        assert!(resolved.is_some());

        // Workspace requires actual workspace allocation, skip for this test
    }

    #[test]
    fn test_external_constant_resolution_maps_file() {
        use std::io::Write;
        use tempfile::NamedTempFile;

        let mut tmp = NamedTempFile::new().expect("tmp");
        let bytes: [u8; 4] = [9, 8, 7, 6];
        tmp.write_all(&bytes).unwrap();
        let path = tmp.path().to_string_lossy().to_string();

        let plan = BackendPlan {
            backend_type: BackendType::Cpu,
            ops: vec![PlanOp {
                kernel_id: KernelId::NOOP,
                kernel_idx: 0,
                params: KernelParams::default(),
                epilogue: EpilogueChain::new(),
                partition: ThreadPartition::sequential(),
                input_refs: vec![BufferRef::ExternalConstant {
                    path: path.clone(),
                    offset: 0,
                    size: bytes.len(),
                }],
                output_refs: vec![],
            }],
            kernel_table: Default::default(),
            tile_params: TileParams::default(),
            layout_metadata: Default::default(),
            workspace_layout: crate::plan::WorkspaceLayout {
                total_size: 0,
                alignment: 64,
                regions: vec![],
            },
            epilogue_chain: EpilogueChain::new(),
            thread_partition: ThreadPartition::sequential(),
            constant_data: Vec::new(),
            lookup_tables: LookupTables::default(),
        };

        let executor = PlanExecutor::without_workspace(plan);
        let input_handle = BufferHandle::new(0);
        let resolved = executor.resolve_buffer_ref(
            &BufferRef::ExternalConstant {
                path,
                offset: 0,
                size: 4,
            },
            &[input_handle],
            &[],
        );
        assert!(resolved.is_some(), "expected buffer ref to resolve");
        let ptr = resolved.unwrap().id() as *const u8;
        let mut buf = [0u8; 4];
        unsafe {
            std::ptr::copy_nonoverlapping(ptr, buf.as_mut_ptr(), 4);
        }
        assert_eq!(buf, bytes);
    }

    #[test]
    fn test_validate_embedded_constants_fails_on_oob() {
        let mut plan = create_plan_with_constant();
        plan.constant_data.truncate(4);
        plan.ops[0].input_refs = vec![
            BufferRef::Input(0),
            BufferRef::Constant { offset: 2, size: 8 },
        ];

        let backend = crate::cpu::CpuBackend::new();
        let result = PlanExecutor::new(plan, &backend);
        assert!(
            result.is_err(),
            "expected PlanExecutor::new to fail when constants exceed buffer"
        );
    }
}
