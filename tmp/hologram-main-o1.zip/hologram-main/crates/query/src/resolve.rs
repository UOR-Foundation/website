//! Query execution engine.
//!
//! Dispatches validated queries to generated `resolve_field()` methods,
//! building JSON responses with only the requested fields.

use serde_json::{json, Map, Value};

use crate::ast::*;
use crate::generated::{ActivationDto, ByteDto, ElementDto, FieldValue, PathDto};
use crate::translate;
use crate::validate::{self, ValidateError};

/// Query execution error.
#[derive(Debug, thiserror::Error)]
pub enum QueryError {
    #[error("validation: {0}")]
    Validate(#[from] ValidateError),
    #[error("field resolution failed for '{field}' on '{domain}'")]
    ResolveFailed { domain: String, field: String },
    #[error("translate error: {0}")]
    Translate(#[from] translate::TranslateError),
    #[error("value out of range: {0}")]
    OutOfRange(String),
}

/// Execute a parsed document, returning JSON.
pub fn execute(doc: &Document) -> Result<Value, QueryError> {
    validate::validate(doc)?;
    match doc.op {
        OpType::Query => resolve_query(&doc.selections),
        OpType::Mutation => resolve_mutation(&doc.selections),
    }
}

/// Execute and return results as individual rows for NDJSON streaming.
/// Returns `None` if the result is not an array (single objects stream as-is).
pub fn execute_rows(doc: &Document) -> Result<Vec<Value>, QueryError> {
    let result = execute(doc)?;
    match result {
        Value::Array(rows) => Ok(rows),
        other => Ok(vec![other]),
    }
}

/// Format rows as NDJSON (newline-delimited JSON).
pub fn to_ndjson(rows: &[Value]) -> String {
    let mut buf = String::new();
    for row in rows {
        buf.push_str(&serde_json::to_string(row).unwrap_or_default());
        buf.push('\n');
    }
    buf
}

fn resolve_query(selections: &[Selection]) -> Result<Value, QueryError> {
    if selections.len() == 1 {
        resolve_root_selection(&selections[0])
    } else {
        let arr: Result<Vec<Value>, _> = selections.iter().map(resolve_root_selection).collect();
        Ok(Value::Array(arr?))
    }
}

fn resolve_root_selection(sel: &Selection) -> Result<Value, QueryError> {
    match sel.field.as_str() {
        "byteRange" | "ringRange" | "activationRange" => resolve_range(sel),
        "observable" | "path" => resolve_observable(sel),
        _ => {
            let value_arg = sel
                .arguments
                .iter()
                .find(|(n, _)| n == "value")
                .and_then(|(_, v)| v.as_int())
                .unwrap_or(0);

            match sel.field.as_str() {
                "byte" => resolve_byte(value_arg, &sel.children),
                "ring" => resolve_ring(value_arg, &sel.children),
                "activation" => resolve_activation(value_arg, &sel.children),
                _ => unreachable!("validator catches unknown roots"),
            }
        }
    }
}

fn extract_range_args(sel: &Selection) -> Result<(i64, i64), QueryError> {
    let from = sel
        .arguments
        .iter()
        .find(|(n, _)| n == "from")
        .and_then(|(_, v)| v.as_int())
        .unwrap_or(0);
    let to = sel
        .arguments
        .iter()
        .find(|(n, _)| n == "to")
        .and_then(|(_, v)| v.as_int())
        .unwrap_or(0);
    if from < 0 || to < 0 || from > 255 || to > 255 {
        return Err(QueryError::OutOfRange(format!(
            "range {from}..={to} exceeds byte bounds 0..=255"
        )));
    }
    Ok((from, to))
}

fn resolve_range(sel: &Selection) -> Result<Value, QueryError> {
    let (from, to) = extract_range_args(sel)?;
    let base_domain = sel.field.strip_suffix("Range").unwrap_or(&sel.field);

    if from > to {
        return Ok(Value::Array(vec![]));
    }

    let mut results = Vec::new();
    for v in from..=to {
        let mut row = match base_domain {
            "byte" => resolve_byte(v, &sel.children)?,
            "ring" => resolve_ring(v, &sel.children)?,
            "activation" => resolve_activation(v, &sel.children)?,
            _ => unreachable!(),
        };
        if let Value::Object(ref mut obj) = row {
            obj.insert("value".to_string(), json!(v));
        }
        results.push(row);
    }
    Ok(Value::Array(results))
}

fn resolve_byte(value: i64, children: &[Selection]) -> Result<Value, QueryError> {
    let v = value as u8;
    let mut obj = Map::new();
    for child in children {
        if !child.children.is_empty() {
            // Nested group (e.g., torus { page, offset })
            let mut nested = Map::new();
            for sub in &child.children {
                let dot_name = format!("{}.{}", child.field, sub.field);
                let fv = ByteDto::resolve_field(v, &dot_name).ok_or_else(|| {
                    QueryError::ResolveFailed {
                        domain: "byte".into(),
                        field: dot_name,
                    }
                })?;
                nested.insert(sub.field.clone(), field_value_to_json(&fv));
            }
            obj.insert(child.field.clone(), Value::Object(nested));
        } else {
            let fv = ByteDto::resolve_field(v, &child.field).ok_or_else(|| {
                QueryError::ResolveFailed {
                    domain: "byte".into(),
                    field: child.field.clone(),
                }
            })?;
            obj.insert(child.field.clone(), field_value_to_json(&fv));
        }
    }
    Ok(Value::Object(obj))
}

fn resolve_ring(value: i64, children: &[Selection]) -> Result<Value, QueryError> {
    let v = value as u8;
    let mut obj = Map::new();
    for child in children {
        // Ring fields are all parameterized (add, sub, mul)
        let args: Vec<FieldValue> = child
            .arguments
            .iter()
            .map(|(_, v)| match v {
                QueryValue::Int(n) => FieldValue::U8(*n as u8),
                _ => FieldValue::U8(0),
            })
            .collect();
        let fv = ElementDto::resolve_param_field(v, &child.field, &args).ok_or_else(|| {
            QueryError::ResolveFailed {
                domain: "ring".into(),
                field: child.field.clone(),
            }
        })?;
        obj.insert(child.field.clone(), field_value_to_json(&fv));
    }
    Ok(Value::Object(obj))
}

fn resolve_activation(value: i64, children: &[Selection]) -> Result<Value, QueryError> {
    let v = value as u8;
    let mut obj = Map::new();
    for child in children {
        let fv = ActivationDto::resolve_field(v, &child.field).ok_or_else(|| {
            QueryError::ResolveFailed {
                domain: "activation".into(),
                field: child.field.clone(),
            }
        })?;
        obj.insert(child.field.clone(), field_value_to_json(&fv));
    }
    Ok(Value::Object(obj))
}

fn extract_observable_args(sel: &Selection) -> (Vec<u64>, u32) {
    let path: Vec<u64> = sel
        .arguments
        .iter()
        .find(|(n, _)| n == "path")
        .and_then(|(_, v)| match v {
            QueryValue::List(items) => Some(
                items
                    .iter()
                    .filter_map(|item| item.as_int().map(|v| v as u64))
                    .collect(),
            ),
            _ => None,
        })
        .unwrap_or_default();

    let quantum = sel
        .arguments
        .iter()
        .find(|(n, _)| n == "quantum")
        .and_then(|(_, v)| v.as_int())
        .unwrap_or(8) as u32;

    (path, quantum)
}

fn resolve_observable(sel: &Selection) -> Result<Value, QueryError> {
    let (path, quantum) = extract_observable_args(sel);
    let mut obj = Map::new();
    for child in &sel.children {
        let fv = PathDto::resolve_field(&path, quantum, &child.field).ok_or_else(|| {
            QueryError::ResolveFailed {
                domain: "observable".into(),
                field: child.field.clone(),
            }
        })?;
        obj.insert(child.field.clone(), field_value_to_json(&fv));
    }
    Ok(Value::Object(obj))
}

fn resolve_mutation(selections: &[Selection]) -> Result<Value, QueryError> {
    let mut results = Vec::new();
    for sel in selections {
        let result = match sel.field.as_str() {
            "pipeline" => crate::pipeline::execute_pipeline(sel)?,
            "chain" => crate::pipeline::execute_chain(sel)?,
            "translateWhere" => translate::execute_translate_where(sel)?,
            _ => translate::execute_translate(sel)?,
        };
        results.push(result);
    }
    if results.len() == 1 {
        Ok(results.into_iter().next().unwrap())
    } else {
        Ok(Value::Array(results))
    }
}

fn field_value_to_json(fv: &FieldValue) -> Value {
    match fv {
        FieldValue::U8(v) => json!(*v),
        FieldValue::U16(v) => json!(*v),
        FieldValue::U32(v) => json!(*v),
        FieldValue::U64(v) => json!(*v),
        FieldValue::Usize(v) => json!(*v),
        FieldValue::I32(v) => json!(*v),
        FieldValue::I64(v) => json!(*v),
        FieldValue::F32(v) => json!(*v),
        FieldValue::Str(v) => json!(v),
        FieldValue::Json(v) => v.clone(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parse::parse;

    #[test]
    fn resolve_byte_single_field() {
        let doc = parse("query { byte(value: 42) { stratum } }").unwrap();
        let result = execute(&doc).unwrap();
        assert!(result["stratum"].is_number());
    }

    #[test]
    fn resolve_byte_multiple_fields() {
        let doc = parse("query { byte(value: 100) { stratum, curvature, domain } }").unwrap();
        let result = execute(&doc).unwrap();
        assert!(result["stratum"].is_number());
        assert!(result["curvature"].is_number());
        assert!(result["domain"].is_number());
    }

    #[test]
    fn resolve_byte_nested_torus() {
        let doc = parse("query { byte(value: 200) { torus { page, offset } } }").unwrap();
        let result = execute(&doc).unwrap();
        assert!(result["torus"]["page"].is_number());
        assert!(result["torus"]["offset"].is_number());
    }

    #[test]
    fn resolve_ring_param() {
        let doc = parse("query { ring(value: 50) { add(other: 10) } }").unwrap();
        let result = execute(&doc).unwrap();
        // 50 + 10 = 60 (mod 96)
        assert_eq!(result["add"], json!(60));
    }

    #[test]
    fn resolve_ring_sub() {
        let doc = parse("query { ring(value: 10) { sub(other: 30) } }").unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["sub"], json!(236));
    }

    #[test]
    fn resolve_ring_mul() {
        let doc = parse("query { ring(value: 5) { mul(other: 7) } }").unwrap();
        let result = execute(&doc).unwrap();
        // 5 * 7 = 35 (mod 96)
        assert_eq!(result["mul"], json!(35));
    }

    #[test]
    fn resolve_activation() {
        let doc = parse("query { activation(value: 128) { sigmoid, relu } }").unwrap();
        let result = execute(&doc).unwrap();
        assert!(result["sigmoid"].is_number());
        assert!(result["relu"].is_number());
    }

    #[test]
    fn resolve_all_256_bytes() {
        for v in 0..=255u16 {
            let q = format!("query {{ byte(value: {v}) {{ stratum, curvature, domain }} }}");
            let doc = parse(&q).unwrap();
            let result = execute(&doc).unwrap();
            assert!(result["stratum"].is_number(), "failed at value {v}");
        }
    }

    #[test]
    fn resolve_multiple_roots() {
        let doc =
            parse("query { byte(value: 1) { stratum }, byte(value: 2) { curvature } }").unwrap();
        let result = execute(&doc).unwrap();
        assert!(result.is_array());
        assert_eq!(result.as_array().unwrap().len(), 2);
    }

    #[test]
    fn resolve_byte_all_fields() {
        let doc = parse(
            "query { byte(value: 42) { stratum, curvature, domain, rank, orbit_class, torus { page, offset } } }",
        )
        .unwrap();
        let result = execute(&doc).unwrap();
        assert!(result["stratum"].is_number());
        assert!(result["orbit_class"].is_number());
        assert!(result["torus"]["page"].is_number());
    }

    // Range query tests

    #[test]
    fn resolve_byte_range_basic() {
        let doc = parse("query { byteRange(from: 0, to: 3) { stratum, curvature } }").unwrap();
        let result = execute(&doc).unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr.len(), 4);
        for (i, row) in arr.iter().enumerate() {
            assert_eq!(row["value"], json!(i as i64));
            assert!(row["stratum"].is_number());
            assert!(row["curvature"].is_number());
        }
    }

    #[test]
    fn resolve_byte_range_nested_torus() {
        let doc =
            parse("query { byteRange(from: 10, to: 12) { torus { page, offset } } }").unwrap();
        let result = execute(&doc).unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr.len(), 3);
        for row in arr {
            assert!(row["torus"]["page"].is_number());
            assert!(row["torus"]["offset"].is_number());
        }
    }

    #[test]
    fn resolve_ring_range() {
        let doc = parse("query { ringRange(from: 0, to: 4) { add(other: 1) } }").unwrap();
        let result = execute(&doc).unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr.len(), 5);
        // 0+1=1, 1+1=2, 2+1=3, 3+1=4, 4+1=5 (all mod 96)
        assert_eq!(arr[0]["add"], json!(1));
        assert_eq!(arr[4]["add"], json!(5));
    }

    #[test]
    fn resolve_activation_range() {
        let doc = parse("query { activationRange(from: 100, to: 102) { sigmoid, relu } }").unwrap();
        let result = execute(&doc).unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr.len(), 3);
        for row in arr {
            assert!(row["sigmoid"].is_number());
            assert!(row["relu"].is_number());
        }
    }

    #[test]
    fn resolve_empty_range() {
        let doc = parse("query { byteRange(from: 10, to: 5) { stratum } }").unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result, json!([]));
    }

    #[test]
    fn resolve_single_element_range() {
        let doc = parse("query { byteRange(from: 42, to: 42) { stratum } }").unwrap();
        let result = execute(&doc).unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr.len(), 1);
        assert_eq!(arr[0]["value"], json!(42));
    }

    #[test]
    fn resolve_full_byte_range() {
        let doc = parse("query { byteRange(from: 0, to: 255) { stratum } }").unwrap();
        let result = execute(&doc).unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr.len(), 256);
    }

    #[test]
    fn resolve_byte_range_all_fields() {
        let doc = parse(
            "query { byteRange(from: 0, to: 2) { stratum, curvature, domain, rank, orbit_class } }",
        )
        .unwrap();
        let result = execute(&doc).unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr.len(), 3);
        for row in arr {
            assert!(row["stratum"].is_number());
            assert!(row["curvature"].is_number());
            assert!(row["domain"].is_number());
            assert!(row["rank"].is_number());
            assert!(row["orbit_class"].is_number());
        }
    }

    // NDJSON streaming tests

    #[test]
    fn ndjson_range_output() {
        let doc = parse("query { byteRange(from: 0, to: 2) { stratum } }").unwrap();
        let rows = execute_rows(&doc).unwrap();
        assert_eq!(rows.len(), 3);
        let ndjson = to_ndjson(&rows);
        let lines: Vec<&str> = ndjson.trim().split('\n').collect();
        assert_eq!(lines.len(), 3);
        // Each line must be valid JSON
        for line in lines {
            serde_json::from_str::<Value>(line).unwrap();
        }
    }

    #[test]
    fn ndjson_single_result() {
        let doc = parse("query { byte(value: 42) { stratum } }").unwrap();
        let rows = execute_rows(&doc).unwrap();
        assert_eq!(rows.len(), 1);
        let ndjson = to_ndjson(&rows);
        assert_eq!(ndjson.trim().split('\n').count(), 1);
    }

    #[test]
    fn ndjson_full_range() {
        let doc = parse("query { byteRange(from: 0, to: 255) { stratum } }").unwrap();
        let rows = execute_rows(&doc).unwrap();
        assert_eq!(rows.len(), 256);
        let ndjson = to_ndjson(&rows);
        assert_eq!(ndjson.trim().split('\n').count(), 256);
    }

    #[test]
    fn ndjson_empty_range() {
        let doc = parse("query { byteRange(from: 10, to: 5) { stratum } }").unwrap();
        let rows = execute_rows(&doc).unwrap();
        assert!(rows.is_empty());
        let ndjson = to_ndjson(&rows);
        assert!(ndjson.is_empty());
    }

    // Observable query tests

    #[test]
    fn resolve_observable_all_fields() {
        let doc = parse(
            "query { observable(path: [0, 1, 2, 3], quantum: 8) { winding, total_variation, cascade_spectrum } }",
        )
        .unwrap();
        let result = execute(&doc).unwrap();
        assert!(result["winding"].is_number());
        assert!(result["total_variation"].is_number());
        assert!(result["cascade_spectrum"].is_array());
    }

    #[test]
    fn resolve_observable_winding_only() {
        let doc =
            parse("query { observable(path: [10, 20, 30], quantum: 8) { winding } }").unwrap();
        let result = execute(&doc).unwrap();
        let winding = result["winding"].as_i64().unwrap();
        assert_eq!(winding, uor::observable::winding_number(&[10, 20, 30], 8));
    }

    #[test]
    fn resolve_observable_total_variation() {
        let doc =
            parse("query { observable(path: [5, 15, 25, 35], quantum: 16) { total_variation } }")
                .unwrap();
        let result = execute(&doc).unwrap();
        let tv = result["total_variation"].as_u64().unwrap();
        assert_eq!(tv, uor::observable::total_variation(&[5, 15, 25, 35], 16));
    }

    #[test]
    fn resolve_observable_cascade_spectrum() {
        let doc =
            parse("query { observable(path: [1, 2, 4, 8], quantum: 8) { cascade_spectrum } }")
                .unwrap();
        let result = execute(&doc).unwrap();
        let spectrum = result["cascade_spectrum"].as_array().unwrap();
        let expected = uor::observable::cascade_spectrum(&[1, 2, 4, 8], 8);
        assert_eq!(spectrum.len(), expected.len());
        for (got, exp) in spectrum.iter().zip(expected.iter()) {
            assert_eq!(got.as_u64().unwrap(), *exp as u64);
        }
    }

    #[test]
    fn resolve_observable_empty_path() {
        let doc = parse("query { observable(path: [], quantum: 8) { winding } }").unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["winding"].as_i64().unwrap(), 0);
    }

    #[test]
    fn resolve_observable_single_element() {
        let doc = parse("query { observable(path: [42], quantum: 8) { winding } }").unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["winding"].as_i64().unwrap(), 0);
    }

    #[test]
    fn resolve_observable_matches_direct_api() {
        let path = &[0u64, 10, 20, 30, 40, 50, 60, 70, 80, 90];
        let quantum = 32u32;
        let doc =
            parse(&format!(
            "query {{ observable(path: [{}], quantum: {quantum}) {{ winding, total_variation }} }}",
            path.iter().map(|v| v.to_string()).collect::<Vec<_>>().join(", ")
        ))
            .unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(
            result["winding"].as_i64().unwrap(),
            uor::observable::winding_number(path, quantum)
        );
        assert_eq!(
            result["total_variation"].as_u64().unwrap(),
            uor::observable::total_variation(path, quantum)
        );
    }
}
