/**
 * Identity Module — Pure Data Types
 * ═══════════════════════════════════
 *
 * All types are readonly interfaces. No classes. No side effects.
 * Compatible with Hologram OS runtime conventions.
 *
 * @module identity/types
 */

// ── Core Identity ───────────────────────────────────────────────────────────

/** A UOR-anchored user identity. Content-addressed via the u: namespace. */
export interface IdentityProfile {
  readonly id: string;               // u: namespace IRI
  readonly displayName: string;
  readonly handle: string;           // human-readable handle
  readonly avatar?: string;          // CID or URL
  readonly bio?: string;
  readonly createdAt: number;        // unix ms
  readonly updatedAt: number;
}

// ── Trust ───────────────────────────────────────────────────────────────────

/** Trust attestation between two identities. */
export interface TrustAttestation {
  readonly id: string;
  readonly fromId: string;           // attestor identity IRI
  readonly toId: string;             // subject identity IRI
  readonly level: TrustLevel;
  readonly reason?: string;
  readonly issuedAt: number;
  readonly expiresAt?: number;
}

export type TrustLevel =
  | "unknown"
  | "distrusted"
  | "minimal"
  | "basic"
  | "verified"
  | "sovereign";

/** Computed trust score for a given identity. */
export interface TrustScore {
  readonly identityId: string;
  readonly score: number;            // 0.0 – 1.0
  readonly level: TrustLevel;
  readonly attestationCount: number;
  readonly lastUpdated: number;
}

// ── Privacy ─────────────────────────────────────────────────────────────────

export type DataCategory =
  | "profile"
  | "activity"
  | "content"
  | "social"
  | "financial"
  | "biometric"
  | "location";

export type ConsentStatus = "granted" | "denied" | "pending" | "expired";

/** A single privacy consent record. */
export interface PrivacyConsent {
  readonly id: string;
  readonly identityId: string;
  readonly category: DataCategory;
  readonly status: ConsentStatus;
  readonly grantedTo?: string;       // identity IRI of data consumer
  readonly grantedAt?: number;
  readonly expiresAt?: number;
  readonly purpose: string;
}

/** Privacy policy version record. */
export interface PrivacyPolicy {
  readonly version: string;
  readonly effectiveDate: number;
  readonly sections: readonly PolicySection[];
}

export interface PolicySection {
  readonly id: string;
  readonly title: string;
  readonly content: string;
  readonly dataCategories: readonly DataCategory[];
}

// ── Sovereignty Surface ─────────────────────────────────────────────────────

/** The 6 sovereignty dimensions. */
export type SovereigntyDimensionId =
  | "identity"
  | "data"
  | "compute"
  | "social"
  | "economic"
  | "governance";

/** Sovereignty dimension definition. */
export interface SovereigntyDimension {
  readonly id: SovereigntyDimensionId;
  readonly label: string;
  readonly offLabel: string;       // conservative state label
  readonly onLabel: string;        // open state label
  readonly index: number;          // 0–5
}

/** State of a single boundary edge. */
export type EdgeState =
  | "shielded"     // fully private (default)
  | "disclosed"    // fully open
  | "selective";   // selectively revealed via proof

/** A single edge on the 96-edge sovereignty boundary. */
export interface BoundaryEdge {
  readonly id: string;
  readonly dimensionA: SovereigntyDimensionId;
  readonly dimensionB: SovereigntyDimensionId;
  readonly label: string;
  readonly state: EdgeState;
  readonly index: number;          // 0–95
}

/** The complete sovereignty surface for an identity. */
export interface SovereigntySurface {
  readonly identityId: string;
  readonly edges: readonly BoundaryEdge[];
  readonly dimensions: readonly SovereigntyDimension[];
  readonly createdAt: number;
  readonly updatedAt: number;
}

/** SHA-256 commitment of the sovereignty surface state. */
export interface BoundaryCommitment {
  readonly identityId: string;
  readonly commitmentHash: string;   // hex-encoded SHA-256
  readonly edgeCount: number;        // always 96
  readonly shieldedCount: number;
  readonly disclosedCount: number;
  readonly selectiveCount: number;
  readonly timestamp: number;
}

/** Diff between two edge states. */
export interface EdgeDiff {
  readonly edgeId: string;
  readonly label: string;
  readonly before: EdgeState;
  readonly after: EdgeState;
  readonly timestamp: number;
}

// ── Permissions ─────────────────────────────────────────────────────────────

export type PermissionAction =
  | "read"
  | "write"
  | "delete"
  | "admin"
  | "delegate"
  | "attest";

export type PermissionScope =
  | "self"        // own data only
  | "trusted"     // trusted circle
  | "public"      // anyone
  | "namespace";  // specific UOR namespace

/** A permission grant on a resource. */
export interface Permission {
  readonly id: string;
  readonly identityId: string;
  readonly resource: string;         // UOR namespace or resource IRI
  readonly action: PermissionAction;
  readonly scope: PermissionScope;
  readonly grantedBy: string;
  readonly grantedAt: number;
  readonly expiresAt?: number;
  readonly active: boolean;
}

// ── Ceremonies ──────────────────────────────────────────────────────────────

/** Type of trust ceremony performed. */
export type CeremonyType =
  | "founding"     // initial identity creation
  | "peer"         // bilateral trust formation
  | "renewal";     // key rotation or re-attestation

/** A cryptographic key fingerprint (hex-encoded SHA-256 of public key). */
export type KeyFingerprint = string;

/** Guardian/Delegate keypair metadata (private keys never stored in state). */
export interface KeyPairMeta {
  readonly fingerprint: KeyFingerprint;
  readonly algorithm: string;           // e.g. "ML-DSA-65" (Dilithium3)
  readonly createdAt: number;
}

/** Record of a trust ceremony event. */
export interface CeremonyRecord {
  readonly id: string;
  readonly type: CeremonyType;
  readonly identityId: string;
  readonly participants: readonly string[];  // identity IRIs involved
  readonly derivationId: string;            // UOR derivation hash
  readonly guardianFingerprint: KeyFingerprint;
  readonly delegateFingerprint: KeyFingerprint;
  readonly timestamp: number;
  readonly metadata?: Record<string, unknown>;
}

/** Extended identity profile with ceremony metadata. */
export interface CeremonyIdentityProfile extends IdentityProfile {
  readonly guardianFingerprint?: KeyFingerprint;
  readonly delegateFingerprint?: KeyFingerprint;
  readonly delegatePublicKeyHex?: string;
  readonly ceremonyId?: string;
  readonly ceremoniedAt?: number;
}

// ── Module Manifest ─────────────────────────────────────────────────────────

export interface IdentityModuleState {
  readonly profile: CeremonyIdentityProfile | null;
  readonly trustScore: TrustScore | null;
  readonly permissions: readonly Permission[];
  readonly consents: readonly PrivacyConsent[];
  readonly privacyPolicy: PrivacyPolicy | null;
  readonly ceremonies: readonly CeremonyRecord[];
}
