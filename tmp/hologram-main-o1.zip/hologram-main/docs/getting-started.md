# Getting Started with Hologram

This guide walks you through installing Hologram and running your first model.

## Installation

### Prerequisites

- Rust 1.70+ (install via [rustup](https://rustup.rs/))
- A C compiler (for some dependencies)

### From Source

```bash
# Clone the repository
git clone https://github.com/UOR-Foundation/hologram.git
cd hologram

# Build in release mode
cargo build --release

# Install the CLI globally (optional)
cargo install --path crates/cli
```

### Verify Installation

```bash
# Check the CLI is working
hologram --version

# Run the test suite
cargo test --workspace
```

## Quick Start

### 1. Create an Operation Graph

Operation graphs define the computation to perform. Here's a simple example that adds two vectors and applies ReLU:

```rust
use hologram_compiler::{OperationGraph, OpNode, OpKind, DType};

fn main() {
    let mut graph = OperationGraph::new();

    // Input nodes
    let input_a = graph.add_node(OpNode::new(0, OpKind::Input, vec![1024], DType::F32));
    let input_b = graph.add_node(OpNode::new(1, OpKind::Input, vec![1024], DType::F32));

    // Add operation
    let add = graph.add_node(OpNode::new(2, OpKind::Add, vec![1024], DType::F32));
    graph.add_edge(input_a, add);
    graph.add_edge(input_b, add);

    // ReLU activation
    let relu = graph.add_node(OpNode::new(3, OpKind::Relu, vec![1024], DType::F32));
    graph.add_edge(add, relu);

    // Output node
    let output = graph.add_node(OpNode::new(4, OpKind::Output, vec![1024], DType::F32));
    graph.add_edge(relu, output);

    // Register named I/O
    graph.add_input("a", input_a);
    graph.add_input("b", input_b);
    graph.add_output("result", output);

    // Save as JSON for CLI compilation
    let json = serde_json::to_string_pretty(&graph).unwrap();
    std::fs::write("add_relu.json", json).unwrap();
}
```

### 2. Compile the Graph

Use the CLI to compile the operation graph:

```bash
# Compile to .holb format
hologram compile add_relu.json -o add_relu.holb

# Inspect the compiled model
hologram model info add_relu.holb
```

### 3. Execute the Model

```bash
# Run with random input (for testing)
hologram run add_relu.holb --random

# Run with specific input data
hologram run add_relu.holb --input input.bin --output result.bin
```

### 4. Execute Programmatically

```rust
use hologram_backend::{cpu::CpuBackend, Backend};
use hologram_holo::HoloLoader;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Load the compiled model
    let loaded = HoloLoader::load("add_relu.holb")?;
    let plan = loaded.plan();

    // Create backend
    let backend = CpuBackend::new();

    // Prepare input data (1024 f32 values each)
    let input_a: Vec<u8> = vec![0u8; 4096]; // 1024 * 4 bytes
    let input_b: Vec<u8> = vec![0u8; 4096];

    // Prepare output buffer
    let mut output: Vec<u8> = vec![0u8; 4096];

    // Execute
    backend.execute_plan(
        plan,
        &[&input_a, &input_b],
        &mut [&mut output],
    )?;

    // Interpret result as f32 slice
    let result: &[f32] = bytemuck::cast_slice(&output);
    println!("First 10 results: {:?}", &result[..10]);

    Ok(())
}
```

## CLI Commands

### Compile

```bash
# Compile JSON graph to .holb
hologram compile model.json -o model.holb

# Compile with optimization level
hologram compile model.json -o model.holb --opt-level 3
```

### Run

```bash
# Execute with input files
hologram run model.holb --input a.bin --input b.bin --output result.bin

# Execute with JSON input/output
hologram run model.holb --input data.json --format json

# Benchmark execution
hologram model benchmark model.holb --iterations 1000
```

### Holo Management

```bash
# Pack multiple models into a pipeline
hologram holo pack model1.holb model2.holb -o pipeline.holm

# Unpack a pipeline
hologram holo unpack pipeline.holm -o extracted/

# Inspect archive contents
hologram holo inspect pipeline.holm
```

### Registry

```bash
# Publish a layer to local registry
hologram registry publish model.holb --name "my-model" --version "1.0.0"

# Fetch a layer by name
hologram registry fetch my-model:1.0.0 -o model.holb

# List all registered layers
hologram registry list
```

## Categorical Operations

Hologram includes specialized operations for categorical computation using the UOR (Universal Object Reference) system.

### Lift Operation

Maps bytes to torus coordinates in the categorical space:

```rust
// In your operation graph
let lift = graph.add_node(OpNode::new(id, OpKind::Lift, vec![256], DType::U8));
```

### Ring Arithmetic

Operates on the resonance ring R = 96:

```rust
// Ring addition: (a + b) mod 96
let ring_add = graph.add_node(OpNode::new(id, OpKind::RingAdd, vec![n], DType::U8));

// Ring multiplication: (a * b) mod 96
let ring_mul = graph.add_node(OpNode::new(id, OpKind::RingMul, vec![n], DType::U8));
```

### Orbit Classification

Assigns orbit class to each byte value:

```rust
let classify = graph.add_node(OpNode::new(id, OpKind::OrbitClassify, vec![n], DType::U8));
```

## Performance Tips

### 1. Use Appropriate Optimization Levels

```bash
# Level 0: No optimization (debugging)
# Level 1: Basic fusion
# Level 2: Full optimization (default)
# Level 3: Aggressive (may increase compile time)
hologram compile model.json -o model.holb --opt-level 2
```

### 2. Align Data to SIMD Boundaries

For best performance, align input data to 32 bytes (AVX2) or 64 bytes (AVX-512).

### 3. Batch Operations

When possible, process data in batches that fit in L2 cache (256KB typical). The compiler will automatically tile operations for cache efficiency.

### 4. Use the Registry for Layer Reuse

Content-addressed storage avoids redundant computation:

```bash
# Publish once
hologram registry publish expensive_layer.holb --name "preprocessor"

# Reuse via CallLayer in subsequent models
```

## Next Steps

- Read the [Architecture Guide](./architecture.md) for deeper understanding
- Explore the [Rust Examples](../examples/rust/) directory for working code
- Check the API documentation: `cargo doc --open`

## Troubleshooting

### "Invalid file format" Error

Ensure you're using the correct file extension:
- `.json` for operation graphs
- `.holb` for compiled single models
- `.holm` for multi-model pipelines

### Performance Issues

1. Check optimization level (`--opt-level 2` recommended)
2. Ensure input data is properly aligned
3. Profile with `hologram model benchmark`

### Missing Features

Some backends are still in development:
- CUDA backend: Skeleton only
- Metal backend: Skeleton only
- WASM backend: Fully functional

Use the CPU backend for production workloads.
