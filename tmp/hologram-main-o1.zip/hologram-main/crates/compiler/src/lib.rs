//! Hologram compilation pipeline.
//!
//! This crate transforms `OperationGraph` DAGs into frozen `BackendPlan` executables
//! through an 8-stage pipeline. All optimization decisions are made at compile time
//! so runtime dispatch is O(1) with zero decision overhead.
//!
//! # Compilation Pipeline
//!
//! ```text
//! OperationGraph (lazy DAG)
//!     |
//! CompilationPipeline (8 stages)
//!     |
//! BackendPlan (frozen, executable)
//! ```
//!
//! ## Stages
//!
//! 1. **IR Conversion**: Convert `OperationGraph` to internal `CompileGraph`
//! 2. **Fusion Passes**: Constant folding, CSE, activation fusion, batch fusion
//! 3. **Kernel Selection**: Choose optimal kernel per operation + backend
//! 4. **Layout Planning**: Memory ordering, alignment, tiling
//! 5. **Workspace Planning**: Liveness analysis, buffer offset computation
//! 6. **Thread Partitioning**: Parallel level construction, static assignment
//! 7. **Epilogue Fusion**: Fuse post-ops into kernel writeback
//! 8. **Plan Assembly**: Emit frozen `BackendPlan`
//!
//! # Example
//!
//! ```rust,ignore
//! use hologram_compiler::{compile, CompilerConfig, OperationGraph};
//! use hologram_backend::BackendCapabilities;
//!
//! let graph = OperationGraph::new();
//! let config = CompilerConfig::default();
//! let plan = compile(&graph, &config)?;
//! ```

#![deny(missing_docs)]
#![deny(clippy::all)]
#![warn(clippy::pedantic)]
#![allow(clippy::module_name_repetitions)]
#![allow(clippy::missing_errors_doc)]
#![allow(clippy::missing_panics_doc)]

pub mod assemble;
pub mod cache;
pub mod epilogue;
pub mod fusion;
pub mod graph;
pub mod kernel;
pub mod layout;
pub mod partition;
pub mod pipeline;
pub mod profile;
pub mod shape;
pub mod validate;
#[cfg(feature = "visualize")]
pub mod visualize;
pub mod workspace;

mod error;

// Re-exports
pub use cache::{compile_cached, CacheStats, CompileCache, DiskCache, LayerId, MemoryCache};
pub use error::CompileError;
pub use fusion::{ActivationLutConfig, QuantizeConfig, QuantizeMode};
pub use graph::{
    CompileGraph, CompileOp, ConstantData, DType, OpCategory, OpKind, OpNode, OperationGraph,
    PadMode,
};
pub use pipeline::{compile, convert_ir, CompilerConfig};
pub use profile::{capture_profile, CompileProfile};
pub use validate::validate_graph;

/// Result type for compilation operations.
pub type Result<T> = std::result::Result<T, CompileError>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_empty_graph_compiles() {
        let graph = OperationGraph::new();
        let config = CompilerConfig::default();
        let result = compile(&graph, &config);
        assert!(result.is_ok());
    }
}
