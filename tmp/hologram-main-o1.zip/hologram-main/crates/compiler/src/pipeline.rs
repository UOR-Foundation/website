//! 8-stage compilation pipeline orchestrator.
//!
//! When the `instrumentation` feature is enabled, each stage is timed and
//! recorded to the global metrics registry. Use `MetricsRegistry::global()`
//! to access timing data after compilation.

use hologram_backend::BackendCapabilities;
use hologram_holo::BackendPlan;

use crate::error::CompileError;
use crate::fusion::QuantizeConfig;
use crate::graph::{CompileGraph, ConstantData, OperationGraph};

// Import timing macro (compiles to no-op when instrumentation is disabled)
#[cfg(feature = "instrumentation")]
use hologram_telemetry::timed;

// No-op fallback when instrumentation is disabled
#[cfg(not(feature = "instrumentation"))]
macro_rules! timed {
    ($name:expr, $block:expr) => {
        $block
    };
}

/// Compiler configuration.
#[derive(Debug, Clone)]
pub struct CompilerConfig {
    /// Target backend capabilities (SIMD width, cache sizes, features).
    pub capabilities: BackendCapabilities,
    /// Parallelism threshold: only fork when element count exceeds this.
    pub parallel_threshold: usize,
    /// Optimization level (0 = none, 1 = basic fusion, 2 = full, 3 = aggressive).
    pub opt_level: u8,
    /// Weight quantization configuration for LUT-GEMM.
    ///
    /// When enabled, `MatMul` operations with constant weights are quantized
    /// for LUT-based execution, trading accuracy for 2-4x speedup.
    pub quantize: QuantizeConfig,
}

impl Default for CompilerConfig {
    fn default() -> Self {
        Self {
            capabilities: BackendCapabilities::default(),
            parallel_threshold: 4096,
            opt_level: 2,
            quantize: QuantizeConfig::default(),
        }
    }
}

/// Compile an `OperationGraph` into a `BackendPlan`.
///
/// This is the primary public API. All 8 stages run in sequence:
///
/// 1. IR Conversion
/// 2. Fusion Passes
/// 3. Kernel Selection
/// 4. Layout Planning
/// 5. Workspace Planning
/// 6. Thread Partitioning
/// 7. Epilogue Fusion
/// 8. Plan Assembly
///
/// # Errors
///
/// Returns an error if:
/// - The graph contains cycles
/// - Shapes are incompatible between connected operations
/// - No suitable kernel is available for an operation
pub fn compile(
    graph: &OperationGraph,
    config: &CompilerConfig,
) -> Result<BackendPlan, CompileError> {
    // Stage 1: IR Conversion
    let mut compile_graph = timed!("compile_stage1_ir_conversion", {
        stage_1_ir_conversion(graph)?
    });

    // Stage 2: Fusion Passes (only if opt_level > 0)
    if config.opt_level > 0 {
        timed!("compile_stage2_fusion_passes", {
            stage_2_fusion_passes(&mut compile_graph, config, &graph.constants);
        });
    }

    // Stage 3: Kernel Selection
    timed!("compile_stage3_kernel_selection", {
        stage_3_kernel_selection(&mut compile_graph, config);
    });

    // Stage 4: Layout Planning
    timed!("compile_stage4_layout_planning", {
        stage_4_layout_planning(&mut compile_graph, config);
    });

    // Stage 5: Workspace Planning
    let workspace = timed!("compile_stage5_workspace_planning", {
        stage_5_workspace_planning(&compile_graph)
    });

    // Stage 6: Thread Partitioning
    let schedule = timed!("compile_stage6_thread_partitioning", {
        stage_6_thread_partitioning(&mut compile_graph, config)
    });

    // Stage 7: Epilogue Fusion
    if config.opt_level >= 2 {
        timed!("compile_stage7_epilogue_fusion", {
            stage_7_epilogue_fusion(&mut compile_graph);
        });
    }

    // Stage 8: Plan Assembly
    // Pass input/output node IDs in registration order
    let input_node_ids: Vec<u32> = graph.inputs.iter().map(|(_, id)| *id).collect();
    let output_node_ids: Vec<u32> = graph.outputs.iter().map(|(_, id)| *id).collect();
    let plan = timed!("compile_stage8_plan_assembly", {
        stage_8_plan_assembly(
            &compile_graph,
            &workspace,
            &schedule,
            &input_node_ids,
            &output_node_ids,
            &graph.constants,
        )
    });

    Ok(plan)
}

/// Convert an `OperationGraph` to a `CompileGraph` with full validation.
///
/// This is the public API for Stage 1 of the compilation pipeline. It:
/// - Validates graph structure (no duplicate IDs, valid edges)
/// - Validates shape compatibility between connected operations
/// - Validates dtype compatibility between connected operations
/// - Validates node connectivity (inputs have no predecessors, ops have required inputs)
/// - Detects cycles via topological sort
/// - Computes topological order for subsequent stages
///
/// # Errors
///
/// Returns an error if:
/// - The graph contains duplicate node IDs
/// - Edges reference non-existent nodes
/// - Shapes are incompatible between connected operations
/// - Data types are incompatible between connected operations
/// - Input nodes have incoming edges
/// - Operations are missing required inputs
/// - The graph contains cycles
///
/// # Example
///
/// ```rust
/// use hologram_compiler::{convert_ir, OperationGraph, OpNode, OpKind, DType};
///
/// let mut graph = OperationGraph::new();
/// graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
/// graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
/// graph.add_edge(0, 1);
///
/// let compile_graph = convert_ir(&graph)?;
/// assert_eq!(compile_graph.node_count(), 2);
/// # Ok::<(), hologram_compiler::CompileError>(())
/// ```
pub fn convert_ir(graph: &OperationGraph) -> Result<CompileGraph, CompileError> {
    stage_1_ir_conversion(graph)
}

/// Stage 1: Convert `OperationGraph` to `CompileGraph`.
///
/// This stage performs comprehensive validation before conversion:
/// - Validates graph structure (no duplicate IDs, valid edges)
/// - Validates shape compatibility between connected operations
/// - Validates dtype compatibility between connected operations
/// - Validates node connectivity (inputs have no predecessors, ops have required inputs)
/// - Detects cycles
fn stage_1_ir_conversion(graph: &OperationGraph) -> Result<CompileGraph, CompileError> {
    // Validate the input graph before conversion
    crate::validate::validate_graph(graph)?;

    // Convert to CompileGraph (also performs cycle detection)
    CompileGraph::from_operation_graph(graph)
}

/// Stage 2: Run fusion passes.
fn stage_2_fusion_passes(
    graph: &mut CompileGraph,
    config: &CompilerConfig,
    constants: &[ConstantData],
) {
    // Constant folding (now computes actual values for folded constants)
    crate::fusion::constant_folding(graph, constants);

    // Common subexpression elimination
    crate::fusion::cse(graph);

    // Activation fusion (requires opt_level >= 2)
    if config.opt_level >= 2 {
        crate::fusion::activation_fusion(graph);
    }

    // Hash chain fusion: Sha256 -> Sha256 = DoubleSha256
    crate::fusion::hash_chain_fusion(graph);

    // Batch fusion (requires opt_level >= 2)
    if config.opt_level >= 2 {
        crate::fusion::batch_fusion(graph, config.parallel_threshold);
    }

    // Weight quantization for LUT-GEMM (when mode is Enabled or Auto)
    if config.quantize.is_active() {
        crate::fusion::quantize_weights(graph, constants, &config.quantize);
    }
}

/// Stage 3: Select kernels for each operation.
fn stage_3_kernel_selection(graph: &mut CompileGraph, config: &CompilerConfig) {
    crate::kernel::select_kernels(graph, &config.capabilities);
}

/// Stage 4: Plan memory layouts.
fn stage_4_layout_planning(graph: &mut CompileGraph, config: &CompilerConfig) {
    crate::layout::plan_layouts(graph, &config.capabilities);
}

/// Workspace layout computed in Stage 5.
#[derive(Debug, Clone, Default)]
pub struct WorkspaceLayout {
    /// Total workspace size in bytes.
    pub total_size: usize,
    /// Per-buffer slots.
    pub slots: Vec<WorkspaceSlot>,
}

/// A workspace buffer slot.
#[derive(Debug, Clone)]
pub struct WorkspaceSlot {
    /// Offset in workspace memory.
    pub offset: usize,
    /// Size in bytes.
    pub size: usize,
    /// Alignment requirement.
    pub alignment: usize,
}

/// Stage 5: Compute workspace layout via liveness analysis.
fn stage_5_workspace_planning(graph: &CompileGraph) -> WorkspaceLayout {
    crate::workspace::plan_workspace(graph)
}

/// Execution schedule computed in Stage 6.
#[derive(Debug, Clone, Default)]
pub struct ExecutionSchedule {
    /// Parallel levels (nodes within a level can execute concurrently).
    pub levels: Vec<ParallelLevel>,
}

/// A parallel execution level.
#[derive(Debug, Clone, Default)]
pub struct ParallelLevel {
    /// Node ids that can execute concurrently.
    pub node_ids: Vec<u32>,
}

/// Stage 6: Partition work across threads.
fn stage_6_thread_partitioning(
    graph: &mut CompileGraph,
    config: &CompilerConfig,
) -> ExecutionSchedule {
    crate::partition::partition_threads(graph, config.parallel_threshold)
}

/// Stage 7: Fuse epilogue operations.
fn stage_7_epilogue_fusion(graph: &mut CompileGraph) {
    crate::epilogue::fuse_epilogues(graph);
}

/// Stage 8: Assemble the final plan.
fn stage_8_plan_assembly(
    graph: &CompileGraph,
    workspace: &WorkspaceLayout,
    _schedule: &ExecutionSchedule,
    input_node_ids: &[u32],
    output_node_ids: &[u32],
    constants: &[ConstantData],
) -> BackendPlan {
    crate::assemble::assemble_plan(graph, workspace, input_node_ids, output_node_ids, constants)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpKind, OpNode};

    #[test]
    fn test_compile_empty_graph() {
        let graph = OperationGraph::new();
        let config = CompilerConfig::default();
        let result = compile(&graph, &config);
        assert!(result.is_ok());
    }

    #[test]
    fn test_compile_simple_graph() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 2], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 2], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![1, 2], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        let config = CompilerConfig::default();
        let result = compile(&graph, &config);
        assert!(result.is_ok());
    }

    #[test]
    fn test_compiler_config_default() {
        let config = CompilerConfig::default();
        assert_eq!(config.parallel_threshold, 4096);
        assert_eq!(config.opt_level, 2);
    }

    // --- convert_ir tests ---

    #[test]
    fn test_convert_ir_empty_graph() {
        let graph = OperationGraph::new();
        let result = convert_ir(&graph);
        assert!(result.is_ok());
        assert_eq!(result.unwrap().node_count(), 0);
    }

    #[test]
    fn test_convert_ir_simple_chain() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![2, 3], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);

        let compile_graph = convert_ir(&graph).unwrap();
        assert_eq!(compile_graph.node_count(), 4);

        // Verify topological order
        let topo = compile_graph.topo_order();
        let pos_0 = topo.iter().position(|&x| x == 0).unwrap();
        let pos_1 = topo.iter().position(|&x| x == 1).unwrap();
        let pos_2 = topo.iter().position(|&x| x == 2).unwrap();
        let pos_3 = topo.iter().position(|&x| x == 3).unwrap();
        assert!(pos_0 < pos_1);
        assert!(pos_1 < pos_2);
        assert!(pos_2 < pos_3);
    }

    #[test]
    fn test_convert_ir_binary_op() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![4, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![4, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Add, vec![4, 4], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![4, 4], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);

        let compile_graph = convert_ir(&graph).unwrap();
        assert_eq!(compile_graph.node_count(), 4);
    }

    #[test]
    fn test_convert_ir_rejects_cycle() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Relu, vec![1], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_edge(2, 1); // Cycle!

        let result = convert_ir(&graph);
        assert!(matches!(result, Err(CompileError::CycleDetected)));
    }

    #[test]
    fn test_convert_ir_rejects_shape_mismatch() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![4, 5], DType::F32)); // Wrong shape
        graph.add_edge(0, 1);

        let result = convert_ir(&graph);
        assert!(matches!(result, Err(CompileError::ShapeMismatch { .. })));
    }

    #[test]
    fn test_convert_ir_rejects_dtype_mismatch() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::I32)); // Wrong dtype
        graph.add_edge(0, 1);

        let result = convert_ir(&graph);
        assert!(matches!(result, Err(CompileError::DTypeMismatch { .. })));
    }

    #[test]
    fn test_convert_ir_rejects_duplicate_node_id() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_node(OpNode::new(0, OpKind::Relu, vec![1], DType::F32)); // Duplicate ID

        let result = convert_ir(&graph);
        assert!(matches!(result, Err(CompileError::DuplicateNodeId(0))));
    }

    #[test]
    fn test_convert_ir_rejects_invalid_edge() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_edge(0, 99); // Node 99 doesn't exist

        let result = convert_ir(&graph);
        assert!(matches!(result, Err(CompileError::InvalidEdge { .. })));
    }

    #[test]
    fn test_convert_ir_rejects_missing_inputs() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Add, vec![1], DType::F32)); // Add needs 2 inputs

        let result = convert_ir(&graph);
        assert!(matches!(result, Err(CompileError::MissingInputs { .. })));
    }

    #[test]
    fn test_convert_ir_rejects_input_with_edges() {
        let mut graph = OperationGraph::new();
        // Create an Input that receives an edge from another Input
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![1], DType::F32));
        graph.add_edge(0, 1); // Input shouldn't have incoming edges

        let result = convert_ir(&graph);
        assert!(matches!(result, Err(CompileError::InputHasEdges { .. })));
    }

    #[test]
    fn test_convert_ir_with_named_io() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_input("x", 0);
        graph.add_output("y", 2);

        let compile_graph = convert_ir(&graph).unwrap();
        assert_eq!(compile_graph.inputs(), &[("x".to_string(), 0)]);
        assert_eq!(compile_graph.outputs(), &[("y".to_string(), 2)]);
    }

    #[test]
    fn test_convert_ir_rejects_invalid_named_input() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_input("x", 99); // Node 99 doesn't exist

        let result = convert_ir(&graph);
        assert!(matches!(result, Err(CompileError::InvalidInput { .. })));
    }

    #[test]
    fn test_convert_ir_rejects_invalid_named_output() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_output("y", 99); // Node 99 doesn't exist

        let result = convert_ir(&graph);
        assert!(matches!(result, Err(CompileError::InvalidOutput { .. })));
    }

    #[test]
    fn test_convert_ir_matmul_graph() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![8, 16], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![16, 32], DType::F32));
        graph.add_node(OpNode::new(
            2,
            OpKind::MatMul { m: 8, k: 16, n: 32 },
            vec![8, 32],
            DType::F32,
        ));
        graph.add_node(OpNode::new(3, OpKind::Relu, vec![8, 32], DType::F32));
        graph.add_node(OpNode::new(4, OpKind::Output, vec![8, 32], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        graph.add_edge(3, 4);

        let compile_graph = convert_ir(&graph).unwrap();
        assert_eq!(compile_graph.node_count(), 5);
    }

    #[test]
    fn test_convert_ir_diamond_graph() {
        // Input -> [A, B] -> Add -> Output (diamond pattern)
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![4, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![4, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![4, 4], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Add, vec![4, 4], DType::F32));
        graph.add_node(OpNode::new(4, OpKind::Output, vec![4, 4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(0, 2);
        graph.add_edge(1, 3);
        graph.add_edge(2, 3);
        graph.add_edge(3, 4);

        let compile_graph = convert_ir(&graph).unwrap();
        assert_eq!(compile_graph.node_count(), 5);

        // In topo order, 0 must come before 1 and 2
        // 1 and 2 must come before 3
        // 3 must come before 4
        let topo = compile_graph.topo_order();
        let pos = |id| topo.iter().position(|&x| x == id).unwrap();
        assert!(pos(0) < pos(1));
        assert!(pos(0) < pos(2));
        assert!(pos(1) < pos(3));
        assert!(pos(2) < pos(3));
        assert!(pos(3) < pos(4));
    }

    // --- Integration tests ---

    #[test]
    fn test_compile_produces_valid_plan() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![64, 64], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);

        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).unwrap();

        // Plan should have buffers (may be fewer due to fusion)
        assert!(!plan.buffers.is_empty());
        // Plan should have at least some instructions
        // Note: some may be fused, so count may be lower than expected
    }

    #[test]
    fn test_compile_opt_level_zero() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![32, 32], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![32, 32], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![32, 32], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        let config = CompilerConfig {
            opt_level: 0,
            ..Default::default()
        };
        let plan = compile(&graph, &config).unwrap();

        // Should still produce a valid plan with opt_level=0
        assert!(!plan.buffers.is_empty());
    }

    #[test]
    fn test_compile_opt_level_one() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![32, 32], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![32, 32], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![32, 32], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        let config = CompilerConfig {
            opt_level: 1,
            ..Default::default()
        };
        let plan = compile(&graph, &config).unwrap();

        // opt_level=1 runs constant folding and CSE but not activation/batch fusion
        assert!(!plan.buffers.is_empty());
    }

    #[test]
    fn test_compile_opt_level_three() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![32, 32], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![32, 32], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![32, 32], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        let config = CompilerConfig {
            opt_level: 3,
            ..Default::default()
        };
        let plan = compile(&graph, &config).unwrap();

        // opt_level=3 (aggressive) should still work
        assert!(!plan.buffers.is_empty());
    }

    #[test]
    fn test_compile_matmul_with_activation() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![16, 32], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![32, 64], DType::F32));
        graph.add_node(OpNode::new(
            2,
            OpKind::MatMul {
                m: 16,
                k: 32,
                n: 64,
            },
            vec![16, 64],
            DType::F32,
        ));
        graph.add_node(OpNode::new(3, OpKind::Relu, vec![16, 64], DType::F32));
        graph.add_node(OpNode::new(4, OpKind::Output, vec![16, 64], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        graph.add_edge(3, 4);

        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).unwrap();

        assert_eq!(plan.buffers.len(), 5);
    }

    #[test]
    fn test_compile_binary_operations() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![128], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![128], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Add, vec![128], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Input, vec![128], DType::F32));
        graph.add_node(OpNode::new(4, OpKind::Sub, vec![128], DType::F32));
        graph.add_node(OpNode::new(5, OpKind::Output, vec![128], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 4);
        graph.add_edge(3, 4);
        graph.add_edge(4, 5);

        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).unwrap();

        // Should have buffers for all nodes
        assert_eq!(plan.buffers.len(), 6);
    }

    #[test]
    fn test_compile_parallel_threshold() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![8192], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![8192], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![8192], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        // Low threshold: more parallelization
        let config_low = CompilerConfig {
            parallel_threshold: 1024,
            ..Default::default()
        };
        let plan_low = compile(&graph, &config_low).unwrap();

        // High threshold: less parallelization
        let config_high = CompilerConfig {
            parallel_threshold: 16384,
            ..Default::default()
        };
        let plan_high = compile(&graph, &config_high).unwrap();

        // Both should compile successfully
        assert!(!plan_low.buffers.is_empty());
        assert!(!plan_high.buffers.is_empty());
    }

    #[test]
    fn test_compile_large_graph() {
        // Build a chain of operations that won't all be fused
        // Use a mix of non-fusable ops
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![256], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![256], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Lift, vec![256], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Sigmoid, vec![256], DType::F32));
        graph.add_node(OpNode::new(4, OpKind::Output, vec![256], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        graph.add_edge(3, 4);

        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).unwrap();

        // Plan should compile successfully
        assert!(!plan.buffers.is_empty());
    }

    #[test]
    fn test_compile_wide_parallel_graph() {
        // Build a graph with parallel branches that converge
        // Input -> [Lift, OrbitClassify] -> Add -> Output
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1024], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Lift, vec![1024], DType::F32));
        graph.add_node(OpNode::new(
            2,
            OpKind::OrbitClassify,
            vec![1024],
            DType::F32,
        ));
        graph.add_node(OpNode::new(3, OpKind::Add, vec![1024], DType::F32));
        graph.add_node(OpNode::new(4, OpKind::Output, vec![1024], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(0, 2);
        graph.add_edge(1, 3);
        graph.add_edge(2, 3);
        graph.add_edge(3, 4);

        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).unwrap();

        // Should compile all nodes (5 total)
        assert_eq!(plan.buffers.len(), 5);
    }

    #[test]
    fn test_compile_with_reduction() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Sum, vec![64], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![64], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).unwrap();

        assert_eq!(plan.buffers.len(), 3);
    }

    #[test]
    fn test_compile_with_multiple_outputs() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![64], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![64], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![64], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![64], DType::F32));
        graph.add_node(OpNode::new(4, OpKind::Output, vec![64], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(0, 2);
        graph.add_edge(1, 3);
        graph.add_edge(2, 4);

        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).unwrap();

        assert_eq!(plan.buffers.len(), 5);
    }

    #[test]
    fn test_compile_preserves_workspace_size() {
        let mut graph = OperationGraph::new();
        // Create nodes large enough to need workspace
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1024, 1024], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1024, 1024], DType::F32));
        graph.add_node(OpNode::new(
            2,
            OpKind::Sigmoid,
            vec![1024, 1024],
            DType::F32,
        ));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![1024, 1024], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);

        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).unwrap();

        // Workspace should be computed from liveness analysis
        // Just verify the plan compiled successfully with a workspace
        let _ = plan.workspace_size; // workspace_size is computed, may be 0 or larger
    }
}
