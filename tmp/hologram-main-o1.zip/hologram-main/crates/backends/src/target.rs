//! Backend target trait for platform-specific primitive implementations.
//!
//! This module provides the `BackendTarget` trait that defines how microcode
//! primitives are implemented on specific hardware targets. Each target
//! (x86_64 AVX2, aarch64 NEON, WASM SIMD128, etc.) provides its own word type
//! and primitive implementations.
//!
//! # Architecture
//!
//! ```text
//! BackendTarget (trait)
//! ├── word_type() - The SIMD word type for this target
//! ├── primitive implementations (bnot, neg, xor, and, or)
//! ├── native_overrides() - Hardware-accelerated operations
//! └── capabilities() - What features this target supports
//!
//! Implementations:
//! ├── ScalarTarget - Pure Rust fallback (u32)
//! ├── X86_64Avx2Target - AVX2 intrinsics ([u32; 8])
//! ├── Aarch64NeonTarget - NEON intrinsics ([u32; 4])
//! └── WasmSimd128Target - WASM SIMD ([u32; 4])
//! ```
//!
//! # Backend Categories
//!
//! Backends are organized into categories:
//! - **CPU**: x86_64, aarch64, scalar fallback
//! - **WASM**: WebAssembly with optional SIMD128
//! - **GPU**: CUDA, Metal, WebGPU
//!
//! # Native Overrides
//!
//! Some operations have hardware implementations that are faster than
//! microcode synthesis. For example, ADD on x86_64 uses `vpaddd` (1 cycle)
//! instead of Kogge-Stone microcode (5-7 cycles). The `NativeOverride`
//! enum tracks which operations have hardware acceleration.

// Primitives are single-instruction operations that must be inlined for performance.
#![allow(clippy::inline_always)]

use std::sync::OnceLock;
use uor::microcode::{MicrocodePrimitives, MicrocodeWord};

/// Backend category for classification.
///
/// Categorizes backends by their execution model and target platform.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum BackendCategory {
    /// CPU backends using SIMD (AVX2, NEON) or scalar operations
    Cpu,
    /// WebAssembly backends (WASM SIMD128 or scalar)
    Wasm,
    /// GPU backends (CUDA, Metal, WebGPU)
    Gpu,
}

impl BackendCategory {
    /// Check if this category uses microcode primitives.
    ///
    /// GPU backends bypass microcode and implement ISA operations directly.
    #[must_use]
    pub const fn uses_microcode(&self) -> bool {
        match self {
            Self::Cpu | Self::Wasm => true,
            Self::Gpu => false,
        }
    }

    /// Get the category name.
    #[must_use]
    pub const fn name(&self) -> &'static str {
        match self {
            Self::Cpu => "cpu",
            Self::Wasm => "wasm",
            Self::Gpu => "gpu",
        }
    }
}

/// Identifies operations that have hardware-accelerated implementations.
///
/// When an operation has a native override, the backend uses the hardware
/// instruction directly instead of synthesizing from microcode primitives.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum NativeOverride {
    /// Integer addition (vpaddd on x86_64, vadd on NEON)
    Add,
    /// Integer subtraction
    Sub,
    /// Integer multiplication
    Mul,
    /// SHA256 round (sha256rnds2 on x86_64 with SHA-NI)
    Sha256Round,
    /// AES encryption round (aesenc on x86_64 with AES-NI)
    AesRound,
    /// AES decryption round (aesdec on x86_64 with AES-NI)
    AesRoundDec,
    /// Population count (popcnt)
    PopCount,
    /// Leading zero count (lzcnt)
    LeadingZeros,
    /// Trailing zero count (tzcnt)
    TrailingZeros,
}

/// Capabilities of a backend target.
///
/// This struct describes what features and optimizations are available
/// on a specific target platform.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct TargetCapabilities {
    /// Backend category (CPU, WASM, GPU)
    pub category: BackendCategory,
    /// Vector width in bits (32 for scalar, 128 for NEON/WASM, 256 for AVX2)
    pub vector_bits: u32,
    /// Number of elements per vector (1 for scalar, 4 for 128-bit, 8 for 256-bit)
    pub vector_lanes: u32,
    /// Whether this target uses SIMD instructions
    pub is_simd: bool,
    /// Whether native ADD is available (faster than Kogge-Stone)
    pub has_native_add: bool,
    /// Whether native MUL is available
    pub has_native_mul: bool,
    /// Whether SHA-NI instructions are available
    pub has_sha_ni: bool,
    /// Whether AES-NI instructions are available
    pub has_aes_ni: bool,
    /// L1 data cache size in bytes (for tiling optimizations)
    pub l1_cache_size: u32,
    /// L2 cache size in bytes
    pub l2_cache_size: u32,
    /// GPU compute units (for GPU backends, 0 for CPU/WASM)
    pub gpu_compute_units: u32,
    /// GPU max workgroup size (for GPU backends, 0 for CPU/WASM)
    pub gpu_max_workgroup_size: u32,
}

impl Default for TargetCapabilities {
    fn default() -> Self {
        Self::scalar()
    }
}

impl TargetCapabilities {
    /// Default capabilities for a scalar target.
    #[must_use]
    pub const fn scalar() -> Self {
        Self {
            category: BackendCategory::Cpu,
            vector_bits: 32,
            vector_lanes: 1,
            is_simd: false,
            has_native_add: true,
            has_native_mul: true,
            has_sha_ni: false,
            has_aes_ni: false,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            gpu_compute_units: 0,
            gpu_max_workgroup_size: 0,
        }
    }

    /// Capabilities for x86_64 with AVX2.
    #[must_use]
    pub const fn x86_64_avx2() -> Self {
        Self {
            category: BackendCategory::Cpu,
            vector_bits: 256,
            vector_lanes: 8,
            is_simd: true,
            has_native_add: true,
            has_native_mul: true,
            has_sha_ni: false, // Separate from AVX2, requires SHA-NI feature
            has_aes_ni: false, // Separate from AVX2, requires AES-NI feature
            l1_cache_size: 32 * 1024,
            l2_cache_size: 512 * 1024,
            gpu_compute_units: 0,
            gpu_max_workgroup_size: 0,
        }
    }

    /// Capabilities for x86_64 with AVX2 + SHA-NI + AES-NI.
    #[must_use]
    pub const fn x86_64_full() -> Self {
        Self {
            category: BackendCategory::Cpu,
            vector_bits: 256,
            vector_lanes: 8,
            is_simd: true,
            has_native_add: true,
            has_native_mul: true,
            has_sha_ni: true,
            has_aes_ni: true,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 512 * 1024,
            gpu_compute_units: 0,
            gpu_max_workgroup_size: 0,
        }
    }

    /// Capabilities for aarch64 with NEON.
    #[must_use]
    pub const fn aarch64_neon() -> Self {
        Self {
            category: BackendCategory::Cpu,
            vector_bits: 128,
            vector_lanes: 4,
            is_simd: true,
            has_native_add: true,
            has_native_mul: true,
            has_sha_ni: false, // ARMv8 has SHA extensions but separate from NEON
            has_aes_ni: false, // ARMv8 has AES extensions but separate from NEON
            l1_cache_size: 64 * 1024,
            l2_cache_size: 512 * 1024,
            gpu_compute_units: 0,
            gpu_max_workgroup_size: 0,
        }
    }

    /// Capabilities for WASM SIMD128.
    #[must_use]
    pub const fn wasm_simd128() -> Self {
        Self {
            category: BackendCategory::Wasm,
            vector_bits: 128,
            vector_lanes: 4,
            is_simd: true,
            has_native_add: true,
            has_native_mul: true,
            has_sha_ni: false,
            has_aes_ni: false,
            l1_cache_size: 32 * 1024, // Varies by browser/runtime
            l2_cache_size: 256 * 1024,
            gpu_compute_units: 0,
            gpu_max_workgroup_size: 0,
        }
    }

    /// Capabilities for WebGPU.
    ///
    /// WebGPU uses thread-based parallelism rather than SIMD lanes.
    /// Actual values depend on the underlying GPU hardware.
    #[must_use]
    pub const fn webgpu() -> Self {
        Self {
            category: BackendCategory::Gpu,
            vector_bits: 32, // WebGPU uses scalar types in WGSL
            vector_lanes: 1,
            is_simd: false, // Thread parallelism, not SIMD
            has_native_add: true,
            has_native_mul: true,
            has_sha_ni: false, // Software crypto
            has_aes_ni: false,
            l1_cache_size: 16 * 1024,
            l2_cache_size: 4 * 1024 * 1024,
            gpu_compute_units: 0,        // Unknown until device enumeration
            gpu_max_workgroup_size: 256, // WebGPU spec minimum
        }
    }

    /// Capabilities for NVIDIA CUDA.
    #[must_use]
    pub const fn cuda() -> Self {
        Self {
            category: BackendCategory::Gpu,
            vector_bits: 32,
            vector_lanes: 1,
            is_simd: false, // Thread parallelism
            has_native_add: true,
            has_native_mul: true,
            has_sha_ni: false,
            has_aes_ni: false,
            l1_cache_size: 48 * 1024,       // Per SM, varies by architecture
            l2_cache_size: 4 * 1024 * 1024, // Varies by device
            gpu_compute_units: 0,           // Unknown until device enumeration
            gpu_max_workgroup_size: 1024,   // CUDA thread block limit
        }
    }

    /// Capabilities for Apple Metal.
    #[must_use]
    pub const fn metal() -> Self {
        Self {
            category: BackendCategory::Gpu,
            vector_bits: 32,
            vector_lanes: 1,
            is_simd: false, // Thread parallelism
            has_native_add: true,
            has_native_mul: true,
            has_sha_ni: false,
            has_aes_ni: false,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 4 * 1024 * 1024,
            gpu_compute_units: 0,         // Unknown until device enumeration
            gpu_max_workgroup_size: 1024, // Apple GPU threadgroup limit
        }
    }

    /// Check if a specific native override is available.
    #[must_use]
    pub const fn has_override(&self, op: NativeOverride) -> bool {
        match op {
            // Add and Sub use the same hardware instruction path
            NativeOverride::Add | NativeOverride::Sub => self.has_native_add,
            NativeOverride::Mul => self.has_native_mul,
            NativeOverride::Sha256Round => self.has_sha_ni,
            NativeOverride::AesRound | NativeOverride::AesRoundDec => self.has_aes_ni,
            NativeOverride::PopCount
            | NativeOverride::LeadingZeros
            | NativeOverride::TrailingZeros => true, // Usually available
        }
    }

    /// Check if this is a GPU backend.
    #[must_use]
    pub const fn is_gpu(&self) -> bool {
        matches!(self.category, BackendCategory::Gpu)
    }

    /// Check if this backend uses microcode primitives.
    #[must_use]
    pub const fn uses_microcode(&self) -> bool {
        self.category.uses_microcode()
    }
}

/// Trait for backend targets that implement microcode primitives.
///
/// Each target provides:
/// 1. A word type (scalar u32 or SIMD vector)
/// 2. Primitive implementations using hardware-specific operations
/// 3. Information about which native overrides are available
///
/// # Example
///
/// ```
/// use hologram_backend::target::{BackendTarget, TargetCapabilities};
/// use uor::microcode::MicrocodePrimitives;
///
/// struct MyScalarTarget;
///
/// impl BackendTarget for MyScalarTarget {
///     type Word = u32;
///
///     fn name(&self) -> &'static str { "my-scalar" }
///
///     fn capabilities(&self) -> TargetCapabilities {
///         TargetCapabilities::scalar()
///     }
/// }
///
/// impl MicrocodePrimitives<u32> for MyScalarTarget {
///     fn bnot(&self, a: u32) -> u32 { !a }
///     fn neg(&self, a: u32) -> u32 { a.wrapping_neg() }
///     fn xor(&self, a: u32, b: u32) -> u32 { a ^ b }
///     fn and(&self, a: u32, b: u32) -> u32 { a & b }
///     fn or(&self, a: u32, b: u32) -> u32 { a | b }
/// }
/// ```
pub trait BackendTarget: MicrocodePrimitives<Self::Word> {
    /// The word type for this target.
    ///
    /// - Scalar: `u32`
    /// - AVX2: `[u32; 8]`
    /// - NEON/WASM: `[u32; 4]`
    type Word: MicrocodeWord;

    /// Get the name of this target.
    fn name(&self) -> &'static str;

    /// Get the capabilities of this target.
    fn capabilities(&self) -> TargetCapabilities;

    /// Check if a native override is available for an operation.
    #[inline]
    fn has_native_override(&self, op: NativeOverride) -> bool {
        self.capabilities().has_override(op)
    }

    /// Get the vector width in bits.
    #[inline]
    fn vector_bits(&self) -> u32 {
        self.capabilities().vector_bits
    }

    /// Check if this target uses SIMD.
    #[inline]
    fn is_simd(&self) -> bool {
        self.capabilities().is_simd
    }
}

// =============================================================================
// Scalar Target (Reference Implementation)
// =============================================================================

/// Scalar target using pure Rust operations.
///
/// This is the fallback target that works on all platforms. It uses
/// 32-bit words and native Rust operations.
#[derive(Debug, Clone, Copy, Default)]
pub struct ScalarTarget;

impl ScalarTarget {
    /// Create a new scalar target.
    #[must_use]
    pub const fn new() -> Self {
        Self
    }
}

impl BackendTarget for ScalarTarget {
    type Word = u32;

    fn name(&self) -> &'static str {
        "scalar"
    }

    fn capabilities(&self) -> TargetCapabilities {
        TargetCapabilities::scalar()
    }
}

impl MicrocodePrimitives<u32> for ScalarTarget {
    #[inline(always)]
    fn bnot(&self, a: u32) -> u32 {
        !a
    }

    #[inline(always)]
    fn neg(&self, a: u32) -> u32 {
        a.wrapping_neg()
    }

    #[inline(always)]
    fn xor(&self, a: u32, b: u32) -> u32 {
        a ^ b
    }

    #[inline(always)]
    fn and(&self, a: u32, b: u32) -> u32 {
        a & b
    }

    #[inline(always)]
    fn or(&self, a: u32, b: u32) -> u32 {
        a | b
    }
}

// =============================================================================
// Array-based Targets (Portable SIMD)
// =============================================================================

/// Portable 128-bit SIMD target using array operations.
///
/// This target processes 4 x u32 elements in parallel using Rust array
/// operations. It serves as a portable SIMD implementation that works
/// on all platforms without hardware-specific intrinsics.
#[derive(Debug, Clone, Copy, Default)]
pub struct Simd128Target;

impl Simd128Target {
    /// Create a new 128-bit SIMD target.
    #[must_use]
    pub const fn new() -> Self {
        Self
    }
}

impl BackendTarget for Simd128Target {
    type Word = [u32; 4];

    fn name(&self) -> &'static str {
        "simd128-portable"
    }

    fn capabilities(&self) -> TargetCapabilities {
        TargetCapabilities {
            category: BackendCategory::Cpu,
            vector_bits: 128,
            vector_lanes: 4,
            is_simd: true,
            has_native_add: true,
            has_native_mul: true,
            has_sha_ni: false,
            has_aes_ni: false,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            gpu_compute_units: 0,
            gpu_max_workgroup_size: 0,
        }
    }
}

impl MicrocodePrimitives<[u32; 4]> for Simd128Target {
    #[inline(always)]
    fn bnot(&self, a: [u32; 4]) -> [u32; 4] {
        [!a[0], !a[1], !a[2], !a[3]]
    }

    #[inline(always)]
    fn neg(&self, a: [u32; 4]) -> [u32; 4] {
        [
            a[0].wrapping_neg(),
            a[1].wrapping_neg(),
            a[2].wrapping_neg(),
            a[3].wrapping_neg(),
        ]
    }

    #[inline(always)]
    fn xor(&self, a: [u32; 4], b: [u32; 4]) -> [u32; 4] {
        [a[0] ^ b[0], a[1] ^ b[1], a[2] ^ b[2], a[3] ^ b[3]]
    }

    #[inline(always)]
    fn and(&self, a: [u32; 4], b: [u32; 4]) -> [u32; 4] {
        [a[0] & b[0], a[1] & b[1], a[2] & b[2], a[3] & b[3]]
    }

    #[inline(always)]
    fn or(&self, a: [u32; 4], b: [u32; 4]) -> [u32; 4] {
        [a[0] | b[0], a[1] | b[1], a[2] | b[2], a[3] | b[3]]
    }
}

/// Portable 256-bit SIMD target using array operations.
///
/// This target processes 8 x u32 elements in parallel using Rust array
/// operations. It matches the width of x86_64 AVX2 registers.
#[derive(Debug, Clone, Copy, Default)]
pub struct Simd256Target;

impl Simd256Target {
    /// Create a new 256-bit SIMD target.
    #[must_use]
    pub const fn new() -> Self {
        Self
    }
}

impl BackendTarget for Simd256Target {
    type Word = [u32; 8];

    fn name(&self) -> &'static str {
        "simd256-portable"
    }

    fn capabilities(&self) -> TargetCapabilities {
        TargetCapabilities {
            category: BackendCategory::Cpu,
            vector_bits: 256,
            vector_lanes: 8,
            is_simd: true,
            has_native_add: true,
            has_native_mul: true,
            has_sha_ni: false,
            has_aes_ni: false,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            gpu_compute_units: 0,
            gpu_max_workgroup_size: 0,
        }
    }
}

impl MicrocodePrimitives<[u32; 8]> for Simd256Target {
    #[inline(always)]
    fn bnot(&self, a: [u32; 8]) -> [u32; 8] {
        [!a[0], !a[1], !a[2], !a[3], !a[4], !a[5], !a[6], !a[7]]
    }

    #[inline(always)]
    fn neg(&self, a: [u32; 8]) -> [u32; 8] {
        [
            a[0].wrapping_neg(),
            a[1].wrapping_neg(),
            a[2].wrapping_neg(),
            a[3].wrapping_neg(),
            a[4].wrapping_neg(),
            a[5].wrapping_neg(),
            a[6].wrapping_neg(),
            a[7].wrapping_neg(),
        ]
    }

    #[inline(always)]
    fn xor(&self, a: [u32; 8], b: [u32; 8]) -> [u32; 8] {
        [
            a[0] ^ b[0],
            a[1] ^ b[1],
            a[2] ^ b[2],
            a[3] ^ b[3],
            a[4] ^ b[4],
            a[5] ^ b[5],
            a[6] ^ b[6],
            a[7] ^ b[7],
        ]
    }

    #[inline(always)]
    fn and(&self, a: [u32; 8], b: [u32; 8]) -> [u32; 8] {
        [
            a[0] & b[0],
            a[1] & b[1],
            a[2] & b[2],
            a[3] & b[3],
            a[4] & b[4],
            a[5] & b[5],
            a[6] & b[6],
            a[7] & b[7],
        ]
    }

    #[inline(always)]
    fn or(&self, a: [u32; 8], b: [u32; 8]) -> [u32; 8] {
        [
            a[0] | b[0],
            a[1] | b[1],
            a[2] | b[2],
            a[3] | b[3],
            a[4] | b[4],
            a[5] | b[5],
            a[6] | b[6],
            a[7] | b[7],
        ]
    }
}

// =============================================================================
// Target Selection
// =============================================================================

/// Select the optimal target at runtime based on CPU features.
///
/// This function detects available CPU features and returns the fastest
/// compatible target for the current platform.
#[must_use]
pub fn auto_select_target() -> SelectedTarget {
    #[cfg(target_arch = "x86_64")]
    {
        if is_x86_feature_detected!("avx2") {
            SelectedTarget::Simd256(Simd256Target::new())
        } else {
            SelectedTarget::Scalar(ScalarTarget::new())
        }
    }

    #[cfg(target_arch = "aarch64")]
    {
        // NEON is mandatory on AArch64
        SelectedTarget::Simd128(Simd128Target::new())
    }

    #[cfg(target_arch = "wasm32")]
    {
        #[cfg(target_feature = "simd128")]
        return SelectedTarget::Simd128(Simd128Target::new());
        #[cfg(not(target_feature = "simd128"))]
        return SelectedTarget::Scalar(ScalarTarget::new());
    }

    #[cfg(not(any(
        target_arch = "x86_64",
        target_arch = "aarch64",
        target_arch = "wasm32"
    )))]
    {
        SelectedTarget::Scalar(ScalarTarget::new())
    }
}

/// Global cache for the auto-selected target.
///
/// This is initialized on first access and never changes afterwards.
/// Feature detection runs exactly once at program startup.
static CACHED_TARGET: OnceLock<SelectedTarget> = OnceLock::new();

/// Get the cached optimal target for the current platform.
///
/// This function performs feature detection on the first call and caches
/// the result. Subsequent calls return the cached value with < 1ns overhead.
///
/// # Performance
///
/// - First call: ~100-500ns (feature detection)
/// - Subsequent calls: < 1ns (single atomic load)
///
/// # Example
///
/// ```
/// use hologram_backend::cached_target;
///
/// // First call detects features
/// let target = cached_target();
///
/// // Subsequent calls use cache
/// let target2 = cached_target();
/// assert_eq!(target.name(), target2.name());
/// ```
#[must_use]
#[inline]
pub fn cached_target() -> &'static SelectedTarget {
    CACHED_TARGET.get_or_init(auto_select_target)
}

/// A dynamically-selected target implementation.
///
/// This enum wraps the available target implementations and provides
/// unified access to their capabilities.
#[derive(Debug, Clone, Copy)]
pub enum SelectedTarget {
    /// Scalar (u32) target
    Scalar(ScalarTarget),
    /// 128-bit SIMD ([u32; 4]) target
    Simd128(Simd128Target),
    /// 256-bit SIMD ([u32; 8]) target
    Simd256(Simd256Target),
}

impl SelectedTarget {
    /// Get the name of the selected target.
    #[must_use]
    pub fn name(&self) -> &'static str {
        match self {
            Self::Scalar(_) => "scalar",
            Self::Simd128(_) => "simd128-portable",
            Self::Simd256(_) => "simd256-portable",
        }
    }

    /// Get the capabilities of the selected target.
    #[must_use]
    pub fn capabilities(&self) -> TargetCapabilities {
        match self {
            Self::Scalar(t) => t.capabilities(),
            Self::Simd128(t) => t.capabilities(),
            Self::Simd256(t) => t.capabilities(),
        }
    }

    /// Check if this target uses SIMD.
    #[must_use]
    pub fn is_simd(&self) -> bool {
        match self {
            Self::Scalar(_) => false,
            Self::Simd128(_) | Self::Simd256(_) => true,
        }
    }

    /// Get the scalar target, if this is a scalar target.
    #[must_use]
    pub fn as_scalar(&self) -> Option<&ScalarTarget> {
        match self {
            Self::Scalar(t) => Some(t),
            _ => None,
        }
    }

    /// Get the 128-bit SIMD target, if this is a 128-bit target.
    #[must_use]
    pub fn as_simd128(&self) -> Option<&Simd128Target> {
        match self {
            Self::Simd128(t) => Some(t),
            _ => None,
        }
    }

    /// Get the 256-bit SIMD target, if this is a 256-bit target.
    #[must_use]
    pub fn as_simd256(&self) -> Option<&Simd256Target> {
        match self {
            Self::Simd256(t) => Some(t),
            _ => None,
        }
    }
}

impl Default for SelectedTarget {
    fn default() -> Self {
        auto_select_target()
    }
}

// =============================================================================
// Backend Registry
// =============================================================================

/// Information about an available backend.
#[derive(Debug, Clone)]
pub struct BackendInfo {
    /// Backend name (e.g., "cuda", "metal", "webgpu", "cpu-avx2")
    pub name: &'static str,
    /// Backend category
    pub category: BackendCategory,
    /// Whether this backend is currently available
    pub available: bool,
    /// Brief description
    pub description: &'static str,
}

/// Registry of all known backends with availability status.
///
/// This provides a unified view of all backends across categories,
/// enabling runtime discovery and selection.
#[derive(Debug, Clone)]
pub struct BackendRegistry {
    backends: Vec<BackendInfo>,
}

impl BackendRegistry {
    /// Create a new registry with all known backends.
    ///
    /// Performs availability checks for each backend type.
    #[must_use]
    pub fn new() -> Self {
        let mut backends = Vec::new();

        // CPU backends
        backends.push(BackendInfo {
            name: "cpu-scalar",
            category: BackendCategory::Cpu,
            available: true, // Always available
            description: "Pure Rust scalar fallback",
        });

        #[cfg(target_arch = "x86_64")]
        {
            backends.push(BackendInfo {
                name: "cpu-avx2",
                category: BackendCategory::Cpu,
                available: is_x86_feature_detected!("avx2"),
                description: "x86_64 with AVX2 (256-bit SIMD)",
            });
        }

        #[cfg(target_arch = "aarch64")]
        {
            backends.push(BackendInfo {
                name: "cpu-neon",
                category: BackendCategory::Cpu,
                available: true, // NEON is mandatory on aarch64
                description: "ARM64 with NEON (128-bit SIMD)",
            });
        }

        // WASM backends
        #[cfg(target_arch = "wasm32")]
        {
            backends.push(BackendInfo {
                name: "wasm-simd128",
                category: BackendCategory::Wasm,
                #[cfg(target_feature = "simd128")]
                available: true,
                #[cfg(not(target_feature = "simd128"))]
                available: false,
                description: "WebAssembly SIMD128 (128-bit)",
            });

            backends.push(BackendInfo {
                name: "wasm-scalar",
                category: BackendCategory::Wasm,
                available: true,
                description: "WebAssembly scalar fallback",
            });
        }

        // GPU backends (check availability via backend structs)
        backends.push(BackendInfo {
            name: "cuda",
            category: BackendCategory::Gpu,
            available: crate::CudaBackend::is_available(),
            description: "NVIDIA CUDA (skeleton)",
        });

        backends.push(BackendInfo {
            name: "metal",
            category: BackendCategory::Gpu,
            available: crate::MetalBackend::is_available(),
            description: "Apple Metal (skeleton)",
        });

        backends.push(BackendInfo {
            name: "webgpu",
            category: BackendCategory::Gpu,
            available: crate::WebGpuBackend::is_available(),
            description: "Cross-platform WebGPU (skeleton)",
        });

        Self { backends }
    }

    /// Get all registered backends.
    #[must_use]
    pub fn all(&self) -> &[BackendInfo] {
        &self.backends
    }

    /// Get backends filtered by category.
    #[must_use]
    pub fn by_category(&self, category: BackendCategory) -> Vec<&BackendInfo> {
        self.backends
            .iter()
            .filter(|b| b.category == category)
            .collect()
    }

    /// Get only available backends.
    #[must_use]
    pub fn available(&self) -> Vec<&BackendInfo> {
        self.backends.iter().filter(|b| b.available).collect()
    }

    /// Get available backends in a specific category.
    #[must_use]
    pub fn available_in_category(&self, category: BackendCategory) -> Vec<&BackendInfo> {
        self.backends
            .iter()
            .filter(|b| b.category == category && b.available)
            .collect()
    }

    /// Check if any GPU backend is available.
    #[must_use]
    pub fn has_gpu(&self) -> bool {
        self.backends
            .iter()
            .any(|b| b.category == BackendCategory::Gpu && b.available)
    }

    /// Get the best available CPU backend.
    #[must_use]
    pub fn best_cpu(&self) -> Option<&BackendInfo> {
        // Prefer SIMD over scalar
        let cpu_backends = self.available_in_category(BackendCategory::Cpu);
        cpu_backends
            .iter()
            .find(|b| b.name.contains("avx2") || b.name.contains("neon"))
            .copied()
            .or_else(|| cpu_backends.first().copied())
    }
}

impl Default for BackendRegistry {
    fn default() -> Self {
        Self::new()
    }
}

/// Global cached backend registry.
static CACHED_REGISTRY: OnceLock<BackendRegistry> = OnceLock::new();

/// Get the cached backend registry.
///
/// This performs backend detection on first call and caches the result.
#[must_use]
pub fn backend_registry() -> &'static BackendRegistry {
    CACHED_REGISTRY.get_or_init(BackendRegistry::new)
}

#[cfg(test)]
mod tests {
    use super::*;
    use uor::microcode::MicrocodeOps;

    #[test]
    fn test_scalar_target_primitives() {
        let target = ScalarTarget::new();

        // Test primitives
        assert_eq!(target.bnot(0u32), u32::MAX);
        assert_eq!(target.bnot(u32::MAX), 0);
        assert_eq!(target.neg(0u32), 0);
        assert_eq!(target.neg(1u32), u32::MAX);
        assert_eq!(target.xor(0xFFFF_0000u32, 0x0000_FFFF), 0xFFFF_FFFF);
        assert_eq!(target.and(0xFFFF_0000u32, 0xFF00_FF00), 0xFF00_0000);
        assert_eq!(target.or(0xFF00_0000u32, 0x00FF_0000), 0xFFFF_0000);
    }

    #[test]
    fn test_scalar_target_derived_ops() {
        let target = ScalarTarget::new();

        // Test derived operations via MicrocodeOps
        assert_eq!(target.inc(41u32), 42);
        assert_eq!(target.dec(42u32), 41);
        assert_eq!(target.add(10u32, 20), 30);
        assert_eq!(target.sub(30u32, 10), 20);
    }

    #[test]
    fn test_scalar_target_capabilities() {
        let target = ScalarTarget::new();
        let caps = target.capabilities();

        assert_eq!(caps.vector_bits, 32);
        assert_eq!(caps.vector_lanes, 1);
        assert!(!caps.is_simd);
        assert!(caps.has_native_add);
        assert!(caps.has_native_mul);
    }

    #[test]
    fn test_simd128_target_primitives() {
        let target = Simd128Target::new();

        let a: [u32; 4] = [1, 2, 3, 4];
        let b: [u32; 4] = [5, 6, 7, 8];

        // Test primitives
        let xor_result = target.xor(a, b);
        assert_eq!(xor_result, [1 ^ 5, 2 ^ 6, 3 ^ 7, 4 ^ 8]);

        let and_result = target.and(a, b);
        assert_eq!(and_result, [1 & 5, 2 & 6, 3 & 7, 4 & 8]);

        let or_result = target.or(a, b);
        assert_eq!(or_result, [1 | 5, 2 | 6, 3 | 7, 4 | 8]);
    }

    #[test]
    fn test_simd128_target_derived_ops() {
        let target = Simd128Target::new();

        let a: [u32; 4] = [10, 20, 30, 40];
        let b: [u32; 4] = [1, 2, 3, 4];

        // Test derived operations
        let sum = target.add(a, b);
        assert_eq!(sum, [11, 22, 33, 44]);

        let diff = target.sub(a, b);
        assert_eq!(diff, [9, 18, 27, 36]);
    }

    #[test]
    fn test_simd128_target_capabilities() {
        let target = Simd128Target::new();
        let caps = target.capabilities();

        assert_eq!(caps.vector_bits, 128);
        assert_eq!(caps.vector_lanes, 4);
        assert!(caps.is_simd);
    }

    #[test]
    fn test_simd256_target_primitives() {
        let target = Simd256Target::new();

        let a: [u32; 8] = [1, 2, 3, 4, 5, 6, 7, 8];
        let b: [u32; 8] = [8, 7, 6, 5, 4, 3, 2, 1];

        let xor_result = target.xor(a, b);
        assert_eq!(
            xor_result,
            [1 ^ 8, 2 ^ 7, 3 ^ 6, 4 ^ 5, 5 ^ 4, 6 ^ 3, 7 ^ 2, 8 ^ 1]
        );
    }

    #[test]
    fn test_simd256_target_capabilities() {
        let target = Simd256Target::new();
        let caps = target.capabilities();

        assert_eq!(caps.vector_bits, 256);
        assert_eq!(caps.vector_lanes, 8);
        assert!(caps.is_simd);
    }

    #[test]
    fn test_target_capabilities_has_override() {
        let scalar = TargetCapabilities::scalar();
        assert!(scalar.has_override(NativeOverride::Add));
        assert!(scalar.has_override(NativeOverride::Mul));
        assert!(!scalar.has_override(NativeOverride::Sha256Round));

        let full = TargetCapabilities::x86_64_full();
        assert!(full.has_override(NativeOverride::Add));
        assert!(full.has_override(NativeOverride::Sha256Round));
        assert!(full.has_override(NativeOverride::AesRound));
    }

    #[test]
    fn test_auto_select_target() {
        let target = auto_select_target();

        // Should return a valid target
        assert!(!target.name().is_empty());

        // Capabilities should be consistent
        let caps = target.capabilities();
        assert!(caps.vector_bits >= 32);
        assert!(caps.vector_lanes >= 1);
    }

    #[test]
    fn test_selected_target_accessors() {
        let target = SelectedTarget::Scalar(ScalarTarget::new());
        assert!(target.as_scalar().is_some());
        assert!(target.as_simd128().is_none());
        assert!(target.as_simd256().is_none());
        assert!(!target.is_simd());

        let target = SelectedTarget::Simd128(Simd128Target::new());
        assert!(target.as_scalar().is_none());
        assert!(target.as_simd128().is_some());
        assert!(target.as_simd256().is_none());
        assert!(target.is_simd());

        let target = SelectedTarget::Simd256(Simd256Target::new());
        assert!(target.as_scalar().is_none());
        assert!(target.as_simd128().is_none());
        assert!(target.as_simd256().is_some());
        assert!(target.is_simd());
    }

    #[test]
    fn test_algebraic_identities_scalar() {
        let target = ScalarTarget::new();

        // neg(bnot(x)) = x + 1
        for x in [0u32, 1, 42, u32::MAX - 1] {
            let inc = target.neg(target.bnot(x));
            assert_eq!(inc, x.wrapping_add(1));
        }

        // bnot(neg(x)) = x - 1
        for x in [1u32, 2, 42, u32::MAX] {
            let dec = target.bnot(target.neg(x));
            assert_eq!(dec, x.wrapping_sub(1));
        }
    }

    #[test]
    fn test_algebraic_identities_simd128() {
        let target = Simd128Target::new();

        let x: [u32; 4] = [0, 1, 42, u32::MAX - 1];

        // neg(bnot(x)) = x + 1
        let inc = target.neg(target.bnot(x));
        assert_eq!(
            inc,
            [
                0u32.wrapping_add(1),
                1u32.wrapping_add(1),
                42u32.wrapping_add(1),
                (u32::MAX - 1).wrapping_add(1)
            ]
        );

        // Involutions
        assert_eq!(target.neg(target.neg(x)), x);
        assert_eq!(target.bnot(target.bnot(x)), x);
    }

    #[test]
    fn test_cached_target() {
        // First call - initializes cache
        let target1 = cached_target();
        assert!(!target1.name().is_empty());

        // Second call - returns cached value
        let target2 = cached_target();
        assert_eq!(target1.name(), target2.name());

        // Both should point to the same static location
        assert!(std::ptr::eq(target1, target2));
    }

    #[test]
    fn test_cached_target_consistency() {
        let cached = cached_target();
        let fresh = auto_select_target();

        // Cached version should match fresh selection
        assert_eq!(cached.name(), fresh.name());
        assert_eq!(cached.capabilities(), fresh.capabilities());
        assert_eq!(cached.is_simd(), fresh.is_simd());
    }

    #[test]
    fn test_backend_category() {
        assert!(BackendCategory::Cpu.uses_microcode());
        assert!(BackendCategory::Wasm.uses_microcode());
        assert!(!BackendCategory::Gpu.uses_microcode());

        assert_eq!(BackendCategory::Cpu.name(), "cpu");
        assert_eq!(BackendCategory::Wasm.name(), "wasm");
        assert_eq!(BackendCategory::Gpu.name(), "gpu");
    }

    #[test]
    fn test_gpu_capabilities() {
        let webgpu = TargetCapabilities::webgpu();
        assert!(webgpu.is_gpu());
        assert!(!webgpu.uses_microcode());
        assert_eq!(webgpu.category, BackendCategory::Gpu);
        assert_eq!(webgpu.gpu_max_workgroup_size, 256);

        let cuda = TargetCapabilities::cuda();
        assert!(cuda.is_gpu());
        assert_eq!(cuda.gpu_max_workgroup_size, 1024);

        let metal = TargetCapabilities::metal();
        assert!(metal.is_gpu());
        assert_eq!(metal.gpu_max_workgroup_size, 1024);
    }

    #[test]
    fn test_cpu_capabilities_category() {
        let scalar = TargetCapabilities::scalar();
        assert_eq!(scalar.category, BackendCategory::Cpu);
        assert!(!scalar.is_gpu());
        assert!(scalar.uses_microcode());

        let avx2 = TargetCapabilities::x86_64_avx2();
        assert_eq!(avx2.category, BackendCategory::Cpu);

        let neon = TargetCapabilities::aarch64_neon();
        assert_eq!(neon.category, BackendCategory::Cpu);
    }

    #[test]
    fn test_wasm_capabilities_category() {
        let wasm = TargetCapabilities::wasm_simd128();
        assert_eq!(wasm.category, BackendCategory::Wasm);
        assert!(!wasm.is_gpu());
        assert!(wasm.uses_microcode());
    }

    // =========================================================================
    // BackendRegistry Tests
    // =========================================================================

    #[test]
    fn test_backend_registry_creation() {
        let registry = BackendRegistry::new();
        assert!(!registry.all().is_empty());
    }

    #[test]
    fn test_backend_registry_has_cpu() {
        let registry = BackendRegistry::new();
        let cpu_backends = registry.by_category(BackendCategory::Cpu);
        assert!(
            !cpu_backends.is_empty(),
            "Should have at least one CPU backend"
        );

        // Scalar is always available
        let available = registry.available_in_category(BackendCategory::Cpu);
        assert!(
            !available.is_empty(),
            "Scalar CPU backend should always be available"
        );
    }

    #[test]
    fn test_backend_registry_has_gpu() {
        let registry = BackendRegistry::new();
        let gpu_backends = registry.by_category(BackendCategory::Gpu);

        // Should have GPU backend entries (even if not available)
        assert!(!gpu_backends.is_empty(), "Should have GPU backend entries");

        // Check that CUDA, Metal, WebGPU are registered
        let names: Vec<_> = gpu_backends.iter().map(|b| b.name).collect();
        assert!(names.contains(&"cuda"));
        assert!(names.contains(&"metal"));
        assert!(names.contains(&"webgpu"));
    }

    #[test]
    fn test_backend_registry_available() {
        let registry = BackendRegistry::new();
        let available = registry.available();

        // At least scalar should be available
        assert!(!available.is_empty());
        assert!(available.iter().any(|b| b.name == "cpu-scalar"));
    }

    #[test]
    fn test_backend_registry_best_cpu() {
        let registry = BackendRegistry::new();
        let best = registry.best_cpu();

        assert!(best.is_some(), "Should have a best CPU backend");
        let best = best.unwrap();
        assert_eq!(best.category, BackendCategory::Cpu);
        assert!(best.available);
    }

    #[test]
    fn test_backend_registry_gpu_skeletons_unavailable() {
        let registry = BackendRegistry::new();

        // GPU skeletons should report as unavailable
        assert!(!registry.has_gpu(), "GPU skeletons should not be available");

        let gpu_available = registry.available_in_category(BackendCategory::Gpu);
        assert!(
            gpu_available.is_empty(),
            "No GPU backends should be available (skeletons)"
        );
    }

    #[test]
    fn test_backend_registry_caching() {
        let registry1 = backend_registry();
        let registry2 = backend_registry();

        // Should be the same static reference
        assert!(std::ptr::eq(registry1, registry2));
    }

    #[test]
    fn test_backend_info_fields() {
        let registry = BackendRegistry::new();

        for backend in registry.all() {
            // All backends should have non-empty name and description
            assert!(!backend.name.is_empty());
            assert!(!backend.description.is_empty());
        }
    }
}
