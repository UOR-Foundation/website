//! End-to-end SHA-256 pipeline integration tests.
//!
//! Validates the full compilation pipeline:
//! `OperationGraph -> compile() -> BackendPlan -> execute_plan() -> correct hash`

use hologram_backend::backends::cpu::CpuBackend;
use hologram_backend::Backend;
use hologram_compiler::{compile, CompilerConfig, DType, OpKind, OpNode, OperationGraph};
use hologram_holo::IsaInstruction;

/// Build an 80-byte Bitcoin-style block header for testing.
fn make_test_header() -> [u8; 80] {
    let mut header = [0u8; 80];
    header[0..4].copy_from_slice(&2u32.to_le_bytes());
    for (i, b) in header[4..36].iter_mut().enumerate() {
        *b = (i as u8).wrapping_mul(7);
    }
    for (i, b) in header[36..68].iter_mut().enumerate() {
        *b = (i as u8).wrapping_mul(13).wrapping_add(1);
    }
    header[68..72].copy_from_slice(&1_700_000_000u32.to_le_bytes());
    header[72..76].copy_from_slice(&0x1d00_ffffu32.to_le_bytes());
    header[76..80].copy_from_slice(&42u32.to_le_bytes());
    header
}

/// Build a SHA-256 graph: Input(src_len) -> Sha256 -> Output(32).
fn sha256_graph(src_len: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![src_len], DType::U8));
    graph.sha256(1, 0, src_len);
    graph.add_node(OpNode::new(2, OpKind::Output, vec![32], DType::U8));
    graph.add_edge(1, 2);
    graph.add_input("data", 0);
    graph.add_output("hash", 2);
    graph
}

/// Build a DoubleSha256 graph: Input(src_len) -> DoubleSha256 -> Output(32).
fn double_sha256_graph(src_len: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![src_len], DType::U8));
    graph.double_sha256(1, 0, src_len);
    graph.add_node(OpNode::new(2, OpKind::Output, vec![32], DType::U8));
    graph.add_edge(1, 2);
    graph.add_input("data", 0);
    graph.add_output("hash", 2);
    graph
}

/// Build a chain graph: Input(80) -> Sha256 -> Sha256 -> Output(32).
fn sha256_chain_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![80], DType::U8));
    graph.sha256(1, 0, 80);
    graph.sha256(2, 1, 32);
    graph.add_node(OpNode::new(3, OpKind::Output, vec![32], DType::U8));
    graph.add_edge(2, 3);
    graph.add_input("header", 0);
    graph.add_output("hash", 3);
    graph
}

/// Execute a plan and return the 32-byte output.
fn execute(plan: &hologram_holo::BackendPlan, input: &[u8]) -> Vec<u8> {
    let backend = CpuBackend::new();
    let mut output = vec![0u8; 32];
    backend
        .execute_plan(plan, &[input], &mut [&mut output[..]])
        .expect("execution failed");
    output
}

// ---------------------------------------------------------------------------
// End-to-end tests
// ---------------------------------------------------------------------------

#[test]
fn e2e_sha256_80byte_header() {
    let graph = sha256_graph(80);
    let plan = compile(&graph, &CompilerConfig::default()).expect("compilation failed");

    assert!(plan
        .instructions
        .iter()
        .any(|i| matches!(i, IsaInstruction::Sha256 { src_len: 80, .. })));

    let header = make_test_header();
    let output = execute(&plan, &header);
    let expected = hologram_sha256::sha256(&header);
    assert_eq!(output, expected.as_ref(), "SHA-256 hash mismatch");
}

#[test]
fn e2e_double_sha256_80byte_header() {
    let graph = double_sha256_graph(80);
    let plan = compile(&graph, &CompilerConfig::default()).expect("compilation failed");

    assert!(plan
        .instructions
        .iter()
        .any(|i| matches!(i, IsaInstruction::DoubleSha256 { src_len: 80, .. })));

    let header = make_test_header();
    let output = execute(&plan, &header);
    let expected = hologram_sha256::double_sha256(&header);
    assert_eq!(output, expected.as_ref(), "DoubleSha256 hash mismatch");
}

#[test]
fn e2e_hash_chain_fuses_to_double() {
    let graph = sha256_chain_graph();
    let plan = compile(&graph, &CompilerConfig::default()).expect("compilation failed");

    // Fusion: two Sha256 -> one DoubleSha256
    assert!(
        plan.instructions
            .iter()
            .any(|i| matches!(i, IsaInstruction::DoubleSha256 { src_len: 80, .. })),
        "chain should fuse into DoubleSha256"
    );
    assert!(
        !plan
            .instructions
            .iter()
            .any(|i| matches!(i, IsaInstruction::Sha256 { .. })),
        "no standalone Sha256 after fusion"
    );

    // Correctness: fused result matches reference
    let header = make_test_header();
    let output = execute(&plan, &header);
    let expected = hologram_sha256::double_sha256(&header);
    assert_eq!(output, expected.as_ref(), "fused chain hash mismatch");
}

#[test]
fn e2e_sha256_output_is_32_bytes() {
    for src_len in [32, 64, 80, 128, 256] {
        let graph = sha256_graph(src_len);
        let plan = compile(&graph, &CompilerConfig::default())
            .unwrap_or_else(|e| panic!("compilation failed for {src_len}B: {e}"));

        let data: Vec<u8> = (0..src_len).map(|i| (i & 0xFF) as u8).collect();
        let output = execute(&plan, &data);

        assert_eq!(output.len(), 32, "output must be exactly 32 bytes");

        let expected = hologram_sha256::sha256(&data);
        assert_eq!(
            output,
            expected.as_ref(),
            "SHA-256 mismatch for {src_len}B input"
        );
    }
}

#[test]
fn e2e_deterministic_output() {
    let graph = sha256_graph(80);
    let plan = compile(&graph, &CompilerConfig::default()).expect("compilation failed");
    let header = make_test_header();

    let out1 = execute(&plan, &header);
    let out2 = execute(&plan, &header);
    assert_eq!(out1, out2, "SHA-256 must be deterministic");
}
