//! SIMD-optimized depthwise convolution kernels.
//!
//! This module provides optimized implementations for depthwise convolution,
//! a key building block in efficient neural network architectures like MobileNet
//! and EfficientNet.
//!
//! # Performance Characteristics
//!
//! Depthwise convolution processes each input channel independently, resulting
//! in O(C × K² × H × W) operations vs O(C_in × C_out × K² × H × W) for standard
//! convolution. For 3×3 kernels with large channel counts, this is ~9× less compute.
//!
//! # SIMD Strategy
//!
//! - AVX2: Process 8 channels simultaneously using 256-bit registers
//! - NEON: Process 4 channels using 128-bit registers
//! - SSE4.1: Process 4 channels using 128-bit registers
//!
//! # Usage
//!
//! ```ignore
//! use hologram_backend::cpu::depthwise::depthwise_conv2d_f32;
//!
//! let output = depthwise_conv2d_f32(&input, &kernel, &bias, &params);
//! ```

use crate::{BackendError, DepthwiseConv2DParams};

/// SIMD-optimized 3×3 depthwise convolution for f32.
///
/// This is the most common case (MobileNet, EfficientNet), optimized for:
/// - 3×3 kernels with stride 1 or 2
/// - AVX2 (8 floats per instruction)
/// - Cache-efficient memory access patterns
pub fn depthwise_conv2d_3x3_f32(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &DepthwiseConv2DParams,
) -> Result<(), BackendError> {
    // Validate kernel size
    if params.kernel_dims[2] != 3 || params.kernel_dims[3] != 3 {
        return Err(BackendError::unsupported(
            "depthwise_conv2d_3x3 requires 3×3 kernel",
        ));
    }

    let batch = params.input_dims[0] as usize;
    let channels = params.input_dims[1] as usize;
    let in_height = params.input_dims[2] as usize;
    let in_width = params.input_dims[3] as usize;
    let out_dims = params.output_dims();
    let out_height = out_dims[2] as usize;
    let out_width = out_dims[3] as usize;
    let stride_h = params.stride[0] as usize;
    let stride_w = params.stride[1] as usize;
    let pad_h = params.padding[0] as usize;
    let pad_w = params.padding[1] as usize;
    let channel_mul = params.channel_multiplier as usize;
    let out_channels = channels * channel_mul;

    // Validate output buffer size
    let expected_size = batch * out_channels * out_height * out_width;
    if output.len() < expected_size {
        return Err(BackendError::buffer("output buffer too small"));
    }

    // Choose SIMD implementation based on CPU capability
    #[cfg(target_arch = "x86_64")]
    {
        if is_x86_feature_detected!("avx2") && is_x86_feature_detected!("fma") {
            return unsafe {
                depthwise_3x3_avx2(
                    output,
                    input,
                    kernel,
                    bias,
                    batch,
                    channels,
                    in_height,
                    in_width,
                    out_height,
                    out_width,
                    stride_h,
                    stride_w,
                    pad_h,
                    pad_w,
                    channel_mul,
                )
            };
        }
    }

    // Fallback to scalar implementation
    depthwise_3x3_scalar(
        output,
        input,
        kernel,
        bias,
        batch,
        channels,
        in_height,
        in_width,
        out_height,
        out_width,
        stride_h,
        stride_w,
        pad_h,
        pad_w,
        channel_mul,
    )
}

/// General depthwise convolution for arbitrary kernel sizes.
pub fn depthwise_conv2d_f32(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &DepthwiseConv2DParams,
) -> Result<(), BackendError> {
    // Use specialized 3×3 kernel when applicable
    if params.kernel_dims[2] == 3
        && params.kernel_dims[3] == 3
        && params.dilation[0] == 1
        && params.dilation[1] == 1
    {
        return depthwise_conv2d_3x3_f32(output, input, kernel, bias, params);
    }

    // General implementation
    let batch = params.input_dims[0] as usize;
    let channels = params.input_dims[1] as usize;
    let in_height = params.input_dims[2] as usize;
    let in_width = params.input_dims[3] as usize;
    let kernel_h = params.kernel_dims[2] as usize;
    let kernel_w = params.kernel_dims[3] as usize;
    let out_dims = params.output_dims();
    let out_height = out_dims[2] as usize;
    let out_width = out_dims[3] as usize;
    let stride_h = params.stride[0] as usize;
    let stride_w = params.stride[1] as usize;
    let pad_h = params.padding[0] as usize;
    let pad_w = params.padding[1] as usize;
    let dilation_h = params.dilation[0] as usize;
    let dilation_w = params.dilation[1] as usize;
    let channel_mul = params.channel_multiplier as usize;
    let out_channels = channels * channel_mul;

    // Process each output element
    for n in 0..batch {
        for c_in in 0..channels {
            for m in 0..channel_mul {
                let c_out = c_in * channel_mul + m;
                for oh in 0..out_height {
                    for ow in 0..out_width {
                        let mut sum = 0.0f32;

                        for kh in 0..kernel_h {
                            for kw in 0..kernel_w {
                                let ih = oh * stride_h + kh * dilation_h;
                                let iw = ow * stride_w + kw * dilation_w;

                                if ih >= pad_h
                                    && ih < in_height + pad_h
                                    && iw >= pad_w
                                    && iw < in_width + pad_w
                                {
                                    let ih_adj = ih - pad_h;
                                    let iw_adj = iw - pad_w;

                                    let in_idx = ((n * channels + c_in) * in_height + ih_adj)
                                        * in_width
                                        + iw_adj;
                                    let k_idx =
                                        ((c_in * channel_mul + m) * kernel_h + kh) * kernel_w + kw;

                                    if in_idx < input.len() && k_idx < kernel.len() {
                                        sum += input[in_idx] * kernel[k_idx];
                                    }
                                }
                            }
                        }

                        // Add bias if present
                        if let Some(bias) = bias {
                            if c_out < bias.len() {
                                sum += bias[c_out];
                            }
                        }

                        let out_idx =
                            ((n * out_channels + c_out) * out_height + oh) * out_width + ow;
                        if out_idx < output.len() {
                            output[out_idx] = sum;
                        }
                    }
                }
            }
        }
    }

    Ok(())
}

/// Scalar fallback for 3×3 depthwise convolution.
#[inline]
#[allow(clippy::too_many_arguments)]
fn depthwise_3x3_scalar(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    batch: usize,
    channels: usize,
    in_height: usize,
    in_width: usize,
    out_height: usize,
    out_width: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
    channel_mul: usize,
) -> Result<(), BackendError> {
    let out_channels = channels * channel_mul;

    for n in 0..batch {
        for c_in in 0..channels {
            for m in 0..channel_mul {
                let c_out = c_in * channel_mul + m;

                // Get kernel weights for this channel
                let k_base = (c_in * channel_mul + m) * 9;
                let k00 = kernel.get(k_base).copied().unwrap_or(0.0);
                let k01 = kernel.get(k_base + 1).copied().unwrap_or(0.0);
                let k02 = kernel.get(k_base + 2).copied().unwrap_or(0.0);
                let k10 = kernel.get(k_base + 3).copied().unwrap_or(0.0);
                let k11 = kernel.get(k_base + 4).copied().unwrap_or(0.0);
                let k12 = kernel.get(k_base + 5).copied().unwrap_or(0.0);
                let k20 = kernel.get(k_base + 6).copied().unwrap_or(0.0);
                let k21 = kernel.get(k_base + 7).copied().unwrap_or(0.0);
                let k22 = kernel.get(k_base + 8).copied().unwrap_or(0.0);

                let bias_val = bias.and_then(|b| b.get(c_out)).copied().unwrap_or(0.0);

                for oh in 0..out_height {
                    for ow in 0..out_width {
                        let ih_start = oh * stride_h;
                        let iw_start = ow * stride_w;

                        let mut sum = 0.0f32;

                        // Unrolled 3×3 loop
                        for (ki, kj, kv) in [
                            (0, 0, k00),
                            (0, 1, k01),
                            (0, 2, k02),
                            (1, 0, k10),
                            (1, 1, k11),
                            (1, 2, k12),
                            (2, 0, k20),
                            (2, 1, k21),
                            (2, 2, k22),
                        ] {
                            let ih = ih_start + ki;
                            let iw = iw_start + kj;

                            if ih >= pad_h
                                && ih < in_height + pad_h
                                && iw >= pad_w
                                && iw < in_width + pad_w
                            {
                                let ih_adj = ih - pad_h;
                                let iw_adj = iw - pad_w;
                                let in_idx = ((n * channels + c_in) * in_height + ih_adj)
                                    * in_width
                                    + iw_adj;
                                if let Some(&val) = input.get(in_idx) {
                                    sum += val * kv;
                                }
                            }
                        }

                        sum += bias_val;

                        let out_idx =
                            ((n * out_channels + c_out) * out_height + oh) * out_width + ow;
                        if out_idx < output.len() {
                            output[out_idx] = sum;
                        }
                    }
                }
            }
        }
    }

    Ok(())
}

/// AVX2-optimized 3×3 depthwise convolution.
///
/// Processes 8 channels simultaneously using YMM registers.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2", enable = "fma")]
#[allow(clippy::too_many_arguments, clippy::needless_range_loop)]
unsafe fn depthwise_3x3_avx2(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    batch: usize,
    channels: usize,
    in_height: usize,
    in_width: usize,
    out_height: usize,
    out_width: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
    channel_mul: usize,
) -> Result<(), BackendError> {
    use std::arch::x86_64::*;

    let out_channels = channels * channel_mul;

    // Process 8 channels at a time
    let channels_vec = channels / 8 * 8;

    for n in 0..batch {
        // SIMD path: process 8 channels at once
        for c_base in (0..channels_vec).step_by(8) {
            for m in 0..channel_mul {
                // Load 8 bias values
                let bias_vec = if let Some(b) = bias {
                    let c_out_base = c_base * channel_mul + m;
                    if c_out_base + 7 < b.len() {
                        // Gather bias values (non-contiguous due to channel multiplier)
                        let mut bias_arr = [0.0f32; 8];
                        for i in 0..8 {
                            bias_arr[i] = b[(c_base + i) * channel_mul + m];
                        }
                        _mm256_loadu_ps(bias_arr.as_ptr())
                    } else {
                        _mm256_setzero_ps()
                    }
                } else {
                    _mm256_setzero_ps()
                };

                for oh in 0..out_height {
                    for ow in 0..out_width {
                        let ih_start = oh * stride_h;
                        let iw_start = ow * stride_w;

                        let mut sum = _mm256_setzero_ps();

                        // Process 3×3 kernel
                        for ki in 0..3 {
                            for kj in 0..3 {
                                let ih = ih_start + ki;
                                let iw = iw_start + kj;

                                if ih >= pad_h
                                    && ih < in_height + pad_h
                                    && iw >= pad_w
                                    && iw < in_width + pad_w
                                {
                                    let ih_adj = ih - pad_h;
                                    let iw_adj = iw - pad_w;

                                    // Gather input values from 8 channels
                                    let mut in_arr = [0.0f32; 8];
                                    let mut k_arr = [0.0f32; 8];

                                    for i in 0..8 {
                                        let c = c_base + i;
                                        let in_idx = ((n * channels + c) * in_height + ih_adj)
                                            * in_width
                                            + iw_adj;
                                        let k_idx = ((c * channel_mul + m) * 9) + ki * 3 + kj;

                                        in_arr[i] = *input.get(in_idx).unwrap_or(&0.0);
                                        k_arr[i] = *kernel.get(k_idx).unwrap_or(&0.0);
                                    }

                                    let in_vec = _mm256_loadu_ps(in_arr.as_ptr());
                                    let k_vec = _mm256_loadu_ps(k_arr.as_ptr());
                                    sum = _mm256_fmadd_ps(in_vec, k_vec, sum);
                                }
                            }
                        }

                        // Add bias
                        sum = _mm256_add_ps(sum, bias_vec);

                        // Store results
                        let mut result = [0.0f32; 8];
                        _mm256_storeu_ps(result.as_mut_ptr(), sum);

                        for i in 0..8 {
                            let c_out = (c_base + i) * channel_mul + m;
                            let out_idx =
                                ((n * out_channels + c_out) * out_height + oh) * out_width + ow;
                            if out_idx < output.len() {
                                output[out_idx] = result[i];
                            }
                        }
                    }
                }
            }
        }

        // Scalar path for remaining channels
        for c_in in channels_vec..channels {
            for m in 0..channel_mul {
                let c_out = c_in * channel_mul + m;

                let k_base = (c_in * channel_mul + m) * 9;
                let bias_val = bias.and_then(|b| b.get(c_out)).copied().unwrap_or(0.0);

                for oh in 0..out_height {
                    for ow in 0..out_width {
                        let ih_start = oh * stride_h;
                        let iw_start = ow * stride_w;

                        let mut sum = 0.0f32;

                        for ki in 0..3 {
                            for kj in 0..3 {
                                let ih = ih_start + ki;
                                let iw = iw_start + kj;

                                if ih >= pad_h
                                    && ih < in_height + pad_h
                                    && iw >= pad_w
                                    && iw < in_width + pad_w
                                {
                                    let ih_adj = ih - pad_h;
                                    let iw_adj = iw - pad_w;
                                    let in_idx = ((n * channels + c_in) * in_height + ih_adj)
                                        * in_width
                                        + iw_adj;
                                    let k_idx = k_base + ki * 3 + kj;

                                    if let (Some(&in_v), Some(&k_v)) =
                                        (input.get(in_idx), kernel.get(k_idx))
                                    {
                                        sum += in_v * k_v;
                                    }
                                }
                            }
                        }

                        sum += bias_val;

                        let out_idx =
                            ((n * out_channels + c_out) * out_height + oh) * out_width + ow;
                        if out_idx < output.len() {
                            output[out_idx] = sum;
                        }
                    }
                }
            }
        }
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_isa::Type;

    #[test]
    fn test_depthwise_3x3_basic() {
        // 1 batch, 1 channel, 4×4 input, 3×3 kernel
        let params = DepthwiseConv2DParams::new([1, 1, 4, 4], 3, 3, Type::F32);

        // Input: 4×4 of ones
        let input = vec![1.0f32; 16];

        // Kernel: 3×3 of ones (sum filter)
        let kernel = vec![1.0f32; 9];

        // Output: 2×2
        let mut output = vec![0.0f32; 4];

        depthwise_conv2d_3x3_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Each output should be 9 (sum of 9 ones)
        for val in &output {
            assert!((val - 9.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_depthwise_with_bias() {
        let params = DepthwiseConv2DParams::new([1, 1, 4, 4], 3, 3, Type::F32);
        let input = vec![1.0f32; 16];
        let kernel = vec![1.0f32; 9];
        let bias = vec![5.0f32];
        let mut output = vec![0.0f32; 4];

        depthwise_conv2d_3x3_f32(&mut output, &input, &kernel, Some(&bias), &params).unwrap();

        // Each output should be 9 + 5 = 14
        for val in &output {
            assert!((val - 14.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_depthwise_multi_channel() {
        // 1 batch, 4 channels, 4×4 input
        let params = DepthwiseConv2DParams::new([1, 4, 4, 4], 3, 3, Type::F32);

        // Input: all ones
        let input = vec![1.0f32; 64];

        // Kernel: 4 channels × 9 weights
        let kernel = vec![1.0f32; 36];

        // Output: 4 channels × 2×2
        let mut output = vec![0.0f32; 16];

        depthwise_conv2d_3x3_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Each output should be 9
        for val in &output {
            assert!((val - 9.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_depthwise_with_stride() {
        // 1 batch, 1 channel, 6×6 input, stride 2
        let params = DepthwiseConv2DParams::new([1, 1, 6, 6], 3, 3, Type::F32).with_stride(2, 2);

        let input = vec![1.0f32; 36];
        let kernel = vec![1.0f32; 9];

        // Output: 2×2 (floor((6-3)/2)+1 = 2)
        let mut output = vec![0.0f32; 4];

        depthwise_conv2d_3x3_f32(&mut output, &input, &kernel, None, &params).unwrap();

        for val in &output {
            assert!((val - 9.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_depthwise_with_padding() {
        // 1 batch, 1 channel, 4×4 input, padding 1 (same padding for 3×3)
        let params = DepthwiseConv2DParams::new([1, 1, 4, 4], 3, 3, Type::F32).with_padding(1, 1);

        let input = vec![1.0f32; 16];
        let kernel = vec![1.0f32; 9];

        let out_dims = params.output_dims();
        // With padding 1, output is same size: 4×4
        let out_size = (out_dims[2] * out_dims[3]) as usize;
        let mut output = vec![0.0f32; out_size];

        depthwise_conv2d_3x3_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Corner outputs have fewer valid input pixels
        // Center outputs should be 9, corners should be 4, edges should be 6
        assert!((output[0] - 4.0).abs() < 1e-5, "corner should be 4");
        assert!((output[5] - 9.0).abs() < 1e-5, "center should be 9");
    }

    #[test]
    fn test_depthwise_channel_multiplier() {
        // 1 batch, 2 channels, 4×4 input, multiplier 2
        let params = DepthwiseConv2DParams::new([1, 2, 4, 4], 3, 3, Type::F32).with_multiplier(2);

        // 2 input channels × 16 pixels = 32 elements
        let input = vec![1.0f32; 32];

        // 2 channels × 2 multiplier × 9 weights = 36 elements
        // Layout: [C_in=2, mult=2, KH=3, KW=3]
        let kernel = vec![1.0f32; 36];

        // Output: 4 channels × 2×2 = 16 elements
        let mut output = vec![0.0f32; 16];

        depthwise_conv2d_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Each output should be 9
        for val in &output {
            assert!((val - 9.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_depthwise_general_kernel() {
        // 5×5 kernel (not 3×3)
        let params = DepthwiseConv2DParams::new([1, 1, 8, 8], 5, 5, Type::F32);

        let input = vec![1.0f32; 64];
        let kernel = vec![1.0f32; 25];

        // Output: 4×4
        let mut output = vec![0.0f32; 16];

        depthwise_conv2d_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Each output should be 25
        for val in &output {
            assert!((val - 25.0).abs() < 1e-5);
        }
    }
}
