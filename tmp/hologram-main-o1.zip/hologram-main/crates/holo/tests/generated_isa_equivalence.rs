//! Structural tests: verify generated ISA code from isa.shell has correct
//! variant count, names, field types, method names, and builder support.

use hologram_holo::instruction::IsaInstruction;

/// Verify the generated enum has the same number of variants as hand-written.
#[test]
fn generated_variant_count_matches() {
    let input = include_str!("../../../descriptors/shells/isa.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ops = hologram_shell::emit_isa::resolve_ops(&shell);

    // Count hand-written variants by parsing the generated match block
    // and comparing to the known count.
    //
    // The generated IsaInstruction enum has exactly 66 variants.
    // The generated code must match this exactly.
    assert_eq!(
        ops.len(),
        68,
        "generated op count ({}) doesn't match variant count (68)",
        ops.len()
    );
}

/// Verify every generated variant name matches the hand-written enum.
#[test]
fn generated_variant_names_match() {
    let input = include_str!("../../../descriptors/shells/isa.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ops = hologram_shell::emit_isa::resolve_ops(&shell);
    let generated_names: Vec<&str> = ops.iter().map(|o| o.variant_name.as_str()).collect();

    // Every variant in the hand-written enum must appear in the generated code.
    // We verify by constructing sample instructions and matching variant names.
    let hand_written_names = [
        "Add",
        "Sub",
        "Mul",
        "Div",
        "Pow",
        "ElemMin",
        "ElemMax",
        "Sqrt",
        "Log",
        "Exp",
        "Abs",
        "Greater",
        "Less",
        "LessOrEqual",
        "GreaterOrEqual",
        "Where",
        "Sigmoid",
        "Tanh",
        "Relu",
        "SigmoidLUT",
        "TanhLUT",
        "ExpLUT",
        "LogLUT",
        "ReluLUT",
        "SqrtLUT",
        "AbsLUT",
        "GeluLUT",
        "SiluLUT",
        "Softmax",
        "MatMul",
        "BatchMatMul",
        "MatMulLUT",
        "Sum",
        "Max",
        "Min",
        "ReduceMean",
        "Lift",
        "OrbitClassify",
        "RingAdd",
        "RingMul",
        "Load",
        "Store",
        "Copy",
        "CallLayer",
        "Encode",
        "Decode",
        "Reshape",
        "Unsqueeze",
        "Squeeze",
        "Transpose",
        "Gather",
        "Concat",
        "Slice",
        "Pad",
        "Cast",
        "Tile",
        "Expand",
        "Conv2d",
        "BatchNorm",
        "LayerNorm",
        "MaxPool2d",
        "AvgPool2d",
        "GlobalAvgPool",
        "Sha256",
        "DoubleSha256",
        "ViterbiTokenize",
        "MatMulRelu",
        "AddSigmoid",
    ];

    for name in &hand_written_names {
        assert!(
            generated_names.contains(name),
            "hand-written variant '{name}' missing from generated code"
        );
    }

    for name in &generated_names {
        assert!(
            hand_written_names.contains(name),
            "generated variant '{name}' not in hand-written code"
        );
    }
}

/// Verify the generated enum code contains correct field types.
#[test]
fn generated_field_types_correct() {
    let input = include_str!("../../../descriptors/shells/isa.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ops = hologram_shell::emit_isa::resolve_ops(&shell);

    // Find Conv2d and verify its field structure
    let conv2d = ops.iter().find(|o| o.variant_name == "Conv2d").unwrap();
    assert_eq!(conv2d.params.len(), 20, "Conv2d should have 20 fields");

    // Verify specific field types
    let bias = conv2d.params.iter().find(|p| p.name == "bias").unwrap();
    assert_eq!(bias.ty, hologram_shell::ast::FieldType::OptBuf);

    let kernel_h = conv2d.params.iter().find(|p| p.name == "kernel_h").unwrap();
    assert_eq!(kernel_h.ty, hologram_shell::ast::FieldType::Usize);

    // Find Transpose and verify array fields
    let transpose = ops.iter().find(|o| o.variant_name == "Transpose").unwrap();
    let shape = transpose.params.iter().find(|p| p.name == "shape").unwrap();
    assert_eq!(
        shape.ty,
        hologram_shell::ast::FieldType::Array(Box::new(hologram_shell::ast::FieldType::Usize), 8)
    );
    let perm = transpose.params.iter().find(|p| p.name == "perm").unwrap();
    assert_eq!(
        perm.ty,
        hologram_shell::ast::FieldType::Array(Box::new(hologram_shell::ast::FieldType::U8), 8)
    );

    // Find CallLayer and verify Vec fields
    let call_layer = ops.iter().find(|o| o.variant_name == "CallLayer").unwrap();
    let inputs = call_layer
        .params
        .iter()
        .find(|p| p.name == "inputs")
        .unwrap();
    assert_eq!(
        inputs.ty,
        hologram_shell::ast::FieldType::Vec(Box::new(hologram_shell::ast::FieldType::Buf))
    );
}

/// Verify generated method names match the hand-written dispatcher trait.
#[test]
fn generated_method_names_match() {
    let input = include_str!("../../../descriptors/shells/isa.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ops = hologram_shell::emit_isa::resolve_ops(&shell);
    let generated_methods: Vec<&str> = ops.iter().map(|o| o.method_name.as_str()).collect();

    // Spot-check key method names
    let expected_methods = [
        "exec_add",
        "exec_matmul",
        "exec_conv2d",
        "exec_sigmoid_lut",
        "exec_softmax",
        "exec_transpose",
        "exec_call_layer",
        "exec_batch_norm",
        "exec_viterbi_tokenize",
        "exec_elem_min",
        "exec_elem_max",
    ];

    for method in &expected_methods {
        assert!(
            generated_methods.contains(method),
            "expected method '{method}' missing from generated code"
        );
    }
}

/// Verify builder generation for @builder-annotated ops.
#[test]
fn generated_builders_present() {
    let input = include_str!("../../../descriptors/shells/isa.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let builder_code = hologram_shell::emit_isa::emit_builder_structs(&shell).to_string();

    // All @builder ops should have builders
    assert!(builder_code.contains("Conv2dBuilder"));
    assert!(builder_code.contains("BatchNormBuilder"));
    assert!(builder_code.contains("MaxPool2dBuilder"));
    assert!(builder_code.contains("AvgPool2dBuilder"));

    // Factory methods should exist
    assert!(builder_code.contains("fn conv2d"));
    assert!(builder_code.contains("fn batch_norm"));
    assert!(builder_code.contains("fn max_pool2d"));
    assert!(builder_code.contains("fn avg_pool2d"));
}

/// Verify a hand-written instruction can be constructed with expected field count.
///
/// This ensures the hand-written enum hasn't changed without updating isa.shell.
#[test]
fn hand_written_sample_instructions() {
    // Construct sample instructions to verify field structure
    let add = IsaInstruction::Add {
        dst: 0,
        a: 1,
        b: 2,
        count: 100,
    };
    assert!(format!("{add:?}").contains("Add"));

    let matmul = IsaInstruction::MatMul {
        c: 0,
        a: 1,
        b: 2,
        m: 4,
        k: 8,
        n: 16,
    };
    assert!(format!("{matmul:?}").contains("MatMul"));

    let conv = IsaInstruction::Conv2d {
        dst: 0,
        input: 1,
        weight: 2,
        bias: Some(3),
        kernel_h: 3,
        kernel_w: 3,
        stride_h: 1,
        stride_w: 1,
        pad_h: 1,
        pad_w: 1,
        dilation_h: 1,
        dilation_w: 1,
        groups: 1,
        batch: 1,
        in_channels: 3,
        out_channels: 64,
        in_h: 28,
        in_w: 28,
        out_h: 28,
        out_w: 28,
    };
    assert!(format!("{conv:?}").contains("Conv2d"));

    let transpose = IsaInstruction::Transpose {
        dst: 0,
        src: 1,
        count: 100,
        ndim: 2,
        shape: [10, 10, 0, 0, 0, 0, 0, 0],
        perm: [1, 0, 2, 3, 4, 5, 6, 7],
    };
    assert!(format!("{transpose:?}").contains("Transpose"));

    let call_layer = IsaInstruction::CallLayer {
        layer_id: 42,
        inputs: vec![0, 1],
        outputs: vec![2],
    };
    assert!(format!("{call_layer:?}").contains("CallLayer"));
}
