//! Worker authentication tokens.

use crate::error::{OrchestrateError, Result};
use crate::types::WorkerHandle;
use base64::Engine;
use serde::{Deserialize, Serialize};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

/// Serde helper for 32-byte arrays.
mod bytes_32 {
    use serde::{Deserialize, Deserializer, Serializer};

    pub fn serialize<S>(bytes: &[u8; 32], serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let encoded = base64::Engine::encode(&base64::engine::general_purpose::STANDARD, bytes);
        serializer.serialize_str(&encoded)
    }

    pub fn deserialize<'de, D>(deserializer: D) -> std::result::Result<[u8; 32], D::Error>
    where
        D: Deserializer<'de>,
    {
        let s = String::deserialize(deserializer)?;
        let bytes = base64::Engine::decode(&base64::engine::general_purpose::STANDARD, &s)
            .map_err(serde::de::Error::custom)?;
        bytes
            .try_into()
            .map_err(|_| serde::de::Error::custom("invalid length for 32-byte array"))
    }
}

/// Serde helper for 64-byte arrays.
mod bytes_64 {
    use serde::{Deserialize, Deserializer, Serializer};

    pub fn serialize<S>(bytes: &[u8; 64], serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let encoded = base64::Engine::encode(&base64::engine::general_purpose::STANDARD, bytes);
        serializer.serialize_str(&encoded)
    }

    pub fn deserialize<'de, D>(deserializer: D) -> std::result::Result<[u8; 64], D::Error>
    where
        D: Deserializer<'de>,
    {
        let s = String::deserialize(deserializer)?;
        let bytes = base64::Engine::decode(&base64::engine::general_purpose::STANDARD, &s)
            .map_err(serde::de::Error::custom)?;
        bytes
            .try_into()
            .map_err(|_| serde::de::Error::custom("invalid length for 64-byte array"))
    }
}

/// Authentication token for a worker.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkerToken {
    /// Worker handle this token authorizes.
    pub worker_handle: WorkerHandle,
    /// Cluster ID (BLAKE3 hash of cluster public key).
    #[serde(with = "bytes_32")]
    pub cluster_id: [u8; 32],
    /// Token expiration timestamp (Unix epoch seconds).
    pub expires_at: u64,
    /// Ed25519 signature over (worker_handle, cluster_id, expires_at).
    #[serde(with = "bytes_64")]
    pub signature: [u8; 64],
}

impl WorkerToken {
    /// Create and sign a new worker token.
    pub fn create<F>(
        worker_handle: WorkerHandle,
        cluster_id: [u8; 32],
        validity: Duration,
        sign_fn: F,
    ) -> Self
    where
        F: FnOnce(&[u8]) -> [u8; 64],
    {
        let expires_at = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or(Duration::ZERO)
            .as_secs()
            + validity.as_secs();

        let message = Self::create_message(worker_handle, &cluster_id, expires_at);
        let signature = sign_fn(&message);

        Self {
            worker_handle,
            cluster_id,
            expires_at,
            signature,
        }
    }

    fn create_message(
        worker_handle: WorkerHandle,
        cluster_id: &[u8; 32],
        expires_at: u64,
    ) -> Vec<u8> {
        let mut message = Vec::with_capacity(8 + 32 + 8);
        message.extend_from_slice(&worker_handle.0.to_le_bytes());
        message.extend_from_slice(cluster_id);
        message.extend_from_slice(&expires_at.to_le_bytes());
        message
    }

    fn message(&self) -> Vec<u8> {
        Self::create_message(self.worker_handle, &self.cluster_id, self.expires_at)
    }

    /// Check if the token has expired.
    #[must_use]
    pub fn is_expired(&self) -> bool {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or(Duration::ZERO)
            .as_secs();
        now >= self.expires_at
    }

    /// Get time remaining until expiration.
    #[must_use]
    pub fn time_remaining(&self) -> Option<Duration> {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or(Duration::ZERO)
            .as_secs();

        if now >= self.expires_at {
            None
        } else {
            Some(Duration::from_secs(self.expires_at - now))
        }
    }

    /// Verify the token signature.
    #[must_use]
    pub fn verify<F>(&self, verify_fn: F) -> bool
    where
        F: FnOnce(&[u8], &[u8; 64]) -> bool,
    {
        let message = self.message();
        verify_fn(&message, &self.signature)
    }

    /// Verify the token signature and check expiration.
    #[must_use]
    pub fn verify_full<F>(&self, expected_cluster_id: &[u8; 32], verify_fn: F) -> TokenVerifyResult
    where
        F: FnOnce(&[u8], &[u8; 64]) -> bool,
    {
        if self.cluster_id != *expected_cluster_id {
            return TokenVerifyResult::ClusterMismatch;
        }

        if self.is_expired() {
            return TokenVerifyResult::Expired;
        }

        if !self.verify(verify_fn) {
            return TokenVerifyResult::InvalidSignature;
        }

        TokenVerifyResult::Valid
    }

    /// Encode the token as base64 for transmission.
    #[must_use]
    pub fn encode(&self) -> String {
        let bytes = self.to_bytes();
        base64::engine::general_purpose::URL_SAFE_NO_PAD.encode(bytes)
    }

    /// Decode a token from base64.
    pub fn decode(encoded: &str) -> Result<Self> {
        let bytes = base64::engine::general_purpose::URL_SAFE_NO_PAD
            .decode(encoded)
            .map_err(|e| OrchestrateError::security(format!("invalid token encoding: {e}")))?;

        Self::from_bytes(&bytes)
    }

    /// Serialize token to bytes.
    #[must_use]
    pub fn to_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::with_capacity(8 + 32 + 8 + 64);
        bytes.extend_from_slice(&self.worker_handle.0.to_le_bytes());
        bytes.extend_from_slice(&self.cluster_id);
        bytes.extend_from_slice(&self.expires_at.to_le_bytes());
        bytes.extend_from_slice(&self.signature);
        bytes
    }

    /// Deserialize token from bytes.
    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        const EXPECTED_LEN: usize = 8 + 32 + 8 + 64;
        if bytes.len() != EXPECTED_LEN {
            return Err(OrchestrateError::security(format!(
                "invalid token length: expected {EXPECTED_LEN}, got {}",
                bytes.len()
            )));
        }

        let worker_handle = WorkerHandle(u64::from_le_bytes(bytes[0..8].try_into().unwrap()));
        let cluster_id: [u8; 32] = bytes[8..40].try_into().unwrap();
        let expires_at = u64::from_le_bytes(bytes[40..48].try_into().unwrap());
        let signature: [u8; 64] = bytes[48..112].try_into().unwrap();

        Ok(Self {
            worker_handle,
            cluster_id,
            expires_at,
            signature,
        })
    }

    /// Get the cluster ID as a hex string.
    #[must_use]
    pub fn cluster_id_hex(&self) -> String {
        let mut result = String::with_capacity(64);
        for byte in self.cluster_id {
            use std::fmt::Write;
            write!(result, "{byte:02x}").unwrap();
        }
        result
    }
}

/// Result of token verification.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TokenVerifyResult {
    /// Token is valid.
    Valid,
    /// Token has expired.
    Expired,
    /// Token signature is invalid.
    InvalidSignature,
    /// Token cluster ID doesn't match.
    ClusterMismatch,
}

impl TokenVerifyResult {
    /// Check if the result is valid.
    #[must_use]
    pub const fn is_valid(&self) -> bool {
        matches!(self, Self::Valid)
    }

    /// Get a human-readable description.
    #[must_use]
    pub const fn description(&self) -> &'static str {
        match self {
            Self::Valid => "token is valid",
            Self::Expired => "token has expired",
            Self::InvalidSignature => "token signature is invalid",
            Self::ClusterMismatch => "token cluster ID does not match",
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn mock_cluster_id() -> [u8; 32] {
        let mut id = [0u8; 32];
        for (i, byte) in id.iter_mut().enumerate() {
            *byte = i as u8;
        }
        id
    }

    fn mock_sign(data: &[u8]) -> [u8; 64] {
        let mut sig = [0u8; 64];
        let hash = blake3::hash(data);
        sig[..32].copy_from_slice(hash.as_bytes());
        sig[32..64].copy_from_slice(hash.as_bytes());
        sig
    }

    fn mock_verify(data: &[u8], signature: &[u8; 64]) -> bool {
        let expected = mock_sign(data);
        expected == *signature
    }

    #[test]
    fn test_create_token() {
        let handle = WorkerHandle(12345);
        let cluster_id = mock_cluster_id();
        let validity = Duration::from_secs(3600);

        let token = WorkerToken::create(handle, cluster_id, validity, mock_sign);

        assert_eq!(token.worker_handle, handle);
        assert_eq!(token.cluster_id, cluster_id);
        assert!(!token.is_expired());
        assert!(token.time_remaining().is_some());
    }

    #[test]
    fn test_token_verification() {
        let handle = WorkerHandle(12345);
        let cluster_id = mock_cluster_id();
        let validity = Duration::from_secs(3600);

        let token = WorkerToken::create(handle, cluster_id, validity, mock_sign);

        assert!(token.verify(mock_verify));
        assert_eq!(
            token.verify_full(&cluster_id, mock_verify),
            TokenVerifyResult::Valid
        );

        let wrong_cluster_id = [0xFFu8; 32];
        assert_eq!(
            token.verify_full(&wrong_cluster_id, mock_verify),
            TokenVerifyResult::ClusterMismatch
        );
    }

    #[test]
    fn test_token_expiration() {
        let handle = WorkerHandle(12345);
        let cluster_id = mock_cluster_id();

        let mut token =
            WorkerToken::create(handle, cluster_id, Duration::from_secs(3600), mock_sign);
        token.expires_at = 0;

        assert!(token.is_expired());
        assert!(token.time_remaining().is_none());
        assert_eq!(
            token.verify_full(&cluster_id, mock_verify),
            TokenVerifyResult::Expired
        );
    }

    #[test]
    fn test_token_encoding() {
        let handle = WorkerHandle(12345);
        let cluster_id = mock_cluster_id();
        let validity = Duration::from_secs(3600);

        let token = WorkerToken::create(handle, cluster_id, validity, mock_sign);
        let encoded = token.encode();

        let decoded = WorkerToken::decode(&encoded).unwrap();
        assert_eq!(decoded.worker_handle, token.worker_handle);
        assert_eq!(decoded.cluster_id, token.cluster_id);
        assert_eq!(decoded.expires_at, token.expires_at);
        assert_eq!(decoded.signature, token.signature);
    }

    #[test]
    fn test_token_bytes() {
        let handle = WorkerHandle(12345);
        let cluster_id = mock_cluster_id();
        let validity = Duration::from_secs(3600);

        let token = WorkerToken::create(handle, cluster_id, validity, mock_sign);
        let bytes = token.to_bytes();

        assert_eq!(bytes.len(), 112);

        let restored = WorkerToken::from_bytes(&bytes).unwrap();
        assert_eq!(restored.worker_handle, token.worker_handle);
        assert_eq!(restored.cluster_id, token.cluster_id);
    }

    #[test]
    fn test_cluster_id_hex() {
        let handle = WorkerHandle(1);
        let cluster_id = mock_cluster_id();
        let token = WorkerToken::create(handle, cluster_id, Duration::from_secs(60), mock_sign);

        let hex = token.cluster_id_hex();
        assert_eq!(hex.len(), 64);
        assert!(hex.chars().all(|c| c.is_ascii_hexdigit()));
    }

    #[test]
    fn test_token_verify_result() {
        assert!(TokenVerifyResult::Valid.is_valid());
        assert!(!TokenVerifyResult::Expired.is_valid());
        assert!(!TokenVerifyResult::InvalidSignature.is_valid());
        assert!(!TokenVerifyResult::ClusterMismatch.is_valid());

        assert_eq!(TokenVerifyResult::Valid.description(), "token is valid");
        assert_eq!(
            TokenVerifyResult::Expired.description(),
            "token has expired"
        );
    }

    #[test]
    fn test_token_serialization() {
        let handle = WorkerHandle(42);
        let cluster_id = mock_cluster_id();
        let token = WorkerToken::create(handle, cluster_id, Duration::from_secs(3600), mock_sign);

        let json = serde_json::to_string(&token).unwrap();
        let parsed: WorkerToken = serde_json::from_str(&json).unwrap();

        assert_eq!(parsed.worker_handle, token.worker_handle);
        assert_eq!(parsed.cluster_id, token.cluster_id);
        assert_eq!(parsed.expires_at, token.expires_at);
    }
}
