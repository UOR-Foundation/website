//! Remote execution of computation using hologram backends.
//!
//! This module provides production-ready execution of BackendPlans
//! using the hologram-backend crate's Backend trait.
//!
//! ## Telemetry
//!
//! This module exports metrics via `hologram-telemetry`:
//! - `executor_executions_total` - Total number of executions
//! - `executor_execution_duration_ms` - Execution duration histogram
//! - `executor_failures_total` - Total failures
//! - `executor_cache_hits` - Cache hit count
//! - `executor_cache_misses` - Cache miss count

use super::scheduler::WorkerId;
use hologram_backend::{Backend, BackendError, BackendPlan, BackendType};
use hologram_holo::{HoloError, HoloLoader, LoadedPlan};
use hologram_registry::{LayerReference, LocalRegistry, NameIndex, RegistryError};
use hologram_telemetry::{count, MetricsRegistry};
use rkyv::Deserialize as RkyvDeserialize;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use thiserror::Error;
use tokio::sync::RwLock;

/// Error type for executor operations.
#[derive(Debug, Error)]
pub enum ExecutorError {
    /// Layer not loaded.
    #[error("Layer not loaded: {0}")]
    LayerNotLoaded(String),

    /// Execution failed.
    #[error("Execution failed: {0}")]
    ExecutionFailed(String),

    /// Invalid input.
    #[error("Invalid input: {0}")]
    InvalidInput(String),

    /// Resource exhausted.
    #[error("Resource exhausted: {0}")]
    ResourceExhausted(String),

    /// Backend error.
    #[error("Backend error: {0}")]
    BackendError(#[from] BackendError),

    /// Registry error.
    #[error("Registry error: {0}")]
    RegistryError(#[from] RegistryError),

    /// Holo format error.
    #[error("Format error: {0}")]
    FormatError(#[from] HoloError),

    /// IO error.
    #[error("IO error: {0}")]
    IoError(#[from] std::io::Error),
}

/// Configuration for the executor.
#[derive(Debug, Clone)]
pub struct ExecutorConfig {
    /// Maximum concurrent executions.
    pub max_concurrent: usize,
    /// Memory limit in bytes.
    pub memory_limit: usize,
    /// Execution timeout in seconds.
    pub timeout_secs: u64,
    /// Backend type for execution.
    pub backend_type: BackendType,
    /// Local registry path (optional).
    pub registry_path: Option<PathBuf>,
}

impl Default for ExecutorConfig {
    fn default() -> Self {
        Self {
            max_concurrent: 4,
            memory_limit: 1024 * 1024 * 1024, // 1GB
            timeout_secs: 300,                // 5 minutes
            backend_type: BackendType::Cpu,
            registry_path: None,
        }
    }
}

impl ExecutorConfig {
    /// Create a new executor config.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the backend type.
    #[must_use]
    pub fn with_backend_type(mut self, backend_type: BackendType) -> Self {
        self.backend_type = backend_type;
        self
    }

    /// Set the maximum concurrent executions.
    #[must_use]
    pub fn with_max_concurrent(mut self, max: usize) -> Self {
        self.max_concurrent = max;
        self
    }

    /// Set the memory limit.
    #[must_use]
    pub fn with_memory_limit(mut self, limit: usize) -> Self {
        self.memory_limit = limit;
        self
    }

    /// Set the registry path.
    #[must_use]
    pub fn with_registry_path(mut self, path: impl Into<PathBuf>) -> Self {
        self.registry_path = Some(path.into());
        self
    }
}

/// Result of an execution.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionResult {
    /// Request ID this result is for.
    pub request_id: u64,
    /// Output data (serialized).
    pub output: Vec<u8>,
    /// Execution duration in milliseconds.
    pub duration_ms: u64,
    /// Worker that executed the request.
    pub worker_id: WorkerId,
}

impl ExecutionResult {
    /// Create a new execution result.
    #[must_use]
    pub fn new(request_id: u64, output: Vec<u8>, duration_ms: u64, worker_id: WorkerId) -> Self {
        Self {
            request_id,
            output,
            duration_ms,
            worker_id,
        }
    }

    /// Check if the result is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.output.is_empty()
    }

    /// Get output length.
    #[must_use]
    pub fn output_len(&self) -> usize {
        self.output.len()
    }
}

/// Statistics about executor performance.
#[derive(Debug, Clone, Default)]
pub struct ExecutorStats {
    /// Total executions completed.
    pub total_executions: u64,
    /// Total execution time in milliseconds.
    pub total_duration_ms: u64,
    /// Number of failures.
    pub failures: u64,
    /// Current active executions.
    pub active: u64,
    /// Cache hits (layer was already loaded).
    pub cache_hits: u64,
    /// Cache misses (layer had to be loaded).
    pub cache_misses: u64,
}

impl ExecutorStats {
    /// Get average duration per execution.
    #[must_use]
    #[allow(clippy::cast_precision_loss)]
    pub fn average_duration_ms(&self) -> f64 {
        if self.total_executions == 0 {
            0.0
        } else {
            self.total_duration_ms as f64 / self.total_executions as f64
        }
    }

    /// Get success rate (0.0 - 1.0).
    #[must_use]
    #[allow(clippy::cast_precision_loss)]
    pub fn success_rate(&self) -> f64 {
        let total = self.total_executions + self.failures;
        if total == 0 {
            1.0
        } else {
            self.total_executions as f64 / total as f64
        }
    }

    /// Get cache hit rate (0.0 - 1.0).
    #[must_use]
    #[allow(clippy::cast_precision_loss)]
    pub fn cache_hit_rate(&self) -> f64 {
        let total = self.cache_hits + self.cache_misses;
        if total == 0 {
            0.0
        } else {
            self.cache_hits as f64 / total as f64
        }
    }
}

/// A loaded layer ready for execution.
struct LoadedLayer {
    /// Layer reference string.
    _layer_ref: String,
    /// The loaded plan.
    loaded: LoadedPlan,
    /// Size in bytes.
    size_bytes: usize,
    /// Last used timestamp.
    last_used: std::time::Instant,
}

/// Executor for running computations locally using hologram backends.
///
/// This executor loads BackendPlans from the registry and executes them
/// using the configured backend (CPU, CUDA, Metal, etc.).
pub struct Executor {
    /// Worker ID for this executor.
    worker_id: WorkerId,
    /// Configuration.
    config: ExecutorConfig,
    /// Loaded layers cache.
    layers: Arc<RwLock<HashMap<String, LoadedLayer>>>,
    /// Statistics.
    stats: Arc<RwLock<ExecutorStats>>,
    /// Local registry (optional).
    registry: Option<LocalRegistry>,
}

impl Executor {
    /// Create a new executor.
    pub fn new(worker_id: WorkerId, config: ExecutorConfig) -> Result<Self, ExecutorError> {
        let registry = config
            .registry_path
            .as_ref()
            .map(LocalRegistry::new)
            .transpose()?;

        Ok(Self {
            worker_id,
            config,
            layers: Arc::new(RwLock::new(HashMap::new())),
            stats: Arc::new(RwLock::new(ExecutorStats::default())),
            registry,
        })
    }

    /// Create an executor with default config.
    pub fn with_defaults(worker_id: WorkerId) -> Result<Self, ExecutorError> {
        Self::new(worker_id, ExecutorConfig::default())
    }

    /// Get the worker ID.
    #[must_use]
    pub fn worker_id(&self) -> WorkerId {
        self.worker_id
    }

    /// Get the configuration.
    #[must_use]
    pub fn config(&self) -> &ExecutorConfig {
        &self.config
    }

    /// Get the backend type.
    #[must_use]
    pub fn backend_type(&self) -> &BackendType {
        &self.config.backend_type
    }

    /// Load a layer from a file path.
    #[allow(clippy::cast_possible_truncation)]
    pub async fn load_layer_from_path(
        &self,
        layer_ref: &str,
        path: impl AsRef<Path>,
    ) -> Result<(), ExecutorError> {
        let path = path.as_ref();
        let loaded = HoloLoader::load(path)?;
        let size_bytes = std::fs::metadata(path)
            .map(|m| m.len() as usize)
            .unwrap_or(0);

        let layer = LoadedLayer {
            _layer_ref: layer_ref.to_string(),
            loaded,
            size_bytes,
            last_used: std::time::Instant::now(),
        };

        // Evict old layers if needed
        self.evict_if_needed(size_bytes).await;

        self.layers
            .write()
            .await
            .insert(layer_ref.to_string(), layer);

        tracing::info!(
            "Loaded layer: {} from {:?} ({}B)",
            layer_ref,
            path,
            size_bytes
        );
        Ok(())
    }

    /// Load a layer from the registry by reference.
    pub async fn load_layer_from_registry(&self, layer_ref: &str) -> Result<(), ExecutorError> {
        let registry = self
            .registry
            .as_ref()
            .ok_or_else(|| ExecutorError::InvalidInput("No registry configured".to_string()))?;

        let reference: LayerReference = layer_ref
            .parse()
            .map_err(|e| ExecutorError::InvalidInput(format!("Invalid layer reference: {e}")))?;

        // Get the layer data from registry
        let data = match &reference {
            LayerReference::ByHash(hash) => registry.fetch(hash)?,
            LayerReference::ByName {
                namespace,
                name,
                version,
            } => {
                // Load name index and resolve
                let index_path = registry.index_path();
                let index = NameIndex::load(&index_path)?;
                let hash = index
                    .lookup(namespace.as_deref(), name, version)
                    .ok_or_else(|| {
                        let full_name = match namespace {
                            Some(ns) => format!("{ns}/{name}:{version}"),
                            None => format!("{name}:{version}"),
                        };
                        ExecutorError::LayerNotLoaded(format!("Name not found: {full_name}"))
                    })?;
                registry.fetch(&hash)?
            }
            LayerReference::ByPath(path) => std::fs::read(path)?,
        };

        // Write to temp file and load
        let temp_dir = std::env::temp_dir();
        let temp_path = temp_dir.join(format!(
            "hologram_layer_{}.holb",
            layer_ref.replace(['/', ':'], "_")
        ));
        std::fs::write(&temp_path, &data)?;

        self.load_layer_from_path(layer_ref, &temp_path).await?;

        // Clean up temp file
        let _ = std::fs::remove_file(temp_path);

        Ok(())
    }

    /// Load a layer from raw bytes.
    pub async fn load_layer_from_bytes(
        &self,
        layer_ref: &str,
        data: &[u8],
    ) -> Result<(), ExecutorError> {
        // Write to temp file and load
        let temp_dir = std::env::temp_dir();
        let temp_path = temp_dir.join(format!(
            "hologram_layer_{}.holb",
            layer_ref.replace(['/', ':'], "_")
        ));
        std::fs::write(&temp_path, data)?;

        self.load_layer_from_path(layer_ref, &temp_path).await?;

        // Clean up temp file
        let _ = std::fs::remove_file(temp_path);

        Ok(())
    }

    /// Load a layer with P2P distribution and registry fallback.
    ///
    /// This implements content-addressed layer distribution:
    /// 1. Check if layer is already loaded (cache hit)
    /// 2. Try to fetch from P2P network (if content_store is available)
    /// 3. Fall back to registry (if configured)
    /// 4. Return error if layer cannot be found
    ///
    /// ## Content Addressing
    ///
    /// Layers are identified by their content hash. When fetching from P2P:
    /// - The hash is computed from the layer's binary content
    /// - After fetching, the hash is verified to ensure integrity
    /// - Successful fetches are cached locally for future use
    ///
    /// ## Metrics
    ///
    /// Records the following metrics:
    /// - `layer_fetch_p2p_success` - P2P fetch succeeded
    /// - `layer_fetch_p2p_miss` - P2P fetch failed, falling back
    /// - `layer_fetch_registry_success` - Registry fetch succeeded
    /// - `layer_load_total` - Total layer loads
    pub async fn load_layer_distributed(
        &self,
        layer_ref: &str,
        content_hash: Option<[u8; 32]>,
    ) -> Result<(), ExecutorError> {
        count!("layer_load_total");

        // Check if already loaded
        if self.has_layer(layer_ref).await {
            tracing::debug!("Layer {} already loaded (cache hit)", layer_ref);
            count!("layer_load_cache_hit");
            return Ok(());
        }

        // Try P2P fetch first (if we have a content hash)
        if let Some(hash) = content_hash {
            if let Some(data) = self.try_fetch_from_p2p(&hash) {
                tracing::info!("Loaded layer {} from P2P network", layer_ref);
                count!("layer_fetch_p2p_success");
                return self.load_layer_from_bytes(layer_ref, &data).await;
            }
            count!("layer_fetch_p2p_miss");
            tracing::debug!("P2P fetch failed for {}, trying registry", layer_ref);
        }

        // Fall back to registry
        if self.registry.is_some() {
            match self.load_layer_from_registry(layer_ref).await {
                Ok(()) => {
                    count!("layer_fetch_registry_success");
                    return Ok(());
                }
                Err(e) => {
                    tracing::warn!("Registry fetch failed for {}: {}", layer_ref, e);
                }
            }
        }

        Err(ExecutorError::LayerNotLoaded(format!(
            "Could not load layer {layer_ref}: not in P2P network or registry"
        )))
    }

    /// Try to fetch layer data from P2P network.
    ///
    /// Currently returns `None` so callers always fall back to the registry.
    #[allow(clippy::unused_self)]
    fn try_fetch_from_p2p(&self, _content_hash: &[u8; 32]) -> Option<Vec<u8>> {
        None
    }

    /// Announce that a layer has been loaded locally.
    ///
    /// Logs the announcement. P2P broadcast is not yet implemented.
    #[allow(clippy::unused_self)]
    pub fn announce_layer(&self, layer_ref: &str, content_hash: [u8; 32]) {
        count!("layer_announcements");
        tracing::debug!(
            "Announcing layer {} (hash: {})",
            layer_ref,
            hex::encode(content_hash)
        );
    }

    /// Unload a layer.
    pub async fn unload_layer(&self, layer_ref: &str) {
        if let Some(layer) = self.layers.write().await.remove(layer_ref) {
            tracing::info!(
                "Unloaded layer: {} (freed {}B)",
                layer_ref,
                layer.size_bytes
            );
        }
    }

    /// Check if a layer is loaded.
    pub async fn has_layer(&self, layer_ref: &str) -> bool {
        self.layers.read().await.contains_key(layer_ref)
    }

    /// Get list of loaded layers.
    pub async fn loaded_layers(&self) -> Vec<String> {
        self.layers.read().await.keys().cloned().collect()
    }

    /// Execute a computation on a loaded layer.
    ///
    /// This is the main execution entry point. It:
    /// 1. Looks up the loaded layer
    /// 2. Creates a backend instance
    /// 3. Executes the plan
    /// 4. Returns the output data
    ///
    /// ## Metrics
    ///
    /// Records the following metrics:
    /// - `executor_executions_total` - incremented on each execution
    /// - `executor_execution_duration_ms` - execution duration histogram
    /// - `executor_failures_total` - incremented on failure
    #[allow(clippy::cast_possible_truncation, clippy::cast_precision_loss)]
    pub async fn execute(
        &self,
        request_id: u64,
        layer_ref: &str,
        inputs: &[&[u8]],
    ) -> Result<ExecutionResult, ExecutorError> {
        // Record execution attempt
        count!("executor_executions_total");

        // Update stats - mark as active
        {
            let mut stats = self.stats.write().await;
            stats.active += 1;
        }

        let start = std::time::Instant::now();

        // Execute the layer
        let result = self.execute_layer(layer_ref, inputs).await;

        let duration_ms = start.elapsed().as_millis() as u64;

        // Record execution duration
        let metrics = MetricsRegistry::global();
        metrics.record("executor_execution_duration_ms", duration_ms as f64);

        // Update stats
        {
            let mut stats = self.stats.write().await;
            stats.active -= 1;
            if result.is_ok() {
                stats.total_executions += 1;
                stats.total_duration_ms += duration_ms;
            } else {
                stats.failures += 1;
                // Record failure metric
                count!("executor_failures_total");
            }
        }

        let output = result?;

        Ok(ExecutionResult {
            request_id,
            output,
            duration_ms,
            worker_id: self.worker_id,
        })
    }

    /// Execute a layer with the given input data.
    async fn execute_layer(
        &self,
        layer_ref: &str,
        inputs: &[&[u8]],
    ) -> Result<Vec<u8>, ExecutorError> {
        // Get the loaded plan
        let plan: BackendPlan = {
            let mut layers = self.layers.write().await;
            let layer = layers
                .get_mut(layer_ref)
                .ok_or_else(|| ExecutorError::LayerNotLoaded(layer_ref.to_string()))?;
            layer.last_used = std::time::Instant::now();

            // Update cache hit stats and record metric
            {
                let mut stats = self.stats.write().await;
                stats.cache_hits += 1;
                count!("executor_cache_hits");
            }

            // Deserialize the archived plan to an owned BackendPlan
            let archived = layer.loaded.plan();
            archived
                .deserialize(&mut rkyv::Infallible)
                .expect("Infallible deserialization")
        };

        // Create backend and execute
        self.execute_plan(&plan, inputs)
    }

    /// Execute a BackendPlan with the given inputs.
    fn execute_plan(&self, plan: &BackendPlan, inputs: &[&[u8]]) -> Result<Vec<u8>, ExecutorError> {
        // Create the appropriate backend
        let backend = self.create_backend()?;

        // Determine output size from plan metadata
        let output_size = plan.workspace_size.max(1024);
        let mut output = vec![0u8; output_size];

        // Convert inputs to the format expected by execute_plan
        let inputs_refs: Vec<&[u8]> = inputs.to_vec();
        let mut outputs_refs: Vec<&mut [u8]> = vec![output.as_mut_slice()];

        // Execute the plan
        backend.execute_plan(plan, &inputs_refs, &mut outputs_refs)?;

        Ok(output)
    }

    /// Create a backend instance for execution.
    fn create_backend(&self) -> Result<Box<dyn Backend>, ExecutorError> {
        match &self.config.backend_type {
            BackendType::Cpu => Ok(Box::new(hologram_backend::cpu::CpuBackend::new())),
            BackendType::Wasm => Ok(Box::new(hologram_backend::wasm::WasmBackend::new())),
            other => Err(ExecutorError::ExecutionFailed(format!(
                "Backend {other:?} not fully implemented for distributed execution"
            ))),
        }
    }

    /// Evict old cache entries if memory limit would be exceeded.
    async fn evict_if_needed(&self, new_size: usize) {
        let mut layers = self.layers.write().await;

        // Calculate current size
        let current_size: usize = layers.values().map(|l| l.size_bytes).sum();

        if current_size + new_size > self.config.memory_limit {
            // Find oldest entries to evict
            let mut entries: Vec<_> = layers
                .iter()
                .map(|(k, v)| (k.clone(), v.last_used, v.size_bytes))
                .collect();
            entries.sort_by_key(|(_, t, _)| *t);

            let mut freed = 0;
            for (key, _, size) in entries {
                if current_size - freed + new_size <= self.config.memory_limit {
                    break;
                }
                if layers.remove(&key).is_some() {
                    freed += size;
                    tracing::debug!("Evicted cached layer: {} (freed {}B)", key, size);
                }
            }
        }
    }

    /// Get execution statistics.
    pub async fn stats(&self) -> ExecutorStats {
        self.stats.read().await.clone()
    }

    /// Get the average execution time in milliseconds.
    pub async fn average_duration_ms(&self) -> f64 {
        self.stats.read().await.average_duration_ms()
    }

    /// Get total memory usage in bytes.
    pub async fn memory_usage(&self) -> usize {
        self.layers
            .read()
            .await
            .values()
            .map(|l| l.size_bytes)
            .sum()
    }

    /// Get the number of active executions.
    pub async fn active_count(&self) -> u64 {
        self.stats.read().await.active
    }

    /// Get the number of cached layers.
    pub async fn cached_layer_count(&self) -> usize {
        self.layers.read().await.len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_executor_creation() {
        let executor = Executor::with_defaults(WorkerId(1)).unwrap();
        assert_eq!(executor.worker_id(), WorkerId(1));
        assert_eq!(executor.config().max_concurrent, 4);
    }

    #[tokio::test]
    async fn test_executor_custom_config() {
        let config = ExecutorConfig::new()
            .with_max_concurrent(8)
            .with_memory_limit(512 * 1024 * 1024)
            .with_backend_type(BackendType::Cpu);

        let executor = Executor::new(WorkerId(1), config).unwrap();
        assert_eq!(executor.config().max_concurrent, 8);
        assert_eq!(executor.config().memory_limit, 512 * 1024 * 1024);
    }

    #[tokio::test]
    async fn test_executor_no_layer() {
        let executor = Executor::with_defaults(WorkerId(1)).unwrap();
        assert!(!executor.has_layer("test:v1").await);
    }

    #[tokio::test]
    async fn test_executor_execute_not_loaded() {
        let executor = Executor::with_defaults(WorkerId(1)).unwrap();
        let result = executor.execute(1, "missing:v1", &[&[1, 2, 3]]).await;
        assert!(matches!(result, Err(ExecutorError::LayerNotLoaded(_))));
    }

    #[tokio::test]
    #[allow(clippy::float_cmp)]
    async fn test_executor_stats_initial() {
        let executor = Executor::with_defaults(WorkerId(1)).unwrap();
        let stats = executor.stats().await;

        assert_eq!(stats.total_executions, 0);
        assert_eq!(stats.failures, 0);
        assert_eq!(stats.active, 0);
        assert_eq!(stats.average_duration_ms(), 0.0);
        assert_eq!(stats.success_rate(), 1.0);
    }

    #[tokio::test]
    async fn test_executor_stats_after_failure() {
        let executor = Executor::with_defaults(WorkerId(1)).unwrap();

        // Try to execute without loading - should fail
        let _ = executor.execute(1, "missing:v1", &[]).await;

        let stats = executor.stats().await;
        assert_eq!(stats.failures, 1);
        assert_eq!(stats.total_executions, 0);
    }

    #[tokio::test]
    async fn test_executor_memory_usage_initial() {
        let executor = Executor::with_defaults(WorkerId(1)).unwrap();
        assert_eq!(executor.memory_usage().await, 0);
        assert_eq!(executor.cached_layer_count().await, 0);
    }

    #[test]
    fn test_execution_result() {
        let result = ExecutionResult::new(1, vec![1, 2, 3], 100, WorkerId(1));
        assert_eq!(result.request_id, 1);
        assert_eq!(result.output_len(), 3);
        assert!(!result.is_empty());

        let empty = ExecutionResult::new(2, vec![], 50, WorkerId(1));
        assert!(empty.is_empty());
    }

    #[test]
    #[allow(clippy::float_cmp)]
    fn test_executor_stats() {
        let mut stats = ExecutorStats::default();
        assert_eq!(stats.average_duration_ms(), 0.0);
        assert_eq!(stats.success_rate(), 1.0);
        assert_eq!(stats.cache_hit_rate(), 0.0);

        stats.total_executions = 10;
        stats.total_duration_ms = 1000;
        assert_eq!(stats.average_duration_ms(), 100.0);

        stats.failures = 2;
        // success_rate = 10 / (10 + 2) = 0.833...
        assert!((stats.success_rate() - 0.833).abs() < 0.01);

        stats.cache_hits = 8;
        stats.cache_misses = 2;
        assert_eq!(stats.cache_hit_rate(), 0.8);
    }

    #[test]
    fn test_executor_error_display() {
        let err = ExecutorError::LayerNotLoaded("test:v1".to_string());
        assert!(err.to_string().contains("test:v1"));

        let err = ExecutorError::ExecutionFailed("timeout".to_string());
        assert!(err.to_string().contains("timeout"));

        let err = ExecutorError::InvalidInput("bad format".to_string());
        assert!(err.to_string().contains("bad format"));

        let err = ExecutorError::ResourceExhausted("memory".to_string());
        assert!(err.to_string().contains("memory"));
    }

    #[test]
    fn test_executor_config_builder() {
        let config = ExecutorConfig::new()
            .with_backend_type(BackendType::Wasm)
            .with_max_concurrent(16)
            .with_memory_limit(2 * 1024 * 1024 * 1024)
            .with_registry_path("/tmp/registry");

        assert_eq!(config.backend_type, BackendType::Wasm);
        assert_eq!(config.max_concurrent, 16);
        assert_eq!(config.memory_limit, 2 * 1024 * 1024 * 1024);
        assert_eq!(config.registry_path, Some(PathBuf::from("/tmp/registry")));
    }
}
