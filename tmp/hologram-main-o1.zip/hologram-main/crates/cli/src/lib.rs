//! Hologram CLI library.
//!
//! Provides the command-line interface for the Hologram compute acceleration framework.
//!
//! # Commands
//!
//! - `compile` - Compile source code or ONNX model to `.holo`
//! - `run` - Execute a `.holo` file with provided inputs
//! - `holo` - Archive management: pack, unpack, inspect `.holo` files
//! - `model` - Model operations: info, validate, benchmark
//! - `registry` - Publish to or fetch from a layer registry
//! - `metrics` - Performance reporting and profiling
//! - `distributed` - Distributed execution: worker management, job submission
//! - `tokenizer` - Tokenizer compilation: compile tokenizer.json to .holo format

pub mod commands;
pub mod error;
pub mod reader;
pub mod writer;

use clap::{Parser, Subcommand};
use commands::{compile, distributed, holo, kernel, metrics, model, registry, run, tokenizer};
use error::CliResult;

/// Hologram: O(1) compute acceleration via pre-computed lookup tables.
#[derive(Parser, Debug)]
#[command(name = "hologram")]
#[command(author, version, about, long_about = None)]
#[command(propagate_version = true)]
pub struct Cli {
    /// Enable verbose output
    #[arg(short, long, global = true)]
    pub verbose: bool,

    #[command(subcommand)]
    pub command: Command,
}

/// Available commands.
#[derive(Subcommand, Debug)]
pub enum Command {
    /// Compile source code or ONNX model to .holo format
    Compile(compile::CompileArgs),

    /// Execute a .holo file with provided inputs
    Run(run::RunArgs),

    /// Archive management: pack, unpack, inspect .holo files
    Holo(holo::HoloArgs),

    /// Model operations: info, validate, benchmark
    Model(model::ModelArgs),

    /// Publish to or fetch from a layer registry
    Registry(registry::RegistryArgs),

    /// Performance reporting and profiling
    Metrics(metrics::MetricsArgs),

    /// Distributed execution: worker management, job submission
    Distributed(distributed::DistributedArgs),

    /// Tokenizer operations: compile tokenizer.json to .holo format
    Tokenizer(tokenizer::TokenizerArgs),

    /// Kernel operations: initialize, build, test external kernels
    Kernel(kernel::KernelArgs),
}

/// Execute the CLI with the parsed arguments.
pub fn run(cli: Cli) -> CliResult<()> {
    match cli.command {
        Command::Compile(args) => compile::execute(args, cli.verbose),
        Command::Run(args) => run::execute(args, cli.verbose),
        Command::Holo(args) => holo::execute(args, cli.verbose),
        Command::Model(args) => model::execute(args, cli.verbose),
        Command::Registry(args) => registry::execute(args, cli.verbose),
        Command::Metrics(args) => metrics::execute(args, cli.verbose),
        Command::Distributed(args) => distributed::execute(args, cli.verbose),
        Command::Tokenizer(args) => tokenizer::execute(args, cli.verbose),
        Command::Kernel(args) => kernel::execute(args, cli.verbose),
    }
}
