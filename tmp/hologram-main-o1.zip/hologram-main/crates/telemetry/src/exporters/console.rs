//! Console exporter for pretty-printed metric output.

use crate::exporters::{format_histogram_summary, MetricExporter};
use crate::metrics::MetricsRegistry;
use tracing::info;

/// Console exporter that produces human-readable output.
pub struct ConsoleExporter;

impl MetricExporter for ConsoleExporter {
    fn export(&self, registry: &MetricsRegistry) -> String {
        let mut output = String::new();

        // Export counters
        let counters = registry.counters();
        if !counters.is_empty() {
            output.push_str("=== Counters ===\n");
            for (name, value) in counters {
                output.push_str(&format!("  {}: {}\n", name, value));
            }
            output.push('\n');
        }

        // Export histograms
        let histograms = registry.histograms();
        if !histograms.is_empty() {
            output.push_str("=== Histograms ===\n");
            for (name, summary) in histograms {
                output.push_str(&format!(
                    "  {}: {}\n",
                    name,
                    format_histogram_summary(&summary)
                ));
            }
            output.push('\n');
        }

        if output.is_empty() {
            output.push_str("No metrics recorded.\n");
        }

        output
    }
}

impl ConsoleExporter {
    /// Create a new console exporter.
    #[must_use]
    pub const fn new() -> Self {
        Self
    }

    /// Export metrics and log to tracing.
    pub fn print(&self, registry: &MetricsRegistry) {
        info!("{}", self.export(registry));
    }
}

impl Default for ConsoleExporter {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_console_exporter_empty() {
        let registry = MetricsRegistry::new();
        let exporter = ConsoleExporter::new();
        let output = exporter.export(&registry);
        assert!(output.contains("No metrics recorded"));
    }

    #[test]
    fn test_console_exporter_counters() {
        let registry = MetricsRegistry::new();
        registry.increment("requests_total", 100);
        registry.increment("errors_total", 5);

        let exporter = ConsoleExporter::new();
        let output = exporter.export(&registry);

        assert!(output.contains("Counters"));
        assert!(output.contains("requests_total"));
        assert!(output.contains("100"));
        assert!(output.contains("errors_total"));
        assert!(output.contains("5"));
    }

    #[test]
    fn test_console_exporter_histograms() {
        let registry = MetricsRegistry::new();
        for i in 1..=10 {
            registry.record("latency_ms", i as f64);
        }

        let exporter = ConsoleExporter::new();
        let output = exporter.export(&registry);

        assert!(output.contains("Histograms"));
        assert!(output.contains("latency_ms"));
        assert!(output.contains("count=10"));
    }

    #[test]
    fn test_console_exporter_both() {
        let registry = MetricsRegistry::new();
        registry.increment("counter", 42);
        registry.record("histogram", 3.5);

        let exporter = ConsoleExporter::new();
        let output = exporter.export(&registry);

        assert!(output.contains("Counters"));
        assert!(output.contains("Histograms"));
    }

    #[test]
    fn test_console_exporter_default() {
        let exporter = ConsoleExporter;
        let registry = MetricsRegistry::new();
        let _ = exporter.export(&registry);
    }
}
