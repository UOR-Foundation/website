/**
 * Mock data for standalone development.
 * On merge: replace with real data sources.
 */

import type {
  TrustAttestation,
  Permission,
  PrivacyConsent,
  PrivacyPolicy,
  CeremonyRecord,
  CeremonyIdentityProfile,
} from "../types";

export const MOCK_PROFILE: CeremonyIdentityProfile = {
  id: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
  displayName: "Sovereign Observer",
  handle: "@sovereign.uor",
  bio: "A self-sovereign identity anchored in the Universal Object Reference framework.",
  createdAt: Date.now() - 86400000 * 30,
  updatedAt: Date.now(),
  guardianFingerprint: "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2",
  delegateFingerprint: "f6e5d4c3b2a1f6e5d4c3b2a1f6e5d4c3b2a1f6e5d4c3b2a1f6e5d4c3b2a1f6e5",
  delegatePublicKeyHex: "d4c3b2a1f6e5d4c3b2a1f6e5d4c3b2a1f6e5d4c3b2a1f6e5d4c3b2a1f6e5d4c3",
  ceremonyId: "urn:uor:derivation:sha256:mock-founding-ceremony",
  ceremoniedAt: Date.now() - 86400000 * 30,
};

export const MOCK_ATTESTATIONS: readonly TrustAttestation[] = [
  {
    id: "att-001",
    fromId: "u:⠋⠕⠥⠝⠙⠁⠞⠊⠕⠝",
    toId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    level: "verified",
    reason: "Foundation-verified contributor",
    issuedAt: Date.now() - 86400000 * 7,
  },
  {
    id: "att-002",
    fromId: "u:⠏⠑⠑⠗⠁",
    toId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    level: "basic",
    reason: "Peer attestation",
    issuedAt: Date.now() - 86400000 * 3,
  },
  {
    id: "att-003",
    fromId: "u:⠏⠑⠑⠗⠃",
    toId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    level: "verified",
    reason: "Code review attestation",
    issuedAt: Date.now() - 86400000 * 1,
  },
];

export const MOCK_PERMISSIONS: Permission[] = [
  {
    id: "perm-001",
    identityId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    resource: "u:*",
    action: "read",
    scope: "self",
    grantedBy: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    grantedAt: Date.now() - 86400000 * 30,
    active: true,
  },
  {
    id: "perm-002",
    identityId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    resource: "schema:*",
    action: "write",
    scope: "namespace",
    grantedBy: "u:⠋⠕⠥⠝⠙⠁⠞⠊⠕⠝",
    grantedAt: Date.now() - 86400000 * 14,
    active: true,
  },
  {
    id: "perm-003",
    identityId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    resource: "state:*",
    action: "admin",
    scope: "trusted",
    grantedBy: "u:⠋⠕⠥⠝⠙⠁⠞⠊⠕⠝",
    grantedAt: Date.now() - 86400000 * 7,
    active: true,
  },
  {
    id: "perm-004",
    identityId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    resource: "cert:*",
    action: "attest",
    scope: "public",
    grantedBy: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    grantedAt: Date.now() - 86400000 * 2,
    active: true,
  },
];

export const MOCK_CONSENTS: PrivacyConsent[] = [
  {
    id: "consent-001",
    identityId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    category: "profile",
    status: "granted",
    purpose: "Display public profile information",
    grantedAt: Date.now() - 86400000 * 30,
  },
  {
    id: "consent-002",
    identityId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    category: "activity",
    status: "granted",
    purpose: "Track interaction patterns for personalization",
    grantedAt: Date.now() - 86400000 * 14,
    expiresAt: Date.now() + 86400000 * 90,
  },
  {
    id: "consent-003",
    identityId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    category: "social",
    status: "denied",
    purpose: "Share social graph with trusted peers",
  },
  {
    id: "consent-004",
    identityId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    category: "content",
    status: "pending",
    purpose: "Index content for semantic search",
  },
  {
    id: "consent-005",
    identityId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    category: "financial",
    status: "denied",
    purpose: "Process transaction history",
  },
];

export const MOCK_POLICY: PrivacyPolicy = {
  version: "1.0.0",
  effectiveDate: Date.now() - 86400000 * 90,
  sections: [
    {
      id: "sec-001",
      title: "Data Sovereignty",
      content: "Your identity data is anchored to your UOR address. You own your data unconditionally. No third party can access, modify, or delete your identity without your explicit cryptographic consent.",
      dataCategories: ["profile", "activity"],
    },
    {
      id: "sec-002",
      title: "Consent & Control",
      content: "All data sharing requires explicit, revocable consent. Consent grants are time-bounded and purpose-specific. You may revoke any consent at any time with immediate effect.",
      dataCategories: ["social", "content", "financial"],
    },
    {
      id: "sec-003",
      title: "Trust Attestations",
      content: "Trust is bidirectional and attestation-based. Your trust score is computed from peer attestations. You control who can attest to your identity and which attestations you accept.",
      dataCategories: ["social"],
    },
    {
      id: "sec-004",
      title: "Zero-Knowledge Proofs",
      content: "Where possible, the system uses zero-knowledge proofs to verify claims without revealing underlying data. Your biometric and location data are never stored in cleartext.",
      dataCategories: ["biometric", "location"],
    },
  ],
};

export const MOCK_CEREMONIES: CeremonyRecord[] = [
  {
    id: "urn:uor:derivation:sha256:mock-founding-ceremony",
    type: "founding",
    identityId: "u:⠓⠕⠇⠕⠛⠗⠁⠍",
    participants: ["u:⠓⠕⠇⠕⠛⠗⠁⠍"],
    derivationId: "urn:uor:derivation:sha256:mock-founding-ceremony",
    guardianFingerprint: "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2",
    delegateFingerprint: "f6e5d4c3b2a1f6e5d4c3b2a1f6e5d4c3b2a1f6e5d4c3b2a1f6e5d4c3b2a1f6e5",
    timestamp: Date.now() - 86400000 * 30,
    metadata: { bootstrapMethod: "email-verified" },
  },
];
