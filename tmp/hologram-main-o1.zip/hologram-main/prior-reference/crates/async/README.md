# hologram-async

**Async runtime support for Hologram I/O-bound operations**

## Overview

`hologram-async` provides async/await support for Hologram operations that benefit from non-blocking I/O. It wraps the synchronous `hologram-core` executor with a Tokio-based async interface, enabling efficient handling of model loading, network operations, and streaming execution.

The crate bridges Hologram's compute-optimized core with async I/O patterns:
- **AsyncExecutor**: Non-blocking wrapper around synchronous execution
- **AsyncLoader**: Progress-reporting model loader with stage tracking
- **ExecutionStream**: Streaming results for long-running computations
- **Runtime Management**: Configurable Tokio runtime with sensible defaults

## Architecture

```
┌────────────────────────────────────────────────────────────────────────────┐
│                           hologram-async                                    │
├────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         AsyncExecutor                                │   │
│  │  Async wrapper → spawn_blocking() → hologram-core Executor          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                          AsyncLoader                                 │   │
│  │  LoadStage: Manifest → Layer → Weights → Validating → Complete      │   │
│  │  Progress callbacks with bytes_loaded, total_bytes, percentage      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        ExecutionStream                               │   │
│  │  async_stream yields partial results for streaming inference        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    Runtime (Tokio)                                   │   │
│  │  create_runtime() │ global_runtime() │ RuntimeConfig                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
                         ┌─────────────────────┐
                         │   hologram-core     │
                         │   (sync Executor)   │
                         └─────────────────────┘
```

### Load Progress Flow

```
AsyncLoader::load("model.toml")
         │
         ▼
┌─────────────────────┐
│ ReadingManifest     │ → Parse TOML, resolve layers
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ LoadingLayer        │ → Fetch each layer, report progress
└─────────┬───────────┘   (bytes_loaded, total_bytes, layer_name)
          │
          ▼
┌─────────────────────┐
│ LoadingWeights      │ → Load weight tensors
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ Validating          │ → Verify checksums, shapes
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ Complete            │ → Model ready for execution
└─────────────────────┘
```

## Features

- **AsyncExecutor**: Non-blocking execution via `spawn_blocking`
- **AsyncBuffer**: Async buffer allocation and management
- **AsyncLoader**: Model loading with stage-based progress
- **ExecutionStream**: Streaming inference results
- **AsyncRegistry**: Remote registry client (requires `registry` feature)
- **Runtime Config**: Customizable Tokio runtime settings
- **Global Runtime**: Shared runtime for simple use cases

## Key Types

| Type | Description |
|------|-------------|
| `AsyncExecutor` | Async wrapper around sync `Executor` |
| `AsyncBuffer` | Async buffer allocation |
| `AsyncLoader` | Model loader with progress callbacks |
| `LoadProgress` | Progress info (stage, bytes, percentage) |
| `LoadStage` | Loading stage enum |
| `ExecutionStream` | Stream of partial execution results |
| `RuntimeConfig` | Tokio runtime configuration |
| `AsyncError` | Error type for async operations |

## Usage

### Async Executor

```rust
use hologram_async::{AsyncExecutor, Result};
use hologram_core::{BackendType, LaunchConfig};

#[tokio::main]
async fn main() -> Result<()> {
    // Create executor with auto-detected backend
    let executor = AsyncExecutor::new().await?;

    // Or specify backend explicitly
    let executor = AsyncExecutor::with_backend(BackendType::Cpu).await?;

    // Allocate buffers asynchronously
    let input: Buffer<f32> = executor.allocate(1024).await?;
    let output: Buffer<f32> = executor.allocate(1024).await?;

    // Execute program (offloaded to blocking pool)
    let config = LaunchConfig::default();
    executor.execute(program, config).await?;

    // Free buffers
    executor.free(input).await?;
    executor.free(output).await?;

    Ok(())
}
```

### Model Loading with Progress

```rust
use hologram_async::{AsyncLoader, LoadProgress, LoadStage};

#[tokio::main]
async fn main() -> Result<()> {
    let loader = AsyncLoader::new();

    // Load with progress callback
    let model = loader.load_with_progress(
        "model.toml",
        |progress: LoadProgress| {
            match progress.stage {
                LoadStage::ReadingManifest => println!("Reading manifest..."),
                LoadStage::LoadingLayer => {
                    if let Some(name) = &progress.layer_name {
                        println!("Loading layer: {}", name);
                    }
                    if let Some(pct) = progress.percentage {
                        println!("Progress: {}%", pct);
                    }
                }
                LoadStage::Complete => println!("Loading complete!"),
                _ => {}
            }
        }
    ).await?;

    Ok(())
}
```

### Execution Streaming

```rust
use hologram_async::{execute_stream, ExecutionStream};
use futures::StreamExt;

#[tokio::main]
async fn main() -> Result<()> {
    let executor = AsyncExecutor::new().await?;

    // Stream partial results
    let mut stream = execute_stream(&executor, program, config);

    while let Some(result) = stream.next().await {
        let partial = result?;
        println!("Received {} elements", partial.len());
        // Process partial results incrementally
    }

    Ok(())
}
```

### Runtime Configuration

```rust
use hologram_async::{create_runtime, RuntimeConfig, global_runtime};

// Custom runtime configuration
let config = RuntimeConfig::new()
    .with_worker_threads(4)
    .with_thread_name("hologram-worker")
    .with_stack_size(4 * 1024 * 1024);

let runtime = create_runtime(config)?;

runtime.block_on(async {
    // Run async code
});

// Or use the global shared runtime
let runtime = global_runtime();
runtime.block_on(async {
    // Uses shared runtime
});

// Pre-configured profiles
let io_config = RuntimeConfig::io_optimized();
let single_config = RuntimeConfig::single_threaded();
```

### Async Registry Client

```rust
use hologram_async::{AsyncRegistry, SearchResult};

#[tokio::main]
async fn main() -> Result<()> {
    let registry = AsyncRegistry::new("https://registry.hologram.dev");

    // Search for models
    let results: Vec<SearchResult> = registry.search("bert", 10).await?;

    for result in results {
        println!("{}: {}", result.name, result.description);
    }

    // Pull a model
    let path = registry.pull("bert/embeddings:v1.0", "./cache").await?;

    Ok(())
}
```

## Modules

| Module | Purpose |
|--------|---------|
| `executor` | `AsyncExecutor` wrapping sync execution |
| `buffer` | `AsyncBuffer` for async allocation |
| `loader` | `AsyncLoader` with progress reporting |
| `stream` | `ExecutionStream` for streaming results |
| `runtime` | Tokio runtime configuration and management |
| `registry` | `AsyncRegistry` HTTP client (feature-gated) |
| `error` | `AsyncError` and `Result` types |

## Feature Flags

| Feature | Description | Default |
|---------|-------------|---------|
| `registry` | Enable async registry HTTP client via `reqwest` | Yes |

## Dependencies

**Internal:**
- `hologram-core` - Executor and buffer types
- `hologram-compiler` - Manifest parsing
- `hologram-isa` - Program types

**External:**
- `tokio` - Async runtime with full features
- `futures` - Async utilities and stream support
- `async-trait` - Async trait support
- `async-stream` - Streaming macro support
- `toml` - Manifest parsing
- `reqwest` (optional) - HTTP client for registry

## Performance

- **spawn_blocking**: Sync operations offloaded to blocking thread pool
- **Buffer reuse**: Async buffers support pooling patterns
- **Streaming**: Partial results reduce latency for large outputs
- **Configurable threads**: Tune worker count for workload
- **Global runtime**: Shared instance avoids runtime creation overhead

### Runtime Recommendations

| Workload | Configuration |
|----------|---------------|
| I/O-bound (model loading) | `RuntimeConfig::io_optimized()` |
| Single request | `RuntimeConfig::single_threaded()` |
| Multi-tenant server | Custom with worker count = CPU cores |
| Batch processing | Default (auto-detected threads) |

## See Also

- [hologram-core](../core/README.md) - Underlying sync executor
- [hologram-network](../network/README.md) - Distributed async networking
- [hologram-registry](../registry/README.md) - Registry client
- [Spec: 08-async-crate.md](../../specs/plans/08-async-crate.md)
