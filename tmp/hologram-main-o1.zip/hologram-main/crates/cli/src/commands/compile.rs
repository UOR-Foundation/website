//! Compile command: compile source or ONNX to .holo format.

use std::path::{Path, PathBuf};
use std::time::Instant;

use clap::Args;
use hologram_compiler::{compile, CompilerConfig, OperationGraph};
use hologram_holo::PlanMetadata;
use owo_colors::OwoColorize;

use crate::error::{CliError, CliResult};
use crate::writer::{write_holb, HolbStats};

/// Arguments for the compile command.
#[derive(Args, Debug)]
pub struct CompileArgs {
    /// Input file (ONNX model, JSON graph, or source file)
    #[arg(value_name = "INPUT")]
    pub input: PathBuf,

    /// Output .holb file path
    #[arg(short, long, value_name = "OUTPUT")]
    pub output: Option<PathBuf>,

    /// Optimization level (0-3)
    #[arg(short = 'O', long, default_value = "2")]
    pub opt_level: u8,

    /// Target backend (cpu, wasm, cuda, metal)
    #[arg(short, long, default_value = "cpu")]
    pub target: String,

    /// Model name for metadata
    #[arg(long)]
    pub name: Option<String>,

    /// Model version for metadata
    #[arg(long = "model-version", default_value = "0.1.0")]
    pub model_version: String,
}

/// Execute the compile command.
pub fn execute(args: CompileArgs, verbose: bool) -> CliResult<()> {
    // Verify input file exists
    if !args.input.exists() {
        return Err(CliError::FileNotFound(args.input));
    }

    // Determine output path (use .holb extension)
    let output = args
        .output
        .unwrap_or_else(|| args.input.with_extension("holb"));

    // Detect input format
    let extension = args
        .input
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("");

    if verbose {
        println!(
            "{} {} -> {}",
            "Compiling".green().bold(),
            args.input.display(),
            output.display()
        );
        println!("  {} {}", "Format:".dimmed(), extension);
        println!("  {} O{}", "Optimization:".dimmed(), args.opt_level);
        println!("  {} {}", "Target:".dimmed(), args.target);
        println!();
    }

    // Build metadata
    let model_name = args.name.unwrap_or_else(|| {
        args.input
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap_or("model")
            .to_string()
    });

    let metadata = PlanMetadata {
        name: model_name,
        version: args.model_version,
        author: None,
        description: None,
    };

    match extension {
        "onnx" => compile_onnx(&args.input, &output, &metadata, verbose),
        "json" => compile_json_graph(&args.input, &output, &metadata, verbose),
        "py" => Err(CliError::NotImplemented("Python frontend".to_string())),
        "ts" | "js" => Err(CliError::NotImplemented("TypeScript frontend".to_string())),
        _ => Err(CliError::UnsupportedFormat(format!(
            "{extension} (supported: .onnx, .json)"
        ))),
    }
}

/// Compile an ONNX model to .holb format.
///
/// ONNX support requires the separate hologram-ai workspace.
fn compile_onnx(
    input: &Path,
    output: &Path,
    _metadata: &PlanMetadata,
    _verbose: bool,
) -> CliResult<()> {
    Err(CliError::NotImplemented(format!(
        "ONNX support not available. See hologram-ai workspace for ONNX compilation (compile {} -> {}).",
        input.display(),
        output.display()
    )))
}

/// Compile a JSON-serialized OperationGraph to .holb format.
///
/// JSON format supports testing the compilation pipeline without ONNX.
fn compile_json_graph(
    input: &Path,
    output: &Path,
    metadata: &PlanMetadata,
    verbose: bool,
) -> CliResult<()> {
    let start = Instant::now();

    if verbose {
        print_stage("Loading", "JSON graph");
    }

    // Read and parse JSON
    let json_bytes = std::fs::read(input)?;
    let graph: OperationGraph = serde_json::from_slice(&json_bytes)
        .map_err(|e| CliError::InvalidInput(format!("failed to parse JSON graph: {e}")))?;

    if verbose {
        print_stage_done(start.elapsed());
        println!(
            "    {} {} nodes, {} edges",
            "Graph:".dimmed(),
            graph.node_count().to_string().cyan(),
            graph.edge_count().to_string().cyan()
        );
    }

    // Compile the graph
    compile_graph(&graph, output, metadata, verbose)
}

/// Compile an OperationGraph to .holb format.
fn compile_graph(
    graph: &OperationGraph,
    output: &Path,
    metadata: &PlanMetadata,
    verbose: bool,
) -> CliResult<()> {
    let total_start = Instant::now();

    // Configure the compiler
    let config = CompilerConfig::default();

    if verbose {
        println!();
        println!("{}", "Pipeline Stages:".bold());
    }

    // Stage 1: Compile to BackendPlan
    let stage_start = Instant::now();
    if verbose {
        print_stage("Compiling", "operation graph to backend plan");
    }

    let mut plan = compile(graph, &config)
        .map_err(|e| CliError::CompilationFailed(format!("compilation failed: {e}")))?;

    if verbose {
        print_stage_done(stage_start.elapsed());
        println!(
            "    {} IR conversion, fusion passes, kernel selection",
            "Stages:".dimmed()
        );
        println!(
            "    {} layout planning, workspace allocation, assembly",
            "       ".dimmed()
        );
    }

    // Set metadata
    plan.metadata = metadata.clone();

    if verbose {
        println!();
        println!("{}", "Plan Summary:".bold());
        println!(
            "    {} {}",
            "Instructions:".dimmed(),
            plan.instructions.len().to_string().cyan()
        );
        println!(
            "    {} {}",
            "Buffers:".dimmed(),
            plan.buffers.len().to_string().cyan()
        );
        println!(
            "    {} {} bytes",
            "Constants:".dimmed(),
            plan.constants.len().to_string().cyan()
        );
        println!(
            "    {} {} bytes",
            "Workspace:".dimmed(),
            plan.workspace_size.to_string().cyan()
        );
    }

    // Stage 2: Write to .holb file
    let stage_start = Instant::now();
    if verbose {
        println!();
        print_stage("Writing", "output file");
    }

    write_holb(&plan, output)?;

    if verbose {
        print_stage_done(stage_start.elapsed());
    }

    // Calculate and report stats
    let file_size = std::fs::metadata(output)?.len() as usize;
    let stats = HolbStats::from_plan(&plan, file_size);
    let total_time = total_start.elapsed();

    if verbose {
        println!();
        println!("{}", "Compilation Complete:".green().bold());
        println!("    {} {}", "Output:".dimmed(), output.display());
        println!(
            "    {} {} bytes ({})",
            "Size:".dimmed(),
            stats.total_size.to_string().cyan(),
            format_size(stats.total_size)
        );
        println!(
            "    {} {}",
            "Instructions:".dimmed(),
            stats.instruction_count.to_string().cyan()
        );
        println!(
            "    {} {}",
            "Buffers:".dimmed(),
            stats.buffer_count.to_string().cyan()
        );
        if stats.weights_size > 0 {
            println!(
                "    {} {} bytes ({})",
                "Weights:".dimmed(),
                stats.weights_size.to_string().cyan(),
                format_size(stats.weights_size)
            );
        }
        println!("    {} {:.2?}", "Total time:".dimmed(), total_time);
    } else {
        println!(
            "{} {} ({}, {} instructions)",
            "Compiled".green(),
            output.display(),
            format_size(stats.total_size),
            stats.instruction_count
        );
    }

    Ok(())
}

/// Print a pipeline stage start message.
fn print_stage(action: &str, description: &str) {
    print!(
        "  {} {} {}... ",
        "→".blue(),
        action.bold(),
        description.dimmed()
    );
    use std::io::Write;
    std::io::stdout().flush().ok();
}

/// Print a pipeline stage completion.
fn print_stage_done(elapsed: std::time::Duration) {
    println!("{} ({:.2?})", "done".green(), elapsed);
}

/// Format a size in bytes as human-readable.
fn format_size(bytes: usize) -> String {
    if bytes >= 1024 * 1024 {
        format!("{:.2} MB", bytes as f64 / 1024.0 / 1024.0)
    } else if bytes >= 1024 {
        format!("{:.2} KB", bytes as f64 / 1024.0)
    } else {
        format!("{bytes} B")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_compiler::{DType, OpKind, OpNode};
    use tempfile::tempdir;

    fn create_test_graph() -> OperationGraph {
        let mut graph = OperationGraph::new();

        // Input -> ReLU -> Output
        let input = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
        let relu = OpNode::new(1, OpKind::Relu, vec![4], DType::F32);
        let output = OpNode::new(2, OpKind::Output, vec![4], DType::F32);

        graph.add_node(input);
        graph.add_node(relu);
        graph.add_node(output);

        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        graph.add_input("x", 0);
        graph.add_output("y", 2);

        graph
    }

    #[test]
    fn test_compile_graph_to_holb() {
        let graph = create_test_graph();
        let dir = tempdir().unwrap();
        let output = dir.path().join("test.holb");

        let metadata = PlanMetadata {
            name: "test".to_string(),
            version: "1.0.0".to_string(),
            author: None,
            description: None,
        };

        let result = compile_graph(&graph, &output, &metadata, false);
        assert!(result.is_ok(), "compile_graph failed: {result:?}");

        // Verify file was created
        assert!(output.exists());

        // Verify magic bytes
        let bytes = std::fs::read(&output).unwrap();
        assert_eq!(&bytes[0..4], b"HOLB");
    }

    #[test]
    fn test_compile_empty_graph() {
        let graph = OperationGraph::new();
        let dir = tempdir().unwrap();
        let output = dir.path().join("empty.holb");

        let metadata = PlanMetadata::default();

        let result = compile_graph(&graph, &output, &metadata, false);
        assert!(result.is_ok());
    }
}
