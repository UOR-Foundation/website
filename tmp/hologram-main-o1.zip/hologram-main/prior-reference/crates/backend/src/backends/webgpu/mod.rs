//! WebGPU backend implementation.
//!
//! This module provides the WebGPU backend for cross-platform GPU compute using wgpu.
//! Only available with the `webgpu` feature enabled.

mod gpu;
pub mod textures;

pub use gpu::WebGpuBackend;
pub use textures::{WebGpuActivationTextures, WebGpuTextureHandle};
