//! Registry error types.

use std::path::PathBuf;

/// Registry error type.
#[derive(Debug, thiserror::Error)]
pub enum RegistryError {
    /// Invalid layer reference format.
    #[error("invalid layer reference: {0}")]
    InvalidRef(String),

    /// Layer not found in registry.
    #[error("layer not found: {0}")]
    NotFound(String),

    /// Content hash mismatch (data corruption).
    #[error("hash mismatch: expected {expected}, got {actual}")]
    HashMismatch {
        /// Expected hash (hex).
        expected: String,
        /// Actual computed hash (hex).
        actual: String,
    },

    /// Invalid hash format.
    #[error("invalid hash: {0}")]
    InvalidHash(String),

    /// Name index corrupted or invalid.
    #[error("index corrupted: {0}")]
    IndexCorrupted(String),

    /// IO error.
    #[error("io error at {path}: {source}")]
    Io {
        /// Path involved in the operation.
        path: PathBuf,
        /// Underlying IO error.
        #[source]
        source: std::io::Error,
    },

    /// JSON serialization/deserialization error.
    #[error("json error: {0}")]
    Json(#[from] serde_json::Error),

    /// Network error (HTTP request failure).
    #[error("network error: {0}")]
    Network(String),

    /// Invalid response from remote registry.
    #[error("invalid response: {0}")]
    InvalidResponse(String),
}

/// Result type for registry operations.
pub type Result<T> = std::result::Result<T, RegistryError>;

impl RegistryError {
    /// Create an IO error with path context.
    pub fn io(path: impl Into<PathBuf>, source: std::io::Error) -> Self {
        Self::Io {
            path: path.into(),
            source,
        }
    }

    /// Check if this is a NotFound error.
    #[must_use]
    pub const fn is_not_found(&self) -> bool {
        matches!(self, Self::NotFound(_))
    }

    /// Check if this is an IO error.
    #[must_use]
    pub const fn is_io(&self) -> bool {
        matches!(self, Self::Io { .. })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_invalid_ref_display() {
        let err = RegistryError::InvalidRef("bad:ref:format".to_string());
        assert_eq!(err.to_string(), "invalid layer reference: bad:ref:format");
    }

    #[test]
    fn test_not_found_display() {
        let err = RegistryError::NotFound("abc123".to_string());
        assert_eq!(err.to_string(), "layer not found: abc123");
    }

    #[test]
    fn test_hash_mismatch_display() {
        let err = RegistryError::HashMismatch {
            expected: "abc".to_string(),
            actual: "def".to_string(),
        };
        assert_eq!(err.to_string(), "hash mismatch: expected abc, got def");
    }

    #[test]
    fn test_io_error_with_path() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "file not found");
        let err = RegistryError::io("/path/to/file", io_err);
        assert!(err.to_string().contains("/path/to/file"));
    }

    #[test]
    fn test_is_not_found() {
        let err = RegistryError::NotFound("test".to_string());
        assert!(err.is_not_found());

        let err2 = RegistryError::InvalidRef("test".to_string());
        assert!(!err2.is_not_found());
    }

    #[test]
    fn test_is_io() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "test");
        let err = RegistryError::io("/test", io_err);
        assert!(err.is_io());

        let err2 = RegistryError::NotFound("test".to_string());
        assert!(!err2.is_io());
    }
}
