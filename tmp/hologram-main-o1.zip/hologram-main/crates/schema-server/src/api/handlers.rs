//! API request handlers.

use crate::error::Result;
use crate::html;
use crate::schema::{GaugeLevel, ListResponse, MutationPreview, MutationRequest};
use crate::state::AppState;
use axum::{
    extract::{Path, Query, State},
    http::header::ACCEPT,
    http::HeaderMap,
    response::{Html, IntoResponse, Response},
    Json,
};
use serde::Deserialize;
use std::sync::Arc;

/// Pagination query parameters.
#[derive(Debug, Deserialize)]
pub struct PaginationParams {
    #[serde(default)]
    pub offset: usize,
    #[serde(default = "default_limit")]
    pub limit: usize,
}

fn default_limit() -> usize {
    50
}

/// Check if request accepts HTML.
fn accepts_html(headers: &HeaderMap) -> bool {
    headers
        .get(ACCEPT)
        .and_then(|v| v.to_str().ok())
        .map(|s| s.contains("text/html"))
        .unwrap_or(false)
}

/// Home page / API info.
pub async fn home(headers: HeaderMap, State(state): State<Arc<AppState>>) -> Response {
    if accepts_html(&headers) {
        let schemas = state.store.list_schemas();
        Html(html::render_home(&schemas)).into_response()
    } else {
        Json(serde_json::json!({
            "name": "Hologram Schema Server",
            "version": "0.1.0",
            "endpoints": {
                "schemas": "/api/schemas",
                "taxons": "/api/taxons",
                "constants": "/api/constants",
                "domains": "/api/domains",
                "gauge_tower": "/api/gauge-tower",
                "query_byte": "/api/query/byte/:value",
                "query_ring": "/api/query/ring/:value",
                "query_ring_op": "/api/query/ring/:op/:a/:b",
                "query_activation": "/api/query/activation/:value",
                "query_dynamic": "/api/query (POST)",
                "query_byte_range": "POST /api/query: byteRange(from, to) { ... }",
                "query_ring_range": "POST /api/query: ringRange(from, to) { ... }",
                "query_activation_range": "POST /api/query: activationRange(from, to) { ... }"
            }
        }))
        .into_response()
    }
}

/// List all schemas.
pub async fn list_schemas(headers: HeaderMap, State(state): State<Arc<AppState>>) -> Response {
    let schemas = state.store.list_schemas();
    if accepts_html(&headers) {
        Html(html::render_schemas_list(&schemas)).into_response()
    } else {
        Json(schemas).into_response()
    }
}

/// Get schema by ID.
pub async fn get_schema(
    headers: HeaderMap,
    Path(id): Path<String>,
    State(state): State<Arc<AppState>>,
) -> Result<Response> {
    let schema = state.store.get_schema(&id)?;
    if accepts_html(&headers) {
        let info = state.store.list_schemas().into_iter().find(|s| s.id == id);
        Ok(Html(html::render_schema_detail(info.as_ref(), schema)).into_response())
    } else {
        Ok(Json(schema).into_response())
    }
}

/// Get schema context.
pub async fn get_schema_context(
    Path(id): Path<String>,
    State(state): State<Arc<AppState>>,
) -> Result<Json<serde_json::Value>> {
    let context = state.store.get_schema_context(&id)?;
    Ok(Json(context))
}

/// Get schema graph.
pub async fn get_schema_graph(
    Path(id): Path<String>,
    State(state): State<Arc<AppState>>,
) -> Result<Response> {
    let entities = state.store.get_schema_graph(&id)?;
    Ok(Json(entities).into_response())
}

/// List all taxons.
pub async fn list_taxons(
    headers: HeaderMap,
    Query(params): Query<PaginationParams>,
    State(state): State<Arc<AppState>>,
) -> Response {
    let response = state.store.list_taxons(params.offset, params.limit);
    if accepts_html(&headers) {
        Html(html::render_taxons_list(&response)).into_response()
    } else {
        Json(response).into_response()
    }
}

/// Get taxon by value.
pub async fn get_taxon(
    headers: HeaderMap,
    Path(value): Path<u8>,
    State(state): State<Arc<AppState>>,
) -> Result<Response> {
    let taxon = state.store.get_taxon(value)?;
    if accepts_html(&headers) {
        Ok(Html(html::render_taxon_detail(&taxon)).into_response())
    } else {
        Ok(Json(taxon).into_response())
    }
}

/// Get taxons by domain.
pub async fn get_taxons_by_domain(
    headers: HeaderMap,
    Path(domain): Path<String>,
    State(state): State<Arc<AppState>>,
) -> Result<Response> {
    let taxons = state.store.get_taxons_by_domain(&domain)?;
    if accepts_html(&headers) {
        let response = ListResponse::new(taxons.clone(), taxons.len(), 0, taxons.len());
        Ok(Html(html::render_taxons_list(&response)).into_response())
    } else {
        Ok(Json(taxons).into_response())
    }
}

/// List all domains.
pub async fn list_domains(headers: HeaderMap, State(state): State<Arc<AppState>>) -> Response {
    let domains = state.store.list_domains();
    if accepts_html(&headers) {
        Html(html::render_domains_list(&domains)).into_response()
    } else {
        Json(domains).into_response()
    }
}

/// Get domain by name.
pub async fn get_domain(
    headers: HeaderMap,
    Path(name): Path<String>,
    State(state): State<Arc<AppState>>,
) -> Result<Response> {
    let domain = state.store.get_domain(&name)?;
    if accepts_html(&headers) {
        Ok(Html(html::render_domain_detail(&domain)).into_response())
    } else {
        Ok(Json(domain).into_response())
    }
}

/// List all constants.
pub async fn list_constants(headers: HeaderMap, State(state): State<Arc<AppState>>) -> Response {
    let constants = state.store.list_constants();
    if accepts_html(&headers) {
        Html(html::render_constants_list(&constants)).into_response()
    } else {
        Json(constants).into_response()
    }
}

/// Get constant by name.
pub async fn get_constant(
    headers: HeaderMap,
    Path(name): Path<String>,
    State(state): State<Arc<AppState>>,
) -> Result<Response> {
    let constant = state.store.get_constant(&name)?;
    if accepts_html(&headers) {
        Ok(Html(html::render_constant_detail(&constant)).into_response())
    } else {
        Ok(Json(constant).into_response())
    }
}

/// Update a constant (mutation).
pub async fn update_constant(
    Path(name): Path<String>,
    State(state): State<Arc<AppState>>,
    Json(req): Json<MutationRequest>,
) -> Result<Json<MutationPreview>> {
    crate::schema::validation::validate_constant_mutation(&name, req.value)?;
    let preview = state.store.update_constant(&name, req.value)?;
    Ok(Json(preview))
}

/// Preview a mutation without applying.
pub async fn preview_mutation(
    State(state): State<Arc<AppState>>,
    Json(req): Json<PreviewMutationRequest>,
) -> Result<Json<MutationPreview>> {
    crate::schema::validation::validate_constant_mutation(&req.name, req.value)?;
    let preview = state.store.preview_mutation(&req.name, req.value)?;
    Ok(Json(preview))
}

/// Request body for mutation preview.
#[derive(Debug, Deserialize)]
pub struct PreviewMutationRequest {
    pub name: String,
    pub value: i64,
}

/// Reset all constants to original values.
pub async fn reset_constants(State(state): State<Arc<AppState>>) -> Json<serde_json::Value> {
    state.store.reset_constants();
    Json(
        serde_json::json!({ "status": "reset", "message": "All constants reset to original values" }),
    )
}

/// Get gauge tower.
pub async fn get_gauge_tower(headers: HeaderMap, State(state): State<Arc<AppState>>) -> Response {
    let tower = state.store.get_gauge_tower();
    if accepts_html(&headers) {
        Html(html::render_gauge_tower(&tower)).into_response()
    } else {
        Json(tower).into_response()
    }
}

/// Get gauge tower levels.
pub async fn get_gauge_levels(State(state): State<Arc<AppState>>) -> Json<Vec<GaugeLevel>> {
    Json(state.store.get_gauge_tower().levels)
}

/// Get specific gauge level.
pub async fn get_gauge_level(
    headers: HeaderMap,
    Path(index): Path<usize>,
    State(state): State<Arc<AppState>>,
) -> Result<Response> {
    let level = state.store.get_gauge_level(index)?;
    if accepts_html(&headers) {
        Ok(Html(html::render_gauge_level(&level)).into_response())
    } else {
        Ok(Json(level).into_response())
    }
}

// ============================================================================
// Query-layer handlers (LUT-backed, O(1))
// ============================================================================

/// Resolve all byte observables via LUT lookup.
pub async fn resolve_byte(Path(value): Path<u8>) -> Json<crate::generated::ByteDto> {
    Json(crate::generated::ByteDto::resolve(value))
}

/// Resolve ring element (mod 96 value).
pub async fn resolve_ring(Path(value): Path<u8>) -> Json<crate::generated::ElementDto> {
    Json(crate::generated::ElementDto::resolve(value))
}

/// Compute a ring operation (add/sub/mul) on two values.
pub async fn ring_op(Path((op, a, b)): Path<(String, u8, u8)>) -> Result<Json<serde_json::Value>> {
    use crate::generated::{ElementResolver, LutElementResolver};
    let resolver = LutElementResolver;
    let result = match op.as_str() {
        "add" => resolver.add(a, b),
        "sub" => resolver.sub(a, b),
        "mul" => resolver.mul(a, b),
        _ => {
            return Err(crate::error::ServerError::ValidationError(format!(
                "Unknown ring operation: {op}. Valid: add, sub, mul"
            )))
        }
    };
    Ok(Json(serde_json::json!({
        "op": op,
        "a": a,
        "b": b,
        "result": result
    })))
}

/// Resolve all activation function outputs via LUT lookup.
pub async fn resolve_activation(Path(value): Path<u8>) -> Json<crate::generated::ActivationDto> {
    Json(crate::generated::ActivationDto::resolve(value))
}

/// Execute a dynamic query (GraphQL-like subset).
/// Supports content negotiation: `Accept: application/x-ndjson` returns NDJSON.
pub async fn execute_query(headers: HeaderMap, body: String) -> Result<Response> {
    let doc = hologram_query::parse(&body).map_err(|e| {
        crate::error::ServerError::ValidationError(format!("query parse error: {e}"))
    })?;

    let wants_ndjson = headers
        .get(ACCEPT)
        .and_then(|v| v.to_str().ok())
        .map(|s| s.contains("application/x-ndjson"))
        .unwrap_or(false);

    if wants_ndjson {
        let rows = hologram_query::execute_rows(&doc)
            .map_err(|e| crate::error::ServerError::ValidationError(format!("query error: {e}")))?;
        let ndjson = hologram_query::to_ndjson(&rows);
        Ok((
            [(axum::http::header::CONTENT_TYPE, "application/x-ndjson")],
            ndjson,
        )
            .into_response())
    } else {
        let result = hologram_query::execute(&doc)
            .map_err(|e| crate::error::ServerError::ValidationError(format!("query error: {e}")))?;
        Ok(Json(result).into_response())
    }
}
