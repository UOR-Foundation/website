//! Q1 Datum integration with derivation chains.
//!
//! This module provides integration between the generated `Datum16` type from
//! `ontology-gen` and the derivation chain system. It enables creating certified
//! proofs for Q1 datum computations.
//!
//! # Example
//!
//! ```
//! use hologram_derivation::datum::{Datum16Proof, datum_derivation_chain};
//! use hologram_derivation::ToJsonLd;
//! use ontology_gen::Datum16;
//!
//! // Create a datum and generate its derivation proof
//! let datum = Datum16::from_value(0x1234);
//! let proof = Datum16Proof::new(datum);
//!
//! // Verify computed observables
//! assert_eq!(proof.stratum, 5);
//! assert!(proof.to_jsonld()["@type"].as_str().unwrap().contains("DatumProof"));
//! ```

use crate::{DerivationChain, DerivationStep, StepKind, ToJsonLd};
use ontology_gen::Datum16;

/// A certified proof for Q1 datum observables.
///
/// Contains the datum value along with all computed observables,
/// packaged for verification and JSON-LD emission.
#[derive(Debug, Clone)]
pub struct Datum16Proof {
    /// The datum value (0-65535).
    pub value: u16,
    /// Hamming weight (0-16).
    pub stratum: u8,
    /// Bit positions of 1-bits.
    pub spectrum: Vec<u8>,
    /// Braille glyph representation.
    pub glyph: String,
    /// Hamming distance to successor.
    pub curvature: u8,
    /// High byte.
    pub high_byte: u8,
    /// Low byte.
    pub low_byte: u8,
}

impl Datum16Proof {
    /// Create a proof by computing all observables for a datum.
    pub fn new(datum: Datum16) -> Self {
        Self {
            value: datum.value,
            stratum: datum.stratum(),
            spectrum: datum.spectrum(),
            glyph: datum.glyph(),
            curvature: datum.curvature(),
            high_byte: datum.high_byte(),
            low_byte: datum.low_byte(),
        }
    }

    /// Create a proof from a raw u16 value.
    pub fn from_value(value: u16) -> Self {
        Self::new(Datum16::from_value(value))
    }

    /// Verify that the proof's observables match recomputed values.
    pub fn verify(&self) -> bool {
        let datum = Datum16::from_value(self.value);
        self.stratum == datum.stratum()
            && self.spectrum == datum.spectrum()
            && self.curvature == datum.curvature()
            && self.high_byte == datum.high_byte()
            && self.low_byte == datum.low_byte()
    }
}

impl ToJsonLd for Datum16Proof {
    fn to_jsonld(&self) -> serde_json::Value {
        serde_json::json!({
            "@context": {
                "datum": "https://uor.foundation/datum/",
                "proof": "https://uor.foundation/proof/"
            },
            "@type": "proof:DatumProof",
            "datum:value": self.value,
            "datum:stratum": self.stratum,
            "datum:spectrum": self.spectrum.iter().map(|p| p.to_string()).collect::<Vec<_>>().join(","),
            "datum:glyph": self.glyph,
            "datum:curvature": self.curvature,
            "datum:highByte": self.high_byte,
            "datum:lowByte": self.low_byte,
            "proof:verified": self.verify()
        })
    }

    fn jsonld_type() -> &'static str {
        "proof:DatumProof"
    }
}

/// Create a derivation chain documenting Q1 datum observable computation.
///
/// The chain records each observable computation as a step:
/// 1. Type declaration (Q1 Datum)
/// 2. Stratum computation (Hamming weight)
/// 3. Spectrum extraction (bit positions)
/// 4. Glyph encoding (Braille)
/// 5. Curvature computation (distance to successor)
pub fn datum_derivation_chain(datum: Datum16, timestamp: &str) -> DerivationChain {
    let id = format!("https://uor.foundation/datum/proof/{}", datum.value);
    let label = format!("Q1 Datum {} Observable Derivation", datum.value);

    let mut chain = DerivationChain::new(&id, &label)
        .with_description(format!(
            "Derivation of observables for Q1 datum value {}",
            datum.value
        ))
        .with_timestamp(timestamp);

    // Step 0: Type declaration
    chain.add_step(
        DerivationStep::new(0, "Declare Q1 Datum type", StepKind::TypeDeclaration)
            .with_input(serde_json::json!({
                "value": datum.value,
                "quantumLevel": 1,
                "precisionBits": 16
            }))
            .with_output(serde_json::json!({
                "type": "datum:Q1Datum",
                "highByte": datum.high_byte(),
                "lowByte": datum.low_byte()
            }))
            .with_assertion("Value is a valid 16-bit unsigned integer"),
    );

    // Step 1: Stratum computation
    chain.add_step(
        DerivationStep::new(1, "Compute stratum (Hamming weight)", StepKind::Compute)
            .with_input(serde_json::json!({
                "value": datum.value,
                "binary": format!("{:016b}", datum.value)
            }))
            .with_output(serde_json::json!({
                "stratum": datum.stratum()
            }))
            .with_assertion(format!(
                "stratum({}) = popcount({:016b}) = {}",
                datum.value,
                datum.value,
                datum.stratum()
            )),
    );

    // Step 2: Spectrum extraction
    let spectrum = datum.spectrum();
    chain.add_step(
        DerivationStep::new(2, "Extract spectrum (bit positions)", StepKind::Compute)
            .with_input(serde_json::json!({
                "value": datum.value,
                "stratum": datum.stratum()
            }))
            .with_output(serde_json::json!({
                "spectrum": spectrum
            }))
            .with_assertion(format!("Bit positions with value 1: {:?}", spectrum)),
    );

    // Step 3: Glyph encoding
    chain.add_step(
        DerivationStep::new(3, "Encode Braille glyph", StepKind::Compute)
            .with_input(serde_json::json!({
                "highByte": datum.high_byte(),
                "lowByte": datum.low_byte()
            }))
            .with_output(serde_json::json!({
                "glyph": datum.glyph()
            }))
            .with_assertion(format!(
                "Braille(0x{:02X}) + Braille(0x{:02X}) = '{}'",
                datum.high_byte(),
                datum.low_byte(),
                datum.glyph()
            )),
    );

    // Step 4: Curvature computation
    let successor = datum.value.wrapping_add(1);
    chain.add_step(
        DerivationStep::new(
            4,
            "Compute curvature (Hamming distance to successor)",
            StepKind::Compute,
        )
        .with_input(serde_json::json!({
            "value": datum.value,
            "successor": successor
        }))
        .with_output(serde_json::json!({
            "curvature": datum.curvature(),
            "xor": datum.value ^ successor
        }))
        .with_assertion(format!(
            "curvature({}) = popcount({} XOR {}) = popcount({}) = {}",
            datum.value,
            datum.value,
            successor,
            datum.value ^ successor,
            datum.curvature()
        )),
    );

    // Step 5: Certificate emission
    chain.add_step(
        DerivationStep::new(5, "Emit datum certificate", StepKind::CertificateEmission)
            .with_input(serde_json::json!({
                "value": datum.value,
                "stratum": datum.stratum(),
                "spectrum": spectrum,
                "glyph": datum.glyph(),
                "curvature": datum.curvature()
            }))
            .with_output(serde_json::json!({
                "@type": "datum:Q1Datum",
                "verified": true
            }))
            .with_assertion("All observables computed and verified"),
    );

    chain
}

/// Emit a complete Q1 datum proof as JSON-LD.
///
/// Combines the datum proof and its derivation chain into a single document.
pub fn emit_datum_proof(datum: Datum16, timestamp: &str) -> serde_json::Value {
    let proof = Datum16Proof::new(datum);
    let chain = datum_derivation_chain(datum, timestamp);

    serde_json::json!({
        "@context": {
            "datum": "https://uor.foundation/datum/",
            "derivation": "https://uor.foundation/derivation/",
            "proof": "https://uor.foundation/proof/",
            "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
            "xsd": "http://www.w3.org/2001/XMLSchema#"
        },
        "@graph": [
            proof.to_jsonld(),
            chain.to_jsonld()
        ]
    })
}

/// Batch process multiple datums and emit proofs.
pub fn emit_datum_batch(
    values: impl IntoIterator<Item = u16>,
    timestamp: &str,
) -> Vec<serde_json::Value> {
    values
        .into_iter()
        .map(|v| emit_datum_proof(Datum16::from_value(v), timestamp))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_datum16_proof_new() {
        let datum = Datum16::from_value(0x1234);
        let proof = Datum16Proof::new(datum);

        assert_eq!(proof.value, 0x1234);
        assert_eq!(proof.stratum, 5); // popcount(0x1234) = 5
        assert_eq!(proof.high_byte, 0x12);
        assert_eq!(proof.low_byte, 0x34);
    }

    #[test]
    fn test_datum16_proof_verify() {
        let proof = Datum16Proof::from_value(0xFFFF);
        assert!(proof.verify());

        let proof = Datum16Proof::from_value(0);
        assert!(proof.verify());
    }

    #[test]
    fn test_datum16_proof_to_jsonld() {
        let proof = Datum16Proof::from_value(0x1234);
        let json = proof.to_jsonld();

        assert_eq!(json["@type"], "proof:DatumProof");
        assert_eq!(json["datum:value"], 0x1234);
        assert_eq!(json["proof:verified"], true);
    }

    #[test]
    fn test_datum_derivation_chain() {
        let datum = Datum16::from_value(0x1234);
        let chain = datum_derivation_chain(datum, "2026-02-06T00:00:00Z");

        assert_eq!(chain.steps.len(), 6);
        assert_eq!(chain.steps[0].kind, StepKind::TypeDeclaration);
        assert_eq!(chain.steps[5].kind, StepKind::CertificateEmission);
    }

    #[test]
    fn test_emit_datum_proof() {
        let datum = Datum16::from_value(0x1234);
        let json = emit_datum_proof(datum, "2026-02-06T00:00:00Z");

        assert!(json["@context"].is_object());
        assert!(json["@graph"].is_array());
        assert_eq!(json["@graph"].as_array().unwrap().len(), 2);
    }

    #[test]
    fn test_emit_datum_batch() {
        let values = vec![0, 1, 255, 256, 65535];
        let proofs = emit_datum_batch(values.clone(), "2026-02-06T00:00:00Z");

        assert_eq!(proofs.len(), 5);
        for (i, proof) in proofs.iter().enumerate() {
            let value = proof["@graph"][0]["datum:value"].as_u64().unwrap();
            assert_eq!(value as u16, values[i]);
        }
    }

    #[test]
    fn test_spectrum_correctness() {
        // Test known bit patterns
        let proof = Datum16Proof::from_value(0b1010_0101_0000_1111);
        // Bits set: 0,1,2,3, 8,10, 13,15
        assert_eq!(proof.spectrum, vec![0, 1, 2, 3, 8, 10, 13, 15]);
    }

    #[test]
    fn test_curvature_patterns() {
        // Curvature of 0 = popcount(0 XOR 1) = 1
        assert_eq!(Datum16Proof::from_value(0).curvature, 1);

        // Curvature of 0xFF = popcount(0xFF XOR 0x100) = 9
        assert_eq!(Datum16Proof::from_value(0xFF).curvature, 9);

        // Curvature of 0xFFFF = popcount(0xFFFF XOR 0) = 16 (wrapping)
        assert_eq!(Datum16Proof::from_value(0xFFFF).curvature, 16);
    }
}
