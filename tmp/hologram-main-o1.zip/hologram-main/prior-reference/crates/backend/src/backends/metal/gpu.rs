//! Actual Metal-based GPU implementation for macOS.

use crate::{
    BackendError, BackendType, BufferHandle, ComputeBackend, LaunchConfig, ProgramBackend,
};
use hologram_isa::{Program, Type};
use metal::{Buffer, CommandQueue, ComputePipelineState, Device, MTLResourceOptions};
use rustc_hash::FxHashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::RwLock;

/// Metal Shading Language (MSL) compute shader for matrix multiplication.
const MATMUL_SHADER: &str = r#"
#include <metal_stdlib>
using namespace metal;

struct MatMulParams {
    uint m;
    uint n;
    uint k;
    uint lda;
    uint ldb;
    uint ldc;
};

kernel void matmul(
    device const float* a [[buffer(0)]],
    device const float* b [[buffer(1)]],
    device float* c [[buffer(2)]],
    constant MatMulParams& params [[buffer(3)]],
    uint2 gid [[thread_position_in_grid]]
) {
    uint row = gid.x;
    uint col = gid.y;

    if (row >= params.m || col >= params.n) {
        return;
    }

    float sum = 0.0f;
    for (uint i = 0; i < params.k; i++) {
        sum += a[row * params.lda + i] * b[i * params.ldb + col];
    }
    c[row * params.ldc + col] = sum;
}
"#;

/// MSL tiled matrix multiplication shader for better performance.
const MATMUL_TILED_SHADER: &str = r#"
#include <metal_stdlib>
using namespace metal;

constant uint TILE_SIZE = 16;

struct MatMulParams {
    uint m;
    uint n;
    uint k;
    uint lda;
    uint ldb;
    uint ldc;
};

kernel void matmul_tiled(
    device const float* a [[buffer(0)]],
    device const float* b [[buffer(1)]],
    device float* c [[buffer(2)]],
    constant MatMulParams& params [[buffer(3)]],
    uint2 gid [[thread_position_in_grid]],
    uint2 lid [[thread_position_in_threadgroup]],
    uint2 tgid [[threadgroup_position_in_grid]]
) {
    // Threadgroup (workgroup) shared memory
    threadgroup float tile_a[TILE_SIZE][TILE_SIZE];
    threadgroup float tile_b[TILE_SIZE][TILE_SIZE];

    uint row = gid.x;
    uint col = gid.y;
    uint local_row = lid.x;
    uint local_col = lid.y;

    float sum = 0.0f;
    uint num_tiles = (params.k + TILE_SIZE - 1) / TILE_SIZE;

    for (uint t = 0; t < num_tiles; t++) {
        // Load tile of A
        uint a_col = t * TILE_SIZE + local_col;
        if (row < params.m && a_col < params.k) {
            tile_a[local_row][local_col] = a[row * params.lda + a_col];
        } else {
            tile_a[local_row][local_col] = 0.0f;
        }

        // Load tile of B
        uint b_row = t * TILE_SIZE + local_row;
        if (b_row < params.k && col < params.n) {
            tile_b[local_row][local_col] = b[b_row * params.ldb + col];
        } else {
            tile_b[local_row][local_col] = 0.0f;
        }

        threadgroup_barrier(mem_flags::mem_threadgroup);

        // Compute partial dot product
        for (uint i = 0; i < TILE_SIZE; i++) {
            sum += tile_a[local_row][i] * tile_b[i][local_col];
        }

        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    if (row < params.m && col < params.n) {
        c[row * params.ldc + col] = sum;
    }
}
"#;

/// MSL vector add shader.
const VECTOR_ADD_SHADER: &str = r#"
#include <metal_stdlib>
using namespace metal;

kernel void vector_add(
    device const uchar* a [[buffer(0)]],
    device const uchar* b [[buffer(1)]],
    device uchar* dst [[buffer(2)]],
    constant uint& count [[buffer(3)]],
    uint gid [[thread_position_in_grid]]
) {
    if (gid >= count) {
        return;
    }
    dst[gid] = a[gid] + b[gid]; // Wrapping add in Metal
}
"#;

/// MSL vector mul shader.
const VECTOR_MUL_SHADER: &str = r#"
#include <metal_stdlib>
using namespace metal;

kernel void vector_mul(
    device const uchar* a [[buffer(0)]],
    device const uchar* b [[buffer(1)]],
    device uchar* dst [[buffer(2)]],
    constant uint& count [[buffer(3)]],
    uint gid [[thread_position_in_grid]]
) {
    if (gid >= count) {
        return;
    }
    dst[gid] = a[gid] * b[gid]; // Wrapping mul in Metal
}
"#;

use super::gpu_constants::{GPU_TILE_SIZE, TILED_MATMUL_THRESHOLD};

/// GPU buffer wrapper that tracks the Metal buffer and its size.
struct GpuBuffer {
    buffer: Buffer,
    size: usize,
}

/// Metal GPU backend for macOS.
///
/// Uses Metal.framework for GPU acceleration on Apple hardware.
/// Uses interior mutability (RwLock, AtomicU64) for thread-safe access.
pub struct MetalBackend {
    device: Device,
    command_queue: CommandQueue,
    adapter_name: String,
    buffers: RwLock<FxHashMap<u64, GpuBuffer>>,
    next_handle: AtomicU64,
    matmul_pipeline: ComputePipelineState,
    matmul_tiled_pipeline: ComputePipelineState,
    vector_add_pipeline: ComputePipelineState,
    vector_mul_pipeline: ComputePipelineState,
}

impl MetalBackend {
    /// Create a new Metal backend.
    ///
    /// Initializes Metal with the system default device.
    /// Returns an error if no Metal device is available.
    #[must_use]
    pub fn new() -> Self {
        let device = Device::system_default().expect("Failed to get Metal device");
        let adapter_name = device.name().to_string();
        let command_queue = device.new_command_queue();

        // Compile shaders
        let matmul_pipeline = Self::compile_shader(&device, MATMUL_SHADER, "matmul");
        let matmul_tiled_pipeline =
            Self::compile_shader(&device, MATMUL_TILED_SHADER, "matmul_tiled");
        let vector_add_pipeline = Self::compile_shader(&device, VECTOR_ADD_SHADER, "vector_add");
        let vector_mul_pipeline = Self::compile_shader(&device, VECTOR_MUL_SHADER, "vector_mul");

        Self {
            device,
            command_queue,
            adapter_name,
            buffers: RwLock::new(FxHashMap::default()),
            next_handle: AtomicU64::new(0),
            matmul_pipeline,
            matmul_tiled_pipeline,
            vector_add_pipeline,
            vector_mul_pipeline,
        }
    }

    fn compile_shader(device: &Device, source: &str, function_name: &str) -> ComputePipelineState {
        let library = device
            .new_library_with_source(source, &metal::CompileOptions::new())
            .expect("Failed to compile Metal shader");
        let function = library
            .get_function(function_name, None)
            .expect("Failed to get shader function");
        device
            .new_compute_pipeline_state_with_function(&function)
            .expect("Failed to create compute pipeline")
    }

    /// Check if Metal is available on this system.
    #[must_use]
    pub fn is_available() -> bool {
        Device::system_default().is_some()
    }

    /// Get the adapter name.
    #[must_use]
    pub fn adapter_name(&self) -> &str {
        &self.adapter_name
    }

    fn next_buffer_handle(&self) -> BufferHandle {
        let id = self.next_handle.fetch_add(1, Ordering::Relaxed);
        BufferHandle::new(id)
    }

    /// Read buffer data from GPU to CPU.
    fn read_buffer(&self, handle: BufferHandle) -> Result<Vec<u8>, BackendError> {
        let buffers = self.buffers.read().unwrap();
        let gpu_buf = buffers
            .get(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;

        let ptr = gpu_buf.buffer.contents() as *const u8;
        let data = unsafe { std::slice::from_raw_parts(ptr, gpu_buf.size) }.to_vec();
        Ok(data)
    }

    /// Get buffer data as f32 slice.
    #[cfg(test)]
    fn get_buffer_f32(&self, handle: BufferHandle) -> Result<Vec<f32>, BackendError> {
        let data = self.read_buffer(handle)?;
        if data.len() % 4 != 0 {
            return Err(BackendError::buffer("Buffer size not aligned to f32"));
        }
        let floats: Vec<f32> = data
            .chunks_exact(4)
            .map(|chunk| f32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]))
            .collect();
        Ok(floats)
    }
}

impl Default for MetalBackend {
    fn default() -> Self {
        Self::new()
    }
}

impl ProgramBackend for MetalBackend {
    fn backend_type(&self) -> BackendType {
        BackendType::Metal
    }

    fn execute_program(
        &self,
        program: &Program,
        _config: &LaunchConfig,
    ) -> Result<(), BackendError> {
        if program.instructions().is_empty() {
            return Ok(());
        }
        // Full program execution would require compiling instructions to MSL
        // For now, individual operations (matmul, etc.) use dedicated pipelines
        Ok(())
    }

    fn allocate_buffer(&self, size: usize) -> Result<BufferHandle, BackendError> {
        let handle = self.next_buffer_handle();

        let buffer = self
            .device
            .new_buffer(size as u64, MTLResourceOptions::StorageModeShared);

        self.buffers
            .write()
            .unwrap()
            .insert(handle.id(), GpuBuffer { buffer, size });
        Ok(handle)
    }

    fn free_buffer(&self, handle: BufferHandle) -> Result<(), BackendError> {
        self.buffers
            .write()
            .unwrap()
            .remove(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;
        Ok(())
    }

    fn copy_to_buffer(&self, handle: BufferHandle, data: &[u8]) -> Result<(), BackendError> {
        let buffers = self.buffers.read().unwrap();
        let gpu_buf = buffers
            .get(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;

        if data.len() > gpu_buf.size {
            return Err(BackendError::buffer("Data exceeds buffer size"));
        }

        let ptr = gpu_buf.buffer.contents() as *mut u8;
        unsafe {
            std::ptr::copy_nonoverlapping(data.as_ptr(), ptr, data.len());
        }
        Ok(())
    }

    fn copy_from_buffer(&self, handle: BufferHandle, data: &mut [u8]) -> Result<(), BackendError> {
        let read_data = self.read_buffer(handle)?;
        if data.len() > read_data.len() {
            return Err(BackendError::buffer("Request exceeds buffer size"));
        }
        data.copy_from_slice(&read_data[..data.len()]);
        Ok(())
    }

    fn buffer_size(&self, handle: BufferHandle) -> Result<usize, BackendError> {
        self.buffers
            .read()
            .unwrap()
            .get(&handle.id())
            .map(|b| b.size)
            .ok_or(BackendError::InvalidHandle(handle))
    }

    fn synchronize(&self) -> Result<(), BackendError> {
        // Metal automatically synchronizes shared memory buffers
        Ok(())
    }

    fn get_buffer_ptr(&self, _handle: BufferHandle) -> Option<*mut u8> {
        // GPU memory is not directly accessible from CPU
        None
    }
}

impl ComputeBackend for MetalBackend {
    fn fma_scalar_crt_batch(
        &self,
        target: &mut [u8],
        a: &[u8],
        k: u64,
    ) -> Result<(), BackendError> {
        // CPU implementation for this simple operation
        for i in 0..target.len().min(a.len()) {
            target[i] = ((a[i] as u64).wrapping_mul(k) % 256) as u8;
        }
        Ok(())
    }

    fn matmul(
        &self,
        c: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        params: &crate::MatMulParams,
    ) -> Result<(), BackendError> {
        if params.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "matmul only supports F32, got {:?}",
                params.dtype
            )));
        }

        let buffers = self.buffers.read().unwrap();
        let a_buf = &buffers
            .get(&a.id())
            .ok_or(BackendError::InvalidHandle(a))?
            .buffer;
        let b_buf = &buffers
            .get(&b.id())
            .ok_or(BackendError::InvalidHandle(b))?
            .buffer;
        let c_buf = &buffers
            .get(&c.id())
            .ok_or(BackendError::InvalidHandle(c))?
            .buffer;

        // Create params buffer
        #[repr(C)]
        struct MatMulParams {
            m: u32,
            n: u32,
            k: u32,
            lda: u32,
            ldb: u32,
            ldc: u32,
        }

        let lda = if params.trans_a { params.m } else { params.k };
        let ldb = if params.trans_b { params.k } else { params.n };
        let ldc = params.n;

        let uniforms = MatMulParams {
            m: params.m,
            n: params.n,
            k: params.k,
            lda,
            ldb,
            ldc,
        };

        let params_buffer = self.device.new_buffer_with_data(
            &uniforms as *const _ as *const std::ffi::c_void,
            std::mem::size_of::<MatMulParams>() as u64,
            MTLResourceOptions::StorageModeShared,
        );

        // Choose pipeline based on matrix size
        let work_size = params.m.saturating_mul(params.n).saturating_mul(params.k);
        let use_tiled = work_size >= TILED_MATMUL_THRESHOLD && !params.trans_a && !params.trans_b;
        let pipeline = if use_tiled {
            &self.matmul_tiled_pipeline
        } else {
            &self.matmul_pipeline
        };

        // Create command buffer and encoder
        let command_buffer = self.command_queue.new_command_buffer();
        let encoder = command_buffer.new_compute_command_encoder();

        encoder.set_compute_pipeline_state(pipeline);
        encoder.set_buffer(0, Some(a_buf), 0);
        encoder.set_buffer(1, Some(b_buf), 0);
        encoder.set_buffer(2, Some(c_buf), 0);
        encoder.set_buffer(3, Some(&params_buffer), 0);

        // Dispatch
        let thread_group_size = metal::MTLSize::new(GPU_TILE_SIZE as u64, GPU_TILE_SIZE as u64, 1);
        let grid_size = metal::MTLSize::new(
            params.m.div_ceil(GPU_TILE_SIZE) as u64 * GPU_TILE_SIZE as u64,
            params.n.div_ceil(GPU_TILE_SIZE) as u64 * GPU_TILE_SIZE as u64,
            1,
        );

        encoder.dispatch_threads(grid_size, thread_group_size);
        encoder.end_encoding();

        command_buffer.commit();
        command_buffer.wait_until_completed();

        Ok(())
    }

    fn batch_matmul(
        &self,
        c: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        batch: u32,
        params: &crate::MatMulParams,
    ) -> Result<(), BackendError> {
        // For now, loop over batches and call single matmul
        // A proper implementation would use a batched kernel
        let m = params.m as usize;
        let k = params.k as usize;
        let n = params.n as usize;

        let a_stride = m * k;
        let b_stride = k * n;
        let c_stride = m * n;

        for bi in 0..batch as usize {
            // Create temporary handles for each batch slice
            // This is inefficient but correct - a proper implementation would use offsets
            let a_data = self.read_buffer(a)?;
            let b_data = self.read_buffer(b)?;
            let c_data = self.read_buffer(c)?;

            let a_slice = &a_data[bi * a_stride * 4..(bi + 1) * a_stride * 4];
            let b_slice = &b_data[bi * b_stride * 4..(bi + 1) * b_stride * 4];
            let c_slice = c_data[bi * c_stride * 4..(bi + 1) * c_stride * 4].to_vec();

            // Convert to f32
            let a_f32: Vec<f32> = a_slice
                .chunks_exact(4)
                .map(|ch| f32::from_le_bytes([ch[0], ch[1], ch[2], ch[3]]))
                .collect();
            let b_f32: Vec<f32> = b_slice
                .chunks_exact(4)
                .map(|ch| f32::from_le_bytes([ch[0], ch[1], ch[2], ch[3]]))
                .collect();
            let mut c_f32: Vec<f32> = c_slice
                .chunks_exact(4)
                .map(|ch| f32::from_le_bytes([ch[0], ch[1], ch[2], ch[3]]))
                .collect();

            // Use CPU fallback for batch matmul
            crate::backends::cpu::compute::cpu_matmul_f32(&mut c_f32, &a_f32, &b_f32, params);

            // Write back
            let c_bytes: Vec<u8> = c_f32.iter().flat_map(|f| f.to_le_bytes()).collect();
            let buffers = self.buffers.read().unwrap();
            let gpu_buf = buffers.get(&c.id()).ok_or(BackendError::InvalidHandle(c))?;
            let ptr = gpu_buf.buffer.contents() as *mut u8;
            unsafe {
                std::ptr::copy_nonoverlapping(
                    c_bytes.as_ptr(),
                    ptr.add(bi * c_stride * 4),
                    c_bytes.len(),
                );
            }
        }

        Ok(())
    }

    fn conv2d(
        &self,
        output: BufferHandle,
        input: BufferHandle,
        kernel: BufferHandle,
        bias: BufferHandle,
        params: &crate::Conv2DParams,
    ) -> Result<(), BackendError> {
        // Conv2D uses CPU fallback via im2col + gemm. Metal shader would require:
        // - MSL kernel with thread/simdgroup optimizations
        // - Winograd transforms for 3x3 kernels
        // - This CPU path provides correctness; Metal shader is a performance optimization.
        if params.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "conv2d only supports F32, got {:?}",
                params.dtype
            )));
        }

        let input_data = self.read_buffer(input)?;
        let kernel_data = self.read_buffer(kernel)?;
        let bias_data = if !bias.is_null() {
            Some(self.read_buffer(bias)?)
        } else {
            None
        };

        let input_f32: Vec<f32> = input_data
            .chunks_exact(4)
            .map(|ch| f32::from_le_bytes([ch[0], ch[1], ch[2], ch[3]]))
            .collect();
        let kernel_f32: Vec<f32> = kernel_data
            .chunks_exact(4)
            .map(|ch| f32::from_le_bytes([ch[0], ch[1], ch[2], ch[3]]))
            .collect();
        let bias_f32: Option<Vec<f32>> = bias_data.map(|b| {
            b.chunks_exact(4)
                .map(|ch| f32::from_le_bytes([ch[0], ch[1], ch[2], ch[3]]))
                .collect()
        });

        let out_dims = params.output_dims();
        let out_size = out_dims.iter().map(|&d| d as usize).product::<usize>();
        let mut output_f32 = vec![0.0f32; out_size];

        crate::backends::cpu::compute::cpu_conv2d_f32(
            &mut output_f32,
            &input_f32,
            &kernel_f32,
            bias_f32.as_deref(),
            params,
        );

        // Write result back
        let output_bytes: Vec<u8> = output_f32.iter().flat_map(|f| f.to_le_bytes()).collect();
        let buffers = self.buffers.read().unwrap();
        let gpu_buf = buffers
            .get(&output.id())
            .ok_or(BackendError::InvalidHandle(output))?;
        let ptr = gpu_buf.buffer.contents() as *mut u8;
        unsafe {
            std::ptr::copy_nonoverlapping(output_bytes.as_ptr(), ptr, output_bytes.len());
        }

        Ok(())
    }

    fn vector_add(
        &self,
        dst: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        count: usize,
    ) -> Result<(), BackendError> {
        let buffers = self.buffers.read().unwrap();
        let a_buf = &buffers
            .get(&a.id())
            .ok_or(BackendError::InvalidHandle(a))?
            .buffer;
        let b_buf = &buffers
            .get(&b.id())
            .ok_or(BackendError::InvalidHandle(b))?
            .buffer;
        let dst_buf = &buffers
            .get(&dst.id())
            .ok_or(BackendError::InvalidHandle(dst))?
            .buffer;

        let count_buffer = self.device.new_buffer_with_data(
            &(count as u32) as *const _ as *const std::ffi::c_void,
            4,
            MTLResourceOptions::StorageModeShared,
        );

        let command_buffer = self.command_queue.new_command_buffer();
        let encoder = command_buffer.new_compute_command_encoder();

        encoder.set_compute_pipeline_state(&self.vector_add_pipeline);
        encoder.set_buffer(0, Some(a_buf), 0);
        encoder.set_buffer(1, Some(b_buf), 0);
        encoder.set_buffer(2, Some(dst_buf), 0);
        encoder.set_buffer(3, Some(&count_buffer), 0);

        let thread_group_size = metal::MTLSize::new(256, 1, 1);
        let grid_size = metal::MTLSize::new(count.div_ceil(256) as u64 * 256, 1, 1);

        encoder.dispatch_threads(grid_size, thread_group_size);
        encoder.end_encoding();

        command_buffer.commit();
        command_buffer.wait_until_completed();

        Ok(())
    }

    fn vector_mul(
        &self,
        dst: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        count: usize,
    ) -> Result<(), BackendError> {
        let buffers = self.buffers.read().unwrap();
        let a_buf = &buffers
            .get(&a.id())
            .ok_or(BackendError::InvalidHandle(a))?
            .buffer;
        let b_buf = &buffers
            .get(&b.id())
            .ok_or(BackendError::InvalidHandle(b))?
            .buffer;
        let dst_buf = &buffers
            .get(&dst.id())
            .ok_or(BackendError::InvalidHandle(dst))?
            .buffer;

        let count_buffer = self.device.new_buffer_with_data(
            &(count as u32) as *const _ as *const std::ffi::c_void,
            4,
            MTLResourceOptions::StorageModeShared,
        );

        let command_buffer = self.command_queue.new_command_buffer();
        let encoder = command_buffer.new_compute_command_encoder();

        encoder.set_compute_pipeline_state(&self.vector_mul_pipeline);
        encoder.set_buffer(0, Some(a_buf), 0);
        encoder.set_buffer(1, Some(b_buf), 0);
        encoder.set_buffer(2, Some(dst_buf), 0);
        encoder.set_buffer(3, Some(&count_buffer), 0);

        let thread_group_size = metal::MTLSize::new(256, 1, 1);
        let grid_size = metal::MTLSize::new(count.div_ceil(256) as u64 * 256, 1, 1);

        encoder.dispatch_threads(grid_size, thread_group_size);
        encoder.end_encoding();

        command_buffer.commit();
        command_buffer.wait_until_completed();

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_metal_backend_new() {
        if !MetalBackend::is_available() {
            eprintln!("Skipping test: Metal not available");
            return;
        }
        let backend = MetalBackend::new();
        assert_eq!(backend.backend_type(), BackendType::Metal);
    }

    #[test]
    fn test_metal_is_gpu() {
        assert!(BackendType::Metal.is_gpu());
    }

    #[test]
    fn test_metal_allocate_buffer() {
        if !MetalBackend::is_available() {
            eprintln!("Skipping test: Metal not available");
            return;
        }
        let mut backend = MetalBackend::new();
        let handle = backend.allocate_buffer(1024).unwrap();
        assert_eq!(backend.buffer_size(handle).unwrap(), 1024);
    }

    #[test]
    fn test_metal_copy_roundtrip() {
        if !MetalBackend::is_available() {
            eprintln!("Skipping test: Metal not available");
            return;
        }
        let mut backend = MetalBackend::new();
        let handle = backend.allocate_buffer(1024).unwrap();

        let data = vec![10u8, 20, 30, 40, 50];
        backend.copy_to_buffer(handle, &data).unwrap();

        let mut read_data = vec![0u8; 5];
        backend.copy_from_buffer(handle, &mut read_data).unwrap();
        assert_eq!(read_data, data);
    }

    #[test]
    fn test_metal_matmul() {
        if !MetalBackend::is_available() {
            eprintln!("Skipping test: Metal not available");
            return;
        }
        let mut backend = MetalBackend::new();

        // 2x3 * 3x2 = 2x2
        let a: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0];
        let b: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0];

        let a_bytes: Vec<u8> = a.iter().flat_map(|f| f.to_le_bytes()).collect();
        let b_bytes: Vec<u8> = b.iter().flat_map(|f| f.to_le_bytes()).collect();

        let a_handle = backend.allocate_buffer(a_bytes.len()).unwrap();
        let b_handle = backend.allocate_buffer(b_bytes.len()).unwrap();
        let c_handle = backend.allocate_buffer(4 * 4).unwrap(); // 2x2 output

        backend.copy_to_buffer(a_handle, &a_bytes).unwrap();
        backend.copy_to_buffer(b_handle, &b_bytes).unwrap();

        let params = crate::MatMulParams {
            m: 2,
            n: 2,
            k: 3,
            dtype: Type::F32,
            alpha: 1.0,
            beta: 0.0,
            trans_a: false,
            trans_b: false,
        };

        backend
            .matmul(c_handle, a_handle, b_handle, &params)
            .unwrap();

        let c_data = backend.get_buffer_f32(c_handle).unwrap();
        // Expected: [[22, 28], [49, 64]]
        assert!((c_data[0] - 22.0).abs() < 0.01);
        assert!((c_data[1] - 28.0).abs() < 0.01);
        assert!((c_data[2] - 49.0).abs() < 0.01);
        assert!((c_data[3] - 64.0).abs() < 0.01);
    }
}
