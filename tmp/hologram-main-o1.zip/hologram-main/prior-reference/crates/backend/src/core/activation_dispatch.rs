//! Backend-specific activation lookup dispatcher.
//!
//! This module provides a unified interface for activation lookups that
//! dispatches to the optimal implementation for each backend:
//!
//! - **CPU**: SIMD-accelerated batch processing (AVX2, AVX-512, NEON, WASM SIMD128)
//! - **CUDA**: Texture-based lookups with dedicated texture cache
//! - **Metal**: Texture-based lookups with Metal texture objects
//! - **WebGPU**: Texture-based lookups with WebGPU textures
//!
//! # Usage
//!
//! ```ignore
//! use hologram_backend::core::activation_dispatch::ActivationDispatcher;
//! use hologram_backend::plan::activation_table_id;
//!
//! // Create dispatcher for the current backend
//! let mut dispatcher = ActivationDispatcher::new();
//!
//! // Preload common activation tables
//! dispatcher.preload_standard();
//!
//! // Apply activation to batch
//! let input: &[u8] = &data;
//! let mut output = vec![0u8; input.len()];
//! dispatcher.apply_batch(activation_table_id::SIGMOID, input, &mut output);
//! ```
//!
//! # Performance
//!
//! | Backend | Technique | Throughput |
//! |---------|-----------|------------|
//! | CPU (AVX2) | SIMD parallel lookup | ~32 lookups/cycle |
//! | CPU (AVX-512) | SIMD parallel lookup | ~64 lookups/cycle |
//! | CPU (NEON) | SIMD parallel lookup | ~16 lookups/cycle |
//! | CUDA | Texture fetch | L1 texture cache speed |
//! | Metal | Texture sample | L1 texture cache speed |

use crate::core::gpu_textures::{self, table_id, TextureActivation};
use crate::core::simd_activation::SimdActivationCache;
use crate::plan::activation_table_id;

// Silence unused import warning when no GPU backends are enabled
#[allow(unused_imports)]
use TextureActivation as _;

/// Backend type for dispatch selection.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum BackendType {
    /// CPU backend with SIMD support.
    #[default]
    Cpu,
    /// CUDA GPU backend.
    #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
    Cuda,
    /// Metal GPU backend (macOS/iOS).
    #[cfg(all(target_os = "macos", feature = "metal"))]
    Metal,
    /// WebGPU backend.
    #[cfg(feature = "webgpu")]
    WebGpu,
    /// WASM backend with SIMD128.
    #[cfg(feature = "wasm")]
    Wasm,
}

/// Unified activation lookup dispatcher.
///
/// Routes activation lookups to the optimal backend implementation.
pub struct ActivationDispatcher {
    backend: BackendType,
    cpu_cache: SimdActivationCache,
    #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
    cuda_textures: Option<crate::backends::cuda::textures::CudaActivationTextures>,
    #[cfg(all(target_os = "macos", feature = "metal"))]
    metal_textures: Option<crate::backends::metal::textures::MetalActivationTextures>,
    #[cfg(feature = "webgpu")]
    webgpu_textures: Option<crate::backends::webgpu::textures::WebGpuActivationTextures>,
    #[cfg(feature = "wasm")]
    wasm_activation: Option<crate::backends::wasm::simd_activation::WasmSimdActivation>,
}

impl Default for ActivationDispatcher {
    fn default() -> Self {
        Self::new()
    }
}

impl ActivationDispatcher {
    /// Create a new dispatcher with automatic backend detection.
    pub fn new() -> Self {
        Self {
            backend: BackendType::default(),
            cpu_cache: SimdActivationCache::new(),
            #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
            cuda_textures: None,
            #[cfg(all(target_os = "macos", feature = "metal"))]
            metal_textures: None,
            #[cfg(feature = "webgpu")]
            webgpu_textures: None,
            #[cfg(feature = "wasm")]
            wasm_activation: None,
        }
    }

    /// Create a dispatcher for a specific backend.
    pub fn with_backend(backend: BackendType) -> Self {
        Self {
            backend,
            cpu_cache: SimdActivationCache::new(),
            #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
            cuda_textures: None,
            #[cfg(all(target_os = "macos", feature = "metal"))]
            metal_textures: None,
            #[cfg(feature = "webgpu")]
            webgpu_textures: None,
            #[cfg(feature = "wasm")]
            wasm_activation: None,
        }
    }

    /// Initialize CUDA textures.
    #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
    pub fn init_cuda(&mut self, device: std::sync::Arc<cudarc::driver::CudaDevice>) {
        use crate::backends::cuda::textures::CudaActivationTextures;
        self.cuda_textures = Some(CudaActivationTextures::new(device));
        self.backend = BackendType::Cuda;
    }

    /// Initialize Metal textures.
    #[cfg(all(target_os = "macos", feature = "metal"))]
    pub fn init_metal(&mut self, device: metal::Device) {
        use crate::backends::metal::textures::MetalActivationTextures;
        self.metal_textures = Some(MetalActivationTextures::new(device));
        self.backend = BackendType::Metal;
    }

    /// Initialize WebGPU textures.
    #[cfg(feature = "webgpu")]
    pub fn init_webgpu(
        &mut self,
        device: std::sync::Arc<wgpu::Device>,
        queue: std::sync::Arc<wgpu::Queue>,
    ) {
        use crate::backends::webgpu::textures::WebGpuActivationTextures;
        self.webgpu_textures = Some(WebGpuActivationTextures::new(device, queue));
        self.backend = BackendType::WebGpu;
    }

    /// Initialize WASM SIMD activation.
    #[cfg(feature = "wasm")]
    pub fn init_wasm(&mut self) {
        use crate::backends::wasm::simd_activation::WasmSimdActivation;
        let mut wasm = WasmSimdActivation::new();
        wasm.preload_standard();
        self.wasm_activation = Some(wasm);
        self.backend = BackendType::Wasm;
    }

    /// Preload standard activation tables.
    ///
    /// This eagerly loads sigmoid, tanh, relu, gelu, and silu tables
    /// to avoid cold-start latency.
    pub fn preload_standard(&mut self) {
        // Preload CPU SIMD tables
        self.cpu_cache.ensure_loaded(activation_table_id::SIGMOID);
        self.cpu_cache.ensure_loaded(activation_table_id::TANH);
        self.cpu_cache.ensure_loaded(activation_table_id::RELU);
        self.cpu_cache.ensure_loaded(activation_table_id::GELU);
        self.cpu_cache.ensure_loaded(activation_table_id::SILU);

        // Preload inverse tables
        self.cpu_cache.ensure_loaded(table_id::SIGMOID_INVERSE);
        self.cpu_cache.ensure_loaded(table_id::TANH_INVERSE);

        // Preload GPU textures
        #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
        if let Some(textures) = &mut self.cuda_textures {
            textures.preload_standard_textures();
        }

        #[cfg(all(target_os = "macos", feature = "metal"))]
        if let Some(textures) = &mut self.metal_textures {
            textures.preload_standard_textures();
        }

        #[cfg(feature = "webgpu")]
        if let Some(textures) = &mut self.webgpu_textures {
            textures.preload_standard_textures();
        }

        #[cfg(feature = "wasm")]
        if let Some(wasm) = &mut self.wasm_activation {
            wasm.preload_standard();
        }
    }

    /// Get the current backend type.
    pub fn backend(&self) -> BackendType {
        self.backend
    }

    /// Set the backend type.
    pub fn set_backend(&mut self, backend: BackendType) {
        self.backend = backend;
    }

    /// Apply activation to a batch of u8 values.
    ///
    /// Routes to the optimal implementation for the current backend.
    ///
    /// Returns `true` if the table was found and applied, `false` otherwise.
    pub fn apply_batch(&mut self, table_id: u32, input: &[u8], output: &mut [u8]) -> bool {
        match self.backend {
            BackendType::Cpu => self.cpu_cache.apply_batch(table_id, input, output),

            #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
            BackendType::Cuda => {
                // For CUDA, batch processing happens on GPU
                // This path is for CPU-side fallback
                self.cpu_cache.apply_batch(table_id, input, output)
            }

            #[cfg(all(target_os = "macos", feature = "metal"))]
            BackendType::Metal => {
                // For Metal, batch processing happens on GPU
                // This path is for CPU-side fallback
                self.cpu_cache.apply_batch(table_id, input, output)
            }

            #[cfg(feature = "webgpu")]
            BackendType::WebGpu => self.cpu_cache.apply_batch(table_id, input, output),

            #[cfg(feature = "wasm")]
            BackendType::Wasm => self.cpu_cache.apply_batch(table_id, input, output),
        }
    }

    /// Apply activation to a batch in-place.
    pub fn apply_inplace(&mut self, table_id: u32, data: &mut [u8]) -> bool {
        match self.backend {
            BackendType::Cpu => self.cpu_cache.apply_inplace(table_id, data),
            #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
            BackendType::Cuda => self.cpu_cache.apply_inplace(table_id, data),
            #[cfg(all(target_os = "macos", feature = "metal"))]
            BackendType::Metal => self.cpu_cache.apply_inplace(table_id, data),
            #[cfg(feature = "webgpu")]
            BackendType::WebGpu => self.cpu_cache.apply_inplace(table_id, data),
            #[cfg(feature = "wasm")]
            BackendType::Wasm => self.cpu_cache.apply_inplace(table_id, data),
        }
    }

    /// Apply activation to a single f32 value.
    ///
    /// Maps the input [0,1] range to table index, performs lookup,
    /// and maps back to [0,1] range.
    pub fn apply_f32(&mut self, table_id: u32, value: f32) -> f32 {
        // Map f32 to u8 index
        let clamped = value.clamp(0.0, 1.0);
        let index = (clamped * 255.0) as u8;

        // Get the table and perform lookup
        if let Some(table) = gpu_textures::get_activation_table(table_id) {
            let result = table[index as usize];
            result as f32 / 255.0
        } else {
            value // Return unchanged if table not found
        }
    }

    /// Apply activation to a batch of f32 values.
    ///
    /// Quantizes to u8, applies table lookup, dequantizes back to f32.
    pub fn apply_f32_batch(&mut self, table_id: u32, input: &[f32], output: &mut [f32]) -> bool {
        if let Some(table) = gpu_textures::get_activation_table(table_id) {
            for (inp, out) in input.iter().zip(output.iter_mut()) {
                let clamped = inp.clamp(0.0, 1.0);
                let index = (clamped * 255.0) as usize;
                *out = table[index] as f32 / 255.0;
            }
            true
        } else {
            false
        }
    }

    /// Get access to the underlying CPU SIMD cache.
    pub fn cpu_cache(&mut self) -> &mut SimdActivationCache {
        &mut self.cpu_cache
    }

    /// Get access to CUDA textures if available.
    #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
    pub fn cuda_textures(
        &mut self,
    ) -> Option<&mut crate::backends::cuda::textures::CudaActivationTextures> {
        self.cuda_textures.as_mut()
    }

    /// Get access to Metal textures if available.
    #[cfg(all(target_os = "macos", feature = "metal"))]
    pub fn metal_textures(
        &mut self,
    ) -> Option<&mut crate::backends::metal::textures::MetalActivationTextures> {
        self.metal_textures.as_mut()
    }

    /// Check if a specific table is available.
    pub fn has_table(&self, table_id: u32) -> bool {
        gpu_textures::get_activation_table(table_id).is_some()
    }

    /// Get the inverse table ID for a forward activation.
    pub fn inverse_table_id(&self, forward_table_id: u32) -> Option<u32> {
        gpu_textures::get_inverse_table_id(forward_table_id)
    }

    /// Get the forward table ID for an inverse activation.
    pub fn forward_table_id(&self, inverse_table_id: u32) -> Option<u32> {
        gpu_textures::get_forward_table_id(inverse_table_id)
    }
}

/// GPU-side activation context for kernel execution.
///
/// This is used within GPU kernels to access activation textures.
pub struct GpuActivationContext<'a> {
    #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
    cuda: Option<&'a crate::backends::cuda::textures::CudaActivationTextures>,
    #[cfg(all(target_os = "macos", feature = "metal"))]
    metal: Option<&'a crate::backends::metal::textures::MetalActivationTextures>,
    /// Marker to ensure lifetime is used even without GPU features
    _phantom: std::marker::PhantomData<&'a ()>,
}

impl<'a> Default for GpuActivationContext<'a> {
    fn default() -> Self {
        Self::new()
    }
}

impl<'a> GpuActivationContext<'a> {
    /// Create an empty context.
    pub fn new() -> Self {
        Self {
            #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
            cuda: None,
            #[cfg(all(target_os = "macos", feature = "metal"))]
            metal: None,
            _phantom: std::marker::PhantomData,
        }
    }

    /// Create a CUDA context.
    #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
    pub fn with_cuda(
        textures: &'a crate::backends::cuda::textures::CudaActivationTextures,
    ) -> Self {
        Self {
            cuda: Some(textures),
            #[cfg(all(target_os = "macos", feature = "metal"))]
            metal: None,
            _phantom: std::marker::PhantomData,
        }
    }

    /// Create a Metal context.
    #[cfg(all(target_os = "macos", feature = "metal"))]
    pub fn with_metal(
        textures: &'a crate::backends::metal::textures::MetalActivationTextures,
    ) -> Self {
        Self {
            #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
            cuda: None,
            metal: Some(textures),
            _phantom: std::marker::PhantomData,
        }
    }

    /// Get CUDA texture handle for a table.
    #[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
    pub fn cuda_texture(
        &self,
        table_id: u32,
    ) -> Option<&crate::backends::cuda::textures::CudaTextureHandle> {
        self.cuda.and_then(|t| t.get_activation_texture(table_id))
    }

    /// Get Metal texture handle for a table.
    #[cfg(all(target_os = "macos", feature = "metal"))]
    pub fn metal_texture(
        &self,
        table_id: u32,
    ) -> Option<&crate::backends::metal::textures::MetalTextureHandle> {
        self.metal.and_then(|t| t.get_activation_texture(table_id))
    }
}

/// Helper to create epilogue chains with table-based activations.
///
/// Provides a convenient way to build epilogue chains that use
/// pre-computed lookup tables instead of computing activations.
pub struct TableEpilogueBuilder {
    ops: Vec<crate::plan::EpilogueOp>,
}

impl Default for TableEpilogueBuilder {
    fn default() -> Self {
        Self::new()
    }
}

impl TableEpilogueBuilder {
    /// Create a new builder.
    pub fn new() -> Self {
        Self { ops: Vec::new() }
    }

    /// Add sigmoid activation via lookup table.
    pub fn sigmoid(mut self) -> Self {
        self.ops.push(crate::plan::EpilogueOp::CustomTable {
            table_id: activation_table_id::SIGMOID,
        });
        self
    }

    /// Add tanh activation via lookup table.
    pub fn tanh(mut self) -> Self {
        self.ops.push(crate::plan::EpilogueOp::CustomTable {
            table_id: activation_table_id::TANH,
        });
        self
    }

    /// Add relu activation via lookup table.
    pub fn relu(mut self) -> Self {
        self.ops.push(crate::plan::EpilogueOp::CustomTable {
            table_id: activation_table_id::RELU,
        });
        self
    }

    /// Add gelu activation via lookup table.
    pub fn gelu(mut self) -> Self {
        self.ops.push(crate::plan::EpilogueOp::CustomTable {
            table_id: activation_table_id::GELU,
        });
        self
    }

    /// Add silu activation via lookup table.
    pub fn silu(mut self) -> Self {
        self.ops.push(crate::plan::EpilogueOp::CustomTable {
            table_id: activation_table_id::SILU,
        });
        self
    }

    /// Add sigmoid inverse via lookup table.
    pub fn sigmoid_inverse(mut self) -> Self {
        self.ops.push(crate::plan::EpilogueOp::CustomTable {
            table_id: table_id::SIGMOID_INVERSE,
        });
        self
    }

    /// Add tanh inverse via lookup table.
    pub fn tanh_inverse(mut self) -> Self {
        self.ops.push(crate::plan::EpilogueOp::CustomTable {
            table_id: table_id::TANH_INVERSE,
        });
        self
    }

    /// Add a custom table by ID.
    pub fn custom(mut self, table_id: u32) -> Self {
        self.ops
            .push(crate::plan::EpilogueOp::CustomTable { table_id });
        self
    }

    /// Add a bias operation.
    pub fn bias(mut self, offset: usize) -> Self {
        self.ops.push(crate::plan::EpilogueOp::BiasAdd { offset });
        self
    }

    /// Add a scale operation.
    pub fn scale(mut self, alpha: f32) -> Self {
        self.ops.push(crate::plan::EpilogueOp::Scale { alpha });
        self
    }

    /// Build the epilogue chain.
    pub fn build(self) -> crate::plan::EpilogueChain {
        let mut chain = crate::plan::EpilogueChain::new();
        for op in self.ops {
            chain.push(op);
        }
        chain
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dispatcher_creation() {
        let dispatcher = ActivationDispatcher::new();
        assert_eq!(dispatcher.backend(), BackendType::Cpu);
    }

    #[test]
    fn test_dispatcher_preload() {
        let mut dispatcher = ActivationDispatcher::new();
        dispatcher.preload_standard();

        // Should have standard tables available
        assert!(dispatcher.has_table(activation_table_id::SIGMOID));
        assert!(dispatcher.has_table(activation_table_id::TANH));
        assert!(dispatcher.has_table(activation_table_id::RELU));
    }

    #[test]
    fn test_dispatcher_apply_batch() {
        let mut dispatcher = ActivationDispatcher::new();
        dispatcher.preload_standard();

        let input: Vec<u8> = (0..256).map(|i| i as u8).collect();
        let mut output = vec![0u8; 256];

        let result = dispatcher.apply_batch(activation_table_id::SIGMOID, &input, &mut output);
        assert!(result);

        // Check that output is different from input (activation was applied)
        assert_ne!(input, output);
    }

    #[test]
    fn test_dispatcher_apply_f32() {
        let mut dispatcher = ActivationDispatcher::new();

        // Sigmoid at midpoint should be ~0.5
        let result = dispatcher.apply_f32(activation_table_id::SIGMOID, 0.5);
        assert!(result > 0.4 && result < 0.6);
    }

    #[test]
    fn test_dispatcher_inverse_tables() {
        let dispatcher = ActivationDispatcher::new();

        // Should find inverse for sigmoid
        let inverse = dispatcher.inverse_table_id(activation_table_id::SIGMOID);
        assert!(inverse.is_some());

        // Should find forward for inverse sigmoid
        let forward = dispatcher.forward_table_id(table_id::SIGMOID_INVERSE);
        assert_eq!(forward, Some(activation_table_id::SIGMOID));
    }

    #[test]
    fn test_table_epilogue_builder() {
        let chain = TableEpilogueBuilder::new().sigmoid().tanh().build();

        assert_eq!(chain.len(), 2);
    }

    #[test]
    fn test_table_epilogue_builder_with_bias() {
        let chain = TableEpilogueBuilder::new()
            .bias(100)
            .sigmoid()
            .scale(2.0)
            .build();

        assert_eq!(chain.len(), 3);
    }

    #[test]
    fn test_gpu_context_creation() {
        let ctx = GpuActivationContext::new();
        // Should be able to create context without GPU features
        let _ = ctx;
    }
}
