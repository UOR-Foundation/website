/**
 * Attestation Engine — Boundary Attestation Payloads for Private Inference
 * ════════════════════════════════════════════════════════════════════════
 *
 * Constructs attestation payloads from the sovereignty surface that replace
 * raw user data with structured boundary claims. The AI model receives only:
 *
 *   1. Boundary commitment hash (proves surface state without revealing edges)
 *   2. Disclosure proof (Merkle proof of which edges are open)
 *   3. Dimension-level summaries (e.g. "identity: shielded", not actual PII)
 *   4. Sovereignty metrics (Φ_v5, T_∫(π), compression ratio)
 *
 * The AI NEVER sees raw data. It reasons over attestations.
 *
 * Pure functions. No side effects.
 *
 * @module identity/engine/attestation
 */

import type { SovereigntySurface, BoundaryCommitment } from "../types";
import type { DisclosureProof } from "./disclosure-engine";
import type { ThreeAxisSeparation } from "../types/three-axis";
import type { PathIntegralResult } from "../types/path-integral";
import {
  disclosureRatio,
  dimensionDisclosureRatios,
  createBoundaryCommitment,
  SOVEREIGNTY_DIMENSIONS,
} from "./sovereignty-engine";
import { createDisclosureProof, proofSummary } from "./disclosure-engine";
import { computeThreeAxisSeparation } from "./three-axis-engine";
import { computePathIntegral } from "./path-integral-engine";
import { algorithmInfo } from "./pq-crypto";

// ── Attestation Types ───────────────────────────────────────────────────────

/** A single dimension's boundary claim — no raw data, only state. */
export interface DimensionClaim {
  readonly dimension: string;
  readonly state: "shielded" | "partial" | "disclosed";
  readonly disclosureRatio: number;
  readonly edgeCount: number;
  readonly openEdges: number;
}

/** The complete attestation payload sent to the AI model. */
export interface BoundaryAttestation {
  readonly identityId: string;
  readonly timestamp: number;

  // Cryptographic anchors
  readonly commitmentHash: string;
  readonly merkleRoot: string;
  readonly proofSummary: {
    readonly revealedCount: number;
    readonly totalEdges: number;
    readonly disclosurePercent: number;
  };

  // Boundary claims (no raw data)
  readonly dimensions: readonly DimensionClaim[];
  readonly overallDisclosure: number;

  // Sovereignty metrics
  readonly sovereignty: {
    readonly phi_v5: number;
    readonly weakestAxis: string;
    readonly sovereigntyLevel: string;
    readonly compressionRatio: number;
    readonly reconstructionDefence: number;
  };

  readonly pathIntegral: {
    readonly value: number;
    readonly efficiency: number;
    readonly checkpoints: number;
    readonly boundaryUtilization: number;
  };

  // Crypto info
  readonly pqAlgorithm: string;
  readonly nistLevel: number;
  readonly quantumBits: number;
}

/** The sanitized system prompt context the AI receives. */
export interface SanitizedContext {
  readonly systemPrompt: string;
  readonly attestation: BoundaryAttestation;
}

// ── Attestation Construction ────────────────────────────────────────────────

/**
 * Build dimension claims from the sovereignty surface.
 * Each claim tells the AI the disclosure STATE, never the raw data.
 */
function buildDimensionClaims(surface: SovereigntySurface): readonly DimensionClaim[] {
  const ratios = dimensionDisclosureRatios(surface);

  return SOVEREIGNTY_DIMENSIONS.map((dim) => {
    const ratio = ratios[dim.id];
    const dimEdges = surface.edges.filter(
      (e) => e.dimensionA === dim.id || e.dimensionB === dim.id,
    );
    const openEdges = dimEdges.filter((e) => e.state !== "shielded").length;

    return {
      dimension: dim.label,
      state: ratio === 0 ? "shielded" : ratio < 0.5 ? "partial" : "disclosed",
      disclosureRatio: ratio,
      edgeCount: dimEdges.length,
      openEdges,
    };
  });
}

/**
 * Construct the complete boundary attestation payload.
 * This is what the AI model receives — boundary claims only, never raw data.
 */
export async function buildBoundaryAttestation(
  surface: SovereigntySurface,
): Promise<BoundaryAttestation> {
  // Get disclosed edge indices for the Merkle proof
  const disclosedIndices = surface.edges
    .map((e, i) => (e.state !== "shielded" ? i : -1))
    .filter((i) => i >= 0);

  const [commitment, proof] = await Promise.all([
    createBoundaryCommitment(surface),
    createDisclosureProof(surface, disclosedIndices),
  ]);

  const summary = proofSummary(proof);
  const threeAxis = computeThreeAxisSeparation(surface);
  const pathResult = computePathIntegral(surface);
  const pqInfo = algorithmInfo();

  return {
    identityId: surface.identityId,
    timestamp: Date.now(),
    commitmentHash: commitment.commitmentHash,
    merkleRoot: proof.merkleRoot,
    proofSummary: {
      revealedCount: summary.revealedCount,
      totalEdges: summary.totalEdges,
      disclosurePercent: summary.disclosurePercent,
    },
    dimensions: buildDimensionClaims(surface),
    overallDisclosure: disclosureRatio(surface),
    sovereignty: {
      phi_v5: threeAxis.phi_v5,
      weakestAxis: threeAxis.weakestAxis,
      sovereigntyLevel: threeAxis.sovereigntyLevel,
      compressionRatio: threeAxis.inference.compressionRatio,
      reconstructionDefence: threeAxis.inference.reconstructionDefence,
    },
    pathIntegral: {
      value: pathResult.integralValue,
      efficiency: pathResult.boundaryUtilization,
      checkpoints: pathResult.verifiedCheckpoints,
      boundaryUtilization: pathResult.boundaryUtilization,
    },
    pqAlgorithm: pqInfo.fips,
    nistLevel: pqInfo.nistLevel,
    quantumBits: pqInfo.quantumBits,
  };
}

/**
 * Build the sanitized system prompt for the AI model.
 * The model receives ONLY boundary attestations and sovereignty metrics.
 * All raw data is stripped — the model reasons over abstract claims.
 */
export async function buildSanitizedContext(
  surface: SovereigntySurface,
  userIntent: string,
): Promise<SanitizedContext> {
  const attestation = await buildBoundaryAttestation(surface);

  const shieldedDims = attestation.dimensions
    .filter((d) => d.state === "shielded")
    .map((d) => d.dimension);

  const disclosedDims = attestation.dimensions
    .filter((d) => d.state === "disclosed")
    .map((d) => d.dimension);

  const partialDims = attestation.dimensions
    .filter((d) => d.state === "partial")
    .map((d) => d.dimension);

  const systemPrompt = `You are a sovereign AI assistant operating under zero-knowledge boundary constraints.

## Boundary Attestation
- Commitment: ${attestation.commitmentHash.slice(0, 16)}...
- Merkle root: ${attestation.merkleRoot.slice(0, 16)}...
- Disclosed edges: ${attestation.proofSummary.revealedCount}/${attestation.proofSummary.totalEdges} (${attestation.proofSummary.disclosurePercent}%)

## Dimension Access
${shieldedDims.length > 0 ? `- SHIELDED (no access): ${shieldedDims.join(", ")}` : ""}
${disclosedDims.length > 0 ? `- DISCLOSED (can reference): ${disclosedDims.join(", ")}` : ""}
${partialDims.length > 0 ? `- PARTIAL (limited): ${partialDims.join(", ")}` : ""}

## Sovereignty Metrics
- Φ_v5 = ${attestation.sovereignty.phi_v5.toFixed(4)} (${attestation.sovereignty.sovereigntyLevel})
- T_∫(π) = ${attestation.pathIntegral.value.toFixed(4)}
- Compression: ${attestation.sovereignty.compressionRatio.toFixed(1)}×
- Reconstruction defence: ${(attestation.sovereignty.reconstructionDefence * 100).toFixed(1)}%

## Rules
1. NEVER infer, guess, or reconstruct data from shielded dimensions.
2. Only reference information from DISCLOSED dimensions.
3. For PARTIAL dimensions, acknowledge the limitation.
4. All responses must respect the boundary commitment.
5. If the user asks about shielded data, explain it is protected by the sovereignty surface.
6. Post-quantum secured with ${attestation.pqAlgorithm} (NIST Level ${attestation.nistLevel}).

## User Intent
${userIntent}`;

  return { systemPrompt, attestation };
}
