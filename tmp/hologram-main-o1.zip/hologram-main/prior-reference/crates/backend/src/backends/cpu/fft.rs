//! FFT-based convolution for large kernels.
//!
//! This module provides FFT-based convolution using rustfft for large kernels
//! and optimized direct convolution for smaller kernels where it's more efficient.

use rustfft::{num_complex::Complex, FftPlanner};

/// Kernel size threshold above which FFT convolution is used.
/// For kernels smaller than this, direct convolution is often faster
/// due to cache efficiency.
pub const FFT_THRESHOLD: usize = 64;

/// Perform 1D convolution.
///
/// For input of length N and kernel of length K, produces output of length N - K + 1.
/// Uses FFT for large kernels (>= FFT_THRESHOLD) and direct convolution otherwise.
///
/// # Arguments
/// * `input` - Input signal (length N)
/// * `kernel` - Convolution kernel (length K)
///
/// # Returns
/// Convolution result (length N - K + 1)
pub fn fft_conv1d(input: &[f32], kernel: &[f32]) -> Vec<f32> {
    if input.is_empty() || kernel.is_empty() {
        return vec![];
    }

    let n = input.len();
    let k = kernel.len();

    if k > n {
        return vec![];
    }

    // Use FFT for large kernels, direct for small
    if k >= FFT_THRESHOLD {
        fft_conv1d_impl(input, kernel)
    } else {
        direct_conv1d(input, kernel)
    }
}

/// FFT-based 1D convolution implementation.
///
/// Uses the overlap-add method for linear convolution via FFT.
/// For valid convolution: output[i] = sum(input[i+j] * kernel[j]) for j in 0..k
fn fft_conv1d_impl(input: &[f32], kernel: &[f32]) -> Vec<f32> {
    let n = input.len();
    let k = kernel.len();
    let out_len = n - k + 1;

    // For linear convolution, we need fft_size >= n + k - 1
    let linear_len = n + k - 1;
    let fft_size = linear_len.next_power_of_two();

    // Create complex buffers with zero padding
    let mut input_c: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); fft_size];
    for (i, &x) in input.iter().enumerate() {
        input_c[i] = Complex::new(x, 0.0);
    }

    // Flip kernel for convolution (correlation would not flip)
    let mut kernel_c: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); fft_size];
    for (i, &x) in kernel.iter().enumerate() {
        kernel_c[i] = Complex::new(x, 0.0);
    }

    // Forward FFT
    let mut planner = FftPlanner::new();
    let fft = planner.plan_fft_forward(fft_size);
    fft.process(&mut input_c);
    fft.process(&mut kernel_c);

    // Element-wise multiply in frequency domain
    let mut result: Vec<Complex<f32>> = input_c
        .iter()
        .zip(kernel_c.iter())
        .map(|(a, b)| a * b)
        .collect();

    // Inverse FFT
    let ifft = planner.plan_fft_inverse(fft_size);
    ifft.process(&mut result);

    // Normalize and extract valid region
    // The linear convolution result is at indices 0..linear_len
    // For "valid" convolution, we want indices (k-1)..(n) which is out_len elements
    let scale = 1.0 / fft_size as f32;
    result[(k - 1)..(k - 1 + out_len)]
        .iter()
        .map(|c| c.re * scale)
        .collect()
}

/// Direct 1D convolution for comparison and small kernels.
fn direct_conv1d(input: &[f32], kernel: &[f32]) -> Vec<f32> {
    let n = input.len();
    let k = kernel.len();
    let output_len = n - k + 1;

    let mut output = vec![0.0; output_len];
    for i in 0..output_len {
        let mut sum = 0.0;
        for j in 0..k {
            sum += input[i + j] * kernel[j];
        }
        output[i] = sum;
    }
    output
}

/// Perform 2D convolution.
///
/// Input: [H, W] (row-major)
/// Kernel: [KH, KW] (row-major)
/// Output: [H - KH + 1, W - KW + 1]
///
/// Uses FFT for large kernels and direct convolution for smaller kernels.
pub fn fft_conv2d(
    input: &[f32],
    input_h: usize,
    input_w: usize,
    kernel: &[f32],
    kernel_h: usize,
    kernel_w: usize,
) -> Vec<f32> {
    // Validate dimensions
    if input_h == 0 || input_w == 0 || kernel_h == 0 || kernel_w == 0 {
        return vec![];
    }
    if input.len() != input_h * input_w {
        return vec![];
    }
    if kernel.len() != kernel_h * kernel_w {
        return vec![];
    }
    if kernel_h > input_h || kernel_w > input_w {
        return vec![];
    }

    // Use FFT for large kernels (either dimension >= threshold)
    if kernel_h >= FFT_THRESHOLD || kernel_w >= FFT_THRESHOLD {
        fft_conv2d_impl(input, input_h, input_w, kernel, kernel_h, kernel_w)
    } else {
        direct_conv2d(input, input_h, input_w, kernel, kernel_h, kernel_w)
    }
}

/// FFT-based 2D convolution implementation.
fn fft_conv2d_impl(
    input: &[f32],
    input_h: usize,
    input_w: usize,
    kernel: &[f32],
    kernel_h: usize,
    kernel_w: usize,
) -> Vec<f32> {
    let out_h = input_h - kernel_h + 1;
    let out_w = input_w - kernel_w + 1;

    // Pad to next power of 2 for FFT efficiency
    let fft_h = (input_h + kernel_h - 1).next_power_of_two();
    let fft_w = (input_w + kernel_w - 1).next_power_of_two();
    let fft_size = fft_h * fft_w;

    // Create padded complex input
    let mut input_c: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); fft_size];
    for h in 0..input_h {
        for w in 0..input_w {
            input_c[h * fft_w + w] = Complex::new(input[h * input_w + w], 0.0);
        }
    }

    // Create padded complex kernel
    let mut kernel_c: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); fft_size];
    for h in 0..kernel_h {
        for w in 0..kernel_w {
            kernel_c[h * fft_w + w] = Complex::new(kernel[h * kernel_w + w], 0.0);
        }
    }

    // 2D FFT via row-column decomposition
    let mut planner = FftPlanner::new();

    // Forward FFT on rows
    let fft_row = planner.plan_fft_forward(fft_w);
    for h in 0..fft_h {
        let row_start = h * fft_w;
        fft_row.process(&mut input_c[row_start..row_start + fft_w]);
        fft_row.process(&mut kernel_c[row_start..row_start + fft_w]);
    }

    // Forward FFT on columns
    let fft_col = planner.plan_fft_forward(fft_h);
    let mut col_input: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); fft_h];
    let mut col_kernel: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); fft_h];
    for w in 0..fft_w {
        // Extract column
        for h in 0..fft_h {
            col_input[h] = input_c[h * fft_w + w];
            col_kernel[h] = kernel_c[h * fft_w + w];
        }
        // FFT column
        fft_col.process(&mut col_input);
        fft_col.process(&mut col_kernel);
        // Write back
        for h in 0..fft_h {
            input_c[h * fft_w + w] = col_input[h];
            kernel_c[h * fft_w + w] = col_kernel[h];
        }
    }

    // Element-wise multiply
    let mut result: Vec<Complex<f32>> = input_c
        .iter()
        .zip(kernel_c.iter())
        .map(|(a, b)| a * b)
        .collect();

    // Inverse FFT on columns
    let ifft_col = planner.plan_fft_inverse(fft_h);
    let mut col_result: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); fft_h];
    for w in 0..fft_w {
        for h in 0..fft_h {
            col_result[h] = result[h * fft_w + w];
        }
        ifft_col.process(&mut col_result);
        for h in 0..fft_h {
            result[h * fft_w + w] = col_result[h];
        }
    }

    // Inverse FFT on rows
    let ifft_row = planner.plan_fft_inverse(fft_w);
    for h in 0..fft_h {
        let row_start = h * fft_w;
        ifft_row.process(&mut result[row_start..row_start + fft_w]);
    }

    // Normalize and extract valid region
    // For valid convolution, extract from offset (kernel_h-1, kernel_w-1)
    let scale = 1.0 / fft_size as f32;
    let mut output = vec![0.0; out_h * out_w];
    for h in 0..out_h {
        for w in 0..out_w {
            let src_h = kernel_h - 1 + h;
            let src_w = kernel_w - 1 + w;
            output[h * out_w + w] = result[src_h * fft_w + src_w].re * scale;
        }
    }

    output
}

/// Direct 2D convolution for comparison and small kernels.
fn direct_conv2d(
    input: &[f32],
    input_h: usize,
    input_w: usize,
    kernel: &[f32],
    kernel_h: usize,
    kernel_w: usize,
) -> Vec<f32> {
    let out_h = input_h - kernel_h + 1;
    let out_w = input_w - kernel_w + 1;

    let mut output = vec![0.0; out_h * out_w];

    for oh in 0..out_h {
        for ow in 0..out_w {
            let mut sum = 0.0;
            for kh in 0..kernel_h {
                for kw in 0..kernel_w {
                    sum += input[(oh + kh) * input_w + (ow + kw)] * kernel[kh * kernel_w + kw];
                }
            }
            output[oh * out_w + ow] = sum;
        }
    }

    output
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_conv1d_basic() {
        let input = vec![1.0, 2.0, 3.0, 4.0, 5.0];
        let kernel = vec![1.0, 2.0, 1.0];
        let result = fft_conv1d(&input, &kernel);

        // Expected: [1*1+2*2+3*1, 2*1+3*2+4*1, 3*1+4*2+5*1] = [8, 12, 16]
        assert_eq!(result.len(), 3);
        assert!((result[0] - 8.0).abs() < 1e-5);
        assert!((result[1] - 12.0).abs() < 1e-5);
        assert!((result[2] - 16.0).abs() < 1e-5);
    }

    #[test]
    fn test_conv1d_sum_kernel() {
        // Larger test with sum kernel
        let input: Vec<f32> = (0..100).map(|i| i as f32).collect();
        let kernel: Vec<f32> = vec![1.0; 16]; // Sum of 16 elements
        let result = fft_conv1d(&input, &kernel);

        // First output: sum(0..16) = 120
        assert!((result[0] - 120.0).abs() < 1e-5);
        // Second output: sum(1..17) = 136
        assert!((result[1] - 136.0).abs() < 1e-5);
    }

    #[test]
    fn test_conv2d_basic() {
        // 3x3 input, 2x2 kernel
        let input = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0];
        let kernel = vec![1.0, 0.0, 0.0, 1.0]; // Diagonal

        let result = fft_conv2d(&input, 3, 3, &kernel, 2, 2);

        // Expected 2x2 output:
        // out[0,0] = 1*1 + 2*0 + 4*0 + 5*1 = 6
        // out[0,1] = 2*1 + 3*0 + 5*0 + 6*1 = 8
        // out[1,0] = 4*1 + 5*0 + 7*0 + 8*1 = 12
        // out[1,1] = 5*1 + 6*0 + 8*0 + 9*1 = 14
        assert_eq!(result.len(), 4);
        assert!((result[0] - 6.0).abs() < 1e-5);
        assert!((result[1] - 8.0).abs() < 1e-5);
        assert!((result[2] - 12.0).abs() < 1e-5);
        assert!((result[3] - 14.0).abs() < 1e-5);
    }

    #[test]
    fn test_conv2d_averaging() {
        // Test averaging kernel on larger input
        let input_h = 32;
        let input_w = 32;
        let kernel_h = 9;
        let kernel_w = 9;

        let input: Vec<f32> = (0..input_h * input_w).map(|i| (i % 10) as f32).collect();
        let kernel: Vec<f32> = vec![1.0 / (kernel_h * kernel_w) as f32; kernel_h * kernel_w];

        let result = fft_conv2d(&input, input_h, input_w, &kernel, kernel_h, kernel_w);

        let out_h = input_h - kernel_h + 1;
        let out_w = input_w - kernel_w + 1;
        assert_eq!(result.len(), out_h * out_w);

        // All values should be roughly the average (between 0-9)
        for &v in &result {
            assert!(
                (0.0..=9.0).contains(&v),
                "Value {} out of expected range",
                v
            );
        }
    }

    #[test]
    fn test_conv1d_empty() {
        assert!(fft_conv1d(&[], &[1.0]).is_empty());
        assert!(fft_conv1d(&[1.0], &[]).is_empty());
        assert!(fft_conv1d(&[1.0], &[1.0, 2.0]).is_empty()); // kernel > input
    }

    #[test]
    fn test_conv2d_empty() {
        assert!(fft_conv2d(&[], 0, 0, &[1.0], 1, 1).is_empty());
        assert!(fft_conv2d(&[1.0], 1, 1, &[], 0, 0).is_empty());
        assert!(fft_conv2d(&[1.0], 1, 1, &[1.0, 2.0], 1, 2).is_empty()); // kernel_w > input_w
    }

    #[test]
    fn test_fft_conv1d_large_kernel() {
        // Test with kernel size >= FFT_THRESHOLD to trigger FFT path
        let input: Vec<f32> = (0..256).map(|i| (i as f32).sin()).collect();
        let kernel: Vec<f32> = vec![1.0 / 64.0; 64]; // 64-element averaging kernel

        let result = fft_conv1d(&input, &kernel);
        let expected = direct_conv1d(&input, &kernel);

        // FFT result should match direct convolution
        assert_eq!(result.len(), expected.len());
        for (r, e) in result.iter().zip(expected.iter()) {
            assert!(
                (r - e).abs() < 1e-4,
                "FFT mismatch: fft={}, direct={}",
                r,
                e
            );
        }
    }

    #[test]
    fn test_fft_conv2d_large_kernel() {
        // Test with kernel size >= FFT_THRESHOLD to trigger FFT path
        let input_h = 128;
        let input_w = 128;
        let kernel_h = 64;
        let kernel_w = 64;

        let input: Vec<f32> = (0..input_h * input_w)
            .map(|i| ((i as f32) * 0.01).sin())
            .collect();
        let kernel: Vec<f32> = vec![1.0 / (kernel_h * kernel_w) as f32; kernel_h * kernel_w];

        let result = fft_conv2d(&input, input_h, input_w, &kernel, kernel_h, kernel_w);
        let expected = direct_conv2d(&input, input_h, input_w, &kernel, kernel_h, kernel_w);

        // FFT result should match direct convolution
        assert_eq!(result.len(), expected.len());
        for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
            assert!(
                (r - e).abs() < 1e-3,
                "FFT mismatch at {}: fft={}, direct={}",
                i,
                r,
                e
            );
        }
    }

    #[test]
    fn test_fft_conv1d_correctness() {
        // Test that FFT convolution produces correct results
        let input: Vec<f32> = (0..200).map(|i| i as f32).collect();
        let kernel: Vec<f32> = vec![1.0; 70]; // 70-element sum kernel

        let result = fft_conv1d(&input, &kernel);

        // First output should be sum(0..70)
        let expected_first: f32 = (0..70).map(|i| i as f32).sum();
        assert!(
            (result[0] - expected_first).abs() < 1e-3,
            "Expected {}, got {}",
            expected_first,
            result[0]
        );

        // Second output should be sum(1..71)
        let expected_second: f32 = (1..71).map(|i| i as f32).sum();
        assert!(
            (result[1] - expected_second).abs() < 1e-3,
            "Expected {}, got {}",
            expected_second,
            result[1]
        );
    }
}
