//! Pure CPU compute functions for use by all backends.
//!
//! These functions operate directly on f32 slices and can be used
//! by GPU backend fallbacks when actual GPU hardware is unavailable.
//!
//! # Performance
//!
//! The primary `cpu_matmul_f32` function uses SIMD-optimized micro-kernels:
//! - **AVX2**: 6x16 micro-kernel with FMA (10-50x faster than naive)
//! - **NEON**: 4x8 micro-kernel with FMA
//! - **Scalar**: Tiled fallback for other architectures
//!
//! Use `cpu_matmul_f32_naive` for reference/testing purposes only.

use crate::cpu::simd_dispatch::SimdDispatcher;
use crate::{Conv2DParams, MatMulParams};

/// Perform matrix multiplication: C = alpha * A @ B + beta * C
///
/// Uses SIMD-optimized micro-kernels with automatic dispatch based on CPU capability.
/// This is the primary matmul implementation and should be used for all production code.
///
/// # Performance
///
/// - **AVX2**: 6x16 micro-kernel, ~10-50x faster than naive for large matrices
/// - **NEON**: 4x8 micro-kernel, ~5-20x faster on ARM
/// - **Scalar**: Tiled fallback, ~2-5x faster than naive due to cache efficiency
///
/// # Arguments
/// * `c` - Output matrix (m x n), row-major
/// * `a` - First input matrix (m x k), row-major (or k x m if trans_a)
/// * `b` - Second input matrix (k x n), row-major (or n x k if trans_b)
/// * `params` - Matrix multiplication parameters (m, k, n, alpha, beta, trans_a, trans_b)
///
/// # Panics
/// Panics if buffer sizes are insufficient or if transpose is requested
/// (transpose support is not yet implemented in SIMD path).
pub fn cpu_matmul_f32(c: &mut [f32], a: &[f32], b: &[f32], params: &MatMulParams) {
    let m = params.m as usize;
    let k = params.k as usize;
    let n = params.n as usize;
    let alpha = params.alpha as f32;
    let beta = params.beta as f32;

    assert!(a.len() >= m * k, "A buffer too small");
    assert!(b.len() >= k * n, "B buffer too small");
    assert!(c.len() >= m * n, "C buffer too small");

    // For transposed inputs, fall back to naive implementation
    // The SIMD path expects row-major non-transposed inputs
    if params.trans_a || params.trans_b {
        cpu_matmul_f32_naive(c, a, b, params);
        return;
    }

    // Use SIMD-optimized dispatcher
    let dispatcher = SimdDispatcher::new();
    if let Err(_e) = dispatcher.matmul_f32(c, a, b, m, k, n, alpha, beta) {
        // Fall back to naive on error (shouldn't happen with valid inputs)
        cpu_matmul_f32_naive(c, a, b, params);
    }
}

/// Naive matrix multiplication for reference and transposed inputs.
///
/// This is the unoptimized reference implementation. Use `cpu_matmul_f32`
/// for production code.
///
/// # Arguments
/// * `c` - Output matrix (m x n), row-major
/// * `a` - First input matrix (m x k), row-major
/// * `b` - Second input matrix (k x n), row-major
/// * `params` - Matrix multiplication parameters (m, k, n, alpha, beta)
pub fn cpu_matmul_f32_naive(c: &mut [f32], a: &[f32], b: &[f32], params: &MatMulParams) {
    let m = params.m as usize;
    let k = params.k as usize;
    let n = params.n as usize;
    let alpha = params.alpha as f32;
    let beta = params.beta as f32;

    // C = alpha * A @ B + beta * C
    for i in 0..m {
        for j in 0..n {
            let mut sum = 0.0f32;
            for l in 0..k {
                let a_val = if params.trans_a {
                    a[l * m + i] // A^T[i,l] = A[l,i]
                } else {
                    a[i * k + l] // A[i,l]
                };
                let b_val = if params.trans_b {
                    b[j * k + l] // B^T[l,j] = B[j,l]
                } else {
                    b[l * n + j] // B[l,j]
                };
                sum += a_val * b_val;
            }
            let c_idx = i * n + j;
            c[c_idx] = alpha * sum + beta * c[c_idx];
        }
    }
}

/// Perform batched matrix multiplication.
///
/// Each batch performs: C[i] = alpha * A[i] @ B[i] + beta * C[i]
pub fn cpu_batch_matmul_f32(
    c: &mut [f32],
    a: &[f32],
    b: &[f32],
    batch: usize,
    params: &MatMulParams,
) {
    let m = params.m as usize;
    let k = params.k as usize;
    let n = params.n as usize;

    let a_stride = m * k;
    let b_stride = k * n;
    let c_stride = m * n;

    assert!(a.len() >= batch * a_stride, "A buffer too small");
    assert!(b.len() >= batch * b_stride, "B buffer too small");
    assert!(c.len() >= batch * c_stride, "C buffer too small");

    for bi in 0..batch {
        let a_slice = &a[bi * a_stride..(bi + 1) * a_stride];
        let b_slice = &b[bi * b_stride..(bi + 1) * b_stride];
        let c_slice = &mut c[bi * c_stride..(bi + 1) * c_stride];

        // Create a temporary params for this batch (same dimensions)
        cpu_matmul_f32(c_slice, a_slice, b_slice, params);
    }
}

/// Perform 2D convolution.
///
/// Input: [N, C_in, H, W]
/// Kernel: [C_out, C_in, KH, KW]
/// Output: [N, C_out, H_out, W_out]
pub fn cpu_conv2d_f32(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &Conv2DParams,
) {
    let batch = params.input_dims[0] as usize;
    let in_channels = params.input_dims[1] as usize;
    let in_height = params.input_dims[2] as usize;
    let in_width = params.input_dims[3] as usize;

    let out_channels = params.kernel_dims[0] as usize;
    let kernel_h = params.kernel_dims[2] as usize;
    let kernel_w = params.kernel_dims[3] as usize;

    let stride_h = params.stride[0] as usize;
    let stride_w = params.stride[1] as usize;
    let pad_h = params.padding[0] as usize;
    let pad_w = params.padding[1] as usize;
    let dilation_h = params.dilation[0].max(1) as usize;
    let dilation_w = params.dilation[1].max(1) as usize;

    // Calculate output dimensions
    let out_height = (in_height + 2 * pad_h - dilation_h * (kernel_h - 1) - 1) / stride_h + 1;
    let out_width = (in_width + 2 * pad_w - dilation_w * (kernel_w - 1) - 1) / stride_w + 1;

    // Output is [N, C_out, H_out, W_out]
    let out_hw = out_height * out_width;
    let out_chw = out_channels * out_hw;

    // Input is [N, C_in, H, W]
    let in_hw = in_height * in_width;
    let in_chw = in_channels * in_hw;

    // Kernel is [C_out, C_in, KH, KW]
    let k_hw = kernel_h * kernel_w;
    let k_chw = in_channels * k_hw;

    for n in 0..batch {
        for oc in 0..out_channels {
            for oh in 0..out_height {
                for ow in 0..out_width {
                    let mut sum = 0.0f32;

                    for ic in 0..in_channels {
                        for kh in 0..kernel_h {
                            for kw in 0..kernel_w {
                                let ih =
                                    (oh * stride_h + kh * dilation_h) as isize - pad_h as isize;
                                let iw =
                                    (ow * stride_w + kw * dilation_w) as isize - pad_w as isize;

                                if ih >= 0
                                    && ih < in_height as isize
                                    && iw >= 0
                                    && iw < in_width as isize
                                {
                                    let ih = ih as usize;
                                    let iw = iw as usize;

                                    // Input index: [n, ic, ih, iw]
                                    let input_idx = n * in_chw + ic * in_hw + ih * in_width + iw;
                                    // Kernel index: [oc, ic, kh, kw]
                                    let kernel_idx = oc * k_chw + ic * k_hw + kh * kernel_w + kw;

                                    sum += input[input_idx] * kernel[kernel_idx];
                                }
                            }
                        }
                    }

                    // Add bias if present
                    if let Some(b) = bias {
                        if oc < b.len() {
                            sum += b[oc];
                        }
                    }

                    // Output index: [n, oc, oh, ow]
                    let output_idx = n * out_chw + oc * out_hw + oh * out_width + ow;
                    output[output_idx] = sum;
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_isa::Type;

    #[test]
    fn test_cpu_matmul_identity() {
        // 2x2 identity matrix times a vector-like matrix
        let a = vec![1.0, 0.0, 0.0, 1.0]; // 2x2 identity
        let b = vec![3.0, 4.0, 5.0, 6.0]; // 2x2
        let mut c = vec![0.0; 4];

        let params = MatMulParams {
            m: 2,
            k: 2,
            n: 2,
            dtype: Type::F32,
            alpha: 1.0,
            beta: 0.0,
            trans_a: false,
            trans_b: false,
        };

        cpu_matmul_f32(&mut c, &a, &b, &params);

        // Identity * B = B
        assert!((c[0] - 3.0).abs() < 1e-5);
        assert!((c[1] - 4.0).abs() < 1e-5);
        assert!((c[2] - 5.0).abs() < 1e-5);
        assert!((c[3] - 6.0).abs() < 1e-5);
    }

    #[test]
    fn test_cpu_matmul_with_alpha_beta() {
        let a = vec![1.0, 2.0, 3.0, 4.0]; // 2x2
        let b = vec![1.0, 0.0, 0.0, 1.0]; // 2x2 identity
        let mut c = vec![10.0, 10.0, 10.0, 10.0]; // pre-filled

        let params = MatMulParams {
            m: 2,
            k: 2,
            n: 2,
            dtype: Type::F32,
            alpha: 2.0, // 2 * (A @ B)
            beta: 0.5,  // + 0.5 * C
            trans_a: false,
            trans_b: false,
        };

        cpu_matmul_f32(&mut c, &a, &b, &params);

        // C = 2.0 * A @ I + 0.5 * [10,10,10,10] = 2*A + [5,5,5,5]
        assert!((c[0] - 7.0).abs() < 1e-5); // 2*1 + 5
        assert!((c[1] - 9.0).abs() < 1e-5); // 2*2 + 5
        assert!((c[2] - 11.0).abs() < 1e-5); // 2*3 + 5
        assert!((c[3] - 13.0).abs() < 1e-5); // 2*4 + 5
    }

    #[test]
    fn test_cpu_batch_matmul() {
        // Two batches of 2x2 matmul
        let a = vec![
            1.0, 2.0, 3.0, 4.0, // batch 0
            5.0, 6.0, 7.0, 8.0, // batch 1
        ];
        let b = vec![
            1.0, 0.0, 0.0, 1.0, // batch 0: identity
            1.0, 0.0, 0.0, 1.0, // batch 1: identity
        ];
        let mut c = vec![0.0; 8];

        let params = MatMulParams {
            m: 2,
            k: 2,
            n: 2,
            dtype: Type::F32,
            alpha: 1.0,
            beta: 0.0,
            trans_a: false,
            trans_b: false,
        };

        cpu_batch_matmul_f32(&mut c, &a, &b, 2, &params);

        // A @ I = A for both batches
        assert!((c[0] - 1.0).abs() < 1e-5);
        assert!((c[3] - 4.0).abs() < 1e-5);
        assert!((c[4] - 5.0).abs() < 1e-5);
        assert!((c[7] - 8.0).abs() < 1e-5);
    }

    #[test]
    fn test_cpu_conv2d_simple() {
        // 1x1x3x3 input, 1x1x2x2 kernel, stride 1, no padding
        let input = vec![
            1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, // 3x3
        ];
        let kernel = vec![
            1.0, 0.0, 0.0, 1.0, // 2x2 diagonal
        ];
        let mut output = vec![0.0; 4]; // 2x2 output

        let params = Conv2DParams {
            input_dims: [1, 1, 3, 3],
            kernel_dims: [1, 1, 2, 2],
            stride: [1, 1],
            padding: [0, 0],
            dilation: [1, 1],
            dtype: Type::F32,
        };

        cpu_conv2d_f32(&mut output, &input, &kernel, None, &params);

        // For diagonal kernel [1,0,0,1]:
        // out[0,0] = 1*1 + 0*2 + 0*4 + 1*5 = 6
        // out[0,1] = 1*2 + 0*3 + 0*5 + 1*6 = 8
        // out[1,0] = 1*4 + 0*5 + 0*7 + 1*8 = 12
        // out[1,1] = 1*5 + 0*6 + 0*8 + 1*9 = 14
        assert!((output[0] - 6.0).abs() < 1e-5);
        assert!((output[1] - 8.0).abs() < 1e-5);
        assert!((output[2] - 12.0).abs() < 1e-5);
        assert!((output[3] - 14.0).abs() < 1e-5);
    }

    #[test]
    fn test_cpu_conv2d_with_bias() {
        let input = vec![1.0, 2.0, 3.0, 4.0]; // 1x1x2x2
        let kernel = vec![1.0]; // 1x1x1x1 (identity-ish)
        let bias = vec![10.0]; // bias for output channel 0
        let mut output = vec![0.0; 4]; // 1x1x2x2 output

        let params = Conv2DParams {
            input_dims: [1, 1, 2, 2],
            kernel_dims: [1, 1, 1, 1],
            stride: [1, 1],
            padding: [0, 0],
            dilation: [1, 1],
            dtype: Type::F32,
        };

        cpu_conv2d_f32(&mut output, &input, &kernel, Some(&bias), &params);

        // Each output = input * 1.0 + 10.0
        assert!((output[0] - 11.0).abs() < 1e-5);
        assert!((output[1] - 12.0).abs() < 1e-5);
        assert!((output[2] - 13.0).abs() < 1e-5);
        assert!((output[3] - 14.0).abs() < 1e-5);
    }
}
