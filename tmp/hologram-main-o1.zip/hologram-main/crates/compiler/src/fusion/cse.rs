//! Common Subexpression Elimination pass.
//!
//! Deduplicates nodes with identical operation and inputs, reducing
//! redundant computation in the graph.

use std::collections::HashMap;
use std::hash::{Hash, Hasher};

use crate::graph::{CompileGraph, OpKind};

/// Deduplicate nodes with identical operation and inputs.
///
/// This pass finds nodes that compute the same result and merges them:
/// 1. Hash nodes by (`op_kind`, sorted predecessor IDs)
/// 2. For nodes with same hash, verify they're truly equivalent
/// 3. Rewire all successors of duplicates to the canonical node
/// 4. Remove duplicate nodes
pub fn cse(graph: &mut CompileGraph) {
    // Build hash map of node signatures to node IDs
    let mut signatures: HashMap<NodeSignature, Vec<u32>> = HashMap::new();

    for (id, node) in graph.nodes() {
        // Skip nodes that can't be deduplicated
        if !node.op.is_pure() {
            continue;
        }

        let sig = NodeSignature::new(graph, id);
        signatures.entry(sig).or_default().push(id);
    }

    // Find and merge duplicates
    let mut removed = Vec::new();
    for (_sig, ids) in signatures {
        if ids.len() < 2 {
            continue;
        }

        // First node is the canonical one, others are duplicates
        let canonical = ids[0];
        for &dup in &ids[1..] {
            // Verify nodes are truly equivalent (same shape, dtype, etc.)
            if nodes_equivalent(graph, canonical, dup) {
                // Rewire successors of duplicate to canonical
                graph.rewire_successors(dup, canonical);
                removed.push(dup);
            }
        }
    }

    // Remove duplicate nodes
    for id in removed {
        graph.remove_node(id);
    }
}

/// Node signature for hash-based comparison.
#[derive(Clone, Eq, PartialEq)]
struct NodeSignature {
    /// Operation discriminant (not full op, to avoid `MatMul` dimensions in hash)
    op_discriminant: std::mem::Discriminant<OpKind>,
    /// Sorted list of predecessor IDs
    predecessors: Vec<u32>,
    /// For `MatMul`, include dimensions in signature
    matmul_dims: Option<(usize, usize, usize)>,
}

impl NodeSignature {
    fn new(graph: &CompileGraph, id: u32) -> Self {
        let node = graph.get_node(id).expect("node exists");
        let mut preds = graph.predecessors(id);
        preds.sort_unstable();

        let matmul_dims = match &node.op {
            OpKind::MatMul { m, k, n } => Some((*m, *k, *n)),
            _ => None,
        };

        Self {
            op_discriminant: std::mem::discriminant(&node.op),
            predecessors: preds,
            matmul_dims,
        }
    }
}

impl Hash for NodeSignature {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.op_discriminant.hash(state);
        self.predecessors.hash(state);
        self.matmul_dims.hash(state);
    }
}

/// Check if two nodes are truly equivalent (same op, shape, dtype).
fn nodes_equivalent(graph: &CompileGraph, a: u32, b: u32) -> bool {
    let Some(node_a) = graph.get_node(a) else {
        return false;
    };
    let Some(node_b) = graph.get_node(b) else {
        return false;
    };

    // Same operation kind (including MatMul dimensions)
    if node_a.op != node_b.op {
        return false;
    }

    // Same shape
    if node_a.shape != node_b.shape {
        return false;
    }

    // Same dtype
    if node_a.dtype != node_b.dtype {
        return false;
    }

    // Same predecessors (already checked in signature, but verify)
    let preds_a = graph.predecessors(a);
    let preds_b = graph.predecessors(b);
    if preds_a.len() != preds_b.len() {
        return false;
    }

    let mut sorted_a = preds_a;
    let mut sorted_b = preds_b;
    sorted_a.sort_unstable();
    sorted_b.sort_unstable();

    sorted_a == sorted_b
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpNode, OperationGraph};

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    #[test]
    fn test_cse_empty_graph() {
        let mut graph = make_graph(vec![], vec![]);
        cse(&mut graph);
        assert_eq!(graph.node_count(), 0);
    }

    #[test]
    fn test_cse_no_duplicates() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        cse(&mut graph);

        // No duplicates, graph unchanged
        assert_eq!(graph.node_count(), 3);
    }

    #[test]
    fn test_cse_duplicate_unary_ops() {
        // Input -> [Relu1, Relu2] -> Add -> Output
        // Relu1 and Relu2 are duplicates (same input)
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Relu, vec![2, 3], DType::F32), // Duplicate of 1
                OpNode::new(3, OpKind::Add, vec![2, 3], DType::F32),
                OpNode::new(4, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 1), (0, 2), (1, 3), (2, 3), (3, 4)],
        );

        let initial_count = graph.node_count();
        cse(&mut graph);

        // One Relu should be eliminated
        assert_eq!(graph.node_count(), initial_count - 1);

        // Verify we have exactly one Relu
        let relu_count = graph
            .nodes()
            .filter(|(_, n)| matches!(n.op, OpKind::Relu))
            .count();
        assert_eq!(relu_count, 1);
    }

    #[test]
    fn test_cse_different_inputs_not_duplicates() {
        // [Input1, Input2] -> [Relu1, Relu2] -> Add -> Output
        // Relu1 (from Input1) and Relu2 (from Input2) are NOT duplicates
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(3, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(4, OpKind::Add, vec![2, 3], DType::F32),
                OpNode::new(5, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 2), (1, 3), (2, 4), (3, 4), (4, 5)],
        );

        let initial_count = graph.node_count();
        cse(&mut graph);

        // No duplicates, graph unchanged
        assert_eq!(graph.node_count(), initial_count);
    }

    #[test]
    fn test_cse_different_shapes_not_duplicates() {
        // Input -> [Relu1(2x3), Relu2(4x5)] -> ...
        // Different shapes, not duplicates even with same input
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Relu, vec![4, 5], DType::F32), // Different shape
            ],
            vec![(0, 1), (0, 2)],
        );

        let initial_count = graph.node_count();
        cse(&mut graph);

        // Different shapes, no deduplication
        assert_eq!(graph.node_count(), initial_count);
    }

    #[test]
    fn test_cse_different_dtypes_not_duplicates() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Relu, vec![2, 3], DType::I32), // Different dtype
            ],
            vec![(0, 1), (0, 2)],
        );

        let initial_count = graph.node_count();
        cse(&mut graph);

        // Different dtypes, no deduplication
        assert_eq!(graph.node_count(), initial_count);
    }

    #[test]
    fn test_cse_binary_ops() {
        // [A, B] -> [Add1, Add2] -> ...
        // Add1 and Add2 are duplicates (same inputs A and B)
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Add, vec![2, 3], DType::F32),
                OpNode::new(3, OpKind::Add, vec![2, 3], DType::F32), // Duplicate
                OpNode::new(4, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 2), (1, 2), (0, 3), (1, 3), (2, 4)],
        );

        let initial_count = graph.node_count();
        cse(&mut graph);

        // One Add should be eliminated
        assert_eq!(graph.node_count(), initial_count - 1);
    }

    #[test]
    fn test_cse_matmul_with_same_dims() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32),
                OpNode::new(1, OpKind::Input, vec![4, 8], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul { m: 2, k: 4, n: 8 },
                    vec![2, 8],
                    DType::F32,
                ),
                OpNode::new(
                    3,
                    OpKind::MatMul { m: 2, k: 4, n: 8 },
                    vec![2, 8],
                    DType::F32,
                ), // Duplicate
            ],
            vec![(0, 2), (1, 2), (0, 3), (1, 3)],
        );

        let initial_count = graph.node_count();
        cse(&mut graph);

        // One MatMul should be eliminated
        assert_eq!(graph.node_count(), initial_count - 1);
    }

    #[test]
    fn test_cse_matmul_different_dims_not_duplicates() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32),
                OpNode::new(1, OpKind::Input, vec![4, 8], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul { m: 2, k: 4, n: 8 },
                    vec![2, 8],
                    DType::F32,
                ),
                OpNode::new(
                    3,
                    OpKind::MatMul { m: 4, k: 4, n: 8 },
                    vec![4, 8],
                    DType::F32,
                ), // Different m
            ],
            vec![(0, 2), (1, 2), (0, 3), (1, 3)],
        );

        let initial_count = graph.node_count();
        cse(&mut graph);

        // Different dimensions, no deduplication
        assert_eq!(graph.node_count(), initial_count);
    }

    #[test]
    fn test_cse_io_nodes_not_deduplicated() {
        // Multiple Input nodes should not be deduplicated
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Input, vec![2, 3], DType::F32),
            ],
            vec![],
        );

        let initial_count = graph.node_count();
        cse(&mut graph);

        // Input nodes should not be deduplicated
        assert_eq!(graph.node_count(), initial_count);
    }

    #[test]
    fn test_cse_multiple_duplicates() {
        // Input -> [Relu1, Relu2, Relu3] (all duplicates)
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(3, OpKind::Relu, vec![2, 3], DType::F32),
            ],
            vec![(0, 1), (0, 2), (0, 3)],
        );

        cse(&mut graph);

        // Should have 2 nodes: Input and one Relu
        assert_eq!(graph.node_count(), 2);
    }

    #[test]
    fn test_is_pure_for_cse() {
        assert!(OpKind::Add.is_pure());
        assert!(OpKind::Relu.is_pure());
        assert!(OpKind::MatMul { m: 1, k: 1, n: 1 }.is_pure());

        // Constant nodes must NOT be CSE candidates because different constants
        // may have the same shape/dtype but different data values
        assert!(!OpKind::Constant.is_pure());

        assert!(!OpKind::Load.is_pure());
        assert!(!OpKind::Store.is_pure());
        assert!(!OpKind::Input.is_pure());
        assert!(!OpKind::Output.is_pure());
        assert!(!OpKind::CallLayer { layer_id: 0 }.is_pure());
    }
}
