import React, { useState, useEffect } from 'react';
import { encodeBigIntToCategoricalX, factorizeSemiprime, randomBigInt } from '../services/codec';
import { EncodedArtifact } from '../types';
import { Activity, Key, Lock, Unlock, ArrowDown, Database, ShieldCheck, AlertTriangle } from 'lucide-react';

const FactorizationDemo: React.FC = () => {
  // We keep P and Q in state ONLY to generate N, but the "Solver" won't look at them.
  // We will nullify them in the "solved" display to prove they come from computation.
  const [generatedP, setGeneratedP] = useState<bigint>(0n);
  const [generatedQ, setGeneratedQ] = useState<bigint>(0n);
  
  const [n, setN] = useState<bigint>(0n);
  const [artifact, setArtifact] = useState<EncodedArtifact | null>(null);
  
  // Solved state
  const [solvedP, setSolvedP] = useState<bigint | null>(null);
  const [solvedQ, setSolvedQ] = useState<bigint | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const [bitSize, setBitSize] = useState(32);
  const [isComputing, setIsComputing] = useState(false);

  /**
   * Generates a prime number of approximate bit length using First Principles.
   * Uses Crypto API (randomBigInt) instead of Math.random to support arbitrary scale.
   */
  const generatePrime = (bits: number): bigint => {
    // Safety break loop
    let attempts = 0;
    while(attempts < 5000) {
        // Generate a random BigInt of 'bits' length
        let cand = randomBigInt(bits);
        // Ensure it's odd
        cand |= 1n;
        // Ensure it is large enough (set high bit)
        cand |= (1n << BigInt(bits - 1));

        if (isPrime(cand)) return cand;
        attempts++;
    }
    return 3n; // Fallback should unlikely happen
  };

  /**
   * Primality test (Miller-Rabin would be better for massive numbers, 
   * but trial division is sufficient for the demo scale of <64 bits).
   */
  const isPrime = (num: bigint): boolean => {
      if (num <= 1n) return false;
      if (num <= 3n) return true;
      if (num % 2n === 0n || num % 3n === 0n) return false;
      // Optimization: Check up to a reasonable limit for demo speed
      // Strictly speaking this is probabilistic for very large numbers if we cap the check,
      // but correct for the demo ranges.
      let limit = 10000n;
      // If number is small, check fully.
      if (num < 100000000n) limit = num;
      
      for (let i = 5n; i * i <= num && i < limit; i += 6n) {
          if (num % i === 0n || num % (i + 2n) === 0n) return false;
      }
      return true;
  };

  const handleGenerate = () => {
      // Reset solution
      setSolvedP(null);
      setSolvedQ(null);
      setError(null);

      // Generate P and Q
      const pBits = Math.floor(bitSize / 2);
      const qBits = bitSize - pBits;
      
      const newP = generatePrime(pBits);
      const newQ = generatePrime(qBits);
      
      setGeneratedP(newP);
      setGeneratedQ(newQ);
      
      const newN = newP * newQ;
      setN(newN);
      
      // Encode N into Categorical X (MRS)
      const encoded = encodeBigIntToCategoricalX(newN, "Semiprime N");
      setArtifact(encoded);
  };

  const handleSolve = async () => {
      if (n === 0n) return;
      setIsComputing(true);
      setError(null);
      
      // We use setTimeout only to allow the React UI to render the "Computing" state
      // The actual computation happens in the next tick synchronously (blocking main thread briefly)
      setTimeout(() => {
          const startTime = performance.now();
          const result = factorizeSemiprime(n);
          const endTime = performance.now();
          console.log(`Factorization computed in ${(endTime - startTime).toFixed(2)}ms`);

          if (result) {
              setSolvedP(result.p);
              setSolvedQ(result.q);
          } else {
              setError("Computation limit reached. The number is too complex for the browser thread.");
          }
          setIsComputing(false);
      }, 50);
  };

  useEffect(() => {
      handleGenerate();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bitSize]);

  // Helper to get RNS residue
  const getRNS = (val: bigint, modStr: string) => {
      return val % BigInt(modStr);
  }

  const isSolved = solvedP !== null && solvedQ !== null;

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-y-auto">
         <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-lg">
            <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
                <Key className="w-6 h-6 text-yellow-400" />
                Gauge Factorization
            </h2>
            <p className="text-slate-400 mb-6">
                Real-time decomposition of Semiprimes ($N = p \times q$). 
                Uses <strong>Arbitrary Precision Cryptographic Key Generation</strong> to create first-principles Semiprimes, then encodes them into the Categorical X Gauge, and executes Pollard's Rho to isolate the prime factors.
            </p>

            {/* Controls */}
            <div className="flex flex-wrap items-center gap-6 mb-8 bg-slate-900 p-4 rounded-lg border border-slate-700">
                <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-400">Scale (Bits):</span>
                    <input 
                        type="range" 
                        min="16" max="64" step="4"
                        value={bitSize}
                        onChange={(e) => setBitSize(parseInt(e.target.value))}
                        className="w-32"
                    />
                    <span className="font-mono text-white w-8">{bitSize}</span>
                </div>
                <button 
                    onClick={handleGenerate}
                    className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded flex items-center gap-2 transition-colors"
                >
                    <Activity className="w-4 h-4" /> Generate New N
                </button>
                <div className="ml-auto">
                    {!isSolved ? (
                         <button 
                            onClick={handleSolve}
                            disabled={isComputing}
                            className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded flex items-center gap-2 shadow-lg shadow-blue-900/20 disabled:opacity-50"
                        >
                            {isComputing ? "Computing Primes..." : "Solve N"}
                            <Unlock className="w-4 h-4" />
                        </button>
                    ) : (
                        <div className="flex items-center gap-2 text-emerald-400 font-bold bg-emerald-900/20 px-4 py-2 rounded border border-emerald-500/30">
                            <ShieldCheck className="w-5 h-5" />
                            Factors Found
                        </div>
                    )}
                </div>
            </div>

            {error && (
                <div className="mb-4 p-4 bg-red-900/20 border border-red-500/50 rounded flex items-center gap-2 text-red-200">
                    <AlertTriangle className="w-5 h-5" />
                    {error}
                </div>
            )}

            {/* Visualization */}
            <div className="space-y-2">
                {/* N Section */}
                <div className="flex items-center gap-4">
                     <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center border-2 border-slate-500">
                        <span className="text-xl font-bold text-white">N</span>
                     </div>
                     <div className="flex-1 bg-slate-900 p-4 rounded border border-slate-700 font-mono text-slate-300 break-all">
                        {n.toString()}
                     </div>
                </div>

                <div className="flex justify-center py-2">
                    <ArrowDown className="w-6 h-6 text-slate-600 animate-bounce" />
                </div>

                {/* Gauge Tower Table */}
                <div className="bg-slate-900 rounded-lg border border-slate-700 overflow-hidden">
                    <div className="px-4 py-2 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
                        <span className="text-xs font-bold uppercase text-slate-400">Hierarchical Gauge Projection</span>
                        <span className="text-xs text-slate-500">Categorical X Model</span>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-slate-900/50 text-slate-400 text-xs uppercase">
                                    <th className="p-3 border-b border-slate-800">Level</th>
                                    <th className="p-3 border-b border-slate-800">{"Gauge Modulus ($m_k$)"}</th>
                                    <th className="p-3 border-b border-slate-800 text-blue-400">{"N Residue ($r_k$)"}</th>
                                    {isSolved && (
                                        <>
                                            <th className="p-3 border-b border-slate-800 text-emerald-400">{'P Residue ($p \\pmod {m_k}$)'}</th>
                                            <th className="p-3 border-b border-slate-800 text-emerald-400">{'Q Residue ($q \\pmod {m_k}$)'}</th>
                                            <th className="p-3 border-b border-slate-800 text-yellow-400">{"Verify ($P \\times Q \\equiv N$)"}</th>
                                        </>
                                    )}
                                </tr>
                            </thead>
                            <tbody className="text-sm font-mono">
                                {artifact?.coordinates.map((coord) => {
                                    const rnsN = getRNS(n, coord.modulus);
                                    let rnsP = 0n;
                                    let rnsQ = 0n;
                                    let verify = false;
                                    
                                    if (isSolved && solvedP && solvedQ) {
                                        rnsP = getRNS(solvedP, coord.modulus);
                                        rnsQ = getRNS(solvedQ, coord.modulus);
                                        verify = (rnsP * rnsQ) % BigInt(coord.modulus) === rnsN;
                                    }

                                    return (
                                        <tr key={coord.level} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                                            <td className="p-3 text-slate-500">{coord.level}</td>
                                            <td className="p-3 text-slate-300">{coord.modulus}</td>
                                            <td className="p-3 text-purple-300">{rnsN.toString()}</td>
                                            {isSolved && (
                                                <>
                                                    <td className="p-3 text-emerald-300">{rnsP.toString()}</td>
                                                    <td className="p-3 text-emerald-300">{rnsQ.toString()}</td>
                                                    <td className="p-3">
                                                        {verify ? (
                                                            <span className="text-yellow-400 font-bold">✓ Match</span>
                                                        ) : (
                                                            <span className="text-red-500">Mismatch</span>
                                                        )}
                                                    </td>
                                                </>
                                            )}
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Decoded Primes Section */}
                {isSolved && solvedP && solvedQ && (
                    <div className="pt-4 animate-in fade-in slide-in-from-top-4 duration-700">
                         <div className="grid grid-cols-2 gap-4">
                            <div className="bg-emerald-900/10 border border-emerald-500/30 rounded p-4 relative overflow-hidden group">
                                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                                    <Lock className="w-16 h-16 text-emerald-400" />
                                </div>
                                <span className="text-emerald-500 text-xs font-bold uppercase">Decoded Prime P</span>
                                <div className="text-2xl font-mono text-emerald-300 mt-2 break-all">{solvedP.toString()}</div>
                            </div>
                            <div className="bg-emerald-900/10 border border-emerald-500/30 rounded p-4 relative overflow-hidden group">
                                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                                    <Lock className="w-16 h-16 text-emerald-400" />
                                </div>
                                <span className="text-emerald-500 text-xs font-bold uppercase">Decoded Prime Q</span>
                                <div className="text-2xl font-mono text-emerald-300 mt-2 break-all">{solvedQ.toString()}</div>
                            </div>
                         </div>
                         <div className="mt-4 p-3 bg-yellow-400/10 border border-yellow-400/20 rounded text-yellow-200 text-sm flex items-center gap-2">
                             <Database className="w-4 h-4" />
                             Factorization Complete: Primes computed successfully.
                         </div>
                    </div>
                )}
            </div>
         </div>
    </div>
  );
};

export default FactorizationDemo;