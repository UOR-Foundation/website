//! Benchmarks for graph operations.

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use hologram_graph::{
    levels, node_depths, reachable_from, toposort, ComputeGraph, GraphBuilder, NodeId,
};

#[derive(Debug, Clone)]
enum BenchOp {
    Input,
    Add,
    Mul,
    Output,
}

/// Create a linear chain graph: A -> B -> C -> ... -> N
fn linear_graph(n: usize) -> ComputeGraph<BenchOp> {
    let mut graph = ComputeGraph::new();
    let mut prev = graph.add_node(BenchOp::Input);

    for i in 1..n {
        let op = if i == n - 1 {
            BenchOp::Output
        } else {
            BenchOp::Add
        };
        let curr = graph.add_node(op);
        graph.add_edge(prev, curr);
        prev = curr;
    }
    graph
}

/// Create a wide graph with many parallel paths.
fn wide_graph(width: usize, depth: usize) -> ComputeGraph<BenchOp> {
    let mut graph = ComputeGraph::new();

    // First layer: width inputs
    let mut prev_layer: Vec<NodeId> = (0..width).map(|_| graph.add_node(BenchOp::Input)).collect();

    // Middle layers
    for _ in 1..depth - 1 {
        let mut curr_layer = Vec::with_capacity(width);
        for &prev in &prev_layer {
            let node = graph.add_node(BenchOp::Add);
            graph.add_edge(prev, node);
            curr_layer.push(node);
        }
        prev_layer = curr_layer;
    }

    // Final layer: merge all to one output
    let output = graph.add_node(BenchOp::Output);
    for &prev in &prev_layer {
        graph.add_edge(prev, output);
    }

    graph
}

/// Create a diamond-shaped graph.
fn diamond_graph(levels_count: usize) -> ComputeGraph<BenchOp> {
    let mut graph = ComputeGraph::new();

    // Start with one node
    let start = graph.add_node(BenchOp::Input);
    let mut prev_level = vec![start];

    // Expanding phase
    for level in 1..=levels_count {
        let mut current_level = Vec::new();
        for _ in 0..level {
            let node = graph.add_node(BenchOp::Add);
            for &prev in &prev_level {
                graph.add_edge(prev, node);
            }
            current_level.push(node);
        }
        prev_level = current_level;
    }

    // Contracting phase
    for level in (1..levels_count).rev() {
        let mut current_level = Vec::new();
        for _ in 0..level {
            let node = graph.add_node(BenchOp::Mul);
            for &prev in &prev_level {
                graph.add_edge(prev, node);
            }
            current_level.push(node);
        }
        prev_level = current_level;
    }

    // Final output
    let output = graph.add_node(BenchOp::Output);
    for &prev in &prev_level {
        graph.add_edge(prev, output);
    }

    graph
}

fn bench_add_node(c: &mut Criterion) {
    let mut group = c.benchmark_group("add_node");

    for size in [10, 100, 1000] {
        group.throughput(Throughput::Elements(size as u64));
        group.bench_with_input(BenchmarkId::from_parameter(size), &size, |b, &size| {
            b.iter(|| {
                let mut graph = ComputeGraph::new();
                for _ in 0..size {
                    black_box(graph.add_node(BenchOp::Add));
                }
                graph
            });
        });
    }

    group.finish();
}

fn bench_toposort(c: &mut Criterion) {
    let mut group = c.benchmark_group("toposort");

    // Linear graphs
    for size in [10, 100, 1000] {
        let graph = linear_graph(size);
        group.throughput(Throughput::Elements(size as u64));
        group.bench_with_input(BenchmarkId::new("linear", size), &graph, |b, graph| {
            b.iter(|| black_box(toposort(graph).unwrap()));
        });
    }

    // Wide graphs
    for (width, depth) in [(10, 10), (50, 10), (10, 50)] {
        let graph = wide_graph(width, depth);
        let size = graph.node_count();
        group.throughput(Throughput::Elements(size as u64));
        group.bench_with_input(
            BenchmarkId::new("wide", format!("{width}x{depth}")),
            &graph,
            |b, graph| {
                b.iter(|| black_box(toposort(graph).unwrap()));
            },
        );
    }

    group.finish();
}

fn bench_node_depths(c: &mut Criterion) {
    let mut group = c.benchmark_group("node_depths");

    for size in [10, 100, 1000] {
        let graph = linear_graph(size);
        group.throughput(Throughput::Elements(size as u64));
        group.bench_with_input(BenchmarkId::from_parameter(size), &graph, |b, graph| {
            b.iter(|| black_box(node_depths(graph)));
        });
    }

    group.finish();
}

fn bench_levels(c: &mut Criterion) {
    let mut group = c.benchmark_group("levels");

    // Diamond graphs are good for level testing
    for diamond_size in [3, 5, 7] {
        let graph = diamond_graph(diamond_size);
        let node_count = graph.node_count();
        group.throughput(Throughput::Elements(node_count as u64));
        group.bench_with_input(
            BenchmarkId::from_parameter(diamond_size),
            &graph,
            |b, graph| {
                b.iter(|| black_box(levels(graph)));
            },
        );
    }

    group.finish();
}

fn bench_reachability(c: &mut Criterion) {
    let mut group = c.benchmark_group("reachability");

    for size in [10, 100, 1000] {
        let graph = linear_graph(size);
        let start = graph.node_ids()[0];
        group.throughput(Throughput::Elements(size as u64));
        group.bench_with_input(
            BenchmarkId::from_parameter(size),
            &(graph, start),
            |b, (graph, start)| {
                b.iter(|| black_box(reachable_from(graph, *start)));
            },
        );
    }

    group.finish();
}

fn bench_predecessors_successors(c: &mut Criterion) {
    let mut group = c.benchmark_group("predecessors_successors");

    let graph = wide_graph(50, 10);
    let middle_node = graph.node_ids()[graph.node_count() / 2];

    group.bench_function("predecessors", |b| {
        b.iter(|| black_box(graph.predecessors(middle_node)));
    });

    group.bench_function("successors", |b| {
        b.iter(|| black_box(graph.successors(middle_node)));
    });

    group.finish();
}

fn bench_builder(c: &mut Criterion) {
    let mut group = c.benchmark_group("builder");

    for size in [10, 100, 1000] {
        group.throughput(Throughput::Elements(size as u64));
        group.bench_with_input(BenchmarkId::from_parameter(size), &size, |b, &size| {
            b.iter(|| {
                let mut builder = GraphBuilder::new().node(BenchOp::Input);
                for _ in 1..size {
                    builder = builder.node_with_inputs(BenchOp::Add, &[]);
                }
                black_box(builder.build())
            });
        });
    }

    group.finish();
}

fn bench_node_lookup(c: &mut Criterion) {
    let mut group = c.benchmark_group("node_lookup");

    let graph = linear_graph(1000);
    let ids: Vec<NodeId> = graph.node_ids();

    group.bench_function("get_existing", |b| {
        let mut i = 0;
        b.iter(|| {
            let id = ids[i % ids.len()];
            i += 1;
            black_box(graph.get(id))
        });
    });

    group.bench_function("contains_existing", |b| {
        let mut i = 0;
        b.iter(|| {
            let id = ids[i % ids.len()];
            i += 1;
            black_box(graph.contains(id))
        });
    });

    let invalid = NodeId::new(9999, 0);
    group.bench_function("get_invalid", |b| {
        b.iter(|| black_box(graph.get(invalid)));
    });

    group.finish();
}

criterion_group!(
    benches,
    bench_add_node,
    bench_toposort,
    bench_node_depths,
    bench_levels,
    bench_reachability,
    bench_predecessors_successors,
    bench_builder,
    bench_node_lookup,
);

criterion_main!(benches);
