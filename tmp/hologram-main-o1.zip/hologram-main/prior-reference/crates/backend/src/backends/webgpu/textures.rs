//! WebGPU texture support for activation table lookups.
//!
//! This module implements `TextureActivation` for the WebGPU backend,
//! providing GPU texture-based activation lookups using wgpu textures.
//!
//! # Performance
//!
//! WebGPU textures provide:
//! - Texture sampling with dedicated cache
//! - Cross-platform GPU support (Vulkan, Metal, DX12, WebGPU)
//! - Hardware-accelerated filtering
//! - Efficient memory access patterns
//!
//! # Usage
//!
//! ```ignore
//! use hologram_backend::backends::webgpu::WebGpuBackend;
//! use hologram_backend::backends::webgpu::textures::WebGpuActivationTextures;
//! use hologram_backend::core::gpu_textures::TextureActivation;
//! use hologram_backend::plan::activation_table_id;
//!
//! let backend = WebGpuBackend::new();
//! let mut textures = WebGpuActivationTextures::new(backend.device(), backend.queue());
//! textures.preload_standard_textures();
//!
//! // Texture is now available for use in compute shaders
//! let tex = textures.get_activation_texture(activation_table_id::SIGMOID);
//! ```

use crate::core::gpu_textures::{get_activation_table, TextureActivation, TextureCache};
use std::sync::Arc;
use wgpu::{Device, Queue, Texture, TextureView};

/// WebGPU texture handle for activation lookups.
///
/// Wraps a wgpu texture created from an activation table.
#[derive(Clone)]
pub struct WebGpuTextureHandle {
    /// The wgpu texture containing activation data.
    pub texture: Arc<Texture>,
    /// Texture view for shader binding.
    pub view: Arc<TextureView>,
    /// Table ID this texture represents.
    pub table_id: u32,
}

/// WebGPU activation texture manager.
///
/// Manages creation and caching of WebGPU textures for activation tables.
pub struct WebGpuActivationTextures {
    device: Arc<Device>,
    queue: Arc<Queue>,
    cache: TextureCache<WebGpuTextureHandle>,
}

impl WebGpuActivationTextures {
    /// Create a new texture manager for the given device and queue.
    pub fn new(device: Arc<Device>, queue: Arc<Queue>) -> Self {
        Self {
            device,
            queue,
            cache: TextureCache::new(),
        }
    }

    /// Create a WebGPU texture from an activation table.
    fn create_texture(&self, table_id: u32) -> Option<WebGpuTextureHandle> {
        let table_data = get_activation_table(table_id)?;

        // Create 1D texture (256 pixels wide)
        let texture = self.device.create_texture(&wgpu::TextureDescriptor {
            label: Some(&format!("Activation Table {}", table_id)),
            size: wgpu::Extent3d {
                width: 256,
                height: 1,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D1,
            format: wgpu::TextureFormat::R8Unorm,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });

        // Copy table data to texture
        self.queue.write_texture(
            wgpu::ImageCopyTexture {
                texture: &texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            table_data,
            wgpu::ImageDataLayout {
                offset: 0,
                bytes_per_row: Some(256),
                rows_per_image: None,
            },
            wgpu::Extent3d {
                width: 256,
                height: 1,
                depth_or_array_layers: 1,
            },
        );

        // Create texture view
        let view = texture.create_view(&wgpu::TextureViewDescriptor::default());

        Some(WebGpuTextureHandle {
            texture: Arc::new(texture),
            view: Arc::new(view),
            table_id,
        })
    }

    /// Get texture view for use in shader bind groups.
    pub fn get_texture_view(&self, table_id: u32) -> Option<&Arc<TextureView>> {
        self.cache.get(table_id).map(|h| &h.view)
    }

    /// Create a sampler suitable for activation lookups.
    pub fn create_activation_sampler(&self) -> wgpu::Sampler {
        self.device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("Activation Sampler"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Nearest,
            min_filter: wgpu::FilterMode::Nearest,
            mipmap_filter: wgpu::FilterMode::Nearest,
            ..Default::default()
        })
    }
}

impl TextureActivation for WebGpuActivationTextures {
    type TextureHandle = WebGpuTextureHandle;

    fn create_activation_texture(&mut self, table_id: u32) -> Option<Self::TextureHandle> {
        // Check cache first
        if let Some(handle) = self.cache.get(table_id) {
            return Some(handle.clone());
        }

        // Create new texture
        if let Some(handle) = self.create_texture(table_id) {
            self.cache.insert(table_id, handle.clone());
            Some(handle)
        } else {
            None
        }
    }

    fn get_activation_texture(&self, table_id: u32) -> Option<&Self::TextureHandle> {
        self.cache.get(table_id)
    }

    fn supports_texture_activations(&self) -> bool {
        true
    }
}

/// WGSL shader snippet for texture-based activation lookup.
///
/// Include this in your WGSL compute shaders to enable texture-based
/// activation in epilogue operations.
pub const ACTIVATION_TEXTURE_WGSL: &str = r#"
// Activation texture and sampler bindings
@group(1) @binding(0) var activation_texture: texture_1d<f32>;
@group(1) @binding(1) var activation_sampler: sampler;

// Apply activation from texture lookup
fn activation_lookup(value: f32) -> f32 {
    // Clamp to [0, 1] range and map to texture coordinate
    let clamped = clamp(value, 0.0, 1.0);
    // textureSample returns normalized value from R8Unorm texture
    return textureSample(activation_texture, activation_sampler, clamped).r;
}

// Apply sigmoid-like activation (assuming input is in [-8, 8] range)
fn sigmoid_activation(value: f32) -> f32 {
    // Map [-8, 8] to [0, 1] for texture lookup
    let normalized = (value + 8.0) * 0.0625; // 1/16
    return activation_lookup(normalized);
}
"#;

/// WGSL shader snippet for epilogue activation in matmul/conv operations.
pub const EPILOGUE_ACTIVATION_WGSL: &str = r#"
// Epilogue activation with texture lookup
fn apply_epilogue_activation(
    value: f32,
    activation_texture: texture_1d<f32>,
    activation_sampler: sampler
) -> f32 {
    // Normalize value to [0, 1] assuming input is in reasonable range
    let normalized = (value + 8.0) * 0.0625; // Map [-8, 8] to [0, 1]
    let clamped = clamp(normalized, 0.0, 1.0);
    return textureSample(activation_texture, activation_sampler, clamped).r;
}
"#;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_wgsl_shaders_not_empty() {
        assert!(!ACTIVATION_TEXTURE_WGSL.is_empty());
        assert!(!EPILOGUE_ACTIVATION_WGSL.is_empty());
    }
}
