# .holo File Format

This document describes the binary formats used by Hologram for storing compiled models and pipelines.

## Overview

Hologram uses three format variants for different use cases:

| Format | Magic | Extension | Purpose |
|--------|-------|-----------|---------|
| Single Graph | (none) | `.holo` | Raw rkyv-serialized `BackendPlan` |
| HOLB | `HOLB` | `.holb` | Single model bundle with embedded weights and sections |
| HOLM | `HOLM` | `.holo` | Multi-model pipeline containing multiple HOLB bundles |

Format detection uses magic bytes at offset 0. Files without magic bytes are treated as raw `BackendPlan` archives.

---

## HOLB Format (Single Model Bundle)

HOLB bundles a compiled graph with its weights and optional metadata sections into a single file. Two header versions exist:

- **V1 (48 bytes)**: Basic format without sections
- **V2 (80 bytes)**: Extended format with sections table

The writer automatically selects V2 when sections are added.

### V1 Header Layout (48 bytes)

```
Offset  Size  Field             Description
------  ----  -----             -----------
0       4     magic             "HOLB" (0x484F4C42)
4       4     version           1
8       8     graph_offset      Offset to BackendPlan data
16      8     graph_size        Size of BackendPlan in bytes
24      8     weights_offset    Offset to weights (page-aligned)
32      8     weights_size      Size of weights in bytes
40      4     graph_checksum    CRC32 of BackendPlan
44      4     weights_checksum  CRC32 of weights
```

### V1 File Layout

```
+---------------------------+
| HOLB Header (48 bytes)    |
+---------------------------+
| BackendPlan data          |
+---------------------------+
| Padding to 4KB boundary   |
+---------------------------+
| Weights (page-aligned)    |
+---------------------------+
```

### V2 Header Layout (80 bytes)

```
Offset  Size  Field                  Description
------  ----  -----                  -----------
0       4     magic                  "HOLB" (0x484F4C42)
4       4     version                2
8       4     flags                  Reserved (0)
12      4     _reserved1             Internal padding
16      8     graph_offset           Offset to BackendPlan data
24      8     graph_size             Size of BackendPlan in bytes
32      8     weights_offset         Offset to weights (page-aligned)
40      8     weights_size           Size of weights in bytes
48      4     graph_checksum         CRC32 of BackendPlan
52      4     weights_checksum       CRC32 of weights
56      8     sections_table_offset  Offset to sections table
64      4     sections_count         Number of sections
68      4     _reserved2             Internal padding
72      8     (padding)              Alignment to 80 bytes
```

### V2 File Layout

```
+---------------------------+
| HOLB Header (80 bytes)    |
+---------------------------+
| BackendPlan data          |
+---------------------------+
| Padding to 4KB boundary   |
+---------------------------+
| Sections table            |
+---------------------------+
| Section 0 data            |
| Section 1 data            |
| ...                       |
+---------------------------+
| Padding to 4KB boundary   |
+---------------------------+
| Weights (page-aligned)    |
+---------------------------+
```

### Section Table Entry

Each section in the table has:

```
Field         Type      Description
-----         ----      -----------
id            String    Section identifier (e.g., "vocabulary")
content_type  String    MIME type (e.g., "text/plain")
version       u32       Section format version
offset        u64       Byte offset in file
size          u64       Size in bytes
checksum      u32       CRC32 checksum
```

### Usage Example

```rust
use hologram_holo::writer::HolbWriter;
use hologram_holo::reader::HolbReader;

// Writing a HOLB bundle
let mut writer = HolbWriter::new();
writer.set_graph(&plan_bytes);
writer.set_weights(&weights_bytes);
writer.add_raw_section("vocabulary", "text/plain", vocab_data);
let bundle = writer.build()?;

// Reading a HOLB bundle
let reader = HolbReader::from_bytes(&bundle)?;
println!("Version: {}", reader.version());
let graph = reader.graph();           // Zero-copy slice
let weights = reader.weights();       // Zero-copy slice
let vocab = reader.get_section("vocabulary");

// Verify integrity
assert!(reader.verify_all_checksums());
```

---

## HOLM Format (Multi-Model Pipeline)

HOLM bundles multiple HOLB models into a single file for multi-stage pipelines (e.g., encoder + decoder + tokenizer).

### Header Layout (64 bytes)

```
Offset  Size  Field              Description
------  ----  -----              -----------
0       4     magic              "HOLM" (0x484F4C4D)
4       4     version            1
8       4     flags              Reserved (0)
12      4     model_count        Number of models in pipeline
16      8     index_offset       Offset to model index
24      8     index_size         Size of index in bytes
32      8     models_offset      Offset to first model (page-aligned)
40      8     models_total_size  Total size of all model data
48      4     index_checksum     CRC32 of index
52      4     _reserved          Internal padding
56      8     (padding)          Alignment to 64 bytes
```

### File Layout

```
+---------------------------+
| HOLM Header (64 bytes)    |
+---------------------------+
| Model index               |
+---------------------------+
| Padding to 4KB boundary   |
+---------------------------+
| Model 0 (complete HOLB)   |
+---------------------------+
| Padding to 4KB boundary   |
+---------------------------+
| Model 1 (complete HOLB)   |
+---------------------------+
| Padding to 4KB boundary   |
+---------------------------+
| Model 2 (complete HOLB)   |
+---------------------------+
| ...                       |
+---------------------------+
```

### Model Index Entry

Each model in the index has:

```
Field     Type    Description
-----     ----    -----------
name      String  Model identifier (length-prefixed)
offset    u64     Byte offset in file
size      u64     Size in bytes
checksum  u32     CRC32 checksum
```

### Usage Example

```rust
use hologram_holo::pipeline::{HolmWriter, HolmReader};
use hologram_holo::writer::HolbWriter;

// Create individual HOLB bundles
let mut encoder = HolbWriter::new();
encoder.set_graph(&encoder_plan);
let encoder_bundle = encoder.build()?;

let mut decoder = HolbWriter::new();
decoder.set_graph(&decoder_plan);
let decoder_bundle = decoder.build()?;

// Package into pipeline
let mut writer = HolmWriter::new();
writer.add_model("encoder", &encoder_bundle)?;
writer.add_model("decoder", &decoder_bundle)?;
let pipeline = writer.build()?;

// Reading a pipeline
let reader = HolmReader::from_bytes(&pipeline)?;
println!("Models: {:?}", reader.model_names());

// Access individual models
let encoder_data = reader.get_model("encoder")?.unwrap();
let decoder_data = reader.get_model("decoder")?.unwrap();

// Iterate all models
for (name, result) in reader.iter_models() {
    let data = result?;
    println!("{}: {} bytes", name, data.len());
}
```

---

## Design Principles

### Page Alignment

Weights, sections, and model data are aligned to 4KB page boundaries (`PAGE_SIZE = 4096`). This enables:

- Efficient memory-mapped file access
- Direct DMA transfers to GPU memory
- Cache-friendly access patterns

### Zero-Copy Access

Readers provide slices into the underlying buffer without copying:

```rust
let reader = HolbReader::from_bytes(&mmap)?;
let graph = reader.graph();    // Points into mmap, no allocation
let weights = reader.weights(); // Points into mmap, no allocation
```

### CRC32 Checksums

All data segments have CRC32 checksums (IEEE polynomial, same as zlib/gzip):

- Graph checksum
- Weights checksum
- Section checksums
- Model checksums (HOLM)
- Index checksum (HOLM)

### Embedded Sections

V2 HOLB supports arbitrary embedded sections for:

- Vocabulary/token mappings
- Tokenizer configuration
- Model metadata
- Custom application data

Sections implement the `EmbeddableSection` trait:

```rust
pub trait EmbeddableSection {
    fn section_id(&self) -> &'static str;
    fn content_type(&self) -> &'static str;
    fn version(&self) -> u32;
    fn to_bytes(&self) -> Vec<u8>;
}
```

---

## Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `HOLB_MAGIC` | `b"HOLB"` | HOLB format magic bytes |
| `HOLM_MAGIC` | `b"HOLM"` | HOLM format magic bytes |
| `PAGE_SIZE` | 4096 | Alignment boundary |
| `HOLB_HEADER_SIZE_V1` | 48 | V1 header size |
| `HOLB_HEADER_SIZE_V2` | 80 | V2 header size |
| `HOLM_HEADER_SIZE` | 64 | HOLM header size |

---

## See Also

- [architecture.md](architecture.md) - Compilation pipeline and execution model
- [crates/holo/src/format.rs](../crates/holo/src/format.rs) - Header definitions
- [crates/holo/src/writer.rs](../crates/holo/src/writer.rs) - HOLB writer implementation
- [crates/holo/src/reader.rs](../crates/holo/src/reader.rs) - HOLB reader implementation
- [crates/holo/src/pipeline.rs](../crates/holo/src/pipeline.rs) - HOLM reader/writer
