# UOR C Bindings Example

This directory contains example C programs demonstrating how to use the UOR C bindings.

## Prerequisites

- GCC or Clang compiler
- UOR library built in release mode (`just ffi-c`)

## Building

### Option 1: Using Make

```bash
cd examples/c
make
```

This will automatically:
1. Build the UOR FFI library with C bindings (`just ffi-c`)
2. Compile the example program
3. Link against the shared library with proper rpath

### Option 2: Manual Build

```bash
# From workspace root
just ffi-c

# Compile the example
gcc -o example examples/c/example.c \
    -I bindings/c \
    -L target/release \
    -luor_ffi \
    -Wl,-rpath,target/release
```

## Running

```bash
# Using make
make run

# Or directly
./example
```

## Expected Output

The example program demonstrates:

1. **Constants**: Braille base/max codepoints, triadic/octave constants, state dimensions
2. **Taxon Operations**: Converting bytes to Braille characters, codepoints, domains, and ranks
3. **Ring Operations**: Successor, predecessor, and bitwise NOT operations
4. **View Operations**: Creating views (identity, constant), applying views to bytes and arrays, view composition

Sample output:
```
=== UOR C Bindings Example ===

Constants:
  Braille Base: U+2800
  Braille Max:  U+28FF
  Triadic (T):  3
  Octave (O):   8
  State Taxons: 624
  State Bits:   4992

Taxon Operations:
  Byte 42 -> Braille: ⠪
  Byte 42 -> Codepoint: U+282A
  Byte 42 -> Domain: 0
  Byte 42 -> Rank: 42

Ring Operations:
  Byte 42 -> Successor: 43
  Byte 42 -> Predecessor: 41
  Byte 42 -> NOT: 213

View Operations:
  Created identity view
  Identity(42) = 42
  Constant(42) = 99
  Constant view is bijective: false
  Identity.then(Identity)(42) = 42

  Applying identity view to array...
  Input:  [0, 1, 2, 3, 4, 5, 6, 7]
  Output: [0, 1, 2, 3, 4, 5, 6, 7]

=== All tests completed successfully! ===
```

## Memory Management

The C bindings follow a caller-frees pattern:

- **Strings**: Returned strings must be freed with `uor_string_free()`
- **Views**: Created views must be freed with `uor_view_free()`
- **Scalars**: Scalar values (bytes, integers) do not require cleanup

Example:
```c
char* braille = uor_byte_to_braille(42);
printf("Braille: %s\n", braille);
uor_string_free(braille);  // Must free!

struct UorView* view = uor_view_identity();
// ... use view ...
uor_view_free(view);  // Must free!
```

## API Reference

See [bindings/c/uor.h](../../bindings/c/uor.h) for the complete C API documentation.

All functions include safety notes and usage examples in the header file.
