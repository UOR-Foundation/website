//! GPU kernel interface definitions.
//!
//! This module defines the mapping from ISA instructions to GPU kernel signatures.
//! GPU backends (CUDA, Metal) implement these kernel signatures to execute
//! ISA operations on GPU hardware.
//!
//! # Architecture
//!
//! ISA instructions are grouped into kernel categories:
//! - **Element-wise**: Operations that process one element at a time (Add, Sub, Mul, Sigmoid, etc.)
//! - **Reduction**: Operations that reduce many elements to one (Sum, Max, Min)
//! - **Matrix**: Matrix operations (MatMul)
//! - **Categorical**: UOR-specific operations (Lift, OrbitClassify, RingAdd, RingMul)
//! - **Memory**: Data movement operations (Copy, Load, Store)
//!
//! Each category has a corresponding kernel signature trait that GPU backends implement.
//!
//! # Zero-Copy Design
//!
//! Kernels receive GPU buffer handles, not host data. The host-device boundary
//! is crossed once when loading the plan, not per-instruction.

use super::gpu::GpuBuffer;
use crate::types::Result;

/// Kernel category for ISA instructions.
///
/// Used for kernel dispatch, occupancy tuning, and memory planning.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KernelCategory {
    /// Element-wise operations (1:1 input to output mapping)
    ElementWise,
    /// Reduction operations (N:1 input to output mapping)
    Reduction,
    /// Matrix operations (blocked computation)
    Matrix,
    /// UOR categorical operations
    Categorical,
    /// Memory movement operations
    Memory,
    /// Layer composition (not a GPU kernel)
    Control,
}

// Generated from descriptors/shells/isa.shell @kernel annotations
include!(concat!(env!("OUT_DIR"), "/generated_kernel_classify.rs"));

/// Element-wise kernel parameters.
///
/// Used for Add, Sub, Mul and unary operations like Sigmoid, Tanh, Relu.
#[derive(Debug, Clone, Copy)]
pub struct ElementWiseParams {
    /// Destination buffer
    pub dst: GpuBuffer,
    /// First source buffer
    pub src_a: GpuBuffer,
    /// Second source buffer (unused for unary ops)
    pub src_b: Option<GpuBuffer>,
    /// Number of elements to process
    pub count: usize,
}

/// Reduction kernel parameters.
///
/// Used for Sum, Max, Min operations.
#[derive(Debug, Clone, Copy)]
pub struct ReductionParams {
    /// Destination buffer (single element output)
    pub dst: GpuBuffer,
    /// Source buffer
    pub src: GpuBuffer,
    /// Number of elements to reduce
    pub count: usize,
}

/// Matrix multiplication kernel parameters.
#[derive(Debug, Clone, Copy)]
pub struct MatMulParams {
    /// Output matrix C (M × N)
    pub c: GpuBuffer,
    /// Left matrix A (M × K)
    pub a: GpuBuffer,
    /// Right matrix B (K × N)
    pub b: GpuBuffer,
    /// Number of rows in A and C
    pub m: usize,
    /// Shared dimension (columns of A, rows of B)
    pub k: usize,
    /// Number of columns in B and C
    pub n: usize,
}

/// Categorical operation kernel parameters.
///
/// Used for UOR-specific operations (Lift, OrbitClassify, RingAdd, RingMul).
#[derive(Debug, Clone, Copy)]
pub struct CategoricalParams {
    /// Destination buffer
    pub dst: GpuBuffer,
    /// First source buffer
    pub src_a: GpuBuffer,
    /// Second source buffer (unused for unary categorical ops)
    pub src_b: Option<GpuBuffer>,
    /// Number of elements
    pub count: usize,
}

/// Memory operation kernel parameters.
#[derive(Debug, Clone, Copy)]
pub struct MemoryParams {
    /// Destination buffer
    pub dst: GpuBuffer,
    /// Source buffer
    pub src: GpuBuffer,
    /// Size in bytes
    pub size: usize,
}

/// Element-wise kernel trait for GPU backends.
///
/// GPU backends implement this trait to provide element-wise operations.
pub trait ElementWiseKernels {
    /// Element-wise addition: `dst[i] = a[i] + b[i]`
    fn kernel_add(&self, params: &ElementWiseParams) -> Result<()>;

    /// Element-wise subtraction: `dst[i] = a[i] - b[i]`
    fn kernel_sub(&self, params: &ElementWiseParams) -> Result<()>;

    /// Element-wise multiplication: `dst[i] = a[i] * b[i]`
    fn kernel_mul(&self, params: &ElementWiseParams) -> Result<()>;

    /// Sigmoid activation: `dst[i] = 1 / (1 + exp(-src[i]))`
    fn kernel_sigmoid(&self, params: &ElementWiseParams) -> Result<()>;

    /// Hyperbolic tangent: `dst[i] = tanh(src[i])`
    fn kernel_tanh(&self, params: &ElementWiseParams) -> Result<()>;

    /// ReLU activation: `dst[i] = max(0, src[i])`
    fn kernel_relu(&self, params: &ElementWiseParams) -> Result<()>;
}

/// Reduction kernel trait for GPU backends.
pub trait ReductionKernels {
    /// Sum reduction: `dst[0] = sum(src[i])`
    fn kernel_sum(&self, params: &ReductionParams) -> Result<()>;

    /// Max reduction: `dst[0] = max(src[i])`
    fn kernel_max(&self, params: &ReductionParams) -> Result<()>;

    /// Min reduction: `dst[0] = min(src[i])`
    fn kernel_min(&self, params: &ReductionParams) -> Result<()>;
}

/// Matrix kernel trait for GPU backends.
pub trait MatrixKernels {
    /// Matrix multiplication: C = A @ B
    fn kernel_matmul(&self, params: &MatMulParams) -> Result<()>;
}

/// Categorical kernel trait for GPU backends.
///
/// Implements UOR-specific operations using **O(1) precomputed lookup tables (LUTs)**.
/// These operations form the foundation of hologram's constant-time computation model.
///
/// # LUT-Based Implementation
///
/// All categorical operations use precomputed tables from `uor::lut`:
///
/// | Operation | LUT Function | Table Size |
/// |-----------|--------------|------------|
/// | `RingAdd` | `ring_add_256(a, b)` | MOD_96[256] + RING_ADD[9216] |
/// | `RingMul` | `ring_mul_256(a, b)` | MOD_96[256] + RING_MUL[9216] |
/// | `Lift` | `torus_page_q0(x)` | TORUS_PAGE[256] |
/// | `OrbitClassify` | `orbit_class_q0(x)` | ORBIT_CLASS[256] |
///
/// # Performance Characteristics
///
/// - **Constant time**: All operations are O(1) regardless of input value
/// - **Cache-friendly**: Small tables fit in L1 cache (< 20 KB total)
/// - **Branch-free**: Pure table lookups with no conditionals
/// - **SIMD-compatible**: GPU kernels bind LUTs to constant memory
///
/// # GPU Kernel Templates
///
/// Use `CategoricalTemplate` from `kernels.rs` to generate WGSL/CUDA/Metal
/// kernels that bind LUT data to constant memory for O(1) GPU execution.
pub trait CategoricalKernels {
    /// Lift operation: maps bytes to torus coordinates (`PackedCell` format).
    ///
    /// Uses `torus_page_q0(x)` LUT for O(1) page lookup.
    fn kernel_lift(&self, params: &CategoricalParams) -> Result<()>;

    /// Orbit classification: assigns orbit class (0-31).
    ///
    /// Uses `orbit_class_q0(x)` LUT for O(1) classification.
    fn kernel_orbit_classify(&self, params: &CategoricalParams) -> Result<()>;

    /// Ring addition on Z/96Z resonance ring.
    ///
    /// Uses `ring_add_256(a, b)` LUT for O(1) modular addition.
    /// Handles full 0-255 range by combining MOD_96 and RING_ADD tables.
    fn kernel_ring_add(&self, params: &CategoricalParams) -> Result<()>;

    /// Ring multiplication on Z/96Z resonance ring.
    ///
    /// Uses `ring_mul_256(a, b)` LUT for O(1) modular multiplication.
    /// Handles full 0-255 range by combining MOD_96 and RING_MUL tables.
    fn kernel_ring_mul(&self, params: &CategoricalParams) -> Result<()>;
}

/// Memory kernel trait for GPU backends.
pub trait MemoryKernels {
    /// Copy data between GPU buffers
    fn kernel_copy(&self, params: &MemoryParams) -> Result<()>;
}

/// Combined GPU kernel trait.
///
/// GPU backends that implement all kernel categories can implement this trait
/// to provide a unified interface. The base `GpuBackend` trait handles device
/// management and memory; this trait handles compute operations.
pub trait GpuKernels:
    ElementWiseKernels + ReductionKernels + MatrixKernels + CategoricalKernels + MemoryKernels
{
}

// Blanket implementation for types implementing all kernel traits
impl<T> GpuKernels for T where
    T: ElementWiseKernels + ReductionKernels + MatrixKernels + CategoricalKernels + MemoryKernels
{
}

// ============================================================================
// Kernel Override System
// ============================================================================

/// Trait for external kernel providers to override default implementations.
///
/// # Overview
///
/// The `KernelOverride` trait enables external crates to inject optimized kernel
/// implementations (cuBLAS, oneDNN, etc.) without modifying hologram itself. This
/// uses **inversion of control**: hologram defines the trait but has zero knowledge
/// of any consumers that implement it.
///
/// # When to Use
///
/// Use kernel overrides when you have access to optimized libraries that can outperform
/// hologram's default implementations:
///
/// | Operation | Override Rationale |
/// |-----------|-------------------|
/// | `matmul` | cuBLAS/oneDNN can be 5-10x faster than hologram's tiled implementation |
/// | `batch_matmul` | Transformer attention patterns benefit from batch optimization |
/// | `layer_norm` | Fused CUDA kernels avoid multiple memory passes |
/// | `softmax` | Numerically stable implementations with hardware-specific tuning |
/// | `conv2d` | cuDNN provides highly optimized convolution implementations |
///
/// # Design Principles
///
/// - **Inversion of control**: hologram has zero knowledge of consumers
/// - **Opt-in per operation**: return `None` to use hologram's default
/// - **Zero overhead when unused**: single atomic load when no override is registered
/// - **One registration per process**: call [`register_kernel_override`] once at startup
///
/// # Thread Safety
///
/// Implementations must be `Send + Sync` since the override may be called from
/// multiple threads concurrently. Internal state (GPU handles, etc.) must use
/// appropriate synchronization.
///
/// # Performance
///
/// - Registration: O(1), happens once at startup
/// - Override lookup: single atomic load per kernel call
/// - When no override: negligible overhead (one branch)
///
/// # Example
///
/// ```ignore
/// use hologram_backend::{register_kernel_override, KernelOverride, Result};
///
/// struct MyOptimizedKernels {
///     cublas: Option<cublas::Handle>,
/// }
///
/// impl KernelOverride for MyOptimizedKernels {
///     fn matmul(&self, a: &[f32], b: &[f32], c: &mut [f32],
///               m: usize, k: usize, n: usize) -> Option<Result<()>> {
///         // Use cuBLAS if available
///         if let Some(ref handle) = self.cublas {
///             return Some(handle.sgemm(a, b, c, m, k, n));
///         }
///         None // Fall back to hologram's default
///     }
///     // Other methods return None to use hologram's defaults
/// }
///
/// // At application startup (before spawning worker threads)
/// fn init() {
///     let kernels = Box::new(MyOptimizedKernels::new());
///     register_kernel_override(kernels).expect("failed to register");
/// }
/// ```
///
/// [`register_kernel_override`]: crate::register_kernel_override
pub trait KernelOverride: Send + Sync {
    /// Override matrix multiplication kernel.
    ///
    /// Computes `C = A @ B` (matrix multiplication).
    ///
    /// # Arguments
    ///
    /// * `a` - Left matrix A, shape (m, k), row-major layout, length `m * k`
    /// * `b` - Right matrix B, shape (k, n), row-major layout, length `k * n`
    /// * `c` - Output matrix C, shape (m, n), row-major layout, length `m * n`
    /// * `m` - Number of rows in A and C
    /// * `k` - Shared dimension (columns of A, rows of B)
    /// * `n` - Number of columns in B and C
    ///
    /// # Buffer Layout
    ///
    /// All matrices use **row-major** (C-style) layout:
    /// - Element at row `i`, column `j` is at index `i * cols + j`
    /// - A[i,j] = a[i * k + j]
    /// - B[i,j] = b[i * n + j]
    /// - C[i,j] = c[i * n + j]
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default implementation
    #[allow(unused_variables)]
    fn matmul(
        &self,
        a: &[f32],
        b: &[f32],
        c: &mut [f32],
        m: usize,
        k: usize,
        n: usize,
    ) -> Option<Result<()>> {
        None
    }

    /// Override batched matrix multiplication kernel.
    ///
    /// Computes `C[b] = A[b] @ B[b]` for each batch index `b` in `0..batch`.
    ///
    /// # Arguments
    ///
    /// * `a` - Batched left matrices, shape (batch, m, k), length `batch * m * k`
    /// * `b` - Batched right matrices, shape (batch, k, n), length `batch * k * n`
    /// * `c` - Output matrices, shape (batch, m, n), length `batch * m * n`
    /// * `batch` - Number of independent matrix multiplications
    /// * `m` - Number of rows in each A and C matrix
    /// * `k` - Shared dimension
    /// * `n` - Number of columns in each B and C matrix
    ///
    /// # Buffer Layout
    ///
    /// Batch dimension is **outermost** (batch-major):
    /// - A[b,i,j] = a[b * m * k + i * k + j]
    /// - B[b,i,j] = b[b * k * n + i * n + j]
    /// - C[b,i,j] = c[b * m * n + i * n + j]
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default implementation
    #[allow(unused_variables)]
    fn batch_matmul(
        &self,
        a: &[f32],
        b: &[f32],
        c: &mut [f32],
        batch: usize,
        m: usize,
        k: usize,
        n: usize,
    ) -> Option<Result<()>> {
        None
    }

    /// Override layer normalization kernel.
    ///
    /// Computes layer normalization over the last dimension:
    ///
    /// ```text
    /// mean = sum(input) / normalized_size
    /// var  = sum((input - mean)²) / normalized_size
    /// output = (input - mean) / sqrt(var + epsilon) * scale + bias
    /// ```
    ///
    /// # Arguments
    ///
    /// * `input` - Input tensor, shape (num_instances, normalized_size)
    /// * `scale` - Scale (gamma) parameters, shape (normalized_size,)
    /// * `bias` - Bias (beta) parameters, shape (normalized_size,)
    /// * `output` - Output tensor, same shape as input
    /// * `num_instances` - Number of independent normalizations (batch * seq_len for transformers)
    /// * `normalized_size` - Size of the normalized dimension (hidden_dim for transformers)
    /// * `epsilon` - Small constant for numerical stability (typically 1e-5)
    ///
    /// # Buffer Layout
    ///
    /// - Input/output are contiguous with normalized dimension innermost
    /// - `input[i,j] = input[i * normalized_size + j]`
    /// - Scale and bias are 1D, broadcast across instances
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default implementation
    #[allow(unused_variables)]
    fn layer_norm(
        &self,
        input: &[f32],
        scale: &[f32],
        bias: &[f32],
        output: &mut [f32],
        num_instances: usize,
        normalized_size: usize,
        epsilon: f32,
    ) -> Option<Result<()>> {
        None
    }

    /// Override softmax kernel.
    ///
    /// Computes softmax along an axis using the numerically stable formulation:
    ///
    /// ```text
    /// max_val = max(input[axis])
    /// exp_val = exp(input - max_val)
    /// output = exp_val / sum(exp_val)
    /// ```
    ///
    /// The `x - max` trick prevents overflow when input values are large.
    ///
    /// # Arguments
    ///
    /// * `input` - Input tensor, total length `outer_size * axis_size * inner_size`
    /// * `output` - Output tensor, same shape as input
    /// * `outer_size` - Product of dimensions before the softmax axis
    /// * `axis_size` - Size of the softmax axis (values normalized along this dimension)
    /// * `inner_size` - Product of dimensions after the softmax axis
    ///
    /// # Buffer Layout
    ///
    /// The tensor is conceptually reshaped to `(outer_size, axis_size, inner_size)`:
    /// - `input[o,a,i] = input[(o * axis_size + a) * inner_size + i]`
    /// - Softmax is computed independently for each `(o, i)` pair
    ///
    /// # Example: 3D tensor with softmax on axis 1
    ///
    /// For shape `(2, 4, 3)` with softmax on axis 1:
    /// - `outer_size = 2`
    /// - `axis_size = 4`
    /// - `inner_size = 3`
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default implementation
    #[allow(unused_variables)]
    fn softmax(
        &self,
        input: &[f32],
        output: &mut [f32],
        outer_size: usize,
        axis_size: usize,
        inner_size: usize,
    ) -> Option<Result<()>> {
        None
    }

    /// Override 2D convolution kernel.
    ///
    /// Computes 2D convolution with optional bias:
    ///
    /// ```text
    /// output[n,oc,oh,ow] = bias[oc] + sum over (ic,kh,kw) of:
    ///     input[n, ic, oh*stride_h + kh - pad_h, ow*stride_w + kw - pad_w]
    ///     * weight[oc, ic, kh, kw]
    /// ```
    ///
    /// # Arguments
    ///
    /// * `input` - Input tensor, shape (batch, in_channels, in_height, in_width)
    /// * `weight` - Convolution filters, shape (out_channels, in_channels, kernel_h, kernel_w)
    /// * `bias` - Optional bias, shape (out_channels,)
    /// * `output` - Output tensor, shape (batch, out_channels, out_height, out_width)
    /// * `batch` - Batch size
    /// * `in_channels` - Number of input channels
    /// * `out_channels` - Number of output channels (number of filters)
    /// * `in_height` - Input spatial height
    /// * `in_width` - Input spatial width
    /// * `kernel_h` - Filter height
    /// * `kernel_w` - Filter width
    /// * `stride_h` - Vertical stride
    /// * `stride_w` - Horizontal stride
    /// * `pad_h` - Vertical padding (applied to both top and bottom)
    /// * `pad_w` - Horizontal padding (applied to both left and right)
    ///
    /// # Buffer Layout
    ///
    /// All tensors use **NCHW** (batch, channels, height, width) layout:
    /// - `input[n,c,h,w] = input[((n * in_channels + c) * in_height + h) * in_width + w]`
    /// - `weight[oc,ic,kh,kw] = weight[((oc * in_channels + ic) * kernel_h + kh) * kernel_w + kw]`
    ///
    /// # Output Dimensions
    ///
    /// ```text
    /// out_height = (in_height + 2*pad_h - kernel_h) / stride_h + 1
    /// out_width  = (in_width  + 2*pad_w - kernel_w) / stride_w + 1
    /// ```
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default implementation
    #[allow(unused_variables)]
    fn conv2d(
        &self,
        input: &[f32],
        weight: &[f32],
        bias: Option<&[f32]>,
        output: &mut [f32],
        batch: usize,
        in_channels: usize,
        out_channels: usize,
        in_height: usize,
        in_width: usize,
        kernel_h: usize,
        kernel_w: usize,
        stride_h: usize,
        stride_w: usize,
        pad_h: usize,
        pad_w: usize,
    ) -> Option<Result<()>> {
        None
    }

    // ========================================================================
    // SHA-256 Cryptographic Operations
    // ========================================================================

    /// Override SHA-256 hash computation.
    ///
    /// Computes the SHA-256 hash of input data.
    ///
    /// # Arguments
    ///
    /// * `data` - Input data to hash (arbitrary length)
    /// * `hash` - Output buffer for 32-byte hash digest
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default implementation
    #[allow(unused_variables)]
    fn sha256(&self, data: &[u8], hash: &mut [u8; 32]) -> Option<Result<()>> {
        None
    }

    /// Override double SHA-256 hash computation (used in Bitcoin).
    ///
    /// Computes SHA256(SHA256(data)), which is the hash function used for
    /// Bitcoin block headers and transactions.
    ///
    /// # Arguments
    ///
    /// * `data` - Input data to hash (arbitrary length)
    /// * `hash` - Output buffer for 32-byte hash digest
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default implementation
    #[allow(unused_variables)]
    fn double_sha256(&self, data: &[u8], hash: &mut [u8; 32]) -> Option<Result<()>> {
        None
    }

    /// Override SHA-256 compression function.
    ///
    /// Processes a single 512-bit (64-byte) block, updating the hash state.
    /// This is the core operation that can be accelerated with SHA-NI instructions.
    ///
    /// # Arguments
    ///
    /// * `state` - 8 x 32-bit hash state words (modified in place)
    /// * `block` - 64-byte message block to process
    ///
    /// # State Layout
    ///
    /// The state array contains the 8 SHA-256 working variables:
    /// - `state[0]` = a
    /// - `state[1]` = b
    /// - `state[2]` = c
    /// - `state[3]` = d
    /// - `state[4]` = e
    /// - `state[5]` = f
    /// - `state[6]` = g
    /// - `state[7]` = h
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default implementation
    #[allow(unused_variables)]
    fn sha256_compress(&self, state: &mut [u32; 8], block: &[u8; 64]) -> Option<Result<()>> {
        None
    }

    // ========================================================================
    // Categorical Operations (UOR-specific, O(1) LUT-based)
    // ========================================================================

    /// Override ring addition on Z/96Z resonance ring.
    ///
    /// Computes `(a + b) mod 96` for each element pair using O(1) LUT lookup.
    ///
    /// # Arguments
    ///
    /// * `a` - First input buffer (0-255 range, reduced mod 96 internally)
    /// * `b` - Second input buffer (0-255 range, reduced mod 96 internally)
    /// * `output` - Output buffer (0-95 range)
    ///
    /// # Default Implementation
    ///
    /// Uses `uor::lut::ring_add_256(a, b)` which combines:
    /// - `MOD_96[256]` table for input reduction
    /// - `RING_ADD[96*96]` table for modular addition
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default LUT implementation
    #[allow(unused_variables)]
    fn ring_add(&self, a: &[u8], b: &[u8], output: &mut [u8]) -> Option<Result<()>> {
        None
    }

    /// Override ring multiplication on Z/96Z resonance ring.
    ///
    /// Computes `(a * b) mod 96` for each element pair using O(1) LUT lookup.
    ///
    /// # Arguments
    ///
    /// * `a` - First input buffer (0-255 range, reduced mod 96 internally)
    /// * `b` - Second input buffer (0-255 range, reduced mod 96 internally)
    /// * `output` - Output buffer (0-95 range)
    ///
    /// # Default Implementation
    ///
    /// Uses `uor::lut::ring_mul_256(a, b)` which combines:
    /// - `MOD_96[256]` table for input reduction
    /// - `RING_MUL[96*96]` table for modular multiplication
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default LUT implementation
    #[allow(unused_variables)]
    fn ring_mul(&self, a: &[u8], b: &[u8], output: &mut [u8]) -> Option<Result<()>> {
        None
    }

    /// Override lift operation (torus coordinate mapping).
    ///
    /// Maps each byte to its torus page coordinate using O(1) LUT lookup.
    ///
    /// # Arguments
    ///
    /// * `input` - Input bytes (0-255 range)
    /// * `output` - Output `PackedCell` values (page, offset pairs)
    ///
    /// # Default Implementation
    ///
    /// Uses `uor::lut::torus_page_q0(x)` for O(1) page lookup.
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default LUT implementation
    #[allow(unused_variables)]
    fn lift(&self, input: &[u8], output: &mut [u8]) -> Option<Result<()>> {
        None
    }

    /// Override orbit classification.
    ///
    /// Assigns each byte to its orbit class (0-31) using O(1) LUT lookup.
    ///
    /// # Arguments
    ///
    /// * `input` - Input bytes (0-255 range)
    /// * `output` - Orbit class assignments (0-31 range)
    ///
    /// # Default Implementation
    ///
    /// Uses `uor::lut::orbit_class_q0(x)` for O(1) classification.
    ///
    /// # Returns
    ///
    /// - `Some(Ok(()))` - Override handled the operation successfully
    /// - `Some(Err(_))` - Override attempted but failed
    /// - `None` - Use hologram's default LUT implementation
    #[allow(unused_variables)]
    fn orbit_classify(&self, input: &[u8], output: &mut [u8]) -> Option<Result<()>> {
        None
    }
}

/// Recommended thread block configuration for different kernel categories.
///
/// These are starting points; actual backends may tune based on specific GPU architecture.
#[must_use]
pub const fn recommended_block_size(category: KernelCategory) -> u32 {
    match category {
        // 256 threads is good for memory-bound operations
        KernelCategory::ElementWise
        | KernelCategory::Reduction
        | KernelCategory::Categorical
        | KernelCategory::Memory => 256,
        // 16x16 tiles are common for matrix operations
        KernelCategory::Matrix => 16,
        // Control flow is not a GPU kernel
        KernelCategory::Control => 1,
    }
}

/// Estimate grid size for given element count and block size.
///
/// Returns the number of thread blocks needed to cover all elements.
/// The result is truncated to u32 which is sufficient for all practical GPU grids.
#[must_use]
#[allow(clippy::cast_possible_truncation)]
pub fn grid_size(element_count: usize, block_size: u32) -> u32 {
    element_count.div_ceil(block_size as usize) as u32
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_holo::IsaInstruction;

    #[test]
    fn test_classify_element_wise() {
        let add = IsaInstruction::Add {
            dst: 0,
            a: 1,
            b: 2,
            count: 100,
        };
        assert_eq!(classify_instruction(&add), KernelCategory::ElementWise);

        let sigmoid = IsaInstruction::Sigmoid {
            dst: 0,
            src: 1,
            count: 100,
        };
        assert_eq!(classify_instruction(&sigmoid), KernelCategory::ElementWise);
    }

    #[test]
    fn test_classify_reduction() {
        let sum = IsaInstruction::Sum {
            dst: 0,
            src: 1,
            count: 100,
        };
        assert_eq!(classify_instruction(&sum), KernelCategory::Reduction);
    }

    #[test]
    fn test_classify_matrix() {
        let matmul = IsaInstruction::MatMul {
            c: 0,
            a: 1,
            b: 2,
            m: 64,
            k: 64,
            n: 64,
        };
        assert_eq!(classify_instruction(&matmul), KernelCategory::Matrix);
    }

    #[test]
    fn test_classify_categorical() {
        let lift = IsaInstruction::Lift {
            dst: 0,
            src: 1,
            count: 256,
        };
        assert_eq!(classify_instruction(&lift), KernelCategory::Categorical);

        let ring_add = IsaInstruction::RingAdd {
            dst: 0,
            a: 1,
            b: 2,
            count: 100,
        };
        assert_eq!(classify_instruction(&ring_add), KernelCategory::Categorical);
    }

    #[test]
    fn test_classify_memory() {
        let copy = IsaInstruction::Copy {
            dst: 0,
            src: 1,
            size: 1024,
        };
        assert_eq!(classify_instruction(&copy), KernelCategory::Memory);
    }

    #[test]
    fn test_classify_control() {
        let call = IsaInstruction::CallLayer {
            layer_id: 123,
            inputs: vec![0, 1],
            outputs: vec![2],
        };
        assert_eq!(classify_instruction(&call), KernelCategory::Control);
    }

    #[test]
    fn test_recommended_block_size() {
        assert_eq!(recommended_block_size(KernelCategory::ElementWise), 256);
        assert_eq!(recommended_block_size(KernelCategory::Reduction), 256);
        assert_eq!(recommended_block_size(KernelCategory::Matrix), 16);
    }

    #[test]
    fn test_grid_size_exact() {
        // Exact division
        assert_eq!(grid_size(256, 256), 1);
        assert_eq!(grid_size(512, 256), 2);
        assert_eq!(grid_size(1024, 256), 4);
    }

    #[test]
    fn test_grid_size_rounded() {
        // Needs rounding up
        assert_eq!(grid_size(257, 256), 2);
        assert_eq!(grid_size(1, 256), 1);
        assert_eq!(grid_size(255, 256), 1);
    }

    #[test]
    fn test_element_wise_params_construction() {
        let params = ElementWiseParams {
            dst: GpuBuffer {
                handle: 0x1000,
                size: 1024,
            },
            src_a: GpuBuffer {
                handle: 0x2000,
                size: 1024,
            },
            src_b: Some(GpuBuffer {
                handle: 0x3000,
                size: 1024,
            }),
            count: 256,
        };
        assert_eq!(params.count, 256);
        assert!(params.src_b.is_some());
    }

    #[test]
    fn test_element_wise_params_unary() {
        let params = ElementWiseParams {
            dst: GpuBuffer {
                handle: 0x1000,
                size: 1024,
            },
            src_a: GpuBuffer {
                handle: 0x2000,
                size: 1024,
            },
            src_b: None,
            count: 256,
        };
        assert!(params.src_b.is_none());
    }

    #[test]
    fn test_matmul_params() {
        let params = MatMulParams {
            c: GpuBuffer {
                handle: 0x1000,
                size: 64 * 64 * 4,
            },
            a: GpuBuffer {
                handle: 0x2000,
                size: 64 * 64 * 4,
            },
            b: GpuBuffer {
                handle: 0x3000,
                size: 64 * 64 * 4,
            },
            m: 64,
            k: 64,
            n: 64,
        };
        assert_eq!(params.m, 64);
        assert_eq!(params.k, 64);
        assert_eq!(params.n, 64);
    }

    #[test]
    fn test_reduction_params() {
        let params = ReductionParams {
            dst: GpuBuffer {
                handle: 0x1000,
                size: 4,
            },
            src: GpuBuffer {
                handle: 0x2000,
                size: 1024,
            },
            count: 256,
        };
        assert_eq!(params.count, 256);
        assert_eq!(params.dst.size, 4); // Single f32
    }

    #[test]
    fn test_categorical_params() {
        let params = CategoricalParams {
            dst: GpuBuffer {
                handle: 0x1000,
                size: 512,
            },
            src_a: GpuBuffer {
                handle: 0x2000,
                size: 256,
            },
            src_b: None,
            count: 256,
        };
        // Lift doubles output size (PackedCell = 2 bytes per input byte)
        assert_eq!(params.dst.size, 512);
        assert_eq!(params.src_a.size, 256);
    }

    #[test]
    fn test_memory_params() {
        let params = MemoryParams {
            dst: GpuBuffer {
                handle: 0x1000,
                size: 1024,
            },
            src: GpuBuffer {
                handle: 0x2000,
                size: 1024,
            },
            size: 1024,
        };
        assert_eq!(params.size, 1024);
    }

    // ========================================================================
    // KernelOverride Tests
    // ========================================================================

    /// Empty override that uses defaults for everything
    struct NoOverrides;
    impl KernelOverride for NoOverrides {}

    #[test]
    fn test_kernel_override_defaults_return_none() {
        let provider = NoOverrides;

        // All methods should return None by default
        let mut c = vec![0.0f32; 4];
        assert!(provider
            .matmul(&[1.0, 2.0], &[3.0, 4.0], &mut c, 2, 1, 2)
            .is_none());
        assert!(provider
            .batch_matmul(&[1.0], &[2.0], &mut c, 1, 1, 1, 1)
            .is_none());
        assert!(provider
            .layer_norm(&[1.0], &[1.0], &[0.0], &mut c, 1, 1, 1e-5)
            .is_none());
        assert!(provider.softmax(&[1.0, 2.0], &mut c, 1, 2, 1).is_none());
        assert!(provider
            .conv2d(
                &[1.0],
                &[1.0],
                None,
                &mut c,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                0,
                0
            )
            .is_none());

        // Categorical operations should also return None by default
        let mut out = vec![0u8; 4];
        assert!(provider.ring_add(&[1, 2], &[3, 4], &mut out).is_none());
        assert!(provider.ring_mul(&[1, 2], &[3, 4], &mut out).is_none());
        assert!(provider.lift(&[1, 2, 3, 4], &mut out).is_none());
        assert!(provider.orbit_classify(&[1, 2, 3, 4], &mut out).is_none());
    }

    /// Override that implements a custom matmul
    struct MatMulOverride;
    impl KernelOverride for MatMulOverride {
        fn matmul(
            &self,
            _a: &[f32],
            _b: &[f32],
            c: &mut [f32],
            _m: usize,
            _k: usize,
            _n: usize,
        ) -> Option<Result<()>> {
            // Custom implementation: fill with 42.0
            for x in c {
                *x = 42.0;
            }
            Some(Ok(()))
        }
    }

    #[test]
    fn test_kernel_override_selective() {
        let provider = MatMulOverride;

        // matmul is overridden
        let mut c = vec![0.0f32; 4];
        let result = provider.matmul(&[1.0, 2.0], &[3.0, 4.0], &mut c, 2, 1, 2);
        assert!(result.is_some());
        assert!(result.unwrap().is_ok());
        assert!(c.iter().all(|&x| (x - 42.0).abs() < f32::EPSILON));

        // Other methods still return None
        let mut d = vec![0.0f32; 4];
        assert!(provider.softmax(&[1.0, 2.0], &mut d, 1, 2, 1).is_none());
        assert!(provider
            .layer_norm(&[1.0], &[1.0], &[0.0], &mut d, 1, 1, 1e-5)
            .is_none());
    }

    #[test]
    fn test_kernel_override_is_send_sync() {
        // Verify KernelOverride is Send + Sync (required for global registration)
        fn assert_send_sync<T: Send + Sync>() {}
        assert_send_sync::<NoOverrides>();
        assert_send_sync::<MatMulOverride>();
    }

    /// Override that implements custom categorical operations
    struct CategoricalOverride;
    impl KernelOverride for CategoricalOverride {
        fn ring_add(&self, _a: &[u8], _b: &[u8], output: &mut [u8]) -> Option<Result<()>> {
            // Custom implementation: always output 42
            for x in output.iter_mut() {
                *x = 42;
            }
            Some(Ok(()))
        }

        fn orbit_classify(&self, input: &[u8], output: &mut [u8]) -> Option<Result<()>> {
            // Custom implementation: identity
            for (out, &inp) in output.iter_mut().zip(input.iter()) {
                *out = inp;
            }
            Some(Ok(()))
        }
    }

    #[test]
    fn test_kernel_override_categorical_selective() {
        let provider = CategoricalOverride;

        // ring_add is overridden
        let mut out = vec![0u8; 4];
        let result = provider.ring_add(&[1, 2, 3, 4], &[5, 6, 7, 8], &mut out);
        assert!(result.is_some());
        assert!(result.unwrap().is_ok());
        assert!(out.iter().all(|&x| x == 42));

        // orbit_classify is overridden
        let mut out2 = vec![0u8; 4];
        let result = provider.orbit_classify(&[10, 20, 30, 40], &mut out2);
        assert!(result.is_some());
        assert!(result.unwrap().is_ok());
        assert_eq!(out2, vec![10, 20, 30, 40]);

        // Other categorical ops still return None
        let mut out3 = vec![0u8; 4];
        assert!(provider.ring_mul(&[1, 2], &[3, 4], &mut out3).is_none());
        assert!(provider.lift(&[1, 2, 3, 4], &mut out3).is_none());

        // Non-categorical ops also return None
        let mut f = vec![0.0f32; 4];
        assert!(provider
            .matmul(&[1.0, 2.0], &[3.0, 4.0], &mut f, 2, 1, 2)
            .is_none());
    }

    #[test]
    fn test_categorical_override_is_send_sync() {
        fn assert_send_sync<T: Send + Sync>() {}
        assert_send_sync::<CategoricalOverride>();
    }
}
