//! Graph node representation.
//!
//! Nodes are generic over their operation type, allowing the same graph
//! structure to be used with different operation sets.

use crate::ids::{GroupId, NodeId, SubgraphId};

/// Source of input data for a node.
#[derive(Debug, Clone, Copy, Eq, PartialEq, Hash, Default)]
pub enum InputSource {
    /// Input comes from another node's output.
    Node(NodeId),
    /// Input comes from a subgraph's output port.
    Subgraph {
        /// The subgraph providing the input.
        subgraph: SubgraphId,
        /// Which output port of the subgraph.
        output_port: u32,
    },
    /// Input comes from a graph-level input.
    GraphInput {
        /// Index of the graph input.
        index: u32,
    },
    /// No input (for sources/constants).
    #[default]
    None,
}

/// An input slot on a node.
#[derive(Debug, Clone, Default)]
pub struct InputSlot {
    /// Where this input comes from.
    pub source: InputSource,
    /// Which output port of the source (for multi-output nodes).
    pub output_port: u32,
}

impl InputSlot {
    /// Create an input slot from a node.
    #[must_use]
    pub fn from_node(id: NodeId) -> Self {
        Self {
            source: InputSource::Node(id),
            output_port: 0,
        }
    }

    /// Create an input slot from a node with a specific output port.
    #[must_use]
    pub fn from_node_port(id: NodeId, port: u32) -> Self {
        Self {
            source: InputSource::Node(id),
            output_port: port,
        }
    }

    /// Create an input slot from a graph input.
    #[must_use]
    pub fn from_graph_input(index: u32) -> Self {
        Self {
            source: InputSource::GraphInput { index },
            output_port: 0,
        }
    }

    /// Create an input slot from a subgraph output.
    #[must_use]
    pub fn from_subgraph(subgraph: SubgraphId, output_port: u32) -> Self {
        Self {
            source: InputSource::Subgraph {
                subgraph,
                output_port,
            },
            output_port: 0,
        }
    }

    /// Check if this slot has no source.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        matches!(self.source, InputSource::None)
    }
}

/// A node in the compute graph.
///
/// Generic over the operation type `Op`, allowing different operation sets
/// to use the same graph structure.
#[derive(Debug, Clone)]
pub struct Node<Op> {
    /// Unique identifier for this node.
    pub id: NodeId,
    /// The operation this node performs.
    pub op: Op,
    /// Parallel execution group.
    pub group: GroupId,
    /// Input connections.
    pub inputs: Vec<InputSlot>,
    /// Number of output ports.
    pub num_outputs: u32,
}

impl<Op> Node<Op> {
    /// Create a new node with the given ID and operation.
    #[must_use]
    pub fn new(id: NodeId, op: Op) -> Self {
        Self {
            id,
            op,
            group: GroupId::default(),
            inputs: Vec::new(),
            num_outputs: 1,
        }
    }

    /// Set the execution group.
    #[must_use]
    pub fn with_group(mut self, group: GroupId) -> Self {
        self.group = group;
        self
    }

    /// Set the input slots.
    #[must_use]
    pub fn with_inputs(mut self, inputs: Vec<InputSlot>) -> Self {
        self.inputs = inputs;
        self
    }

    /// Set the number of outputs.
    #[must_use]
    pub fn with_outputs(mut self, num_outputs: u32) -> Self {
        self.num_outputs = num_outputs;
        self
    }

    /// Add an input from another node.
    pub fn add_input(&mut self, id: NodeId) {
        self.inputs.push(InputSlot::from_node(id));
    }

    /// Add an input from a graph input.
    pub fn add_graph_input(&mut self, index: u32) {
        self.inputs.push(InputSlot::from_graph_input(index));
    }

    /// Get all node IDs that this node depends on.
    pub fn dependencies(&self) -> impl Iterator<Item = NodeId> + '_ {
        self.inputs.iter().filter_map(|slot| {
            if let InputSource::Node(id) = slot.source {
                Some(id)
            } else {
                None
            }
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Debug, Clone, PartialEq)]
    enum TestOp {
        Add,
        Mul,
    }

    #[test]
    fn test_node_creation() {
        let node = Node::new(NodeId::new(0, 0), TestOp::Add);
        assert_eq!(node.id, NodeId::new(0, 0));
        assert_eq!(node.op, TestOp::Add);
        assert_eq!(node.num_outputs, 1);
        assert!(node.inputs.is_empty());
    }

    #[test]
    fn test_node_builder_pattern() {
        let node = Node::new(NodeId::new(1, 0), TestOp::Mul)
            .with_group(GroupId::new(5))
            .with_outputs(2)
            .with_inputs(vec![
                InputSlot::from_node(NodeId::new(0, 0)),
                InputSlot::from_graph_input(0),
            ]);

        assert_eq!(node.group, GroupId::new(5));
        assert_eq!(node.num_outputs, 2);
        assert_eq!(node.inputs.len(), 2);
    }

    #[test]
    fn test_node_add_input() {
        let mut node = Node::new(NodeId::new(1, 0), TestOp::Add);
        node.add_input(NodeId::new(0, 0));
        node.add_graph_input(0);

        assert_eq!(node.inputs.len(), 2);
        assert_eq!(node.inputs[0].source, InputSource::Node(NodeId::new(0, 0)));
        assert_eq!(node.inputs[1].source, InputSource::GraphInput { index: 0 });
    }

    #[test]
    fn test_node_dependencies() {
        let node = Node::new(NodeId::new(2, 0), TestOp::Add).with_inputs(vec![
            InputSlot::from_node(NodeId::new(0, 0)),
            InputSlot::from_graph_input(0),
            InputSlot::from_node(NodeId::new(1, 0)),
        ]);

        let deps: Vec<_> = node.dependencies().collect();
        assert_eq!(deps.len(), 2);
        assert!(deps.contains(&NodeId::new(0, 0)));
        assert!(deps.contains(&NodeId::new(1, 0)));
    }

    #[test]
    fn test_input_slot_from_node() {
        let slot = InputSlot::from_node(NodeId::new(5, 2));
        assert_eq!(slot.source, InputSource::Node(NodeId::new(5, 2)));
        assert_eq!(slot.output_port, 0);
        assert!(!slot.is_empty());
    }

    #[test]
    fn test_input_slot_from_node_port() {
        let slot = InputSlot::from_node_port(NodeId::new(3, 1), 2);
        assert_eq!(slot.source, InputSource::Node(NodeId::new(3, 1)));
        assert_eq!(slot.output_port, 2);
    }

    #[test]
    fn test_input_slot_from_subgraph() {
        let slot = InputSlot::from_subgraph(SubgraphId::new(1), 3);
        assert_eq!(
            slot.source,
            InputSource::Subgraph {
                subgraph: SubgraphId::new(1),
                output_port: 3
            }
        );
    }

    #[test]
    fn test_input_slot_empty() {
        let slot = InputSlot::default();
        assert!(slot.is_empty());
        assert_eq!(slot.source, InputSource::None);
    }

    #[test]
    fn test_input_source_default() {
        assert_eq!(InputSource::default(), InputSource::None);
    }
}
