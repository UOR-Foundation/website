/**
 * WASM Boundary Service
 *
 * Provides utilities for working with the hologram ToroidalBoundary
 * using the Rust WASM bindings.
 */

import type { WasmModule, ToroidalBoundary, Cell, Res96 } from '../hooks/useWasm';
import { BOUNDARY_SIZE, R } from '../hooks/useWasm';

// Re-export constants
export { BOUNDARY_SIZE, R, T, O, C, B } from '../hooks/useWasm';

/**
 * Mutation types available for boundary operations
 */
export type MutationType =
  | 'set' | 'add' | 'mirror' | 'swap'
  | 'multiply' | 'mul' | 'mulFrom' | 'fma'
  | 'bitwiseAnd' | 'bitwiseOr' | 'bitwiseXor' | 'bitwiseNot'
  | 'shiftLeft' | 'shiftRight'
  | 'indexedWrite' | 'indexedCopy'
  | 'indirectRead' | 'indirectMulFrom';

/**
 * Create a mutation JSON string using MutationFactory
 */
export function createMutation(
  wasm: WasmModule,
  type: MutationType,
  ...args: number[]
): string {
  const factory = wasm.MutationFactory;

  switch (type) {
    case 'set':
      return factory.set(args[0], args[1]);
    case 'add':
      return factory.add(args[0], args[1]);
    case 'mirror':
      return factory.mirror(args[0]);
    case 'swap':
      return factory.swap(args[0], args[1]);
    case 'multiply':
      return factory.multiply(args[0], args[1]);
    case 'mul':
      return factory.mul(args[0], args[1]);
    case 'mulFrom':
      return factory.mulFrom(args[0], args[1]);
    case 'fma':
      return factory.fma(args[0], args[1], args[2]);
    case 'bitwiseAnd':
      return factory.bitwiseAnd(args[0], args[1]);
    case 'bitwiseOr':
      return factory.bitwiseOr(args[0], args[1]);
    case 'bitwiseXor':
      return factory.bitwiseXor(args[0], args[1]);
    case 'bitwiseNot':
      return factory.bitwiseNot(args[0]);
    case 'shiftLeft':
      return factory.shiftLeft(args[0], args[1]);
    case 'shiftRight':
      return factory.shiftRight(args[0], args[1]);
    case 'indexedWrite':
      return factory.indexedWrite(args[0], args[1]);
    case 'indexedCopy':
      return factory.indexedCopy(args[0], args[1]);
    case 'indirectRead':
      return factory.indirectRead(args[0], args[1], args[2]);
    case 'indirectMulFrom':
      return factory.indirectMulFrom(args[0], args[1], args[2]);
    default:
      throw new Error(`Unknown mutation type: ${type}`);
  }
}

/**
 * Create a batch of mutations
 */
export function createBatch(mutations: string[]): string {
  return JSON.stringify(mutations.map(m => JSON.parse(m)));
}

/**
 * BoundaryWrapper provides a higher-level interface to ToroidalBoundary
 */
export class BoundaryWrapper {
  private wasm: WasmModule;
  private boundary: ToroidalBoundary;

  constructor(wasm: WasmModule, boundary?: ToroidalBoundary) {
    this.wasm = wasm;
    this.boundary = boundary ?? new wasm.ToroidalBoundary();
  }

  static zero(wasm: WasmModule): BoundaryWrapper {
    return new BoundaryWrapper(wasm, wasm.ToroidalBoundary.newZero());
  }

  static one(wasm: WasmModule): BoundaryWrapper {
    return new BoundaryWrapper(wasm, wasm.ToroidalBoundary.newOne());
  }

  static fill(wasm: WasmModule, value: number): BoundaryWrapper {
    const res = new wasm.Res96(value);
    const boundary = wasm.ToroidalBoundary.newFill(res);
    res.free();
    return new BoundaryWrapper(wasm, boundary);
  }

  get(index: number): number {
    const cell = new this.wasm.Cell(index);
    const res = this.boundary.get(cell);
    const value = res.value;
    res.free();
    cell.free();
    return value;
  }

  set(index: number, value: number): void {
    const cell = new this.wasm.Cell(index);
    const res = new this.wasm.Res96(value);
    this.boundary.set(cell, res);
    res.free();
    cell.free();
  }

  apply(type: MutationType, ...args: number[]): void {
    const mutation = createMutation(this.wasm, type, ...args);
    this.boundary.applyMutation(mutation);
  }

  applyBatch(mutations: { type: MutationType; args: number[] }[]): void {
    const batch = mutations.map(m => createMutation(this.wasm, m.type, ...m.args));
    this.boundary.applyBatch(createBatch(batch));
  }

  clear(): void {
    this.boundary.clear();
  }

  totalBudget(): bigint {
    return this.boundary.totalBudget();
  }

  signedBudget(): bigint {
    return this.boundary.signedBudget();
  }

  toArray(): number[] {
    const values: number[] = [];
    for (let i = 0; i < BOUNDARY_SIZE; i++) {
      values.push(this.get(i));
    }
    return values;
  }

  toUint8Array(): Uint8Array {
    return this.boundary.toUint8Array();
  }

  free(): void {
    this.boundary.free();
  }

  getRawBoundary(): ToroidalBoundary {
    return this.boundary;
  }
}

/**
 * Encode a string into the boundary using base-96 encoding
 * Each character is stored as a Res96 value at sequential cells
 */
export function encodeStringToBoundary(
  wasm: WasmModule,
  boundary: BoundaryWrapper,
  input: string,
  startCell: number = 0
): { length: number; endCell: number } {
  const BASE_96_CHARS = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";

  for (let i = 0; i < input.length; i++) {
    const charIndex = BASE_96_CHARS.indexOf(input[i]);
    const value = charIndex >= 0 ? charIndex : BASE_96_CHARS.indexOf('?');
    const cellIndex = (startCell + i) % BOUNDARY_SIZE;
    boundary.set(cellIndex, value);
  }

  return {
    length: input.length,
    endCell: (startCell + input.length) % BOUNDARY_SIZE
  };
}

/**
 * Decode a string from the boundary
 */
export function decodeStringFromBoundary(
  boundary: BoundaryWrapper,
  startCell: number,
  length: number
): string {
  const BASE_96_CHARS = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";

  let result = '';
  for (let i = 0; i < length; i++) {
    const cellIndex = (startCell + i) % BOUNDARY_SIZE;
    const value = boundary.get(cellIndex);
    result += BASE_96_CHARS[value] || '?';
  }
  return result;
}

/**
 * Visualize a portion of the boundary as a 2D grid
 */
export function getBoundaryGrid(
  boundary: BoundaryWrapper,
  startCell: number,
  width: number,
  height: number
): number[][] {
  const grid: number[][] = [];

  for (let y = 0; y < height; y++) {
    const row: number[] = [];
    for (let x = 0; x < width; x++) {
      const cellIndex = (startCell + y * width + x) % BOUNDARY_SIZE;
      row.push(boundary.get(cellIndex));
    }
    grid.push(row);
  }

  return grid;
}

/**
 * Calculate statistics about the boundary state
 */
export function getBoundaryStats(boundary: BoundaryWrapper): {
  totalBudget: bigint;
  signedBudget: bigint;
  nonZeroCount: number;
  histogram: Map<number, number>;
} {
  const histogram = new Map<number, number>();
  let nonZeroCount = 0;

  for (let i = 0; i < BOUNDARY_SIZE; i++) {
    const value = boundary.get(i);
    if (value !== 0) nonZeroCount++;
    histogram.set(value, (histogram.get(value) || 0) + 1);
  }

  return {
    totalBudget: boundary.totalBudget(),
    signedBudget: boundary.signedBudget(),
    nonZeroCount,
    histogram
  };
}
