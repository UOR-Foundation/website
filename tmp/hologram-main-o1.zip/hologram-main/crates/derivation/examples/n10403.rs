//! Generate the N=10403 factorization proof chain.
//!
//! This example generates the complete derivation chain for factoring
//! the semiprime 10403 = 101 * 103.
//!
//! Usage:
//!   cargo run -p hologram-derivation --example n10403

use hologram_derivation::{
    emit_factorization_proof, factorize_semiprime, verify_derivation_chain, verify_factorization,
    FactorizationResult,
};

fn main() {
    println!("Factoring N = 10403...\n");

    // Factorize
    let result: FactorizationResult =
        factorize_semiprime(10403, 32).expect("Factorization should succeed");

    println!("Result:");
    println!("  N = {}", result.n);
    println!("  p = {}", result.p);
    println!("  q = {}", result.q);
    println!("  k = {} (quantum level)", result.k);
    println!("  i = {} (orbit index)", result.i);
    println!("  v = {} (orbit value)", result.v);
    println!();

    // Verify
    let verification = verify_factorization(&result);
    println!(
        "Verification: {}",
        if verification.valid { "PASS" } else { "FAIL" }
    );
    for check in &verification.checks {
        println!(
            "  [{}] {}: {}",
            if check.passed { "OK" } else { "FAIL" },
            check.name,
            check.description
        );
    }
    println!();

    // Generate proof
    let timestamp = "2026-02-05T00:00:00Z";
    let proof = emit_factorization_proof(&result, timestamp);

    // Also verify the derivation chain
    let chain = hologram_derivation::factorization_derivation(&result, timestamp);
    let chain_verification = verify_derivation_chain(&chain);
    println!(
        "Derivation chain verification: {}",
        if chain_verification.valid {
            "PASS"
        } else {
            "FAIL"
        }
    );
    println!();

    // Output JSON-LD
    let json = serde_json::to_string_pretty(&proof).expect("JSON serialization should succeed");
    println!("JSON-LD Proof:\n{}", json);
}
