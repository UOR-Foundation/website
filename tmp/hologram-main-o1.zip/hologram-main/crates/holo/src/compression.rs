//! Compression support for weight tensors.
//!
//! This module provides optional compression and decompression utilities
//! for weight data in `.holb` bundles. Compression is feature-gated and
//! supports zstd and lz4 algorithms.
//!
//! # Feature Flags
//!
//! - `compression` - Enables compression/decompression with zstd and lz4
//!
//! # Example
//!
//! ```rust,ignore
//! use hologram_holo::compression::{CompressionAlgorithm, CompressionMetadata};
//! use hologram_holo::compression::{compress_weights, decompress_weights};
//!
//! let data = vec![0u8; 1024];
//!
//! // Compress with zstd
//! let compressed = compress_weights(&data, CompressionAlgorithm::Zstd, 3)?;
//!
//! // Create metadata
//! let metadata = CompressionMetadata {
//!     algorithm: CompressionAlgorithm::Zstd,
//!     level: 3,
//!     uncompressed_size: data.len() as u64,
//!     compressed_size: compressed.len() as u64,
//!     uncompressed_checksum: hologram_holo::crc32(&data),
//! };
//!
//! // Decompress
//! let restored = decompress_weights(&compressed, &metadata)?;
//! assert_eq!(data, restored);
//! ```

use rkyv::{Archive, Deserialize, Serialize};

use crate::{HoloError, Result};

// ============================================================================
// Compression Types
// ============================================================================

/// Compression algorithm identifier.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
#[repr(u8)]
pub enum CompressionAlgorithm {
    /// No compression (default)
    #[default]
    None = 0,
    /// Zstandard compression (good balance of speed/ratio)
    Zstd = 1,
    /// LZ4 compression (faster, lower ratio)
    Lz4 = 2,
}

impl CompressionAlgorithm {
    /// Check if this represents actual compression.
    #[must_use]
    pub const fn is_compressed(self) -> bool {
        !matches!(self, Self::None)
    }

    /// Get default compression level for this algorithm.
    #[must_use]
    pub const fn default_level(self) -> i32 {
        match self {
            Self::None => 0,
            Self::Zstd => 3, // zstd default
            Self::Lz4 => 1,  // lz4 default
        }
    }
}

/// Compression metadata for the weights blob.
///
/// This metadata is stored alongside compressed weights to enable
/// decompression and verification.
#[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct CompressionMetadata {
    /// Algorithm used for compression
    pub algorithm: CompressionAlgorithm,
    /// Compression level (algorithm-specific)
    pub level: i32,
    /// Original uncompressed size in bytes
    pub uncompressed_size: u64,
    /// Compressed size in bytes
    pub compressed_size: u64,
    /// CRC32 of uncompressed data (for verification after decompress)
    pub uncompressed_checksum: u32,
}

impl CompressionMetadata {
    /// Create metadata for uncompressed data.
    #[must_use]
    pub fn uncompressed(size: u64, checksum: u32) -> Self {
        Self {
            algorithm: CompressionAlgorithm::None,
            level: 0,
            uncompressed_size: size,
            compressed_size: size,
            uncompressed_checksum: checksum,
        }
    }

    /// Calculate compression ratio (compressed / uncompressed).
    ///
    /// Returns 1.0 for uncompressed or empty data.
    #[must_use]
    #[allow(clippy::cast_precision_loss)]
    pub fn compression_ratio(&self) -> f64 {
        if self.uncompressed_size == 0 {
            return 1.0;
        }
        // Precision loss is acceptable for a compression ratio calculation
        self.compressed_size as f64 / self.uncompressed_size as f64
    }

    /// Calculate space savings as a percentage.
    ///
    /// Returns 0.0 for uncompressed or empty data.
    #[must_use]
    pub fn space_savings_percent(&self) -> f64 {
        (1.0 - self.compression_ratio()) * 100.0
    }
}

impl Default for CompressionMetadata {
    fn default() -> Self {
        Self {
            algorithm: CompressionAlgorithm::None,
            level: 0,
            uncompressed_size: 0,
            compressed_size: 0,
            uncompressed_checksum: 0,
        }
    }
}

// ============================================================================
// Compression Functions (feature-gated)
// ============================================================================

/// Compress weights using the specified algorithm.
///
/// # Errors
///
/// Returns error if compression fails or the algorithm is not supported.
#[cfg(feature = "compression")]
pub fn compress_weights(
    data: &[u8],
    algorithm: CompressionAlgorithm,
    level: i32,
) -> Result<Vec<u8>> {
    match algorithm {
        CompressionAlgorithm::None => Ok(data.to_vec()),
        CompressionAlgorithm::Zstd => compress_zstd(data, level),
        CompressionAlgorithm::Lz4 => Ok(compress_lz4(data, level)),
    }
}

/// Decompress weights using metadata.
///
/// Verifies the checksum after decompression.
///
/// # Errors
///
/// Returns error if:
/// - Decompression fails
/// - Checksum mismatch after decompression
/// - Algorithm is not supported
#[cfg(feature = "compression")]
pub fn decompress_weights(compressed: &[u8], metadata: &CompressionMetadata) -> Result<Vec<u8>> {
    let decompressed = match metadata.algorithm {
        CompressionAlgorithm::None => return Ok(compressed.to_vec()),
        CompressionAlgorithm::Zstd => decompress_zstd(compressed, metadata.uncompressed_size)?,
        CompressionAlgorithm::Lz4 => decompress_lz4(compressed, metadata.uncompressed_size)?,
    };

    // Verify checksum
    let checksum = crate::format::crc32(&decompressed);
    if checksum != metadata.uncompressed_checksum {
        return Err(HoloError::checksum_mismatch(
            metadata.uncompressed_checksum,
            checksum,
        ));
    }

    Ok(decompressed)
}

/// Compress and create metadata for weights.
///
/// Convenience function that compresses data and creates the corresponding
/// metadata in one call.
///
/// # Errors
///
/// Returns error if compression fails.
#[cfg(feature = "compression")]
pub fn compress_with_metadata(
    data: &[u8],
    algorithm: CompressionAlgorithm,
    level: i32,
) -> Result<(Vec<u8>, CompressionMetadata)> {
    let checksum = crate::format::crc32(data);
    let compressed = compress_weights(data, algorithm, level)?;

    let metadata = CompressionMetadata {
        algorithm,
        level,
        uncompressed_size: data.len() as u64,
        compressed_size: compressed.len() as u64,
        uncompressed_checksum: checksum,
    };

    Ok((compressed, metadata))
}

// ============================================================================
// Stub Functions (when compression feature is disabled)
// ============================================================================

/// Compress weights (stub when compression feature is disabled).
///
/// # Errors
///
/// Always returns error when compression feature is disabled and
/// algorithm is not `None`.
#[cfg(not(feature = "compression"))]
pub fn compress_weights(
    data: &[u8],
    algorithm: CompressionAlgorithm,
    _level: i32,
) -> Result<Vec<u8>> {
    match algorithm {
        CompressionAlgorithm::None => Ok(data.to_vec()),
        _ => Err(HoloError::compression_not_available()),
    }
}

/// Decompress weights (stub when compression feature is disabled).
///
/// # Errors
///
/// Always returns error when compression feature is disabled and
/// algorithm is not `None`.
#[cfg(not(feature = "compression"))]
pub fn decompress_weights(compressed: &[u8], metadata: &CompressionMetadata) -> Result<Vec<u8>> {
    match metadata.algorithm {
        CompressionAlgorithm::None => Ok(compressed.to_vec()),
        _ => Err(HoloError::compression_not_available()),
    }
}

/// Compress and create metadata (stub when compression feature is disabled).
///
/// # Errors
///
/// Always returns error when compression feature is disabled and
/// algorithm is not `None`.
#[cfg(not(feature = "compression"))]
pub fn compress_with_metadata(
    data: &[u8],
    algorithm: CompressionAlgorithm,
    level: i32,
) -> Result<(Vec<u8>, CompressionMetadata)> {
    let compressed = compress_weights(data, algorithm, level)?;
    let checksum = crate::format::crc32(data);

    let metadata = CompressionMetadata {
        algorithm,
        level,
        uncompressed_size: data.len() as u64,
        compressed_size: compressed.len() as u64,
        uncompressed_checksum: checksum,
    };

    Ok((compressed, metadata))
}

// ============================================================================
// Algorithm-Specific Implementations
// ============================================================================

#[cfg(feature = "compression")]
fn compress_zstd(data: &[u8], level: i32) -> Result<Vec<u8>> {
    zstd::encode_all(std::io::Cursor::new(data), level)
        .map_err(|e| HoloError::compression(format!("zstd compression failed: {e}")))
}

#[cfg(feature = "compression")]
fn decompress_zstd(data: &[u8], expected_size: u64) -> Result<Vec<u8>> {
    let capacity = usize::try_from(expected_size).map_err(|_| {
        HoloError::decompression("uncompressed size exceeds usize::MAX".to_string())
    })?;
    let mut output = Vec::with_capacity(capacity);
    zstd::stream::copy_decode(data, &mut output)
        .map_err(|e| HoloError::decompression(format!("zstd decompression failed: {e}")))?;
    Ok(output)
}

#[cfg(feature = "compression")]
fn compress_lz4(data: &[u8], _level: i32) -> Vec<u8> {
    lz4_flex::compress_prepend_size(data)
}

#[cfg(feature = "compression")]
fn decompress_lz4(data: &[u8], _expected_size: u64) -> Result<Vec<u8>> {
    lz4_flex::decompress_size_prepended(data)
        .map_err(|e| HoloError::decompression(format!("lz4 decompression failed: {e}")))
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    // ------------------------------------------------------------------------
    // CompressionAlgorithm Tests
    // ------------------------------------------------------------------------

    #[test]
    fn test_compression_algorithm_is_compressed() {
        assert!(!CompressionAlgorithm::None.is_compressed());
        assert!(CompressionAlgorithm::Zstd.is_compressed());
        assert!(CompressionAlgorithm::Lz4.is_compressed());
    }

    #[test]
    fn test_compression_algorithm_default_level() {
        assert_eq!(CompressionAlgorithm::None.default_level(), 0);
        assert_eq!(CompressionAlgorithm::Zstd.default_level(), 3);
        assert_eq!(CompressionAlgorithm::Lz4.default_level(), 1);
    }

    #[test]
    fn test_compression_algorithm_default() {
        assert_eq!(CompressionAlgorithm::default(), CompressionAlgorithm::None);
    }

    // ------------------------------------------------------------------------
    // CompressionMetadata Tests
    // ------------------------------------------------------------------------

    #[test]
    fn test_compression_metadata_uncompressed() {
        let metadata = CompressionMetadata::uncompressed(1000, 0xDEAD_BEEF);

        assert_eq!(metadata.algorithm, CompressionAlgorithm::None);
        assert_eq!(metadata.uncompressed_size, 1000);
        assert_eq!(metadata.compressed_size, 1000);
        assert_eq!(metadata.uncompressed_checksum, 0xDEAD_BEEF);
    }

    #[test]
    fn test_compression_metadata_compression_ratio() {
        let metadata = CompressionMetadata {
            algorithm: CompressionAlgorithm::Zstd,
            level: 3,
            uncompressed_size: 1000,
            compressed_size: 500,
            uncompressed_checksum: 0,
        };

        assert!((metadata.compression_ratio() - 0.5).abs() < 0.001);
    }

    #[test]
    fn test_compression_metadata_compression_ratio_empty() {
        let metadata = CompressionMetadata::default();
        assert!((metadata.compression_ratio() - 1.0).abs() < 0.001);
    }

    #[test]
    fn test_compression_metadata_space_savings() {
        let metadata = CompressionMetadata {
            algorithm: CompressionAlgorithm::Zstd,
            level: 3,
            uncompressed_size: 1000,
            compressed_size: 250,
            uncompressed_checksum: 0,
        };

        assert!((metadata.space_savings_percent() - 75.0).abs() < 0.001);
    }

    #[test]
    fn test_compression_metadata_default() {
        let metadata = CompressionMetadata::default();
        assert_eq!(metadata.algorithm, CompressionAlgorithm::None);
        assert_eq!(metadata.uncompressed_size, 0);
        assert_eq!(metadata.compressed_size, 0);
    }

    // ------------------------------------------------------------------------
    // Serialization Tests
    // ------------------------------------------------------------------------

    #[test]
    fn test_compression_algorithm_rkyv_roundtrip() {
        for algo in [
            CompressionAlgorithm::None,
            CompressionAlgorithm::Zstd,
            CompressionAlgorithm::Lz4,
        ] {
            let bytes = rkyv::to_bytes::<_, 16>(&algo).unwrap();
            let restored: CompressionAlgorithm = rkyv::from_bytes(&bytes).unwrap();
            assert_eq!(algo, restored);
        }
    }

    #[test]
    fn test_compression_metadata_rkyv_roundtrip() {
        let metadata = CompressionMetadata {
            algorithm: CompressionAlgorithm::Zstd,
            level: 5,
            uncompressed_size: 1_000_000,
            compressed_size: 250_000,
            uncompressed_checksum: 0xCAFE_BABE,
        };

        let bytes = rkyv::to_bytes::<_, 64>(&metadata).unwrap();
        let restored: CompressionMetadata = rkyv::from_bytes(&bytes).unwrap();

        assert_eq!(metadata.algorithm, restored.algorithm);
        assert_eq!(metadata.level, restored.level);
        assert_eq!(metadata.uncompressed_size, restored.uncompressed_size);
        assert_eq!(metadata.compressed_size, restored.compressed_size);
        assert_eq!(
            metadata.uncompressed_checksum,
            restored.uncompressed_checksum
        );
    }

    // ------------------------------------------------------------------------
    // Compression Function Tests (no-compression feature)
    // ------------------------------------------------------------------------

    #[test]
    fn test_compress_none_algorithm() {
        let data = vec![1, 2, 3, 4, 5];
        let result = compress_weights(&data, CompressionAlgorithm::None, 0);
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), data);
    }

    #[test]
    fn test_decompress_none_algorithm() {
        let data = vec![1, 2, 3, 4, 5];
        let metadata = CompressionMetadata::uncompressed(5, 0);
        let result = decompress_weights(&data, &metadata);
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), data);
    }

    // ------------------------------------------------------------------------
    // Compression Tests (with compression feature)
    // ------------------------------------------------------------------------

    #[cfg(feature = "compression")]
    mod compression_tests {
        use super::*;

        #[test]
        fn test_zstd_compress_decompress() {
            let data: Vec<u8> = (0u32..1000)
                .map(|i| u8::try_from(i % 256).unwrap())
                .collect();
            let compressed = compress_weights(&data, CompressionAlgorithm::Zstd, 3).unwrap();

            // Should be compressed
            assert!(compressed.len() < data.len());

            let metadata = CompressionMetadata {
                algorithm: CompressionAlgorithm::Zstd,
                level: 3,
                uncompressed_size: data.len() as u64,
                compressed_size: compressed.len() as u64,
                uncompressed_checksum: crate::format::crc32(&data),
            };

            let decompressed = decompress_weights(&compressed, &metadata).unwrap();
            assert_eq!(data, decompressed);
        }

        #[test]
        fn test_lz4_compress_decompress() {
            let data: Vec<u8> = (0u32..1000)
                .map(|i| u8::try_from(i % 256).unwrap())
                .collect();
            let compressed = compress_weights(&data, CompressionAlgorithm::Lz4, 1).unwrap();

            let metadata = CompressionMetadata {
                algorithm: CompressionAlgorithm::Lz4,
                level: 1,
                uncompressed_size: data.len() as u64,
                compressed_size: compressed.len() as u64,
                uncompressed_checksum: crate::format::crc32(&data),
            };

            let decompressed = decompress_weights(&compressed, &metadata).unwrap();
            assert_eq!(data, decompressed);
        }

        #[test]
        fn test_compress_with_metadata() {
            let data: Vec<u8> = vec![0; 1000]; // Highly compressible

            let (compressed, metadata) =
                compress_with_metadata(&data, CompressionAlgorithm::Zstd, 3).unwrap();

            assert_eq!(metadata.algorithm, CompressionAlgorithm::Zstd);
            assert_eq!(metadata.uncompressed_size, 1000);
            assert_eq!(metadata.compressed_size, compressed.len() as u64);
            assert!(compressed.len() < 1000);

            // Verify can decompress
            let decompressed = decompress_weights(&compressed, &metadata).unwrap();
            assert_eq!(data, decompressed);
        }

        #[test]
        fn test_decompress_checksum_mismatch() {
            let data = vec![1, 2, 3, 4, 5];
            let compressed = compress_weights(&data, CompressionAlgorithm::Zstd, 3).unwrap();

            let metadata = CompressionMetadata {
                algorithm: CompressionAlgorithm::Zstd,
                level: 3,
                uncompressed_size: data.len() as u64,
                compressed_size: compressed.len() as u64,
                uncompressed_checksum: 0xDEAD_BEEF, // Wrong checksum
            };

            let result = decompress_weights(&compressed, &metadata);
            assert!(result.is_err());
        }
    }
}
