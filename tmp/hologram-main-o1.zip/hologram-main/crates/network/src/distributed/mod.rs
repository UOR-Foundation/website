//! Distributed execution module.
//!
//! This module provides work distribution across nodes in the network,
//! enabling parallel execution of computation graphs across multiple machines.
//!
//! # Features
//!
//! - **Work Scheduling**: Distribute tasks to available workers
//! - **Result Aggregation**: Collect and combine results from workers
//! - **Fault Tolerance**: Handle worker failures gracefully
//! - **Local Pool**: Zero-overhead execution for single-machine deployments
//!
//! # Example
//!
//! ```ignore
//! use hologram_network::distributed::{Scheduler, ExecutionRequest};
//!
//! // Create a scheduler
//! let scheduler = Scheduler::default();
//!
//! // Register a worker
//! let worker_id = scheduler.register_worker(vec!["bert/embeddings:v1.0".to_string()]).await;
//!
//! // Submit work
//! let request = ExecutionRequest::new("bert/embeddings:v1.0", vec![1, 2, 3]);
//! scheduler.submit(request).await?;
//! ```

mod executor;
mod local_pool;
mod scheduler;

pub use executor::{ExecutionResult, Executor, ExecutorConfig, ExecutorError, ExecutorStats};
pub use local_pool::{
    LocalPoolConfig, LocalPoolError, LocalWorkerPool, PartitionExecutor, PartitionExecutorConfig,
    PartitionExecutorStats, PartitionRequest, PartitionResult,
};
pub use scheduler::{
    ExecutionRequest, Scheduler, SchedulerConfig, SchedulerError, WorkerId, WorkerState,
};
