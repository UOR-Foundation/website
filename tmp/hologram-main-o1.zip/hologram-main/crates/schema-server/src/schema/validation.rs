//! Validation rules for mutations.

use crate::error::{Result, ServerError};

/// Validate that a constant can be mutated to the given value.
pub fn validate_constant_mutation(name: &str, value: i64) -> Result<()> {
    match name {
        // Fundamental axioms cannot be changed
        "U" => Err(ServerError::ImmutableConstant(
            "U (Identity axiom) is immutable".to_string(),
        )),
        "D" => Err(ServerError::ImmutableConstant(
            "D (Duality axiom) is immutable".to_string(),
        )),

        // T must be positive and reasonable
        "T" => {
            if !(1..=10).contains(&value) {
                Err(ServerError::ValidationError(
                    "T must be between 1 and 10".to_string(),
                ))
            } else {
                Ok(())
            }
        }

        // O must be positive and reasonable
        "O" => {
            if !(1..=16).contains(&value) {
                Err(ServerError::ValidationError(
                    "O must be between 1 and 16".to_string(),
                ))
            } else {
                Ok(())
            }
        }

        // B must be a power of 2
        "B" => {
            if value < 1 || (value & (value - 1)) != 0 {
                Err(ServerError::ValidationError(
                    "B must be a positive power of 2".to_string(),
                ))
            } else {
                Ok(())
            }
        }

        // R must be positive
        "R" => {
            if value < 1 {
                Err(ServerError::ValidationError(
                    "R must be positive".to_string(),
                ))
            } else {
                Ok(())
            }
        }

        // Other constants - allow any value
        _ => Ok(()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_immutable_axioms() {
        assert!(validate_constant_mutation("U", 2).is_err());
        assert!(validate_constant_mutation("D", 3).is_err());
    }

    #[test]
    fn test_valid_t() {
        assert!(validate_constant_mutation("T", 3).is_ok());
        assert!(validate_constant_mutation("T", 1).is_ok());
        assert!(validate_constant_mutation("T", 10).is_ok());
    }

    #[test]
    fn test_invalid_t() {
        assert!(validate_constant_mutation("T", 0).is_err());
        assert!(validate_constant_mutation("T", 11).is_err());
    }

    #[test]
    fn test_valid_b() {
        assert!(validate_constant_mutation("B", 1).is_ok());
        assert!(validate_constant_mutation("B", 2).is_ok());
        assert!(validate_constant_mutation("B", 32).is_ok());
        assert!(validate_constant_mutation("B", 64).is_ok());
    }

    #[test]
    fn test_invalid_b() {
        assert!(validate_constant_mutation("B", 0).is_err());
        assert!(validate_constant_mutation("B", 3).is_err());
        assert!(validate_constant_mutation("B", 5).is_err());
    }
}
