//! Graph visualization in DOT format.
//!
//! This module provides DOT (Graphviz) format output for debugging
//! compilation issues. Enable with the `visualize` feature flag.
//!
//! # Example
//!
//! ```rust,ignore
//! use hologram_compiler::{OperationGraph, visualize::to_dot};
//!
//! let graph = build_graph();
//! let dot = to_dot(&graph);
//! std::fs::write("graph.dot", dot)?;
//! // Then: dot -Tpng graph.dot -o graph.png
//! ```

use crate::graph::{DType, OpKind, OperationGraph};
use std::fmt::Write;

/// Configuration for DOT output.
#[derive(Debug, Clone)]
#[allow(clippy::struct_excessive_bools)]
pub struct DotConfig {
    /// Include shape information in node labels.
    pub show_shapes: bool,
    /// Include data types in node labels.
    pub show_dtypes: bool,
    /// Include operation parameters in node labels.
    pub show_params: bool,
    /// Use colors to distinguish operation categories.
    pub use_colors: bool,
    /// Graph direction: "TB" (top-bottom), "LR" (left-right).
    pub direction: String,
}

impl Default for DotConfig {
    fn default() -> Self {
        Self {
            show_shapes: true,
            show_dtypes: true,
            show_params: true,
            use_colors: true,
            direction: "TB".to_string(),
        }
    }
}

impl DotConfig {
    /// Create a minimal config (just operation names).
    #[must_use]
    pub fn minimal() -> Self {
        Self {
            show_shapes: false,
            show_dtypes: false,
            show_params: false,
            use_colors: false,
            direction: "TB".to_string(),
        }
    }

    /// Set graph direction to left-right.
    #[must_use]
    pub fn left_right(mut self) -> Self {
        self.direction = "LR".to_string();
        self
    }
}

/// Convert an `OperationGraph` to DOT format.
///
/// # Example
///
/// ```rust
/// use hologram_compiler::graph::{OperationGraph, OpNode, OpKind, DType};
/// use hologram_compiler::visualize::to_dot;
///
/// let mut graph = OperationGraph::new();
/// graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
/// graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
/// graph.add_edge(0, 1);
///
/// let dot = to_dot(&graph);
/// assert!(dot.contains("digraph"));
/// assert!(dot.contains("Input"));
/// assert!(dot.contains("Relu"));
/// ```
#[must_use]
pub fn to_dot(graph: &OperationGraph) -> String {
    to_dot_with_config(graph, &DotConfig::default())
}

/// Convert an `OperationGraph` to DOT format with custom configuration.
#[must_use]
pub fn to_dot_with_config(graph: &OperationGraph, config: &DotConfig) -> String {
    let mut dot = String::new();

    // Header
    let _ = writeln!(dot, "digraph OperationGraph {{");
    let _ = writeln!(dot, "  rankdir={};", config.direction);
    let _ = writeln!(dot, "  node [shape=box, fontname=\"Helvetica\"];");
    let _ = writeln!(dot, "  edge [fontname=\"Helvetica\", fontsize=10];");
    dot.push('\n');

    // Nodes
    for node in &graph.nodes {
        let label = format_node_label(node, config);
        let color = if config.use_colors {
            op_color(&node.op)
        } else {
            "white"
        };

        let _ = writeln!(
            dot,
            "  n{} [label=\"{}\", style=filled, fillcolor=\"{}\"];",
            node.id, label, color
        );
    }
    dot.push('\n');

    // Edges
    for (src, dst) in &graph.edges {
        let _ = writeln!(dot, "  n{src} -> n{dst};");
    }
    dot.push('\n');

    // Input/output subgraphs for visual grouping
    if !graph.inputs.is_empty() {
        let _ = writeln!(dot, "  subgraph cluster_inputs {{");
        let _ = writeln!(dot, "    label=\"Inputs\";");
        let _ = writeln!(dot, "    style=dashed;");
        let _ = writeln!(dot, "    color=gray;");
        for (name, id) in &graph.inputs {
            let _ = writeln!(dot, "    n{id} [xlabel=\"{name}\"];");
        }
        let _ = writeln!(dot, "  }}");
        dot.push('\n');
    }

    if !graph.outputs.is_empty() {
        let _ = writeln!(dot, "  subgraph cluster_outputs {{");
        let _ = writeln!(dot, "    label=\"Outputs\";");
        let _ = writeln!(dot, "    style=dashed;");
        let _ = writeln!(dot, "    color=gray;");
        for (name, id) in &graph.outputs {
            let _ = writeln!(dot, "    n{id} [xlabel=\"{name}\"];");
        }
        let _ = writeln!(dot, "  }}");
    }

    dot.push_str("}\n");
    dot
}

/// Format a node label based on configuration.
fn format_node_label(node: &crate::graph::OpNode, config: &DotConfig) -> String {
    let mut parts = Vec::new();

    // Node ID and operation name
    let name = format_op_name(&node.op);
    parts.push(format!("[{}] {name}", node.id));

    // Optional debug name
    if let Some(name) = &node.name {
        parts.push(format!("\\n({name})"));
    }

    // Operation parameters
    if config.show_params {
        if let Some(params) = format_op_params(&node.op) {
            parts.push(format!("\\n{params}"));
        }
    }

    // Shape
    if config.show_shapes {
        let shape_str = format_shape(&node.shape);
        parts.push(format!("\\n{shape_str}"));
    }

    // Data type
    if config.show_dtypes {
        parts.push(format!("\\n{}", format_dtype(node.dtype)));
    }

    parts.join("")
}

/// Format operation name (without parameters).
fn format_op_name(op: &OpKind) -> &'static str {
    match op {
        // Arithmetic
        OpKind::Add => "Add",
        OpKind::Sub => "Sub",
        OpKind::Mul => "Mul",
        OpKind::Div => "Div",
        OpKind::Sqrt => "Sqrt",
        OpKind::Log => "Log",
        OpKind::Pow => "Pow",
        OpKind::Exp => "Exp",
        OpKind::Abs => "Abs",
        OpKind::ElemMin => "ElemMin",
        OpKind::ElemMax => "ElemMax",

        // Comparison
        OpKind::Greater => "Greater",
        OpKind::Less => "Less",
        OpKind::LessOrEqual => "LessOrEqual",
        OpKind::GreaterOrEqual => "GreaterOrEqual",

        // Conditional
        OpKind::Where => "Where",

        // Activations
        OpKind::Sigmoid => "Sigmoid",
        OpKind::Tanh => "Tanh",
        OpKind::Relu => "ReLU",
        OpKind::Gelu => "GELU",
        OpKind::Silu => "SiLU",
        OpKind::Softmax { .. } => "Softmax",

        // Linear algebra
        OpKind::MatMul { .. } => "MatMul",
        OpKind::BatchMatMul { .. } => "BatchMatMul",

        // CNN
        OpKind::Conv2d { .. } => "Conv2d",
        OpKind::BatchNormalization { .. } => "BatchNorm",
        OpKind::LayerNorm { .. } => "LayerNorm",
        OpKind::MaxPool { .. } => "MaxPool",
        OpKind::AvgPool { .. } => "AvgPool",
        OpKind::GlobalAveragePool => "GlobalAvgPool",
        OpKind::Flatten { .. } => "Flatten",

        // Reduction
        OpKind::Sum => "Sum",
        OpKind::Max => "Max",
        OpKind::Min => "Min",
        OpKind::Mean => "Mean",

        // Categorical
        OpKind::Lift => "Lift",
        OpKind::OrbitClassify => "OrbitClassify",

        // Memory
        OpKind::Load => "Load",
        OpKind::Store => "Store",
        OpKind::Copy => "Copy",

        // Shape
        OpKind::Reshape { .. } => "Reshape",
        OpKind::Transpose { .. } => "Transpose",
        OpKind::Gather { .. } => "Gather",
        OpKind::Concat { .. } => "Concat",
        OpKind::Unsqueeze { .. } => "Unsqueeze",
        OpKind::Squeeze { .. } => "Squeeze",
        OpKind::Tile { .. } => "Tile",
        OpKind::Expand { .. } => "Expand",
        OpKind::Slice { .. } => "Slice",
        OpKind::Split { .. } => "Split",
        OpKind::Pad { .. } => "Pad",
        OpKind::Cast { .. } => "Cast",

        // Control flow
        OpKind::CallLayer { .. } => "CallLayer",

        // Codec
        OpKind::Encode { .. } => "Encode",
        OpKind::Decode { .. } => "Decode",

        // Hash
        OpKind::Sha256 { .. } => "Sha256",
        OpKind::DoubleSha256 { .. } => "DoubleSha256",

        // Tokenization
        OpKind::ViterbiTokenize { .. } => "ViterbiTokenize",

        // Fused
        OpKind::MatMulRelu { .. } => "MatMulReLU",
        OpKind::AddSigmoid => "AddSigmoid",

        // Special
        OpKind::Input => "Input",
        OpKind::Output => "Output",
        OpKind::Constant => "Constant",
    }
}

/// Format operation parameters for display.
fn format_op_params(op: &OpKind) -> Option<String> {
    match op {
        OpKind::Softmax { axis } => Some(format!("axis={axis}")),
        OpKind::MatMul { m, k, n } | OpKind::MatMulRelu { m, k, n } => Some(format!("{m}x{k}x{n}")),
        OpKind::BatchMatMul { batch, m, k, n } => Some(format!("batch={batch:?}, {m}x{k}x{n}")),
        OpKind::Conv2d {
            kernel,
            stride,
            padding,
            dilation,
            groups,
        } => Some(format!(
            "k={}x{}, s={},{}, p={},{}, d={},{}, g={}",
            kernel.0,
            kernel.1,
            stride.0,
            stride.1,
            padding.0,
            padding.1,
            dilation.0,
            dilation.1,
            groups
        )),
        OpKind::BatchNormalization { epsilon } => Some(format!("eps={epsilon:.0e}")),
        OpKind::LayerNorm {
            normalized_dims,
            epsilon,
        } => Some(format!("dims={normalized_dims}, eps={epsilon:.0e}")),
        OpKind::MaxPool {
            kernel,
            stride,
            padding,
        }
        | OpKind::AvgPool {
            kernel,
            stride,
            padding,
        } => Some(format!(
            "k={}x{}, s={},{}, p={},{}",
            kernel.0, kernel.1, stride.0, stride.1, padding.0, padding.1
        )),
        OpKind::Flatten { start_dim } => Some(format!("start={start_dim}")),
        OpKind::Reshape { shape } | OpKind::Expand { shape } => Some(format!("shape={shape:?}")),
        OpKind::Transpose { perm } => Some(format!("perm={perm:?}")),
        OpKind::Gather { axis } | OpKind::Unsqueeze { axis } | OpKind::Squeeze { axis } => {
            Some(format!("axis={axis}"))
        }
        OpKind::Concat { axis, num_inputs } => Some(format!("axis={axis}, n={num_inputs}")),
        OpKind::Tile { multiples } => Some(format!("mult={multiples:?}")),
        OpKind::Slice {
            starts,
            ends,
            steps,
        } => Some(format!("starts={starts:?}, ends={ends:?}, steps={steps:?}")),
        OpKind::Split {
            axis,
            split_sizes,
            output_index,
        } => Some(format!(
            "axis={axis}, sizes={split_sizes:?}, out={output_index}"
        )),
        OpKind::Pad {
            pads,
            mode,
            constant_value,
        } => Some(format!(
            "pads={pads:?}, mode={mode:?}, val={constant_value}"
        )),
        OpKind::Cast { to } => Some(format!("to={}", format_dtype(*to))),
        OpKind::CallLayer { layer_id } => Some(format!("layer={layer_id}")),
        OpKind::Encode { codec_id } | OpKind::Decode { codec_id } => {
            Some(format!("codec={codec_id}"))
        }
        OpKind::Sha256 { src_len } | OpKind::DoubleSha256 { src_len } => {
            Some(format!("src_len={src_len}"))
        }
        OpKind::ViterbiTokenize { max_tokens, .. } => Some(format!("max_tokens={max_tokens}")),
        _ => None,
    }
}

/// Format a shape for display.
fn format_shape(shape: &[usize]) -> String {
    if shape.is_empty() {
        "scalar".to_string()
    } else {
        format!(
            "[{}]",
            shape
                .iter()
                .map(ToString::to_string)
                .collect::<Vec<_>>()
                .join(", ")
        )
    }
}

/// Format a data type for display.
fn format_dtype(dtype: DType) -> &'static str {
    match dtype {
        DType::F32 => "f32",
        DType::F64 => "f64",
        DType::I8 => "i8",
        DType::I16 => "i16",
        DType::I32 => "i32",
        DType::I64 => "i64",
        DType::U8 => "u8",
        DType::U16 => "u16",
        DType::U32 => "u32",
        DType::U64 => "u64",
        DType::Bool => "bool",
    }
}

/// Get a color for an operation category.
fn op_color(op: &OpKind) -> &'static str {
    match op {
        // Input/Output: light blue
        OpKind::Input | OpKind::Output => "#E3F2FD",

        // Constants: light gray
        OpKind::Constant => "#F5F5F5",

        // Arithmetic: light green
        OpKind::Add
        | OpKind::Sub
        | OpKind::Mul
        | OpKind::Div
        | OpKind::Sqrt
        | OpKind::Log
        | OpKind::Pow
        | OpKind::Exp
        | OpKind::Abs
        | OpKind::ElemMin
        | OpKind::ElemMax => "#E8F5E9",

        // Comparison/Conditional: light yellow
        OpKind::Greater
        | OpKind::Less
        | OpKind::LessOrEqual
        | OpKind::GreaterOrEqual
        | OpKind::Where => "#FFFDE7",

        // Activations: light orange
        OpKind::Sigmoid
        | OpKind::Tanh
        | OpKind::Relu
        | OpKind::Gelu
        | OpKind::Silu
        | OpKind::Softmax { .. } => "#FFF3E0",

        // Linear algebra: light purple
        OpKind::MatMul { .. } | OpKind::BatchMatMul { .. } => "#F3E5F5",

        // CNN: light red
        OpKind::Conv2d { .. }
        | OpKind::BatchNormalization { .. }
        | OpKind::LayerNorm { .. }
        | OpKind::MaxPool { .. }
        | OpKind::AvgPool { .. }
        | OpKind::GlobalAveragePool
        | OpKind::Flatten { .. } => "#FFEBEE",

        // Reduction: light teal
        OpKind::Sum | OpKind::Max | OpKind::Min | OpKind::Mean => "#E0F2F1",

        // Shape: light cyan
        OpKind::Reshape { .. }
        | OpKind::Transpose { .. }
        | OpKind::Gather { .. }
        | OpKind::Concat { .. }
        | OpKind::Unsqueeze { .. }
        | OpKind::Squeeze { .. }
        | OpKind::Tile { .. }
        | OpKind::Expand { .. }
        | OpKind::Slice { .. }
        | OpKind::Split { .. }
        | OpKind::Pad { .. }
        | OpKind::Cast { .. } => "#E0F7FA",

        // Categorical: light pink
        OpKind::Lift | OpKind::OrbitClassify => "#FCE4EC",

        // Codec: light amber
        OpKind::Encode { .. } | OpKind::Decode { .. } => "#FFF8E1",

        // Hash: light blue-gray
        OpKind::Sha256 { .. } | OpKind::DoubleSha256 { .. } => "#ECEFF1",

        // Memory: light brown
        OpKind::Load | OpKind::Store | OpKind::Copy => "#EFEBE9",

        // Control flow: light indigo
        OpKind::CallLayer { .. } => "#E8EAF6",

        // Tokenization: light lime
        OpKind::ViterbiTokenize { .. } => "#F9FBE7",

        // Fused: light violet
        OpKind::MatMulRelu { .. } | OpKind::AddSigmoid => "#EDE7F6",
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::OpNode;

    fn create_simple_graph() -> OperationGraph {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![1, 4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_input("x", 0);
        graph.add_output("y", 2);
        graph
    }

    #[test]
    fn test_to_dot_basic() {
        let graph = create_simple_graph();
        let dot = to_dot(&graph);

        assert!(dot.contains("digraph OperationGraph"));
        assert!(dot.contains("n0"));
        assert!(dot.contains("n1"));
        assert!(dot.contains("n2"));
        assert!(dot.contains("n0 -> n1"));
        assert!(dot.contains("n1 -> n2"));
        assert!(dot.contains("Input"));
        assert!(dot.contains("ReLU"));
        assert!(dot.contains("Output"));
    }

    #[test]
    fn test_to_dot_with_shapes() {
        let graph = create_simple_graph();
        let dot = to_dot(&graph);

        assert!(dot.contains("[1, 4]"));
        assert!(dot.contains("f32"));
    }

    #[test]
    fn test_to_dot_minimal() {
        let graph = create_simple_graph();
        let config = DotConfig::minimal();
        let dot = to_dot_with_config(&graph, &config);

        assert!(dot.contains("Input"));
        assert!(!dot.contains("[1, 4]")); // No shape
        assert!(!dot.contains("f32")); // No dtype
    }

    #[test]
    fn test_to_dot_matmul() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![4, 8], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![8, 16], DType::F32));
        graph.add_node(OpNode::new(
            2,
            OpKind::MatMul { m: 4, k: 8, n: 16 },
            vec![4, 16],
            DType::F32,
        ));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);

        let dot = to_dot(&graph);
        assert!(dot.contains("MatMul"));
        assert!(dot.contains("4x8x16"));
    }

    #[test]
    fn test_to_dot_conv2d() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(
            0,
            OpKind::Conv2d {
                kernel: (3, 3),
                stride: (1, 1),
                padding: (1, 1),
                dilation: (1, 1),
                groups: 1,
            },
            vec![1, 64, 32, 32],
            DType::F32,
        ));

        let dot = to_dot(&graph);
        assert!(dot.contains("Conv2d"));
        assert!(dot.contains("k=3x3"));
        assert!(dot.contains("s=1,1"));
        assert!(dot.contains("p=1,1"));
    }

    #[test]
    fn test_to_dot_colors() {
        let graph = create_simple_graph();
        let dot = to_dot(&graph);

        // Input should have blue color
        assert!(dot.contains("#E3F2FD"));
        // ReLU should have orange color
        assert!(dot.contains("#FFF3E0"));
    }

    #[test]
    fn test_to_dot_left_right() {
        let graph = create_simple_graph();
        let config = DotConfig::default().left_right();
        let dot = to_dot_with_config(&graph, &config);

        assert!(dot.contains("rankdir=LR"));
    }

    #[test]
    fn test_to_dot_subgraphs() {
        let graph = create_simple_graph();
        let dot = to_dot(&graph);

        assert!(dot.contains("subgraph cluster_inputs"));
        assert!(dot.contains("subgraph cluster_outputs"));
        assert!(dot.contains("label=\"Inputs\""));
        assert!(dot.contains("label=\"Outputs\""));
    }

    #[test]
    fn test_to_dot_named_node() {
        let mut graph = OperationGraph::new();
        let node = OpNode::new(0, OpKind::Relu, vec![1, 4], DType::F32).with_name("my_relu");
        graph.add_node(node);

        let dot = to_dot(&graph);
        assert!(dot.contains("my_relu"));
    }

    #[test]
    fn test_to_dot_empty_graph() {
        let graph = OperationGraph::new();
        let dot = to_dot(&graph);

        assert!(dot.contains("digraph OperationGraph"));
        assert!(dot.contains('}'));
    }

    #[test]
    fn test_format_shape() {
        assert_eq!(format_shape(&[]), "scalar");
        assert_eq!(format_shape(&[1]), "[1]");
        assert_eq!(format_shape(&[1, 2, 3]), "[1, 2, 3]");
    }

    #[test]
    fn test_op_colors_distinct() {
        // Verify different categories get different colors
        let input_color = op_color(&OpKind::Input);
        let relu_color = op_color(&OpKind::Relu);
        let matmul_color = op_color(&OpKind::MatMul { m: 1, k: 1, n: 1 });
        let conv_color = op_color(&OpKind::Conv2d {
            kernel: (1, 1),
            stride: (1, 1),
            padding: (0, 0),
            dilation: (1, 1),
            groups: 1,
        });

        assert_ne!(input_color, relu_color);
        assert_ne!(relu_color, matmul_color);
        assert_ne!(matmul_color, conv_color);
    }
}
