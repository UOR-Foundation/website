# hologram-sha256

High-performance SHA-256 implementation tailored for Bitcoin mining using hardware acceleration (SHA-NI, ARMv8) and algorithmic optimizations.

## 🚀 Performance

| Metric      | Speedup vs Pure Rust     |
| ----------- | ------------------------ |
| Double Hash | **2.05x**                |
| Throughput  | **28.8 MH/s** (per core) |

## Quick Start (Mining)

```rust
use hologram_sha256::mining::MiningState;

let mut header = [0u8; 80];
let target = [0xFF; 32];
let mut miner = MiningState::new(&header, &target);

if let Some(nonce) = miner.check_range(0, 1_000_000) {
    println!("Found nonce: {}", nonce);
}
```

## Documentation

Full documentation and optimization details are available in **[docs/sha256.md](../../docs/sha256.md)**.
