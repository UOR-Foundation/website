//! Runtime performance baselines for Sprint 28 optimization targets.
//!
//! Isolates specific bottlenecks:
//! - Buffer allocation overhead (TASK-283)
//! - Plan clone cost (TASK-284)
//! - In-place operation overhead (TASK-285)
//! - Activation chain throughput (TASK-286)
//! - MatMul with varying sizes (TASK-287)

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};

use hologram_backend::backends::{cpu::CpuBackend, Backend};
use hologram_compiler::{compile, CompilerConfig, DType, OpKind, OpNode, OperationGraph};
use hologram_holo::types::{BufferMetadata, BufferType};
use hologram_holo::BackendPlan;

// ============================================================================
// Helpers
// ============================================================================

fn make_input(size: usize, seed: f32) -> Vec<u8> {
    let floats: Vec<f32> = (0..size).map(|i| seed + i as f32 * 0.1).collect();
    floats.iter().flat_map(|f| f.to_le_bytes()).collect()
}

fn make_binary_op_graph(op: OpKind, size: usize) -> BackendPlan {
    let mut graph = OperationGraph::new();
    let input_a = OpNode::new(0, OpKind::Input, vec![size], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![size], DType::F32);
    let operation = OpNode::new(2, op, vec![size], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![size], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(operation);
    graph.add_node(output);
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("result", 3);

    compile(&graph, &CompilerConfig::default()).expect("compilation failed")
}

fn make_unary_op_graph(op: OpKind, size: usize) -> BackendPlan {
    let mut graph = OperationGraph::new();
    let input = OpNode::new(0, OpKind::Input, vec![size], DType::F32);
    let operation = OpNode::new(1, op, vec![size], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![size], DType::F32);

    graph.add_node(input);
    graph.add_node(operation);
    graph.add_node(output);
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_input("x", 0);
    graph.add_output("result", 2);

    compile(&graph, &CompilerConfig::default()).expect("compilation failed")
}

fn make_matmul_graph(m: usize, n: usize, k: usize) -> BackendPlan {
    let mut graph = OperationGraph::new();
    let input_a = OpNode::new(0, OpKind::Input, vec![m, k], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![k, n], DType::F32);
    let matmul = OpNode::new(2, OpKind::MatMul { m, k, n }, vec![m, n], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![m, n], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(matmul);
    graph.add_node(output);
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("result", 3);

    compile(&graph, &CompilerConfig::default()).expect("compilation failed")
}

// ============================================================================
// 1. Buffer Allocation Overhead (TASK-283 baseline)
// ============================================================================

/// Measures BufferManager::new() cost in isolation.
/// This is the per-plan allocation overhead we want to eliminate with arena allocation.
fn bench_buffer_allocation(c: &mut Criterion) {
    use hologram_backend::backends::cpu::BufferManager;

    let mut group = c.benchmark_group("buffer_allocation");

    // Varying number of buffers (typical plans have 4-20 buffers)
    for num_buffers in [4, 8, 16, 32] {
        let buf_size = 16384; // 16 KB per buffer (4096 f32s)
        let total_bytes = num_buffers * buf_size;
        group.throughput(Throughput::Bytes(total_bytes as u64));

        // Build metadata: 1 input, num_buffers-2 workspace, 1 output
        let mut types = vec![BufferType::Input];
        for _ in 0..num_buffers - 2 {
            types.push(BufferType::Workspace);
        }
        types.push(BufferType::Output);

        let metadata: Vec<BufferMetadata> = types
            .iter()
            .map(|&bt| BufferMetadata::new(buf_size, bt))
            .collect();

        let input_data = vec![0u8; buf_size];
        let inputs: &[&[u8]] = &[&input_data];

        group.bench_with_input(
            BenchmarkId::new("new", format!("{num_buffers}x{buf_size}")),
            &num_buffers,
            |bench, _| {
                bench.iter(|| {
                    black_box(
                        BufferManager::new(black_box(&metadata), black_box(inputs), &[]).unwrap(),
                    )
                })
            },
        );
    }

    // Varying buffer sizes (with fixed 8 buffers)
    for buf_size in [256, 4096, 16384, 65536] {
        let num_buffers = 8;
        let total_bytes = num_buffers * buf_size;
        group.throughput(Throughput::Bytes(total_bytes as u64));

        let mut types = vec![BufferType::Input];
        for _ in 0..num_buffers - 2 {
            types.push(BufferType::Workspace);
        }
        types.push(BufferType::Output);

        let metadata: Vec<BufferMetadata> = types
            .iter()
            .map(|&bt| BufferMetadata::new(buf_size, bt))
            .collect();

        let input_data = vec![0u8; buf_size];
        let inputs: &[&[u8]] = &[&input_data];

        group.bench_with_input(
            BenchmarkId::new("size", format!("8x{buf_size}")),
            &buf_size,
            |bench, _| {
                bench.iter(|| {
                    black_box(
                        BufferManager::new(black_box(&metadata), black_box(inputs), &[]).unwrap(),
                    )
                })
            },
        );
    }

    group.finish();
}

// ============================================================================
// 1b. Lazy Zeroing Impact (TASK-323)
// ============================================================================

/// Compares buffer allocation with and without `fully_written` hint.
///
/// - `zeroed`: Output/Workspace buffers are zeroed (conservative, `fully_written=false`)
/// - `lazy`: Output/Workspace buffers skip zeroing (`fully_written=true`)
fn bench_lazy_zeroing(c: &mut Criterion) {
    use hologram_backend::backends::cpu::BufferManager;

    let mut group = c.benchmark_group("lazy_zeroing");

    for buf_size in [4096, 16384, 65536] {
        let num_buffers = 8;
        let total_bytes = num_buffers * buf_size;
        group.throughput(Throughput::Bytes(total_bytes as u64));

        // Conservative: fully_written=false (must zero workspace/output)
        let mut types_zeroed = vec![BufferType::Input];
        for _ in 0..num_buffers - 2 {
            types_zeroed.push(BufferType::Workspace);
        }
        types_zeroed.push(BufferType::Output);
        let metadata_zeroed: Vec<BufferMetadata> = types_zeroed
            .iter()
            .map(|&bt| BufferMetadata::new(buf_size, bt))
            .collect();

        // Lazy: fully_written=true (skip zeroing workspace/output)
        let metadata_lazy: Vec<BufferMetadata> = types_zeroed
            .iter()
            .map(|&bt| {
                let m = BufferMetadata::new(buf_size, bt);
                if matches!(bt, BufferType::Workspace | BufferType::Output) {
                    m.with_fully_written()
                } else {
                    m
                }
            })
            .collect();

        let input_data = vec![0u8; buf_size];
        let inputs: &[&[u8]] = &[&input_data];

        group.bench_with_input(
            BenchmarkId::new("zeroed", format!("8x{buf_size}")),
            &buf_size,
            |bench, _| {
                bench.iter(|| {
                    black_box(
                        BufferManager::new(black_box(&metadata_zeroed), black_box(inputs), &[])
                            .unwrap(),
                    )
                })
            },
        );

        group.bench_with_input(
            BenchmarkId::new("lazy", format!("8x{buf_size}")),
            &buf_size,
            |bench, _| {
                bench.iter(|| {
                    black_box(
                        BufferManager::new(black_box(&metadata_lazy), black_box(inputs), &[])
                            .unwrap(),
                    )
                })
            },
        );
    }

    group.finish();
}

// ============================================================================
// 2. Plan Clone Cost (TASK-284 baseline)
// ============================================================================

/// Measures the cost of BackendPlan::clone() at various plan sizes.
/// This is what Arc<BackendPlan> eliminates.
fn bench_plan_clone(c: &mut Criterion) {
    let mut group = c.benchmark_group("plan_clone");

    // Small plan: single Add operation
    let small_plan = make_binary_op_graph(OpKind::Add, 256);
    group.bench_function("small_add_256", |b| {
        b.iter(|| black_box(black_box(&small_plan).clone()))
    });

    // Medium plan: single MatMul
    let medium_plan = make_matmul_graph(128, 128, 128);
    group.bench_function("medium_matmul_128", |b| {
        b.iter(|| black_box(black_box(&medium_plan).clone()))
    });

    // Large plan: MatMul with large constants
    let large_plan = make_matmul_graph(512, 512, 512);
    group.bench_function("large_matmul_512", |b| {
        b.iter(|| black_box(black_box(&large_plan).clone()))
    });

    group.finish();
}

// ============================================================================
// 3. Small Plan End-to-End (TASK-283 + TASK-285 combined baseline)
// ============================================================================

/// Measures total execute_plan() latency for small plans where allocation dominates.
/// After arena allocation, these should improve dramatically.
fn bench_small_plan_e2e(c: &mut Criterion) {
    let mut group = c.benchmark_group("small_plan_e2e");
    let backend = CpuBackend::new();

    for size in [64, 256, 1024] {
        group.throughput(Throughput::Elements(size as u64));

        let plan = make_binary_op_graph(OpKind::Add, size);
        let a = make_input(size, 1.0);
        let b = make_input(size, 2.0);
        let inputs: &[&[u8]] = &[&a, &b];
        let mut output = vec![0u8; size * 4];

        group.bench_with_input(BenchmarkId::new("add", size), &size, |bench, _| {
            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
            })
        });

        let plan = make_unary_op_graph(OpKind::Relu, size);
        let x = make_input(size, -1.0);
        let inputs: &[&[u8]] = &[&x];

        group.bench_with_input(BenchmarkId::new("relu", size), &size, |bench, _| {
            bench.iter(|| {
                let outputs: &mut [&mut [u8]] = &mut [&mut output];
                backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
            })
        });
    }

    group.finish();
}

// ============================================================================
// 4. Activation Chain (TASK-286 baseline)
// ============================================================================

/// Measures sequential activation execution — the pattern LUT fusion targets.
/// Runs sigmoid, then tanh, then relu on the same data as separate plans.
fn bench_activation_chain(c: &mut Criterion) {
    let mut group = c.benchmark_group("activation_chain");
    let backend = CpuBackend::new();

    for size in [1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        let sigmoid_plan = make_unary_op_graph(OpKind::Sigmoid, size);
        let tanh_plan = make_unary_op_graph(OpKind::Tanh, size);
        let relu_plan = make_unary_op_graph(OpKind::Relu, size);

        let x = make_input(size, -2.0);
        let mut buf = vec![0u8; size * 4];

        // Single activation
        group.bench_with_input(
            BenchmarkId::new("single_sigmoid", size),
            &size,
            |bench, _| {
                bench.iter(|| {
                    let inputs: &[&[u8]] = &[&x];
                    let outputs: &mut [&mut [u8]] = &mut [&mut buf];
                    backend.execute_plan(black_box(&sigmoid_plan), black_box(inputs), outputs)
                })
            },
        );

        // Three activations in sequence (current: 3 separate dispatches)
        group.bench_with_input(
            BenchmarkId::new("chain_sig_tanh_relu", size),
            &size,
            |bench, _| {
                bench.iter(|| {
                    let mut intermediate = x.clone();
                    let mut out = vec![0u8; size * 4];

                    // Sigmoid
                    let inputs: &[&[u8]] = &[&intermediate];
                    let outputs: &mut [&mut [u8]] = &mut [&mut out];
                    backend
                        .execute_plan(black_box(&sigmoid_plan), black_box(inputs), outputs)
                        .unwrap();
                    std::mem::swap(&mut intermediate, &mut out);

                    // Tanh
                    let inputs: &[&[u8]] = &[&intermediate];
                    let outputs: &mut [&mut [u8]] = &mut [&mut out];
                    backend
                        .execute_plan(black_box(&tanh_plan), black_box(inputs), outputs)
                        .unwrap();
                    std::mem::swap(&mut intermediate, &mut out);

                    // Relu
                    let inputs: &[&[u8]] = &[&intermediate];
                    let outputs: &mut [&mut [u8]] = &mut [&mut out];
                    backend
                        .execute_plan(black_box(&relu_plan), black_box(inputs), outputs)
                        .unwrap();
                })
            },
        );
    }

    group.finish();
}

// ============================================================================
// 5. MatMul Baseline (TASK-287 baseline)
// ============================================================================

/// Focused MatMul benchmarks at sizes relevant to transformer layers.
/// After weight pre-packing, these should improve 10-20%.
fn bench_matmul_baseline(c: &mut Criterion) {
    let mut group = c.benchmark_group("matmul_baseline");
    let backend = CpuBackend::new();

    // Transformer-relevant sizes: (batch, hidden, hidden)
    for (m, n, k) in [
        (1, 768, 768),   // Single token, GPT-2 hidden dim
        (8, 768, 768),   // 8 tokens
        (32, 768, 768),  // 32 tokens
        (1, 768, 3072),  // FFN expansion (1:4)
        (32, 3072, 768), // FFN contraction
    ] {
        let flops = 2 * m * n * k;
        group.throughput(Throughput::Elements(flops as u64));

        let plan = make_matmul_graph(m, n, k);
        let a = make_input(m * k, 0.01);
        let b = make_input(k * n, 0.01);
        let inputs: &[&[u8]] = &[&a, &b];
        let mut output = vec![0u8; m * n * 4];

        group.bench_with_input(
            BenchmarkId::new("gemm", format!("{m}x{n}x{k}")),
            &(m, n, k),
            |bench, _| {
                bench.iter(|| {
                    let outputs: &mut [&mut [u8]] = &mut [&mut output];
                    backend.execute_plan(black_box(&plan), black_box(inputs), outputs)
                })
            },
        );
    }

    group.finish();
}

// ============================================================================
// 6. LUT Fusion (TASK-286 target)
// ============================================================================

/// Build a BackendPlan with sequential LUT instructions for fusion benchmarks.
fn make_lut_chain_plan(lut_count: usize, data_size: usize) -> BackendPlan {
    use hologram_holo::IsaInstruction;

    // 2 buffers: input (buf 0), workspace (buf 1)
    let buffers = vec![
        BufferMetadata::new(data_size, BufferType::Input),
        BufferMetadata::new(data_size, BufferType::Output),
    ];

    // Chain of LUT instructions cycling through sigmoid→tanh→relu
    let lut_ops = [
        |dst, src, count| IsaInstruction::SigmoidLUT { dst, src, count },
        |dst, src, count| IsaInstruction::TanhLUT { dst, src, count },
        |dst, src, count| IsaInstruction::ReluLUT { dst, src, count },
    ];

    let mut instructions = Vec::with_capacity(lut_count);
    for i in 0..lut_count {
        let (src, dst) = if i == 0 { (0, 1) } else { (1, 1) };
        instructions.push(lut_ops[i % 3](dst, src, data_size));
    }

    BackendPlan {
        instructions,
        buffers,
        constants: vec![],
        workspace_size: 0,
        dependencies: vec![],
        node_buffer_map: vec![Some(0), Some(1)],
        metadata: hologram_holo::PlanMetadata::default(),
        observable_metadata: hologram_holo::types::ObservableMetadata::new(),
        lut_section: hologram_holo::types::LutSection::new(),
    }
}

/// Benchmark LUT activation chains: unfused vs fused.
fn bench_lut_fusion(c: &mut Criterion) {
    let mut group = c.benchmark_group("lut_fusion");
    let backend = CpuBackend::new();

    for size in [1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        // Single LUT (baseline)
        let single_plan = make_lut_chain_plan(1, size);
        let input: Vec<u8> = (0..size).map(|i| (i % 256) as u8).collect();
        let mut out = vec![0u8; size];

        group.bench_with_input(
            BenchmarkId::new("single_sigmoid", size),
            &size,
            |bench, _| {
                bench.iter(|| {
                    let inputs: &[&[u8]] = &[&input];
                    let outputs: &mut [&mut [u8]] = &mut [&mut out];
                    backend
                        .execute_plan(black_box(&single_plan), black_box(inputs), outputs)
                        .unwrap();
                })
            },
        );

        // Chain of 3 LUTs (should be fused into single pass)
        let chain3_plan = make_lut_chain_plan(3, size);

        group.bench_with_input(
            BenchmarkId::new("chain_3_fused", size),
            &size,
            |bench, _| {
                bench.iter(|| {
                    let inputs: &[&[u8]] = &[&input];
                    let outputs: &mut [&mut [u8]] = &mut [&mut out];
                    backend
                        .execute_plan(black_box(&chain3_plan), black_box(inputs), outputs)
                        .unwrap();
                })
            },
        );

        // Chain of 5 LUTs (should be fused into single pass)
        let chain5_plan = make_lut_chain_plan(5, size);

        group.bench_with_input(
            BenchmarkId::new("chain_5_fused", size),
            &size,
            |bench, _| {
                bench.iter(|| {
                    let inputs: &[&[u8]] = &[&input];
                    let outputs: &mut [&mut [u8]] = &mut [&mut out];
                    backend
                        .execute_plan(black_box(&chain5_plan), black_box(inputs), outputs)
                        .unwrap();
                })
            },
        );
    }

    group.finish();
}

// ============================================================================
// 7. MatMul Packed vs Unpacked (TASK-306 comparison)
// ============================================================================

/// Direct comparison of packed vs unpacked SIMD matmul at transformer sizes.
fn bench_matmul_packed(c: &mut Criterion) {
    use hologram_backend::backends::cpu::{matmul_parallel, matmul_tiled, matmul_tiled_packed};

    let mut group = c.benchmark_group("matmul_packed");

    for (m, k, n) in [
        (32, 768, 768),  // Standard transformer hidden dim
        (1, 768, 3072),  // Single-token FFN expansion
        (32, 3072, 768), // Multi-token FFN contraction
        (128, 768, 768), // Larger batch
    ] {
        let flops = 2 * m * n * k;
        group.throughput(Throughput::Elements(flops as u64));

        let a: Vec<f32> = (0..m * k).map(|i| (i % 100) as f32 / 100.0).collect();
        let b: Vec<f32> = (0..k * n).map(|i| (i % 100) as f32 / 100.0).collect();
        let mut c_buf = vec![0.0f32; m * n];

        group.bench_with_input(
            BenchmarkId::new("unpacked", format!("{m}x{k}x{n}")),
            &(),
            |bench, _| {
                bench.iter(|| {
                    matmul_tiled(black_box(&a), black_box(&b), black_box(&mut c_buf), m, k, n);
                })
            },
        );

        group.bench_with_input(
            BenchmarkId::new("packed", format!("{m}x{k}x{n}")),
            &(),
            |bench, _| {
                bench.iter(|| {
                    matmul_tiled_packed(
                        black_box(&a),
                        black_box(&b),
                        black_box(&mut c_buf),
                        m,
                        k,
                        n,
                    );
                })
            },
        );

        group.bench_with_input(
            BenchmarkId::new("parallel", format!("{m}x{k}x{n}")),
            &(),
            |bench, _| {
                bench.iter(|| {
                    matmul_parallel(black_box(&a), black_box(&b), black_box(&mut c_buf), m, k, n);
                })
            },
        );
    }

    group.finish();
}

// ============================================================================
// BLAS Override Comparison (feature-gated)
// ============================================================================

#[cfg(any(feature = "accelerate", feature = "openblas"))]
fn bench_blas_matmul(c: &mut Criterion) {
    use hologram_backend::backends::cpu::{blas::BlasOverride, matmul_parallel};
    use hologram_backend::KernelOverride;

    let mut group = c.benchmark_group("blas_matmul");

    let provider = BlasOverride;

    for (m, k, n) in [
        (1, 768, 768),    // Single-token inference
        (8, 768, 768),    // Small batch
        (32, 768, 768),   // Standard batch
        (1, 768, 3072),   // Single-token FFN expansion
        (32, 3072, 768),  // Multi-token FFN contraction
        (128, 768, 768),  // Large batch
        (256, 768, 768),  // Very large batch
        (512, 768, 3072), // Large FFN expansion
    ] {
        let flops = 2 * m * n * k;
        group.throughput(Throughput::Elements(flops as u64));

        let a: Vec<f32> = (0..m * k).map(|i| (i % 100) as f32 / 100.0).collect();
        let b: Vec<f32> = (0..k * n).map(|i| (i % 100) as f32 / 100.0).collect();
        let mut c_buf = vec![0.0f32; m * n];

        group.bench_with_input(
            BenchmarkId::new("parallel", format!("{m}x{k}x{n}")),
            &(),
            |bench, _| {
                bench.iter(|| {
                    matmul_parallel(black_box(&a), black_box(&b), black_box(&mut c_buf), m, k, n);
                })
            },
        );

        group.bench_with_input(
            BenchmarkId::new("openblas", format!("{m}x{k}x{n}")),
            &(),
            |bench, _| {
                bench.iter(|| {
                    provider.matmul(black_box(&a), black_box(&b), black_box(&mut c_buf), m, k, n);
                })
            },
        );
    }

    group.finish();
}

#[cfg(any(feature = "accelerate", feature = "openblas"))]
criterion_group!(
    benches,
    bench_buffer_allocation,
    bench_lazy_zeroing,
    bench_plan_clone,
    bench_small_plan_e2e,
    bench_activation_chain,
    bench_matmul_baseline,
    bench_lut_fusion,
    bench_matmul_packed,
    bench_blas_matmul,
);

#[cfg(not(any(feature = "accelerate", feature = "openblas")))]
criterion_group!(
    benches,
    bench_buffer_allocation,
    bench_lazy_zeroing,
    bench_plan_clone,
    bench_small_plan_e2e,
    bench_activation_chain,
    bench_matmul_baseline,
    bench_lut_fusion,
    bench_matmul_packed,
);
criterion_main!(benches);
