//! Hologram CLI entry point.

use clap::Parser;
use hologram_cli::{error::print_error, run, Cli};

#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;

fn main() {
    let cli = Cli::parse();

    if let Err(e) = run(cli) {
        print_error(&e);
        std::process::exit(1);
    }
}
