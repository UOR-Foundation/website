# Sprint Tracker

## Current Sprint — Sprint 42: FFI & Architecture Alignment

**Goal:** **MAXIMUM PERFORMANCE**. Implement "fastest on Earth" SHA-256 mining kernel (SHA-NI/AVX-512), design native AI kernel interface for ONNX/GGUF support, and evaluate FFI strategies.

**Where code lives:** `crates/sha256/`, `crates/uor/src/`, `crates/ffi/`, `specs/plans/`.

### In Progress

- **TASK-389**: **Remove Z_96 Hard Stop Migration** — Eliminate `%96`/`Res96`/ring96 operations across `uor`, compiler, backends, FFI, query, and docs; make 4-type frame model canonical.
- **TASK-386**: **FFI Strategy Evaluation** — Evaluate UniFFI vs ctypes-over-C for Python bindings. Create decision record.
- **TASK-387**: **Architecture: Native AI Kernels** — Design architecture for loading external native kernels (ONNX/GGUF/GGML) to support any AI model. Document integration points.
- **TASK-388**: **SHA-256 "Fastest on Earth"** — Implement hardware-accelerated SHA-256 (SHA-NI, AVX-512) in `crates/sha256`. Benchmark against OpenSSL and `sha2` crate. Target: Bitcoin mining dominance.

### Backlog

(none)

### Completed This Sprint

(none)

---

## Backlog

See [BACKLOG.md](BACKLOG.md) for detailed backlog items.

---

## Sprint History

| Sprint | Focus                              | Tasks | Archive                                                 |
| ------ | ---------------------------------- | ----- | ------------------------------------------------------- |
| 41     | Multi-Modal Q0 Prototype           | 6     | `specs/sprints/41-multimodal-q0-prototype.md`           |
| 40     | Type Space Geometry                | 6     | `specs/sprints/40-type-space-geometry.md`               |
| 39     | Performance & Pipeline Integration | 6     | `specs/sprints/39-performance-pipeline-integration.md`  |
| 38     | Observable Embedding & Certs       | 7     | `specs/sprints/38-observable-embedding-certificates.md` |
| 37     | UOR Frame & Q0 Partition           | 9     | `specs/sprints/37-uor-frame.md`                         |
| 36     | hologram-bitcoin Kernel            | 5     | `specs/sprints/36-hologram-bitcoin-kernel.md`           |
| 35     | Shell Codegen Hardening            | 7     | `specs/sprints/35-shell-codegen-hardening.md`           |
| 34     | SHA-256 Mining Performance         | 8     | `specs/docs/sha256-mining-final-comparison.md`          |
| 33     | Runtime Performance Phase 2        | 9     | `specs/sprints/33-runtime-performance-phase2.md`        |
| 32     | UniFFI Bindings & Observable       | 10    | `specs/sprints/32-uniffi-bindings-observable-shell.md`  |
| 31     | MatMul BLIS Packing                | 5     | —                                                       |
| 30     | Shell Phase 6: Pipelines           | 6     | `specs/sprints/30-shell-phase6-pipelines.md`            |
| 29     | Shell Phase 5: Query Engine        | 7     | `specs/sprints/29-shell-phase5-query-engine.md`         |
| 28     | Runtime Performance Quick Wins     | 7     | `specs/sprints/28-runtime-performance-quick-wins.md`    |
| 27     | Dependency Audit & FFI Features    | 12    | `specs/sprints/27-dependency-audit-ffi-features.md`     |
| 26     | Codebase Cleanup                   | 10    | `specs/sprints/26-codebase-cleanup.md`                  |
| 25     | SHA-256 & Resolver                 | 7     | `specs/sprints/25-sha256-resolver.md`                   |
| 24     | Tokenization Support               | 8     | `specs/sprints/24-tokenization-support.md`              |
| 23     | Codec & UOR Framework              | 16    | `specs/sprints/23-codec-uor-framework.md`               |
| 22     | Integration & Tooling              | 6     | —                                                       |
| 21     | Validation & Quality               | 9     | `specs/sprints/21-validation-quality.md`                |
| 20     | Transformer Operations             | 8     | —                                                       |
| 19     | UOR FFI Exports                    | 2     | `specs/sprints/19-uor-ffi-exports.md`                   |
| 18     | Distributed Execution              | 5     | `specs/sprints/18-integration-distributed.md`           |
| 17     | Network Infrastructure             | 9     | `specs/sprints/17-network-infrastructure.md`            |
| 16     | Production Hardening               | 11    | —                                                       |
| 15     | Microcode Integration              | 6     | `specs/sprints/15-microcode-integration-performance.md` |
| 14     | Polish and Hardening               | 8     | `specs/sprints/14-polish-and-hardening.md`              |
| 13     | Performance Phase 2                | 2     | `specs/sprints/13-performance-optimization-phase2.md`   |
| 12     | SIMD Optimization                  | 15    | `specs/sprints/12-simd-optimization.md`                 |
| 11     | uor::arch Executors                | 13    | `specs/sprints/11-arch-executors.md`                    |
| 10     | Bundle/Archive                     | 3     | `specs/sprints/10-bundle-archive-completion.md`         |
| 9      | Backend Unification                | 12    | `specs/sprints/9-backend-unification.md`                |
| 8      | Microcode Foundation               | 17    | `specs/sprints/8-microcode-production-hardening.md`     |
| 7      | E2E Integration & CLI              | 26    | `specs/sprints/7-end-to-end-integration-cli.md`         |
| 6      | GPU/WASM Backends                  | 14    | `specs/sprints/6-categorical-gpu-wasm.md`               |
| 5      | Backend Execution                  | 20    | `specs/sprints/5-backend-execution.md`                  |
| 4      | Compiler                           | 19    | `specs/sprints/4-compiler.md`                           |
| 3      | Public API                         | 12    | `specs/sprints/3-public-api.md`                         |
| 2      | Architecture                       | 4     | —                                                       |
| 1      | Clean Workspace                    | 4     | —                                                       |

**Total**: 379 tasks completed across 42 sprints.
