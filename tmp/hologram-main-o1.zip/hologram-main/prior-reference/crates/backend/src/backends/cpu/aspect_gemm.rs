//! Aspect-ratio-aware GEMM optimization.
//!
//! Different matrix shapes benefit from different tiling and access patterns.
//! This module provides optimized GEMM variants based on the aspect ratio of
//! the operand matrices.
//!
//! # Aspect Ratio Categories
//!
//! - **Balanced**: M ≈ N ≈ K - Use standard tiled GEMM
//! - **TallThin**: M >> N - Many rows, few columns (column-major friendly)
//! - **WideShort**: N >> M - Few rows, many columns (row-major friendly)
//! - **SkinnyK**: K << M, N - Small reduction dimension (process K in single pass)
//! - **SmallBatched**: Small M, N, K with many batches (fuse across batch)
//!
//! # Tiling Strategy
//!
//! Each aspect hint suggests a different tile configuration:
//!
//! | Hint | MC | KC | NC | Strategy |
//! |------|----|----|----|----|
//! | Balanced | 512 | 384 | 2048 | Standard cache-blocking |
//! | TallThin | 1024 | 256 | 512 | Tall MC, narrow NC |
//! | WideShort | 256 | 384 | 4096 | Short MC, wide NC |
//! | SkinnyK | 512 | K | 2048 | Full K in single pass |
//! | SmallBatched | 64 | 64 | 64 | Minimal tiles, batch fusion |

use crate::{AspectAwareMatMulParams, BackendError, GemmAspectHint, MatMulParams};

use super::simd_dispatch::TileConfig;

/// Perform aspect-aware matrix multiplication.
///
/// This is the main entry point for optimized GEMM based on matrix shape.
pub fn aspect_aware_matmul_f32(
    c: &mut [f32],
    a: &[f32],
    b: &[f32],
    params: &AspectAwareMatMulParams,
) -> Result<(), BackendError> {
    let m = params.base.m as usize;
    let k = params.base.k as usize;
    let n = params.base.n as usize;
    let alpha = params.base.alpha as f32;
    let beta = params.base.beta as f32;

    // Validate buffer sizes
    if a.len() < m * k {
        return Err(BackendError::buffer("A buffer too small"));
    }
    if b.len() < k * n {
        return Err(BackendError::buffer("B buffer too small"));
    }
    if c.len() < m * n {
        return Err(BackendError::buffer("C buffer too small"));
    }

    // Get optimal tile configuration for this aspect
    let config = tile_config_for_aspect(params.aspect_hint, m, k, n);

    // Handle batched case
    if let (GemmAspectHint::SmallBatched, Some(batch)) = (params.aspect_hint, params.batch_count) {
        return batched_gemm_f32(c, a, b, m, k, n, batch as usize, alpha, beta, &config);
    }

    // Single matrix multiplication with aspect-aware tiling
    tiled_gemm_f32(c, a, b, m, k, n, alpha, beta, &config)
}

/// Get optimal tile configuration for the given aspect ratio.
pub fn tile_config_for_aspect(hint: GemmAspectHint, m: usize, k: usize, n: usize) -> TileConfig {
    match hint {
        GemmAspectHint::Balanced => TileConfig {
            mr: 8,
            nr: 8,
            mc: 512.min(m),
            kc: 384.min(k),
            nc: 2048.min(n),
        },
        GemmAspectHint::TallThin => TileConfig {
            mr: 8,
            nr: 4, // Narrower micro-tile for N
            mc: 1024.min(m),
            kc: 256.min(k),
            nc: 512.min(n), // Smaller NC for tall matrices
        },
        GemmAspectHint::WideShort => TileConfig {
            mr: 4, // Smaller micro-tile for M
            nr: 8,
            mc: 256.min(m), // Smaller MC for wide matrices
            kc: 384.min(k),
            nc: 4096.min(n), // Larger NC
        },
        GemmAspectHint::SkinnyK => TileConfig {
            mr: 8,
            nr: 8,
            mc: 512.min(m),
            kc: k.max(1), // Process all of K in one pass
            nc: 2048.min(n),
        },
        GemmAspectHint::SmallBatched => TileConfig {
            mr: 4,
            nr: 4,
            mc: 64.min(m), // Small tiles for batch fusion
            kc: 64.min(k),
            nc: 64.min(n),
        },
    }
}

/// Tiled GEMM with configurable tile sizes.
#[allow(clippy::too_many_arguments)]
fn tiled_gemm_f32(
    c: &mut [f32],
    a: &[f32],
    b: &[f32],
    m: usize,
    k: usize,
    n: usize,
    alpha: f32,
    beta: f32,
    config: &TileConfig,
) -> Result<(), BackendError> {
    // Apply beta scaling to C if needed
    if beta != 1.0 {
        for val in c.iter_mut() {
            *val *= beta;
        }
    }

    // Outer loop: tiles over N (columns of B and C)
    for jc in (0..n).step_by(config.nc) {
        let nc = config.nc.min(n - jc);

        // Middle loop: tiles over K (shared dimension)
        for pc in (0..k).step_by(config.kc) {
            let kc = config.kc.min(k - pc);

            // Inner loop: tiles over M (rows of A and C)
            for ic in (0..m).step_by(config.mc) {
                let mc = config.mc.min(m - ic);

                // Micro-kernel: process MC x NC tile
                macro_kernel_f32(c, a, b, m, k, n, ic, jc, pc, mc, nc, kc, alpha, config)?;
            }
        }
    }

    Ok(())
}

/// Macro-kernel: processes an MC×NC tile of C.
#[inline]
#[allow(clippy::too_many_arguments)]
fn macro_kernel_f32(
    c: &mut [f32],
    a: &[f32],
    b: &[f32],
    _m: usize,
    k: usize,
    n: usize,
    ic: usize,
    jc: usize,
    pc: usize,
    mc: usize,
    nc: usize,
    kc: usize,
    alpha: f32,
    config: &TileConfig,
) -> Result<(), BackendError> {
    // Process micro-tiles within the macro-tile
    for ir in (0..mc).step_by(config.mr) {
        let mr = config.mr.min(mc - ir);

        for jr in (0..nc).step_by(config.nr) {
            let nr = config.nr.min(nc - jr);

            // Micro-kernel: MR×NR tile
            micro_kernel_f32(c, a, b, k, n, ic + ir, jc + jr, pc, mr, nr, kc, alpha)?;
        }
    }

    Ok(())
}

/// Micro-kernel: computes an MR×NR tile of C.
#[inline]
#[allow(clippy::too_many_arguments, clippy::needless_range_loop)]
fn micro_kernel_f32(
    c: &mut [f32],
    a: &[f32],
    b: &[f32],
    k: usize,
    n: usize,
    i: usize,
    j: usize,
    pc: usize,
    mr: usize,
    nr: usize,
    kc: usize,
    alpha: f32,
) -> Result<(), BackendError> {
    // Initialize accumulator
    let mut acc = [[0.0f32; 16]; 16]; // Max MR=NR=16

    // Accumulate: acc += A[i:i+mr, pc:pc+kc] @ B[pc:pc+kc, j:j+nr]
    for pp in 0..kc {
        let p = pc + pp;

        for ii in 0..mr {
            let a_val = a[(i + ii) * k + p];

            for jj in 0..nr {
                let b_val = b[p * n + (j + jj)];
                acc[ii][jj] += a_val * b_val;
            }
        }
    }

    // Store: C[i:i+mr, j:j+nr] += alpha * acc
    for ii in 0..mr {
        for jj in 0..nr {
            let c_idx = (i + ii) * n + (j + jj);
            if c_idx < c.len() {
                c[c_idx] += alpha * acc[ii][jj];
            }
        }
    }

    Ok(())
}

/// Batched GEMM: process multiple small matrix multiplications.
#[allow(clippy::too_many_arguments)]
fn batched_gemm_f32(
    c: &mut [f32],
    a: &[f32],
    b: &[f32],
    m: usize,
    k: usize,
    n: usize,
    batch: usize,
    alpha: f32,
    beta: f32,
    config: &TileConfig,
) -> Result<(), BackendError> {
    let a_stride = m * k;
    let b_stride = k * n;
    let c_stride = m * n;

    // Validate batch sizes
    if a.len() < batch * a_stride {
        return Err(BackendError::buffer("A buffer too small for batch"));
    }
    if b.len() < batch * b_stride {
        return Err(BackendError::buffer("B buffer too small for batch"));
    }
    if c.len() < batch * c_stride {
        return Err(BackendError::buffer("C buffer too small for batch"));
    }

    // Process each batch
    for i in 0..batch {
        let a_slice = &a[i * a_stride..(i + 1) * a_stride];
        let b_slice = &b[i * b_stride..(i + 1) * b_stride];
        let c_slice = &mut c[i * c_stride..(i + 1) * c_stride];

        tiled_gemm_f32(c_slice, a_slice, b_slice, m, k, n, alpha, beta, config)?;
    }

    Ok(())
}

/// Auto-detect optimal aspect hint from matrix dimensions.
pub fn detect_aspect(m: usize, k: usize, n: usize) -> GemmAspectHint {
    GemmAspectHint::detect(m as u32, k as u32, n as u32)
}

/// Create aspect-aware params from base params with auto-detection.
pub fn auto_aspect_params(base: MatMulParams) -> AspectAwareMatMulParams {
    let hint = GemmAspectHint::detect(base.m, base.k, base.n);
    AspectAwareMatMulParams::with_hint(base, hint)
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_isa::Type;

    fn make_params(m: u32, k: u32, n: u32, hint: GemmAspectHint) -> AspectAwareMatMulParams {
        AspectAwareMatMulParams {
            base: MatMulParams::new(m, k, n, Type::F32),
            aspect_hint: hint,
            batch_count: None,
        }
    }

    #[test]
    fn test_aspect_matmul_identity() {
        // C = I × B = B
        let params = make_params(3, 3, 3, GemmAspectHint::Balanced);

        let a = [
            1.0, 0.0, 0.0, //
            0.0, 1.0, 0.0, //
            0.0, 0.0, 1.0, //
        ];
        let b = [
            1.0, 2.0, 3.0, //
            4.0, 5.0, 6.0, //
            7.0, 8.0, 9.0, //
        ];
        let mut c = [0.0f32; 9];

        aspect_aware_matmul_f32(&mut c, &a, &b, &params).unwrap();

        for (c_val, b_val) in c.iter().zip(b.iter()) {
            assert!((c_val - b_val).abs() < 1e-5);
        }
    }

    #[test]
    fn test_aspect_matmul_tall_thin() {
        // Tall-thin: M >> N
        let params = make_params(16, 4, 2, GemmAspectHint::TallThin);

        let a = vec![1.0f32; 64]; // 16×4
        let b = vec![1.0f32; 8]; // 4×2
        let mut c = vec![0.0f32; 32]; // 16×2

        aspect_aware_matmul_f32(&mut c, &a, &b, &params).unwrap();

        // Each element: sum of 4 ones = 4
        for val in &c {
            assert!((val - 4.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_aspect_matmul_wide_short() {
        // Wide-short: N >> M
        let params = make_params(2, 4, 16, GemmAspectHint::WideShort);

        let a = vec![1.0f32; 8]; // 2×4
        let b = vec![1.0f32; 64]; // 4×16
        let mut c = vec![0.0f32; 32]; // 2×16

        aspect_aware_matmul_f32(&mut c, &a, &b, &params).unwrap();

        for val in &c {
            assert!((val - 4.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_aspect_matmul_skinny_k() {
        // Skinny K: K << M, N
        let params = make_params(16, 2, 16, GemmAspectHint::SkinnyK);

        let a = vec![1.0f32; 32]; // 16×2
        let b = vec![1.0f32; 32]; // 2×16
        let mut c = vec![0.0f32; 256]; // 16×16

        aspect_aware_matmul_f32(&mut c, &a, &b, &params).unwrap();

        for val in &c {
            assert!((val - 2.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_aspect_matmul_batched() {
        // Small batched: 4 batches of 4×4 matrices
        let mut params = make_params(4, 4, 4, GemmAspectHint::SmallBatched);
        params.batch_count = Some(4);

        let a = vec![1.0f32; 64]; // 4 × (4×4)
        let b = vec![1.0f32; 64];
        let mut c = vec![0.0f32; 64];

        aspect_aware_matmul_f32(&mut c, &a, &b, &params).unwrap();

        for val in &c {
            assert!((val - 4.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_aspect_matmul_with_scaling() {
        let mut params = make_params(2, 2, 2, GemmAspectHint::Balanced);
        params.base.alpha = 2.0;
        params.base.beta = 0.5;

        let a = vec![1.0f32; 4];
        let b = vec![1.0f32; 4];
        let mut c = vec![10.0f32; 4]; // Pre-filled with 10

        aspect_aware_matmul_f32(&mut c, &a, &b, &params).unwrap();

        // C = 0.5 * 10 + 2.0 * (1+1) = 5 + 4 = 9
        for val in &c {
            assert!((val - 9.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_tile_config_selection() {
        let balanced = tile_config_for_aspect(GemmAspectHint::Balanced, 1000, 1000, 1000);
        assert_eq!(balanced.mr, 8);
        assert_eq!(balanced.mc, 512);

        let tall = tile_config_for_aspect(GemmAspectHint::TallThin, 1000, 100, 10);
        assert_eq!(tall.nr, 4); // Narrower for tall matrices

        let wide = tile_config_for_aspect(GemmAspectHint::WideShort, 10, 100, 1000);
        assert_eq!(wide.mr, 4); // Smaller for wide matrices

        let skinny = tile_config_for_aspect(GemmAspectHint::SkinnyK, 100, 8, 100);
        assert_eq!(skinny.kc, 8); // Full K in one pass

        let small = tile_config_for_aspect(GemmAspectHint::SmallBatched, 16, 16, 16);
        assert_eq!(small.mc, 16); // Capped at matrix size
    }

    #[test]
    fn test_detect_aspect() {
        assert_eq!(detect_aspect(100, 100, 100), GemmAspectHint::Balanced);
        assert_eq!(detect_aspect(1000, 100, 10), GemmAspectHint::TallThin);
        assert_eq!(detect_aspect(10, 100, 1000), GemmAspectHint::WideShort);
        assert_eq!(detect_aspect(100, 8, 100), GemmAspectHint::SkinnyK);
    }

    #[test]
    fn test_auto_aspect_params() {
        let base = MatMulParams::new(1000, 100, 10, Type::F32);
        let auto = auto_aspect_params(base);

        assert_eq!(auto.aspect_hint, GemmAspectHint::TallThin);
    }
}
