//! Integration tests: compile and execute end-to-end (TASK-049).
//!
//! Tests the full pipeline: OperationGraph -> compile() -> execute_plan().

use hologram_backend::backends::cpu::CpuBackend;
use hologram_backend::backends::{Backend, ExecuteOn};
use hologram_compiler::{compile, CompilerConfig, DType, OpKind, OpNode, OperationGraph, PadMode};

/// Helper to convert f32 slice to byte buffer.
fn f32_to_bytes(data: &[f32]) -> Vec<u8> {
    data.iter().flat_map(|f| f.to_ne_bytes()).collect()
}

/// Helper to read f32 values from a byte slice.
fn bytes_to_f32(bytes: &[u8]) -> Vec<f32> {
    bytes
        .chunks_exact(4)
        .map(|chunk| f32::from_ne_bytes(chunk.try_into().unwrap()))
        .collect()
}

// ============================================================================
// Add Operation Tests
// ============================================================================

#[test]
fn test_compile_and_execute_add() {
    // Build graph: output = input_a + input_b
    let mut graph = OperationGraph::new();

    // Two inputs
    let input_a = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let add = OpNode::new(2, OpKind::Add, vec![4], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(add);
    graph.add_node(output);

    // Edges: input_a -> add, input_b -> add, add -> output
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    // Register I/O
    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("result", 3);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();
    let input_a_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
    let input_b_bytes = f32_to_bytes(&[5.0, 6.0, 7.0, 8.0]);
    let inputs: &[&[u8]] = &[&input_a_bytes, &input_b_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    // Verify: [1+5, 2+6, 3+7, 4+8] = [6, 8, 10, 12]
    let result = bytes_to_f32(&output_bytes);
    let expected = [6.0, 8.0, 10.0, 12.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

// ============================================================================
// Activation Function Tests
// ============================================================================

#[test]
fn test_compile_and_execute_relu() {
    // Build graph: output = relu(input)
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let relu = OpNode::new(1, OpKind::Relu, vec![4], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input);
    graph.add_node(relu);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();
    let input_bytes = f32_to_bytes(&[1.0, -2.0, 3.0, -4.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    // Verify: relu([1, -2, 3, -4]) = [1, 0, 3, 0]
    let result = bytes_to_f32(&output_bytes);
    let expected = [1.0, 0.0, 3.0, 0.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_sigmoid() {
    // Build graph: output = sigmoid(input)
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![2], DType::F32);
    let sigmoid = OpNode::new(1, OpKind::Sigmoid, vec![2], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![2], DType::F32);

    graph.add_node(input);
    graph.add_node(sigmoid);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();
    let input_bytes = f32_to_bytes(&[0.0, 100.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 8];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    // Verify: sigmoid(0) = 0.5, sigmoid(100) ≈ 1.0
    let result = bytes_to_f32(&output_bytes);
    assert!((result[0] - 0.5).abs() < 1e-6);
    assert!((result[1] - 1.0).abs() < 1e-6);
}

// ============================================================================
// Reduction Tests
// ============================================================================

#[test]
fn test_compile_and_execute_sum() {
    // Build graph: output = sum(input)
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let sum = OpNode::new(1, OpKind::Sum, vec![1], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![1], DType::F32);

    graph.add_node(input);
    graph.add_node(sum);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();
    let input_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 4];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    // Verify: sum([1, 2, 3, 4]) = 10
    let result = bytes_to_f32(&output_bytes);
    assert!(
        (result[0] - 10.0).abs() < 1e-6,
        "expected 10.0, got {}",
        result[0]
    );
}

// ============================================================================
// MatMul Tests
// ============================================================================

#[test]
fn test_compile_and_execute_matmul() {
    // Build graph: C = A @ B (2x2)
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![2, 2], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![2, 2], DType::F32);
    let matmul = OpNode::new(
        2,
        OpKind::MatMul { m: 2, k: 2, n: 2 },
        vec![2, 2],
        DType::F32,
    );
    let output = OpNode::new(3, OpKind::Output, vec![2, 2], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(matmul);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("c", 3);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute: A = [[1,2],[3,4]], B = [[5,6],[7,8]]
    // C = [[19,22],[43,50]]
    let backend = CpuBackend::new();
    let a_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
    let b_bytes = f32_to_bytes(&[5.0, 6.0, 7.0, 8.0]);
    let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    let expected = [19.0, 22.0, 43.0, 50.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-5, "expected {e}, got {r}");
    }
}

// ============================================================================
// Chained Operations Tests
// ============================================================================

#[test]
fn test_compile_and_execute_chain_add_relu() {
    // Build graph: output = relu(a + b)
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let add = OpNode::new(2, OpKind::Add, vec![4], DType::F32);
    let relu = OpNode::new(3, OpKind::Relu, vec![4], DType::F32);
    let output = OpNode::new(4, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(add);
    graph.add_node(relu);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph.add_edge(3, 4);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("result", 4);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute: a = [1, -5, 3, -7], b = [2, 3, -5, 6]
    // a + b = [3, -2, -2, -1]
    // relu = [3, 0, 0, 0]
    let backend = CpuBackend::new();
    let a_bytes = f32_to_bytes(&[1.0, -5.0, 3.0, -7.0]);
    let b_bytes = f32_to_bytes(&[2.0, 3.0, -5.0, 6.0]);
    let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    let expected = [3.0, 0.0, 0.0, 0.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

// ============================================================================
// Empty Graph Test
// ============================================================================

#[test]
fn test_compile_and_execute_empty_graph() {
    let graph = OperationGraph::new();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let inputs: &[&[u8]] = &[];
    let outputs: &mut [&mut [u8]] = &mut [];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");
}

// ============================================================================
// Error Handling Tests (TASK-051)
// ============================================================================

#[test]
fn test_error_wrong_input_count() {
    // Build a graph that expects 2 inputs
    let mut graph = OperationGraph::new();
    let input_a = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let add = OpNode::new(2, OpKind::Add, vec![4], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(add);
    graph.add_node(output);
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("result", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute with only 1 input (should fail)
    let backend = CpuBackend::new();
    let input_a_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
    let inputs: &[&[u8]] = &[&input_a_bytes]; // Missing second input
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    let result = backend.execute_plan(&plan, inputs, outputs);
    assert!(result.is_err(), "should fail with wrong input count");

    let err = result.unwrap_err();
    let msg = err.to_string();
    assert!(
        msg.contains("input") || msg.contains("buffer"),
        "error should mention input/buffer issue: {msg}"
    );
}

#[test]
fn test_error_wrong_output_count() {
    // Build a simple graph with 1 output
    let mut graph = OperationGraph::new();
    let input = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let relu = OpNode::new(1, OpKind::Relu, vec![4], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input);
    graph.add_node(relu);
    graph.add_node(output);
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_input("x", 0);
    graph.add_output("y", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute with 2 outputs (should fail)
    let backend = CpuBackend::new();
    let input_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output1 = vec![0u8; 16];
    let mut output2 = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output1, &mut output2]; // Extra output

    let result = backend.execute_plan(&plan, inputs, outputs);
    assert!(result.is_err(), "should fail with wrong output count");

    let err = result.unwrap_err();
    let msg = err.to_string();
    assert!(
        msg.contains("output") || msg.contains("buffer"),
        "error should mention output/buffer issue: {msg}"
    );
}

#[test]
fn test_error_message_is_informative() {
    // Build a graph expecting 2 inputs
    let mut graph = OperationGraph::new();
    let input_a = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let add = OpNode::new(2, OpKind::Add, vec![4], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(add);
    graph.add_node(output);
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("result", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Wrong input count
    let backend = CpuBackend::new();
    let inputs: &[&[u8]] = &[]; // No inputs at all
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    let result = backend.execute_plan(&plan, inputs, outputs);
    let err = result.unwrap_err();
    let msg = err.to_string();

    // Error message should be human-readable
    // It should contain numbers so user knows expected vs actual
    let has_numbers = msg.chars().any(|c| c.is_ascii_digit());
    assert!(has_numbers, "error message should include counts: {msg}");
}

#[test]
fn test_successful_execution_after_error() {
    // Verify we can successfully execute after a failed execution
    let mut graph = OperationGraph::new();
    let input = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let relu = OpNode::new(1, OpKind::Relu, vec![4], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input);
    graph.add_node(relu);
    graph.add_node(output);
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_input("x", 0);
    graph.add_output("y", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");
    let backend = CpuBackend::new();

    // First: fail with wrong inputs
    let inputs: &[&[u8]] = &[];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];
    assert!(backend.execute_plan(&plan, inputs, outputs).is_err());

    // Second: succeed with correct inputs
    let input_bytes = f32_to_bytes(&[1.0, -2.0, 3.0, -4.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("should succeed");

    let result = bytes_to_f32(&output_bytes);
    assert!((result[0] - 1.0).abs() < 1e-6);
    assert!((result[1] - 0.0).abs() < 1e-6);
    assert!((result[2] - 3.0).abs() < 1e-6);
    assert!((result[3] - 0.0).abs() < 1e-6);
}

// ============================================================================
// Categorical Operations Tests (TASK-062)
// ============================================================================

#[test]
fn test_compile_and_execute_lift() {
    // Build graph: output = lift(input)
    // Lift maps bytes to torus coordinates (page, offset)
    // Lift node shape = input count; output is count*2 bytes internally
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![4], DType::U8);
    let lift = OpNode::new(1, OpKind::Lift, vec![4], DType::U8); // Shape is input count
    let output = OpNode::new(2, OpKind::Output, vec![8], DType::U8); // Output buffer: 4*2 = 8 bytes

    graph.add_node(input);
    graph.add_node(lift);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("bytes", 0);
    graph.add_output("coords", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute with test bytes
    let backend = CpuBackend::new();
    let input_bytes: Vec<u8> = vec![0, 1, 96, 255];
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 8];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    // Verify torus coordinates (little-endian u16: offset in lower byte, page in upper byte)
    // byte 0: resonance_class = 0, page = 0/2 = 0, offset = 0
    assert_eq!(output_bytes[0], 0); // offset
    assert_eq!(output_bytes[1], 0); // page

    // byte 1: resonance_class = 1, page = 1/2 = 0, offset = 1
    assert_eq!(output_bytes[2], 1); // offset
    assert_eq!(output_bytes[3], 0); // page

    // byte 96: page = 96 / 8 = 12, offset = 96
    assert_eq!(output_bytes[4], 96); // offset
    assert_eq!(output_bytes[5], 12); // page

    // byte 255: page = 255 / 8 = 31, offset = 255
    assert_eq!(output_bytes[6], 255); // offset
    assert_eq!(output_bytes[7], 31); // page
}

#[test]
fn test_compile_and_execute_orbit_classify() {
    // Build graph: output = orbit_classify(input)
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![8], DType::U8);
    let orbit = OpNode::new(1, OpKind::OrbitClassify, vec![8], DType::U8);
    let output = OpNode::new(2, OpKind::Output, vec![8], DType::U8);

    graph.add_node(input);
    graph.add_node(orbit);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("bytes", 0);
    graph.add_output("classes", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();
    let input_bytes: Vec<u8> = vec![0, 7, 8, 15, 16, 31, 248, 255];
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 8];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    // Verify orbit classes (byte / 8)
    assert_eq!(output_bytes[0], 0); // 0 / 8 = 0
    assert_eq!(output_bytes[1], 0); // 7 / 8 = 0
    assert_eq!(output_bytes[2], 1); // 8 / 8 = 1
    assert_eq!(output_bytes[3], 1); // 15 / 8 = 1
    assert_eq!(output_bytes[4], 2); // 16 / 8 = 2
    assert_eq!(output_bytes[5], 3); // 31 / 8 = 3
    assert_eq!(output_bytes[6], 31); // 248 / 8 = 31
    assert_eq!(output_bytes[7], 31); // 255 / 8 = 31
}

#[test]
fn test_categorical_bijection_property() {
    // Verify Lift preserves bijection: all 256 bytes map to unique torus cells
    // Note: Lift takes N input bytes and produces N*2 output bytes (PackedCell per byte)
    // The node shape is the INPUT count since that's what the instruction's `count` uses
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![256], DType::U8);
    // Lift node shape = input count (the instruction outputs count*2 bytes internally)
    let lift = OpNode::new(1, OpKind::Lift, vec![256], DType::U8);
    // Output buffer needs to hold the actual output: 256*2 = 512 bytes
    let output = OpNode::new(2, OpKind::Output, vec![512], DType::U8);

    graph.add_node(input);
    graph.add_node(lift);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("bytes", 0);
    graph.add_output("coords", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let input_bytes: Vec<u8> = (0..=255).collect();
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 512];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    // Verify all cells are unique
    let mut cells = std::collections::HashSet::new();
    for i in 0..256 {
        let offset = output_bytes[i * 2];
        let page = output_bytes[i * 2 + 1];
        let cell = (page, offset);
        assert!(
            cells.insert(cell),
            "Duplicate cell ({page}, {offset}) at byte {i}"
        );
    }
    assert_eq!(cells.len(), 256, "Should have 256 unique cells");
}

#[test]
fn test_categorical_orbit_partition_property() {
    // Verify OrbitClassify partitions 256 bytes into 32 classes of 8
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![256], DType::U8);
    let orbit = OpNode::new(1, OpKind::OrbitClassify, vec![256], DType::U8);
    let output = OpNode::new(2, OpKind::Output, vec![256], DType::U8);

    graph.add_node(input);
    graph.add_node(orbit);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("bytes", 0);
    graph.add_output("classes", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let input_bytes: Vec<u8> = (0..=255).collect();
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 256];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    // Count members in each class
    let mut class_counts = [0usize; 32];
    for &class in &output_bytes {
        assert!(class < 32, "Orbit class {class} out of range [0, 31]");
        class_counts[class as usize] += 1;
    }

    // Each class should have exactly 8 members
    for (i, &count) in class_counts.iter().enumerate() {
        assert_eq!(count, 8, "Orbit class {i} has {count} members, expected 8");
    }
}

// ============================================================================
// CallLayer Tests (TASK-065)
// ============================================================================

#[test]
fn test_call_layer_basic_execution() {
    use hologram_backend::cpu::{BufferManager, ExecutionContext};
    use hologram_backend::IsaInstruction;
    use hologram_holo::types::{BufferMetadata, BufferType};

    // Create buffers: input -> (CallLayer) -> output
    let metadata = vec![
        BufferMetadata::new(8, BufferType::Input),
        BufferMetadata::new(8, BufferType::Output),
    ];
    let input_data = vec![1u8, 2, 3, 4, 5, 6, 7, 8];
    let inputs: &[&[u8]] = &[&input_data];
    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
    let node_map: Vec<Option<u32>> = vec![Some(0), Some(1)];

    // Layer executor that increments each byte
    let mut executor = |_layer_id: u64, layer_inputs: &[&[u8]], layer_outputs: &mut [&mut [u8]]| {
        if !layer_inputs.is_empty() && !layer_outputs.is_empty() {
            for (out, &inp) in layer_outputs[0].iter_mut().zip(layer_inputs[0].iter()) {
                *out = inp.wrapping_add(10);
            }
        }
        Ok(())
    };

    let mut ctx = ExecutionContext::with_layer_executor(&mut manager, &node_map, &mut executor);

    let instr = IsaInstruction::CallLayer {
        layer_id: 0x1234,
        inputs: vec![0],
        outputs: vec![1],
    };

    instr.execute(&mut ctx).expect("CallLayer failed");

    // Verify output: each byte incremented by 10
    let output = ctx.read_buffer(1).unwrap();
    assert_eq!(&output[..8], &[11, 12, 13, 14, 15, 16, 17, 18]);
}

#[test]
fn test_call_layer_multiple_inputs_outputs() {
    use hologram_backend::cpu::{BufferManager, ExecutionContext};
    use hologram_backend::IsaInstruction;
    use hologram_holo::types::{BufferMetadata, BufferType};

    // Two inputs, two outputs
    let metadata = vec![
        BufferMetadata::new(4, BufferType::Input),
        BufferMetadata::new(4, BufferType::Input),
        BufferMetadata::new(4, BufferType::Output),
        BufferMetadata::new(4, BufferType::Output),
    ];
    let input1 = vec![1u8, 2, 3, 4];
    let input2 = vec![10u8, 20, 30, 40];
    let inputs: &[&[u8]] = &[&input1, &input2];
    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
    let node_map: Vec<Option<u32>> = vec![Some(0), Some(1), Some(2), Some(3)];

    // Layer executor: output0 = input0 + input1, output1 = input0 * input1
    let mut executor = |_layer_id: u64, layer_inputs: &[&[u8]], layer_outputs: &mut [&mut [u8]]| {
        if layer_inputs.len() >= 2 && layer_outputs.len() >= 2 {
            for i in 0..4 {
                layer_outputs[0][i] = layer_inputs[0][i].wrapping_add(layer_inputs[1][i]);
                layer_outputs[1][i] = layer_inputs[0][i].wrapping_mul(layer_inputs[1][i]);
            }
        }
        Ok(())
    };

    let mut ctx = ExecutionContext::with_layer_executor(&mut manager, &node_map, &mut executor);

    let instr = IsaInstruction::CallLayer {
        layer_id: 0xABCD,
        inputs: vec![0, 1],
        outputs: vec![2, 3],
    };

    instr.execute(&mut ctx).expect("CallLayer failed");

    // Verify outputs
    let out0 = ctx.read_buffer(2).unwrap();
    let out1 = ctx.read_buffer(3).unwrap();
    assert_eq!(&out0[..4], &[11, 22, 33, 44]); // 1+10, 2+20, 3+30, 4+40
    assert_eq!(&out1[..4], &[10, 40, 90, 160]); // 1*10, 2*20, 3*30, 4*40
}

#[test]
fn test_call_layer_error_propagation() {
    use hologram_backend::cpu::{BufferManager, ExecutionContext};
    use hologram_backend::{BackendError, IsaInstruction};
    use hologram_holo::types::{BufferMetadata, BufferType};

    let metadata = vec![
        BufferMetadata::new(4, BufferType::Input),
        BufferMetadata::new(4, BufferType::Output),
    ];
    let input_data = vec![1u8, 2, 3, 4];
    let inputs: &[&[u8]] = &[&input_data];
    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
    let node_map: Vec<Option<u32>> = vec![Some(0), Some(1)];

    // Layer executor that always fails
    let mut executor = |_layer_id: u64, _inputs: &[&[u8]], _outputs: &mut [&mut [u8]]| {
        Err(BackendError::LayerLoadError {
            layer_id: "test".into(),
            reason: "simulated failure".into(),
        })
    };

    let mut ctx = ExecutionContext::with_layer_executor(&mut manager, &node_map, &mut executor);

    let instr = IsaInstruction::CallLayer {
        layer_id: 0x9999,
        inputs: vec![0],
        outputs: vec![1],
    };

    let result = instr.execute(&mut ctx);
    assert!(matches!(result, Err(BackendError::LayerLoadError { .. })));
}

#[test]
fn test_call_layer_nested_execution() {
    use hologram_backend::cpu::{BufferManager, ExecutionContext};
    use hologram_backend::IsaInstruction;
    use hologram_holo::types::{BufferMetadata, BufferType};

    // Simulates: input -> Layer1 (adds 5) -> Layer2 (multiplies by 2) -> output
    let metadata = vec![
        BufferMetadata::new(4, BufferType::Input),
        BufferMetadata::new(4, BufferType::Workspace), // intermediate
        BufferMetadata::new(4, BufferType::Output),
    ];
    let input_data = vec![1u8, 2, 3, 4];
    let inputs: &[&[u8]] = &[&input_data];
    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
    let node_map: Vec<Option<u32>> = vec![Some(0), Some(1), Some(2)];

    // Nested executor: layer 1 adds 5, layer 2 multiplies by 2
    let mut call_count = 0u32;
    let mut executor = |layer_id: u64, layer_inputs: &[&[u8]], layer_outputs: &mut [&mut [u8]]| {
        call_count += 1;
        if !layer_inputs.is_empty() && !layer_outputs.is_empty() {
            match layer_id {
                1 => {
                    // Layer 1: add 5
                    for (out, &inp) in layer_outputs[0].iter_mut().zip(layer_inputs[0].iter()) {
                        *out = inp.wrapping_add(5);
                    }
                }
                2 => {
                    // Layer 2: multiply by 2
                    for (out, &inp) in layer_outputs[0].iter_mut().zip(layer_inputs[0].iter()) {
                        *out = inp.wrapping_mul(2);
                    }
                }
                _ => {}
            }
        }
        Ok(())
    };

    let mut ctx = ExecutionContext::with_layer_executor(&mut manager, &node_map, &mut executor);

    // First call: input -> workspace (add 5)
    let instr1 = IsaInstruction::CallLayer {
        layer_id: 1,
        inputs: vec![0],
        outputs: vec![1],
    };
    instr1.execute(&mut ctx).expect("Layer 1 failed");

    // Second call: workspace -> output (multiply by 2)
    let instr2 = IsaInstruction::CallLayer {
        layer_id: 2,
        inputs: vec![1],
        outputs: vec![2],
    };
    instr2.execute(&mut ctx).expect("Layer 2 failed");

    // Verify: (input + 5) * 2
    let output = ctx.read_buffer(2).unwrap();
    assert_eq!(&output[..4], &[12, 14, 16, 18]); // (1+5)*2, (2+5)*2, (3+5)*2, (4+5)*2
    assert_eq!(call_count, 2);
}

#[test]
fn test_no_overhead_without_call_layer() {
    // Verify that plans without CallLayer have zero overhead from layer support
    // by checking that ExecutionContext::new() (without layer executor) works identically

    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let relu = OpNode::new(1, OpKind::Relu, vec![4], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input);
    graph.add_node(relu);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();

    // Negative and positive values
    let input_floats: Vec<f32> = vec![-1.0, 0.0, 1.0, 2.0];
    let input_bytes: Vec<u8> = input_floats.iter().flat_map(|f| f.to_le_bytes()).collect();

    let mut output_bytes = vec![0u8; 16];

    // Execute without any layer executor overhead
    backend
        .execute_plan(&plan, &[&input_bytes], &mut [&mut output_bytes])
        .expect("execution failed");

    // Verify ReLU: max(0, x)
    let output_floats: Vec<f32> = output_bytes
        .chunks(4)
        .map(|c| f32::from_le_bytes(c.try_into().unwrap()))
        .collect();

    assert_eq!(output_floats, vec![0.0, 0.0, 1.0, 2.0]);
}

// ============================================================================
// Codec Integration Tests (TASK-090)
// ============================================================================

#[test]
fn test_codec_encode_decode_binary_roundtrip() {
    // Binary codec (codec_id=0) is an identity transform
    use hologram_backend::cpu::{BufferManager, ExecutionContext};
    use hologram_backend::IsaInstruction;
    use hologram_holo::types::{BufferMetadata, BufferType};

    let metadata = vec![
        BufferMetadata::new(8, BufferType::Input),
        BufferMetadata::new(8, BufferType::Workspace),
        BufferMetadata::new(8, BufferType::Output),
    ];
    let input_data: Vec<u8> = vec![0xDE, 0xAD, 0xBE, 0xEF, 0xCA, 0xFE, 0xBA, 0xBE];
    let inputs: &[&[u8]] = &[&input_data];
    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
    let node_map: Vec<Option<u32>> = vec![Some(0), Some(1), Some(2)];
    let mut ctx = ExecutionContext::new(&mut manager, &node_map);

    // Encode
    let encode = IsaInstruction::Encode {
        dst: 1,
        src: 0,
        codec_id: 0, // binary
        count: 8,
    };
    encode.execute(&mut ctx).expect("Encode failed");

    // For binary codec, encoded == input
    let encoded = ctx.read_buffer(1).unwrap();
    assert_eq!(&encoded[..8], &input_data);

    // Decode
    let decode = IsaInstruction::Decode {
        dst: 2,
        src: 1,
        codec_id: 0,
        count: 8,
    };
    decode.execute(&mut ctx).expect("Decode failed");

    let decoded = ctx.read_buffer(2).unwrap();
    assert_eq!(&decoded[..8], &input_data);
}

#[test]
fn test_codec_encode_decode_all_codecs_roundtrip() {
    // Test roundtrip for all 5 codecs
    use hologram_backend::codec::get_codec;
    use hologram_backend::cpu::{BufferManager, ExecutionContext};
    use hologram_backend::IsaInstruction;
    use hologram_holo::types::{BufferMetadata, BufferType};

    let test_inputs: &[&[u8]] = &[&[1, 2, 3], &[255], &[0xDE, 0xAD, 0xBE, 0xEF]];

    for codec_id in 0..5u32 {
        for &input_data in test_inputs {
            // Get expected encoded length by calling codec directly
            let codec = get_codec(codec_id).expect("codec should exist");
            let expected_encoded = codec.encode(input_data).expect("encode should work");
            let encoded_len = expected_encoded.len();

            let metadata = vec![
                BufferMetadata::new(input_data.len(), BufferType::Input),
                BufferMetadata::new(64, BufferType::Workspace), // large enough for any encoding
                BufferMetadata::new(input_data.len(), BufferType::Output),
            ];
            let inputs: &[&[u8]] = &[input_data];
            let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
            let node_map: Vec<Option<u32>> = vec![Some(0), Some(1), Some(2)];
            let mut ctx = ExecutionContext::new(&mut manager, &node_map);

            // Encode
            let encode = IsaInstruction::Encode {
                dst: 1,
                src: 0,
                codec_id,
                count: input_data.len(),
            };
            encode
                .execute(&mut ctx)
                .unwrap_or_else(|e| panic!("Encode failed for codec {codec_id}: {e}"));

            // Decode
            let decode = IsaInstruction::Decode {
                dst: 2,
                src: 1,
                codec_id,
                count: encoded_len,
            };
            decode
                .execute(&mut ctx)
                .unwrap_or_else(|e| panic!("Decode failed for codec {codec_id}: {e}"));

            let decoded = ctx.read_buffer(2).unwrap();
            assert_eq!(
                &decoded[..input_data.len()],
                input_data,
                "Roundtrip failed for codec {codec_id} with input {:?}",
                input_data
            );
        }
    }
}

#[test]
fn test_codec_encode_invalid_codec_id_error() {
    // Verify that invalid codec IDs return errors
    use hologram_backend::cpu::{BufferManager, ExecutionContext};
    use hologram_backend::{BackendError, IsaInstruction};
    use hologram_holo::types::{BufferMetadata, BufferType};

    let metadata = vec![
        BufferMetadata::new(4, BufferType::Input),
        BufferMetadata::new(16, BufferType::Workspace),
    ];
    let input_data: Vec<u8> = vec![1, 2, 3, 4];
    let inputs: &[&[u8]] = &[&input_data];
    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
    let node_map: Vec<Option<u32>> = vec![Some(0), Some(1)];
    let mut ctx = ExecutionContext::new(&mut manager, &node_map);

    // Try invalid codec IDs
    for invalid_codec_id in [5, 10, 100, 255, u32::MAX] {
        let encode = IsaInstruction::Encode {
            dst: 1,
            src: 0,
            codec_id: invalid_codec_id,
            count: 4,
        };

        let result = encode.execute(&mut ctx);
        assert!(
            result.is_err(),
            "Expected error for codec_id {invalid_codec_id}"
        );
        assert!(
            matches!(result, Err(BackendError::UnsupportedInstruction(_))),
            "Expected UnsupportedInstruction error for codec_id {invalid_codec_id}"
        );
    }
}

#[test]
fn test_codec_decode_invalid_codec_id_error() {
    // Verify that invalid codec IDs return errors on decode
    use hologram_backend::cpu::{BufferManager, ExecutionContext};
    use hologram_backend::{BackendError, IsaInstruction};
    use hologram_holo::types::{BufferMetadata, BufferType};

    let metadata = vec![
        BufferMetadata::new(4, BufferType::Input),
        BufferMetadata::new(16, BufferType::Workspace),
    ];
    let input_data: Vec<u8> = vec![1, 2, 3, 4];
    let inputs: &[&[u8]] = &[&input_data];
    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
    let node_map: Vec<Option<u32>> = vec![Some(0), Some(1)];
    let mut ctx = ExecutionContext::new(&mut manager, &node_map);

    let decode = IsaInstruction::Decode {
        dst: 1,
        src: 0,
        codec_id: 999, // Invalid
        count: 4,
    };

    let result = decode.execute(&mut ctx);
    assert!(result.is_err());
    assert!(matches!(
        result,
        Err(BackendError::UnsupportedInstruction(_))
    ));
}

#[test]
fn test_codec_encode_insufficient_buffer_error() {
    // Verify error when source buffer is too small for count
    use hologram_backend::cpu::{BufferManager, ExecutionContext};
    use hologram_backend::{BackendError, IsaInstruction};
    use hologram_holo::types::{BufferMetadata, BufferType};

    let metadata = vec![
        BufferMetadata::new(4, BufferType::Input),
        BufferMetadata::new(16, BufferType::Workspace),
    ];
    let input_data: Vec<u8> = vec![1, 2, 3, 4];
    let inputs: &[&[u8]] = &[&input_data];
    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
    let node_map: Vec<Option<u32>> = vec![Some(0), Some(1)];
    let mut ctx = ExecutionContext::new(&mut manager, &node_map);

    let encode = IsaInstruction::Encode {
        dst: 1,
        src: 0,
        codec_id: 1, // decimal
        count: 100,  // More than buffer has (4 bytes)
    };

    let result = encode.execute(&mut ctx);
    assert!(result.is_err());
    assert!(
        matches!(result, Err(BackendError::SizeMismatch { .. })),
        "Expected SizeMismatch error"
    );
}

#[test]
fn test_codec_encode_single_byte() {
    // Test encoding a single byte through all codecs
    use hologram_backend::codec::get_codec;
    use hologram_backend::cpu::{BufferManager, ExecutionContext};
    use hologram_backend::IsaInstruction;
    use hologram_holo::types::{BufferMetadata, BufferType};

    for codec_id in 0..5u32 {
        let input_data: Vec<u8> = vec![42];

        let codec = get_codec(codec_id).unwrap();
        let expected_encoded = codec.encode(&input_data).unwrap();
        let encoded_len = expected_encoded.len();

        let metadata = vec![
            BufferMetadata::new(1, BufferType::Input),
            BufferMetadata::new(16, BufferType::Workspace),
            BufferMetadata::new(1, BufferType::Output),
        ];
        let inputs: &[&[u8]] = &[&input_data];
        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map: Vec<Option<u32>> = vec![Some(0), Some(1), Some(2)];
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        // Encode
        let encode = IsaInstruction::Encode {
            dst: 1,
            src: 0,
            codec_id,
            count: 1,
        };
        encode
            .execute(&mut ctx)
            .unwrap_or_else(|e| panic!("Encode failed for codec {codec_id}: {e}"));

        // Decode
        let decode = IsaInstruction::Decode {
            dst: 2,
            src: 1,
            codec_id,
            count: encoded_len,
        };
        decode
            .execute(&mut ctx)
            .unwrap_or_else(|e| panic!("Decode failed for codec {codec_id}: {e}"));

        let decoded = ctx.read_buffer(2).unwrap();
        assert_eq!(
            decoded[0], 42,
            "Single byte roundtrip failed for codec {codec_id}"
        );
    }
}

#[test]
fn test_codec_decimal_specific_values() {
    // Test decimal codec with known values
    use hologram_backend::codec::get_codec;
    use hologram_backend::cpu::{BufferManager, ExecutionContext};
    use hologram_backend::IsaInstruction;
    use hologram_holo::types::{BufferMetadata, BufferType};

    // 255 as a single byte encodes to decimal representation
    let input_data: Vec<u8> = vec![255];

    let codec = get_codec(1).unwrap(); // decimal
    let expected_encoded = codec.encode(&input_data).unwrap();
    let encoded_len = expected_encoded.len();

    let metadata = vec![
        BufferMetadata::new(1, BufferType::Input),
        BufferMetadata::new(16, BufferType::Workspace),
        BufferMetadata::new(1, BufferType::Output),
    ];
    let inputs: &[&[u8]] = &[&input_data];
    let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
    let node_map: Vec<Option<u32>> = vec![Some(0), Some(1), Some(2)];
    let mut ctx = ExecutionContext::new(&mut manager, &node_map);

    // Encode
    let encode = IsaInstruction::Encode {
        dst: 1,
        src: 0,
        codec_id: 1,
        count: 1,
    };
    encode.execute(&mut ctx).expect("Encode failed");

    // Verify encoded value matches expected
    let encoded = ctx.read_buffer(1).unwrap();
    assert_eq!(
        &encoded[..encoded_len],
        &expected_encoded,
        "Decimal encoding mismatch"
    );

    // Decode
    let decode = IsaInstruction::Decode {
        dst: 2,
        src: 1,
        codec_id: 1,
        count: encoded_len,
    };
    decode.execute(&mut ctx).expect("Decode failed");

    let decoded = ctx.read_buffer(2).unwrap();
    assert_eq!(decoded[0], 255, "Decimal roundtrip failed for value 255");
}

// ============================================================================
// Backend Unification Integration Tests (TASK-127)
// ============================================================================

#[test]
fn test_auto_select_execute_add() {
    use hologram_backend::microcode::BackendImpl;
    use uor::microcode::MicrocodeOps;

    // Test complete flow: auto_select() -> execute primitive -> verify
    let backend = BackendImpl::auto_select();

    // Verify auto-selection produces a valid backend
    assert!(!backend.name().is_empty());

    // Execute add operation
    let result = backend.add(10u32, 20u32);
    assert_eq!(result, 30);

    // Execute with edge cases
    assert_eq!(backend.add(u32::MAX, 1u32), 0); // Overflow wraps
    assert_eq!(backend.add(0u32, 0u32), 0);
}

#[test]
fn test_generated_backend_full_flow() {
    use hologram_backend::microcode::generated::GeneratedBackend;
    use uor::microcode::MicrocodeOps;

    // Test: GeneratedBackend -> to_backend_impl() -> execute -> verify
    let generated = GeneratedBackend::auto_select();
    let backend = generated.to_backend_impl();

    // Verify backend is functional
    assert!(!backend.name().is_empty());

    // Execute derived operations
    let sum = backend.add(100u32, 50u32);
    assert_eq!(sum, 150);

    let diff = backend.sub(100u32, 30u32);
    assert_eq!(diff, 70);

    let inc = backend.inc(41u32);
    assert_eq!(inc, 42);

    let dec = backend.dec(42u32);
    assert_eq!(dec, 41);
}

#[test]
fn test_cached_target_execution_flow() {
    use hologram_backend::target::cached_target;
    use uor::microcode::MicrocodeOps;

    // Test: cached_target() -> execute -> verify
    let target = cached_target();

    // Verify cached target is valid
    assert!(!target.name().is_empty());
    assert!(target.capabilities().vector_bits >= 32);

    // Execute via target (scalar path)
    if let Some(scalar) = target.as_scalar() {
        let sum = scalar.add(15u32, 27u32);
        assert_eq!(sum, 42);

        let product = scalar.add(scalar.add(6u32, 6u32), scalar.add(6u32, 12u32));
        assert_eq!(product, 30);
    }
}

#[test]
fn test_target_primitives_flow() {
    use hologram_backend::target::{ScalarTarget, Simd128Target, Simd256Target};
    use uor::microcode::{MicrocodeOps, MicrocodePrimitives};

    // Test complete flow through each target type

    // Scalar target
    let scalar = ScalarTarget::new();
    assert_eq!(scalar.xor(0xFFu32, 0xF0u32), 0x0Fu32);
    assert_eq!(scalar.and(0xFFu32, 0xF0u32), 0xF0u32);
    assert_eq!(scalar.or(0x0Fu32, 0xF0u32), 0xFFu32);
    assert_eq!(scalar.add(10u32, 20u32), 30u32);

    // SIMD-128 target
    let simd128 = Simd128Target::new();
    let a4: [u32; 4] = [10, 20, 30, 40];
    let b4: [u32; 4] = [1, 2, 3, 4];
    let sum4 = simd128.add(a4, b4);
    assert_eq!(sum4, [11, 22, 33, 44]);

    // SIMD-256 target
    let simd256 = Simd256Target::new();
    let a8: [u32; 8] = [10, 20, 30, 40, 50, 60, 70, 80];
    let b8: [u32; 8] = [1, 2, 3, 4, 5, 6, 7, 8];
    let sum8 = simd256.add(a8, b8);
    assert_eq!(sum8, [11, 22, 33, 44, 55, 66, 77, 88]);
}

#[test]
fn test_compile_execute_with_backend_selection() {
    // Test full pipeline: graph -> compile -> BackendPlan -> execute

    let mut graph = OperationGraph::new();
    let input = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let relu = OpNode::new(1, OpKind::Relu, vec![4], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input);
    graph.add_node(relu);
    graph.add_node(output);
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_input("x", 0);
    graph.add_output("y", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compile failed");

    // Execute with CpuBackend (which uses auto-selected microcode internally)
    let backend = CpuBackend::new();
    let input_bytes = f32_to_bytes(&[-1.0, 0.0, 1.0, 2.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    assert!((result[0] - 0.0).abs() < 1e-6); // ReLU(-1.0) = 0.0
    assert!((result[1] - 0.0).abs() < 1e-6); // ReLU(0.0) = 0.0
    assert!((result[2] - 1.0).abs() < 1e-6); // ReLU(1.0) = 1.0
    assert!((result[3] - 2.0).abs() < 1e-6); // ReLU(2.0) = 2.0
}

#[test]
fn test_backend_selection_consistency() {
    use hologram_backend::microcode::generated::GeneratedBackend;
    use hologram_backend::microcode::BackendImpl;
    use hologram_backend::target::{auto_select_target, cached_target};
    use uor::microcode::MicrocodeOps;

    // Verify all selection mechanisms produce consistent results
    let backend_impl = BackendImpl::auto_select();
    let generated = GeneratedBackend::auto_select().to_backend_impl();
    let _auto_target = auto_select_target();
    let _cached = cached_target();

    // All should compute the same result
    let a: u32 = 0xDEAD_BEEF;
    let b: u32 = 0xCAFE_BABE;

    let result_impl = backend_impl.add(a, b);
    let result_generated = generated.add(a, b);
    let expected = a.wrapping_add(b);

    assert_eq!(result_impl, expected);
    assert_eq!(result_generated, expected);
    assert_eq!(result_impl, result_generated);
}

// ============================================================================
// CNN Operations Integration Tests
// ============================================================================

#[test]
fn test_compile_and_execute_conv2d() {
    // Build graph: Input -> Conv2d(with constant weights) -> Output
    // Input: [1, 1, 4, 4] (batch=1, channels=1, height=4, width=4)
    // Weight: [1, 1, 3, 3] (out_channels=1, in_channels=1, kernel=3x3)
    // Output: [1, 1, 2, 2] (no padding, stride=1)

    let mut graph = OperationGraph::new();

    // Node 0: Input [1, 1, 4, 4]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 1, 4, 4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Constant weights [1, 1, 3, 3] - all 1.0
    graph.add_node(OpNode::new(
        1,
        OpKind::Constant,
        vec![1, 1, 3, 3],
        DType::F32,
    ));
    graph.add_constant_for_node(1, hologram_compiler::ConstantData::F32(vec![1.0; 9]));

    // Node 2: Conv2d output [1, 1, 2, 2]
    graph.add_node(OpNode::new(
        2,
        OpKind::Conv2d {
            kernel: (3, 3),
            stride: (1, 1),
            padding: (0, 0),
            dilation: (1, 1),
            groups: 1,
        },
        vec![1, 1, 2, 2],
        DType::F32,
    ));
    graph.add_edge(0, 2); // input -> conv
    graph.add_edge(1, 2); // weight -> conv

    // Node 3: Output
    graph.add_node(OpNode::new(3, OpKind::Output, vec![1, 1, 2, 2], DType::F32));
    graph.add_edge(2, 3);
    graph.add_output("output", 3);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: values 1..16
    let input_data: Vec<f32> = (1..=16).map(|i| i as f32).collect();
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16]; // 4 f32 = 16 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Input layout (4x4):
    //  1  2  3  4
    //  5  6  7  8
    //  9 10 11 12
    // 13 14 15 16
    //
    // With all-ones 3x3 kernel:
    // output[0,0] = sum of 3x3 at (0,0) = 1+2+3+5+6+7+9+10+11 = 54
    // output[0,1] = sum of 3x3 at (0,1) = 2+3+4+6+7+8+10+11+12 = 63
    // output[1,0] = sum of 3x3 at (1,0) = 5+6+7+9+10+11+13+14+15 = 90
    // output[1,1] = sum of 3x3 at (1,1) = 6+7+8+10+11+12+14+15+16 = 99

    let expected = [54.0, 63.0, 90.0, 99.0];
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        assert!((r - e).abs() < 1e-5, "output[{i}] expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_batch_norm() {
    // Build graph: Input -> BatchNorm -> Output
    // BatchNorm with scale=2, bias=1, mean=0, var=1 should produce: output = input * 2 + 1

    let mut graph = OperationGraph::new();

    // Node 0: Input [1, 2, 2, 2] (batch=1, channels=2, spatial=2x2)
    graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 2, 2, 2], DType::F32));
    graph.add_input("input", 0);

    // Node 1: scale [2] = [2.0, 2.0]
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![2], DType::F32));
    graph.add_constant_for_node(1, hologram_compiler::ConstantData::F32(vec![2.0, 2.0]));

    // Node 2: bias [2] = [1.0, 1.0]
    graph.add_node(OpNode::new(2, OpKind::Constant, vec![2], DType::F32));
    graph.add_constant_for_node(2, hologram_compiler::ConstantData::F32(vec![1.0, 1.0]));

    // Node 3: mean [2] = [0.0, 0.0]
    graph.add_node(OpNode::new(3, OpKind::Constant, vec![2], DType::F32));
    graph.add_constant_for_node(3, hologram_compiler::ConstantData::F32(vec![0.0, 0.0]));

    // Node 4: var [2] = [1.0, 1.0]
    graph.add_node(OpNode::new(4, OpKind::Constant, vec![2], DType::F32));
    graph.add_constant_for_node(4, hologram_compiler::ConstantData::F32(vec![1.0, 1.0]));

    // Node 5: BatchNorm output [1, 2, 2, 2]
    graph.add_node(OpNode::new(
        5,
        OpKind::BatchNormalization { epsilon: 1e-5 },
        vec![1, 2, 2, 2],
        DType::F32,
    ));
    graph.add_edge(0, 5); // input
    graph.add_edge(1, 5); // scale
    graph.add_edge(2, 5); // bias
    graph.add_edge(3, 5); // mean
    graph.add_edge(4, 5); // var

    // Node 6: Output
    graph.add_node(OpNode::new(6, OpKind::Output, vec![1, 2, 2, 2], DType::F32));
    graph.add_edge(5, 6);
    graph.add_output("output", 6);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: [1, 2, 3, 4, 5, 6, 7, 8] (2 channels * 4 spatial)
    let input_data: Vec<f32> = (1..=8).map(|i| i as f32).collect();
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 32]; // 8 f32 = 32 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Expected: (input - mean) / sqrt(var + eps) * scale + bias
    // With mean=0, var=1, scale=2, bias=1: output = input * 2 + 1
    let expected: Vec<f32> = (1..=8).map(|i| i as f32 * 2.0 + 1.0).collect();
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        assert!((r - e).abs() < 1e-4, "output[{i}] expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_max_pool() {
    // Build graph: Input -> MaxPool -> Output
    // Input: [1, 1, 4, 4], kernel=2x2, stride=2 -> Output: [1, 1, 2, 2]

    let mut graph = OperationGraph::new();

    // Node 0: Input [1, 1, 4, 4]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 1, 4, 4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: MaxPool output [1, 1, 2, 2]
    graph.add_node(OpNode::new(
        1,
        OpKind::MaxPool {
            kernel: (2, 2),
            stride: (2, 2),
            padding: (0, 0),
        },
        vec![1, 1, 2, 2],
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![1, 1, 2, 2], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: values 1..16
    let input_data: Vec<f32> = (1..=16).map(|i| i as f32).collect();
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16]; // 4 f32 = 16 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Input layout (4x4):
    //  1  2  3  4
    //  5  6  7  8
    //  9 10 11 12
    // 13 14 15 16
    //
    // MaxPool 2x2 with stride 2:
    // output[0,0] = max(1,2,5,6) = 6
    // output[0,1] = max(3,4,7,8) = 8
    // output[1,0] = max(9,10,13,14) = 14
    // output[1,1] = max(11,12,15,16) = 16

    let expected = [6.0, 8.0, 14.0, 16.0];
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        assert!((r - e).abs() < 1e-5, "output[{i}] expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_avg_pool() {
    // Build graph: Input -> AvgPool -> Output
    // Input: [1, 1, 4, 4], kernel=2x2, stride=2 -> Output: [1, 1, 2, 2]

    let mut graph = OperationGraph::new();

    // Node 0: Input [1, 1, 4, 4]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 1, 4, 4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: AvgPool output [1, 1, 2, 2]
    graph.add_node(OpNode::new(
        1,
        OpKind::AvgPool {
            kernel: (2, 2),
            stride: (2, 2),
            padding: (0, 0),
        },
        vec![1, 1, 2, 2],
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![1, 1, 2, 2], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: values 1..16
    let input_data: Vec<f32> = (1..=16).map(|i| i as f32).collect();
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16]; // 4 f32 = 16 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Input layout (4x4):
    //  1  2  3  4
    //  5  6  7  8
    //  9 10 11 12
    // 13 14 15 16
    //
    // AvgPool 2x2 with stride 2:
    // output[0,0] = mean(1,2,5,6) = 3.5
    // output[0,1] = mean(3,4,7,8) = 5.5
    // output[1,0] = mean(9,10,13,14) = 11.5
    // output[1,1] = mean(11,12,15,16) = 13.5

    let expected = [3.5, 5.5, 11.5, 13.5];
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        assert!((r - e).abs() < 1e-5, "output[{i}] expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_global_avg_pool() {
    // Build graph: Input -> GlobalAvgPool -> Output
    // Input: [1, 2, 2, 2] -> Output: [1, 2] (average over spatial dims)

    let mut graph = OperationGraph::new();

    // Node 0: Input [1, 2, 2, 2] (batch=1, channels=2, spatial=2x2)
    graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 2, 2, 2], DType::F32));
    graph.add_input("input", 0);

    // Node 1: GlobalAvgPool output [1, 2, 1, 1]
    graph.add_node(OpNode::new(
        1,
        OpKind::GlobalAveragePool,
        vec![1, 2, 1, 1],
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![1, 2], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: [1, 2, 3, 4] for channel 0, [5, 6, 7, 8] for channel 1
    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 8]; // 2 f32 = 8 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Channel 0: avg(1,2,3,4) = 2.5
    // Channel 1: avg(5,6,7,8) = 6.5
    let expected = [2.5, 6.5];
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        assert!((r - e).abs() < 1e-5, "output[{i}] expected {e}, got {r}");
    }
}

#[test]
fn test_constants_out_of_order() {
    // This test exposes a bug where constants added out of node ID order
    // get incorrectly mapped to the wrong buffers.
    //
    // We add constant for node 10 first, then node 5.
    // We use operations that would produce different results if constants are swapped.
    //
    // Graph: input -> mul(node10_const) -> add(node5_const) -> output
    // node10 constant = [2.0] (multiplier)
    // node5 constant = [100.0] (addend)
    //
    // Correct: (input * 2) + 100
    // If swapped: (input * 100) + 2 (very different!)

    let mut graph = OperationGraph::new();

    // Node 0: Input [4]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![4], DType::F32));
    graph.add_input("input", 0);

    // Node 10: Constant - ADD THIS FIRST (higher ID)
    // This is the multiplier = [2.0, 2.0, 2.0, 2.0]
    graph.add_node(OpNode::new(10, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        2.0, 2.0, 2.0, 2.0,
    ]));

    // Node 5: Constant - ADD THIS SECOND (lower ID)
    // This is the addend = [100.0, 100.0, 100.0, 100.0]
    graph.add_node(OpNode::new(5, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        100.0, 100.0, 100.0, 100.0,
    ]));

    // Node 15: Mul input * node10_constant (should multiply by 2)
    graph.add_node(OpNode::new(15, OpKind::Mul, vec![4], DType::F32));
    graph.add_edge(0, 15); // input
    graph.add_edge(10, 15); // constant [2, 2, 2, 2]

    // Node 20: Add result + node5_constant (should add 100)
    graph.add_node(OpNode::new(20, OpKind::Add, vec![4], DType::F32));
    graph.add_edge(15, 20); // intermediate (input * 2)
    graph.add_edge(5, 20); // constant [100, 100, 100, 100]

    // Node 25: Output
    graph.add_node(OpNode::new(25, OpKind::Output, vec![4], DType::F32));
    graph.add_edge(20, 25);
    graph.add_output("output", 25);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: [1, 2, 3, 4]
    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16]; // 4 f32 = 16 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Correct: (input * 2) + 100
    // [1*2+100, 2*2+100, 3*2+100, 4*2+100] = [102, 104, 106, 108]
    //
    // If constants swapped (bug): (input * 100) + 2
    // [1*100+2, 2*100+2, 3*100+2, 4*100+2] = [102, 202, 302, 402]
    //
    // Note: first element would be same (102), but others differ significantly!

    let expected = [102.0, 104.0, 106.0, 108.0];
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        assert!(
            (r - e).abs() < 1e-4,
            "output[{i}] expected {e}, got {r}\n\
             If constants were swapped, result would be [{}, {}, {}, {}]",
            102.0,
            202.0,
            302.0,
            402.0
        );
    }
}

// ============================================================================
// Transformer Operation Tests
// ============================================================================

#[test]
fn test_compile_and_execute_sqrt() {
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let sqrt = OpNode::new(1, OpKind::Sqrt, vec![4], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input);
    graph.add_node(sqrt);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let input_bytes = f32_to_bytes(&[1.0, 4.0, 9.0, 16.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    let expected = [1.0, 2.0, 3.0, 4.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_log() {
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![3], DType::F32);
    let log = OpNode::new(1, OpKind::Log, vec![3], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![3], DType::F32);

    graph.add_node(input);
    graph.add_node(log);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let e = std::f32::consts::E;
    let input_bytes = f32_to_bytes(&[1.0, e, e * e]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 12];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    let expected = [0.0, 1.0, 2.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-5, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_exp() {
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![3], DType::F32);
    let exp = OpNode::new(1, OpKind::Exp, vec![3], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![3], DType::F32);

    graph.add_node(input);
    graph.add_node(exp);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let input_bytes = f32_to_bytes(&[0.0, 1.0, 2.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 12];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    let e = std::f32::consts::E;
    let expected = [1.0, e, e * e];
    for (r, exp_val) in result.iter().zip(expected.iter()) {
        assert!((r - exp_val).abs() < 1e-5, "expected {exp_val}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_abs() {
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let abs = OpNode::new(1, OpKind::Abs, vec![4], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input);
    graph.add_node(abs);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let input_bytes = f32_to_bytes(&[-3.0, -1.0, 0.0, 2.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    let expected = [3.0, 1.0, 0.0, 2.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_pow() {
    let mut graph = OperationGraph::new();

    let input_base = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_exp = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let pow = OpNode::new(2, OpKind::Pow, vec![4], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_base);
    graph.add_node(input_exp);
    graph.add_node(pow);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("base", 0);
    graph.add_input("exp", 1);
    graph.add_output("y", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let base_bytes = f32_to_bytes(&[2.0, 3.0, 4.0, 5.0]);
    let exp_bytes = f32_to_bytes(&[2.0, 2.0, 0.5, 1.0]);
    let inputs: &[&[u8]] = &[&base_bytes, &exp_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    // 2^2=4, 3^2=9, 4^0.5=2, 5^1=5
    // Note: SIMD pow uses exp(y*log(x)) approximation, so higher tolerance needed
    let expected = [4.0, 9.0, 2.0, 5.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 0.1, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_elem_min() {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let elem_min = OpNode::new(2, OpKind::ElemMin, vec![4], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(elem_min);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("y", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let a_bytes = f32_to_bytes(&[1.0, 5.0, 3.0, 8.0]);
    let b_bytes = f32_to_bytes(&[2.0, 4.0, 6.0, 7.0]);
    let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    let expected = [1.0, 4.0, 3.0, 7.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_elem_max() {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let elem_max = OpNode::new(2, OpKind::ElemMax, vec![4], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(elem_max);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("y", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let a_bytes = f32_to_bytes(&[1.0, 5.0, 3.0, 8.0]);
    let b_bytes = f32_to_bytes(&[2.0, 4.0, 6.0, 7.0]);
    let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    let expected = [2.0, 5.0, 6.0, 8.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_greater() {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let greater = OpNode::new(2, OpKind::Greater, vec![4], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(greater);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("y", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let a_bytes = f32_to_bytes(&[1.0, 5.0, 3.0, 3.0]);
    let b_bytes = f32_to_bytes(&[2.0, 4.0, 3.0, 2.0]);
    let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    // 1>2=0, 5>4=1, 3>3=0, 3>2=1
    let expected = [0.0, 1.0, 0.0, 1.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_less() {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let less = OpNode::new(2, OpKind::Less, vec![4], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(less);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("y", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let a_bytes = f32_to_bytes(&[1.0, 5.0, 3.0, 3.0]);
    let b_bytes = f32_to_bytes(&[2.0, 4.0, 3.0, 2.0]);
    let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    // 1<2=1, 5<4=0, 3<3=0, 3<2=0
    let expected = [1.0, 0.0, 0.0, 0.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_where() {
    let mut graph = OperationGraph::new();

    let input_cond = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_x = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let input_y = OpNode::new(2, OpKind::Input, vec![4], DType::F32);
    let where_op = OpNode::new(3, OpKind::Where, vec![4], DType::F32);
    let output = OpNode::new(4, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_cond);
    graph.add_node(input_x);
    graph.add_node(input_y);
    graph.add_node(where_op);
    graph.add_node(output);

    graph.add_edge(0, 3);
    graph.add_edge(1, 3);
    graph.add_edge(2, 3);
    graph.add_edge(3, 4);

    graph.add_input("cond", 0);
    graph.add_input("x", 1);
    graph.add_input("y", 2);
    graph.add_output("result", 4);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    // cond: [1, 0, 1, 0] (non-zero = true)
    let cond_bytes = f32_to_bytes(&[1.0, 0.0, 1.0, 0.0]);
    let x_bytes = f32_to_bytes(&[10.0, 20.0, 30.0, 40.0]);
    let y_bytes = f32_to_bytes(&[100.0, 200.0, 300.0, 400.0]);
    let inputs: &[&[u8]] = &[&cond_bytes, &x_bytes, &y_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    // where(cond, x, y): cond[0]=1 -> x[0]=10, cond[1]=0 -> y[1]=200, ...
    let expected = [10.0, 200.0, 30.0, 400.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_less_or_equal() {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let less_or_equal = OpNode::new(2, OpKind::LessOrEqual, vec![4], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(less_or_equal);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("y", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let a_bytes = f32_to_bytes(&[1.0, 5.0, 3.0, 3.0]);
    let b_bytes = f32_to_bytes(&[2.0, 4.0, 3.0, 2.0]);
    let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    // 1<=2=1, 5<=4=0, 3<=3=1, 3<=2=0
    let expected = [1.0, 0.0, 1.0, 0.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_greater_or_equal() {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![4], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![4], DType::F32);
    let greater_or_equal = OpNode::new(2, OpKind::GreaterOrEqual, vec![4], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(greater_or_equal);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("y", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let a_bytes = f32_to_bytes(&[1.0, 5.0, 3.0, 3.0]);
    let b_bytes = f32_to_bytes(&[2.0, 4.0, 3.0, 2.0]);
    let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];
    let mut output_bytes = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    // 1>=2=0, 5>=4=1, 3>=3=1, 3>=2=1
    let expected = [0.0, 1.0, 1.0, 1.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_tile_1d() {
    let mut graph = OperationGraph::new();

    // Input shape [2], tile with multiples [3] -> output shape [6]
    let input = OpNode::new(0, OpKind::Input, vec![2], DType::F32);
    let tile = OpNode::new(1, OpKind::Tile { multiples: vec![3] }, vec![6], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![6], DType::F32);

    graph.add_node(input);
    graph.add_node(tile);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let input_bytes = f32_to_bytes(&[1.0, 2.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 24]; // 6 * 4 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    // [1, 2] tiled 3x -> [1, 2, 1, 2, 1, 2]
    let expected = [1.0, 2.0, 1.0, 2.0, 1.0, 2.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_tile_2d() {
    let mut graph = OperationGraph::new();

    // Input shape [2, 2], tile with multiples [2, 3] -> output shape [4, 6]
    let input = OpNode::new(0, OpKind::Input, vec![2, 2], DType::F32);
    let tile = OpNode::new(
        1,
        OpKind::Tile {
            multiples: vec![2, 3],
        },
        vec![4, 6],
        DType::F32,
    );
    let output = OpNode::new(2, OpKind::Output, vec![4, 6], DType::F32);

    graph.add_node(input);
    graph.add_node(tile);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    // Input: [[1, 2], [3, 4]] in row-major
    let input_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 96]; // 4 * 6 * 4 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    // Verify output shape is correct (4x6 = 24 elements)
    assert_eq!(result.len(), 24);

    // Row 0: [1,2] repeated 3x -> [1,2,1,2,1,2]
    // Row 1: [3,4] repeated 3x -> [3,4,3,4,3,4]
    // Then rows 0-1 repeated 2x
    let expected = [
        1.0, 2.0, 1.0, 2.0, 1.0, 2.0, // row 0
        3.0, 4.0, 3.0, 4.0, 3.0, 4.0, // row 1
        1.0, 2.0, 1.0, 2.0, 1.0, 2.0, // row 2 (repeat of row 0)
        3.0, 4.0, 3.0, 4.0, 3.0, 4.0, // row 3 (repeat of row 1)
    ];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_expand_1d_to_2d() {
    let mut graph = OperationGraph::new();

    // Input shape [1, 2], expand to [3, 2]
    let input = OpNode::new(0, OpKind::Input, vec![1, 2], DType::F32);
    let expand = OpNode::new(
        1,
        OpKind::Expand { shape: vec![3, 2] },
        vec![3, 2],
        DType::F32,
    );
    let output = OpNode::new(2, OpKind::Output, vec![3, 2], DType::F32);

    graph.add_node(input);
    graph.add_node(expand);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let input_bytes = f32_to_bytes(&[1.0, 2.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 24]; // 3 * 2 * 4 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    // [[1, 2]] broadcast to [[1, 2], [1, 2], [1, 2]]
    let expected = [1.0, 2.0, 1.0, 2.0, 1.0, 2.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

#[test]
fn test_compile_and_execute_expand_scalar_broadcast() {
    let mut graph = OperationGraph::new();

    // Input shape [1], expand to [4]
    let input = OpNode::new(0, OpKind::Input, vec![1], DType::F32);
    let expand = OpNode::new(1, OpKind::Expand { shape: vec![4] }, vec![4], DType::F32);
    let output = OpNode::new(2, OpKind::Output, vec![4], DType::F32);

    graph.add_node(input);
    graph.add_node(expand);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    graph.add_input("x", 0);
    graph.add_output("y", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let backend = CpuBackend::new();
    let input_bytes = f32_to_bytes(&[5.0]);
    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16]; // 4 * 4 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    // [5] broadcast to [5, 5, 5, 5]
    let expected = [5.0, 5.0, 5.0, 5.0];
    for (r, e) in result.iter().zip(expected.iter()) {
        assert!((r - e).abs() < 1e-6, "expected {e}, got {r}");
    }
}

// ============================================================================
// LayerNorm Tests
// ============================================================================

#[test]
fn test_compile_and_execute_layer_norm_2d() {
    // Build graph: Input -> LayerNorm -> Output
    // LayerNorm with scale=1, bias=0 should produce normalized output
    // For input [1, 2, 3, 4]: mean=2.5, var=1.25
    // normalized = (x - mean) / sqrt(var + eps)

    let mut graph = OperationGraph::new();

    // Node 0: Input [2, 4] (batch=2, hidden=4)
    graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: scale [4] = [1.0, 1.0, 1.0, 1.0]
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        1.0, 1.0, 1.0, 1.0,
    ]));

    // Node 2: bias [4] = [0.0, 0.0, 0.0, 0.0]
    graph.add_node(OpNode::new(2, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        0.0, 0.0, 0.0, 0.0,
    ]));

    // Node 3: LayerNorm output [2, 4]
    graph.add_node(OpNode::new(
        3,
        OpKind::LayerNorm {
            normalized_dims: 1,
            epsilon: 1e-5,
        },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(0, 3); // input
    graph.add_edge(1, 3); // scale
    graph.add_edge(2, 3); // bias

    // Node 4: Output
    graph.add_node(OpNode::new(4, OpKind::Output, vec![2, 4], DType::F32));
    graph.add_edge(3, 4);
    graph.add_output("output", 4);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: first row [1,2,3,4], second row [5,6,7,8]
    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 32]; // 8 f32 = 32 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // For each row, verify mean≈0 and variance≈1
    // Row 1: [1,2,3,4] -> mean=2.5, std≈1.118
    // Row 2: [5,6,7,8] -> mean=6.5, std≈1.118
    for row in 0..2 {
        let start = row * 4;
        let row_data = &result[start..start + 4];

        // Compute mean and variance of normalized output
        let mean: f32 = row_data.iter().sum::<f32>() / 4.0;
        let var: f32 = row_data.iter().map(|x| (x - mean).powi(2)).sum::<f32>() / 4.0;

        assert!(mean.abs() < 1e-4, "Row {row} mean should be ~0, got {mean}");
        assert!(
            (var - 1.0).abs() < 0.1,
            "Row {row} variance should be ~1, got {var}"
        );
    }
}

#[test]
fn test_compile_and_execute_layer_norm_3d() {
    // Build graph: Input -> LayerNorm -> Output
    // 3D input: [batch=1, seq_len=2, hidden=4]

    let mut graph = OperationGraph::new();

    // Node 0: Input [1, 2, 4] (batch=1, seq_len=2, hidden=4)
    graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 2, 4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: scale [4] = [2.0, 2.0, 2.0, 2.0] (non-identity scale)
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        2.0, 2.0, 2.0, 2.0,
    ]));

    // Node 2: bias [4] = [1.0, 1.0, 1.0, 1.0] (non-zero bias)
    graph.add_node(OpNode::new(2, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        1.0, 1.0, 1.0, 1.0,
    ]));

    // Node 3: LayerNorm output [1, 2, 4]
    graph.add_node(OpNode::new(
        3,
        OpKind::LayerNorm {
            normalized_dims: 1,
            epsilon: 1e-5,
        },
        vec![1, 2, 4],
        DType::F32,
    ));
    graph.add_edge(0, 3); // input
    graph.add_edge(1, 3); // scale
    graph.add_edge(2, 3); // bias

    // Node 4: Output
    graph.add_node(OpNode::new(4, OpKind::Output, vec![1, 2, 4], DType::F32));
    graph.add_edge(3, 4);
    graph.add_output("output", 4);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: two positions, each with 4 hidden dims
    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 32]; // 8 f32 = 32 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // With scale=2 and bias=1, output = normalized * 2 + 1
    // For each row, mean of output should be ~1 (bias)
    for row in 0..2 {
        let start = row * 4;
        let row_data = &result[start..start + 4];

        // Mean should be bias (1.0) since normalized mean is 0
        let mean: f32 = row_data.iter().sum::<f32>() / 4.0;
        assert!(
            (mean - 1.0).abs() < 0.1,
            "Row {row} mean should be ~1 (bias), got {mean}"
        );

        // Variance should be scale^2 = 4 since normalized variance is 1
        let var: f32 = row_data.iter().map(|x| (x - mean).powi(2)).sum::<f32>() / 4.0;
        assert!(
            (var - 4.0).abs() < 0.5,
            "Row {row} variance should be ~4 (scale^2), got {var}"
        );
    }
}

#[test]
fn test_layer_norm_numerical_stability() {
    // Test with large values to verify numerical stability

    let mut graph = OperationGraph::new();

    // Node 0: Input [1, 4] with large values
    graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: scale [4] = [1.0, 1.0, 1.0, 1.0]
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        1.0, 1.0, 1.0, 1.0,
    ]));

    // Node 2: bias [4] = [0.0, 0.0, 0.0, 0.0]
    graph.add_node(OpNode::new(2, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        0.0, 0.0, 0.0, 0.0,
    ]));

    // Node 3: LayerNorm output [1, 4]
    graph.add_node(OpNode::new(
        3,
        OpKind::LayerNorm {
            normalized_dims: 1,
            epsilon: 1e-5,
        },
        vec![1, 4],
        DType::F32,
    ));
    graph.add_edge(0, 3);
    graph.add_edge(1, 3);
    graph.add_edge(2, 3);

    // Node 4: Output
    graph.add_node(OpNode::new(4, OpKind::Output, vec![1, 4], DType::F32));
    graph.add_edge(3, 4);
    graph.add_output("output", 4);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Large values that could cause numerical issues with naive mean/variance
    let input_data: Vec<f32> = vec![1e6, 1e6 + 1.0, 1e6 + 2.0, 1e6 + 3.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16]; // 4 f32 = 16 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Verify no NaN or Inf
    for (i, &val) in result.iter().enumerate() {
        assert!(val.is_finite(), "output[{i}] is not finite: {val}");
    }

    // Verify normalized mean is ~0
    let mean: f32 = result.iter().sum::<f32>() / 4.0;
    assert!(
        mean.abs() < 1e-3,
        "Mean should be ~0 for normalized output, got {mean}"
    );
}

// ============================================================================
// Softmax Tests (TASK-203)
// ============================================================================

#[test]
fn test_softmax_axis_last() {
    // Test softmax along the last axis (axis=-1)
    // Shape: [2, 4] - softmax over 4 elements for each of 2 batches

    let mut graph = OperationGraph::new();

    // Node 0: Input [2, 4]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Softmax output [2, 4]
    graph.add_node(OpNode::new(
        1,
        OpKind::Softmax { axis: -1 },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![2, 4], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: [1, 2, 3, 4] and [0, 0, 0, 0]
    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 0.0, 0.0, 0.0, 0.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 32]; // 8 f32 = 32 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Each row should sum to 1.0
    let sum1: f32 = result[0..4].iter().sum();
    let sum2: f32 = result[4..8].iter().sum();

    assert!(
        (sum1 - 1.0).abs() < 1e-5,
        "First batch softmax sum should be 1.0, got {sum1}"
    );
    assert!(
        (sum2 - 1.0).abs() < 1e-5,
        "Second batch softmax sum should be 1.0, got {sum2}"
    );

    // Second batch (all zeros) should be uniform distribution [0.25, 0.25, 0.25, 0.25]
    for val in &result[4..8] {
        assert!(
            (*val - 0.25).abs() < 1e-5,
            "Uniform input should give uniform output, got {val}",
        );
    }

    // First batch should have increasing probabilities
    assert!(
        result[0] < result[1] && result[1] < result[2] && result[2] < result[3],
        "Softmax should preserve relative ordering"
    );
}

#[test]
fn test_softmax_axis_1() {
    // Test softmax along axis=1
    // Shape: [2, 3] - softmax over 3 elements for each of 2 batches

    let mut graph = OperationGraph::new();

    // Node 0: Input [2, 3]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Softmax output [2, 3] with axis=1
    graph.add_node(OpNode::new(
        1,
        OpKind::Softmax { axis: 1 },
        vec![2, 3],
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: [1, 2, 3] and [10, 20, 30]
    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 10.0, 20.0, 30.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 24]; // 6 f32 = 24 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Each row should sum to 1.0
    let sum1: f32 = result[0..3].iter().sum();
    let sum2: f32 = result[3..6].iter().sum();

    assert!(
        (sum1 - 1.0).abs() < 1e-5,
        "First batch softmax sum should be 1.0, got {sum1}"
    );
    assert!(
        (sum2 - 1.0).abs() < 1e-5,
        "Second batch softmax sum should be 1.0, got {sum2}"
    );
}

#[test]
fn test_softmax_numerical_stability() {
    // Test with large values to verify numerical stability (subtract max before exp)

    let mut graph = OperationGraph::new();

    // Node 0: Input [1, 4]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Softmax output [1, 4]
    graph.add_node(OpNode::new(
        1,
        OpKind::Softmax { axis: -1 },
        vec![1, 4],
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![1, 4], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Large values that would overflow naive exp()
    let input_data: Vec<f32> = vec![1000.0, 1001.0, 1002.0, 1003.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16]; // 4 f32 = 16 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Verify no NaN or Inf
    for (i, &val) in result.iter().enumerate() {
        assert!(
            val.is_finite(),
            "output[{i}] is not finite (numerical instability): {val}"
        );
    }

    // Should sum to 1.0
    let sum: f32 = result.iter().sum();
    assert!(
        (sum - 1.0).abs() < 1e-5,
        "Softmax sum should be 1.0, got {sum}"
    );

    // Should have increasing probabilities
    assert!(
        result[0] < result[1] && result[1] < result[2] && result[2] < result[3],
        "Softmax should preserve relative ordering"
    );
}

// ============================================================================
// Slice Tests (TASK-204)
// ============================================================================

#[test]
fn test_slice_basic() {
    // Test basic slice without strides: extract first 2 elements from [4]
    let mut graph = OperationGraph::new();

    // Node 0: Input [4]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Slice to [2] (first 2 elements)
    graph.add_node(OpNode::new(
        1,
        OpKind::Slice {
            starts: vec![0],
            ends: vec![2],
            steps: vec![1],
        },
        vec![2],
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![2], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 8]; // 2 f32 = 8 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    assert_eq!(result.len(), 2, "Should have 2 elements");
    assert!(
        (result[0] - 1.0).abs() < 1e-6,
        "First element should be 1.0"
    );
    assert!(
        (result[1] - 2.0).abs() < 1e-6,
        "Second element should be 2.0"
    );
}

#[test]
fn test_slice_with_stride() {
    // Test strided slice: every other element from [6]
    // Input: [1, 2, 3, 4, 5, 6], step=2 -> [1, 3, 5]
    let mut graph = OperationGraph::new();

    // Node 0: Input [6]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![6], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Slice with step=2, gets [0, 2, 4] indices
    graph.add_node(OpNode::new(
        1,
        OpKind::Slice {
            starts: vec![0],
            ends: vec![6],
            steps: vec![2],
        },
        vec![3],
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![3], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 12]; // 3 f32 = 12 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    assert_eq!(result.len(), 3, "Should have 3 elements");
    assert!(
        (result[0] - 1.0).abs() < 1e-6,
        "First element should be 1.0"
    );
    assert!(
        (result[1] - 3.0).abs() < 1e-6,
        "Second element should be 3.0"
    );
    assert!(
        (result[2] - 5.0).abs() < 1e-6,
        "Third element should be 5.0"
    );
}

#[test]
fn test_slice_2d() {
    // Test 2D slice: extract top-left 2x2 from 3x3
    let mut graph = OperationGraph::new();

    // Node 0: Input [3, 3]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![3, 3], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Slice to [2, 2]
    graph.add_node(OpNode::new(
        1,
        OpKind::Slice {
            starts: vec![0, 0],
            ends: vec![2, 2],
            steps: vec![1, 1],
        },
        vec![2, 2],
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![2, 2], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // 3x3 matrix: [[1,2,3], [4,5,6], [7,8,9]]
    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 16]; // 4 f32 = 16 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);
    // Top-left 2x2: [[1,2], [4,5]] flattened = [1, 2, 4, 5]
    assert_eq!(result.len(), 4, "Should have 4 elements");
    assert!(
        (result[0] - 1.0).abs() < 1e-6,
        "element [0,0] should be 1.0"
    );
    assert!(
        (result[1] - 2.0).abs() < 1e-6,
        "element [0,1] should be 2.0"
    );
    assert!(
        (result[2] - 4.0).abs() < 1e-6,
        "element [1,0] should be 4.0"
    );
    assert!(
        (result[3] - 5.0).abs() < 1e-6,
        "element [1,1] should be 5.0"
    );
}

// ============================================================================
// Split Tests (TASK-205)
// ============================================================================

#[test]
fn test_split_1d() {
    // Split [6] into [2] and [4] along axis 0
    let mut graph = OperationGraph::new();

    // Node 0: Input [6]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![6], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Split output 0 -> [2]
    graph.add_node(OpNode::new(
        1,
        OpKind::Split {
            axis: 0,
            split_sizes: vec![2, 4],
            output_index: 0,
        },
        vec![2],
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Split output 1 -> [4]
    graph.add_node(OpNode::new(
        2,
        OpKind::Split {
            axis: 0,
            split_sizes: vec![2, 4],
            output_index: 1,
        },
        vec![4],
        DType::F32,
    ));
    graph.add_edge(0, 2);

    // Node 3: Output 0
    graph.add_node(OpNode::new(3, OpKind::Output, vec![2], DType::F32));
    graph.add_edge(1, 3);
    graph.add_output("output0", 3);

    // Node 4: Output 1
    graph.add_node(OpNode::new(4, OpKind::Output, vec![4], DType::F32));
    graph.add_edge(2, 4);
    graph.add_output("output1", 4);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: [1, 2, 3, 4, 5, 6]
    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output0_bytes = vec![0u8; 8]; // 2 f32 = 8 bytes
    let mut output1_bytes = vec![0u8; 16]; // 4 f32 = 16 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output0_bytes, &mut output1_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result0 = bytes_to_f32(&output0_bytes);
    let result1 = bytes_to_f32(&output1_bytes);

    // First split: [1, 2]
    assert_eq!(result0.len(), 2, "First split should have 2 elements");
    assert!(
        (result0[0] - 1.0).abs() < 1e-6,
        "First element should be 1.0"
    );
    assert!(
        (result0[1] - 2.0).abs() < 1e-6,
        "Second element should be 2.0"
    );

    // Second split: [3, 4, 5, 6]
    assert_eq!(result1.len(), 4, "Second split should have 4 elements");
    assert!((result1[0] - 3.0).abs() < 1e-6, "Element should be 3.0");
    assert!((result1[1] - 4.0).abs() < 1e-6, "Element should be 4.0");
    assert!((result1[2] - 5.0).abs() < 1e-6, "Element should be 5.0");
    assert!((result1[3] - 6.0).abs() < 1e-6, "Element should be 6.0");
}

// ============================================================================
// Pad Tests (TASK-206)
// ============================================================================

#[test]
fn test_pad_1d_constant() {
    // Pad [4] with (1, 2) padding => [7]
    let mut graph = OperationGraph::new();

    // Node 0: Input [4]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![4], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Pad with constant value 0.0
    graph.add_node(OpNode::new(
        1,
        OpKind::Pad {
            pads: vec![(1, 2)],
            mode: PadMode::Constant,
            constant_value: 0.0,
        },
        vec![7], // 4 + 1 + 2 = 7
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![7], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: [1, 2, 3, 4]
    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 28]; // 7 f32 = 28 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Expected: [0, 1, 2, 3, 4, 0, 0]
    let expected = [0.0, 1.0, 2.0, 3.0, 4.0, 0.0, 0.0];
    assert_eq!(result.len(), 7, "Output should have 7 elements");
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        assert!((r - e).abs() < 1e-6, "Element {i} should be {e}, got {r}");
    }
}

#[test]
fn test_pad_2d_constant() {
    // Pad [2, 3] with (1, 0) and (0, 1) padding => [3, 4]
    // Input:
    //   [[1, 2, 3],
    //    [4, 5, 6]]
    // Output with pad_before = [1, 0], pad_after = [0, 1]:
    //   [[0, 0, 0, 0],  <- padded row
    //    [1, 2, 3, 0],  <- original row 0 + pad right
    //    [4, 5, 6, 0]]  <- original row 1 + pad right
    let mut graph = OperationGraph::new();

    // Node 0: Input [2, 3]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Pad with constant value 0.0
    graph.add_node(OpNode::new(
        1,
        OpKind::Pad {
            pads: vec![(1, 0), (0, 1)], // dim0: 1 before, 0 after; dim1: 0 before, 1 after
            mode: PadMode::Constant,
            constant_value: 0.0,
        },
        vec![3, 4], // [2+1+0, 3+0+1] = [3, 4]
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![3, 4], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: [[1, 2, 3], [4, 5, 6]] in row-major
    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 48]; // 12 f32 = 48 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Expected: [[0, 0, 0, 0], [1, 2, 3, 0], [4, 5, 6, 0]] in row-major
    let expected = [0.0, 0.0, 0.0, 0.0, 1.0, 2.0, 3.0, 0.0, 4.0, 5.0, 6.0, 0.0];
    assert_eq!(result.len(), 12, "Output should have 12 elements");
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        assert!((r - e).abs() < 1e-6, "Element {i} should be {e}, got {r}");
    }
}

#[test]
fn test_pad_with_nonzero_constant() {
    // Pad [3] with (2, 1) padding and constant value -1.0 => [6]
    let mut graph = OperationGraph::new();

    // Node 0: Input [3]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![3], DType::F32));
    graph.add_input("input", 0);

    // Node 1: Pad with constant value -1.0
    graph.add_node(OpNode::new(
        1,
        OpKind::Pad {
            pads: vec![(2, 1)],
            mode: PadMode::Constant,
            constant_value: -1.0,
        },
        vec![6], // 3 + 2 + 1 = 6
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Node 2: Output
    graph.add_node(OpNode::new(2, OpKind::Output, vec![6], DType::F32));
    graph.add_edge(1, 2);
    graph.add_output("output", 2);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: [10, 20, 30]
    let input_data: Vec<f32> = vec![10.0, 20.0, 30.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 24]; // 6 f32 = 24 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Expected: [-1, -1, 10, 20, 30, -1]
    let expected = [-1.0, -1.0, 10.0, 20.0, 30.0, -1.0];
    assert_eq!(result.len(), 6, "Output should have 6 elements");
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        assert!((r - e).abs() < 1e-6, "Element {i} should be {e}, got {r}");
    }
}

// ============================================================================
// Concat Tests (TASK-207)
// ============================================================================

#[test]
fn test_concat_1d() {
    // Concatenate two 1D arrays: [3] + [4] = [7]
    let mut graph = OperationGraph::new();

    // Node 0: Input [3]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![3], DType::F32));
    graph.add_input("input1", 0);

    // Node 1: Input [4]
    graph.add_node(OpNode::new(1, OpKind::Input, vec![4], DType::F32));
    graph.add_input("input2", 1);

    // Node 2: Concat along axis 0
    graph.add_node(OpNode::new(
        2,
        OpKind::Concat {
            axis: 0,
            num_inputs: 2,
        },
        vec![7], // 3 + 4 = 7
        DType::F32,
    ));
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);

    // Node 3: Output
    graph.add_node(OpNode::new(3, OpKind::Output, vec![7], DType::F32));
    graph.add_edge(2, 3);
    graph.add_output("output", 3);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    let input1_data: Vec<f32> = vec![1.0, 2.0, 3.0];
    let input2_data: Vec<f32> = vec![4.0, 5.0, 6.0, 7.0];
    let input1_bytes = f32_to_bytes(&input1_data);
    let input2_bytes = f32_to_bytes(&input2_data);

    let inputs: &[&[u8]] = &[&input1_bytes, &input2_bytes];
    let mut output_bytes = vec![0u8; 28]; // 7 f32 = 28 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Expected: [1, 2, 3, 4, 5, 6, 7]
    let expected = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0];
    assert_eq!(result.len(), 7, "Output should have 7 elements");
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        assert!((r - e).abs() < 1e-6, "Element {i} should be {e}, got {r}");
    }
}

#[test]
fn test_concat_2d_axis0() {
    // Concatenate along axis 0 (batch dimension)
    // [2, 3] + [1, 3] = [3, 3]
    let mut graph = OperationGraph::new();

    // Node 0: Input [2, 3]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
    graph.add_input("input1", 0);

    // Node 1: Input [1, 3]
    graph.add_node(OpNode::new(1, OpKind::Input, vec![1, 3], DType::F32));
    graph.add_input("input2", 1);

    // Node 2: Concat along axis 0
    graph.add_node(OpNode::new(
        2,
        OpKind::Concat {
            axis: 0,
            num_inputs: 2,
        },
        vec![3, 3], // 2 + 1 = 3 along axis 0
        DType::F32,
    ));
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);

    // Node 3: Output
    graph.add_node(OpNode::new(3, OpKind::Output, vec![3, 3], DType::F32));
    graph.add_edge(2, 3);
    graph.add_output("output", 3);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input 1: [[1, 2, 3], [4, 5, 6]]
    let input1_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0];
    // Input 2: [[7, 8, 9]]
    let input2_data: Vec<f32> = vec![7.0, 8.0, 9.0];
    let input1_bytes = f32_to_bytes(&input1_data);
    let input2_bytes = f32_to_bytes(&input2_data);

    let inputs: &[&[u8]] = &[&input1_bytes, &input2_bytes];
    let mut output_bytes = vec![0u8; 36]; // 9 f32 = 36 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Expected: [[1, 2, 3], [4, 5, 6], [7, 8, 9]] in row-major
    let expected = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0];
    assert_eq!(result.len(), 9, "Output should have 9 elements");
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        assert!((r - e).abs() < 1e-6, "Element {i} should be {e}, got {r}");
    }
}

#[test]
fn test_concat_multi_head_attention() {
    // Simulates multi-head attention concatenation
    // 4 heads of [batch=1, seq=2, head_dim=3] concatenated => [1, 2, 12]
    // In row-major with axis=0 concatenation, this works if each head is flattened
    let mut graph = OperationGraph::new();

    // Node 0-3: 4 input heads, each [2, 3] (seq_len=2, head_dim=3)
    for i in 0..4 {
        graph.add_node(OpNode::new(i, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_input(format!("head{i}"), i);
    }

    // Node 4: Concat along axis 0 (will produce [8, 3] = flattened heads)
    graph.add_node(OpNode::new(
        4,
        OpKind::Concat {
            axis: 0,
            num_inputs: 4,
        },
        vec![8, 3], // 4 heads * 2 seq = 8
        DType::F32,
    ));
    for i in 0..4 {
        graph.add_edge(i, 4);
    }

    // Node 5: Output
    graph.add_node(OpNode::new(5, OpKind::Output, vec![8, 3], DType::F32));
    graph.add_edge(4, 5);
    graph.add_output("output", 5);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Each head: [[1,2,3], [4,5,6]] type pattern but with head-specific offset
    let head0: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0];
    let head1: Vec<f32> = vec![10.0, 20.0, 30.0, 40.0, 50.0, 60.0];
    let head2: Vec<f32> = vec![100.0, 200.0, 300.0, 400.0, 500.0, 600.0];
    let head3: Vec<f32> = vec![1000.0, 2000.0, 3000.0, 4000.0, 5000.0, 6000.0];

    let head0_bytes = f32_to_bytes(&head0);
    let head1_bytes = f32_to_bytes(&head1);
    let head2_bytes = f32_to_bytes(&head2);
    let head3_bytes = f32_to_bytes(&head3);

    let inputs: &[&[u8]] = &[&head0_bytes, &head1_bytes, &head2_bytes, &head3_bytes];
    let mut output_bytes = vec![0u8; 96]; // 24 f32 = 96 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Should have all 24 elements from all 4 heads concatenated
    assert_eq!(result.len(), 24, "Output should have 24 elements");

    // First 6 from head0
    assert!(
        (result[0] - 1.0).abs() < 1e-6,
        "First element should be from head0"
    );
    assert!(
        (result[5] - 6.0).abs() < 1e-6,
        "6th element should be from head0"
    );

    // Next 6 from head1
    assert!(
        (result[6] - 10.0).abs() < 1e-6,
        "7th element should be from head1"
    );

    // Next 6 from head2
    assert!(
        (result[12] - 100.0).abs() < 1e-6,
        "13th element should be from head2"
    );

    // Next 6 from head3
    assert!(
        (result[18] - 1000.0).abs() < 1e-6,
        "19th element should be from head3"
    );
}

// ============================================================================
// Backend::execute_plan_with_layers API Tests
// ============================================================================

/// Test the high-level `execute_plan_with_layers` API on CpuBackend.
///
/// This tests the public Backend trait method rather than the internal
/// ExecutionContext::with_layer_executor used by other CallLayer tests.
#[test]
fn test_backend_execute_plan_with_layers_cpu() {
    use hologram_holo::types::{BufferMetadata, BufferType};
    use hologram_holo::{BackendPlan, IsaInstruction, PlanMetadata};

    // Create a plan with a CallLayer instruction
    let plan = BackendPlan {
        instructions: vec![IsaInstruction::CallLayer {
            layer_id: 0x42,
            inputs: vec![0],
            outputs: vec![1],
        }],
        buffers: vec![
            BufferMetadata::new(16, BufferType::Input),
            BufferMetadata::new(16, BufferType::Output),
        ],
        constants: vec![],
        workspace_size: 0,
        dependencies: vec![],
        metadata: PlanMetadata {
            name: "test_layer_plan".into(),
            version: "1.0".into(),
            author: None,
            description: None,
        },
        node_buffer_map: vec![Some(0), Some(1)],
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let backend = CpuBackend::new();

    // Input: 4 f32 values
    let input_data = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
    let inputs: &[&[u8]] = &[&input_data];
    let mut output_data = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_data];

    // Layer executor: doubles each f32 value
    let mut executor = |_layer_id: u64, layer_inputs: &[&[u8]], layer_outputs: &mut [&mut [u8]]| {
        if !layer_inputs.is_empty() && !layer_outputs.is_empty() {
            let input_floats = bytes_to_f32(layer_inputs[0]);
            let doubled: Vec<f32> = input_floats.iter().map(|x| x * 2.0).collect();
            let doubled_bytes = f32_to_bytes(&doubled);
            layer_outputs[0][..doubled_bytes.len()].copy_from_slice(&doubled_bytes);
        }
        Ok(())
    };

    // Execute using the new API
    backend
        .execute_plan_with_layers(&plan, inputs, outputs, &mut executor)
        .expect("execute_plan_with_layers failed");

    // Verify output: [2.0, 4.0, 6.0, 8.0]
    let result = bytes_to_f32(&output_data);
    assert!((result[0] - 2.0).abs() < 1e-6);
    assert!((result[1] - 4.0).abs() < 1e-6);
    assert!((result[2] - 6.0).abs() < 1e-6);
    assert!((result[3] - 8.0).abs() < 1e-6);
}

/// Test the high-level `execute_plan_with_layers` API on WasmBackend.
#[test]
fn test_backend_execute_plan_with_layers_wasm() {
    use hologram_backend::backends::wasm::WasmBackend;
    use hologram_holo::types::{BufferMetadata, BufferType};
    use hologram_holo::{BackendPlan, IsaInstruction, PlanMetadata};

    // Create a plan with a CallLayer instruction
    let plan = BackendPlan {
        instructions: vec![IsaInstruction::CallLayer {
            layer_id: 0x123,
            inputs: vec![0],
            outputs: vec![1],
        }],
        buffers: vec![
            BufferMetadata::new(16, BufferType::Input),
            BufferMetadata::new(16, BufferType::Output),
        ],
        constants: vec![],
        workspace_size: 0,
        dependencies: vec![],
        metadata: PlanMetadata {
            name: "test_wasm_layer".into(),
            version: "1.0".into(),
            author: None,
            description: None,
        },
        node_buffer_map: vec![Some(0), Some(1)],
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let backend = WasmBackend::new();

    // Input: 4 f32 values
    let input_data = f32_to_bytes(&[10.0, 20.0, 30.0, 40.0]);
    let inputs: &[&[u8]] = &[&input_data];
    let mut output_data = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_data];

    // Layer executor: adds 1.0 to each f32 value
    let mut executor = |_layer_id: u64, layer_inputs: &[&[u8]], layer_outputs: &mut [&mut [u8]]| {
        if !layer_inputs.is_empty() && !layer_outputs.is_empty() {
            let input_floats = bytes_to_f32(layer_inputs[0]);
            let incremented: Vec<f32> = input_floats.iter().map(|x| x + 1.0).collect();
            let out_bytes = f32_to_bytes(&incremented);
            layer_outputs[0][..out_bytes.len()].copy_from_slice(&out_bytes);
        }
        Ok(())
    };

    // Execute using the new API
    backend
        .execute_plan_with_layers(&plan, inputs, outputs, &mut executor)
        .expect("execute_plan_with_layers failed on WASM backend");

    // Verify output: [11.0, 21.0, 31.0, 41.0]
    let result = bytes_to_f32(&output_data);
    assert!((result[0] - 11.0).abs() < 1e-6);
    assert!((result[1] - 21.0).abs() < 1e-6);
    assert!((result[2] - 31.0).abs() < 1e-6);
    assert!((result[3] - 41.0).abs() < 1e-6);
}

/// Test that execute_plan (without layers) fails gracefully on CallLayer.
#[test]
fn test_backend_execute_plan_without_layers_fails_on_call_layer() {
    use hologram_holo::types::{BufferMetadata, BufferType};
    use hologram_holo::{BackendPlan, IsaInstruction, PlanMetadata};

    let plan = BackendPlan {
        instructions: vec![IsaInstruction::CallLayer {
            layer_id: 0x999,
            inputs: vec![0],
            outputs: vec![1],
        }],
        buffers: vec![
            BufferMetadata::new(16, BufferType::Input),
            BufferMetadata::new(16, BufferType::Output),
        ],
        constants: vec![],
        workspace_size: 0,
        dependencies: vec![],
        metadata: PlanMetadata {
            name: "test".into(),
            version: "1.0".into(),
            author: None,
            description: None,
        },
        node_buffer_map: vec![Some(0), Some(1)],
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let backend = CpuBackend::new();
    let input_data = vec![0u8; 16];
    let inputs: &[&[u8]] = &[&input_data];
    let mut output_data = vec![0u8; 16];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_data];

    // Should fail because no layer executor provided
    let result = backend.execute_plan(&plan, inputs, outputs);
    assert!(result.is_err());

    let err_msg = result.unwrap_err().to_string();
    assert!(
        err_msg.contains("CallLayer") || err_msg.contains("layer executor"),
        "Error should mention CallLayer: {err_msg}"
    );
}

// ============================================================================
// T5 Encoder Integration Tests (TASK-209)
// ============================================================================

/// T5 encoder self-attention block integration test.
///
/// This test validates the complete self-attention pattern used in T5/BERT transformers:
///   1. LayerNorm (pre-norm architecture)
///   2. Q, K, V linear projections (MatMul)
///   3. Attention scores: Q @ K^T (MatMul)
///   4. Softmax on attention scores
///   5. Weighted values: attention_weights @ V (MatMul)
///   6. Output projection (MatMul)
///   7. Residual connection (Add)
///
/// Uses small dimensions for tractable verification:
///   seq_len=2, hidden_dim=4
#[test]
fn test_t5_encoder_self_attention_block() {
    // Dimensions: seq_len=2, hidden_dim=4
    // This tests the complete self-attention pattern from T5/BERT encoders
    let mut graph = OperationGraph::new();
    let mut node_id = 0;

    // ========== INPUT ==========
    // Node 0: Input [2, 4] (seq_len=2, hidden=4)
    graph.add_node(OpNode::new(node_id, OpKind::Input, vec![2, 4], DType::F32));
    graph.add_input("input", node_id);
    let input_node = node_id;
    node_id += 1;

    // ========== LAYER NORM (Pre-Norm) ==========
    // Node 1: scale [4]
    graph.add_node(OpNode::new(node_id, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        1.0, 1.0, 1.0, 1.0,
    ]));
    let ln_scale = node_id;
    node_id += 1;

    // Node 2: bias [4]
    graph.add_node(OpNode::new(node_id, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        0.0, 0.0, 0.0, 0.0,
    ]));
    let ln_bias = node_id;
    node_id += 1;

    // Node 3: LayerNorm output [2, 4]
    graph.add_node(OpNode::new(
        node_id,
        OpKind::LayerNorm {
            normalized_dims: 1,
            epsilon: 1e-5,
        },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(input_node, node_id);
    graph.add_edge(ln_scale, node_id);
    graph.add_edge(ln_bias, node_id);
    let ln_output = node_id;
    node_id += 1;

    // ========== Q, K, V PROJECTIONS ==========
    // For simplicity, use identity-like weights for Q, K, V
    // Each projection: [hidden=4] -> [hidden=4]

    // Q weight [4, 4] - identity with slight variation
    graph.add_node(OpNode::new(
        node_id,
        OpKind::Constant,
        vec![4, 4],
        DType::F32,
    ));
    #[rustfmt::skip]
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        1.0, 0.0, 0.0, 0.0,
        0.0, 1.0, 0.0, 0.0,
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0,
    ]));
    let w_q = node_id;
    node_id += 1;

    // K weight [4, 4] - identity
    graph.add_node(OpNode::new(
        node_id,
        OpKind::Constant,
        vec![4, 4],
        DType::F32,
    ));
    #[rustfmt::skip]
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        1.0, 0.0, 0.0, 0.0,
        0.0, 1.0, 0.0, 0.0,
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0,
    ]));
    let w_k = node_id;
    node_id += 1;

    // V weight [4, 4] - identity
    graph.add_node(OpNode::new(
        node_id,
        OpKind::Constant,
        vec![4, 4],
        DType::F32,
    ));
    #[rustfmt::skip]
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        1.0, 0.0, 0.0, 0.0,
        0.0, 1.0, 0.0, 0.0,
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0,
    ]));
    let w_v = node_id;
    node_id += 1;

    // Q = LayerNorm @ W_Q: [2, 4] @ [4, 4] = [2, 4]
    graph.add_node(OpNode::new(
        node_id,
        OpKind::MatMul { m: 2, k: 4, n: 4 },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(ln_output, node_id);
    graph.add_edge(w_q, node_id);
    let q = node_id;
    node_id += 1;

    // K = LayerNorm @ W_K: [2, 4] @ [4, 4] = [2, 4]
    graph.add_node(OpNode::new(
        node_id,
        OpKind::MatMul { m: 2, k: 4, n: 4 },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(ln_output, node_id);
    graph.add_edge(w_k, node_id);
    let k = node_id;
    node_id += 1;

    // V = LayerNorm @ W_V: [2, 4] @ [4, 4] = [2, 4]
    graph.add_node(OpNode::new(
        node_id,
        OpKind::MatMul { m: 2, k: 4, n: 4 },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(ln_output, node_id);
    graph.add_edge(w_v, node_id);
    let v = node_id;
    node_id += 1;

    // ========== TRANSPOSE K for attention ==========
    // K^T: [2, 4] -> [4, 2] via Transpose
    graph.add_node(OpNode::new(
        node_id,
        OpKind::Transpose { perm: vec![1, 0] },
        vec![4, 2],
        DType::F32,
    ));
    graph.add_edge(k, node_id);
    let k_t = node_id;
    node_id += 1;

    // ========== ATTENTION SCORES ==========
    // Scores = Q @ K^T: [2, 4] @ [4, 2] = [2, 2]
    graph.add_node(OpNode::new(
        node_id,
        OpKind::MatMul { m: 2, k: 4, n: 2 },
        vec![2, 2],
        DType::F32,
    ));
    graph.add_edge(q, node_id);
    graph.add_edge(k_t, node_id);
    let scores = node_id;
    node_id += 1;

    // ========== SOFTMAX ==========
    // Softmax along last axis (axis=-1)
    graph.add_node(OpNode::new(
        node_id,
        OpKind::Softmax { axis: -1 },
        vec![2, 2],
        DType::F32,
    ));
    graph.add_edge(scores, node_id);
    let attn_weights = node_id;
    node_id += 1;

    // ========== WEIGHTED VALUES ==========
    // Output = Softmax @ V: [2, 2] @ [2, 4] = [2, 4]
    graph.add_node(OpNode::new(
        node_id,
        OpKind::MatMul { m: 2, k: 2, n: 4 },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(attn_weights, node_id);
    graph.add_edge(v, node_id);
    let attn_output = node_id;
    node_id += 1;

    // ========== OUTPUT PROJECTION ==========
    // W_O [4, 4] - identity
    graph.add_node(OpNode::new(
        node_id,
        OpKind::Constant,
        vec![4, 4],
        DType::F32,
    ));
    #[rustfmt::skip]
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        1.0, 0.0, 0.0, 0.0,
        0.0, 1.0, 0.0, 0.0,
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0,
    ]));
    let w_o = node_id;
    node_id += 1;

    // Projected = AttnOutput @ W_O: [2, 4] @ [4, 4] = [2, 4]
    graph.add_node(OpNode::new(
        node_id,
        OpKind::MatMul { m: 2, k: 4, n: 4 },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(attn_output, node_id);
    graph.add_edge(w_o, node_id);
    let projected = node_id;
    node_id += 1;

    // ========== RESIDUAL CONNECTION ==========
    // Add residual: output = projected + input
    graph.add_node(OpNode::new(node_id, OpKind::Add, vec![2, 4], DType::F32));
    graph.add_edge(projected, node_id);
    graph.add_edge(input_node, node_id); // Skip connection from original input
    let residual_output = node_id;
    node_id += 1;

    // ========== OUTPUT ==========
    graph.add_node(OpNode::new(node_id, OpKind::Output, vec![2, 4], DType::F32));
    graph.add_edge(residual_output, node_id);
    graph.add_output("output", node_id);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("T5 encoder compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: two sequence positions with different values
    // Row 1: [1, 2, 3, 4], Row 2: [5, 6, 7, 8]
    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 32]; // 8 f32 = 32 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("T5 encoder execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Verify output properties:
    // 1. Output has same shape as input (8 elements)
    assert_eq!(result.len(), 8, "Output should have 8 elements");

    // 2. With identity projections and softmax attention,
    //    the output should be a weighted combination of input values
    //    plus the residual connection. Values should be finite and reasonable.
    for (i, val) in result.iter().enumerate() {
        assert!(val.is_finite(), "Element {i} should be finite, got {val}");
        assert!(
            val.abs() < 100.0,
            "Element {i} should be reasonable magnitude, got {val}"
        );
    }

    // 3. The residual connection means output should contain information
    //    from the original input. With identity weights, the attention
    //    mechanism mixes the two positions, and adding residual adds
    //    the original values back.
    //
    //    Since we use identity weights:
    //    - LayerNorm normalizes each row to mean=0, var=1
    //    - Q=K=V = normalized input
    //    - Q@K^T produces attention scores
    //    - Softmax normalizes to probabilities
    //    - Softmax @ V produces weighted output
    //    - Add brings back original input

    // Verify rows have been modified from pure input
    // (attention should have mixed information between positions)
    let row1_sum: f32 = result[0..4].iter().sum();
    let row2_sum: f32 = result[4..8].iter().sum();
    let input_row1_sum: f32 = input_data[0..4].iter().sum();
    let input_row2_sum: f32 = input_data[4..8].iter().sum();

    // The sums should differ from pure input due to attention mixing
    // (though with residual they stay close)
    assert!(
        (row1_sum - input_row1_sum).abs() < 15.0,
        "Row 1 should be related to input with attention mixing"
    );
    assert!(
        (row2_sum - input_row2_sum).abs() < 15.0,
        "Row 2 should be related to input with attention mixing"
    );
}

/// Test LayerNorm -> Softmax chain (common in attention pre-processing).
#[test]
fn test_layernorm_then_softmax_chain() {
    let mut graph = OperationGraph::new();

    // Input [2, 4]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32));
    graph.add_input("input", 0);

    // LayerNorm scale
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        1.0, 1.0, 1.0, 1.0,
    ]));

    // LayerNorm bias
    graph.add_node(OpNode::new(2, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        0.0, 0.0, 0.0, 0.0,
    ]));

    // LayerNorm
    graph.add_node(OpNode::new(
        3,
        OpKind::LayerNorm {
            normalized_dims: 1,
            epsilon: 1e-5,
        },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(0, 3);
    graph.add_edge(1, 3);
    graph.add_edge(2, 3);

    // Softmax (simulates attention score normalization)
    graph.add_node(OpNode::new(
        4,
        OpKind::Softmax { axis: -1 },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(3, 4);

    // Output
    graph.add_node(OpNode::new(5, OpKind::Output, vec![2, 4], DType::F32));
    graph.add_edge(4, 5);
    graph.add_output("output", 5);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 0.0, 0.0, 0.0, 0.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 32];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Each row of softmax output should sum to 1.0
    let sum1: f32 = result[0..4].iter().sum();
    let sum2: f32 = result[4..8].iter().sum();

    assert!(
        (sum1 - 1.0).abs() < 1e-4,
        "First row softmax sum should be 1.0, got {sum1}"
    );
    assert!(
        (sum2 - 1.0).abs() < 1e-4,
        "Second row softmax sum should be 1.0, got {sum2}"
    );

    // Second row (all zeros -> normalized to mean=0, var=1) then softmax
    // should give uniform distribution since all values are equal after LayerNorm
    for val in &result[4..8] {
        assert!(
            (*val - 0.25).abs() < 1e-3,
            "Uniform row should have 0.25 per element, got {val}"
        );
    }
}

/// Test MatMul -> Add -> Softmax chain (attention score computation).
#[test]
fn test_matmul_add_softmax_attention_pattern() {
    let mut graph = OperationGraph::new();

    // Q [2, 3] (seq_len=2, head_dim=3)
    graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
    graph.add_input("q", 0);

    // K^T [3, 2] (head_dim=3, seq_len=2)
    graph.add_node(OpNode::new(1, OpKind::Input, vec![3, 2], DType::F32));
    graph.add_input("k_t", 1);

    // Attention mask [2, 2] - additive mask (0 for attend, -inf for mask)
    graph.add_node(OpNode::new(2, OpKind::Constant, vec![2, 2], DType::F32));
    #[rustfmt::skip]
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        0.0, 0.0,
        0.0, 0.0, // No masking for this test
    ]));

    // Scores = Q @ K^T: [2, 3] @ [3, 2] = [2, 2]
    graph.add_node(OpNode::new(
        3,
        OpKind::MatMul { m: 2, k: 3, n: 2 },
        vec![2, 2],
        DType::F32,
    ));
    graph.add_edge(0, 3);
    graph.add_edge(1, 3);

    // Masked scores = scores + mask
    graph.add_node(OpNode::new(4, OpKind::Add, vec![2, 2], DType::F32));
    graph.add_edge(3, 4);
    graph.add_edge(2, 4);

    // Softmax on masked scores
    graph.add_node(OpNode::new(
        5,
        OpKind::Softmax { axis: -1 },
        vec![2, 2],
        DType::F32,
    ));
    graph.add_edge(4, 5);

    // Output
    graph.add_node(OpNode::new(6, OpKind::Output, vec![2, 2], DType::F32));
    graph.add_edge(5, 6);
    graph.add_output("output", 6);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Q = [[1, 0, 0], [0, 1, 0]] - one-hot like
    let q_data: Vec<f32> = vec![1.0, 0.0, 0.0, 0.0, 1.0, 0.0];
    // K^T = [[1, 0], [0, 1], [0, 0]] - identity-like transposed
    let kt_data: Vec<f32> = vec![1.0, 0.0, 0.0, 1.0, 0.0, 0.0];

    let q_bytes = f32_to_bytes(&q_data);
    let kt_bytes = f32_to_bytes(&kt_data);

    let inputs: &[&[u8]] = &[&q_bytes, &kt_bytes];
    let mut output_bytes = vec![0u8; 16]; // 4 f32
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Q @ K^T with our inputs:
    // Row 0: [1,0,0] @ [[1,0],[0,1],[0,0]] = [1, 0]
    // Row 1: [0,1,0] @ [[1,0],[0,1],[0,0]] = [0, 1]
    // After softmax:
    // Row 0: softmax([1, 0]) = [exp(1)/(exp(1)+exp(0)), exp(0)/(exp(1)+exp(0))]
    //      ≈ [0.731, 0.269]
    // Row 1: softmax([0, 1]) = [exp(0)/(exp(0)+exp(1)), exp(1)/(exp(0)+exp(1))]
    //      ≈ [0.269, 0.731]

    // Each row should sum to 1.0
    let sum1: f32 = result[0..2].iter().sum();
    let sum2: f32 = result[2..4].iter().sum();

    assert!(
        (sum1 - 1.0).abs() < 1e-5,
        "Row 1 softmax should sum to 1.0, got {sum1}"
    );
    assert!(
        (sum2 - 1.0).abs() < 1e-5,
        "Row 2 softmax should sum to 1.0, got {sum2}"
    );

    // Verify approximate values
    let e = std::f32::consts::E;
    let expected_high = e / (e + 1.0);
    let expected_low = 1.0 / (e + 1.0);

    assert!(
        (result[0] - expected_high).abs() < 1e-4,
        "Expected ~{expected_high}, got {}",
        result[0]
    );
    assert!(
        (result[1] - expected_low).abs() < 1e-4,
        "Expected ~{expected_low}, got {}",
        result[1]
    );
}

/// Test residual connection pattern: output = LayerNorm(x) + x
#[test]
fn test_residual_connection_with_layernorm() {
    let mut graph = OperationGraph::new();

    // Input [2, 4]
    graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32));
    graph.add_input("input", 0);

    // LayerNorm scale
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        1.0, 1.0, 1.0, 1.0,
    ]));

    // LayerNorm bias
    graph.add_node(OpNode::new(2, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        0.0, 0.0, 0.0, 0.0,
    ]));

    // LayerNorm
    graph.add_node(OpNode::new(
        3,
        OpKind::LayerNorm {
            normalized_dims: 1,
            epsilon: 1e-5,
        },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(0, 3);
    graph.add_edge(1, 3);
    graph.add_edge(2, 3);

    // Residual: LayerNorm(x) + x
    graph.add_node(OpNode::new(4, OpKind::Add, vec![2, 4], DType::F32));
    graph.add_edge(3, 4); // LayerNorm output
    graph.add_edge(0, 4); // Original input (skip connection)

    // Output
    graph.add_node(OpNode::new(5, OpKind::Output, vec![2, 4], DType::F32));
    graph.add_edge(4, 5);
    graph.add_output("output", 5);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Execute
    let backend = CpuBackend::new();

    let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 32];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let result = bytes_to_f32(&output_bytes);

    // LayerNorm of [1,2,3,4]: mean=2.5, std≈1.118
    // Normalized: [-1.34, -0.45, 0.45, 1.34] approximately
    // Result: normalized + original = [-1.34+1, -0.45+2, 0.45+3, 1.34+4]
    //       = [-0.34, 1.55, 3.45, 5.34] approximately

    // Verify each row has the residual pattern
    for row in 0..2 {
        let start = row * 4;
        let row_data = &result[start..start + 4];
        let input_row = &input_data[start..start + 4];

        // The result should be different from input (LayerNorm effect)
        // but still correlated (residual preserves information)
        let input_sum: f32 = input_row.iter().sum();
        let output_sum: f32 = row_data.iter().sum();

        // Sum should be close to input sum (since LayerNorm has mean 0, it just adds 0)
        assert!(
            (output_sum - input_sum).abs() < 0.5,
            "Row {row}: output sum should be close to input sum"
        );

        // Each element should be finite
        for (i, val) in row_data.iter().enumerate() {
            assert!(
                val.is_finite(),
                "Row {row}, element {i} should be finite, got {val}"
            );
        }
    }
}

// ============================================================================
// BERT-Style Attention Tests (TASK-210)
// ============================================================================

/// BERT-style multi-head attention test.
///
/// Tests the complete multi-head attention pattern:
///   1. Input [seq_len=4, hidden=4]
///   2. Split into 2 heads: 2 x [seq_len=4, head_dim=2]
///   3. Compute attention per head
///   4. Concat heads back: [seq_len=4, hidden=4]
///
/// This validates Slice for head splitting and Concat for merging.
#[test]
fn test_bert_multi_head_attention() {
    // Dimensions: seq_len=4, hidden=4, num_heads=2, head_dim=2
    let mut graph = OperationGraph::new();

    // Input [4, 4] - 4 sequence positions, 4 hidden dims
    graph.add_node(OpNode::new(0, OpKind::Input, vec![4, 4], DType::F32));
    graph.add_input("input", 0);

    // Split into 2 heads using Slice operations
    // Head 0: columns 0-1 (first 2 dims)
    graph.add_node(OpNode::new(
        1,
        OpKind::Slice {
            starts: vec![0, 0],
            ends: vec![4, 2],
            steps: vec![1, 1],
        },
        vec![4, 2],
        DType::F32,
    ));
    graph.add_edge(0, 1);

    // Head 1: columns 2-3 (last 2 dims)
    graph.add_node(OpNode::new(
        2,
        OpKind::Slice {
            starts: vec![0, 2],
            ends: vec![4, 4],
            steps: vec![1, 1],
        },
        vec![4, 2],
        DType::F32,
    ));
    graph.add_edge(0, 2);

    // For each head, compute self-attention: softmax(Q @ K^T) @ V
    // Here we use the head itself as Q, K, V (simplified self-attention)

    // Head 0: Transpose for K^T [4,2] -> [2,4]
    graph.add_node(OpNode::new(
        3,
        OpKind::Transpose { perm: vec![1, 0] },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(1, 3);

    // Head 0: Q @ K^T = [4,2] @ [2,4] = [4,4]
    graph.add_node(OpNode::new(
        4,
        OpKind::MatMul { m: 4, k: 2, n: 4 },
        vec![4, 4],
        DType::F32,
    ));
    graph.add_edge(1, 4); // Q
    graph.add_edge(3, 4); // K^T

    // Head 0: Softmax
    graph.add_node(OpNode::new(
        5,
        OpKind::Softmax { axis: -1 },
        vec![4, 4],
        DType::F32,
    ));
    graph.add_edge(4, 5);

    // Head 0: Attention @ V = [4,4] @ [4,2] = [4,2]
    graph.add_node(OpNode::new(
        6,
        OpKind::MatMul { m: 4, k: 4, n: 2 },
        vec![4, 2],
        DType::F32,
    ));
    graph.add_edge(5, 6); // Attention weights
    graph.add_edge(1, 6); // V (same as input head)

    // Head 1: Transpose for K^T [4,2] -> [2,4]
    graph.add_node(OpNode::new(
        7,
        OpKind::Transpose { perm: vec![1, 0] },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(2, 7);

    // Head 1: Q @ K^T = [4,2] @ [2,4] = [4,4]
    graph.add_node(OpNode::new(
        8,
        OpKind::MatMul { m: 4, k: 2, n: 4 },
        vec![4, 4],
        DType::F32,
    ));
    graph.add_edge(2, 8); // Q
    graph.add_edge(7, 8); // K^T

    // Head 1: Softmax
    graph.add_node(OpNode::new(
        9,
        OpKind::Softmax { axis: -1 },
        vec![4, 4],
        DType::F32,
    ));
    graph.add_edge(8, 9);

    // Head 1: Attention @ V = [4,4] @ [4,2] = [4,2]
    graph.add_node(OpNode::new(
        10,
        OpKind::MatMul { m: 4, k: 4, n: 2 },
        vec![4, 2],
        DType::F32,
    ));
    graph.add_edge(9, 10); // Attention weights
    graph.add_edge(2, 10); // V (same as input head)

    // Concat heads: [4,2] + [4,2] -> [4,4] along axis 1
    graph.add_node(OpNode::new(
        11,
        OpKind::Concat {
            axis: 1,
            num_inputs: 2,
        },
        vec![4, 4],
        DType::F32,
    ));
    graph.add_edge(6, 11); // Head 0 output
    graph.add_edge(10, 11); // Head 1 output

    // Output
    graph.add_node(OpNode::new(12, OpKind::Output, vec![4, 4], DType::F32));
    graph.add_edge(11, 12);
    graph.add_output("output", 12);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("Multi-head attention compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Input: 4 positions with 4 features each
    #[rustfmt::skip]
    let input_data: Vec<f32> = vec![
        1.0, 2.0, 3.0, 4.0,   // Position 0
        2.0, 3.0, 4.0, 5.0,   // Position 1
        3.0, 4.0, 5.0, 6.0,   // Position 2
        4.0, 5.0, 6.0, 7.0,   // Position 3
    ];
    let input_bytes = f32_to_bytes(&input_data);

    let inputs: &[&[u8]] = &[&input_bytes];
    let mut output_bytes = vec![0u8; 64]; // 16 f32 = 64 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("Multi-head attention execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Verify output shape (16 elements = 4x4)
    assert_eq!(result.len(), 16, "Output should have 16 elements");

    // Each row should be a valid attention-weighted combination
    for row in 0..4 {
        let start = row * 4;
        let row_data = &result[start..start + 4];

        // All values should be finite
        for (i, val) in row_data.iter().enumerate() {
            assert!(
                val.is_finite(),
                "Row {row}, col {i} should be finite, got {val}"
            );
        }

        // Values should be in reasonable range (attention-weighted means of input)
        for (i, val) in row_data.iter().enumerate() {
            assert!(
                *val >= 0.0 && *val <= 10.0,
                "Row {row}, col {i} should be in [0, 10], got {val}"
            );
        }
    }
}

/// Test attention with causal mask (lower triangular).
///
/// Causal masking prevents attending to future positions:
///   Position 0 can only attend to position 0
///   Position 1 can attend to positions 0, 1
///   Position 2 can attend to positions 0, 1, 2
///   etc.
///
/// This is critical for autoregressive models like GPT.
#[test]
fn test_attention_with_causal_mask() {
    let mut graph = OperationGraph::new();

    // Q [3, 2] - 3 positions, head_dim=2
    graph.add_node(OpNode::new(0, OpKind::Input, vec![3, 2], DType::F32));
    graph.add_input("q", 0);

    // K [3, 2] - same shape as Q
    graph.add_node(OpNode::new(1, OpKind::Input, vec![3, 2], DType::F32));
    graph.add_input("k", 1);

    // V [3, 2] - same shape
    graph.add_node(OpNode::new(2, OpKind::Input, vec![3, 2], DType::F32));
    graph.add_input("v", 2);

    // Causal mask [3, 3] - additive mask with -inf for future positions
    // Lower triangular: [[0, -inf, -inf], [0, 0, -inf], [0, 0, 0]]
    graph.add_node(OpNode::new(3, OpKind::Constant, vec![3, 3], DType::F32));
    #[rustfmt::skip]
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        0.0,        -1e9, -1e9,  // Pos 0: only attend to 0
        0.0,         0.0, -1e9,  // Pos 1: attend to 0, 1
        0.0,         0.0,  0.0,  // Pos 2: attend to all
    ]));

    // K^T [2, 3]
    graph.add_node(OpNode::new(
        4,
        OpKind::Transpose { perm: vec![1, 0] },
        vec![2, 3],
        DType::F32,
    ));
    graph.add_edge(1, 4);

    // Scores = Q @ K^T = [3, 2] @ [2, 3] = [3, 3]
    graph.add_node(OpNode::new(
        5,
        OpKind::MatMul { m: 3, k: 2, n: 3 },
        vec![3, 3],
        DType::F32,
    ));
    graph.add_edge(0, 5);
    graph.add_edge(4, 5);

    // Masked scores = scores + causal_mask
    graph.add_node(OpNode::new(6, OpKind::Add, vec![3, 3], DType::F32));
    graph.add_edge(5, 6);
    graph.add_edge(3, 6);

    // Softmax on masked scores
    graph.add_node(OpNode::new(
        7,
        OpKind::Softmax { axis: -1 },
        vec![3, 3],
        DType::F32,
    ));
    graph.add_edge(6, 7);

    // Attention output = softmax @ V = [3, 3] @ [3, 2] = [3, 2]
    graph.add_node(OpNode::new(
        8,
        OpKind::MatMul { m: 3, k: 3, n: 2 },
        vec![3, 2],
        DType::F32,
    ));
    graph.add_edge(7, 8);
    graph.add_edge(2, 8);

    // Output
    graph.add_node(OpNode::new(9, OpKind::Output, vec![3, 2], DType::F32));
    graph.add_edge(8, 9);
    graph.add_output("output", 9);

    // Also output attention weights for verification
    graph.add_node(OpNode::new(10, OpKind::Output, vec![3, 3], DType::F32));
    graph.add_edge(7, 10);
    graph.add_output("attention_weights", 10);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("Causal attention compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Q, K, V all same for simplicity
    #[rustfmt::skip]
    let qkv_data: Vec<f32> = vec![
        1.0, 0.0,  // Position 0
        0.0, 1.0,  // Position 1
        1.0, 1.0,  // Position 2
    ];
    let qkv_bytes = f32_to_bytes(&qkv_data);

    let inputs: &[&[u8]] = &[&qkv_bytes, &qkv_bytes, &qkv_bytes];
    let mut output_bytes = vec![0u8; 24]; // 6 f32 = 24 bytes
    let mut attn_weights_bytes = vec![0u8; 36]; // 9 f32 = 36 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes, &mut attn_weights_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("Causal attention execution failed");

    let attn_weights = bytes_to_f32(&attn_weights_bytes);

    // Verify causal masking in attention weights:
    // Row 0: future positions (1, 2) should have ~0 attention
    // Row 1: future position (2) should have ~0 attention
    // Row 2: can attend to all positions

    // Row 0: future positions should be masked (near zero)
    assert!(
        attn_weights[1] < 1e-3,
        "Position 0 should not attend to future position 1, got {}",
        attn_weights[1]
    );
    assert!(
        attn_weights[2] < 1e-3,
        "Position 0 should not attend to future position 2, got {}",
        attn_weights[2]
    );

    // Row 1: future position 2 should be masked
    assert!(
        attn_weights[5] < 1e-3,
        "Position 1 should not attend to future position 2, got {}",
        attn_weights[5]
    );

    // Each row should sum to 1.0 (valid probability distribution)
    for row in 0..3 {
        let start = row * 3;
        let row_sum: f32 = attn_weights[start..start + 3].iter().sum();
        assert!(
            (row_sum - 1.0).abs() < 1e-4,
            "Row {row} attention should sum to 1.0, got {row_sum}"
        );
    }
}

/// Test attention with padding mask.
///
/// Padding mask zeros out attention to padded positions.
/// This is used when batch processing sequences of different lengths.
#[test]
fn test_attention_with_padding_mask() {
    let mut graph = OperationGraph::new();

    // Attention scores [2, 4] - 2 queries, 4 keys
    // Simulating a case where positions 2 and 3 are padding
    graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32));
    graph.add_input("scores", 0);

    // Padding mask [2, 4] - 0 for valid, -inf for padding
    // Positions 2, 3 are masked out
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![2, 4], DType::F32));
    #[rustfmt::skip]
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        0.0, 0.0, -1e9, -1e9,  // Query 0: can attend to positions 0, 1
        0.0, 0.0, -1e9, -1e9,  // Query 1: can attend to positions 0, 1
    ]));

    // Masked scores = scores + mask
    graph.add_node(OpNode::new(2, OpKind::Add, vec![2, 4], DType::F32));
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);

    // Softmax
    graph.add_node(OpNode::new(
        3,
        OpKind::Softmax { axis: -1 },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(2, 3);

    // Output
    graph.add_node(OpNode::new(4, OpKind::Output, vec![2, 4], DType::F32));
    graph.add_edge(3, 4);
    graph.add_output("output", 4);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("Padding mask compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Attention scores before masking - all positions have similar scores
    #[rustfmt::skip]
    let scores_data: Vec<f32> = vec![
        1.0, 1.0, 1.0, 1.0,  // Query 0
        2.0, 2.0, 2.0, 2.0,  // Query 1
    ];
    let scores_bytes = f32_to_bytes(&scores_data);

    let inputs: &[&[u8]] = &[&scores_bytes];
    let mut output_bytes = vec![0u8; 32]; // 8 f32 = 32 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("Padding mask execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Verify padding mask effect:
    // Positions 2 and 3 should have ~0 attention weight
    // Positions 0 and 1 should share the attention (each ~0.5)

    for row in 0..2 {
        let start = row * 4;

        // Positions 0 and 1 should have ~equal weight (0.5 each)
        assert!(
            (result[start] - 0.5).abs() < 1e-4,
            "Row {row}, pos 0 should be ~0.5, got {}",
            result[start]
        );
        assert!(
            (result[start + 1] - 0.5).abs() < 1e-4,
            "Row {row}, pos 1 should be ~0.5, got {}",
            result[start + 1]
        );

        // Positions 2 and 3 should be ~0 (masked)
        assert!(
            result[start + 2] < 1e-4,
            "Row {row}, pos 2 should be ~0 (masked), got {}",
            result[start + 2]
        );
        assert!(
            result[start + 3] < 1e-4,
            "Row {row}, pos 3 should be ~0 (masked), got {}",
            result[start + 3]
        );

        // Row should sum to 1.0
        let row_sum: f32 = result[start..start + 4].iter().sum();
        assert!(
            (row_sum - 1.0).abs() < 1e-5,
            "Row {row} should sum to 1.0, got {row_sum}"
        );
    }
}

/// Test scaled dot-product attention (the complete BERT attention formula).
///
/// Attention(Q, K, V) = softmax(Q @ K^T / sqrt(d_k)) @ V
///
/// This test validates the full formula with scaling.
#[test]
fn test_scaled_dot_product_attention() {
    let mut graph = OperationGraph::new();

    // Q [2, 4] - 2 queries, head_dim=4
    graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 4], DType::F32));
    graph.add_input("q", 0);

    // K [3, 4] - 3 keys, head_dim=4
    graph.add_node(OpNode::new(1, OpKind::Input, vec![3, 4], DType::F32));
    graph.add_input("k", 1);

    // V [3, 4] - 3 values, head_dim=4
    graph.add_node(OpNode::new(2, OpKind::Input, vec![3, 4], DType::F32));
    graph.add_input("v", 2);

    // Scale factor: 1/sqrt(d_k) = 1/sqrt(4) = 0.5
    // Shape [2, 3] to match matmul output for element-wise multiplication
    graph.add_node(OpNode::new(3, OpKind::Constant, vec![2, 3], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![
        0.5, 0.5, 0.5, 0.5, 0.5, 0.5,
    ])); // 1/sqrt(4) broadcast to [2,3]

    // K^T [4, 3]
    graph.add_node(OpNode::new(
        4,
        OpKind::Transpose { perm: vec![1, 0] },
        vec![4, 3],
        DType::F32,
    ));
    graph.add_edge(1, 4);

    // Scores = Q @ K^T = [2, 4] @ [4, 3] = [2, 3]
    graph.add_node(OpNode::new(
        5,
        OpKind::MatMul { m: 2, k: 4, n: 3 },
        vec![2, 3],
        DType::F32,
    ));
    graph.add_edge(0, 5);
    graph.add_edge(4, 5);

    // Scaled scores = scores * scale (broadcast multiply)
    graph.add_node(OpNode::new(6, OpKind::Mul, vec![2, 3], DType::F32));
    graph.add_edge(5, 6);
    graph.add_edge(3, 6);

    // Softmax
    graph.add_node(OpNode::new(
        7,
        OpKind::Softmax { axis: -1 },
        vec![2, 3],
        DType::F32,
    ));
    graph.add_edge(6, 7);

    // Output = softmax @ V = [2, 3] @ [3, 4] = [2, 4]
    graph.add_node(OpNode::new(
        8,
        OpKind::MatMul { m: 2, k: 3, n: 4 },
        vec![2, 4],
        DType::F32,
    ));
    graph.add_edge(7, 8);
    graph.add_edge(2, 8);

    // Output
    graph.add_node(OpNode::new(9, OpKind::Output, vec![2, 4], DType::F32));
    graph.add_edge(8, 9);
    graph.add_output("output", 9);

    // Also output attention weights
    graph.add_node(OpNode::new(10, OpKind::Output, vec![2, 3], DType::F32));
    graph.add_edge(7, 10);
    graph.add_output("attention", 10);

    // Compile
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("Scaled attention compilation failed");

    // Execute
    let backend = CpuBackend::new();

    // Q: 2 queries
    #[rustfmt::skip]
    let q_data: Vec<f32> = vec![
        1.0, 0.0, 0.0, 0.0,  // Query 0: one-hot position 0
        0.0, 1.0, 0.0, 0.0,  // Query 1: one-hot position 1
    ];

    // K: 3 keys
    #[rustfmt::skip]
    let k_data: Vec<f32> = vec![
        1.0, 0.0, 0.0, 0.0,  // Key 0: matches query 0
        0.0, 1.0, 0.0, 0.0,  // Key 1: matches query 1
        0.0, 0.0, 1.0, 0.0,  // Key 2: matches neither
    ];

    // V: 3 values with distinct patterns
    #[rustfmt::skip]
    let v_data: Vec<f32> = vec![
        1.0, 1.0, 1.0, 1.0,  // Value 0
        2.0, 2.0, 2.0, 2.0,  // Value 1
        3.0, 3.0, 3.0, 3.0,  // Value 2
    ];

    let q_bytes = f32_to_bytes(&q_data);
    let k_bytes = f32_to_bytes(&k_data);
    let v_bytes = f32_to_bytes(&v_data);

    let inputs: &[&[u8]] = &[&q_bytes, &k_bytes, &v_bytes];
    let mut output_bytes = vec![0u8; 32]; // 8 f32 = 32 bytes
    let mut attn_bytes = vec![0u8; 24]; // 6 f32 = 24 bytes
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes, &mut attn_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("Scaled attention execution failed");

    let output = bytes_to_f32(&output_bytes);
    let attn_weights = bytes_to_f32(&attn_bytes);

    // Verify attention weights sum to 1.0 per row
    for row in 0..2 {
        let start = row * 3;
        let row_sum: f32 = attn_weights[start..start + 3].iter().sum();
        assert!(
            (row_sum - 1.0).abs() < 1e-5,
            "Row {row} attention should sum to 1.0, got {row_sum}"
        );
    }

    // With one-hot Q and K, the attention for query 0 should favor key 0,
    // and query 1 should favor key 1 (due to dot product similarity)
    // The scaling by 0.5 softens the distribution but maintains the preference

    // Query 0 should have highest attention on key 0
    assert!(
        attn_weights[0] > attn_weights[1] && attn_weights[0] > attn_weights[2],
        "Query 0 should attend most to key 0"
    );

    // Query 1 should have highest attention on key 1
    assert!(
        attn_weights[4] > attn_weights[3] && attn_weights[4] > attn_weights[5],
        "Query 1 should attend most to key 1"
    );

    // Output should be valid (finite, reasonable range)
    for (i, val) in output.iter().enumerate() {
        assert!(val.is_finite(), "Output {i} should be finite, got {val}");
        assert!(
            *val >= 0.5 && *val <= 3.5,
            "Output {i} should be weighted average of V values [1,2,3], got {val}"
        );
    }
}

// ============================================================================
// LUT-GEMM Quantization Tests
// ============================================================================

/// Test compile and execute MatMul with constant weights and LUT-GEMM quantization.
///
/// This tests the full LUT-GEMM pipeline:
/// 1. Compiler identifies MatMul with constant weights
/// 2. Quantization pass clusters weights to 16 centroids (Q4)
/// 3. Assembly emits MatMulLUT instruction
/// 4. Backend executes via Psumbook lookup
#[test]
fn test_compile_and_execute_matmul_lut_q4() {
    use hologram_compiler::QuantizeConfig;
    use hologram_holo::IsaInstruction;

    // Build graph: C = A @ W (where W is constant)
    // A: [4, 8] input activations
    // W: [8, 4] constant weights
    // C: [4, 4] output
    let m = 4;
    let k = 8;
    let n = 4;

    let mut graph = OperationGraph::new();

    // Node 0: Input activations [4, 8]
    let input_a = OpNode::new(0, OpKind::Input, vec![m, k], DType::F32);
    graph.add_node(input_a);

    // Node 1: Constant weights [8, 4]
    // Use weights with clear clustering to ensure Q4 is chosen
    let weights: Vec<f32> = (0..(k * n))
        .map(|i| {
            // Create clustered weights: 4 distinct value ranges
            let cluster = (i % 4) as f32;
            cluster * 0.25 + 0.1
        })
        .collect();
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![k, n], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(weights.clone()));

    // Node 2: MatMul [4, 4]
    let matmul = OpNode::new(2, OpKind::MatMul { m, k, n }, vec![m, n], DType::F32);
    graph.add_node(matmul);

    // Node 3: Output [4, 4]
    let output = OpNode::new(3, OpKind::Output, vec![m, n], DType::F32);
    graph.add_node(output);

    graph.add_edge(0, 2); // A -> MatMul
    graph.add_edge(1, 2); // W -> MatMul
    graph.add_edge(2, 3); // MatMul -> Output

    graph.add_input("a", 0);
    graph.add_output("c", 3);

    // Compile with quantization enabled
    let config = CompilerConfig {
        quantize: QuantizeConfig::enabled(),
        ..Default::default()
    };
    let plan = compile(&graph, &config).expect("compilation with LUT-GEMM failed");

    // Verify the plan contains a MatMulLUT instruction
    let has_matmul_lut = plan
        .instructions
        .iter()
        .any(|instr| matches!(instr, IsaInstruction::MatMulLUT { .. }));
    assert!(
        has_matmul_lut,
        "Plan should contain MatMulLUT instruction when quantization is enabled"
    );

    // Execute the plan
    let backend = CpuBackend::new();

    // Input A: simple identity-ish pattern
    let a_data: Vec<f32> = (0..(m * k)).map(|i| (i as f32) * 0.1).collect();
    let a_bytes = f32_to_bytes(&a_data);

    let inputs: &[&[u8]] = &[&a_bytes];
    let mut output_bytes = vec![0u8; m * n * 4]; // 4 bytes per f32
    let outputs: &mut [&mut [u8]] = &mut [&mut output_bytes];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("LUT-GEMM execution failed");

    let result = bytes_to_f32(&output_bytes);

    // Compute expected result using regular matmul
    let mut expected = vec![0.0f32; m * n];
    for i in 0..m {
        for j in 0..n {
            let mut sum = 0.0;
            for l in 0..k {
                sum += a_data[i * k + l] * weights[l * n + j];
            }
            expected[i * n + j] = sum;
        }
    }

    // LUT-GEMM introduces quantization error, so we use a relaxed tolerance
    // Q4 (16 centroids) typically has 5-15% relative error
    for (i, (r, e)) in result.iter().zip(expected.iter()).enumerate() {
        let abs_err = (r - e).abs();
        let rel_err = if e.abs() > 0.001 {
            abs_err / e.abs()
        } else {
            abs_err
        };
        assert!(
            rel_err < 0.25 || abs_err < 0.1,
            "Output[{i}]: expected {e}, got {r} (rel_err={rel_err:.2}, abs_err={abs_err:.4})"
        );
    }
}

/// Test that compilation without quantization produces standard MatMul.
#[test]
fn test_compile_matmul_without_quantization() {
    use hologram_holo::IsaInstruction;

    // Same graph as above but with quantization disabled
    let m = 4;
    let k = 8;
    let n = 4;

    let mut graph = OperationGraph::new();

    graph.add_node(OpNode::new(0, OpKind::Input, vec![m, k], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![k, n], DType::F32));
    graph.add_constant(hologram_compiler::ConstantData::F32(vec![1.0; k * n]));
    graph.add_node(OpNode::new(
        2,
        OpKind::MatMul { m, k, n },
        vec![m, n],
        DType::F32,
    ));
    graph.add_node(OpNode::new(3, OpKind::Output, vec![m, n], DType::F32));

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph.add_input("a", 0);
    graph.add_output("c", 3);

    // Compile with quantization DISABLED (default)
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Verify no MatMulLUT instruction
    let has_matmul_lut = plan
        .instructions
        .iter()
        .any(|instr| matches!(instr, IsaInstruction::MatMulLUT { .. }));
    assert!(
        !has_matmul_lut,
        "Plan should NOT contain MatMulLUT when quantization is disabled"
    );

    // Should have regular MatMul
    let has_matmul = plan
        .instructions
        .iter()
        .any(|instr| matches!(instr, IsaInstruction::MatMul { .. }));
    assert!(has_matmul, "Plan should contain regular MatMul instruction");
}

// ============================================================================
// SHA-256 End-to-End Tests
// ============================================================================

/// Build an 80-byte Bitcoin-style block header for testing.
fn make_test_block_header() -> [u8; 80] {
    let mut header = [0u8; 80];
    // version = 2 (little-endian)
    header[0..4].copy_from_slice(&2u32.to_le_bytes());
    // prev_block_hash (32 bytes) — arbitrary test data
    for (i, b) in header[4..36].iter_mut().enumerate() {
        *b = (i as u8).wrapping_mul(7);
    }
    // merkle_root (32 bytes)
    for (i, b) in header[36..68].iter_mut().enumerate() {
        *b = (i as u8).wrapping_mul(13).wrapping_add(1);
    }
    // timestamp
    header[68..72].copy_from_slice(&1_700_000_000u32.to_le_bytes());
    // bits
    header[72..76].copy_from_slice(&0x1d00_ffffu32.to_le_bytes());
    // nonce
    header[76..80].copy_from_slice(&42u32.to_le_bytes());
    header
}

#[test]
fn test_execute_sha256_80byte_input() {
    use hologram_holo::IsaInstruction;

    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![80], DType::U8);
    let sha = OpNode::new(1, OpKind::Sha256 { src_len: 80 }, vec![32], DType::U8);
    let output = OpNode::new(2, OpKind::Output, vec![32], DType::U8);

    graph.add_node(input);
    graph.add_node(sha);
    graph.add_node(output);
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_input("header", 0);
    graph.add_output("hash", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Verify instruction
    assert!(plan
        .instructions
        .iter()
        .any(|i| matches!(i, IsaInstruction::Sha256 { src_len: 80, .. })));

    // Execute
    let backend = CpuBackend::new();
    let header = make_test_block_header();
    let inputs: &[&[u8]] = &[&header];
    let mut output_buf = vec![0u8; 32];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_buf];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    // Verify against direct SHA-256
    let expected = hologram_sha256::sha256(&header);
    assert_eq!(&output_buf, expected.as_ref(), "SHA-256 hash mismatch");
}

#[test]
fn test_execute_double_sha256_80byte_input() {
    use hologram_holo::IsaInstruction;

    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![80], DType::U8);
    let dsha = OpNode::new(1, OpKind::DoubleSha256 { src_len: 80 }, vec![32], DType::U8);
    let output = OpNode::new(2, OpKind::Output, vec![32], DType::U8);

    graph.add_node(input);
    graph.add_node(dsha);
    graph.add_node(output);
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_input("header", 0);
    graph.add_output("hash", 2);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    assert!(plan
        .instructions
        .iter()
        .any(|i| matches!(i, IsaInstruction::DoubleSha256 { src_len: 80, .. })));

    let backend = CpuBackend::new();
    let header = make_test_block_header();
    let inputs: &[&[u8]] = &[&header];
    let mut output_buf = vec![0u8; 32];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_buf];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let expected = hologram_sha256::double_sha256(&header);
    assert_eq!(
        &output_buf,
        expected.as_ref(),
        "Double SHA-256 hash mismatch"
    );
}

#[test]
fn test_execute_sha256_chain_fuses_to_double() {
    use hologram_holo::IsaInstruction;

    // Input -> Sha256 -> Sha256 -> Output
    // Should fuse to DoubleSha256
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![80], DType::U8);
    let sha1 = OpNode::new(1, OpKind::Sha256 { src_len: 80 }, vec![32], DType::U8);
    let sha2 = OpNode::new(2, OpKind::Sha256 { src_len: 32 }, vec![32], DType::U8);
    let output = OpNode::new(3, OpKind::Output, vec![32], DType::U8);

    graph.add_node(input);
    graph.add_node(sha1);
    graph.add_node(sha2);
    graph.add_node(output);
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph.add_input("header", 0);
    graph.add_output("hash", 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Verify fusion: should be DoubleSha256, not two separate Sha256
    assert!(plan
        .instructions
        .iter()
        .any(|i| matches!(i, IsaInstruction::DoubleSha256 { src_len: 80, .. })));
    assert!(
        !plan
            .instructions
            .iter()
            .any(|i| matches!(i, IsaInstruction::Sha256 { .. })),
        "Chain should be fused — no standalone Sha256"
    );

    // Execute and verify correctness
    let backend = CpuBackend::new();
    let header = make_test_block_header();
    let inputs: &[&[u8]] = &[&header];
    let mut output_buf = vec![0u8; 32];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_buf];

    backend
        .execute_plan(&plan, inputs, outputs)
        .expect("execution failed");

    let expected = hologram_sha256::double_sha256(&header);
    assert_eq!(
        &output_buf,
        expected.as_ref(),
        "Fused chain should match double SHA-256"
    );
}

#[test]
fn test_execute_sha256_various_sizes() {
    for input_size in [32, 64, 80, 128, 256] {
        let mut graph = OperationGraph::new();

        let input = OpNode::new(0, OpKind::Input, vec![input_size], DType::U8);
        let sha = OpNode::new(
            1,
            OpKind::Sha256 {
                src_len: input_size,
            },
            vec![32],
            DType::U8,
        );
        let output = OpNode::new(2, OpKind::Output, vec![32], DType::U8);

        graph.add_node(input);
        graph.add_node(sha);
        graph.add_node(output);
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_input("data", 0);
        graph.add_output("hash", 2);

        let plan = compile(&graph, &CompilerConfig::default()).expect("compilation failed");
        let backend = CpuBackend::new();

        let data: Vec<u8> = (0..input_size).map(|i| (i & 0xFF) as u8).collect();
        let inputs: &[&[u8]] = &[&data];
        let mut output_buf = vec![0u8; 32];
        let outputs: &mut [&mut [u8]] = &mut [&mut output_buf];

        backend
            .execute_plan(&plan, inputs, outputs)
            .unwrap_or_else(|e| panic!("execution failed for {input_size}B: {e}"));

        let expected = hologram_sha256::sha256(&data);
        assert_eq!(
            &output_buf,
            expected.as_ref(),
            "SHA-256 mismatch for {input_size}-byte input"
        );
    }
}
