import { useState, useRef } from "react";
import { User, Plus, Camera, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

export function AvatarUpload({
  avatarUrl,
  onAvatarChange,
}: {
  avatarUrl?: string;
  onAvatarChange: (url: string) => void;
}) {
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast({ title: "Please select an image file", variant: "destructive" });
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "Image must be under 5MB", variant: "destructive" });
      return;
    }

    setUploading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast({ title: "Please sign in first", variant: "destructive" });
        return;
      }

      const userId = session.user.id;
      const ext = file.name.split(".").pop() || "jpg";
      const filePath = `${userId}/avatar.${ext}`;

      const { error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from("avatars")
        .getPublicUrl(filePath);

      const url = `${publicUrl}?t=${Date.now()}`;

      await supabase
        .from("profiles")
        .update({ avatar_url: url })
        .eq("user_id", userId);

      onAvatarChange(url);
      toast({ title: "Profile picture updated" });
    } catch (err: any) {
      console.error("Avatar upload error:", err);
      toast({ title: "Failed to upload profile picture", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="relative shrink-0">
      <div className="absolute inset-0 rounded-full bg-sanctuary-glow/30 blur-2xl scale-150" />
      <div className="relative flex h-28 w-28 sm:h-32 sm:w-32 items-center justify-center rounded-full bg-background border-4 border-background shadow-lg">
        {avatarUrl ? (
          <img
            src={avatarUrl}
            alt="Your profile"
            className="h-full w-full rounded-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center rounded-full bg-primary/10 border border-primary/15">
            <User className="h-12 w-12 sm:h-14 sm:w-14 text-primary/60" />
          </div>
        )}
        <button
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          className={`absolute bottom-0 right-0 flex items-center justify-center w-8 h-8 rounded-full 
            bg-background border-2 border-background shadow-md
            transition-all duration-500 disabled:opacity-50
            ${avatarUrl 
              ? "bg-muted/80 text-foreground/50 hover:text-foreground hover:bg-muted" 
              : "bg-primary/15 text-primary animate-pulse-gold"
            }`}
        >
          {uploading ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : avatarUrl ? (
            <Camera className="h-3.5 w-3.5" />
          ) : (
            <Plus className="h-4 w-4" />
          )}
        </button>
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  );
}
