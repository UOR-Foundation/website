//! Parser edge case and robustness tests.
//!
//! Tests syntax edge cases, error paths, and full real-file parsing
//! that complement the inline unit tests in parse.rs.

/// An empty shell body should parse to zero items.
#[test]
fn empty_shell_body() {
    let shell = hologram_shell::parse_shell("shell empty {}").unwrap();
    assert_eq!(shell.name, "empty");
    assert!(shell.items.is_empty());
}

/// A shell with only comments should parse to zero items.
#[test]
fn shell_with_only_comments() {
    let input = r#"
shell commented {
    # This is a comment
    # Another comment
}
"#;
    let shell = hologram_shell::parse_shell(input).unwrap();
    assert_eq!(shell.name, "commented");
    assert!(shell.items.is_empty());
}

/// Nested fields (2 levels) should parse correctly.
#[test]
fn deeply_nested_type_field() {
    let input = r#"
shell nested {
    type Outer(value: u8) {
        inner {
            leaf: u8 = some_func(value)
        }
    }
}
"#;
    let shell = hologram_shell::parse_shell(input).unwrap();
    let types: Vec<_> = shell
        .items
        .iter()
        .filter_map(|i| match i {
            hologram_shell::ast::ShellItem::Type(t) => Some(t),
            _ => None,
        })
        .collect();
    assert_eq!(types.len(), 1);
    assert_eq!(types[0].fields.len(), 1); // "inner" group
    assert_eq!(types[0].fields[0].name, "inner");
    assert_eq!(types[0].fields[0].children.len(), 1); // "leaf" inside inner
    assert_eq!(types[0].fields[0].children[0].name, "leaf");
}

/// Multiple annotations on a single op should all be parsed.
#[test]
fn multiple_annotations_on_op() {
    let input = r#"
shell multi_annot {
    op fancy(dst: buf, src: buf, count: usize) @builder @variant("Fancy") @kernel("ElementWise")
}
"#;
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ops: Vec<_> = shell
        .items
        .iter()
        .filter_map(|i| match i {
            hologram_shell::ast::ShellItem::Op(o) => Some(o),
            _ => None,
        })
        .collect();
    assert_eq!(ops.len(), 1);
    assert!(ops[0]
        .annotations
        .iter()
        .any(|a| matches!(a, hologram_shell::ast::Annotation::Builder)));
    assert!(ops[0]
        .annotations
        .iter()
        .any(|a| matches!(a, hologram_shell::ast::Annotation::Variant(v) if v == "Fancy")));
    assert!(ops[0]
        .annotations
        .iter()
        .any(|a| matches!(a, hologram_shell::ast::Annotation::Kernel(k) if k == "ElementWise")));
}

/// Group without trailing comma parses correctly.
#[test]
fn group_members_no_trailing_comma() {
    let input = r#"
shell notrail {
    group ops(dst: buf, a: buf, b: buf, count: usize) {
        add,
        sub
    }
}
"#;
    let shell = hologram_shell::parse_shell(input).unwrap();
    let groups: Vec<_> = shell
        .items
        .iter()
        .filter_map(|i| match i {
            hologram_shell::ast::ShellItem::Group(g) => Some(g),
            _ => None,
        })
        .collect();
    assert_eq!(groups.len(), 1);
    assert_eq!(groups[0].members.len(), 2);
}

/// Hex literal defaults should parse correctly.
#[test]
fn hex_literal_in_default() {
    let input = r#"
shell hex {
    op fill(dst: buf, count: usize, pattern: u32 = 0xFF)
}
"#;
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ops: Vec<_> = shell
        .items
        .iter()
        .filter_map(|i| match i {
            hologram_shell::ast::ShellItem::Op(o) => Some(o),
            _ => None,
        })
        .collect();
    assert_eq!(ops.len(), 1);

    let pattern_param = ops[0]
        .params
        .iter()
        .filter_map(|p| match p {
            hologram_shell::ast::OpParam::Simple(param) => Some(param),
            _ => None,
        })
        .find(|p| p.name == "pattern")
        .expect("should have pattern param");

    assert_eq!(
        pattern_param.default,
        Some(hologram_shell::ast::DefaultValue::Int(255))
    );
}

/// Float defaults with scientific notation should parse correctly.
#[test]
fn float_default_in_param() {
    let input = r#"
shell floats {
    op norm(dst: buf, src: buf, count: usize, epsilon: f32 = 1e-5)
}
"#;
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ops: Vec<_> = shell
        .items
        .iter()
        .filter_map(|i| match i {
            hologram_shell::ast::ShellItem::Op(o) => Some(o),
            _ => None,
        })
        .collect();
    assert_eq!(ops.len(), 1);

    let epsilon = ops[0]
        .params
        .iter()
        .filter_map(|p| match p {
            hologram_shell::ast::OpParam::Simple(param) => Some(param),
            _ => None,
        })
        .find(|p| p.name == "epsilon")
        .expect("should have epsilon param");

    match &epsilon.default {
        Some(hologram_shell::ast::DefaultValue::Float(v)) => {
            assert!(
                (v - 1e-5).abs() < 1e-10,
                "epsilon default should be 1e-5, got {v}"
            );
        }
        other => panic!("expected Float default, got {other:?}"),
    }
}

/// The full isa.shell file (271 lines) should parse and produce the expected counts.
#[test]
fn real_isa_shell_round_trip() {
    let input = include_str!("../../../descriptors/shells/isa.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    assert_eq!(shell.name, "isa");

    let ops = hologram_shell::emit_isa::resolve_ops(&shell);
    assert_eq!(ops.len(), 68, "isa.shell should produce 68 ops");

    let composes: Vec<_> = shell
        .items
        .iter()
        .filter(|i| matches!(i, hologram_shell::ast::ShellItem::Compose(_)))
        .collect();
    assert_eq!(
        composes.len(),
        2,
        "isa.shell should have 2 compose definitions"
    );
}

/// Module path annotation should be preserved.
#[test]
fn module_path_annotation() {
    let input = r#"
shell custom @module("my::custom::path") {
    type Foo(value: u8) {
        bar: u8 = bar_func(value)
    }
}
"#;
    let shell = hologram_shell::parse_shell(input).unwrap();
    assert_eq!(shell.module_path.as_deref(), Some("my::custom::path"));
}
