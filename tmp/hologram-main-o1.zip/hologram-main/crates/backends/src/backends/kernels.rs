//! GPU kernel code generation for compute backends.
//!
//! This module provides kernel templates that generate valid shader/kernel code for:
//! - WGSL shaders for WebGPU
//! - CUDA kernels (CUDA C)
//! - Metal shaders (MSL)
//!
//! # Architecture
//!
//! ISA operations are mapped to GPU kernels:
//!
//! | ISA Operation | Kernel Type | Notes |
//! |--------------|-------------|-------|
//! | Add, Sub, Mul | Element-wise | 1:1 element mapping |
//! | ReLU, Sigmoid, Tanh | Element-wise | Unary activation functions |
//! | MatMul | Tiled | 32x32 blocks with shared memory |
//! | Sum, Max, Min | Tree reduction | Log(N) parallel reduction |
//!
//! # Usage
//!
//! ```rust
//! use hologram_backend::backends::kernels::{ElementWiseTemplate, KernelLanguage};
//!
//! let template = ElementWiseTemplate::new("add", KernelLanguage::Wgsl);
//! let wgsl_code = template.generate();
//! // wgsl_code is valid WGSL that performs element-wise addition
//! ```

/// Kernel language target.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum KernelLanguage {
    /// WebGPU Shading Language
    Wgsl,
    /// NVIDIA CUDA (C or PTX)
    Cuda,
    /// Apple Metal Shading Language
    Metal,
}

impl KernelLanguage {
    /// Get the file extension for this language.
    #[must_use]
    pub const fn extension(&self) -> &'static str {
        match self {
            Self::Wgsl => "wgsl",
            Self::Cuda => "cu",
            Self::Metal => "metal",
        }
    }

    /// Get the language name.
    #[must_use]
    pub const fn name(&self) -> &'static str {
        match self {
            Self::Wgsl => "WGSL",
            Self::Cuda => "CUDA",
            Self::Metal => "Metal",
        }
    }
}

/// Kernel template for element-wise operations.
///
/// Element-wise operations apply the same function to each element
/// independently (Add, Sub, Mul, ReLU, Sigmoid, etc.).
#[derive(Debug, Clone)]
pub struct ElementWiseTemplate {
    /// Operation name (e.g., "add", "relu")
    pub operation: &'static str,
    /// Target language
    pub language: KernelLanguage,
}

impl ElementWiseTemplate {
    /// Create a new element-wise template.
    #[must_use]
    pub const fn new(operation: &'static str, language: KernelLanguage) -> Self {
        Self {
            operation,
            language,
        }
    }

    /// Generate the kernel source code (stub).
    ///
    /// Returns a placeholder template. Full implementation pending.
    #[must_use]
    pub fn generate(&self) -> String {
        match self.language {
            KernelLanguage::Wgsl => self.generate_wgsl(),
            KernelLanguage::Cuda => self.generate_cuda(),
            KernelLanguage::Metal => self.generate_metal(),
        }
    }

    fn generate_wgsl(&self) -> String {
        let op_code = match self.operation {
            "add" => "output[idx] = input_a[idx] + input_b[idx];",
            "sub" => "output[idx] = input_a[idx] - input_b[idx];",
            "mul" => "output[idx] = input_a[idx] * input_b[idx];",
            "relu" => "output[idx] = max(input_a[idx], 0.0);",
            "sigmoid" => "output[idx] = 1.0 / (1.0 + exp(-input_a[idx]));",
            "tanh" => "output[idx] = tanh(input_a[idx]);",
            _ => "output[idx] = input_a[idx]; // Unsupported operation",
        };

        format!(
            r"// WGSL kernel for {op}
@group(0) @binding(0) var<storage, read> input_a: array<f32>;
@group(0) @binding(1) var<storage, read> input_b: array<f32>;
@group(0) @binding(2) var<storage, read_write> output: array<f32>;
@group(0) @binding(3) var<uniform> n: u32;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {{
    let idx = id.x;
    if (idx >= n) {{
        return;
    }}
    {op_code}
}}
",
            op = self.operation,
            op_code = op_code
        )
    }

    fn generate_cuda(&self) -> String {
        let op_code = match self.operation {
            "add" => "output[idx] = input_a[idx] + input_b[idx];",
            "sub" => "output[idx] = input_a[idx] - input_b[idx];",
            "mul" => "output[idx] = input_a[idx] * input_b[idx];",
            "relu" => "output[idx] = fmaxf(input_a[idx], 0.0f);",
            "sigmoid" => "output[idx] = 1.0f / (1.0f + expf(-input_a[idx]));",
            "tanh" => "output[idx] = tanhf(input_a[idx]);",
            _ => "output[idx] = input_a[idx]; // Unsupported operation",
        };

        format!(
            r"// CUDA kernel for {op}
__global__ void {op}_kernel(
    const float* __restrict__ input_a,
    const float* __restrict__ input_b,
    float* __restrict__ output,
    int n
) {{
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) {{
        {op_code}
    }}
}}

// Launch configuration helper
inline void launch_{op}_kernel(
    const float* input_a,
    const float* input_b,
    float* output,
    int n,
    cudaStream_t stream = 0
) {{
    int threads = 256;
    int blocks = (n + threads - 1) / threads;
    {op}_kernel<<<blocks, threads, 0, stream>>>(input_a, input_b, output, n);
}}
",
            op = self.operation,
            op_code = op_code
        )
    }

    fn generate_metal(&self) -> String {
        let op_code = match self.operation {
            "add" => "output[idx] = input_a[idx] + input_b[idx];",
            "sub" => "output[idx] = input_a[idx] - input_b[idx];",
            "mul" => "output[idx] = input_a[idx] * input_b[idx];",
            "relu" => "output[idx] = max(input_a[idx], 0.0f);",
            "sigmoid" => "output[idx] = 1.0f / (1.0f + exp(-input_a[idx]));",
            "tanh" => "output[idx] = tanh(input_a[idx]);",
            _ => "output[idx] = input_a[idx]; // Unsupported operation",
        };

        format!(
            r"// Metal kernel for {op}
#include <metal_stdlib>
using namespace metal;

kernel void {op}_kernel(
    device const float* input_a [[buffer(0)]],
    device const float* input_b [[buffer(1)]],
    device float* output [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint idx [[thread_position_in_grid]]
) {{
    if (idx >= n) {{
        return;
    }}
    {op_code}
}}
",
            op = self.operation,
            op_code = op_code
        )
    }
}

/// Kernel template for matrix multiplication.
///
/// Uses tiled algorithm with shared memory for efficiency.
#[derive(Debug, Clone)]
pub struct MatMulTemplate {
    /// Target language
    pub language: KernelLanguage,
    /// Tile size (typically 16 or 32)
    pub tile_size: u32,
}

impl MatMulTemplate {
    /// Create a new matmul template.
    #[must_use]
    pub const fn new(language: KernelLanguage, tile_size: u32) -> Self {
        Self {
            language,
            tile_size,
        }
    }

    /// Generate the kernel source code (stub).
    #[must_use]
    pub fn generate(&self) -> String {
        match self.language {
            KernelLanguage::Wgsl => self.generate_wgsl(),
            KernelLanguage::Cuda => self.generate_cuda(),
            KernelLanguage::Metal => self.generate_metal(),
        }
    }

    fn generate_wgsl(&self) -> String {
        format!(
            r"// WGSL tiled matmul kernel
// Computes C = A * B where A is MxK, B is KxN, C is MxN
// Tile size: {tile}x{tile}

struct Dimensions {{
    M: u32,
    N: u32,
    K: u32,
    _pad: u32,
}}

@group(0) @binding(0) var<storage, read> A: array<f32>;
@group(0) @binding(1) var<storage, read> B: array<f32>;
@group(0) @binding(2) var<storage, read_write> C: array<f32>;
@group(0) @binding(3) var<uniform> dims: Dimensions;

var<workgroup> tile_A: array<f32, {tile_sq}>;
var<workgroup> tile_B: array<f32, {tile_sq}>;

const TILE_SIZE: u32 = {tile}u;

@compute @workgroup_size({tile}, {tile})
fn main(
    @builtin(global_invocation_id) global_id: vec3<u32>,
    @builtin(local_invocation_id) local_id: vec3<u32>,
    @builtin(workgroup_id) group_id: vec3<u32>
) {{
    let row = global_id.y;
    let col = global_id.x;
    let local_row = local_id.y;
    let local_col = local_id.x;

    var acc: f32 = 0.0;

    // Number of tiles along K dimension
    let num_tiles = (dims.K + TILE_SIZE - 1u) / TILE_SIZE;

    for (var t: u32 = 0u; t < num_tiles; t = t + 1u) {{
        // Load tile of A into shared memory
        let a_col = t * TILE_SIZE + local_col;
        if (row < dims.M && a_col < dims.K) {{
            tile_A[local_row * TILE_SIZE + local_col] = A[row * dims.K + a_col];
        }} else {{
            tile_A[local_row * TILE_SIZE + local_col] = 0.0;
        }}

        // Load tile of B into shared memory
        let b_row = t * TILE_SIZE + local_row;
        if (b_row < dims.K && col < dims.N) {{
            tile_B[local_row * TILE_SIZE + local_col] = B[b_row * dims.N + col];
        }} else {{
            tile_B[local_row * TILE_SIZE + local_col] = 0.0;
        }}

        workgroupBarrier();

        // Compute partial dot product for this tile
        for (var k: u32 = 0u; k < TILE_SIZE; k = k + 1u) {{
            acc = acc + tile_A[local_row * TILE_SIZE + k] * tile_B[k * TILE_SIZE + local_col];
        }}

        workgroupBarrier();
    }}

    // Write result
    if (row < dims.M && col < dims.N) {{
        C[row * dims.N + col] = acc;
    }}
}}
",
            tile = self.tile_size,
            tile_sq = self.tile_size * self.tile_size
        )
    }

    fn generate_cuda(&self) -> String {
        format!(
            r"// CUDA tiled matmul kernel
// Computes C = A * B where A is MxK, B is KxN, C is MxN
// Tile size: {tile}x{tile}

#define TILE_SIZE {tile}

__global__ void matmul_kernel(
    const float* __restrict__ A,
    const float* __restrict__ B,
    float* __restrict__ C,
    int M, int N, int K
) {{
    __shared__ float tile_A[TILE_SIZE][TILE_SIZE];
    __shared__ float tile_B[TILE_SIZE][TILE_SIZE];

    int row = blockIdx.y * TILE_SIZE + threadIdx.y;
    int col = blockIdx.x * TILE_SIZE + threadIdx.x;
    int local_row = threadIdx.y;
    int local_col = threadIdx.x;

    float acc = 0.0f;

    // Number of tiles along K dimension
    int num_tiles = (K + TILE_SIZE - 1) / TILE_SIZE;

    for (int t = 0; t < num_tiles; t++) {{
        // Load tile of A into shared memory
        int a_col = t * TILE_SIZE + local_col;
        if (row < M && a_col < K) {{
            tile_A[local_row][local_col] = A[row * K + a_col];
        }} else {{
            tile_A[local_row][local_col] = 0.0f;
        }}

        // Load tile of B into shared memory
        int b_row = t * TILE_SIZE + local_row;
        if (b_row < K && col < N) {{
            tile_B[local_row][local_col] = B[b_row * N + col];
        }} else {{
            tile_B[local_row][local_col] = 0.0f;
        }}

        __syncthreads();

        // Compute partial dot product for this tile
        #pragma unroll
        for (int k = 0; k < TILE_SIZE; k++) {{
            acc += tile_A[local_row][k] * tile_B[k][local_col];
        }}

        __syncthreads();
    }}

    // Write result
    if (row < M && col < N) {{
        C[row * N + col] = acc;
    }}
}}

// Launch configuration helper
inline void launch_matmul_kernel(
    const float* A,
    const float* B,
    float* C,
    int M, int N, int K,
    cudaStream_t stream = 0
) {{
    dim3 threads(TILE_SIZE, TILE_SIZE);
    dim3 blocks((N + TILE_SIZE - 1) / TILE_SIZE, (M + TILE_SIZE - 1) / TILE_SIZE);
    matmul_kernel<<<blocks, threads, 0, stream>>>(A, B, C, M, N, K);
}}
",
            tile = self.tile_size
        )
    }

    fn generate_metal(&self) -> String {
        format!(
            r"// Metal tiled matmul kernel
// Computes C = A * B where A is MxK, B is KxN, C is MxN
// Tile size: {tile}x{tile}

#include <metal_stdlib>
using namespace metal;

#define TILE_SIZE {tile}

struct Dimensions {{
    uint M;
    uint N;
    uint K;
    uint _pad;
}};

kernel void matmul_kernel(
    device const float* A [[buffer(0)]],
    device const float* B [[buffer(1)]],
    device float* C [[buffer(2)]],
    constant Dimensions& dims [[buffer(3)]],
    uint2 gid [[thread_position_in_grid]],
    uint2 lid [[thread_position_in_threadgroup]],
    uint2 group_id [[threadgroup_position_in_grid]]
) {{
    threadgroup float tile_A[TILE_SIZE][TILE_SIZE];
    threadgroup float tile_B[TILE_SIZE][TILE_SIZE];

    uint row = gid.y;
    uint col = gid.x;
    uint local_row = lid.y;
    uint local_col = lid.x;

    float acc = 0.0f;

    // Number of tiles along K dimension
    uint num_tiles = (dims.K + TILE_SIZE - 1) / TILE_SIZE;

    for (uint t = 0; t < num_tiles; t++) {{
        // Load tile of A into shared memory
        uint a_col = t * TILE_SIZE + local_col;
        if (row < dims.M && a_col < dims.K) {{
            tile_A[local_row][local_col] = A[row * dims.K + a_col];
        }} else {{
            tile_A[local_row][local_col] = 0.0f;
        }}

        // Load tile of B into shared memory
        uint b_row = t * TILE_SIZE + local_row;
        if (b_row < dims.K && col < dims.N) {{
            tile_B[local_row][local_col] = B[b_row * dims.N + col];
        }} else {{
            tile_B[local_row][local_col] = 0.0f;
        }}

        threadgroup_barrier(mem_flags::mem_threadgroup);

        // Compute partial dot product for this tile
        for (uint k = 0; k < TILE_SIZE; k++) {{
            acc += tile_A[local_row][k] * tile_B[k][local_col];
        }}

        threadgroup_barrier(mem_flags::mem_threadgroup);
    }}

    // Write result
    if (row < dims.M && col < dims.N) {{
        C[row * dims.N + col] = acc;
    }}
}}
",
            tile = self.tile_size
        )
    }
}

/// Kernel template for reduction operations.
///
/// Uses tree reduction pattern for Sum, Max, Min, etc.
#[derive(Debug, Clone)]
pub struct ReductionTemplate {
    /// Operation (e.g., "sum", "max", "min")
    pub operation: &'static str,
    /// Target language
    pub language: KernelLanguage,
}

impl ReductionTemplate {
    /// Create a new reduction template.
    #[must_use]
    pub const fn new(operation: &'static str, language: KernelLanguage) -> Self {
        Self {
            operation,
            language,
        }
    }

    /// Generate the kernel source code (stub).
    #[must_use]
    pub fn generate(&self) -> String {
        match self.language {
            KernelLanguage::Wgsl => self.generate_wgsl(),
            KernelLanguage::Cuda => self.generate_cuda(),
            KernelLanguage::Metal => self.generate_metal(),
        }
    }

    /// Get the reduction operation expression for WGSL.
    fn wgsl_reduce_op(&self) -> &'static str {
        match self.operation {
            "sum" => "shared_data[tid] = shared_data[tid] + shared_data[tid + stride];",
            "max" => "shared_data[tid] = max(shared_data[tid], shared_data[tid + stride]);",
            "min" => "shared_data[tid] = min(shared_data[tid], shared_data[tid + stride]);",
            _ => "shared_data[tid] = shared_data[tid]; // Unsupported operation",
        }
    }

    /// Get the identity value for this reduction in WGSL.
    fn wgsl_identity(&self) -> &'static str {
        match self.operation {
            "max" => "-3.402823e+38", // -FLT_MAX approximation
            "min" => "3.402823e+38",  // FLT_MAX approximation
            // sum and other ops use 0.0 as identity
            _ => "0.0",
        }
    }

    fn generate_wgsl(&self) -> String {
        format!(
            r"// WGSL tree reduction kernel for {op}
// Reduces input array to one value per workgroup

@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<f32>;
@group(0) @binding(2) var<uniform> n: u32;

var<workgroup> shared_data: array<f32, 256>;

const WORKGROUP_SIZE: u32 = 256u;

@compute @workgroup_size(256)
fn main(
    @builtin(global_invocation_id) global_id: vec3<u32>,
    @builtin(local_invocation_id) local_id: vec3<u32>,
    @builtin(workgroup_id) group_id: vec3<u32>
) {{
    let tid = local_id.x;
    let gid = global_id.x;

    // Load to shared memory with bounds check
    if (gid < n) {{
        shared_data[tid] = input[gid];
    }} else {{
        shared_data[tid] = {identity};
    }}
    workgroupBarrier();

    // Tree reduction
    var stride: u32 = WORKGROUP_SIZE / 2u;
    while (stride > 0u) {{
        if (tid < stride) {{
            {reduce_op}
        }}
        workgroupBarrier();
        stride = stride / 2u;
    }}

    // Write result
    if (tid == 0u) {{
        output[group_id.x] = shared_data[0];
    }}
}}
",
            op = self.operation,
            reduce_op = self.wgsl_reduce_op(),
            identity = self.wgsl_identity()
        )
    }

    /// Get the reduction operation expression for CUDA.
    fn cuda_reduce_op(&self) -> &'static str {
        match self.operation {
            "sum" => "shared_data[tid] = shared_data[tid] + shared_data[tid + stride];",
            "max" => "shared_data[tid] = fmaxf(shared_data[tid], shared_data[tid + stride]);",
            "min" => "shared_data[tid] = fminf(shared_data[tid], shared_data[tid + stride]);",
            _ => "shared_data[tid] = shared_data[tid]; // Unsupported operation",
        }
    }

    /// Get the identity value for this reduction in CUDA.
    fn cuda_identity(&self) -> &'static str {
        match self.operation {
            "max" => "-FLT_MAX",
            "min" => "FLT_MAX",
            // sum and other ops use 0.0f as identity
            _ => "0.0f",
        }
    }

    fn generate_cuda(&self) -> String {
        format!(
            r"// CUDA tree reduction kernel for {op}
// Reduces input array to one value per block
#include <float.h>

#define BLOCK_SIZE 256

__global__ void {op}_reduce_kernel(
    const float* __restrict__ input,
    float* __restrict__ output,
    int n
) {{
    __shared__ float shared_data[BLOCK_SIZE];

    int tid = threadIdx.x;
    int gid = blockIdx.x * blockDim.x + threadIdx.x;

    // Load to shared memory with bounds check
    shared_data[tid] = (gid < n) ? input[gid] : {identity};
    __syncthreads();

    // Tree reduction (unrolled for common sizes)
    #pragma unroll
    for (int stride = BLOCK_SIZE / 2; stride > 0; stride >>= 1) {{
        if (tid < stride) {{
            {reduce_op}
        }}
        __syncthreads();
    }}

    // Write result
    if (tid == 0) {{
        output[blockIdx.x] = shared_data[0];
    }}
}}

// Launch configuration helper
inline void launch_{op}_reduce_kernel(
    const float* input,
    float* output,
    int n,
    cudaStream_t stream = 0
) {{
    int threads = BLOCK_SIZE;
    int blocks = (n + threads - 1) / threads;
    {op}_reduce_kernel<<<blocks, threads, 0, stream>>>(input, output, n);
}}
",
            op = self.operation,
            reduce_op = self.cuda_reduce_op(),
            identity = self.cuda_identity()
        )
    }

    /// Get the reduction operation expression for Metal.
    fn metal_reduce_op(&self) -> &'static str {
        match self.operation {
            "sum" => "shared_data[tid] = shared_data[tid] + shared_data[tid + stride];",
            "max" => "shared_data[tid] = max(shared_data[tid], shared_data[tid + stride]);",
            "min" => "shared_data[tid] = min(shared_data[tid], shared_data[tid + stride]);",
            _ => "shared_data[tid] = shared_data[tid]; // Unsupported operation",
        }
    }

    /// Get the identity value for this reduction in Metal.
    fn metal_identity(&self) -> &'static str {
        match self.operation {
            "max" => "-FLT_MAX",
            "min" => "FLT_MAX",
            // sum and other ops use 0.0f as identity
            _ => "0.0f",
        }
    }

    fn generate_metal(&self) -> String {
        format!(
            r"// Metal tree reduction kernel for {op}
// Reduces input array to one value per threadgroup
#include <metal_stdlib>
using namespace metal;

#define THREADGROUP_SIZE 256

kernel void {op}_reduce_kernel(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_index_in_threadgroup]],
    uint gid [[thread_position_in_grid]],
    uint group_id [[threadgroup_position_in_grid]]
) {{
    threadgroup float shared_data[THREADGROUP_SIZE];

    // Load to shared memory with bounds check
    shared_data[tid] = (gid < n) ? input[gid] : {identity};
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Tree reduction
    for (uint stride = THREADGROUP_SIZE / 2; stride > 0; stride >>= 1) {{
        if (tid < stride) {{
            {reduce_op}
        }}
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }}

    // Write result
    if (tid == 0) {{
        output[group_id] = shared_data[0];
    }}
}}
",
            op = self.operation,
            reduce_op = self.metal_reduce_op(),
            identity = self.metal_identity()
        )
    }
}

// ============================================================================
// Categorical Kernel Templates (LUT-Based O(1) Operations)
// ============================================================================

/// Kernel template for categorical operations using precomputed LUTs.
///
/// These kernels implement O(1) operations using lookup tables:
/// - `mod_96`: 256-byte table for modulo reduction
/// - `ring_add`: 96x96 addition table (9KB)
/// - `ring_mul`: 96x96 multiplication table (9KB)
/// - `torus_page`: 256-byte table for page mapping
/// - `orbit_class`: 256-byte table for orbit classification
///
/// LUT data is passed as GPU buffer bindings for efficient access.
#[derive(Debug, Clone)]
pub struct CategoricalTemplate {
    /// Operation: "ring_add", "ring_mul", "lift", "orbit_classify"
    pub operation: &'static str,
    /// Target language
    pub language: KernelLanguage,
}

impl CategoricalTemplate {
    /// Create a new categorical template.
    #[must_use]
    pub const fn new(operation: &'static str, language: KernelLanguage) -> Self {
        Self {
            operation,
            language,
        }
    }

    /// Generate the kernel source code.
    #[must_use]
    pub fn generate(&self) -> String {
        match self.language {
            KernelLanguage::Wgsl => self.generate_wgsl(),
            KernelLanguage::Cuda => self.generate_cuda(),
            KernelLanguage::Metal => self.generate_metal(),
        }
    }

    fn generate_wgsl(&self) -> String {
        match self.operation {
            "ring_add" => self.generate_ring_add_wgsl(),
            "ring_mul" => self.generate_ring_mul_wgsl(),
            "lift" => self.generate_lift_wgsl(),
            "orbit_classify" => self.generate_orbit_classify_wgsl(),
            _ => format!("// Unsupported categorical operation: {}", self.operation),
        }
    }

    fn generate_cuda(&self) -> String {
        match self.operation {
            "ring_add" => self.generate_ring_add_cuda(),
            "ring_mul" => self.generate_ring_mul_cuda(),
            "lift" => self.generate_lift_cuda(),
            "orbit_classify" => self.generate_orbit_classify_cuda(),
            _ => format!("// Unsupported categorical operation: {}", self.operation),
        }
    }

    fn generate_metal(&self) -> String {
        match self.operation {
            "ring_add" => self.generate_ring_add_metal(),
            "ring_mul" => self.generate_ring_mul_metal(),
            "lift" => self.generate_lift_metal(),
            "orbit_classify" => self.generate_orbit_classify_metal(),
            _ => format!("// Unsupported categorical operation: {}", self.operation),
        }
    }

    // ========================================================================
    // Ring Addition (WGSL/CUDA/Metal)
    // ========================================================================

    fn generate_ring_add_wgsl(&self) -> String {
        r"// WGSL O(1) ring addition using LUT
// Ring operation: dst[i] = (a[i] + b[i]) mod 96
// Uses precomputed MOD_96 (256 bytes) and RING_ADD (96x96 = 9KB) tables

@group(0) @binding(0) var<storage, read> input_a: array<u32>;
@group(0) @binding(1) var<storage, read> input_b: array<u32>;
@group(0) @binding(2) var<storage, read_write> output: array<u32>;
@group(0) @binding(3) var<storage, read> mod_96_lut: array<u32>;      // 256 bytes
@group(0) @binding(4) var<storage, read> ring_add_lut: array<u32>;    // 96x96 bytes
@group(0) @binding(5) var<uniform> n: u32;

const RING_SIZE: u32 = 96u;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    let idx = id.x;
    if (idx >= n) {
        return;
    }

    // O(1) LUT lookups - no runtime arithmetic
    let a_val = input_a[idx] & 0xFFu;
    let b_val = input_b[idx] & 0xFFu;

    // First reduce to ring domain via LUT
    let a_mod = mod_96_lut[a_val];
    let b_mod = mod_96_lut[b_val];

    // Then O(1) ring addition via 96x96 LUT
    let result = ring_add_lut[a_mod * RING_SIZE + b_mod];

    output[idx] = result;
}
"
        .to_string()
    }

    fn generate_ring_add_cuda(&self) -> String {
        r"// CUDA O(1) ring addition using LUT
// Ring operation: dst[i] = (a[i] + b[i]) mod 96
// Uses precomputed MOD_96 (256 bytes) and RING_ADD (96x96 = 9KB) tables

#define RING_SIZE 96

__constant__ unsigned char d_mod_96[256];      // Device constant memory for mod table
__constant__ unsigned char d_ring_add[9216];   // 96x96 ring addition table

__global__ void ring_add_lut_kernel(
    const unsigned char* __restrict__ input_a,
    const unsigned char* __restrict__ input_b,
    unsigned char* __restrict__ output,
    int n
) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) {
        // O(1) LUT lookups - no runtime arithmetic
        unsigned char a_mod = d_mod_96[input_a[idx]];
        unsigned char b_mod = d_mod_96[input_b[idx]];
        output[idx] = d_ring_add[a_mod * RING_SIZE + b_mod];
    }
}

// Host function to initialize LUT tables in constant memory
void init_ring_add_lut(const unsigned char* mod_96, const unsigned char* ring_add) {
    cudaMemcpyToSymbol(d_mod_96, mod_96, 256);
    cudaMemcpyToSymbol(d_ring_add, ring_add, 9216);
}

inline void launch_ring_add_kernel(
    const unsigned char* a, const unsigned char* b, unsigned char* out,
    int n, cudaStream_t stream = 0
) {
    int threads = 256;
    int blocks = (n + threads - 1) / threads;
    ring_add_lut_kernel<<<blocks, threads, 0, stream>>>(a, b, out, n);
}
"
        .to_string()
    }

    fn generate_ring_add_metal(&self) -> String {
        r"// Metal O(1) ring addition using LUT
// Ring operation: dst[i] = (a[i] + b[i]) mod 96

#include <metal_stdlib>
using namespace metal;

constant uint RING_SIZE = 96;

kernel void ring_add_lut_kernel(
    device const uchar* input_a [[buffer(0)]],
    device const uchar* input_b [[buffer(1)]],
    device uchar* output [[buffer(2)]],
    device const uchar* mod_96_lut [[buffer(3)]],
    device const uchar* ring_add_lut [[buffer(4)]],
    constant uint& n [[buffer(5)]],
    uint idx [[thread_position_in_grid]]
) {
    if (idx >= n) {
        return;
    }

    // O(1) LUT lookups
    uchar a_mod = mod_96_lut[input_a[idx]];
    uchar b_mod = mod_96_lut[input_b[idx]];
    output[idx] = ring_add_lut[a_mod * RING_SIZE + b_mod];
}
"
        .to_string()
    }

    // ========================================================================
    // Ring Multiplication (WGSL/CUDA/Metal)
    // ========================================================================

    fn generate_ring_mul_wgsl(&self) -> String {
        r"// WGSL O(1) ring multiplication using LUT
// Ring operation: dst[i] = (a[i] * b[i]) mod 96

@group(0) @binding(0) var<storage, read> input_a: array<u32>;
@group(0) @binding(1) var<storage, read> input_b: array<u32>;
@group(0) @binding(2) var<storage, read_write> output: array<u32>;
@group(0) @binding(3) var<storage, read> mod_96_lut: array<u32>;
@group(0) @binding(4) var<storage, read> ring_mul_lut: array<u32>;
@group(0) @binding(5) var<uniform> n: u32;

const RING_SIZE: u32 = 96u;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    let idx = id.x;
    if (idx >= n) {
        return;
    }

    let a_val = input_a[idx] & 0xFFu;
    let b_val = input_b[idx] & 0xFFu;

    let a_mod = mod_96_lut[a_val];
    let b_mod = mod_96_lut[b_val];

    output[idx] = ring_mul_lut[a_mod * RING_SIZE + b_mod];
}
"
        .to_string()
    }

    fn generate_ring_mul_cuda(&self) -> String {
        r"// CUDA O(1) ring multiplication using LUT

#define RING_SIZE 96

__constant__ unsigned char d_mod_96[256];
__constant__ unsigned char d_ring_mul[9216];

__global__ void ring_mul_lut_kernel(
    const unsigned char* __restrict__ input_a,
    const unsigned char* __restrict__ input_b,
    unsigned char* __restrict__ output,
    int n
) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) {
        unsigned char a_mod = d_mod_96[input_a[idx]];
        unsigned char b_mod = d_mod_96[input_b[idx]];
        output[idx] = d_ring_mul[a_mod * RING_SIZE + b_mod];
    }
}

void init_ring_mul_lut(const unsigned char* mod_96, const unsigned char* ring_mul) {
    cudaMemcpyToSymbol(d_mod_96, mod_96, 256);
    cudaMemcpyToSymbol(d_ring_mul, ring_mul, 9216);
}

inline void launch_ring_mul_kernel(
    const unsigned char* a, const unsigned char* b, unsigned char* out,
    int n, cudaStream_t stream = 0
) {
    int threads = 256;
    int blocks = (n + threads - 1) / threads;
    ring_mul_lut_kernel<<<blocks, threads, 0, stream>>>(a, b, out, n);
}
"
        .to_string()
    }

    fn generate_ring_mul_metal(&self) -> String {
        r"// Metal O(1) ring multiplication using LUT

#include <metal_stdlib>
using namespace metal;

constant uint RING_SIZE = 96;

kernel void ring_mul_lut_kernel(
    device const uchar* input_a [[buffer(0)]],
    device const uchar* input_b [[buffer(1)]],
    device uchar* output [[buffer(2)]],
    device const uchar* mod_96_lut [[buffer(3)]],
    device const uchar* ring_mul_lut [[buffer(4)]],
    constant uint& n [[buffer(5)]],
    uint idx [[thread_position_in_grid]]
) {
    if (idx >= n) {
        return;
    }

    uchar a_mod = mod_96_lut[input_a[idx]];
    uchar b_mod = mod_96_lut[input_b[idx]];
    output[idx] = ring_mul_lut[a_mod * RING_SIZE + b_mod];
}
"
        .to_string()
    }

    // ========================================================================
    // Lift Operation (WGSL/CUDA/Metal)
    // ========================================================================

    fn generate_lift_wgsl(&self) -> String {
        r"// WGSL O(1) lift operation using LUT
// Maps bytes to torus coordinates: page = torus_page_lut[byte], offset = byte
// Output is PackedCell: upper 8 bits = page, lower 8 bits = offset

@group(0) @binding(0) var<storage, read> input: array<u32>;
@group(0) @binding(1) var<storage, read_write> output: array<u32>;
@group(0) @binding(2) var<storage, read> torus_page_lut: array<u32>;  // 256 bytes
@group(0) @binding(3) var<uniform> n: u32;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    let idx = id.x;
    if (idx >= n) {
        return;
    }

    let byte_val = input[idx] & 0xFFu;

    // O(1) LUT lookup for page
    let page = torus_page_lut[byte_val];

    // PackedCell: page in high byte, offset (original byte) in low byte
    output[idx] = (page << 8u) | byte_val;
}
"
        .to_string()
    }

    fn generate_lift_cuda(&self) -> String {
        r"// CUDA O(1) lift operation using LUT

__constant__ unsigned char d_torus_page[256];

__global__ void lift_lut_kernel(
    const unsigned char* __restrict__ input,
    unsigned short* __restrict__ output,  // PackedCell as u16
    int n
) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) {
        unsigned char byte_val = input[idx];
        unsigned char page = d_torus_page[byte_val];
        // PackedCell: page in high byte, offset in low byte
        output[idx] = ((unsigned short)page << 8) | byte_val;
    }
}

void init_lift_lut(const unsigned char* torus_page) {
    cudaMemcpyToSymbol(d_torus_page, torus_page, 256);
}

inline void launch_lift_kernel(
    const unsigned char* input, unsigned short* output,
    int n, cudaStream_t stream = 0
) {
    int threads = 256;
    int blocks = (n + threads - 1) / threads;
    lift_lut_kernel<<<blocks, threads, 0, stream>>>(input, output, n);
}
"
        .to_string()
    }

    fn generate_lift_metal(&self) -> String {
        r"// Metal O(1) lift operation using LUT

#include <metal_stdlib>
using namespace metal;

kernel void lift_lut_kernel(
    device const uchar* input [[buffer(0)]],
    device ushort* output [[buffer(1)]],
    device const uchar* torus_page_lut [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint idx [[thread_position_in_grid]]
) {
    if (idx >= n) {
        return;
    }

    uchar byte_val = input[idx];
    uchar page = torus_page_lut[byte_val];
    output[idx] = (ushort(page) << 8) | byte_val;
}
"
        .to_string()
    }

    // ========================================================================
    // Orbit Classification (WGSL/CUDA/Metal)
    // ========================================================================

    fn generate_orbit_classify_wgsl(&self) -> String {
        r"// WGSL O(1) orbit classification using LUT
// Maps bytes to orbit class (0..31) via precomputed table

@group(0) @binding(0) var<storage, read> input: array<u32>;
@group(0) @binding(1) var<storage, read_write> output: array<u32>;
@group(0) @binding(2) var<storage, read> orbit_class_lut: array<u32>;  // 256 bytes
@group(0) @binding(3) var<uniform> n: u32;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    let idx = id.x;
    if (idx >= n) {
        return;
    }

    let byte_val = input[idx] & 0xFFu;

    // O(1) LUT lookup
    output[idx] = orbit_class_lut[byte_val];
}
"
        .to_string()
    }

    fn generate_orbit_classify_cuda(&self) -> String {
        r"// CUDA O(1) orbit classification using LUT

__constant__ unsigned char d_orbit_class[256];

__global__ void orbit_classify_lut_kernel(
    const unsigned char* __restrict__ input,
    unsigned char* __restrict__ output,
    int n
) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) {
        output[idx] = d_orbit_class[input[idx]];
    }
}

void init_orbit_classify_lut(const unsigned char* orbit_class) {
    cudaMemcpyToSymbol(d_orbit_class, orbit_class, 256);
}

inline void launch_orbit_classify_kernel(
    const unsigned char* input, unsigned char* output,
    int n, cudaStream_t stream = 0
) {
    int threads = 256;
    int blocks = (n + threads - 1) / threads;
    orbit_classify_lut_kernel<<<blocks, threads, 0, stream>>>(input, output, n);
}
"
        .to_string()
    }

    fn generate_orbit_classify_metal(&self) -> String {
        r"// Metal O(1) orbit classification using LUT

#include <metal_stdlib>
using namespace metal;

kernel void orbit_classify_lut_kernel(
    device const uchar* input [[buffer(0)]],
    device uchar* output [[buffer(1)]],
    device const uchar* orbit_class_lut [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint idx [[thread_position_in_grid]]
) {
    if (idx >= n) {
        return;
    }

    output[idx] = orbit_class_lut[input[idx]];
}
"
        .to_string()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // ========================================================================
    // Basic API Tests
    // ========================================================================

    #[test]
    fn test_kernel_language_extension() {
        assert_eq!(KernelLanguage::Wgsl.extension(), "wgsl");
        assert_eq!(KernelLanguage::Cuda.extension(), "cu");
        assert_eq!(KernelLanguage::Metal.extension(), "metal");
    }

    #[test]
    fn test_kernel_language_name() {
        assert_eq!(KernelLanguage::Wgsl.name(), "WGSL");
        assert_eq!(KernelLanguage::Cuda.name(), "CUDA");
        assert_eq!(KernelLanguage::Metal.name(), "Metal");
    }

    // ========================================================================
    // Element-wise Kernel Tests (TASK-161)
    // ========================================================================

    #[test]
    fn test_elementwise_add_wgsl() {
        let template = ElementWiseTemplate::new("add", KernelLanguage::Wgsl);
        let source = template.generate();

        assert!(source.contains("WGSL kernel for add"));
        assert!(source.contains("@compute @workgroup_size(256)"));
        assert!(source.contains("input_a[idx] + input_b[idx]"));
    }

    #[test]
    fn test_elementwise_sub_wgsl() {
        let template = ElementWiseTemplate::new("sub", KernelLanguage::Wgsl);
        let source = template.generate();

        assert!(source.contains("input_a[idx] - input_b[idx]"));
    }

    #[test]
    fn test_elementwise_mul_wgsl() {
        let template = ElementWiseTemplate::new("mul", KernelLanguage::Wgsl);
        let source = template.generate();

        assert!(source.contains("input_a[idx] * input_b[idx]"));
    }

    #[test]
    fn test_elementwise_relu_wgsl() {
        let template = ElementWiseTemplate::new("relu", KernelLanguage::Wgsl);
        let source = template.generate();

        assert!(source.contains("max(input_a[idx], 0.0)"));
    }

    #[test]
    fn test_elementwise_sigmoid_wgsl() {
        let template = ElementWiseTemplate::new("sigmoid", KernelLanguage::Wgsl);
        let source = template.generate();

        assert!(source.contains("1.0 / (1.0 + exp(-input_a[idx]))"));
    }

    #[test]
    fn test_elementwise_tanh_wgsl() {
        let template = ElementWiseTemplate::new("tanh", KernelLanguage::Wgsl);
        let source = template.generate();

        assert!(source.contains("tanh(input_a[idx])"));
    }

    #[test]
    fn test_elementwise_relu_cuda() {
        let template = ElementWiseTemplate::new("relu", KernelLanguage::Cuda);
        let source = template.generate();

        assert!(source.contains("CUDA kernel for relu"));
        assert!(source.contains("__global__"));
        assert!(source.contains("fmaxf(input_a[idx], 0.0f)"));
        assert!(source.contains("launch_relu_kernel"));
    }

    #[test]
    fn test_elementwise_sigmoid_cuda() {
        let template = ElementWiseTemplate::new("sigmoid", KernelLanguage::Cuda);
        let source = template.generate();

        assert!(source.contains("1.0f / (1.0f + expf(-input_a[idx]))"));
    }

    #[test]
    fn test_elementwise_tanh_cuda() {
        let template = ElementWiseTemplate::new("tanh", KernelLanguage::Cuda);
        let source = template.generate();

        assert!(source.contains("tanhf(input_a[idx])"));
    }

    #[test]
    fn test_elementwise_sigmoid_metal() {
        let template = ElementWiseTemplate::new("sigmoid", KernelLanguage::Metal);
        let source = template.generate();

        assert!(source.contains("Metal kernel for sigmoid"));
        assert!(source.contains("kernel void"));
        assert!(source.contains("1.0f / (1.0f + exp(-input_a[idx]))"));
    }

    #[test]
    fn test_elementwise_bounds_check() {
        // All kernels should have bounds checking
        let wgsl = ElementWiseTemplate::new("add", KernelLanguage::Wgsl).generate();
        let cuda = ElementWiseTemplate::new("add", KernelLanguage::Cuda).generate();
        let metal = ElementWiseTemplate::new("add", KernelLanguage::Metal).generate();

        assert!(wgsl.contains("if (idx >= n)"));
        assert!(cuda.contains("if (idx < n)"));
        assert!(metal.contains("if (idx >= n)"));
    }

    // ========================================================================
    // MatMul Kernel Tests (TASK-161)
    // ========================================================================

    #[test]
    fn test_matmul_wgsl_tiled() {
        let template = MatMulTemplate::new(KernelLanguage::Wgsl, 32);
        let source = template.generate();

        assert!(source.contains("WGSL tiled matmul kernel"));
        assert!(source.contains("Tile size: 32x32"));
        assert!(source.contains("var<workgroup> tile_A"));
        assert!(source.contains("var<workgroup> tile_B"));
        assert!(source.contains("workgroupBarrier()"));
        // Verify actual computation
        assert!(source
            .contains("tile_A[local_row * TILE_SIZE + k] * tile_B[k * TILE_SIZE + local_col]"));
    }

    #[test]
    fn test_matmul_cuda_tiled() {
        let template = MatMulTemplate::new(KernelLanguage::Cuda, 32);
        let source = template.generate();

        assert!(source.contains("CUDA tiled matmul kernel"));
        assert!(source.contains("#define TILE_SIZE 32"));
        assert!(source.contains("__shared__ float tile_A"));
        assert!(source.contains("__shared__ float tile_B"));
        assert!(source.contains("__syncthreads()"));
        // Verify actual computation
        assert!(source.contains("tile_A[local_row][k] * tile_B[k][local_col]"));
        assert!(source.contains("launch_matmul_kernel"));
    }

    #[test]
    fn test_matmul_metal_tiled() {
        let template = MatMulTemplate::new(KernelLanguage::Metal, 16);
        let source = template.generate();

        assert!(source.contains("Metal tiled matmul kernel"));
        assert!(source.contains("#define TILE_SIZE 16"));
        assert!(source.contains("threadgroup float tile_A"));
        assert!(source.contains("threadgroup float tile_B"));
        assert!(source.contains("threadgroup_barrier(mem_flags::mem_threadgroup)"));
        // Verify actual computation
        assert!(source.contains("tile_A[local_row][k] * tile_B[k][local_col]"));
    }

    #[test]
    fn test_matmul_different_tile_sizes() {
        for tile_size in [8, 16, 32] {
            let template = MatMulTemplate::new(KernelLanguage::Cuda, tile_size);
            let source = template.generate();
            assert!(source.contains(&format!("#define TILE_SIZE {tile_size}")));
        }
    }

    // ========================================================================
    // Reduction Kernel Tests (TASK-161)
    // ========================================================================

    #[test]
    fn test_reduction_sum_wgsl() {
        let template = ReductionTemplate::new("sum", KernelLanguage::Wgsl);
        let source = template.generate();

        assert!(source.contains("WGSL tree reduction kernel for sum"));
        assert!(source.contains("shared_data[tid] = shared_data[tid] + shared_data[tid + stride]"));
        assert!(source.contains("workgroupBarrier()"));
        // Sum identity is 0.0 (in the else branch)
        assert!(source.contains("= 0.0;"));
    }

    #[test]
    fn test_reduction_max_wgsl() {
        let template = ReductionTemplate::new("max", KernelLanguage::Wgsl);
        let source = template.generate();

        assert!(source.contains("max(shared_data[tid], shared_data[tid + stride])"));
        // Max identity is -infinity (approximated)
        assert!(source.contains("-3.402823e+38"));
    }

    #[test]
    fn test_reduction_min_wgsl() {
        let template = ReductionTemplate::new("min", KernelLanguage::Wgsl);
        let source = template.generate();

        assert!(source.contains("min(shared_data[tid], shared_data[tid + stride])"));
        // Min identity is +infinity (approximated)
        assert!(source.contains("3.402823e+38"));
    }

    #[test]
    fn test_reduction_sum_cuda() {
        let template = ReductionTemplate::new("sum", KernelLanguage::Cuda);
        let source = template.generate();

        assert!(source.contains("CUDA tree reduction kernel for sum"));
        assert!(source.contains("shared_data[tid] + shared_data[tid + stride]"));
        assert!(source.contains("__syncthreads()"));
        assert!(source.contains("launch_sum_reduce_kernel"));
    }

    #[test]
    fn test_reduction_max_cuda() {
        let template = ReductionTemplate::new("max", KernelLanguage::Cuda);
        let source = template.generate();

        assert!(source.contains("fmaxf(shared_data[tid], shared_data[tid + stride])"));
        assert!(source.contains("-FLT_MAX"));
    }

    #[test]
    fn test_reduction_min_cuda() {
        let template = ReductionTemplate::new("min", KernelLanguage::Cuda);
        let source = template.generate();

        assert!(source.contains("fminf(shared_data[tid], shared_data[tid + stride])"));
        assert!(source.contains("FLT_MAX"));
    }

    #[test]
    fn test_reduction_sum_metal() {
        let template = ReductionTemplate::new("sum", KernelLanguage::Metal);
        let source = template.generate();

        assert!(source.contains("Metal tree reduction kernel for sum"));
        assert!(source.contains("shared_data[tid] + shared_data[tid + stride]"));
        assert!(source.contains("threadgroup_barrier(mem_flags::mem_threadgroup)"));
    }

    #[test]
    fn test_reduction_max_metal() {
        let template = ReductionTemplate::new("max", KernelLanguage::Metal);
        let source = template.generate();

        assert!(source.contains("max(shared_data[tid], shared_data[tid + stride])"));
    }

    #[test]
    fn test_reduction_min_metal() {
        let template = ReductionTemplate::new("min", KernelLanguage::Metal);
        let source = template.generate();

        assert!(source.contains("min(shared_data[tid], shared_data[tid + stride])"));
    }

    // ========================================================================
    // Comprehensive Coverage Tests
    // ========================================================================

    #[test]
    fn test_all_elementwise_ops_all_languages() {
        let ops = ["add", "sub", "mul", "relu", "sigmoid", "tanh"];
        let langs = [
            KernelLanguage::Wgsl,
            KernelLanguage::Cuda,
            KernelLanguage::Metal,
        ];

        for op in ops {
            for lang in langs {
                let template = ElementWiseTemplate::new(op, lang);
                let source = template.generate();
                assert!(!source.is_empty(), "Empty kernel for {op} on {lang:?}");
                assert!(source.contains(op), "Kernel should mention operation {op}");
            }
        }
    }

    #[test]
    fn test_all_reduction_ops_all_languages() {
        let ops = ["sum", "max", "min"];
        let langs = [
            KernelLanguage::Wgsl,
            KernelLanguage::Cuda,
            KernelLanguage::Metal,
        ];

        for op in ops {
            for lang in langs {
                let template = ReductionTemplate::new(op, lang);
                let source = template.generate();
                assert!(!source.is_empty(), "Empty kernel for {op} on {lang:?}");
                assert!(source.contains(op), "Kernel should mention operation {op}");
            }
        }
    }

    #[test]
    fn test_matmul_all_languages() {
        let langs = [
            KernelLanguage::Wgsl,
            KernelLanguage::Cuda,
            KernelLanguage::Metal,
        ];

        for lang in langs {
            let template = MatMulTemplate::new(lang, 32);
            let source = template.generate();
            assert!(!source.is_empty(), "Empty matmul kernel for {lang:?}");
            // All should have tiling
            assert!(
                source.contains("tile") || source.contains("TILE"),
                "Matmul should use tiling"
            );
        }
    }

    #[test]
    fn test_unsupported_operation_fallback() {
        // Unsupported operations should fall back gracefully
        let template = ElementWiseTemplate::new("unsupported_op", KernelLanguage::Wgsl);
        let source = template.generate();
        assert!(source.contains("Unsupported operation"));
    }
}
