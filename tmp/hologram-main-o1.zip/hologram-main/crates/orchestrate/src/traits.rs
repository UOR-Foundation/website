//! Orchestrator trait definitions.

use crate::error::Result;
use crate::types::{ProvisionConfig, WorkerHandle, WorkerInfo, WorkerState};
use hologram_backend::BackendType;
use std::time::Duration;

/// Capabilities of an orchestrator backend.
#[derive(Debug, Clone)]
pub struct OrchestratorCapabilities {
    /// Maximum workers this orchestrator can manage.
    pub max_workers: Option<u32>,
    /// Supported backend types.
    pub supported_backends: Vec<BackendType>,
    /// Whether GPU allocation is supported.
    pub gpu_support: bool,
    /// Whether auto-scaling is supported.
    pub auto_scale_support: bool,
    /// Typical provisioning latency.
    pub typical_provision_latency: Duration,
    /// Name of the orchestrator backend.
    pub name: String,
}

impl Default for OrchestratorCapabilities {
    fn default() -> Self {
        Self {
            max_workers: None,
            supported_backends: vec![BackendType::Cpu],
            gpu_support: false,
            auto_scale_support: false,
            typical_provision_latency: Duration::from_secs(30),
            name: "unknown".to_string(),
        }
    }
}

impl OrchestratorCapabilities {
    /// Create a new capabilities instance with default values.
    #[must_use]
    pub fn new(name: impl Into<String>) -> Self {
        Self {
            name: name.into(),
            ..Self::default()
        }
    }

    /// Set the maximum workers.
    #[must_use]
    pub const fn with_max_workers(mut self, max_workers: u32) -> Self {
        self.max_workers = Some(max_workers);
        self
    }

    /// Add a supported backend type.
    #[must_use]
    pub fn with_backend(mut self, backend: BackendType) -> Self {
        if !self.supported_backends.contains(&backend) {
            self.supported_backends.push(backend);
        }
        self
    }

    /// Set supported backend types.
    #[must_use]
    pub fn with_backends(mut self, backends: Vec<BackendType>) -> Self {
        self.supported_backends = backends;
        self
    }

    /// Enable GPU support.
    #[must_use]
    pub const fn with_gpu_support(mut self) -> Self {
        self.gpu_support = true;
        self
    }

    /// Enable auto-scaling support.
    #[must_use]
    pub const fn with_auto_scale_support(mut self) -> Self {
        self.auto_scale_support = true;
        self
    }

    /// Set typical provisioning latency.
    #[must_use]
    pub const fn with_provision_latency(mut self, latency: Duration) -> Self {
        self.typical_provision_latency = latency;
        self
    }

    /// Check if a backend type is supported.
    #[must_use]
    pub fn supports_backend(&self, backend: &BackendType) -> bool {
        self.supported_backends.contains(backend)
    }

    /// Check if more workers can be provisioned.
    #[must_use]
    pub fn can_provision(&self, current_count: u32) -> bool {
        match self.max_workers {
            Some(max) => current_count < max,
            None => true,
        }
    }
}

/// Primary trait for orchestration backends (sync version).
///
/// This trait defines the interface for managing worker lifecycles
/// in a synchronous context.
pub trait Orchestrator: Send + Sync {
    /// Provision a new worker instance.
    fn provision(&self, config: ProvisionConfig) -> Result<WorkerHandle>;

    /// Terminate a worker instance.
    fn terminate(&self, handle: WorkerHandle) -> Result<()>;

    /// Force terminate a worker without graceful shutdown.
    fn force_terminate(&self, handle: WorkerHandle) -> Result<()>;

    /// Get information about a specific worker.
    fn worker_info(&self, handle: WorkerHandle) -> Result<WorkerInfo>;

    /// List all workers managed by this orchestrator.
    fn list_workers(&self) -> Result<Vec<WorkerInfo>>;

    /// Get workers in a specific state.
    fn workers_by_state(&self, state: WorkerState) -> Result<Vec<WorkerInfo>>;

    /// Get orchestrator capabilities.
    fn capabilities(&self) -> OrchestratorCapabilities;
}

/// Primary trait for orchestration backends (async version).
///
/// This trait provides async versions of all orchestrator operations,
/// suitable for use with async runtimes like Tokio.
#[cfg(feature = "async")]
#[async_trait::async_trait]
pub trait AsyncOrchestrator: Send + Sync {
    /// Provision a new worker instance.
    async fn provision(&self, config: ProvisionConfig) -> Result<WorkerHandle>;

    /// Terminate a worker instance.
    async fn terminate(&self, handle: WorkerHandle) -> Result<()>;

    /// Force terminate a worker without graceful shutdown.
    async fn force_terminate(&self, handle: WorkerHandle) -> Result<()>;

    /// Get information about a specific worker.
    async fn worker_info(&self, handle: WorkerHandle) -> Result<WorkerInfo>;

    /// List all workers managed by this orchestrator.
    async fn list_workers(&self) -> Result<Vec<WorkerInfo>>;

    /// Get workers in a specific state.
    async fn workers_by_state(&self, state: WorkerState) -> Result<Vec<WorkerInfo>>;

    /// Scale to a target number of workers.
    async fn scale(&self, target: u32, config: ProvisionConfig) -> Result<Vec<WorkerHandle>>;

    /// Wait for a worker to reach a specific state.
    async fn wait_for_state(
        &self,
        handle: WorkerHandle,
        target_state: WorkerState,
        timeout: Duration,
    ) -> Result<WorkerInfo>;

    /// Get orchestrator capabilities.
    fn capabilities(&self) -> OrchestratorCapabilities;
}

/// Extension trait for orchestrators that support health checking.
pub trait HealthCheckOrchestrator: Orchestrator {
    /// Check health of a specific worker.
    fn health_check(&self, handle: WorkerHandle) -> Result<HealthStatus>;

    /// Configure health check parameters.
    fn configure_health_check(&self, config: HealthCheckConfig) -> Result<()>;
}

/// Extension trait for async orchestrators that support health checking.
#[cfg(feature = "async")]
#[async_trait::async_trait]
pub trait AsyncHealthCheckOrchestrator: AsyncOrchestrator {
    /// Check health of a specific worker.
    async fn health_check(&self, handle: WorkerHandle) -> Result<HealthStatus>;

    /// Configure health check parameters.
    async fn configure_health_check(&self, config: HealthCheckConfig) -> Result<()>;
}

/// Health status of a worker.
#[derive(Debug, Clone)]
pub struct HealthStatus {
    /// Whether the worker is healthy.
    pub healthy: bool,
    /// Last health check timestamp (Unix epoch seconds).
    pub last_check: u64,
    /// Number of consecutive failures.
    pub consecutive_failures: u32,
    /// Optional details about the health status.
    pub details: Option<String>,
}

impl HealthStatus {
    /// Create a healthy status.
    #[must_use]
    pub fn healthy() -> Self {
        Self {
            healthy: true,
            last_check: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_secs())
                .unwrap_or(0),
            consecutive_failures: 0,
            details: None,
        }
    }

    /// Create an unhealthy status.
    #[must_use]
    pub fn unhealthy(failures: u32, details: impl Into<String>) -> Self {
        Self {
            healthy: false,
            last_check: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_secs())
                .unwrap_or(0),
            consecutive_failures: failures,
            details: Some(details.into()),
        }
    }
}

impl Default for HealthStatus {
    fn default() -> Self {
        Self::healthy()
    }
}

/// Configuration for health checks.
#[derive(Debug, Clone)]
pub struct HealthCheckConfig {
    /// Interval between health checks.
    pub interval: Duration,
    /// Timeout for each health check.
    pub timeout: Duration,
    /// Number of consecutive failures before marking unhealthy.
    pub unhealthy_threshold: u32,
    /// Number of consecutive successes before marking healthy.
    pub healthy_threshold: u32,
}

impl Default for HealthCheckConfig {
    fn default() -> Self {
        Self {
            interval: Duration::from_secs(10),
            timeout: Duration::from_secs(5),
            unhealthy_threshold: 3,
            healthy_threshold: 2,
        }
    }
}

impl HealthCheckConfig {
    /// Create a new health check config with default values.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the health check interval.
    #[must_use]
    pub const fn with_interval(mut self, interval: Duration) -> Self {
        self.interval = interval;
        self
    }

    /// Set the health check timeout.
    #[must_use]
    pub const fn with_timeout(mut self, timeout: Duration) -> Self {
        self.timeout = timeout;
        self
    }

    /// Set the unhealthy threshold.
    #[must_use]
    pub const fn with_unhealthy_threshold(mut self, threshold: u32) -> Self {
        self.unhealthy_threshold = threshold;
        self
    }

    /// Set the healthy threshold.
    #[must_use]
    pub const fn with_healthy_threshold(mut self, threshold: u32) -> Self {
        self.healthy_threshold = threshold;
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_orchestrator_capabilities_default() {
        let caps = OrchestratorCapabilities::default();
        assert_eq!(caps.max_workers, None);
        assert!(!caps.gpu_support);
        assert!(!caps.auto_scale_support);
        assert_eq!(caps.supported_backends, vec![BackendType::Cpu]);
    }

    #[test]
    fn test_orchestrator_capabilities_builder() {
        let caps = OrchestratorCapabilities::new("test")
            .with_max_workers(100)
            .with_backend(BackendType::Cuda)
            .with_gpu_support()
            .with_auto_scale_support()
            .with_provision_latency(Duration::from_secs(10));

        assert_eq!(caps.name, "test");
        assert_eq!(caps.max_workers, Some(100));
        assert!(caps.gpu_support);
        assert!(caps.auto_scale_support);
        assert!(caps.supports_backend(&BackendType::Cpu));
        assert!(caps.supports_backend(&BackendType::Cuda));
        assert_eq!(caps.typical_provision_latency, Duration::from_secs(10));
    }

    #[test]
    fn test_capabilities_can_provision() {
        let caps = OrchestratorCapabilities::new("test").with_max_workers(10);

        assert!(caps.can_provision(0));
        assert!(caps.can_provision(5));
        assert!(caps.can_provision(9));
        assert!(!caps.can_provision(10));
        assert!(!caps.can_provision(100));

        let unlimited = OrchestratorCapabilities::new("unlimited");
        assert!(unlimited.can_provision(0));
        assert!(unlimited.can_provision(1000));
    }

    #[test]
    fn test_health_check_config_default() {
        let config = HealthCheckConfig::default();
        assert_eq!(config.interval, Duration::from_secs(10));
        assert_eq!(config.timeout, Duration::from_secs(5));
        assert_eq!(config.unhealthy_threshold, 3);
        assert_eq!(config.healthy_threshold, 2);
    }

    #[test]
    fn test_health_check_config_builder() {
        let config = HealthCheckConfig::new()
            .with_interval(Duration::from_secs(5))
            .with_timeout(Duration::from_secs(2))
            .with_unhealthy_threshold(5)
            .with_healthy_threshold(3);

        assert_eq!(config.interval, Duration::from_secs(5));
        assert_eq!(config.timeout, Duration::from_secs(2));
        assert_eq!(config.unhealthy_threshold, 5);
        assert_eq!(config.healthy_threshold, 3);
    }

    #[test]
    fn test_health_status_healthy() {
        let status = HealthStatus::healthy();
        assert!(status.healthy);
        assert_eq!(status.consecutive_failures, 0);
        assert!(status.details.is_none());
    }

    #[test]
    fn test_health_status_unhealthy() {
        let status = HealthStatus::unhealthy(3, "connection refused");
        assert!(!status.healthy);
        assert_eq!(status.consecutive_failures, 3);
        assert_eq!(status.details, Some("connection refused".to_string()));
    }

    #[test]
    fn test_trait_object_safety() {
        // Verify Orchestrator trait is object-safe by attempting to create a dyn reference
        fn _takes_orchestrator(_r: &dyn Orchestrator) {}
    }

    // ========================================================================
    // Additional edge case tests
    // ========================================================================

    #[test]
    fn test_orchestrator_capabilities_with_backends() {
        let caps = OrchestratorCapabilities::new("test").with_backends(vec![
            BackendType::Cpu,
            BackendType::Cuda,
            BackendType::Metal,
        ]);

        assert_eq!(caps.supported_backends.len(), 3);
        assert!(caps.supports_backend(&BackendType::Cpu));
        assert!(caps.supports_backend(&BackendType::Cuda));
        assert!(caps.supports_backend(&BackendType::Metal));
        assert!(!caps.supports_backend(&BackendType::Wasm));
    }

    #[test]
    fn test_orchestrator_capabilities_duplicate_backend() {
        // Adding the same backend twice should not create duplicates
        let caps = OrchestratorCapabilities::new("test")
            .with_backend(BackendType::Cuda)
            .with_backend(BackendType::Cuda);

        // CPU is default, Cuda added once
        assert_eq!(caps.supported_backends.len(), 2);
    }

    #[test]
    fn test_health_status_default() {
        let status = HealthStatus::default();
        assert!(status.healthy);
        assert_eq!(status.consecutive_failures, 0);
    }

    #[test]
    fn test_health_status_timestamp() {
        let status = HealthStatus::healthy();
        // Timestamp should be recent (within last 5 seconds)
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        assert!(status.last_check <= now);
        assert!(status.last_check >= now.saturating_sub(5));
    }

    #[test]
    fn test_capabilities_unlimited_workers() {
        let caps = OrchestratorCapabilities::new("unlimited");
        assert!(caps.max_workers.is_none());
        // Can always provision when no limit
        assert!(caps.can_provision(0));
        assert!(caps.can_provision(u32::MAX - 1));
    }
}
