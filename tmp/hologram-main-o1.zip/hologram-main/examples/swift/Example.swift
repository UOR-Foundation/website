/**
 * Swift FFI Example (C interop, ~5-10ns/call)
 * 
 * Demonstrates UOR Rust bindings via high-performance C FFI.
 * 
 * Build:
 *     swift build
 * 
 * Run:
 *     swift run
 */

import Foundation

// Import UOR wrapper (assumes UOR.swift is in same directory or package)
#if canImport(UOR)
import UOR
#endif

print("=== UOR Swift (C Interop) Example ===\n")

let uor = UOR()

// Constants
print("Braille base: U+\(String(format: "%04X", uor.brailleBase))")
assert(uor.brailleBase == 0x2800, "brailleBase should be 0x2800")

print("Braille max: U+\(String(format: "%04X", uor.brailleMax))")
assert(uor.brailleMax == 0x28FF, "brailleMax should be 0x28FF")

print("Triadic constant (T): \(uor.triadicConstant)")
assert(uor.triadicConstant == 3, "triadicConstant should be 3")

print("Octave constant (O): \(uor.octaveConstant)")
assert(uor.octaveConstant == 8, "octaveConstant should be 8")

print("State taxons: \(uor.stateTaxons)")
assert(uor.stateTaxons == 624, "stateTaxons should be 624")

print("State bits: \(uor.stateBits)")
assert(uor.stateBits == 4992, "stateBits should be 4992")

// Taxon Operations
print("\n--- Taxon Operations ---")
let value: UInt8 = 42
let braille = uor.byteToBraille(value)
print("byteToBraille(\(value)) = '\(braille)'")
assert(!braille.isEmpty, "braille string should not be empty")

let codepoint = uor.byteToCodepoint(value)
print("byteToCodepoint(\(value)) = \(codepoint) (U+\(String(format: "%04X", codepoint)))")
assert(codepoint >= 0x2800 && codepoint <= 0x28FF, "codepoint should be in Braille range")
assert(codepoint == 0x2800 + UInt32(value), "codepoint should be base + byte")

let domain = uor.byteToDomain(value)
print("byteToDomain(\(value)) = \(domain)")
assert(domain <= 2, "domain should be 0, 1, or 2")

let rank = uor.byteRank(value)
print("byteRank(\(value)) = \(rank)")
assert(rank < 96, "rank should be less than 96")

// Ring Operations
print("\n--- Ring Operations ---")
let succ = uor.byteSucc(value)
print("byteSucc(\(value)) = \(succ)")
assert(succ == 43, "succ(42) should be 43")

let pred = uor.bytePred(value)
print("bytePred(\(value)) = \(pred)")
assert(pred == 41, "pred(42) should be 41")

let notval = uor.byteNot(value)
print("byteNot(\(value)) = \(notval)")
assert(notval <= 255, "NOT result should be a valid byte")

// View Operations
print("\n--- View Operations ---")
let identity = uor.viewIdentity()
let identityResult = identity.apply(value)
print("identity.apply(\(value)) = \(identityResult)")
assert(identityResult == value, "identity should preserve value")

let isBij = identity.isBijective()
print("identity.isBijective() = \(isBij)")
assert(isBij, "identity view should be bijective")

if let constant = uor.viewConstant(99) {
    let constResult = constant.apply(value)
    print("constant(99).apply(\(value)) = \(constResult)")
    assert(constResult == 99, "constant(99) should always return 99")

    // Composition
    if let composed = identity.then(constant) {
        let composedResult = composed.apply(value)
        print("identity.then(constant(99)).apply(\(value)) = \(composedResult)")
        assert(composedResult == 99, "identity.then(constant(99)) should return 99")
    }
}

// Batch Operations
print("\n--- Batch Operations ---")
let data: [UInt8] = [0, 1, 2, 3, 4, 5, 6, 7]
let result = identity.applySlice(data)
print("identity.applySlice(\(data)) = \(result)")
assert(result == data, "identity should preserve array")

// Inverse
print("\n--- Inverse Operations ---")
if identity.isBijective() {
    if let inv = identity.inverse() {
        let invResult = inv.apply(value)
        print("identity.inverse().apply(\(value)) = \(invResult)")
        assert(invResult == value, "identity.inverse() should equal identity")

        let invBij = inv.isBijective()
        print("identity.inverse().isBijective() = \(invBij)")
        assert(invBij, "inverse of bijective view should be bijective")
    }
}

print("\n=== All tests passed! ===")
