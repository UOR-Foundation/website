//! Codec code generation from JSON-LD descriptors.
//!
//! This crate provides lossless encoding/decoding between byte sequences and
//! various numeral system representations. Codec definitions are specified in
//! JSON-LD descriptor files and Rust implementations are generated at build time.
//!
//! # Features
//!
//! - **Codegen-driven**: Codec definitions live in JSON-LD files (`descriptors/*.jsonld`)
//!   and Rust code is generated at build time
//! - **Lossless**: All codecs preserve information - encode then decode returns the original
//! - **Multiple radices**: Support for binary, decimal, hexadecimal, and mixed-radix systems
//! - **Braille encoding**: Bijective mapping from bytes to Unicode Braille codepoints
//!
//! # Architecture
//!
//! ```text
//! descriptors/*.jsonld    (Source of Truth)
//!         ↓ build.rs
//! src/generated.rs        (Generated Rust code)
//!         ↓
//! Codec trait impls       (Runtime API)
//! ```
//!
//! The crate is organized into:
//!
//! - **`traits` module**: Core `Codec` and `ScaleFactor` types
//! - **`generated` module**: Build-time generated codec implementations
//! - **`error` module**: Error types for codec operations
//!
//! # Available Codecs
//!
//! | Codec | Radix | Description |
//! |-------|-------|-------------|
//! | `NumeralsSystemsBinary` | 2 | Passthrough (bytes = binary) |
//! | `NumeralsSystemsDecimal` | 10 | Base-10 representation |
//! | `NumeralsSystemsHexadecimal` | 16 | Base-16 representation |
//! | `NumeralsSystemsMod96crt` | 32,3 | Mixed-radix CRT system |
//! | `CodecsBrailleQ0` | 256 | 1 byte → 1 Braille glyph |
//! | `CodecsBrailleQ1` | 256 | 2 bytes → 2 Braille glyphs |
//! | `CodecsBrailleQ2` | 256 | 3 bytes → 3 Braille glyphs |
//! | `CodecsBrailleQ3` | 256 | 4 bytes → 4 Braille glyphs |
//!
//! # Quick Start
//!
//! ```
//! use categorical_codec::{Codec, NumeralsSystemsDecimal, CodecsBrailleQ1};
//!
//! // Base-10 encoding
//! let decimal = NumeralsSystemsDecimal;
//! let encoded = decimal.encode(&[0xDE, 0xAD]).unwrap();
//! let decoded = decimal.decode(&encoded).unwrap();
//! assert_eq!(decoded, vec![0xDE, 0xAD]);
//!
//! // Braille encoding (2 bytes → 2 Unicode glyphs)
//! let braille = CodecsBrailleQ1;
//! let encoded = braille.encode(&[0x42, 0xFF]).unwrap();
//! let text = std::str::from_utf8(&encoded).unwrap();
//! assert_eq!(text.chars().count(), 2); // Two Braille characters
//!
//! let decoded = braille.decode(&encoded).unwrap();
//! assert_eq!(decoded, vec![0x42, 0xFF]);
//! ```
//!
//! # Braille Encoding
//!
//! The Braille codecs provide a bijective mapping between bytes and Unicode
//! Braille Pattern codepoints (U+2800 to U+28FF). Each byte value 0-255 maps
//! to exactly one Braille codepoint.
//!
//! ```
//! use categorical_codec::{Codec, CodecsBrailleQ0};
//!
//! let codec = CodecsBrailleQ0;
//!
//! // Byte 0 → U+2800 (⠀), Byte 255 → U+28FF (⣿)
//! let encoded = codec.encode(&[0]).unwrap();
//! assert_eq!(std::str::from_utf8(&encoded).unwrap(), "⠀");
//!
//! let encoded = codec.encode(&[255]).unwrap();
//! assert_eq!(std::str::from_utf8(&encoded).unwrap(), "⣿");
//! ```
//!
//! # Integration with ISA
//!
//! Codecs integrate with the hologram ISA via `OpKind::Encode` and `OpKind::Decode`
//! operations. The compiler can emit codec operations that backends execute:
//!
//! ```text
//! // In a compiled operation graph:
//! OpKind::Encode { codec_id: "cxs:codecs/braille/q1", input, output }
//! OpKind::Decode { codec_id: "cxs:codecs/braille/q1", input, output }
//! ```
//!
//! # Adding New Codecs
//!
//! To add a new codec:
//!
//! 1. Add the codec definition to `descriptors/hologram.jsonld`:
//!    ```json
//!    {
//!      "@id": "cxs:my/new/codec",
//!      "@type": ["NumeralSystem", "PositionalSystem"],
//!      "rdfs:label": "My Codec",
//!      "hasRadix": 42,
//!      "precisionBits": 64
//!    }
//!    ```
//!
//! 2. Rebuild the crate - `build.rs` will generate the implementation
//!
//! 3. The codec is now available as `MyNewCodec` (name derived from @id)
//!
//! # Performance
//!
//! Run benchmarks with: `cargo bench -p categorical-codec`
//!
//! Benchmark groups:
//! - `binary`, `decimal`, `hexadecimal`, `mod96crt`: Base-N codec throughput
//! - `braille_q0` through `braille_q3`: Braille codec throughput
//! - `comparison_64bytes`: Side-by-side codec comparison

pub mod error;
pub mod generated;
pub mod traits;

// Re-export commonly used types
pub use error::CodecError;
pub use traits::{
    BatchDecoder, BatchEncoder, BrailleStreamDecoder, BrailleStreamEncoder, ChunkDecoder,
    ChunkEncoder, Codec, ScaleFactor, StreamingCodec,
};

// Re-export generated codecs
pub use generated::*;
