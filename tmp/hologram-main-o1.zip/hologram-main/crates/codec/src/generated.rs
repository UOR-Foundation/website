//! Auto-generated codec implementations.
//!
//! This module contains codecs generated from JSON-LD descriptors at build time.
//! The `generated.rs` file in OUT_DIR is included here.

use crate::error::CodecError;
use num_bigint::BigUint;
use num_traits::Zero;

// Include the build-generated code
include!(concat!(env!("OUT_DIR"), "/generated.rs"));

/// Encode bytes to base-N representation.
///
/// Converts a byte sequence to its representation in the given radix (base).
/// The output is in big-endian order (most significant digit first).
pub fn encode_base_n(input: &[u8], radix: u32) -> Result<Vec<u8>, CodecError> {
    if input.is_empty() {
        return Ok(vec![0]);
    }

    // Convert bytes to BigUint
    let value = BigUint::from_bytes_be(input);

    if value.is_zero() {
        return Ok(vec![0]);
    }

    // Convert to target base
    let radix_big = BigUint::from(radix);
    let mut digits = Vec::new();
    let mut remaining = value;

    while !remaining.is_zero() {
        let digit = (&remaining % &radix_big).to_u32_digits();
        let digit_val = digit.first().copied().unwrap_or(0) as u8;
        digits.push(digit_val);
        remaining /= &radix_big;
    }

    // Reverse for big-endian output
    digits.reverse();
    Ok(digits)
}

/// Decode base-N representation to bytes.
///
/// Converts a sequence of digits in the given radix (base) back to bytes.
/// The input is expected in big-endian order (most significant digit first).
pub fn decode_base_n(input: &[u8], radix: u32) -> Result<Vec<u8>, CodecError> {
    if input.is_empty() || (input.len() == 1 && input[0] == 0) {
        return Ok(Vec::new());
    }

    // Convert from target base to BigUint
    let radix_big = BigUint::from(radix);
    let mut value = BigUint::ZERO;

    for &digit in input {
        value = value * &radix_big + BigUint::from(digit);
    }

    // Convert to bytes
    Ok(value.to_bytes_be())
}

/// Encode bytes using mixed radices.
///
/// Uses a mixed-radix (factorial-like) number system where each position
/// has a different radix. The radices array specifies the radix for each
/// position from least to most significant.
pub fn encode_mixed_radix(input: &[u8], radices: &[u32]) -> Result<Vec<u8>, CodecError> {
    if input.is_empty() {
        return Ok(vec![0]);
    }

    // Convert bytes to BigUint
    let value = BigUint::from_bytes_be(input);

    if value.is_zero() {
        return Ok(vec![0]);
    }

    let mut digits = Vec::new();
    let mut remaining = value;
    let mut position = 0;

    while !remaining.is_zero() {
        let radix = if position < radices.len() {
            radices[position]
        } else {
            *radices.last().unwrap_or(&10)
        };

        let radix_big = BigUint::from(radix);
        let digit = (&remaining % &radix_big).to_u32_digits();
        let digit_val = digit.first().copied().unwrap_or(0) as u8;
        digits.push(digit_val);
        remaining /= &radix_big;
        position += 1;
    }

    // Reverse for big-endian output
    digits.reverse();
    Ok(digits)
}

/// Decode mixed radix representation to bytes.
///
/// Converts a mixed-radix representation back to bytes. The radices array
/// specifies the radix for each position from least to most significant.
pub fn decode_mixed_radix(input: &[u8], radices: &[u32]) -> Result<Vec<u8>, CodecError> {
    if input.is_empty() || (input.len() == 1 && input[0] == 0) {
        return Ok(Vec::new());
    }

    // Reverse to process from least significant
    let reversed: Vec<_> = input.iter().rev().copied().collect();

    let mut value = BigUint::ZERO;
    let mut multiplier = BigUint::from(1u32);

    for (position, &digit) in reversed.iter().enumerate() {
        value += BigUint::from(digit) * &multiplier;

        let radix = if position < radices.len() {
            radices[position]
        } else {
            *radices.last().unwrap_or(&10)
        };

        multiplier *= BigUint::from(radix);
    }

    // Convert to bytes
    Ok(value.to_bytes_be())
}

/// Braille block base codepoint (U+2800).
const BRAILLE_BASE: u32 = 0x2800;

/// Encode bytes to Braille UTF-8 representation.
///
/// Each byte (0-255) maps bijectively to a Braille codepoint (U+2800-U+28FF).
/// The `expected_glyphs` parameter specifies how many bytes/glyphs are expected.
/// If input is shorter, it's padded with zeros. If longer, it's truncated.
pub fn encode_braille(input: &[u8], expected_glyphs: u64) -> Result<Vec<u8>, CodecError> {
    let glyph_count = expected_glyphs as usize;
    let mut output = Vec::with_capacity(glyph_count * 3); // Each Braille char is 3 UTF-8 bytes
    let mut buf = [0u8; 4];

    // Process each byte, padding with zeros if input is short
    for i in 0..glyph_count {
        let byte_val = if i < input.len() { input[i] } else { 0 };
        let codepoint = BRAILLE_BASE + u32::from(byte_val);

        // Safe because BRAILLE_BASE + 0..255 is always valid Unicode
        let ch = char::from_u32(codepoint).unwrap();
        let encoded = ch.encode_utf8(&mut buf);
        output.extend_from_slice(encoded.as_bytes());
    }

    Ok(output)
}

/// Decode Braille UTF-8 representation to bytes.
///
/// Each Braille codepoint (U+2800-U+28FF) maps bijectively to a byte (0-255).
/// The `expected_glyphs` parameter specifies how many glyphs to decode.
/// Extra input is ignored, missing input is padded with zeros.
pub fn decode_braille(input: &[u8], expected_glyphs: u64) -> Result<Vec<u8>, CodecError> {
    let glyph_count = expected_glyphs as usize;
    let mut output = Vec::with_capacity(glyph_count);

    // Parse UTF-8 string from input bytes
    let s = std::str::from_utf8(input).map_err(|_| CodecError::invalid_input("invalid UTF-8"))?;

    let mut chars = s.chars();
    for _ in 0..glyph_count {
        let byte_val = match chars.next() {
            Some(ch) => {
                let codepoint = ch as u32;
                if !(BRAILLE_BASE..=BRAILLE_BASE + 255).contains(&codepoint) {
                    return Err(CodecError::invalid_input("codepoint not in Braille range"));
                }
                (codepoint - BRAILLE_BASE) as u8
            }
            None => 0, // Pad with zeros if input is short
        };
        output.push(byte_val);
    }

    Ok(output)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_base_n_roundtrip() {
        let original = vec![1, 2, 3, 4, 5];
        let encoded = encode_base_n(&original, 10).unwrap();
        let decoded = decode_base_n(&encoded, 10).unwrap();
        assert_eq!(decoded, original);
    }

    #[test]
    fn test_base_16_roundtrip() {
        let original = vec![0xDE, 0xAD, 0xBE, 0xEF];
        let encoded = encode_base_n(&original, 16).unwrap();
        let decoded = decode_base_n(&encoded, 16).unwrap();
        assert_eq!(decoded, original);
    }

    #[test]
    fn test_mixed_radix_roundtrip() {
        let original = vec![1, 2, 3];
        let radices = vec![32, 3];
        let encoded = encode_mixed_radix(&original, &radices).unwrap();
        let decoded = decode_mixed_radix(&encoded, &radices).unwrap();
        assert_eq!(decoded, original);
    }

    #[test]
    fn test_empty_input() {
        assert_eq!(encode_base_n(&[], 10).unwrap(), vec![0]);
        assert_eq!(decode_base_n(&[], 10).unwrap(), Vec::<u8>::new());
        assert_eq!(decode_base_n(&[0], 10).unwrap(), Vec::<u8>::new());
    }

    #[test]
    fn test_zero_value() {
        let zero = vec![0];
        let encoded = encode_base_n(&zero, 10).unwrap();
        assert_eq!(encoded, vec![0]);
    }

    #[test]
    fn test_braille_q0_roundtrip_all_bytes() {
        // Test all 256 values for Q0 (1 byte = 1 glyph)
        for byte_val in 0..=255u8 {
            let input = vec![byte_val];
            let encoded = encode_braille(&input, 1).unwrap();
            let decoded = decode_braille(&encoded, 1).unwrap();
            assert_eq!(decoded, input, "roundtrip failed for byte {}", byte_val);
        }
    }

    #[test]
    fn test_braille_q0_encoding() {
        // U+2800 = 0xE2 0xA0 0x80 (byte 0)
        let encoded = encode_braille(&[0], 1).unwrap();
        assert_eq!(encoded, vec![0xE2, 0xA0, 0x80]);

        // U+28FF = 0xE2 0xA3 0xBF (byte 255)
        let encoded = encode_braille(&[255], 1).unwrap();
        assert_eq!(encoded, vec![0xE2, 0xA3, 0xBF]);
    }

    #[test]
    fn test_braille_q1_roundtrip() {
        // Q1: 2 bytes = 2 glyphs
        let test_cases = [
            vec![0, 0],
            vec![255, 255],
            vec![0, 255],
            vec![255, 0],
            vec![0x12, 0x34],
        ];

        for input in &test_cases {
            let encoded = encode_braille(input, 2).unwrap();
            assert_eq!(encoded.len(), 6, "Q1 should produce 6 UTF-8 bytes");
            let decoded = decode_braille(&encoded, 2).unwrap();
            assert_eq!(&decoded, input, "Q1 roundtrip failed for {:?}", input);
        }
    }

    #[test]
    fn test_braille_q2_roundtrip() {
        // Q2: 3 bytes = 3 glyphs
        let input = vec![0xAA, 0xBB, 0xCC];
        let encoded = encode_braille(&input, 3).unwrap();
        assert_eq!(encoded.len(), 9, "Q2 should produce 9 UTF-8 bytes");
        let decoded = decode_braille(&encoded, 3).unwrap();
        assert_eq!(decoded, input);
    }

    #[test]
    fn test_braille_q3_roundtrip() {
        // Q3: 4 bytes = 4 glyphs
        let input = vec![0xDE, 0xAD, 0xBE, 0xEF];
        let encoded = encode_braille(&input, 4).unwrap();
        assert_eq!(encoded.len(), 12, "Q3 should produce 12 UTF-8 bytes");
        let decoded = decode_braille(&encoded, 4).unwrap();
        assert_eq!(decoded, input);
    }

    #[test]
    fn test_braille_short_input_pads_with_zeros() {
        // If input is shorter than expected glyphs, pad with zeros
        let input = vec![0x42];
        let encoded = encode_braille(&input, 2).unwrap();
        let decoded = decode_braille(&encoded, 2).unwrap();
        assert_eq!(decoded, vec![0x42, 0]);
    }

    #[test]
    fn test_braille_is_valid_utf8() {
        // Verify encoded output is valid UTF-8
        for byte_val in 0..=255u8 {
            let encoded = encode_braille(&[byte_val], 1).unwrap();
            let s = std::str::from_utf8(&encoded);
            assert!(s.is_ok(), "invalid UTF-8 for byte {}", byte_val);

            // Verify it's a single Braille character
            let s = s.unwrap();
            assert_eq!(s.chars().count(), 1);
            let ch = s.chars().next().unwrap();
            assert!(('\u{2800}'..='\u{28FF}').contains(&ch));
        }
    }

    #[test]
    fn test_braille_invalid_codepoint() {
        // Non-Braille Unicode should fail decode
        let invalid_utf8 = "A"; // ASCII 'A' is not in Braille range
        let result = decode_braille(invalid_utf8.as_bytes(), 1);
        assert!(result.is_err());
    }
}
