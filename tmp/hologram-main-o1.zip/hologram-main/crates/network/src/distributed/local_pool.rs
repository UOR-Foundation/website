//! Local worker pool for in-process partition execution.
//!
//! This module provides a local-first execution pool that runs partitions
//! without any network overhead. When all workers are on the same machine,
//! execution happens directly through shared memory.
//!
//! # Design
//!
//! The `LocalWorkerPool` holds worker executors and routes execution requests
//! directly to them. This is the default execution strategy when no remote
//! workers are registered.
//!
//! # Zero Network Overhead
//!
//! For single-machine scenarios, there is zero network overhead:
//! - No serialization of data between workers
//! - No network protocol handling
//! - Direct function calls to executors
//! - Shared partition cache across workers
//!
//! # Telemetry
//!
//! This module exports metrics via `hologram-telemetry`:
//! - `partition_executions_total` - Total partition executions
//! - `partition_execution_duration_ms` - Execution duration histogram
//! - `partition_cache_hits` - Partition cache hits
//! - `partition_cache_misses` - Partition cache misses
//! - `workers_active` - Number of active workers
//!
//! # Example
//!
//! ```ignore
//! use hologram_network::distributed::{LocalWorkerPool, LocalPoolConfig};
//! use hologram_backend::BackendType;
//!
//! // Create pool with default config (one worker per CPU core)
//! let pool = LocalWorkerPool::new(LocalPoolConfig::default());
//!
//! // Add a worker
//! let worker_id = pool.add_worker(BackendType::Cpu).await;
//!
//! // Load partition on worker
//! pool.load_partition(worker_id, "model/p1:v1.0", partition).await?;
//!
//! // Execute - no network overhead, direct function call
//! let result = pool.execute(worker_id, request).await?;
//! ```

use super::scheduler::WorkerId;
use hologram_backend::{Backend, BackendError, BackendPlan, BackendType};
use hologram_holo::PlanPartition;
use hologram_telemetry::{count, MetricsRegistry};
use rkyv::Deserialize as RkyvDeserialize;
use rkyv::Infallible;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use thiserror::Error;
use tokio::sync::RwLock;

/// Error type for local worker pool operations.
#[derive(Debug, Error)]
pub enum LocalPoolError {
    /// Worker not found.
    #[error("Worker not found: {0}")]
    WorkerNotFound(WorkerId),

    /// Partition not loaded.
    #[error("Partition not loaded: {0}")]
    PartitionNotLoaded(String),

    /// Compilation failed.
    #[error("Compilation failed: {0}")]
    CompilationFailed(String),

    /// Execution failed.
    #[error("Execution failed: {0}")]
    ExecutionFailed(String),

    /// Invalid input data.
    #[error("Invalid input: {0}")]
    InvalidInput(String),

    /// Backend error.
    #[error("Backend error: {0}")]
    BackendError(#[from] BackendError),

    /// Pool is empty.
    #[error("Pool is empty - no workers registered")]
    EmptyPool,

    /// Serialization error.
    #[error("Serialization error: {0}")]
    SerializationError(String),

    /// Resource exhausted.
    #[error("Resource exhausted: {0}")]
    ResourceExhausted(String),
}

/// Configuration for partition execution.
#[derive(Debug, Clone)]
pub struct PartitionExecutorConfig {
    /// Maximum cached partitions.
    pub max_cached_partitions: usize,
    /// Maximum memory for cached plans in bytes.
    pub max_cache_memory: usize,
    /// Execution timeout in seconds.
    pub timeout_secs: u64,
    /// Target backend type.
    pub backend_type: BackendType,
}

impl Default for PartitionExecutorConfig {
    fn default() -> Self {
        Self {
            max_cached_partitions: 32,
            max_cache_memory: 512 * 1024 * 1024, // 512MB
            timeout_secs: 300,
            backend_type: BackendType::Cpu,
        }
    }
}

impl PartitionExecutorConfig {
    /// Create a new config with defaults.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the backend type.
    #[must_use]
    pub fn with_backend_type(mut self, backend_type: BackendType) -> Self {
        self.backend_type = backend_type;
        self
    }

    /// Set max cached partitions.
    #[must_use]
    pub fn with_max_cached(mut self, max: usize) -> Self {
        self.max_cached_partitions = max;
        self
    }

    /// Set max cache memory.
    #[must_use]
    pub fn with_max_memory(mut self, max: usize) -> Self {
        self.max_cache_memory = max;
        self
    }
}

/// Configuration for the local worker pool.
#[derive(Debug, Clone)]
pub struct LocalPoolConfig {
    /// Default executor config for new workers.
    pub executor_config: PartitionExecutorConfig,
    /// Maximum workers in the pool.
    pub max_workers: usize,
}

impl Default for LocalPoolConfig {
    fn default() -> Self {
        Self {
            executor_config: PartitionExecutorConfig::default(),
            max_workers: std::thread::available_parallelism()
                .map(std::num::NonZero::get)
                .unwrap_or(4),
        }
    }
}

impl LocalPoolConfig {
    /// Create a new config with defaults.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the executor config.
    #[must_use]
    pub fn with_executor_config(mut self, config: PartitionExecutorConfig) -> Self {
        self.executor_config = config;
        self
    }

    /// Set max workers.
    #[must_use]
    pub fn with_max_workers(mut self, max: usize) -> Self {
        self.max_workers = max;
        self
    }
}

/// Request to execute a specific partition.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PartitionRequest {
    /// Unique request ID.
    pub request_id: u64,
    /// Partition reference (e.g., "model/partition_0:v1.0").
    pub partition_ref: String,
    /// Input data (serialized tensors).
    pub inputs: Vec<Vec<u8>>,
    /// Priority (higher = more urgent).
    pub priority: u32,
}

impl PartitionRequest {
    /// Create a new partition request.
    pub fn new(partition_ref: impl Into<String>, inputs: Vec<Vec<u8>>) -> Self {
        static COUNTER: AtomicU64 = AtomicU64::new(0);
        Self {
            request_id: COUNTER.fetch_add(1, Ordering::SeqCst),
            partition_ref: partition_ref.into(),
            inputs,
            priority: 0,
        }
    }

    /// Set priority.
    #[must_use]
    pub fn with_priority(mut self, priority: u32) -> Self {
        self.priority = priority;
        self
    }
}

/// Result of a partition execution.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PartitionResult {
    /// Request ID this result is for.
    pub request_id: u64,
    /// Output data (serialized tensors).
    pub outputs: Vec<Vec<u8>>,
    /// Execution duration in milliseconds.
    pub duration_ms: u64,
    /// Worker that executed the request.
    pub worker_id: WorkerId,
}

impl PartitionResult {
    /// Create a new partition result.
    #[must_use]
    pub fn new(
        request_id: u64,
        outputs: Vec<Vec<u8>>,
        duration_ms: u64,
        worker_id: WorkerId,
    ) -> Self {
        Self {
            request_id,
            outputs,
            duration_ms,
            worker_id,
        }
    }

    /// Check if the result has no outputs.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.outputs.is_empty()
    }

    /// Get total output bytes.
    #[must_use]
    pub fn total_output_bytes(&self) -> usize {
        self.outputs.iter().map(Vec::len).sum()
    }
}

/// Statistics for a partition executor.
#[derive(Debug, Clone, Default)]
pub struct PartitionExecutorStats {
    /// Total executions.
    pub total_executions: u64,
    /// Successful executions.
    pub successful_executions: u64,
    /// Failed executions.
    pub failed_executions: u64,
    /// Cache hits.
    pub cache_hits: u64,
    /// Cache misses (required compilation).
    pub cache_misses: u64,
    /// Total execution time in milliseconds.
    pub total_duration_ms: u64,
}

impl PartitionExecutorStats {
    /// Get average execution duration.
    #[must_use]
    #[allow(clippy::cast_precision_loss)]
    pub fn average_duration_ms(&self) -> f64 {
        if self.total_executions == 0 {
            0.0
        } else {
            self.total_duration_ms as f64 / self.total_executions as f64
        }
    }

    /// Get success rate.
    #[must_use]
    #[allow(clippy::cast_precision_loss)]
    pub fn success_rate(&self) -> f64 {
        let total = self.successful_executions + self.failed_executions;
        if total == 0 {
            1.0
        } else {
            self.successful_executions as f64 / total as f64
        }
    }

    /// Get cache hit rate.
    #[must_use]
    #[allow(clippy::cast_precision_loss)]
    pub fn cache_hit_rate(&self) -> f64 {
        let total = self.cache_hits + self.cache_misses;
        if total == 0 {
            0.0
        } else {
            self.cache_hits as f64 / total as f64
        }
    }
}

/// A compiled partition ready for execution.
struct CompiledPartition {
    /// The compiled plan.
    plan: BackendPlan,
    /// Size in bytes (for cache management).
    size_bytes: usize,
    /// Last used timestamp.
    last_used: std::time::Instant,
}

/// Partition executor for a single worker.
///
/// This executor loads partitions, compiles them for the local backend,
/// caches the compiled plans, and executes them.
pub struct PartitionExecutor {
    /// Worker ID.
    worker_id: WorkerId,
    /// Configuration.
    config: PartitionExecutorConfig,
    /// Cached compiled partitions.
    cache: Arc<RwLock<HashMap<String, CompiledPartition>>>,
    /// Raw partition data (before compilation).
    raw_partitions: Arc<RwLock<HashMap<String, PlanPartition>>>,
    /// Execution statistics.
    stats: Arc<RwLock<PartitionExecutorStats>>,
}

impl PartitionExecutor {
    /// Create a new partition executor.
    #[must_use]
    pub fn new(worker_id: WorkerId, config: PartitionExecutorConfig) -> Self {
        Self {
            worker_id,
            config,
            cache: Arc::new(RwLock::new(HashMap::new())),
            raw_partitions: Arc::new(RwLock::new(HashMap::new())),
            stats: Arc::new(RwLock::new(PartitionExecutorStats::default())),
        }
    }

    /// Get the worker ID.
    #[must_use]
    pub fn worker_id(&self) -> WorkerId {
        self.worker_id
    }

    /// Get the target backend type.
    #[must_use]
    pub fn backend_type(&self) -> &BackendType {
        &self.config.backend_type
    }

    /// Load a raw partition (will be compiled on first execution).
    pub async fn load_partition(
        &self,
        partition_ref: &str,
        partition: PlanPartition,
    ) -> Result<(), LocalPoolError> {
        // Verify partition hash
        if !partition.verify_hash() {
            return Err(LocalPoolError::InvalidInput(format!(
                "Partition {partition_ref} has invalid content hash"
            )));
        }

        self.raw_partitions
            .write()
            .await
            .insert(partition_ref.to_string(), partition);
        tracing::info!("Loaded partition: {}", partition_ref);
        Ok(())
    }

    /// Load a partition from bytes (rkyv serialized).
    pub async fn load_partition_bytes(
        &self,
        partition_ref: &str,
        bytes: &[u8],
    ) -> Result<(), LocalPoolError> {
        // Use rkyv 0.7 check_archived_root for validation
        let archived = rkyv::check_archived_root::<PlanPartition>(bytes)
            .map_err(|e| LocalPoolError::SerializationError(e.to_string()))?;

        // Deserialize to owned value
        let partition: PlanPartition = archived
            .deserialize(&mut Infallible)
            .expect("Infallible deserialization");

        self.load_partition(partition_ref, partition).await
    }

    /// Unload a partition from cache.
    pub async fn unload_partition(&self, partition_ref: &str) {
        self.cache.write().await.remove(partition_ref);
        self.raw_partitions.write().await.remove(partition_ref);
        tracing::info!("Unloaded partition: {}", partition_ref);
    }

    /// Check if a partition is loaded (raw or compiled).
    pub async fn has_partition(&self, partition_ref: &str) -> bool {
        self.raw_partitions.read().await.contains_key(partition_ref)
            || self.cache.read().await.contains_key(partition_ref)
    }

    /// Get list of loaded partition references.
    pub async fn loaded_partitions(&self) -> Vec<String> {
        let raw = self.raw_partitions.read().await;
        let compiled = self.cache.read().await;

        let mut all: std::collections::HashSet<String> = raw.keys().cloned().collect();
        for key in compiled.keys() {
            all.insert(key.clone());
        }
        all.into_iter().collect()
    }

    /// Execute a partition request.
    ///
    /// ## Metrics
    ///
    /// Records the following metrics:
    /// - `partition_executions_total` - incremented on each execution
    /// - `partition_execution_duration_ms` - execution duration histogram
    #[allow(clippy::cast_possible_truncation)]
    pub async fn execute(
        &self,
        request: PartitionRequest,
    ) -> Result<PartitionResult, LocalPoolError> {
        // Record execution attempt
        count!("partition_executions_total");

        let start = std::time::Instant::now();

        // Get or compile the partition
        let plan = self
            .get_or_compile_partition(&request.partition_ref)
            .await?;

        // Create backend for execution
        let backend = self.create_backend()?;

        // Execute the plan
        let outputs = self.execute_plan(&plan, &request.inputs, backend.as_ref())?;

        let duration_ms = start.elapsed().as_millis() as u64;

        // Record execution duration metric
        let metrics = MetricsRegistry::global();
        #[allow(clippy::cast_precision_loss)]
        metrics.record("partition_execution_duration_ms", duration_ms as f64);

        // Update stats
        {
            let mut stats = self.stats.write().await;
            stats.total_executions += 1;
            stats.successful_executions += 1;
            stats.total_duration_ms += duration_ms;
        }

        Ok(PartitionResult {
            request_id: request.request_id,
            outputs,
            duration_ms,
            worker_id: self.worker_id,
        })
    }

    /// Get a compiled partition from cache, or compile it if needed.
    ///
    /// Records `partition_cache_hits` and `partition_cache_misses` metrics.
    async fn get_or_compile_partition(
        &self,
        partition_ref: &str,
    ) -> Result<BackendPlan, LocalPoolError> {
        // Check cache first
        {
            let mut cache = self.cache.write().await;
            if let Some(compiled) = cache.get_mut(partition_ref) {
                compiled.last_used = std::time::Instant::now();
                self.stats.write().await.cache_hits += 1;
                count!("partition_cache_hits");
                return Ok(compiled.plan.clone());
            }
        }

        // Cache miss - need to compile
        self.stats.write().await.cache_misses += 1;
        count!("partition_cache_misses");

        // Get raw partition
        let raw_partition = self
            .raw_partitions
            .read()
            .await
            .get(partition_ref)
            .cloned()
            .ok_or_else(|| LocalPoolError::PartitionNotLoaded(partition_ref.to_string()))?;

        // Compile the partition's IR for the local backend
        let plan = self.compile_partition(&raw_partition)?;

        // Cache the compiled plan
        let size_bytes = std::mem::size_of::<BackendPlan>()
            + plan.instructions.len() * 128 // Rough estimate per instruction
            + plan.workspace_size;

        let compiled = CompiledPartition {
            plan: plan.clone(),
            size_bytes,
            last_used: std::time::Instant::now(),
        };

        // Evict old entries if needed
        self.evict_if_needed(size_bytes).await;

        self.cache
            .write()
            .await
            .insert(partition_ref.to_string(), compiled);

        tracing::debug!("Compiled and cached partition: {}", partition_ref);
        Ok(plan)
    }

    /// Compile a partition's IR to a BackendPlan for the local backend.
    #[allow(clippy::unused_self, clippy::unnecessary_wraps)]
    fn compile_partition(&self, partition: &PlanPartition) -> Result<BackendPlan, LocalPoolError> {
        use hologram_holo::PlanMetadata;

        // The partition contains portable IR bytes
        // Check for our partition format marker
        if partition.ir_bytes.starts_with(b"HOLO_PARTITION_V1") {
            // This is our simple passthrough format - create a minimal plan
            // In production, this would deserialize the full IR and compile it
            return Ok(BackendPlan {
                instructions: Vec::new(),
                buffers: Vec::new(),
                constants: Vec::new(),
                workspace_size: 0,
                dependencies: Vec::new(),
                metadata: PlanMetadata {
                    name: partition.name().to_string(),
                    version: "0.1.0".to_string(),
                    author: None,
                    description: None,
                },
                node_buffer_map: Vec::new(),
                observable_metadata: hologram_holo::ObservableMetadata::default(),
                lut_section: hologram_holo::LutSection::new(),
            });
        }

        // Try to deserialize as a BackendPlan directly (for pre-compiled partitions)
        if let Ok(archived) = rkyv::check_archived_root::<BackendPlan>(&partition.ir_bytes) {
            let plan: BackendPlan = archived
                .deserialize(&mut Infallible)
                .expect("Infallible deserialization");
            return Ok(plan);
        }

        // If we can't deserialize, create a passthrough plan
        // In a full implementation, this would compile from IR
        Ok(BackendPlan {
            instructions: Vec::new(),
            buffers: Vec::new(),
            constants: Vec::new(),
            workspace_size: 0,
            dependencies: Vec::new(),
            metadata: PlanMetadata {
                name: partition.name().to_string(),
                version: "0.1.0".to_string(),
                author: None,
                description: None,
            },
            node_buffer_map: Vec::new(),
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        })
    }

    /// Execute a compiled plan with the given inputs.
    #[allow(clippy::unused_self)]
    fn execute_plan(
        &self,
        plan: &BackendPlan,
        inputs: &[Vec<u8>],
        backend: &dyn Backend,
    ) -> Result<Vec<Vec<u8>>, LocalPoolError> {
        // If the plan is empty (passthrough), just return inputs as outputs
        if plan.instructions.is_empty() {
            return Ok(inputs.to_vec());
        }

        // Prepare input slices
        let input_slices: Vec<&[u8]> = inputs.iter().map(Vec::as_slice).collect();

        // Allocate output buffers
        let output_size = plan.workspace_size.max(1024);
        let mut output = vec![0u8; output_size];
        let mut output_slices: Vec<&mut [u8]> = vec![output.as_mut_slice()];

        // Execute the plan using the backend
        backend.execute_plan(plan, &input_slices, &mut output_slices)?;

        Ok(vec![output])
    }

    /// Create a backend instance for execution.
    fn create_backend(&self) -> Result<Box<dyn Backend>, LocalPoolError> {
        match &self.config.backend_type {
            BackendType::Cpu => Ok(Box::new(hologram_backend::cpu::CpuBackend::new())),
            BackendType::Wasm => Ok(Box::new(hologram_backend::wasm::WasmBackend::new())),
            other => Err(LocalPoolError::ExecutionFailed(format!(
                "Backend {other:?} not supported for partition execution"
            ))),
        }
    }

    /// Evict old cache entries if memory limit would be exceeded.
    async fn evict_if_needed(&self, new_size: usize) {
        let mut cache = self.cache.write().await;

        // Calculate current size
        let current_size: usize = cache.values().map(|c| c.size_bytes).sum();

        if current_size + new_size > self.config.max_cache_memory {
            // Find oldest entries to evict (LRU)
            let mut entries: Vec<_> = cache
                .iter()
                .map(|(k, v)| (k.clone(), v.last_used, v.size_bytes))
                .collect();
            entries.sort_by_key(|(_, t, _)| *t);

            let mut freed = 0;
            for (key, _, size) in entries {
                if current_size - freed + new_size <= self.config.max_cache_memory {
                    break;
                }
                if cache.remove(&key).is_some() {
                    freed += size;
                    tracing::debug!("Evicted cached partition: {}", key);
                }
            }
        }
    }

    /// Get execution statistics.
    pub async fn stats(&self) -> PartitionExecutorStats {
        self.stats.read().await.clone()
    }

    /// Get cache size in bytes.
    pub async fn cache_size_bytes(&self) -> usize {
        self.cache.read().await.values().map(|c| c.size_bytes).sum()
    }

    /// Get number of cached partitions.
    pub async fn cache_count(&self) -> usize {
        self.cache.read().await.len()
    }
}

/// A local worker pool for in-process partition execution.
///
/// This pool holds `PartitionExecutor` instances and provides direct
/// execution without any network overhead. It's the default execution
/// strategy for single-machine deployments.
pub struct LocalWorkerPool {
    /// Configuration.
    config: LocalPoolConfig,
    /// Worker executors.
    executors: Arc<RwLock<HashMap<WorkerId, Arc<PartitionExecutor>>>>,
    /// Next worker ID.
    next_worker_id: AtomicU64,
}

impl LocalWorkerPool {
    /// Create a new local worker pool.
    #[must_use]
    pub fn new(config: LocalPoolConfig) -> Self {
        Self {
            config,
            executors: Arc::new(RwLock::new(HashMap::new())),
            next_worker_id: AtomicU64::new(0),
        }
    }

    /// Get the pool configuration.
    #[must_use]
    pub fn config(&self) -> &LocalPoolConfig {
        &self.config
    }

    /// Add a worker to the pool with the specified backend type.
    ///
    /// Returns the worker ID.
    pub async fn add_worker(&self, backend_type: BackendType) -> WorkerId {
        let id = WorkerId(self.next_worker_id.fetch_add(1, Ordering::SeqCst));

        let mut executor_config = self.config.executor_config.clone();
        executor_config.backend_type = backend_type.clone();

        let executor = Arc::new(PartitionExecutor::new(id, executor_config));
        self.executors.write().await.insert(id, executor);

        tracing::info!("Added local worker {} with backend {:?}", id, &backend_type);
        id
    }

    /// Remove a worker from the pool.
    pub async fn remove_worker(&self, worker_id: WorkerId) -> Option<Arc<PartitionExecutor>> {
        let removed = self.executors.write().await.remove(&worker_id);
        if removed.is_some() {
            tracing::info!("Removed local worker {}", worker_id);
        }
        removed
    }

    /// Get the number of workers in the pool.
    pub async fn worker_count(&self) -> usize {
        self.executors.read().await.len()
    }

    /// Get all worker IDs.
    pub async fn worker_ids(&self) -> Vec<WorkerId> {
        self.executors.read().await.keys().copied().collect()
    }

    /// Get executor for a worker (for direct access).
    pub async fn get_executor(&self, worker_id: WorkerId) -> Option<Arc<PartitionExecutor>> {
        self.executors.read().await.get(&worker_id).cloned()
    }

    /// Load a partition onto a specific worker.
    pub async fn load_partition(
        &self,
        worker_id: WorkerId,
        partition_ref: &str,
        partition: PlanPartition,
    ) -> Result<(), LocalPoolError> {
        let executor = self
            .executors
            .read()
            .await
            .get(&worker_id)
            .cloned()
            .ok_or(LocalPoolError::WorkerNotFound(worker_id))?;

        executor.load_partition(partition_ref, partition).await?;
        Ok(())
    }

    /// Load a partition onto all workers (for redundancy).
    pub async fn load_partition_all(
        &self,
        partition_ref: &str,
        partition: PlanPartition,
    ) -> Result<(), LocalPoolError> {
        let executors = self.executors.read().await;

        if executors.is_empty() {
            return Err(LocalPoolError::EmptyPool);
        }

        for executor in executors.values() {
            executor
                .load_partition(partition_ref, partition.clone())
                .await?;
        }

        Ok(())
    }

    /// Check if a worker has a partition loaded.
    pub async fn has_partition(&self, worker_id: WorkerId, partition_ref: &str) -> bool {
        if let Some(executor) = self.executors.read().await.get(&worker_id) {
            executor.has_partition(partition_ref).await
        } else {
            false
        }
    }

    /// Execute a partition on a specific worker.
    ///
    /// This is the main execution path - no network overhead, just a direct
    /// function call to the executor.
    pub async fn execute(
        &self,
        worker_id: WorkerId,
        request: PartitionRequest,
    ) -> Result<PartitionResult, LocalPoolError> {
        let executor = self
            .executors
            .read()
            .await
            .get(&worker_id)
            .cloned()
            .ok_or(LocalPoolError::WorkerNotFound(worker_id))?;

        // Direct execution - no serialization, no network
        executor.execute(request).await
    }

    /// Execute a partition on any available worker that has it loaded.
    ///
    /// Tries workers in order of preference:
    /// 1. Workers that have the partition cached (compiled)
    /// 2. Workers that have the partition loaded (raw)
    /// 3. Any available worker (will need to load partition first)
    pub async fn execute_any(
        &self,
        request: PartitionRequest,
    ) -> Result<PartitionResult, LocalPoolError> {
        let partition_ref = &request.partition_ref;
        let executors = self.executors.read().await;

        if executors.is_empty() {
            return Err(LocalPoolError::EmptyPool);
        }

        // Find best worker for this partition
        let mut best_worker: Option<(WorkerId, Arc<PartitionExecutor>)> = None;

        for (worker_id, executor) in executors.iter() {
            if executor.has_partition(partition_ref).await {
                best_worker = Some((*worker_id, executor.clone()));
                break;
            }
            // Fall back to first available
            if best_worker.is_none() {
                best_worker = Some((*worker_id, executor.clone()));
            }
        }

        let (_, executor) = best_worker.ok_or(LocalPoolError::EmptyPool)?;
        drop(executors); // Release read lock

        executor.execute(request).await
    }

    /// Get loaded partitions across all workers.
    pub async fn loaded_partitions(&self) -> HashMap<WorkerId, Vec<String>> {
        let executors = self.executors.read().await;
        let mut result = HashMap::new();

        for (worker_id, executor) in executors.iter() {
            result.insert(*worker_id, executor.loaded_partitions().await);
        }

        result
    }

    /// Check if pool has any workers.
    pub async fn is_empty(&self) -> bool {
        self.executors.read().await.is_empty()
    }

    /// Get backend types of all workers.
    pub async fn backend_types(&self) -> HashMap<WorkerId, BackendType> {
        let executors = self.executors.read().await;
        executors
            .iter()
            .map(|(id, e)| (*id, e.backend_type().clone()))
            .collect()
    }

    /// Get aggregate statistics across all workers.
    pub async fn aggregate_stats(&self) -> PartitionExecutorStats {
        let executors = self.executors.read().await;
        let mut aggregate = PartitionExecutorStats::default();

        for executor in executors.values() {
            let stats = executor.stats().await;
            aggregate.total_executions += stats.total_executions;
            aggregate.successful_executions += stats.successful_executions;
            aggregate.failed_executions += stats.failed_executions;
            aggregate.cache_hits += stats.cache_hits;
            aggregate.cache_misses += stats.cache_misses;
            aggregate.total_duration_ms += stats.total_duration_ms;
        }

        aggregate
    }
}

impl Default for LocalWorkerPool {
    fn default() -> Self {
        Self::new(LocalPoolConfig::default())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn test_partition() -> PlanPartition {
        let ir_bytes = b"HOLO_PARTITION_V1_test_data".to_vec();
        let mut partition = PlanPartition::new("test_partition", [0; 32], ir_bytes);
        // Set the correct hash
        partition.content_hash = partition.compute_hash();
        partition.with_cost(100).with_memory(1024)
    }

    #[tokio::test]
    async fn test_pool_creation() {
        let pool = LocalWorkerPool::default();
        assert!(pool.is_empty().await);
        assert_eq!(pool.worker_count().await, 0);
    }

    #[tokio::test]
    async fn test_pool_config() {
        let config = LocalPoolConfig::new()
            .with_max_workers(8)
            .with_executor_config(
                PartitionExecutorConfig::new()
                    .with_backend_type(BackendType::Cpu)
                    .with_max_cached(64),
            );

        assert_eq!(config.max_workers, 8);
        assert_eq!(config.executor_config.max_cached_partitions, 64);
    }

    #[tokio::test]
    async fn test_add_worker() {
        let pool = LocalWorkerPool::default();
        let worker_id = pool.add_worker(BackendType::Cpu).await;

        assert!(!pool.is_empty().await);
        assert_eq!(pool.worker_count().await, 1);
        assert!(pool.get_executor(worker_id).await.is_some());
    }

    #[tokio::test]
    async fn test_add_multiple_workers() {
        let pool = LocalWorkerPool::default();
        let w1 = pool.add_worker(BackendType::Cpu).await;
        let w2 = pool.add_worker(BackendType::Cpu).await;

        assert_eq!(pool.worker_count().await, 2);
        assert_ne!(w1, w2);
    }

    #[tokio::test]
    async fn test_remove_worker() {
        let pool = LocalWorkerPool::default();
        let worker_id = pool.add_worker(BackendType::Cpu).await;

        let removed = pool.remove_worker(worker_id).await;
        assert!(removed.is_some());
        assert!(pool.is_empty().await);
    }

    #[tokio::test]
    async fn test_load_partition() {
        let pool = LocalWorkerPool::default();
        let worker_id = pool.add_worker(BackendType::Cpu).await;
        let partition = test_partition();

        pool.load_partition(worker_id, "model/p1:v1.0", partition)
            .await
            .unwrap();

        assert!(pool.has_partition(worker_id, "model/p1:v1.0").await);
    }

    #[tokio::test]
    async fn test_load_partition_invalid_hash() {
        let pool = LocalWorkerPool::default();
        let worker_id = pool.add_worker(BackendType::Cpu).await;

        // Create partition with invalid hash
        let partition = PlanPartition::new("test", [0; 32], vec![1, 2, 3]);

        let result = pool
            .load_partition(worker_id, "model/p1:v1.0", partition)
            .await;
        assert!(matches!(result, Err(LocalPoolError::InvalidInput(_))));
    }

    #[tokio::test]
    async fn test_load_partition_all() {
        let pool = LocalWorkerPool::default();
        let w1 = pool.add_worker(BackendType::Cpu).await;
        let w2 = pool.add_worker(BackendType::Cpu).await;

        pool.load_partition_all("model/p1:v1.0", test_partition())
            .await
            .unwrap();

        assert!(pool.has_partition(w1, "model/p1:v1.0").await);
        assert!(pool.has_partition(w2, "model/p1:v1.0").await);
    }

    #[tokio::test]
    async fn test_load_partition_all_empty_pool() {
        let pool = LocalWorkerPool::default();
        let result = pool
            .load_partition_all("model/p1:v1.0", test_partition())
            .await;
        assert!(matches!(result, Err(LocalPoolError::EmptyPool)));
    }

    #[tokio::test]
    async fn test_execute_direct() {
        let pool = LocalWorkerPool::default();
        let worker_id = pool.add_worker(BackendType::Cpu).await;

        pool.load_partition(worker_id, "model/p1:v1.0", test_partition())
            .await
            .unwrap();

        let request = PartitionRequest::new("model/p1:v1.0", vec![vec![1, 2, 3]]);
        let result = pool.execute(worker_id, request).await.unwrap();

        // Passthrough returns inputs as outputs
        assert_eq!(result.outputs, vec![vec![1, 2, 3]]);
        assert_eq!(result.worker_id, worker_id);
    }

    #[tokio::test]
    async fn test_execute_any() {
        let pool = LocalWorkerPool::default();
        pool.add_worker(BackendType::Cpu).await;

        pool.load_partition_all("model/p1:v1.0", test_partition())
            .await
            .unwrap();

        let request = PartitionRequest::new("model/p1:v1.0", vec![vec![1, 2, 3]]);
        let result = pool.execute_any(request).await.unwrap();

        assert_eq!(result.outputs, vec![vec![1, 2, 3]]);
    }

    #[tokio::test]
    async fn test_execute_worker_not_found() {
        let pool = LocalWorkerPool::default();
        let fake_worker = WorkerId(999);

        let request = PartitionRequest::new("model/p1:v1.0", vec![]);
        let result = pool.execute(fake_worker, request).await;

        assert!(matches!(result, Err(LocalPoolError::WorkerNotFound(_))));
    }

    #[tokio::test]
    async fn test_execute_partition_not_loaded() {
        let pool = LocalWorkerPool::default();
        let worker_id = pool.add_worker(BackendType::Cpu).await;

        let request = PartitionRequest::new("missing:v1.0", vec![]);
        let result = pool.execute(worker_id, request).await;

        assert!(matches!(result, Err(LocalPoolError::PartitionNotLoaded(_))));
    }

    #[tokio::test]
    async fn test_execute_any_empty_pool() {
        let pool = LocalWorkerPool::default();
        let request = PartitionRequest::new("model/p1:v1.0", vec![]);

        let result = pool.execute_any(request).await;
        assert!(matches!(result, Err(LocalPoolError::EmptyPool)));
    }

    #[tokio::test]
    async fn test_backend_types() {
        let pool = LocalWorkerPool::default();
        let w1 = pool.add_worker(BackendType::Cpu).await;
        let w2 = pool.add_worker(BackendType::Wasm).await;

        let types = pool.backend_types().await;
        assert_eq!(types.get(&w1), Some(&BackendType::Cpu));
        assert_eq!(types.get(&w2), Some(&BackendType::Wasm));
    }

    #[tokio::test]
    async fn test_worker_ids() {
        let pool = LocalWorkerPool::default();
        let w1 = pool.add_worker(BackendType::Cpu).await;
        let w2 = pool.add_worker(BackendType::Cpu).await;

        let ids = pool.worker_ids().await;
        assert!(ids.contains(&w1));
        assert!(ids.contains(&w2));
    }

    #[tokio::test]
    async fn test_loaded_partitions_across_workers() {
        let pool = LocalWorkerPool::default();
        let w1 = pool.add_worker(BackendType::Cpu).await;
        let w2 = pool.add_worker(BackendType::Cpu).await;

        pool.load_partition(w1, "model/p1:v1.0", test_partition())
            .await
            .unwrap();
        pool.load_partition(w2, "model/p2:v1.0", test_partition())
            .await
            .unwrap();

        let loaded = pool.loaded_partitions().await;
        assert!(loaded[&w1].contains(&"model/p1:v1.0".to_string()));
        assert!(loaded[&w2].contains(&"model/p2:v1.0".to_string()));
    }

    #[tokio::test]
    async fn test_aggregate_stats() {
        let pool = LocalWorkerPool::default();
        let w1 = pool.add_worker(BackendType::Cpu).await;
        let w2 = pool.add_worker(BackendType::Cpu).await;

        pool.load_partition(w1, "model/p1:v1.0", test_partition())
            .await
            .unwrap();
        pool.load_partition(w2, "model/p1:v1.0", test_partition())
            .await
            .unwrap();

        // Execute on both workers
        pool.execute(w1, PartitionRequest::new("model/p1:v1.0", vec![vec![1]]))
            .await
            .unwrap();
        pool.execute(w2, PartitionRequest::new("model/p1:v1.0", vec![vec![2]]))
            .await
            .unwrap();

        let stats = pool.aggregate_stats().await;
        assert_eq!(stats.total_executions, 2);
        assert_eq!(stats.successful_executions, 2);
    }

    #[test]
    fn test_partition_request() {
        let req = PartitionRequest::new("model/p1:v1.0", vec![vec![1, 2, 3]]).with_priority(10);

        assert_eq!(req.partition_ref, "model/p1:v1.0");
        assert_eq!(req.priority, 10);
        assert_eq!(req.inputs, vec![vec![1, 2, 3]]);
    }

    #[test]
    fn test_partition_result() {
        let result = PartitionResult::new(1, vec![vec![1, 2, 3]], 100, WorkerId(1));

        assert_eq!(result.request_id, 1);
        assert!(!result.is_empty());
        assert_eq!(result.total_output_bytes(), 3);

        let empty = PartitionResult::new(2, vec![], 50, WorkerId(1));
        assert!(empty.is_empty());
    }

    #[test]
    #[allow(clippy::float_cmp)]
    fn test_partition_executor_stats() {
        let mut stats = PartitionExecutorStats::default();
        assert_eq!(stats.average_duration_ms(), 0.0);
        assert_eq!(stats.success_rate(), 1.0);
        assert_eq!(stats.cache_hit_rate(), 0.0);

        stats.total_executions = 10;
        stats.total_duration_ms = 1000;
        assert_eq!(stats.average_duration_ms(), 100.0);

        stats.successful_executions = 8;
        stats.failed_executions = 2;
        assert_eq!(stats.success_rate(), 0.8);

        stats.cache_hits = 6;
        stats.cache_misses = 4;
        assert_eq!(stats.cache_hit_rate(), 0.6);
    }

    #[test]
    fn test_local_pool_error_display() {
        let err = LocalPoolError::WorkerNotFound(WorkerId(1));
        assert!(err.to_string().contains("worker-1"));

        let err = LocalPoolError::PartitionNotLoaded("test:v1".to_string());
        assert!(err.to_string().contains("test:v1"));

        let err = LocalPoolError::EmptyPool;
        assert!(err.to_string().contains("empty"));

        let err = LocalPoolError::CompilationFailed("syntax error".to_string());
        assert!(err.to_string().contains("syntax error"));

        let err = LocalPoolError::ExecutionFailed("timeout".to_string());
        assert!(err.to_string().contains("timeout"));
    }

    #[tokio::test]
    async fn test_partition_executor_direct() {
        let executor = PartitionExecutor::new(WorkerId(1), PartitionExecutorConfig::default());

        assert_eq!(executor.worker_id(), WorkerId(1));
        assert_eq!(executor.backend_type(), &BackendType::Cpu);

        executor
            .load_partition("test:v1", test_partition())
            .await
            .unwrap();

        assert!(executor.has_partition("test:v1").await);

        let loaded = executor.loaded_partitions().await;
        assert!(loaded.contains(&"test:v1".to_string()));

        executor.unload_partition("test:v1").await;
        assert!(!executor.has_partition("test:v1").await);
    }

    #[tokio::test]
    async fn test_partition_executor_cache_hit() {
        let executor = PartitionExecutor::new(WorkerId(1), PartitionExecutorConfig::default());
        executor
            .load_partition("test:v1", test_partition())
            .await
            .unwrap();

        // First execution - cache miss
        let req1 = PartitionRequest::new("test:v1", vec![]);
        executor.execute(req1).await.unwrap();

        // Second execution - cache hit
        let req2 = PartitionRequest::new("test:v1", vec![]);
        executor.execute(req2).await.unwrap();

        let stats = executor.stats().await;
        assert_eq!(stats.cache_misses, 1);
        assert_eq!(stats.cache_hits, 1);
        assert_eq!(stats.total_executions, 2);
    }

    #[tokio::test]
    async fn test_partition_executor_cache_size() {
        let executor = PartitionExecutor::new(WorkerId(1), PartitionExecutorConfig::default());
        executor
            .load_partition("test:v1", test_partition())
            .await
            .unwrap();

        // Compile by executing
        let req = PartitionRequest::new("test:v1", vec![]);
        executor.execute(req).await.unwrap();

        assert!(executor.cache_size_bytes().await > 0);
        assert_eq!(executor.cache_count().await, 1);
    }
}
