//! SHA-256 compression function.
//!
//! This module implements the SHA-256 compression function as specified in
//! FIPS 180-4. The implementation uses micro-optimizations including:
//!
//! - Loop unrolling (8 rounds per iteration)
//! - Sliding window message schedule (16 words instead of 64)
//! - Inlined round functions
//! - Optimized bitwise operations
//! - Specialized second-hash compression for double SHA-256

/// SHA-256 round constants K (first 32 bits of fractional parts of cube roots of first 64 primes).
pub const K: [u32; 64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

/// Initial hash values H0 (first 32 bits of fractional parts of square roots of first 8 primes).
pub const H0: [u32; 8] = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];

/// σ₀ function for message schedule
#[inline(always)]
pub(crate) const fn sigma0(x: u32) -> u32 {
    x.rotate_right(7) ^ x.rotate_right(18) ^ (x >> 3)
}

/// σ₁ function for message schedule
#[inline(always)]
pub(crate) const fn sigma1(x: u32) -> u32 {
    x.rotate_right(17) ^ x.rotate_right(19) ^ (x >> 10)
}

/// Σ₀ function for compression
#[inline(always)]
pub(crate) const fn big_sigma0(x: u32) -> u32 {
    x.rotate_right(2) ^ x.rotate_right(13) ^ x.rotate_right(22)
}

/// Σ₁ function for compression
#[inline(always)]
pub(crate) const fn big_sigma1(x: u32) -> u32 {
    x.rotate_right(6) ^ x.rotate_right(11) ^ x.rotate_right(25)
}

/// Ch (choice) function
#[inline(always)]
pub(crate) const fn ch(x: u32, y: u32, z: u32) -> u32 {
    (x & y) ^ (!x & z)
}

/// Maj (majority) function
#[inline(always)]
pub(crate) const fn maj(x: u32, y: u32, z: u32) -> u32 {
    (x & y) ^ (x & z) ^ (y & z)
}

/// Single round of SHA-256 compression (unrolled for performance)
macro_rules! sha256_round {
    ($a:expr, $b:expr, $c:expr, $d:expr, $e:expr, $f:expr, $g:expr, $h:expr, $k:expr, $w:expr) => {{
        let t1 = $h
            .wrapping_add(big_sigma1($e))
            .wrapping_add(ch($e, $f, $g))
            .wrapping_add($k)
            .wrapping_add($w);
        let t2 = big_sigma0($a).wrapping_add(maj($a, $b, $c));
        $d = $d.wrapping_add(t1);
        $h = t1.wrapping_add(t2);
    }};
}

/// Message schedule expansion for one word
macro_rules! schedule {
    ($w:expr, $i:expr) => {{
        let w15 = $w[($i + 1) & 0xF];
        let w2 = $w[($i + 14) & 0xF];
        let w16 = $w[$i & 0xF];
        let w7 = $w[($i + 9) & 0xF];
        $w[$i & 0xF] = sigma1(w2)
            .wrapping_add(w7)
            .wrapping_add(sigma0(w15))
            .wrapping_add(w16);
    }};
}

/// Load a big-endian u32 from bytes
#[inline(always)]
fn load_be32(bytes: &[u8]) -> u32 {
    u32::from_be_bytes([bytes[0], bytes[1], bytes[2], bytes[3]])
}

/// Convert SHA-256 state words to big-endian output bytes.
#[inline(always)]
pub(crate) fn state_to_bytes(state: &[u32; 8]) -> [u8; 32] {
    let mut out = [0u8; 32];
    let mut i = 0;
    while i < 8 {
        let bytes = state[i].to_be_bytes();
        out[i * 4] = bytes[0];
        out[i * 4 + 1] = bytes[1];
        out[i * 4 + 2] = bytes[2];
        out[i * 4 + 3] = bytes[3];
        i += 1;
    }
    out
}

/// Core 64-round SHA-256 computation on a pre-loaded message schedule.
///
/// Extracted from `compress` to enable reuse by `compress_second_hash`
/// without duplicating the 64 unrolled rounds.
#[inline]
fn compress_rounds(state: &mut [u32; 8], w: &mut [u32; 16]) {
    let mut a = state[0];
    let mut b = state[1];
    let mut c = state[2];
    let mut d = state[3];
    let mut e = state[4];
    let mut f = state[5];
    let mut g = state[6];
    let mut h = state[7];

    // Rounds 0-15 (use initial message words)
    sha256_round!(a, b, c, d, e, f, g, h, K[0], w[0]);
    sha256_round!(h, a, b, c, d, e, f, g, K[1], w[1]);
    sha256_round!(g, h, a, b, c, d, e, f, K[2], w[2]);
    sha256_round!(f, g, h, a, b, c, d, e, K[3], w[3]);
    sha256_round!(e, f, g, h, a, b, c, d, K[4], w[4]);
    sha256_round!(d, e, f, g, h, a, b, c, K[5], w[5]);
    sha256_round!(c, d, e, f, g, h, a, b, K[6], w[6]);
    sha256_round!(b, c, d, e, f, g, h, a, K[7], w[7]);
    sha256_round!(a, b, c, d, e, f, g, h, K[8], w[8]);
    sha256_round!(h, a, b, c, d, e, f, g, K[9], w[9]);
    sha256_round!(g, h, a, b, c, d, e, f, K[10], w[10]);
    sha256_round!(f, g, h, a, b, c, d, e, K[11], w[11]);
    sha256_round!(e, f, g, h, a, b, c, d, K[12], w[12]);
    sha256_round!(d, e, f, g, h, a, b, c, K[13], w[13]);
    sha256_round!(c, d, e, f, g, h, a, b, K[14], w[14]);
    sha256_round!(b, c, d, e, f, g, h, a, K[15], w[15]);

    // Rounds 16-31
    schedule!(w, 0);
    sha256_round!(a, b, c, d, e, f, g, h, K[16], w[0]);
    schedule!(w, 1);
    sha256_round!(h, a, b, c, d, e, f, g, K[17], w[1]);
    schedule!(w, 2);
    sha256_round!(g, h, a, b, c, d, e, f, K[18], w[2]);
    schedule!(w, 3);
    sha256_round!(f, g, h, a, b, c, d, e, K[19], w[3]);
    schedule!(w, 4);
    sha256_round!(e, f, g, h, a, b, c, d, K[20], w[4]);
    schedule!(w, 5);
    sha256_round!(d, e, f, g, h, a, b, c, K[21], w[5]);
    schedule!(w, 6);
    sha256_round!(c, d, e, f, g, h, a, b, K[22], w[6]);
    schedule!(w, 7);
    sha256_round!(b, c, d, e, f, g, h, a, K[23], w[7]);
    schedule!(w, 8);
    sha256_round!(a, b, c, d, e, f, g, h, K[24], w[8]);
    schedule!(w, 9);
    sha256_round!(h, a, b, c, d, e, f, g, K[25], w[9]);
    schedule!(w, 10);
    sha256_round!(g, h, a, b, c, d, e, f, K[26], w[10]);
    schedule!(w, 11);
    sha256_round!(f, g, h, a, b, c, d, e, K[27], w[11]);
    schedule!(w, 12);
    sha256_round!(e, f, g, h, a, b, c, d, K[28], w[12]);
    schedule!(w, 13);
    sha256_round!(d, e, f, g, h, a, b, c, K[29], w[13]);
    schedule!(w, 14);
    sha256_round!(c, d, e, f, g, h, a, b, K[30], w[14]);
    schedule!(w, 15);
    sha256_round!(b, c, d, e, f, g, h, a, K[31], w[15]);

    // Rounds 32-47
    schedule!(w, 0);
    sha256_round!(a, b, c, d, e, f, g, h, K[32], w[0]);
    schedule!(w, 1);
    sha256_round!(h, a, b, c, d, e, f, g, K[33], w[1]);
    schedule!(w, 2);
    sha256_round!(g, h, a, b, c, d, e, f, K[34], w[2]);
    schedule!(w, 3);
    sha256_round!(f, g, h, a, b, c, d, e, K[35], w[3]);
    schedule!(w, 4);
    sha256_round!(e, f, g, h, a, b, c, d, K[36], w[4]);
    schedule!(w, 5);
    sha256_round!(d, e, f, g, h, a, b, c, K[37], w[5]);
    schedule!(w, 6);
    sha256_round!(c, d, e, f, g, h, a, b, K[38], w[6]);
    schedule!(w, 7);
    sha256_round!(b, c, d, e, f, g, h, a, K[39], w[7]);
    schedule!(w, 8);
    sha256_round!(a, b, c, d, e, f, g, h, K[40], w[8]);
    schedule!(w, 9);
    sha256_round!(h, a, b, c, d, e, f, g, K[41], w[9]);
    schedule!(w, 10);
    sha256_round!(g, h, a, b, c, d, e, f, K[42], w[10]);
    schedule!(w, 11);
    sha256_round!(f, g, h, a, b, c, d, e, K[43], w[11]);
    schedule!(w, 12);
    sha256_round!(e, f, g, h, a, b, c, d, K[44], w[12]);
    schedule!(w, 13);
    sha256_round!(d, e, f, g, h, a, b, c, K[45], w[13]);
    schedule!(w, 14);
    sha256_round!(c, d, e, f, g, h, a, b, K[46], w[14]);
    schedule!(w, 15);
    sha256_round!(b, c, d, e, f, g, h, a, K[47], w[15]);

    // Rounds 48-63
    schedule!(w, 0);
    sha256_round!(a, b, c, d, e, f, g, h, K[48], w[0]);
    schedule!(w, 1);
    sha256_round!(h, a, b, c, d, e, f, g, K[49], w[1]);
    schedule!(w, 2);
    sha256_round!(g, h, a, b, c, d, e, f, K[50], w[2]);
    schedule!(w, 3);
    sha256_round!(f, g, h, a, b, c, d, e, K[51], w[3]);
    schedule!(w, 4);
    sha256_round!(e, f, g, h, a, b, c, d, K[52], w[4]);
    schedule!(w, 5);
    sha256_round!(d, e, f, g, h, a, b, c, K[53], w[5]);
    schedule!(w, 6);
    sha256_round!(c, d, e, f, g, h, a, b, K[54], w[6]);
    schedule!(w, 7);
    sha256_round!(b, c, d, e, f, g, h, a, K[55], w[7]);
    schedule!(w, 8);
    sha256_round!(a, b, c, d, e, f, g, h, K[56], w[8]);
    schedule!(w, 9);
    sha256_round!(h, a, b, c, d, e, f, g, K[57], w[9]);
    schedule!(w, 10);
    sha256_round!(g, h, a, b, c, d, e, f, K[58], w[10]);
    schedule!(w, 11);
    sha256_round!(f, g, h, a, b, c, d, e, K[59], w[11]);
    schedule!(w, 12);
    sha256_round!(e, f, g, h, a, b, c, d, K[60], w[12]);
    schedule!(w, 13);
    sha256_round!(d, e, f, g, h, a, b, c, K[61], w[13]);
    schedule!(w, 14);
    sha256_round!(c, d, e, f, g, h, a, b, K[62], w[14]);
    schedule!(w, 15);
    sha256_round!(b, c, d, e, f, g, h, a, K[63], w[15]);

    // Add compressed chunk to current hash value
    state[0] = state[0].wrapping_add(a);
    state[1] = state[1].wrapping_add(b);
    state[2] = state[2].wrapping_add(c);
    state[3] = state[3].wrapping_add(d);
    state[4] = state[4].wrapping_add(e);
    state[5] = state[5].wrapping_add(f);
    state[6] = state[6].wrapping_add(g);
    state[7] = state[7].wrapping_add(h);
}

/// SHA-256 compression function: process a single 512-bit block.
///
/// This is an optimized implementation using:
/// - Loop unrolling (8 rounds per iteration)
/// - Sliding window message schedule (16 words instead of 64)
/// - Inlined round macro
#[inline]
pub fn compress(state: &mut [u32; 8], block: &[u8; 64]) {
    let mut w = [0u32; 16];
    for i in 0..16 {
        w[i] = load_be32(&block[i * 4..]);
    }
    compress_rounds(state, &mut w);
}

/// Specialized compression for the second hash of double SHA-256.
///
/// Takes the first hash state as u32 words directly, skipping:
/// - State-to-bytes conversion between first and second hash
/// - Block construction (zeroing, copying, padding writes)
/// - Big-endian byte-swap loads for the 8 variable words
///
/// The second hash block is always:
/// `[w0..w7 = first_hash_state, w8 = 0x80000000, w9..w14 = 0, w15 = 0x00000100]`
#[inline]
pub fn compress_second_hash(first_hash_state: &[u32; 8]) -> [u8; 32] {
    state_to_bytes(&compress_second_hash_state(first_hash_state))
}

/// Like `compress_second_hash` but returns the raw `[u32; 8]` state.
///
/// Enables early rejection: check `state[7] == 0` (last 4 output bytes)
/// before converting to bytes, skipping the conversion for >99.99% of
/// nonces at typical mining difficulties.
#[inline]
pub fn compress_second_hash_state(first_hash_state: &[u32; 8]) -> [u32; 8] {
    let mut w = [0u32; 16];
    w[..8].copy_from_slice(first_hash_state);
    w[8] = 0x8000_0000;
    w[15] = 0x0000_0100;
    let mut state = H0;
    compress_rounds(&mut state, &mut w);
    state
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_compress_single_block() {
        let mut state = H0;
        let block = [0u8; 64];
        compress(&mut state, &block);
        // State should have changed
        assert_ne!(state, H0);
    }

    #[test]
    fn test_h0_values() {
        // Verify H0 matches FIPS 180-4
        assert_eq!(H0[0], 0x6a09e667);
        assert_eq!(H0[7], 0x5be0cd19);
    }

    #[test]
    fn test_k_values() {
        // Verify K constants match FIPS 180-4
        assert_eq!(K[0], 0x428a2f98);
        assert_eq!(K[63], 0xc67178f2);
    }

    #[test]
    fn test_sigma_functions() {
        // Test sigma0
        assert_eq!(
            sigma0(0x12345678),
            0x12345678_u32.rotate_right(7)
                ^ 0x12345678_u32.rotate_right(18)
                ^ (0x12345678_u32 >> 3)
        );
        // Test sigma1
        assert_eq!(
            sigma1(0x12345678),
            0x12345678_u32.rotate_right(17)
                ^ 0x12345678_u32.rotate_right(19)
                ^ (0x12345678_u32 >> 10)
        );
    }

    #[test]
    fn test_compress_second_hash_matches_manual() {
        // Compute a first hash state by compressing a known block
        let mut state = H0;
        let block = [0x61u8; 64]; // 'a' repeated
        compress(&mut state, &block);

        // Manual: build the second-hash block, compress with standard path
        let mut second_block = [0u8; 64];
        for (i, &word) in state.iter().enumerate() {
            second_block[i * 4..(i + 1) * 4].copy_from_slice(&word.to_be_bytes());
        }
        second_block[32] = 0x80;
        second_block[62] = 0x01;
        second_block[63] = 0x00;
        let mut expected_state = H0;
        compress(&mut expected_state, &second_block);
        let expected = state_to_bytes(&expected_state);

        // Specialized path
        let result = compress_second_hash(&state);

        assert_eq!(
            result, expected,
            "compress_second_hash must match manual block path"
        );
    }

    #[test]
    fn test_state_to_bytes_roundtrip() {
        let state: [u32; 8] = [
            0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab,
            0x5be0cd19,
        ];
        let bytes = state_to_bytes(&state);
        // Verify first word
        assert_eq!(bytes[0..4], [0x6a, 0x09, 0xe6, 0x67]);
        // Verify last word
        assert_eq!(bytes[28..32], [0x5b, 0xe0, 0xcd, 0x19]);
    }
}
