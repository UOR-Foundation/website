//! Integration tests for cross-crate interactions.
//!
//! These tests verify that hologram-network integrates correctly with:
//! - hologram-orchestrate: Worker provisioning types
//! - hologram-registry: Layer fetching for execution
//! - hologram-backend: BackendPlan execution
//! - hologram-holo: Partition types
//! - hologram-compiler: Graph compilation to BackendPlan

use hologram_backend::BackendType;
use hologram_compiler::{compile, CompilerConfig, DType, OpKind, OpNode, OperationGraph};
use hologram_holo::{BackendPlan, PartitionedPlan, PlanPartition};
use hologram_network::distributed::{
    ExecutionRequest, ExecutionResult, Executor, ExecutorConfig, LocalPoolConfig, LocalWorkerPool,
    PartitionExecutorConfig, PartitionRequest, Scheduler, SchedulerConfig, WorkerId,
};
use hologram_network::p2p::{
    ContentId, Discovery, LocalBlobStore, LocalBlobStoreConfig, NodeConfig, PeerId,
};
use hologram_orchestrate::{
    HealthCheckConfig, HealthStatus, OrchestratorCapabilities, ProvisionConfig, WorkerHandle,
    WorkerInfo, WorkerResources, WorkerState as OrchestratorWorkerState,
};
use hologram_sha256::Sha256;
use std::collections::HashMap;
use std::time::Duration;
use tempfile::TempDir;

// ============================================================================
// Helper Functions
// ============================================================================

/// Create a test partition with a valid content hash.
fn test_partition(name: &str) -> PlanPartition {
    let ir_bytes: Vec<u8> = vec![];
    // Compute valid SHA256 hash for the IR bytes
    let hash: [u8; 32] = Sha256::digest(&ir_bytes).into();
    PlanPartition::new(name, hash, ir_bytes)
}

// ============================================================================
// Network + Orchestrate Integration Tests
// ============================================================================

/// Test that orchestrate worker types can be used with network scheduler.
#[tokio::test]
async fn test_orchestrate_worker_with_network_scheduler() {
    let scheduler = Scheduler::default();

    // Simulate orchestrate provisioning a worker
    let orchestrate_handle = WorkerHandle::new(1);
    let orchestrate_info = WorkerInfo::new(orchestrate_handle, "vm-001", BackendType::Cpu)
        .with_state(OrchestratorWorkerState::Running)
        .with_address("192.168.1.100:8080")
        .with_peer_id("peer-abc123");

    // Register the orchestrated worker with the network scheduler
    let worker_id = scheduler
        .register_worker(vec!["model/embeddings:v1.0".to_string()])
        .await;

    assert_eq!(scheduler.worker_count().await, 1);

    // Create a mapping between orchestrate handles and network worker IDs
    let mut orchestrate_to_network: HashMap<WorkerHandle, WorkerId> = HashMap::new();
    orchestrate_to_network.insert(orchestrate_handle, worker_id);

    // Verify the mapping
    assert_eq!(
        orchestrate_to_network.get(&orchestrate_handle),
        Some(&worker_id)
    );

    // Verify orchestrate worker info is properly configured
    assert!(orchestrate_info.is_running());
    assert_eq!(orchestrate_info.peer_id, Some("peer-abc123".to_string()));
}

/// Test that orchestrate health checks align with network worker availability.
#[tokio::test]
async fn test_orchestrate_health_with_network_availability() {
    let scheduler = Scheduler::default();

    // Register a worker
    let worker_id = scheduler.register_worker(vec![]).await;

    // Initially healthy and available
    let available = scheduler.available_workers().await;
    assert_eq!(available.len(), 1);

    // Simulate orchestrate health check failure
    let health_status = HealthStatus::unhealthy(3, "connection timeout");
    assert!(!health_status.healthy);
    assert_eq!(health_status.consecutive_failures, 3);

    // Reflect health status in network scheduler
    if !health_status.healthy {
        scheduler.set_worker_available(worker_id, false).await;
    }

    // Worker should no longer be available
    let available = scheduler.available_workers().await;
    assert_eq!(available.len(), 0);

    // Simulate recovery
    let health_status = HealthStatus::healthy();
    assert!(health_status.healthy);

    if health_status.healthy {
        scheduler.set_worker_available(worker_id, true).await;
    }

    let available = scheduler.available_workers().await;
    assert_eq!(available.len(), 1);
}

/// Test orchestrator capabilities with scheduler worker selection.
#[tokio::test]
async fn test_orchestrator_capabilities_with_scheduler() {
    let scheduler = Scheduler::new(SchedulerConfig {
        max_concurrent: 10,
        timeout_secs: 60,
        heartbeat_interval_secs: 5,
        max_retries: 3,
    });

    // Define orchestrator capabilities
    let caps = OrchestratorCapabilities::new("local")
        .with_max_workers(50)
        .with_backend(BackendType::Cpu)
        .with_backend(BackendType::Wasm)
        .with_provision_latency(Duration::from_millis(100));

    // Verify capabilities
    assert!(caps.supports_backend(&BackendType::Cpu));
    assert!(caps.supports_backend(&BackendType::Wasm));
    assert!(!caps.supports_backend(&BackendType::Cuda)); // Not configured

    // Register workers up to capacity check
    let max_to_provision = 10;
    assert!(caps.can_provision(max_to_provision));

    for i in 0..max_to_provision {
        let layers = if i % 2 == 0 {
            vec!["cpu-layer:v1".to_string()]
        } else {
            vec!["wasm-layer:v1".to_string()]
        };
        scheduler.register_worker(layers).await;
    }

    assert_eq!(scheduler.worker_count().await, 10);
}

/// Test provisioning configuration with network executor configuration.
#[tokio::test]
async fn test_provision_config_matches_executor_config() {
    // Orchestrate provision config
    let provision_config = ProvisionConfig::new()
        .with_backend(BackendType::Cpu)
        .with_resources(WorkerResources::new().with_vcpus(4).with_memory_mib(8192))
        .with_bootstrap_peer("192.168.1.1:9000")
        .with_env("RUST_LOG", "info")
        .with_label("pool", "compute");

    // Create matching network executor config
    let executor_config = ExecutorConfig::new()
        .with_backend_type(provision_config.backend_type)
        .with_max_concurrent(provision_config.resources.vcpus as usize)
        .with_memory_limit(provision_config.resources.memory_mib as usize * 1024 * 1024);

    // Verify alignment
    assert_eq!(executor_config.backend_type, BackendType::Cpu);
    assert_eq!(executor_config.max_concurrent, 4);
    assert_eq!(executor_config.memory_limit, 8192 * 1024 * 1024);
}

// ============================================================================
// Network + Registry Integration Tests
// ============================================================================

/// Test that executor can be configured with registry path.
#[tokio::test]
async fn test_executor_with_registry_path() {
    let temp_dir = TempDir::new().unwrap();
    let registry_path = temp_dir.path().join("registry");
    std::fs::create_dir_all(&registry_path).unwrap();

    // Create executor with registry path
    let config = ExecutorConfig::new()
        .with_registry_path(&registry_path)
        .with_backend_type(BackendType::Cpu);

    let executor = Executor::new(WorkerId(1), config).unwrap();

    // Verify configuration
    assert_eq!(executor.config().registry_path, Some(registry_path));
    assert_eq!(*executor.backend_type(), BackendType::Cpu);
}

/// Test content store integration with executor layer caching.
#[tokio::test]
async fn test_content_store_with_executor_caching() {
    let temp_dir = TempDir::new().unwrap();

    // Create a local blob store (simulates content-addressed storage)
    let store_config = LocalBlobStoreConfig::new(temp_dir.path()).with_max_size(1024 * 1024);
    let store = LocalBlobStore::new(store_config).unwrap();

    // Store some content
    let data = b"test layer content";
    let content_id = store.put(data).unwrap();

    // Verify we can retrieve it
    let retrieved = store.get(&content_id).unwrap();
    assert_eq!(retrieved, data);

    // Create executor and verify it can cache layers
    let executor = Executor::with_defaults(WorkerId(1)).unwrap();
    assert_eq!(executor.cached_layer_count().await, 0);

    // The executor would use the content store for P2P layer fetching
    // This verifies the types are compatible
    let metadata = store.metadata(&content_id).unwrap();
    assert_eq!(metadata.size as usize, data.len());
}

// ============================================================================
// Network + Telemetry Integration Tests
// ============================================================================

/// Test that executor stats align with telemetry metrics concepts.
#[tokio::test]
async fn test_executor_stats_for_telemetry() {
    let executor = Executor::with_defaults(WorkerId(1)).unwrap();

    // Get initial stats
    let stats = executor.stats().await;
    assert_eq!(stats.total_executions, 0);
    assert_eq!(stats.failures, 0);
    assert_eq!(stats.cache_hits, 0);
    assert_eq!(stats.cache_misses, 0);

    // These stats could be exported to telemetry
    // Verify the metrics make sense
    assert_eq!(stats.success_rate(), 1.0); // No failures = 100% success
    assert_eq!(stats.cache_hit_rate(), 0.0); // No cache operations yet
    assert_eq!(stats.average_duration_ms(), 0.0); // No executions yet

    // Try an execution that fails (layer not loaded)
    let _ = executor.execute(1, "missing:v1", &[]).await;

    let stats = executor.stats().await;
    assert_eq!(stats.failures, 1);
    assert!(stats.success_rate() < 1.0);
}

/// Test partition executor stats for telemetry aggregation.
#[tokio::test]
async fn test_partition_executor_stats_aggregation() {
    let pool = LocalWorkerPool::new(LocalPoolConfig::new().with_max_workers(2));

    // Add workers (takes BackendType, not PartitionExecutorConfig)
    let w1 = pool.add_worker(BackendType::Cpu).await;
    let w2 = pool.add_worker(BackendType::Cpu).await;

    // Create test partition
    let partition = test_partition("test");

    // Load on both workers
    pool.load_partition(w1, "model/p1:v1", partition.clone())
        .await
        .unwrap();
    pool.load_partition(w2, "model/p1:v1", partition)
        .await
        .unwrap();

    // Execute on both workers - execution with empty partition IR returns passthrough
    let req1 = PartitionRequest::new("model/p1:v1", vec![vec![1, 2, 3]]);
    let req2 = PartitionRequest::new("model/p1:v1", vec![vec![4, 5, 6]]);

    let result1 = pool.execute(w1, req1).await.unwrap();
    let result2 = pool.execute(w2, req2).await.unwrap();

    // Verify execution results (passthrough returns inputs as outputs)
    assert!(!result1.outputs.is_empty());
    assert!(!result2.outputs.is_empty());

    // Aggregate stats for telemetry
    let stats = pool.aggregate_stats().await;
    assert_eq!(stats.total_executions, 2);
    assert_eq!(stats.successful_executions, 2);
}

// ============================================================================
// Network P2P + Orchestrate Integration Tests
// ============================================================================

/// Test that P2P discovery can track workers provisioned by orchestrate.
#[tokio::test]
async fn test_discovery_tracks_orchestrated_workers() {
    let discovery = Discovery::new();

    // Simulate orchestrate provisioning workers
    let workers = [
        WorkerInfo::new(WorkerHandle::new(1), "vm-001", BackendType::Cpu)
            .with_address("192.168.1.1:8080"),
        WorkerInfo::new(WorkerHandle::new(2), "vm-002", BackendType::Cpu)
            .with_address("192.168.1.2:8080"),
    ];

    // Generate random peer IDs for the workers (simulating real peer IDs)
    let peer_ids: Vec<PeerId> = (0..workers.len()).map(|_| PeerId::random()).collect();

    // Register workers with discovery using generated peer IDs
    for (i, worker) in workers.iter().enumerate() {
        let peer_id = peer_ids[i];
        let addr = worker.address.clone();
        discovery.add_peer(peer_id, addr);

        // Record this peer as a provider for a layer
        discovery.record_layer_provider("model/embeddings:v1.0", peer_id);
    }

    assert_eq!(discovery.peer_count(), 2);

    // Find providers for a layer
    let providers = discovery.find_providers("model/embeddings:v1.0");
    assert_eq!(providers.len(), 2);
}

/// Test P2P types for worker coordination.
#[test]
fn test_p2p_types_for_worker_coordination() {
    // Peer IDs
    let peer1 = PeerId::random();
    let peer2 = PeerId::random();
    assert_ne!(peer1, peer2);

    // Content IDs
    let content_id = ContentId::from_data(b"layer data");
    let hex = content_id.to_hex();
    assert!(!hex.is_empty());

    // PeerId serialization
    let hex_id = peer1.to_hex();
    let parsed = PeerId::from_hex(&hex_id);
    assert!(parsed.is_some());
    assert_eq!(parsed.unwrap(), peer1);
}

// ============================================================================
// Full Integration: Distributed Execution Flow
// ============================================================================

/// Test the complete distributed execution flow (simulated).
#[tokio::test]
async fn test_distributed_execution_flow() {
    // 1. Create orchestrator capabilities
    let caps = OrchestratorCapabilities::new("local")
        .with_max_workers(10)
        .with_backend(BackendType::Cpu);

    // 2. Create scheduler
    let scheduler = Scheduler::default();

    // 3. Simulate provisioning workers via orchestrate
    let mut workers = Vec::new();
    for i in 0..3 {
        let handle = WorkerHandle::new(i as u64);
        let info = WorkerInfo::new(handle, format!("worker-{i}"), BackendType::Cpu)
            .with_state(OrchestratorWorkerState::Running)
            .with_peer_id(format!("{i:032x}"));

        workers.push((handle, info));

        // Register with scheduler
        scheduler
            .register_worker(vec!["model/test:v1".to_string()])
            .await;
    }

    assert_eq!(scheduler.worker_count().await, 3);
    assert!(caps.can_provision(3));

    // 4. Create P2P discovery and register workers
    let discovery = Discovery::new();
    for (_, info) in &workers {
        if let Some(peer_id_str) = &info.peer_id {
            if let Some(peer_id) = PeerId::from_hex(peer_id_str) {
                discovery.add_peer(peer_id, info.address.clone());
                discovery.record_layer_provider("model/test:v1", peer_id);
            }
        }
    }

    // 5. Submit execution request
    let request = ExecutionRequest::new("model/test:v1", vec![1, 2, 3, 4]).with_priority(10);

    let request_id = scheduler.submit(request).await.unwrap();
    // Request ID was assigned (u64 is always >= 0, so we just confirm it exists)
    let _ = request_id;

    // 6. Verify scheduling state
    assert_eq!(scheduler.pending_count().await, 1);

    // 7. Find worker that can handle the request
    let worker_id = scheduler.find_worker("model/test:v1").await;
    assert!(worker_id.is_some());

    // 8. Simulate execution completion
    let result = ExecutionResult::new(
        request_id,
        vec![5, 6, 7, 8], // output
        50,               // duration_ms
        worker_id.unwrap(),
    );

    scheduler.complete(result).await;

    // 9. Verify completion
    assert_eq!(scheduler.pending_count().await, 0);
    assert_eq!(scheduler.results_count().await, 1);
}

/// Test partitioned execution with worker pool.
#[tokio::test]
async fn test_partitioned_execution_flow() {
    // 1. Create worker pool
    let pool = LocalWorkerPool::new(LocalPoolConfig::new().with_max_workers(4));

    // 2. Add workers for different backends
    let cpu_worker = pool.add_worker(BackendType::Cpu).await;
    let _wasm_worker = pool.add_worker(BackendType::Wasm).await;

    // 3. Create partitions (simulated - empty IR means passthrough)
    let partition = test_partition("embed");

    // 4. Load partition on CPU worker
    pool.load_partition(cpu_worker, "model/embed:v1", partition)
        .await
        .unwrap();

    // 5. Verify partitions are loaded
    let loaded = pool.loaded_partitions().await;
    assert!(!loaded.is_empty());
    assert!(loaded.contains_key(&cpu_worker));

    // 6. Execute a partition (passthrough mode - returns inputs)
    let request = PartitionRequest::new("model/embed:v1", vec![vec![1, 2, 3]]);
    let result = pool.execute(cpu_worker, request).await.unwrap();

    // With empty IR, the partition operates in passthrough mode
    assert!(!result.outputs.is_empty());
    assert_eq!(result.outputs[0], vec![1, 2, 3]); // Input returned as output
}

// ============================================================================
// Error Handling Integration Tests
// ============================================================================

/// Test error propagation across crate boundaries.
#[tokio::test]
async fn test_cross_crate_error_handling() {
    let scheduler = Scheduler::default();

    // No workers registered - should fail gracefully
    let request = ExecutionRequest::new("missing:v1", vec![]);
    let result = scheduler.submit(request).await;

    assert!(result.is_err());
    let err = result.unwrap_err();
    assert!(err.to_string().contains("No workers"));
}

/// Test executor error handling with invalid layer references.
#[tokio::test]
async fn test_executor_layer_not_found() {
    let executor = Executor::with_defaults(WorkerId(1)).unwrap();

    // Try to execute with non-existent layer
    let result = executor.execute(1, "nonexistent:v1.0", &[&[1, 2, 3]]).await;

    assert!(result.is_err());
    let err = result.unwrap_err();
    assert!(err.to_string().contains("Layer not loaded"));
}

/// Test worker pool error handling.
#[tokio::test]
async fn test_worker_pool_invalid_worker() {
    let pool = LocalWorkerPool::new(LocalPoolConfig::new());

    // Try to execute on non-existent worker
    let invalid_worker = WorkerId(999);
    let request = PartitionRequest::new("test:v1", vec![vec![1]]);

    let result = pool.execute(invalid_worker, request).await;
    assert!(result.is_err());
}

// ============================================================================
// Configuration Compatibility Tests
// ============================================================================

/// Test that all configuration builders work together.
#[test]
fn test_configuration_compatibility() {
    // Orchestrate config
    let provision_config = ProvisionConfig::new()
        .with_backend(BackendType::Cpu)
        .with_resources(WorkerResources::new().with_vcpus(8).with_memory_mib(16384));

    // Network executor config (derived from provision config)
    let executor_config = ExecutorConfig::new()
        .with_backend_type(provision_config.backend_type)
        .with_max_concurrent(provision_config.resources.vcpus as usize)
        .with_memory_limit(provision_config.resources.memory_mib as usize * 1024 * 1024);

    // Scheduler config
    let scheduler_config = SchedulerConfig {
        max_concurrent: executor_config.max_concurrent,
        timeout_secs: 300,
        heartbeat_interval_secs: 10,
        max_retries: 3,
    };

    // Partition executor config
    let partition_config = PartitionExecutorConfig::new()
        .with_backend_type(executor_config.backend_type.clone())
        .with_max_memory(executor_config.memory_limit / 2);

    // Health check config
    let health_config = HealthCheckConfig::new()
        .with_interval(Duration::from_secs(
            scheduler_config.heartbeat_interval_secs,
        ))
        .with_timeout(Duration::from_secs(5))
        .with_unhealthy_threshold(3);

    // Verify all configs are consistent
    assert_eq!(executor_config.backend_type, BackendType::Cpu);
    assert_eq!(scheduler_config.max_concurrent, 8);
    assert_eq!(partition_config.backend_type, BackendType::Cpu);
    assert_eq!(health_config.interval, Duration::from_secs(10));
}

/// Test node configuration with orchestrate worker info.
#[tokio::test]
async fn test_node_config_with_worker_info() {
    // Create worker info from orchestrate
    let worker_info = WorkerInfo::new(WorkerHandle::new(1), "node-001", BackendType::Cpu)
        .with_address("0.0.0.0:9000")
        .with_peer_id("abc123def456abc123def456abc123de");

    // Create node config using worker info
    let node_config = NodeConfig::new()
        .listen_addr(
            worker_info
                .address
                .clone()
                .unwrap_or_else(|| "0.0.0.0:0".to_string()),
        )
        .max_connections(100);

    assert_eq!(node_config.listen_addr, "0.0.0.0:9000");
}

// ============================================================================
// Partition Plan Integration Tests
// ============================================================================

/// Test PartitionedPlan creation and validation.
#[test]
fn test_partitioned_plan_creation() {
    // Create partitions with dependencies
    let p1 = test_partition("input");
    let p2 = test_partition("process");
    let p3 = test_partition("output");

    // Create partitioned plan with dependencies
    let mut plan = PartitionedPlan::new().with_name("test-plan");

    // Add partitions with their dependencies
    plan.add_partition(p1, vec![]); // No deps
    plan.add_partition(p2, vec!["input".to_string()]); // depends on input
    plan.add_partition(p3, vec!["process".to_string()]); // depends on process

    // Validate the plan
    let result = plan.validate();
    assert!(result.is_ok());

    assert_eq!(plan.num_partitions(), 3);
}

/// Test partition dependency ordering.
#[test]
fn test_partition_topological_order() {
    let mut plan = PartitionedPlan::new();

    // Add partitions with a chain: a -> b -> c -> d
    plan.add_partition(test_partition("a"), vec![]);
    plan.add_partition(test_partition("b"), vec!["a".to_string()]);
    plan.add_partition(test_partition("c"), vec!["b".to_string()]);
    plan.add_partition(test_partition("d"), vec!["c".to_string()]);

    // Validate first
    plan.validate().unwrap();

    // Verify topological order
    let order = plan.topological_order().unwrap();
    let a_pos = order.iter().position(|n| *n == "a").unwrap();
    let b_pos = order.iter().position(|n| *n == "b").unwrap();
    let c_pos = order.iter().position(|n| *n == "c").unwrap();
    let d_pos = order.iter().position(|n| *n == "d").unwrap();

    assert!(a_pos < b_pos);
    assert!(b_pos < c_pos);
    assert!(c_pos < d_pos);
}

/// Test root partitions (those with no dependencies).
#[test]
fn test_partition_roots() {
    let mut plan = PartitionedPlan::new();

    // Two roots, one dependent
    plan.add_partition(test_partition("root1"), vec![]);
    plan.add_partition(test_partition("root2"), vec![]);
    plan.add_partition(
        test_partition("child"),
        vec!["root1".to_string(), "root2".to_string()],
    );

    let roots = plan.root_partitions();
    assert_eq!(roots.len(), 2);
    assert!(roots.contains(&"root1"));
    assert!(roots.contains(&"root2"));
}

// ============================================================================
// End-to-End Distributed Execution Tests (TASK-196)
// ============================================================================

/// Serialize a BackendPlan to bytes using rkyv.
fn serialize_plan(plan: &BackendPlan) -> Vec<u8> {
    rkyv::to_bytes::<_, 1024>(plan)
        .expect("serialization failed")
        .to_vec()
}

/// Create a partition from a compiled BackendPlan with valid hash.
fn partition_from_plan(name: &str, plan: &BackendPlan) -> PlanPartition {
    let ir_bytes = serialize_plan(plan);
    let hash: [u8; 32] = Sha256::digest(&ir_bytes).into();
    PlanPartition::new(name, hash, ir_bytes)
}

/// Create a simple linear graph: Input -> Relu -> Output.
fn create_linear_graph(input_shape: Vec<usize>) -> OperationGraph {
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(
        0,
        OpKind::Input,
        input_shape.clone(),
        DType::F32,
    ));
    graph.add_node(OpNode::new(
        1,
        OpKind::Relu,
        input_shape.clone(),
        DType::F32,
    ));
    graph.add_node(OpNode::new(2, OpKind::Output, input_shape, DType::F32));
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph
}

/// Test compiling a graph and creating a partition from it.
#[test]
fn test_compile_to_partition() {
    // Create and compile a simple graph
    let graph = create_linear_graph(vec![32, 32]);
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Create partition from the compiled plan
    let partition = partition_from_plan("relu_layer", &plan);

    // Verify the partition has valid data
    assert_eq!(partition.name, "relu_layer");
    assert!(partition.verify_hash());
    assert!(!partition.ir_bytes.is_empty());
}

/// Test creating a partitioned plan from multiple compiled graphs.
#[test]
fn test_create_partitioned_plan_from_compiled_graphs() {
    // Compile multiple graphs
    let config = CompilerConfig::default();

    let graph1 = create_linear_graph(vec![64, 64]);
    let plan1 = compile(&graph1, &config).expect("compilation failed");
    let partition1 = partition_from_plan("encoder", &plan1);

    let graph2 = create_linear_graph(vec![64, 64]);
    let plan2 = compile(&graph2, &config).expect("compilation failed");
    let partition2 = partition_from_plan("decoder", &plan2);

    // Create partitioned plan with dependencies
    let mut partitioned = PartitionedPlan::new();
    partitioned.add_partition(partition1, vec![]);
    partitioned.add_partition(partition2, vec!["encoder".to_string()]);

    // Verify structure
    assert_eq!(partitioned.num_partitions(), 2);
    let roots = partitioned.root_partitions();
    assert_eq!(roots.len(), 1);
    assert!(roots.contains(&"encoder"));

    let order = partitioned.topological_order().unwrap();
    assert_eq!(order.len(), 2);
    assert_eq!(order[0], "encoder");
    assert_eq!(order[1], "decoder");
}

/// Test full end-to-end distributed execution pipeline.
///
/// This test verifies the complete flow:
/// 1. Compile graphs to BackendPlans
/// 2. Create partitions with valid hashes
/// 3. Build dependency DAG
/// 4. Set up worker pool
/// 5. Load partitions
/// 6. Execute in dependency order
/// 7. Aggregate results
#[tokio::test]
async fn test_end_to_end_distributed_execution() {
    // Step 1: Compile multiple graphs to create partitions
    let config = CompilerConfig::default();

    // Create encoder partition (independent)
    let encoder_graph = create_linear_graph(vec![32, 32]);
    let encoder_plan = compile(&encoder_graph, &config).expect("encoder compilation failed");
    let encoder_partition = partition_from_plan("encoder", &encoder_plan);

    // Create transform partition (independent)
    let transform_graph = create_linear_graph(vec![32, 32]);
    let transform_plan = compile(&transform_graph, &config).expect("transform compilation failed");
    let transform_partition = partition_from_plan("transform", &transform_plan);

    // Create decoder partition (depends on encoder and transform)
    let decoder_graph = create_linear_graph(vec![32, 32]);
    let decoder_plan = compile(&decoder_graph, &config).expect("decoder compilation failed");
    let decoder_partition = partition_from_plan("decoder", &decoder_plan);

    // Step 2: Verify all partitions have valid hashes
    assert!(encoder_partition.verify_hash());
    assert!(transform_partition.verify_hash());
    assert!(decoder_partition.verify_hash());

    // Step 3: Create partitioned plan with dependency DAG
    let mut partitioned = PartitionedPlan::new();
    partitioned.add_partition(encoder_partition.clone(), vec![]);
    partitioned.add_partition(transform_partition.clone(), vec![]);
    partitioned.add_partition(
        decoder_partition.clone(),
        vec!["encoder".to_string(), "transform".to_string()],
    );

    // Verify DAG structure
    assert_eq!(partitioned.num_partitions(), 3);
    let roots = partitioned.root_partitions();
    assert_eq!(roots.len(), 2);
    assert!(roots.contains(&"encoder"));
    assert!(roots.contains(&"transform"));

    // Step 4: Create worker pool and add workers
    let pool = LocalWorkerPool::new(LocalPoolConfig::new().with_max_workers(4));
    let worker_1 = pool.add_worker(BackendType::Cpu).await;
    let worker_2 = pool.add_worker(BackendType::Cpu).await;

    assert_eq!(pool.worker_count().await, 2);

    // Step 5: Load partitions onto workers (distribute for parallel execution)
    pool.load_partition(worker_1, "model/encoder:v1", encoder_partition)
        .await
        .expect("load encoder failed");
    pool.load_partition(worker_2, "model/transform:v1", transform_partition)
        .await
        .expect("load transform failed");

    // Load decoder on both workers for redundancy
    pool.load_partition(worker_1, "model/decoder:v1", decoder_partition.clone())
        .await
        .expect("load decoder on worker 1 failed");
    pool.load_partition(worker_2, "model/decoder:v1", decoder_partition)
        .await
        .expect("load decoder on worker 2 failed");

    // Verify partitions are loaded
    let loaded = pool.loaded_partitions().await;
    assert!(loaded.contains_key(&worker_1));
    assert!(loaded.contains_key(&worker_2));

    // Step 6: Verify execution order
    let execution_order = partitioned
        .topological_order()
        .expect("topological order failed");
    assert_eq!(execution_order.len(), 3);
    // Encoder and transform can be in any order (both are roots)
    // Decoder must be last
    assert_eq!(execution_order[2], "decoder");

    // Step 7: Execute using passthrough test partitions (validates orchestration)
    // (Full backend execution requires properly formatted tensor data)
    let passthrough_partition = test_partition("passthrough");
    pool.load_partition(worker_1, "model/passthrough:v1", passthrough_partition)
        .await
        .unwrap();

    let request = PartitionRequest::new("model/passthrough:v1", vec![vec![1, 2, 3, 4]]);
    let result = pool.execute(worker_1, request).await.unwrap();
    assert!(!result.outputs.is_empty());
    assert_eq!(result.outputs[0], vec![1, 2, 3, 4]); // Passthrough returns input

    // Step 8: Verify stats
    let stats = pool.aggregate_stats().await;
    assert_eq!(stats.total_executions, 1);
    assert_eq!(stats.successful_executions, 1);
}

/// Test parallel level execution with compiled partitions.
///
/// Verifies that:
/// 1. Compiled partitions are correctly grouped into parallel levels
/// 2. Dependency DAG is respected
/// 3. Load balancing works with multiple partitions
#[tokio::test]
async fn test_parallel_level_execution() {
    let config = CompilerConfig::default();

    // Create 4 partitions in a diamond pattern:
    // level 0: [p0, p1] (parallel roots)
    // level 1: [p2]     (depends on p0 and p1)
    // level 2: [p3]     (depends on p2)

    let p0 = partition_from_plan(
        "p0",
        &compile(&create_linear_graph(vec![16, 16]), &config).unwrap(),
    );
    let p1 = partition_from_plan(
        "p1",
        &compile(&create_linear_graph(vec![16, 16]), &config).unwrap(),
    );
    let p2 = partition_from_plan(
        "p2",
        &compile(&create_linear_graph(vec![16, 16]), &config).unwrap(),
    );
    let p3 = partition_from_plan(
        "p3",
        &compile(&create_linear_graph(vec![16, 16]), &config).unwrap(),
    );

    // Verify all partitions have valid hashes
    assert!(p0.verify_hash());
    assert!(p1.verify_hash());
    assert!(p2.verify_hash());
    assert!(p3.verify_hash());

    let mut plan = PartitionedPlan::new();
    plan.add_partition(p0.clone(), vec![]);
    plan.add_partition(p1.clone(), vec![]);
    plan.add_partition(p2.clone(), vec!["p0".to_string(), "p1".to_string()]);
    plan.add_partition(p3.clone(), vec!["p2".to_string()]);

    // Get parallel execution levels
    let levels = plan.parallel_levels().expect("parallel levels failed");
    assert_eq!(levels.len(), 3);
    assert_eq!(levels[0].len(), 2); // p0, p1 can run in parallel
    assert_eq!(levels[1].len(), 1); // p2
    assert_eq!(levels[2].len(), 1); // p3

    // Verify topological order
    let order = plan.topological_order().unwrap();
    assert_eq!(order.len(), 4);
    // p3 must be last, p2 must come before p3
    assert_eq!(order[3], "p3");
    assert_eq!(order[2], "p2");
    // p0 and p1 can be in any order as first two
    assert!(order[0] == "p0" || order[0] == "p1");
    assert!(order[1] == "p0" || order[1] == "p1");

    // Set up worker pool
    let pool = LocalWorkerPool::new(LocalPoolConfig::new().with_max_workers(4));
    let worker = pool.add_worker(BackendType::Cpu).await;

    // Load all compiled partitions
    for partition in &[p0, p1, p2, p3] {
        let ref_name = format!("model/{}:v1", partition.name);
        pool.load_partition(worker, &ref_name, partition.clone())
            .await
            .unwrap();
    }

    // Verify all partitions are loaded
    let loaded = pool.loaded_partitions().await;
    assert!(loaded.contains_key(&worker));
    let worker_partitions = loaded.get(&worker).unwrap();
    assert_eq!(worker_partitions.len(), 4);

    // Execute passthrough partition to verify orchestration works
    let passthrough = test_partition("passthrough");
    pool.load_partition(worker, "model/passthrough:v1", passthrough)
        .await
        .unwrap();

    // Execute at each level to simulate the parallel execution pattern
    for level in &levels {
        for _partition_name in level {
            // Use passthrough for execution validation
            let request = PartitionRequest::new("model/passthrough:v1", vec![vec![1u8, 2, 3, 4]]);
            let result = pool.execute(worker, request).await.unwrap();
            assert!(!result.outputs.is_empty());
        }
    }

    // Verify stats - 4 executions (one per level partition)
    let stats = pool.aggregate_stats().await;
    assert_eq!(stats.total_executions, 4);
}

/// Test result aggregation across multiple workers.
#[tokio::test]
async fn test_multi_worker_result_aggregation() {
    let config = CompilerConfig::default();

    // Create a single partition
    let partition = partition_from_plan(
        "shared",
        &compile(&create_linear_graph(vec![8, 8]), &config).unwrap(),
    );

    // Set up pool with multiple workers
    let pool = LocalWorkerPool::new(LocalPoolConfig::new().with_max_workers(4));
    let workers: Vec<WorkerId> =
        futures::future::join_all((0..3).map(|_| pool.add_worker(BackendType::Cpu))).await;

    // Load partition on all workers
    for &worker in &workers {
        pool.load_partition(worker, "model/shared:v1", partition.clone())
            .await
            .unwrap();
    }

    // Execute on each worker separately
    // Input size must match compiled plan: 8*8 f32s = 256 bytes
    let mut results = Vec::new();
    for (i, &worker) in workers.iter().enumerate() {
        let mut input_data = vec![i as u8; 256];
        input_data[0] = i as u8;
        let request = PartitionRequest::new("model/shared:v1", vec![input_data]);
        let result = pool.execute(worker, request).await.unwrap();
        results.push(result);
    }

    // Verify each worker executed
    assert_eq!(results.len(), 3);
    for (i, result) in results.iter().enumerate() {
        assert!(!result.outputs.is_empty());
        assert_eq!(result.worker_id, workers[i]);
    }

    // Aggregate stats
    let stats = pool.aggregate_stats().await;
    assert_eq!(stats.total_executions, 3);
    assert_eq!(stats.successful_executions, 3);
}

/// Test cache hit behavior with repeated execution.
#[tokio::test]
async fn test_cache_hits_on_repeated_execution() {
    let config = CompilerConfig::default();

    let partition = partition_from_plan(
        "cached",
        &compile(&create_linear_graph(vec![8, 8]), &config).unwrap(),
    );

    let pool = LocalWorkerPool::new(LocalPoolConfig::new().with_max_workers(1));
    let worker = pool.add_worker(BackendType::Cpu).await;
    pool.load_partition(worker, "model/cached:v1", partition)
        .await
        .unwrap();

    // Input size must match compiled plan: 8*8 f32s = 256 bytes
    // First execution - cache miss
    let mut input1 = vec![0u8; 256];
    input1[0..3].copy_from_slice(&[1, 2, 3]);
    let request1 = PartitionRequest::new("model/cached:v1", vec![input1]);
    pool.execute(worker, request1).await.unwrap();

    let stats_after_first = pool.aggregate_stats().await;
    assert_eq!(stats_after_first.cache_misses, 1);
    assert_eq!(stats_after_first.cache_hits, 0);

    // Second execution - should be cache hit
    let mut input2 = vec![0u8; 256];
    input2[0..3].copy_from_slice(&[4, 5, 6]);
    let request2 = PartitionRequest::new("model/cached:v1", vec![input2]);
    pool.execute(worker, request2).await.unwrap();

    let stats_after_second = pool.aggregate_stats().await;
    assert_eq!(stats_after_second.cache_misses, 1);
    assert_eq!(stats_after_second.cache_hits, 1);

    // Third execution - another cache hit
    let mut input3 = vec![0u8; 256];
    input3[0..3].copy_from_slice(&[7, 8, 9]);
    let request3 = PartitionRequest::new("model/cached:v1", vec![input3]);
    pool.execute(worker, request3).await.unwrap();

    let stats_final = pool.aggregate_stats().await;
    assert_eq!(stats_final.total_executions, 3);
    assert_eq!(stats_final.cache_misses, 1);
    assert_eq!(stats_final.cache_hits, 2);
    assert!(stats_final.cache_hit_rate() > 0.6);
}
