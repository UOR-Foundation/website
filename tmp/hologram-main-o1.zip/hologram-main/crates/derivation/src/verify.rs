//! Verification functions for derivation chains and factorizations.
//!
//! This module provides independent verification of factorization results
//! and derivation chains, enabling third-party auditing of proofs.

use crate::chain::{DerivationChain, StepKind};
use crate::factorize::{gcd, FactorizationResult};

/// Result of verifying a factorization.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VerificationResult {
    /// Whether the verification passed.
    pub valid: bool,
    /// Detailed verification steps.
    pub checks: Vec<VerificationCheck>,
}

/// A single verification check.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VerificationCheck {
    /// Name of the check.
    pub name: &'static str,
    /// Whether the check passed.
    pub passed: bool,
    /// Description of the check.
    pub description: String,
}

impl VerificationResult {
    /// Create a new verification result from checks.
    pub fn from_checks(checks: Vec<VerificationCheck>) -> Self {
        let valid = checks.iter().all(|c| c.passed);
        Self { valid, checks }
    }

    /// Get all failed checks.
    pub fn failures(&self) -> impl Iterator<Item = &VerificationCheck> {
        self.checks.iter().filter(|c| !c.passed)
    }
}

/// Verify a factorization result.
///
/// Performs the following checks:
/// 1. Product check: p * q == n
/// 2. Factor ordering: p <= q
/// 3. Non-trivial factors: p > 1 and q > 1
/// 4. Factors are proper: p < n and q < n
/// 5. Primality check (probabilistic): both factors are likely prime
///
/// # Example
///
/// ```
/// use hologram_derivation::{factorize_semiprime, verify_factorization};
///
/// let result = factorize_semiprime(10403, 32).unwrap();
/// let verification = verify_factorization(&result);
/// assert!(verification.valid);
/// ```
pub fn verify_factorization(result: &FactorizationResult) -> VerificationResult {
    let mut checks = Vec::new();

    // Check 1: Product check
    let product_ok = result.p * result.q == result.n;
    checks.push(VerificationCheck {
        name: "product",
        passed: product_ok,
        description: format!(
            "{} * {} = {} (expected {})",
            result.p,
            result.q,
            result.p * result.q,
            result.n
        ),
    });

    // Check 2: Factor ordering
    let ordered = result.p <= result.q;
    checks.push(VerificationCheck {
        name: "ordering",
        passed: ordered,
        description: format!("p={} <= q={}: {}", result.p, result.q, ordered),
    });

    // Check 3: Non-trivial factors
    let nontrivial = result.p > 1 && result.q > 1;
    checks.push(VerificationCheck {
        name: "nontrivial",
        passed: nontrivial,
        description: format!("p={} > 1 and q={} > 1: {}", result.p, result.q, nontrivial),
    });

    // Check 4: Proper factors
    let proper = result.p < result.n && result.q < result.n;
    checks.push(VerificationCheck {
        name: "proper",
        passed: proper,
        description: format!(
            "p={} < n={} and q={} < n={}: {}",
            result.p, result.n, result.q, result.n, proper
        ),
    });

    // Check 5: Primality (Miller-Rabin probabilistic test)
    let p_prime = is_probably_prime(result.p);
    let q_prime = is_probably_prime(result.q);
    checks.push(VerificationCheck {
        name: "primality_p",
        passed: p_prime,
        description: format!("p={} is prime: {}", result.p, p_prime),
    });
    checks.push(VerificationCheck {
        name: "primality_q",
        passed: q_prime,
        description: format!("q={} is prime: {}", result.q, q_prime),
    });

    // Check 6: GCD verification (orbit value should share factor with n)
    let gcd_check = gcd(result.v, result.n) == result.p || gcd(result.v, result.n) == result.q;
    checks.push(VerificationCheck {
        name: "gcd_orbit",
        passed: gcd_check,
        description: format!(
            "gcd({}, {}) = {} (should be p or q)",
            result.v,
            result.n,
            gcd(result.v, result.n)
        ),
    });

    VerificationResult::from_checks(checks)
}

/// Verify a derivation chain for internal consistency.
///
/// Checks that:
/// 1. Step indices are sequential (0, 1, 2, ...)
/// 2. Required step kinds are present
/// 3. Chain has non-empty ID and timestamp
pub fn verify_derivation_chain(chain: &DerivationChain) -> VerificationResult {
    let mut checks = Vec::new();

    // Check 1: Non-empty ID
    let has_id = !chain.id.is_empty();
    checks.push(VerificationCheck {
        name: "has_id",
        passed: has_id,
        description: format!("Chain has ID: {}", has_id),
    });

    // Check 2: Non-empty timestamp
    let has_timestamp = !chain.timestamp.is_empty();
    checks.push(VerificationCheck {
        name: "has_timestamp",
        passed: has_timestamp,
        description: format!("Chain has timestamp: {}", has_timestamp),
    });

    // Check 3: Sequential indices
    let sequential = chain
        .steps
        .iter()
        .enumerate()
        .all(|(i, step)| step.index == i);
    checks.push(VerificationCheck {
        name: "sequential_indices",
        passed: sequential,
        description: format!("Step indices are sequential: {}", sequential),
    });

    // Check 4: Has type declaration step
    let has_type_decl = chain
        .steps
        .iter()
        .any(|s| s.kind == StepKind::TypeDeclaration);
    checks.push(VerificationCheck {
        name: "has_type_declaration",
        passed: has_type_decl,
        description: format!("Has type declaration step: {}", has_type_decl),
    });

    // Check 5: Has certificate emission step
    let has_cert = chain
        .steps
        .iter()
        .any(|s| s.kind == StepKind::CertificateEmission);
    checks.push(VerificationCheck {
        name: "has_certificate",
        passed: has_cert,
        description: format!("Has certificate emission step: {}", has_cert),
    });

    VerificationResult::from_checks(checks)
}

/// Miller-Rabin primality test (probabilistic).
///
/// For numbers < 3,317,044,064,679,887,385,961,981, this is deterministic
/// when using the witness set [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37].
fn is_probably_prime(n: u64) -> bool {
    if n < 2 {
        return false;
    }
    if n == 2 || n == 3 {
        return true;
    }
    if n.is_multiple_of(2) {
        return false;
    }

    // Write n-1 as 2^r * d
    let mut d = n - 1;
    let mut r = 0u32;
    while d.is_multiple_of(2) {
        d /= 2;
        r += 1;
    }

    // Witnesses sufficient for n < 3,317,044,064,679,887,385,961,981
    let witnesses: &[u64] = if n < 2047 {
        &[2]
    } else if n < 1_373_653 {
        &[2, 3]
    } else if n < 9_080_191 {
        &[31, 73]
    } else if n < 25_326_001 {
        &[2, 3, 5]
    } else if n < 3_215_031_751 {
        &[2, 3, 5, 7]
    } else {
        &[2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
    };

    'witness: for &a in witnesses {
        if a >= n {
            continue;
        }

        // Compute a^d mod n
        let mut x = mod_pow(a, d, n);

        if x == 1 || x == n - 1 {
            continue 'witness;
        }

        for _ in 0..r - 1 {
            x = mod_mul(x, x, n);
            if x == n - 1 {
                continue 'witness;
            }
        }

        return false;
    }

    true
}

/// Modular exponentiation: a^b mod m
fn mod_pow(mut base: u64, mut exp: u64, modulus: u64) -> u64 {
    if modulus == 1 {
        return 0;
    }
    let mut result = 1u64;
    base %= modulus;
    while exp > 0 {
        if exp % 2 == 1 {
            result = mod_mul(result, base, modulus);
        }
        exp /= 2;
        base = mod_mul(base, base, modulus);
    }
    result
}

/// Modular multiplication: a * b mod m (handles overflow)
fn mod_mul(a: u64, b: u64, m: u64) -> u64 {
    ((a as u128 * b as u128) % m as u128) as u64
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::factorize::{factorization_derivation, factorize_semiprime};

    #[test]
    fn test_verify_factorization_10403() {
        let result = factorize_semiprime(10403, 32).unwrap();
        let verification = verify_factorization(&result);

        assert!(verification.valid, "Verification should pass");
        assert!(
            verification.failures().count() == 0,
            "No checks should fail"
        );
    }

    #[test]
    fn test_verify_factorization_details() {
        let result = factorize_semiprime(10403, 32).unwrap();
        let verification = verify_factorization(&result);

        // Find specific checks
        let product_check = verification.checks.iter().find(|c| c.name == "product");
        assert!(product_check.is_some());
        assert!(product_check.unwrap().passed);

        let primality_p = verification.checks.iter().find(|c| c.name == "primality_p");
        assert!(primality_p.is_some());
        assert!(primality_p.unwrap().passed);
    }

    #[test]
    fn test_is_probably_prime() {
        // Known primes
        assert!(is_probably_prime(2));
        assert!(is_probably_prime(3));
        assert!(is_probably_prime(5));
        assert!(is_probably_prime(7));
        assert!(is_probably_prime(11));
        assert!(is_probably_prime(101));
        assert!(is_probably_prime(103));
        assert!(is_probably_prime(10007));

        // Known composites
        assert!(!is_probably_prime(4));
        assert!(!is_probably_prime(9));
        assert!(!is_probably_prime(15));
        assert!(!is_probably_prime(10403));
        assert!(!is_probably_prime(100));
    }

    #[test]
    fn test_verify_derivation_chain() {
        let result = factorize_semiprime(10403, 32).unwrap();
        let chain = factorization_derivation(&result, "2026-02-05T00:00:00Z");
        let verification = verify_derivation_chain(&chain);

        assert!(verification.valid, "Chain verification should pass");
    }

    #[test]
    fn test_verification_result_failures() {
        let checks = vec![
            VerificationCheck {
                name: "pass",
                passed: true,
                description: "Passed".to_string(),
            },
            VerificationCheck {
                name: "fail",
                passed: false,
                description: "Failed".to_string(),
            },
        ];

        let result = VerificationResult::from_checks(checks);
        assert!(!result.valid);
        assert_eq!(result.failures().count(), 1);
    }

    #[test]
    fn test_mod_pow() {
        assert_eq!(mod_pow(2, 10, 1000), 24); // 2^10 = 1024 mod 1000 = 24
        assert_eq!(mod_pow(3, 4, 100), 81); // 3^4 = 81
        assert_eq!(mod_pow(2, 0, 100), 1); // Any^0 = 1
    }

    #[test]
    fn test_various_semiprimes() {
        let semiprimes = [
            (15, 3, 5),
            (21, 3, 7),
            (35, 5, 7),
            (77, 7, 11),
            (143, 11, 13),
            (221, 13, 17),
            (10403, 101, 103),
        ];

        for (n, expected_p, expected_q) in semiprimes {
            let result = factorize_semiprime(n, 32).unwrap();
            let verification = verify_factorization(&result);

            assert!(
                verification.valid,
                "Verification failed for n={}: {:?}",
                n,
                verification.failures().collect::<Vec<_>>()
            );

            assert_eq!(result.p, expected_p, "Wrong p for n={}", n);
            assert_eq!(result.q, expected_q, "Wrong q for n={}", n);
        }
    }
}
