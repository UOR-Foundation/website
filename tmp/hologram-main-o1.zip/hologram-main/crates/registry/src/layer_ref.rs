//! Layer reference types for flexible layer addressing.
//!
//! A `LayerReference` can identify a layer by:
//! - Content hash (BLAKE3)
//! - Name and version
//! - Local file path

use std::fmt;
use std::path::PathBuf;
use std::str::FromStr;

use serde::{Deserialize, Serialize};

use crate::error::{RegistryError, Result};

/// Reference to a layer using various addressing schemes.
///
/// # Parsing
///
/// - `blake3:abc123...` or 64-char hex -> [`LayerReference::ByHash`]
/// - `./path`, `../path`, `/path` -> [`LayerReference::ByPath`]
/// - `name:version` -> [`LayerReference::ByName`] with no namespace
/// - `namespace/name:version` -> [`LayerReference::ByName`] with namespace
/// - `name` (no colon) -> [`LayerReference::ByName`] with version "latest"
///
/// # Examples
///
/// ```
/// use hologram_registry::LayerReference;
///
/// // By hash (64 hex characters = 32 bytes)
/// let by_hash: LayerReference = "blake3:abababababababababababababababababababababababababababababababab".parse().unwrap();
///
/// // By path
/// let by_path: LayerReference = "./model.holb".parse().unwrap();
///
/// // By name with version
/// let by_name: LayerReference = "my-model:v1.0".parse().unwrap();
///
/// // By name with namespace
/// let by_ns: LayerReference = "org/model:v1.0".parse().unwrap();
/// ```
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum LayerReference {
    /// Reference by content hash (BLAKE3).
    ByHash(
        /// 32-byte BLAKE3 hash.
        [u8; 32],
    ),

    /// Reference by name and version.
    ByName {
        /// Optional namespace (e.g., organization).
        namespace: Option<String>,
        /// Layer name.
        name: String,
        /// Version string (defaults to "latest").
        version: String,
    },

    /// Reference by local file path.
    ByPath(
        /// Path to the layer file.
        PathBuf,
    ),
}

impl LayerReference {
    /// Create a hash reference from 32 bytes.
    #[must_use]
    pub const fn from_hash(hash: [u8; 32]) -> Self {
        Self::ByHash(hash)
    }

    /// Create a name reference with optional namespace.
    #[must_use]
    pub fn from_name(
        namespace: Option<impl Into<String>>,
        name: impl Into<String>,
        version: impl Into<String>,
    ) -> Self {
        Self::ByName {
            namespace: namespace.map(Into::into),
            name: name.into(),
            version: version.into(),
        }
    }

    /// Create a path reference.
    #[must_use]
    pub fn from_path(path: impl Into<PathBuf>) -> Self {
        Self::ByPath(path.into())
    }

    /// Parse a layer reference from a string.
    ///
    /// # Errors
    ///
    /// Returns [`RegistryError::InvalidRef`] if the string cannot be parsed.
    pub fn parse(s: &str) -> Result<Self> {
        let s = s.trim();

        if s.is_empty() {
            return Err(RegistryError::InvalidRef("empty reference".to_string()));
        }

        // Check for blake3: prefix
        if let Some(hash_str) = s.strip_prefix("blake3:") {
            return parse_hex_hash(hash_str);
        }

        // Check for 64-char hex (raw hash)
        if s.len() == 64 && s.chars().all(|c| c.is_ascii_hexdigit()) {
            return parse_hex_hash(s);
        }

        // Check for path (starts with ./, ../, or /)
        if s.starts_with("./") || s.starts_with("../") || s.starts_with('/') {
            return Ok(Self::ByPath(PathBuf::from(s)));
        }

        // Otherwise it's a name reference
        parse_name_ref(s)
    }

    /// Check if this is a hash reference.
    #[must_use]
    pub const fn is_hash(&self) -> bool {
        matches!(self, Self::ByHash(_))
    }

    /// Check if this is a name reference.
    #[must_use]
    pub const fn is_name(&self) -> bool {
        matches!(self, Self::ByName { .. })
    }

    /// Check if this is a path reference.
    #[must_use]
    pub const fn is_path(&self) -> bool {
        matches!(self, Self::ByPath(_))
    }

    /// Get the hash if this is a hash reference.
    #[must_use]
    pub const fn as_hash(&self) -> Option<&[u8; 32]> {
        match self {
            Self::ByHash(h) => Some(h),
            _ => None,
        }
    }

    /// Get the path if this is a path reference.
    #[must_use]
    pub fn as_path(&self) -> Option<&PathBuf> {
        match self {
            Self::ByPath(p) => Some(p),
            _ => None,
        }
    }

    /// Get the full name key for index lookup.
    ///
    /// Returns `None` if this is not a name reference.
    /// Format: `namespace/name:version` or `name:version`.
    #[must_use]
    pub fn name_key(&self) -> Option<String> {
        match self {
            Self::ByName {
                namespace,
                name,
                version,
            } => {
                let key = match namespace {
                    Some(ns) => format!("{ns}/{name}:{version}"),
                    None => format!("{name}:{version}"),
                };
                Some(key)
            }
            _ => None,
        }
    }
}

/// Parse a hex string into a 32-byte hash.
fn parse_hex_hash(s: &str) -> Result<LayerReference> {
    let s = s.trim();

    if s.len() != 64 {
        return Err(RegistryError::InvalidHash(format!(
            "expected 64 hex chars, got {}",
            s.len()
        )));
    }

    let bytes = hex::decode(s).map_err(|e| RegistryError::InvalidHash(e.to_string()))?;

    let hash: [u8; 32] = bytes
        .try_into()
        .map_err(|_| RegistryError::InvalidHash("invalid hash length".to_string()))?;

    Ok(LayerReference::ByHash(hash))
}

/// Parse a name reference (namespace/name:version or name:version or name).
fn parse_name_ref(s: &str) -> Result<LayerReference> {
    // Split on first : to get name part and version
    let (name_part, version) = if let Some(idx) = s.rfind(':') {
        let (n, v) = s.split_at(idx);
        (n, &v[1..]) // Skip the ':'
    } else {
        (s, "latest")
    };

    // Validate version is not empty
    let version = if version.is_empty() {
        "latest"
    } else {
        version
    };

    // Split name_part on / to get namespace
    let (namespace, name) = if let Some(idx) = name_part.rfind('/') {
        let (ns, n) = name_part.split_at(idx);
        (Some(ns), &n[1..]) // Skip the '/'
    } else {
        (None, name_part)
    };

    // Validate name is not empty
    if name.is_empty() {
        return Err(RegistryError::InvalidRef(
            "layer name cannot be empty".to_string(),
        ));
    }

    // Validate name characters (alphanumeric, dash, underscore)
    if !is_valid_name(name) {
        return Err(RegistryError::InvalidRef(format!(
            "invalid layer name: {name}"
        )));
    }

    // Validate namespace if present
    if let Some(ns) = namespace {
        if ns.is_empty() {
            return Err(RegistryError::InvalidRef(
                "namespace cannot be empty".to_string(),
            ));
        }
        if !is_valid_name(ns) {
            return Err(RegistryError::InvalidRef(format!(
                "invalid namespace: {ns}"
            )));
        }
    }

    Ok(LayerReference::ByName {
        namespace: namespace.map(String::from),
        name: name.to_string(),
        version: version.to_string(),
    })
}

/// Check if a name contains only valid characters.
fn is_valid_name(s: &str) -> bool {
    !s.is_empty()
        && s.chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.')
}

impl FromStr for LayerReference {
    type Err = RegistryError;

    fn from_str(s: &str) -> Result<Self> {
        Self::parse(s)
    }
}

impl fmt::Display for LayerReference {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::ByHash(hash) => write!(f, "blake3:{}", hex::encode(hash)),
            Self::ByName {
                namespace,
                name,
                version,
            } => match namespace {
                Some(ns) => write!(f, "{ns}/{name}:{version}"),
                None => write!(f, "{name}:{version}"),
            },
            Self::ByPath(path) => write!(f, "{}", path.display()),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_blake3_prefix() {
        let hash_hex = "0".repeat(64);
        let ref_str = format!("blake3:{hash_hex}");
        let layer_ref: LayerReference = ref_str.parse().unwrap();

        assert!(layer_ref.is_hash());
        assert_eq!(layer_ref.as_hash(), Some(&[0u8; 32]));
    }

    #[test]
    fn test_parse_raw_hex() {
        let hash_hex = "a".repeat(64);
        let layer_ref: LayerReference = hash_hex.parse().unwrap();

        assert!(layer_ref.is_hash());
        let expected = [0xaa; 32];
        assert_eq!(layer_ref.as_hash(), Some(&expected));
    }

    #[test]
    fn test_parse_path_relative() {
        let layer_ref: LayerReference = "./model.holb".parse().unwrap();
        assert!(layer_ref.is_path());
        assert_eq!(layer_ref.as_path(), Some(&PathBuf::from("./model.holb")));
    }

    #[test]
    fn test_parse_path_parent() {
        let layer_ref: LayerReference = "../other/model.holb".parse().unwrap();
        assert!(layer_ref.is_path());
        assert_eq!(
            layer_ref.as_path(),
            Some(&PathBuf::from("../other/model.holb"))
        );
    }

    #[test]
    fn test_parse_path_absolute() {
        let layer_ref: LayerReference = "/home/user/model.holb".parse().unwrap();
        assert!(layer_ref.is_path());
        assert_eq!(
            layer_ref.as_path(),
            Some(&PathBuf::from("/home/user/model.holb"))
        );
    }

    #[test]
    fn test_parse_name_with_version() {
        let layer_ref: LayerReference = "my-model:v1.0".parse().unwrap();

        match &layer_ref {
            LayerReference::ByName {
                namespace,
                name,
                version,
            } => {
                assert!(namespace.is_none());
                assert_eq!(name, "my-model");
                assert_eq!(version, "v1.0");
            }
            _ => panic!("expected ByName"),
        }
    }

    #[test]
    fn test_parse_name_with_namespace() {
        let layer_ref: LayerReference = "org/my-model:v2.0".parse().unwrap();

        match &layer_ref {
            LayerReference::ByName {
                namespace,
                name,
                version,
            } => {
                assert_eq!(namespace.as_deref(), Some("org"));
                assert_eq!(name, "my-model");
                assert_eq!(version, "v2.0");
            }
            _ => panic!("expected ByName"),
        }
    }

    #[test]
    fn test_parse_name_default_version() {
        let layer_ref: LayerReference = "simple-model".parse().unwrap();

        match &layer_ref {
            LayerReference::ByName {
                namespace,
                name,
                version,
            } => {
                assert!(namespace.is_none());
                assert_eq!(name, "simple-model");
                assert_eq!(version, "latest");
            }
            _ => panic!("expected ByName"),
        }
    }

    #[test]
    fn test_parse_name_empty_version() {
        let layer_ref: LayerReference = "model:".parse().unwrap();

        match &layer_ref {
            LayerReference::ByName { version, .. } => {
                assert_eq!(version, "latest");
            }
            _ => panic!("expected ByName"),
        }
    }

    #[test]
    fn test_parse_invalid_empty() {
        let result = LayerReference::parse("");
        assert!(result.is_err());
    }

    #[test]
    fn test_parse_invalid_hash_length() {
        let result = LayerReference::parse("blake3:abc");
        assert!(result.is_err());
    }

    #[test]
    fn test_parse_invalid_hash_chars() {
        let result = LayerReference::parse(
            "blake3:zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz",
        );
        assert!(result.is_err());
    }

    #[test]
    fn test_parse_invalid_name_chars() {
        let result = LayerReference::parse("model@bad:v1");
        assert!(result.is_err());
    }

    #[test]
    fn test_display_hash() {
        let layer_ref = LayerReference::from_hash([0xab; 32]);
        let display = layer_ref.to_string();
        assert!(display.starts_with("blake3:"));
        assert!(display.contains("abab"));
    }

    #[test]
    fn test_display_name() {
        let layer_ref = LayerReference::from_name(None::<String>, "model", "v1");
        assert_eq!(layer_ref.to_string(), "model:v1");
    }

    #[test]
    fn test_display_name_with_namespace() {
        let layer_ref = LayerReference::from_name(Some("org"), "model", "v1");
        assert_eq!(layer_ref.to_string(), "org/model:v1");
    }

    #[test]
    fn test_display_path() {
        let layer_ref = LayerReference::from_path("./test.holb");
        assert_eq!(layer_ref.to_string(), "./test.holb");
    }

    #[test]
    fn test_roundtrip_hash() {
        let original = LayerReference::from_hash([0x42; 32]);
        let serialized = original.to_string();
        let parsed: LayerReference = serialized.parse().unwrap();
        assert_eq!(original, parsed);
    }

    #[test]
    fn test_roundtrip_name() {
        let original = LayerReference::from_name(Some("ns"), "model", "v1.2.3");
        let serialized = original.to_string();
        let parsed: LayerReference = serialized.parse().unwrap();
        assert_eq!(original, parsed);
    }

    #[test]
    fn test_roundtrip_path() {
        let original = LayerReference::from_path("./some/path.holb");
        let serialized = original.to_string();
        let parsed: LayerReference = serialized.parse().unwrap();
        assert_eq!(original, parsed);
    }

    #[test]
    fn test_name_key() {
        let no_ns = LayerReference::from_name(None::<String>, "model", "v1");
        assert_eq!(no_ns.name_key(), Some("model:v1".to_string()));

        let with_ns = LayerReference::from_name(Some("org"), "model", "v1");
        assert_eq!(with_ns.name_key(), Some("org/model:v1".to_string()));

        let hash = LayerReference::from_hash([0; 32]);
        assert_eq!(hash.name_key(), None);
    }

    #[test]
    fn test_is_methods() {
        let hash = LayerReference::from_hash([0; 32]);
        assert!(hash.is_hash());
        assert!(!hash.is_name());
        assert!(!hash.is_path());

        let name = LayerReference::from_name(None::<String>, "m", "v");
        assert!(!name.is_hash());
        assert!(name.is_name());
        assert!(!name.is_path());

        let path = LayerReference::from_path("/test");
        assert!(!path.is_hash());
        assert!(!path.is_name());
        assert!(path.is_path());
    }

    #[test]
    fn test_serde_roundtrip() {
        let refs = vec![
            LayerReference::from_hash([0x12; 32]),
            LayerReference::from_name(Some("ns"), "model", "v1"),
            LayerReference::from_path("./test.holb"),
        ];

        for original in refs {
            let json = serde_json::to_string(&original).unwrap();
            let deserialized: LayerReference = serde_json::from_str(&json).unwrap();
            assert_eq!(original, deserialized);
        }
    }

    #[test]
    fn test_name_with_dots() {
        let layer_ref: LayerReference = "my.model.name:v1.0.0".parse().unwrap();
        match &layer_ref {
            LayerReference::ByName { name, version, .. } => {
                assert_eq!(name, "my.model.name");
                assert_eq!(version, "v1.0.0");
            }
            _ => panic!("expected ByName"),
        }
    }

    #[test]
    fn test_name_with_underscores() {
        let layer_ref: LayerReference = "my_model_name:v1".parse().unwrap();
        match &layer_ref {
            LayerReference::ByName { name, .. } => {
                assert_eq!(name, "my_model_name");
            }
            _ => panic!("expected ByName"),
        }
    }
}
