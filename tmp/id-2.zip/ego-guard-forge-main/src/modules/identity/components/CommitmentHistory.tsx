/**
 * CommitmentHistory — Auditable timeline of sovereignty boundary commitment hashes.
 */

import { useMemo, useCallback } from "react";
import type { BoundaryCommitment } from "../types";
import { History, Shield, Eye, EyeOff, Hash, Download } from "lucide-react";

interface Props {
  readonly commitments: readonly BoundaryCommitment[];
}

function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString(undefined, {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export default function CommitmentHistory({ commitments }: Props) {
  const sorted = useMemo(
    () => [...commitments].sort((a, b) => b.timestamp - a.timestamp),
    [commitments],
  );

  const exportAuditTrail = useCallback(() => {
    const payload = {
      exportedAt: new Date().toISOString(),
      version: "1.0.0",
      commitmentCount: sorted.length,
      commitments: sorted.map((c) => ({
        commitmentHash: c.commitmentHash,
        identityId: c.identityId,
        edgeCount: c.edgeCount,
        shieldedCount: c.shieldedCount,
        disclosedCount: c.disclosedCount,
        selectiveCount: c.selectiveCount,
        timestamp: c.timestamp,
        iso: new Date(c.timestamp).toISOString(),
      })),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `boundary-audit-trail-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [sorted]);

  if (sorted.length === 0) {
    return (
      <div className="rounded-lg border border-border bg-card p-6 animate-fade-in">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2 mb-3">
          <History className="h-3.5 w-3.5" />
          Privacy Change Log
        </h3>
        <p className="text-xs text-muted-foreground text-center py-4">
          No privacy changes recorded yet. Adjust your sharing preferences to start tracking.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-border bg-card p-6 animate-fade-in space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
          <History className="h-3.5 w-3.5" />
          Privacy Change Log
        </h3>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-muted-foreground">
            {sorted.length} snapshot{sorted.length !== 1 ? "s" : ""}
          </span>
          <button
            onClick={exportAuditTrail}
            className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-primary px-1.5 py-1 rounded border border-border hover:border-primary/40 transition-colors"
            title="Export audit trail as JSON"
          >
            <Download className="h-3 w-3" />
            Export
          </button>
        </div>
      </div>

      <div className="space-y-0 relative">
        {/* Timeline line */}
        <div className="absolute left-3 top-2 bottom-2 w-px bg-border" />

        {sorted.map((c, i) => {
          const isLatest = i === 0;
          return (
            <div
              key={`${c.commitmentHash}-${c.timestamp}`}
              className="relative pl-8 py-3 group"
            >
              {/* Timeline dot */}
              <div
                className={`absolute left-[7px] top-[18px] w-[13px] h-[13px] rounded-full border-2 ${
                  isLatest
                    ? "border-primary bg-primary/30"
                    : "border-border bg-card"
                }`}
              />

              <div className="space-y-1.5">
                {/* Time + badge */}
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-muted-foreground">
                    {formatTime(c.timestamp)}
                  </span>
                  {isLatest && (
                    <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded bg-primary/10 text-primary">
                      LATEST
                    </span>
                  )}
                </div>

                {/* Hash */}
                <div className="flex items-center gap-1.5">
                  <Hash className="h-3 w-3 text-muted-foreground shrink-0" />
                  <code className="text-[10px] font-mono text-foreground/80 truncate max-w-[220px]" title={c.commitmentHash}>
                    {c.commitmentHash.slice(0, 16)}…{c.commitmentHash.slice(-8)}
                  </code>
                </div>

                {/* Edge state counts */}
                <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <EyeOff className="h-2.5 w-2.5" />
                    {c.shieldedCount}
                  </span>
                  <span className="flex items-center gap-1">
                    <Shield className="h-2.5 w-2.5" />
                    {c.selectiveCount}
                  </span>
                  <span className="flex items-center gap-1">
                    <Eye className="h-2.5 w-2.5" />
                    {c.disclosedCount}
                  </span>
                  <span className="ml-auto text-[9px]">
                    {c.edgeCount} data points
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
