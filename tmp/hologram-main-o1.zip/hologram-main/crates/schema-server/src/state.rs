//! Application state.

use crate::schema::SchemaStore;

/// Shared application state.
pub struct AppState {
    pub store: SchemaStore,
}

impl AppState {
    /// Create new application state with the given schema store.
    pub fn new(store: SchemaStore) -> Self {
        Self { store }
    }
}
