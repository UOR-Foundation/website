//! Tracing setup and configuration.
//!
//! This module provides structured logging with spans and events using the `tracing` ecosystem.

use tracing_subscriber::{fmt, layer::SubscriberExt, util::SubscriberInitExt, EnvFilter};

/// Error type for tracing initialization.
#[derive(Debug)]
pub enum TracingError {
    /// Failed to parse the filter directive.
    FilterParse(String),
    /// Tracing subscriber already initialized.
    AlreadyInitialized,
}

impl std::fmt::Display for TracingError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TracingError::FilterParse(msg) => write!(f, "Failed to parse filter: {}", msg),
            TracingError::AlreadyInitialized => {
                write!(f, "Tracing subscriber already initialized")
            }
        }
    }
}

impl std::error::Error for TracingError {}

impl From<tracing_subscriber::filter::ParseError> for TracingError {
    fn from(err: tracing_subscriber::filter::ParseError) -> Self {
        TracingError::FilterParse(err.to_string())
    }
}

/// Configuration for tracing setup.
#[derive(Debug, Clone)]
pub struct TracingConfig {
    /// Log level filter (e.g., "hologram=debug,warn").
    pub filter: String,
    /// Enable ANSI colors.
    pub ansi: bool,
    /// Include file/line in logs.
    pub file_line: bool,
    /// Include target in logs.
    pub target: bool,
    /// JSON output format.
    pub json: bool,
}

impl Default for TracingConfig {
    fn default() -> Self {
        Self {
            filter: "hologram=info,warn".into(),
            ansi: true,
            file_line: false,
            target: true,
            json: false,
        }
    }
}

impl TracingConfig {
    /// Create a new TracingConfig with the given filter.
    #[must_use]
    pub fn with_filter(filter: impl Into<String>) -> Self {
        Self {
            filter: filter.into(),
            ..Default::default()
        }
    }

    /// Set whether to enable ANSI colors.
    #[must_use]
    pub fn ansi(mut self, ansi: bool) -> Self {
        self.ansi = ansi;
        self
    }

    /// Set whether to include file/line in logs.
    #[must_use]
    pub fn file_line(mut self, file_line: bool) -> Self {
        self.file_line = file_line;
        self
    }

    /// Set whether to include target in logs.
    #[must_use]
    pub fn target(mut self, target: bool) -> Self {
        self.target = target;
        self
    }

    /// Set whether to use JSON output format.
    #[must_use]
    pub fn json(mut self, json: bool) -> Self {
        self.json = json;
        self
    }
}

/// Initialize tracing with the given configuration.
///
/// # Errors
///
/// Returns an error if the filter string is invalid or if tracing is already initialized.
///
/// # Example
///
/// ```rust,no_run
/// use hologram_telemetry::{init_tracing, TracingConfig};
///
/// let config = TracingConfig::with_filter("hologram=debug")
///     .ansi(true)
///     .target(true);
///
/// init_tracing(config).expect("Failed to initialize tracing");
/// ```
pub fn init_tracing(config: TracingConfig) -> Result<(), TracingError> {
    let filter = EnvFilter::try_new(&config.filter)?;

    let result = if config.json {
        tracing_subscriber::registry()
            .with(filter)
            .with(fmt::layer().json())
            .try_init()
    } else {
        tracing_subscriber::registry()
            .with(filter)
            .with(
                fmt::layer()
                    .with_ansi(config.ansi)
                    .with_file(config.file_line)
                    .with_line_number(config.file_line)
                    .with_target(config.target),
            )
            .try_init()
    };

    result.map_err(|_| TracingError::AlreadyInitialized)
}

/// Initialize tracing from environment variables.
///
/// Environment variables:
/// - `HOLOGRAM_LOG`: Log filter (default: "hologram=info,warn")
/// - `NO_COLOR`: If set, disables ANSI colors
/// - `HOLOGRAM_LOG_JSON`: If set, enables JSON output format
///
/// # Errors
///
/// Returns an error if the filter string is invalid or if tracing is already initialized.
///
/// # Example
///
/// ```rust,no_run
/// use hologram_telemetry::init_from_env;
///
/// init_from_env().expect("Failed to initialize tracing");
/// ```
pub fn init_from_env() -> Result<(), TracingError> {
    let config = TracingConfig {
        filter: std::env::var("HOLOGRAM_LOG").unwrap_or_else(|_| "hologram=info,warn".into()),
        ansi: std::env::var("NO_COLOR").is_err(),
        json: std::env::var("HOLOGRAM_LOG_JSON").is_ok(),
        ..Default::default()
    };
    init_tracing(config)
}

/// Check if tracing can be initialized (for testing purposes).
#[must_use]
pub fn can_initialize() -> bool {
    // Try to create a filter to see if it would work
    EnvFilter::try_new("info").is_ok()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tracing_config_default() {
        let config = TracingConfig::default();
        assert_eq!(config.filter, "hologram=info,warn");
        assert!(config.ansi);
        assert!(!config.file_line);
        assert!(config.target);
        assert!(!config.json);
    }

    #[test]
    fn test_tracing_config_with_filter() {
        let config = TracingConfig::with_filter("debug");
        assert_eq!(config.filter, "debug");
    }

    #[test]
    fn test_tracing_config_builder() {
        let config = TracingConfig::with_filter("trace")
            .ansi(false)
            .file_line(true)
            .target(false)
            .json(true);

        assert_eq!(config.filter, "trace");
        assert!(!config.ansi);
        assert!(config.file_line);
        assert!(!config.target);
        assert!(config.json);
    }

    #[test]
    fn test_tracing_error_display() {
        let err = TracingError::FilterParse("invalid".to_string());
        assert!(err.to_string().contains("invalid"));

        let err = TracingError::AlreadyInitialized;
        assert!(err.to_string().contains("already initialized"));
    }

    #[test]
    fn test_can_initialize() {
        // This should always return true since "info" is a valid filter
        assert!(can_initialize());
    }

    #[test]
    fn test_env_filter_parsing() {
        // Valid filters
        assert!(EnvFilter::try_new("info").is_ok());
        assert!(EnvFilter::try_new("debug").is_ok());
        assert!(EnvFilter::try_new("hologram=debug,warn").is_ok());
        assert!(EnvFilter::try_new("hologram::metrics=trace").is_ok());
    }
}
