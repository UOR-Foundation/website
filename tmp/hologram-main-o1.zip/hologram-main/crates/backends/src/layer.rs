//! Layer loading infrastructure for CallLayer composition.
//!
//! This module provides the [`LayerLoader`] trait and implementations for
//! loading referenced layers from various locations:
//!
//! - [`Embedded`](LayerLocation::Embedded): Zero-copy from archive data
//! - [`External`](LayerLocation::External): Load from file path
//! - [`Registry`](LayerLocation::Registry): Fetch from remote registry by content hash
//!
//! # Caching
//!
//! [`LayerCache`] provides in-memory caching of loaded layers by their content hash
//! to avoid redundant loading/parsing.
//!
//! For registry fetches, a disk cache stores downloaded layers at
//! `~/.hologram/cache/layers/<hash>.holb` to avoid re-downloading.
//!
//! # Example
//!
//! ```rust,ignore
//! use hologram_backend::layer::{LayerLoader, FileSystemLoader, LayerCache};
//! use hologram_holo::LayerRef;
//!
//! let mut cache = LayerCache::new();
//! let loader = FileSystemLoader::new();
//!
//! // Load a layer reference
//! let plan = loader.load(&layer_ref, None, &mut cache)?;
//! ```

use std::collections::HashMap;
use std::fs;
#[cfg(not(target_arch = "wasm32"))]
use std::io::Read;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use hologram_holo::{BackendPlan, LayerLocation, LayerRef};
use hologram_sha256::Sha256;
use rkyv::Deserialize;

use crate::types::{BackendError, Result};

/// Trait for loading layers from various sources.
///
/// Implementations handle the specifics of each [`LayerLocation`] variant.
pub trait LayerLoader: Send + Sync {
    /// Load a layer from its reference.
    ///
    /// # Arguments
    ///
    /// * `layer_ref` - Reference containing location and hash information
    /// * `archive_data` - Optional archive data for embedded layers
    /// * `cache` - Cache to check/store loaded layers
    ///
    /// # Errors
    ///
    /// Returns error if:
    /// - Layer cannot be found at specified location
    /// - Layer data is corrupted or invalid
    /// - Content hash doesn't match expected value
    fn load(
        &self,
        layer_ref: &LayerRef,
        archive_data: Option<&[u8]>,
        cache: &mut LayerCache,
    ) -> Result<Arc<BackendPlan>>;
}

/// Cache for loaded layers, keyed by content hash.
///
/// Stores `Arc<BackendPlan>` so retrieval is an atomic refcount increment
/// (~1 ns) instead of a deep clone (~400 ns). This eliminates O(n) clones
/// for multi-layer pipelines.
#[derive(Default)]
pub struct LayerCache {
    /// Cached plans by their SHA-256 content hash
    plans: HashMap<[u8; 32], Arc<BackendPlan>>,
}

impl LayerCache {
    /// Create a new empty cache.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Get a cached plan by its hash (cheap Arc clone).
    #[must_use]
    pub fn get(&self, hash: &[u8; 32]) -> Option<Arc<BackendPlan>> {
        self.plans.get(hash).cloned()
    }

    /// Insert a plan into the cache.
    pub fn insert(&mut self, hash: [u8; 32], plan: Arc<BackendPlan>) {
        self.plans.insert(hash, plan);
    }

    /// Check if a plan is already cached.
    #[must_use]
    pub fn contains(&self, hash: &[u8; 32]) -> bool {
        self.plans.contains_key(hash)
    }

    /// Number of cached layers.
    #[must_use]
    pub fn len(&self) -> usize {
        self.plans.len()
    }

    /// Check if cache is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.plans.is_empty()
    }

    /// Clear all cached layers.
    pub fn clear(&mut self) {
        self.plans.clear();
    }
}

/// File system layer loader with registry support.
///
/// Loads layers from:
/// - Embedded data within archive bytes
/// - External file paths on the local filesystem
/// - Remote registries via HTTP (content-addressed by hash)
///
/// Registry fetches are cached to disk at `~/.hologram/cache/layers/`.
#[derive(Debug)]
pub struct FileSystemLoader {
    /// Base path for resolving relative external paths
    base_path: Option<String>,
    /// Directory for caching downloaded registry layers
    cache_dir: Option<PathBuf>,
}

impl Default for FileSystemLoader {
    fn default() -> Self {
        Self {
            base_path: None,
            cache_dir: default_cache_dir(),
        }
    }
}

/// Get the default cache directory for downloaded layers.
fn default_cache_dir() -> Option<PathBuf> {
    dirs_next().map(|home| home.join(".hologram").join("cache").join("layers"))
}

/// Get the user's home directory (platform-specific).
fn dirs_next() -> Option<PathBuf> {
    #[cfg(unix)]
    {
        std::env::var_os("HOME").map(PathBuf::from)
    }
    #[cfg(windows)]
    {
        std::env::var_os("USERPROFILE").map(PathBuf::from)
    }
    #[cfg(not(any(unix, windows)))]
    {
        None
    }
}

impl FileSystemLoader {
    /// Create a new loader with no base path.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Create a new loader with a base path for relative paths.
    #[must_use]
    pub fn with_base_path(base_path: impl Into<String>) -> Self {
        Self {
            base_path: Some(base_path.into()),
            cache_dir: default_cache_dir(),
        }
    }

    /// Create a loader with a custom cache directory.
    #[must_use]
    pub fn with_cache_dir(cache_dir: impl Into<PathBuf>) -> Self {
        Self {
            base_path: None,
            cache_dir: Some(cache_dir.into()),
        }
    }

    /// Disable disk caching for registry fetches.
    #[must_use]
    pub fn without_cache(mut self) -> Self {
        self.cache_dir = None;
        self
    }

    /// Load from embedded location within archive data.
    fn load_embedded(
        &self,
        layer_ref: &LayerRef,
        archive_data: &[u8],
        offset: usize,
        size: usize,
    ) -> Result<BackendPlan> {
        // Validate bounds
        if offset + size > archive_data.len() {
            return Err(BackendError::LayerLoadError {
                layer_id: format_hash(&layer_ref.layer_id),
                reason: format!(
                    "embedded offset {} + size {} exceeds archive length {}",
                    offset,
                    size,
                    archive_data.len()
                ),
            });
        }

        // Extract embedded data
        let layer_data = &archive_data[offset..offset + size];

        // Parse the layer
        parse_layer_data(layer_data, layer_ref)
    }

    /// Load from external file path.
    fn load_external(&self, layer_ref: &LayerRef, path: &str) -> Result<BackendPlan> {
        // Resolve path relative to base if needed
        let full_path = if Path::new(path).is_absolute() {
            path.to_string()
        } else if let Some(base) = &self.base_path {
            format!("{base}/{path}")
        } else {
            path.to_string()
        };

        // Read file contents
        let layer_data = fs::read(&full_path).map_err(|e| BackendError::LayerLoadError {
            layer_id: format_hash(&layer_ref.layer_id),
            reason: format!("failed to read '{full_path}': {e}"),
        })?;

        // Parse the layer
        parse_layer_data(&layer_data, layer_ref)
    }

    /// Load from a remote registry.
    ///
    /// Checks disk cache first, then fetches via HTTP if not cached.
    /// The URL is constructed as: `{registry_url}/v{version}/{hash}.holb`
    #[cfg(not(target_arch = "wasm32"))]
    fn load_registry(
        &self,
        layer_ref: &LayerRef,
        registry_url: &str,
        version: &str,
    ) -> Result<BackendPlan> {
        let hash_hex = format_hash_full(&layer_ref.layer_id);

        // Check disk cache first
        if let Some(cache_dir) = &self.cache_dir {
            let cache_path = cache_dir.join(format!("{hash_hex}.holb"));
            if cache_path.exists() {
                let layer_data =
                    fs::read(&cache_path).map_err(|e| BackendError::LayerLoadError {
                        layer_id: format_hash(&layer_ref.layer_id),
                        reason: format!("failed to read cache file: {e}"),
                    })?;
                return parse_layer_data(&layer_data, layer_ref);
            }
        }

        // Construct URL: {registry_url}/v{version}/{hash}.holb
        let url = format!("{registry_url}/v{version}/{hash_hex}.holb");

        // Fetch via HTTP
        let response = ureq::get(&url)
            .call()
            .map_err(|e| BackendError::LayerLoadError {
                layer_id: format_hash(&layer_ref.layer_id),
                reason: format!("failed to fetch from registry: {e}"),
            })?;

        // Read response body
        let mut layer_data = Vec::new();
        response
            .into_reader()
            .read_to_end(&mut layer_data)
            .map_err(|e| BackendError::LayerLoadError {
                layer_id: format_hash(&layer_ref.layer_id),
                reason: format!("failed to read response body: {e}"),
            })?;

        // Cache to disk if cache directory is configured
        if let Some(cache_dir) = &self.cache_dir {
            // Create cache directory if it doesn't exist
            if let Err(e) = fs::create_dir_all(cache_dir) {
                // Log but don't fail - caching is optional
                tracing::warn!("failed to create cache directory: {e}");
            } else {
                let cache_path = cache_dir.join(format!("{hash_hex}.holb"));
                if let Err(e) = fs::write(&cache_path, &layer_data) {
                    tracing::warn!("failed to cache layer to disk: {e}");
                }
            }
        }

        // Parse the layer (this also verifies the hash)
        parse_layer_data(&layer_data, layer_ref)
    }

    /// Stub for wasm32 - registry loading not supported.
    #[cfg(target_arch = "wasm32")]
    fn load_registry(
        &self,
        layer_ref: &LayerRef,
        registry_url: &str,
        _version: &str,
    ) -> Result<BackendPlan> {
        Err(BackendError::LayerLoadError {
            layer_id: format_hash(&layer_ref.layer_id),
            reason: format!("registry loading not supported on wasm32 (url: {registry_url})"),
        })
    }
}

impl LayerLoader for FileSystemLoader {
    #[cfg_attr(
        feature = "instrumentation",
        tracing::instrument(skip(self, archive_data, cache), level = "debug")
    )]
    fn load(
        &self,
        layer_ref: &LayerRef,
        archive_data: Option<&[u8]>,
        cache: &mut LayerCache,
    ) -> Result<Arc<BackendPlan>> {
        // Check cache first — returns Arc clone (~1 ns atomic increment)
        if let Some(plan) = cache.get(&layer_ref.layer_id) {
            return Ok(plan);
        }

        // Load based on location
        let plan = match &layer_ref.location {
            LayerLocation::Embedded { offset, size } => {
                let data = archive_data.ok_or_else(|| BackendError::LayerLoadError {
                    layer_id: format_hash(&layer_ref.layer_id),
                    reason: "embedded location requires archive data".into(),
                })?;
                self.load_embedded(layer_ref, data, *offset, *size)?
            }

            LayerLocation::External(path) => self.load_external(layer_ref, path)?,

            LayerLocation::Registry {
                registry_url,
                version,
            } => self.load_registry(layer_ref, registry_url, version)?,
        };

        // Wrap in Arc, cache, and return (single Arc allocation, no clone)
        let plan = Arc::new(plan);
        cache.insert(layer_ref.layer_id, Arc::clone(&plan));
        Ok(plan)
    }
}

/// Parse layer data into a `BackendPlan`.
///
/// Uses rkyv for zero-copy deserialization. Layer data is expected to be
/// a serialized `BackendPlan` in rkyv format.
///
/// Verifies the content hash matches the expected hash in `layer_ref.layer_id`.
fn parse_layer_data(data: &[u8], layer_ref: &LayerRef) -> Result<BackendPlan> {
    // Verify content hash before deserialization
    verify_hash(data, &layer_ref.layer_id)?;

    // Validate and access the archived data
    let archived = rkyv::check_archived_root::<BackendPlan>(data).map_err(|e| {
        BackendError::LayerLoadError {
            layer_id: format_hash(&layer_ref.layer_id),
            reason: format!("invalid archive format: {e}"),
        }
    })?;

    // Deserialize to owned BackendPlan
    let plan: BackendPlan =
        archived
            .deserialize(&mut rkyv::Infallible)
            .map_err(
                |_: core::convert::Infallible| BackendError::LayerLoadError {
                    layer_id: format_hash(&layer_ref.layer_id),
                    reason: "deserialization failed".into(),
                },
            )?;

    Ok(plan)
}

/// Verify the SHA-256 hash of layer data matches the expected hash.
fn verify_hash(data: &[u8], expected_hash: &[u8; 32]) -> Result<()> {
    let mut hasher = Sha256::new();
    hasher.update(data);
    let computed: [u8; 32] = hasher.finalize().into();

    if computed != *expected_hash {
        return Err(BackendError::CorruptedLayer {
            layer_id: format_hash(expected_hash),
            expected: format_hash(expected_hash),
            actual: format_hash(&computed),
        });
    }

    Ok(())
}

/// Format a hash as truncated hex string for error messages (first 8 bytes).
fn format_hash(hash: &[u8; 32]) -> String {
    use std::fmt::Write;
    hash.iter()
        .take(8)
        .fold(String::with_capacity(16), |mut acc, b| {
            let _ = write!(acc, "{b:02x}");
            acc
        })
}

/// Format a hash as full hex string (all 32 bytes).
fn format_hash_full(hash: &[u8; 32]) -> String {
    use std::fmt::Write;
    hash.iter().fold(String::with_capacity(64), |mut acc, b| {
        let _ = write!(acc, "{b:02x}");
        acc
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cache_operations() {
        let mut cache = LayerCache::new();
        assert!(cache.is_empty());

        let hash = [0u8; 32];
        let plan = Arc::new(BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: hologram_holo::PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        });

        assert!(!cache.contains(&hash));
        cache.insert(hash, Arc::clone(&plan));

        assert!(cache.contains(&hash));
        assert_eq!(cache.len(), 1);

        let retrieved = cache.get(&hash);
        assert!(retrieved.is_some());

        cache.clear();
        assert!(cache.is_empty());
    }

    #[test]
    fn test_format_hash() {
        let hash = [
            0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
        ];
        let formatted = format_hash(&hash);
        assert_eq!(formatted, "123456789abcdef0");
    }

    #[test]
    fn test_loader_embedded_out_of_bounds() {
        let loader = FileSystemLoader::new();
        let mut cache = LayerCache::new();

        let layer_ref = LayerRef {
            layer_id: [0u8; 32],
            name: None,
            location: LayerLocation::Embedded {
                offset: 100,
                size: 200,
            },
        };

        // Archive is only 50 bytes, but embedded claims offset 100 + size 200
        let archive_data = vec![0u8; 50];
        let result = loader.load(&layer_ref, Some(&archive_data), &mut cache);

        assert!(matches!(result, Err(BackendError::LayerLoadError { .. })));
    }

    #[test]
    fn test_loader_embedded_missing_archive() {
        let loader = FileSystemLoader::new();
        let mut cache = LayerCache::new();

        let layer_ref = LayerRef {
            layer_id: [0u8; 32],
            name: None,
            location: LayerLocation::Embedded {
                offset: 0,
                size: 10,
            },
        };

        // No archive data provided
        let result = loader.load(&layer_ref, None, &mut cache);

        assert!(matches!(result, Err(BackendError::LayerLoadError { .. })));
    }

    #[test]
    fn test_loader_registry_not_implemented() {
        let loader = FileSystemLoader::new();
        let mut cache = LayerCache::new();

        let layer_ref = LayerRef {
            layer_id: [0u8; 32],
            name: None,
            location: LayerLocation::Registry {
                registry_url: "https://example.com".into(),
                version: "1.0.0".into(),
            },
        };

        // This will fail because the URL doesn't exist, but it should
        // attempt to fetch (not return "not implemented")
        let result = loader.load(&layer_ref, None, &mut cache);

        assert!(matches!(result, Err(BackendError::LayerLoadError { .. })));
        if let Err(BackendError::LayerLoadError { reason, .. }) = result {
            // Should fail with network error, not "not implemented"
            assert!(
                reason.contains("failed to fetch") || reason.contains("not supported"),
                "Expected network error, got: {reason}"
            );
        }
    }

    #[test]
    fn test_loader_external_file_not_found() {
        let loader = FileSystemLoader::new();
        let mut cache = LayerCache::new();

        let layer_ref = LayerRef {
            layer_id: [0u8; 32],
            name: None,
            location: LayerLocation::External("/nonexistent/path/layer.holo".into()),
        };

        let result = loader.load(&layer_ref, None, &mut cache);

        assert!(matches!(result, Err(BackendError::LayerLoadError { .. })));
    }

    #[test]
    fn test_loader_with_base_path() {
        let loader = FileSystemLoader::with_base_path("/base/dir");
        assert!(loader.base_path.is_some());
        assert_eq!(loader.base_path.as_ref().unwrap(), "/base/dir");
    }

    // ========================================================================
    // Hash Verification Tests (TASK-162)
    // ========================================================================

    #[test]
    fn test_verify_hash_valid() {
        // Create some test data
        let data = b"test layer data for hash verification";

        // Compute the correct hash
        let mut hasher = Sha256::new();
        hasher.update(data);
        let correct_hash: [u8; 32] = hasher.finalize().into();

        // Verification should succeed
        let result = super::verify_hash(data, &correct_hash);
        assert!(result.is_ok());
    }

    #[test]
    fn test_verify_hash_invalid() {
        // Create some test data
        let data = b"test layer data for hash verification";

        // Use an incorrect hash (all zeros)
        let wrong_hash = [0u8; 32];

        // Verification should fail with CorruptedLayer error
        let result = super::verify_hash(data, &wrong_hash);
        assert!(result.is_err());

        if let Err(BackendError::CorruptedLayer {
            layer_id,
            expected,
            actual,
        }) = result
        {
            // layer_id and expected should both be the truncated wrong_hash
            assert_eq!(layer_id, "0000000000000000");
            assert_eq!(expected, "0000000000000000");
            // actual should be the truncated real hash (not all zeros)
            assert_ne!(actual, "0000000000000000");
        } else {
            panic!("Expected CorruptedLayer error");
        }
    }

    #[test]
    fn test_verify_hash_empty_data() {
        // Empty data still has a valid SHA-256 hash
        let data: &[u8] = b"";

        // SHA-256 of empty string is well-known
        let mut hasher = Sha256::new();
        hasher.update(data);
        let correct_hash: [u8; 32] = hasher.finalize().into();

        // Verification should succeed
        let result = super::verify_hash(data, &correct_hash);
        assert!(result.is_ok());

        // But with wrong hash should fail
        let wrong_hash = [0xFFu8; 32];
        let result = super::verify_hash(data, &wrong_hash);
        assert!(result.is_err());
    }

    #[test]
    fn test_verify_hash_single_bit_difference() {
        // Create test data
        let data = b"test data for single bit verification";

        // Compute correct hash
        let mut hasher = Sha256::new();
        hasher.update(data);
        let mut almost_correct_hash: [u8; 32] = hasher.finalize().into();

        // Flip a single bit in the hash
        almost_correct_hash[0] ^= 0x01;

        // Verification should fail even with single bit difference
        let result = super::verify_hash(data, &almost_correct_hash);
        assert!(result.is_err());
        assert!(matches!(result, Err(BackendError::CorruptedLayer { .. })));
    }

    #[test]
    fn test_format_hash_truncation() {
        // Verify format_hash only uses first 8 bytes
        let hash1 = [
            0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, // first 8 bytes
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, // different tail
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00,
        ];
        let hash2 = [
            0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, // same first 8 bytes
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // different tail
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
            0xFF, 0xFF,
        ];

        // Both should produce the same truncated output
        assert_eq!(super::format_hash(&hash1), super::format_hash(&hash2));
        assert_eq!(super::format_hash(&hash1), "123456789abcdef0");
    }

    // ========================================================================
    // Registry Loading Tests (TASK-163)
    // ========================================================================

    #[test]
    fn test_format_hash_full() {
        let hash = [
            0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66,
            0x77, 0x88, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55,
            0x66, 0x77, 0x88, 0x99,
        ];
        let formatted = super::format_hash_full(&hash);
        assert_eq!(formatted.len(), 64); // 32 bytes * 2 hex chars
        assert_eq!(
            formatted,
            "123456789abcdef01122334455667788aabbccddeeff00112233445566778899"
        );
    }

    #[test]
    fn test_loader_with_cache_dir() {
        let loader = FileSystemLoader::with_cache_dir("/tmp/test-cache");
        assert!(loader.cache_dir.is_some());
        assert_eq!(
            loader.cache_dir.as_ref().unwrap().to_str().unwrap(),
            "/tmp/test-cache"
        );
    }

    #[test]
    fn test_loader_without_cache() {
        let loader = FileSystemLoader::new().without_cache();
        assert!(loader.cache_dir.is_none());
    }

    #[test]
    fn test_default_cache_dir() {
        // default_cache_dir should return Some on unix/windows
        let cache_dir = super::default_cache_dir();
        #[cfg(any(unix, windows))]
        assert!(cache_dir.is_some());
        #[cfg(any(unix, windows))]
        {
            let path = cache_dir.unwrap();
            assert!(path.to_string_lossy().contains(".hologram"));
            assert!(path.to_string_lossy().contains("cache"));
            assert!(path.to_string_lossy().contains("layers"));
        }
    }

    #[test]
    fn test_dirs_next_returns_home() {
        let home = super::dirs_next();
        #[cfg(unix)]
        {
            // On unix, should return HOME env var
            if std::env::var("HOME").is_ok() {
                assert!(home.is_some());
            }
        }
        #[cfg(windows)]
        {
            // On windows, should return USERPROFILE
            if std::env::var("USERPROFILE").is_ok() {
                assert!(home.is_some());
            }
        }
    }

    #[test]
    #[cfg(not(target_arch = "wasm32"))]
    fn test_registry_network_error() {
        // Test that invalid URLs produce network errors
        let loader = FileSystemLoader::new().without_cache();
        let mut cache = LayerCache::new();

        let layer_ref = LayerRef {
            layer_id: [0xab; 32],
            name: Some("test-layer".into()),
            location: LayerLocation::Registry {
                registry_url: "http://localhost:99999".into(), // Invalid port
                version: "1.0.0".into(),
            },
        };

        let result = loader.load(&layer_ref, None, &mut cache);
        assert!(result.is_err());
        if let Err(BackendError::LayerLoadError { reason, .. }) = result {
            assert!(
                reason.contains("failed to fetch"),
                "Expected fetch error, got: {reason}"
            );
        }
    }

    #[test]
    #[cfg(not(target_arch = "wasm32"))]
    fn test_registry_url_construction() {
        // Verify URL is constructed correctly by checking error message
        let loader = FileSystemLoader::new().without_cache();
        let mut cache = LayerCache::new();

        let layer_ref = LayerRef {
            layer_id: [
                0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66,
                0x77, 0x88, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55,
                0x66, 0x77, 0x88, 0x99,
            ],
            name: None,
            location: LayerLocation::Registry {
                registry_url: "https://registry.example.com".into(),
                version: "2.0.0".into(),
            },
        };

        // Will fail but error should indicate the URL was constructed properly
        let result = loader.load(&layer_ref, None, &mut cache);
        assert!(result.is_err());
    }
}
