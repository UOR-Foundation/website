//! Integration tests for bundle read/write operations.
//!
//! These tests verify end-to-end functionality across modules.

use hologram_holo::instruction::{BackendPlan, PlanMetadata};
use hologram_holo::types::ObservableMetadata;
use hologram_holo::{
    crc32, EmbeddableSection, FromEmbeddedSection, HolbReader, HolbWriter, HolmReader, HolmWriter,
    HoloError, HoloLoader,
};
use rkyv::ser::{serializers::AllocSerializer, Serializer};
use std::io::Write;
use tempfile::NamedTempFile;

// ============================================================================
// HOLB V1 Integration Tests
// ============================================================================

#[test]
fn test_holb_v1_full_roundtrip() {
    // Create a V1 bundle with graph and weights
    let graph_data = vec![1, 2, 3, 4, 5, 6, 7, 8];
    let weights_data = vec![10, 20, 30, 40, 50];

    let mut writer = HolbWriter::new();
    writer.set_graph(&graph_data);
    writer.set_weights(&weights_data);

    let bundle = writer.build().unwrap();

    // Read it back
    let reader = HolbReader::from_bytes(&bundle).unwrap();

    assert_eq!(reader.version(), 1);
    assert_eq!(reader.graph(), &graph_data);
    assert_eq!(reader.weights(), &weights_data);
    assert!(!reader.has_sections());
    assert!(reader.verify_all_checksums());
}

#[test]
fn test_holb_v1_graph_only() {
    let graph_data = vec![255; 1000];

    let mut writer = HolbWriter::new();
    writer.set_graph(&graph_data);

    let bundle = writer.build().unwrap();
    let reader = HolbReader::from_bytes(&bundle).unwrap();

    assert_eq!(reader.version(), 1);
    assert_eq!(reader.graph(), &graph_data);
    assert!(!reader.has_weights());
    assert!(reader.weights().is_empty());
}

// ============================================================================
// HOLB V2 Integration Tests
// ============================================================================

#[test]
fn test_holb_v2_with_sections_roundtrip() {
    let graph_data = vec![1, 2, 3, 4];
    let vocab_data = b"token1\ntoken2\ntoken3";
    let config_data = br#"{"model": "test"}"#;

    let mut writer = HolbWriter::new();
    writer.set_graph(&graph_data);
    writer.add_raw_section("vocabulary", "text/plain", vocab_data);
    writer.add_raw_section("config", "application/json", config_data);

    let bundle = writer.build().unwrap();
    let reader = HolbReader::from_bytes(&bundle).unwrap();

    assert_eq!(reader.version(), 2);
    assert_eq!(reader.graph(), &graph_data);
    assert!(reader.has_sections());
    assert_eq!(reader.sections_count(), 2);

    // Verify sections
    let vocab = reader.get_section("vocabulary").unwrap();
    assert_eq!(vocab, vocab_data);

    let config = reader.get_section("config").unwrap();
    assert_eq!(config, config_data);

    // Verify checksums
    assert!(reader.verify_all_checksums());
    assert!(reader.verify_section_checksum("vocabulary").unwrap());
    assert!(reader.verify_section_checksum("config").unwrap());
}

#[test]
fn test_holb_v2_with_sections_and_weights() {
    let graph_data = vec![1, 2];
    let section_data = b"section content";
    let weights_data = vec![100, 200, 150];

    let mut writer = HolbWriter::new();
    writer.set_graph(&graph_data);
    writer.add_raw_section("data", "application/octet-stream", section_data);
    writer.set_weights(&weights_data);

    let bundle = writer.build().unwrap();
    let reader = HolbReader::from_bytes(&bundle).unwrap();

    assert_eq!(reader.version(), 2);
    assert_eq!(reader.graph(), &graph_data);
    assert!(reader.has_sections());
    assert!(reader.has_weights());
    assert_eq!(reader.get_section("data").unwrap(), section_data);
    assert_eq!(reader.weights(), &weights_data);
    assert!(reader.verify_all_checksums());
}

// ============================================================================
// Custom Section Types
// ============================================================================

#[derive(Clone, Debug, PartialEq)]
struct Vocabulary {
    tokens: Vec<String>,
}

impl EmbeddableSection for Vocabulary {
    fn section_id(&self) -> &'static str {
        "vocabulary"
    }

    fn to_bytes(&self) -> Vec<u8> {
        self.tokens.join("\n").into_bytes()
    }

    fn content_type(&self) -> &'static str {
        "text/plain"
    }

    fn version(&self) -> u32 {
        1
    }
}

impl FromEmbeddedSection for Vocabulary {
    const SECTION_ID: &'static str = "vocabulary";

    fn from_bytes(bytes: &[u8]) -> hologram_holo::Result<Self> {
        let text = std::str::from_utf8(bytes).map_err(|e| HoloError::Other(e.to_string()))?;
        Ok(Self {
            tokens: text.lines().map(String::from).collect(),
        })
    }
}

#[test]
fn test_custom_section_roundtrip() {
    let vocab = Vocabulary {
        tokens: vec!["hello".into(), "world".into(), "test".into()],
    };

    let mut writer = HolbWriter::new();
    writer.set_graph(&[1, 2, 3]);
    writer.add_section(&vocab);

    let bundle = writer.build().unwrap();
    let reader = HolbReader::from_bytes(&bundle).unwrap();

    // Read back as raw bytes
    let vocab_bytes = reader.get_section("vocabulary").unwrap();

    // Parse using FromEmbeddedSection
    let parsed = Vocabulary::from_bytes(vocab_bytes).unwrap();
    assert_eq!(parsed, vocab);
}

// ============================================================================
// HOLM Pipeline Integration Tests
// ============================================================================

fn create_holb(id: u8) -> Vec<u8> {
    let mut writer = HolbWriter::new();
    writer.set_graph(&[id; 10]);
    writer.build().unwrap()
}

#[test]
fn test_holm_pipeline_roundtrip() {
    let model1 = create_holb(1);
    let model2 = create_holb(2);
    let model3 = create_holb(3);

    let mut writer = HolmWriter::new();
    writer.add_model("encoder", &model1).unwrap();
    writer.add_model("decoder", &model2).unwrap();
    writer.add_model("classifier", &model3).unwrap();

    let pipeline = writer.build().unwrap();
    let reader = HolmReader::from_bytes(&pipeline).unwrap();

    assert_eq!(reader.model_count(), 3);
    assert_eq!(
        reader.model_names(),
        vec!["encoder", "decoder", "classifier"]
    );

    // Verify each model
    let enc = reader.get_model("encoder").unwrap().unwrap();
    assert_eq!(enc, &model1[..]);

    let dec = reader.get_model("decoder").unwrap().unwrap();
    assert_eq!(dec, &model2[..]);

    let cls = reader.get_model("classifier").unwrap().unwrap();
    assert_eq!(cls, &model3[..]);

    assert!(reader.verify_all_checksums());
}

#[test]
fn test_holm_iterate_models() {
    let models: Vec<_> = (1..=5)
        .map(|i| (format!("model{i}"), create_holb(i)))
        .collect();

    let mut writer = HolmWriter::new();
    for (name, data) in &models {
        writer.add_model(name, data).unwrap();
    }

    let pipeline = writer.build().unwrap();
    let reader = HolmReader::from_bytes(&pipeline).unwrap();

    let mut count = 0;
    for (name, result) in reader.iter_models() {
        let data = result.unwrap();
        let expected = &models[count].1;
        assert_eq!(name, models[count].0);
        assert_eq!(data, &expected[..]);
        count += 1;
    }
    assert_eq!(count, 5);
}

#[test]
fn test_holm_get_model_by_index() {
    let model1 = create_holb(10);
    let model2 = create_holb(20);

    let mut writer = HolmWriter::new();
    writer.add_model("first", &model1).unwrap();
    writer.add_model("second", &model2).unwrap();

    let pipeline = writer.build().unwrap();
    let reader = HolmReader::from_bytes(&pipeline).unwrap();

    let first = reader.get_model_by_index(0).unwrap().unwrap();
    assert_eq!(first, &model1[..]);

    let second = reader.get_model_by_index(1).unwrap().unwrap();
    assert_eq!(second, &model2[..]);

    let missing = reader.get_model_by_index(99).unwrap();
    assert!(missing.is_none());
}

// ============================================================================
// Checksum Verification Tests
// ============================================================================

#[test]
fn test_checksum_consistency() {
    let data = b"Hello, World! This is test data for CRC32.";

    // Verify checksum is deterministic
    let checksum1 = crc32(data);
    let checksum2 = crc32(data);
    assert_eq!(checksum1, checksum2);

    // Verify different data gives different checksum
    let other_data = b"Different data";
    let checksum3 = crc32(other_data);
    assert_ne!(checksum1, checksum3);
}

#[test]
fn test_holb_corrupted_data_detection() {
    let mut writer = HolbWriter::new();
    writer.set_graph(&[1, 2, 3, 4, 5]);

    let mut bundle = writer.build().unwrap();

    // Corrupt the graph data (after header)
    let corrupt_pos = 50; // After the 48-byte header
    if corrupt_pos < bundle.len() {
        bundle[corrupt_pos] ^= 0xFF; // Flip bits
    }

    let reader = HolbReader::from_bytes(&bundle).unwrap();
    // Checksum should fail
    assert!(!reader.verify_graph_checksum());
    assert!(!reader.verify_all_checksums());
}

// ============================================================================
// Error Handling Tests
// ============================================================================

#[test]
fn test_empty_bundle_error() {
    let mut writer = HolbWriter::new();
    let result = writer.build();
    assert!(result.is_err());
}

#[test]
fn test_invalid_magic_error() {
    let bad_data = vec![b'J', b'U', b'N', b'K', 1, 0, 0, 0, 0, 0, 0, 0];
    let result = HolbReader::from_bytes(&bad_data);
    assert!(result.is_err());
}

#[test]
fn test_unsupported_version_error() {
    let mut data = vec![0u8; 64];
    data[0..4].copy_from_slice(b"HOLB");
    data[4..8].copy_from_slice(&99u32.to_le_bytes()); // Invalid version

    let result = HolbReader::from_bytes(&data);
    assert!(result.is_err());
}

#[test]
fn test_holm_duplicate_model_error() {
    let model = create_holb(1);

    let mut writer = HolmWriter::new();
    writer.add_model("test", &model).unwrap();

    let result = writer.add_model("test", &model);
    assert!(result.is_err());
}

#[test]
fn test_holm_invalid_holb_error() {
    let mut writer = HolmWriter::new();
    let result = writer.add_model("bad", &[1, 2, 3, 4]);
    assert!(result.is_err());
}

// ============================================================================
// Edge Cases
// ============================================================================

#[test]
fn test_large_graph_data() {
    let large_data: Vec<u8> = (0..10000).map(|i| (i % 256) as u8).collect();

    let mut writer = HolbWriter::new();
    writer.set_graph(&large_data);

    let bundle = writer.build().unwrap();
    let reader = HolbReader::from_bytes(&bundle).unwrap();

    assert_eq!(reader.graph(), &large_data[..]);
    assert!(reader.verify_all_checksums());
}

#[test]
fn test_many_sections() {
    let mut writer = HolbWriter::new();
    writer.set_graph(&[1, 2, 3]);

    for i in 0..20 {
        let name = format!("section_{i}");
        let data = format!("data for section {i}");
        writer.add_raw_section(&name, "text/plain", data.as_bytes());
    }

    let bundle = writer.build().unwrap();
    let reader = HolbReader::from_bytes(&bundle).unwrap();

    assert_eq!(reader.sections_count(), 20);

    for i in 0..20 {
        let name = format!("section_{i}");
        let expected = format!("data for section {i}");
        let actual = reader.get_section(&name).unwrap();
        assert_eq!(actual, expected.as_bytes());
    }

    assert!(reader.verify_all_checksums());
}

#[test]
fn test_unicode_section_ids() {
    let mut writer = HolbWriter::new();
    writer.set_graph(&[1]);
    writer.add_raw_section("日本語", "text/plain", b"japanese");
    writer.add_raw_section("emoji_🚀", "text/plain", b"rocket");

    let bundle = writer.build().unwrap();
    let reader = HolbReader::from_bytes(&bundle).unwrap();

    assert_eq!(reader.get_section("日本語").unwrap(), b"japanese");
    assert_eq!(reader.get_section("emoji_🚀").unwrap(), b"rocket");
}

#[test]
fn test_section_entry_metadata() {
    let mut writer = HolbWriter::new();
    writer.set_graph(&[1]);
    writer.add_raw_section("test", "application/x-custom", b"data");

    let bundle = writer.build().unwrap();
    let reader = HolbReader::from_bytes(&bundle).unwrap();

    let entry = reader.get_section_entry("test").unwrap();
    assert_eq!(entry.id, "test");
    assert_eq!(entry.content_type, "application/x-custom");
    assert_eq!(entry.size, 4);
    assert_eq!(entry.version, 1);
}

#[test]
fn test_holm_single_model() {
    let model = create_holb(42);

    let mut writer = HolmWriter::new();
    writer.add_model("only_model", &model).unwrap();

    let pipeline = writer.build().unwrap();
    let reader = HolmReader::from_bytes(&pipeline).unwrap();

    assert_eq!(reader.model_count(), 1);
    assert_eq!(reader.model_names(), vec!["only_model"]);

    let data = reader.get_model("only_model").unwrap().unwrap();
    assert_eq!(data, &model[..]);
}

// ============================================================================
// Memory-Mapped Zero-Copy Tests
// ============================================================================

/// Create a valid rkyv-serialized BackendPlan for testing with HoloLoader.
fn create_test_plan_bytes(constants: Vec<u8>) -> Vec<u8> {
    let plan = BackendPlan {
        instructions: vec![],
        buffers: vec![],
        constants,
        workspace_size: 0,
        dependencies: vec![],
        metadata: PlanMetadata {
            name: "test".to_string(),
            version: "1.0".to_string(),
            author: None,
            description: None,
        },
        node_buffer_map: vec![],
        observable_metadata: ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let mut serializer = AllocSerializer::<256>::default();
    serializer
        .serialize_value(&plan)
        .expect("Failed to serialize plan");
    serializer.into_serializer().into_inner().to_vec()
}

#[test]
fn test_mmap_zero_copy_holb() {
    // Create a valid BackendPlan with known constants
    let constants = vec![0xAB, 0xCD, 0xEF, 0x12];
    let plan_bytes = create_test_plan_bytes(constants.clone());

    // Create HOLB bundle
    let mut writer = HolbWriter::new();
    writer.set_graph(&plan_bytes);
    let bundle = writer.build().unwrap();

    // Write to temp file
    let mut file = NamedTempFile::new().unwrap();
    file.write_all(&bundle).unwrap();
    file.flush().unwrap();

    // Load via HoloLoader (uses mmap)
    let loaded = HoloLoader::load(file.path()).unwrap();

    // Get constants (zero-copy reference into mmap)
    let loaded_constants = loaded.constants();

    // Verify the constants match - this proves zero-copy is working
    assert_eq!(loaded_constants, &constants[..]);
}

#[test]
fn test_mmap_zero_copy_holm_pipeline() {
    // Create valid BackendPlans with distinct constants
    let constants1 = vec![1, 2, 3, 4];
    let constants2 = vec![10, 20, 30, 40];

    let plan_bytes1 = create_test_plan_bytes(constants1.clone());
    let plan_bytes2 = create_test_plan_bytes(constants2.clone());

    // Create HOLB bundles
    let mut holb_writer1 = HolbWriter::new();
    holb_writer1.set_graph(&plan_bytes1);
    let model1 = holb_writer1.build().unwrap();

    let mut holb_writer2 = HolbWriter::new();
    holb_writer2.set_graph(&plan_bytes2);
    let model2 = holb_writer2.build().unwrap();

    // Create HOLM pipeline
    let mut holm_writer = HolmWriter::new();
    holm_writer.add_model("encoder", &model1).unwrap();
    holm_writer.add_model("decoder", &model2).unwrap();
    let pipeline = holm_writer.build().unwrap();

    // Write to temp file
    let mut file = NamedTempFile::new().unwrap();
    file.write_all(&pipeline).unwrap();
    file.flush().unwrap();

    // Load as pipeline via HoloLoader (uses mmap with Arc<Mmap>)
    let loaded = HoloLoader::load_pipeline(file.path()).unwrap();

    // Verify model count and names
    assert_eq!(loaded.model_count(), 2);
    assert_eq!(loaded.model_names(), vec!["encoder", "decoder"]);

    // Access models - these are zero-copy references into the shared mmap
    let enc = loaded.get_model("encoder").unwrap().unwrap();
    let dec = loaded.get_model("decoder").unwrap().unwrap();

    // Verify the constants match - proves zero-copy from mmap
    assert_eq!(&enc.constants[..], &constants1[..]);
    assert_eq!(&dec.constants[..], &constants2[..]);

    // Primary model should work
    let primary = loaded.primary_model().unwrap();
    assert_eq!(&primary.constants[..], &constants1[..]);
}

#[test]
fn test_mmap_lifetime_preserved() {
    // Create a valid BackendPlan
    let constants = vec![42, 43, 44, 45];
    let plan_bytes = create_test_plan_bytes(constants.clone());

    // Create HOLB bundle
    let mut writer = HolbWriter::new();
    writer.set_graph(&plan_bytes);
    let bundle = writer.build().unwrap();

    // Write to temp file
    let mut file = NamedTempFile::new().unwrap();
    file.write_all(&bundle).unwrap();
    file.flush().unwrap();

    // Load via HoloLoader
    let loaded = HoloLoader::load(file.path()).unwrap();

    // Get the plan reference
    let plan = loaded.plan();

    // Access plan data multiple times - should work because mmap is preserved
    for _ in 0..10 {
        assert_eq!(&plan.constants[..], &constants[..]);
        assert_eq!(plan.workspace_size, 0);
    }
}
