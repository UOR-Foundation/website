/**
 * SovereigntyMap — Interactive hexagonal visualization of 96 sovereignty edges.
 *
 * Renders the 6 sovereignty dimensions as vertices of a hexagon.
 * Edges between dimension-pairs are drawn as arc segments, color-coded by state.
 * Click any edge segment to cycle: shielded → selective → disclosed → shielded.
 */

import { useState, useMemo } from "react";
import type { SovereigntySurface, EdgeState, BoundaryEdge } from "../types";
import {
  SOVEREIGNTY_DIMENSIONS,
  edgesByDimension,
  disclosureRatio,
} from "../engine/sovereignty-engine";
import { Shield, Eye, EyeOff } from "lucide-react";

interface Props {
  readonly surface: SovereigntySurface;
  readonly onFlipEdge: (edgeId: string, newState: EdgeState) => void;
}

// ── Layout constants ────────────────────────────────────────────────────────

const SIZE = 420;
const CX = SIZE / 2;
const CY = SIZE / 2;
const RADIUS = 160;
const EDGE_RING_INNER = 96;
const EDGE_RING_OUTER = 145;

/** Get (x, y) for a hexagon vertex at index 0–5 (top = 0, clockwise). */
function hexPoint(index: number, r: number): [number, number] {
  const angle = (Math.PI / 2) + (index * (2 * Math.PI) / 6); // start from top
  return [CX + r * Math.cos(angle), CY - r * Math.sin(angle)];
}

const NEXT_STATE: Record<EdgeState, EdgeState> = {
  shielded: "selective",
  selective: "disclosed",
  disclosed: "shielded",
};

const STATE_COLORS: Record<EdgeState, string> = {
  shielded: "hsl(38, 15%, 20%)",     // border color — dark
  selective: "hsl(38, 50%, 40%)",     // accent — gold
  disclosed: "hsl(38, 60%, 60%)",     // primary — bright gold
};

const STATE_LABELS: Record<EdgeState, string> = {
  shielded: "Private",
  selective: "Limited",
  disclosed: "Shared",
};

// ── Dimension pair indices (matching sovereignty-engine) ────────────────────

function getDimensionPairs() {
  const ids = SOVEREIGNTY_DIMENSIONS.map((d) => d.id);
  return ids.map((id, i) => ({
    a: id,
    b: ids[(i + 1) % ids.length],
    pairIndex: i,
  }));
}

export default function SovereigntyMap({ surface, onFlipEdge }: Props) {
  const [hoveredEdge, setHoveredEdge] = useState<string | null>(null);
  const [selectedDim, setSelectedDim] = useState<string | null>(null);

  const pairs = useMemo(getDimensionPairs, []);
  const ratio = disclosureRatio(surface);

  // Group edges by pair index
  const edgesByPair = useMemo(() => {
    const map = new Map<number, BoundaryEdge[]>();
    for (const edge of surface.edges) {
      const pairIdx = Math.floor(edge.index / 16);
      if (!map.has(pairIdx)) map.set(pairIdx, []);
      map.get(pairIdx)!.push(edge);
    }
    return map;
  }, [surface.edges]);

  // Stats for selected dimension
  const dimStats = useMemo(() => {
    if (!selectedDim) return null;
    const edges = edgesByDimension(surface, selectedDim as any);
    const shielded = edges.filter((e) => e.state === "shielded").length;
    const selective = edges.filter((e) => e.state === "selective").length;
    const disclosed = edges.filter((e) => e.state === "disclosed").length;
    return { total: edges.length, shielded, selective, disclosed, edges };
  }, [surface, selectedDim]);

  const hoveredEdgeData = hoveredEdge
    ? surface.edges.find((e) => e.id === hoveredEdge)
    : null;

  return (
    <div
      className="rounded-lg border border-border bg-card p-6 animate-fade-in space-y-4"
      style={{ animationDelay: "0.1s" }}
    >
      <div className="flex items-center justify-between">
        <h3 className="text-base font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
          <Shield className="h-4 w-4" />
          Privacy Controls
        </h3>
        <span className="text-sm text-muted-foreground">
          {Math.round(ratio * 100)}% shared
        </span>
      </div>

      {/* SVG Hex Diagram */}
      <div className="flex justify-center">
        <svg
          viewBox={`0 0 ${SIZE} ${SIZE}`}
          width={SIZE}
          height={SIZE}
          className="overflow-visible"
        >
          {/* Background hex outline */}
          <polygon
            points={Array.from({ length: 6 }, (_, i) => hexPoint(i, RADIUS).join(",")).join(" ")}
            fill="none"
            stroke="hsl(38, 15%, 18%)"
            strokeWidth="1"
          />

          {/* Inner hex */}
          <polygon
            points={Array.from({ length: 6 }, (_, i) => hexPoint(i, EDGE_RING_INNER - 8).join(",")).join(" ")}
            fill="hsl(25, 10%, 10%)"
            stroke="hsl(38, 15%, 16%)"
            strokeWidth="0.5"
          />

          {/* Edge segments — 16 tiny arcs per dimension pair */}
          {pairs.map((pair, pairIdx) => {
            const pairEdges = edgesByPair.get(pairIdx) ?? [];
            const [x1, y1] = hexPoint(pairIdx, RADIUS);
            const [x2, y2] = hexPoint((pairIdx + 1) % 6, RADIUS);

            return pairEdges.map((edge, subIdx) => {
              const t0 = subIdx / 16;
              const t1 = (subIdx + 1) / 16;

              // Interpolate along the edge between two hex vertices
              // But place them in an arc between inner and outer rings
              const midAngle = (Math.PI / 2) + ((pairIdx + 0.5) * (2 * Math.PI) / 6);
              const segAngleSpread = (2 * Math.PI) / 6;
              const startAngle = midAngle + segAngleSpread * (t0 - 0.5);
              const endAngle = midAngle + segAngleSpread * (t1 - 0.5);

              const rMid = (EDGE_RING_INNER + EDGE_RING_OUTER) / 2;
              const rHalf = (EDGE_RING_OUTER - EDGE_RING_INNER) / 2 - 1;

              const cx = CX + rMid * Math.cos(startAngle + (endAngle - startAngle) / 2);
              const cy = CY - rMid * Math.sin(startAngle + (endAngle - startAngle) / 2);

              const isHovered = hoveredEdge === edge.id;
              const color = STATE_COLORS[edge.state];

              return (
                <g key={edge.id}>
                  <circle
                    cx={cx}
                    cy={cy}
                    r={isHovered ? rHalf + 2 : rHalf}
                    fill={color}
                    opacity={isHovered ? 1 : 0.8}
                    stroke={isHovered ? "hsl(38, 60%, 70%)" : "none"}
                    strokeWidth={isHovered ? 1.5 : 0}
                    className="cursor-pointer transition-all duration-150"
                    onMouseEnter={() => setHoveredEdge(edge.id)}
                    onMouseLeave={() => setHoveredEdge(null)}
                    onClick={() => onFlipEdge(edge.id, NEXT_STATE[edge.state])}
                  />
                </g>
              );
            });
          })}

          {/* Dimension vertex labels */}
          {SOVEREIGNTY_DIMENSIONS.map((dim, i) => {
            const [x, y] = hexPoint(i, RADIUS + 32);
            const isSelected = selectedDim === dim.id;
            return (
              <g key={dim.id}>
                {/* Vertex dot */}
                <circle
                  cx={hexPoint(i, RADIUS)[0]}
                  cy={hexPoint(i, RADIUS)[1]}
                  r={isSelected ? 5 : 4}
                  fill={isSelected ? "hsl(38, 60%, 60%)" : "hsl(38, 40%, 45%)"}
                  className="cursor-pointer"
                  onClick={() => setSelectedDim(isSelected ? null : dim.id)}
                />
                {/* Label */}
                <text
                  x={x}
                  y={y}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill={isSelected ? "hsl(38, 60%, 60%)" : "hsl(30, 10%, 60%)"}
                  fontSize="15"
                  fontWeight={isSelected ? "700" : "500"}
                  fontFamily="var(--font-body)"
                  className="cursor-pointer select-none"
                  onClick={() => setSelectedDim(isSelected ? null : dim.id)}
                >
                  {dim.label}
                </text>
              </g>
            );
          })}

          {/* Center label */}
          <text
            x={CX}
            y={CY - 10}
            textAnchor="middle"
            fill="hsl(38, 20%, 85%)"
            fontSize="34"
            fontFamily="var(--font-display)"
          >
            {96 - surface.edges.filter((e) => e.state === "shielded").length}
          </text>
          <text
            x={CX}
            y={CY + 14}
            textAnchor="middle"
            fill="hsl(30, 10%, 50%)"
            fontSize="13"
            fontFamily="var(--font-body)"
          >
            data points shared
          </text>
        </svg>
      </div>

      {/* Legend */}
      <div className="flex justify-center gap-4">
        {(["shielded", "selective", "disclosed"] as const).map((state) => (
          <div key={state} className="flex items-center gap-2">
            <div
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: STATE_COLORS[state] }}
            />
            <span className="text-sm text-muted-foreground">{STATE_LABELS[state]}</span>
          </div>
        ))}
      </div>

      {/* Hover tooltip */}
      {hoveredEdgeData && (
        <div className="text-center text-xs text-muted-foreground animate-fade-in">
          <span className="font-mono text-foreground">{hoveredEdgeData.label || hoveredEdgeData.id}</span>
          {" — "}
          <span style={{ color: STATE_COLORS[hoveredEdgeData.state] }}>
            {STATE_LABELS[hoveredEdgeData.state]}
          </span>
          <span className="text-muted-foreground"> · click to change</span>
        </div>
      )}

      {/* Dimension detail panel */}
      {dimStats && selectedDim && (
        <div className="rounded-md border border-border bg-muted/30 p-4 space-y-3 animate-fade-in">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-foreground">
              {SOVEREIGNTY_DIMENSIONS.find((d) => d.id === selectedDim)?.label} Dimension
            </span>
            <span className="text-[10px] text-muted-foreground">{dimStats.total} data points</span>
          </div>

          {/* State breakdown bar */}
          <div className="flex h-2 rounded-full overflow-hidden bg-muted">
            {dimStats.disclosed > 0 && (
              <div
                className="h-full transition-all duration-300"
                style={{
                  width: `${(dimStats.disclosed / dimStats.total) * 100}%`,
                  backgroundColor: STATE_COLORS.disclosed,
                }}
              />
            )}
            {dimStats.selective > 0 && (
              <div
                className="h-full transition-all duration-300"
                style={{
                  width: `${(dimStats.selective / dimStats.total) * 100}%`,
                  backgroundColor: STATE_COLORS.selective,
                }}
              />
            )}
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <div className="text-sm font-semibold text-foreground">{dimStats.shielded}</div>
              <div className="text-[10px] text-muted-foreground flex items-center justify-center gap-1">
                <EyeOff className="h-2.5 w-2.5" /> Private
              </div>
            </div>
            <div>
              <div className="text-sm font-semibold text-foreground">{dimStats.selective}</div>
              <div className="text-[10px] text-muted-foreground flex items-center justify-center gap-1">
                <Shield className="h-2.5 w-2.5" /> Limited
              </div>
            </div>
            <div>
              <div className="text-sm font-semibold text-foreground">{dimStats.disclosed}</div>
              <div className="text-[10px] text-muted-foreground flex items-center justify-center gap-1">
                <Eye className="h-2.5 w-2.5" /> Shared
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
