//! Allocation tracking for zero-copy validation.
//!
//! This module provides utilities for tracking memory allocations within
//! specific code regions. It is used to validate that hot paths do not
//! perform unexpected allocations.
//!
//! Requires the `alloc-tracking` feature to be enabled.

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};

/// Global flag indicating if we're in a no-allocation zone.
static IN_NO_ALLOC_ZONE: AtomicBool = AtomicBool::new(false);

/// Counter for allocations that occurred in no-alloc zones.
static VIOLATION_COUNT: AtomicU64 = AtomicU64::new(0);

/// A guard that marks a region of code as an allocation-free zone.
///
/// When allocation tracking is enabled, any allocations that occur while
/// this guard is active will be logged as violations.
///
/// # Example
///
/// ```rust
/// use hologram_telemetry::alloc::AllocationZoneGuard;
///
/// fn hot_path() {
///     let _guard = AllocationZoneGuard::new("critical_section");
///     // Code here should not allocate
/// }
/// ```
pub struct AllocationZoneGuard {
    context: &'static str,
    was_active: bool,
}

impl AllocationZoneGuard {
    /// Create a new allocation zone guard with the given context name.
    #[must_use]
    pub fn new(context: &'static str) -> Self {
        let was_active = IN_NO_ALLOC_ZONE.swap(true, Ordering::SeqCst);
        Self {
            context,
            was_active,
        }
    }

    /// Get the context name for this zone.
    #[must_use]
    pub const fn context(&self) -> &'static str {
        self.context
    }

    /// Check if currently in a no-allocation zone.
    #[must_use]
    pub fn is_active() -> bool {
        IN_NO_ALLOC_ZONE.load(Ordering::SeqCst)
    }

    /// Get the current violation count.
    #[must_use]
    pub fn violation_count() -> u64 {
        VIOLATION_COUNT.load(Ordering::SeqCst)
    }

    /// Reset the violation counter.
    pub fn reset_violations() {
        VIOLATION_COUNT.store(0, Ordering::SeqCst);
    }

    /// Record an allocation violation.
    ///
    /// This is called by the global allocator hook when an allocation
    /// occurs within a no-alloc zone.
    pub fn record_violation() {
        VIOLATION_COUNT.fetch_add(1, Ordering::SeqCst);
    }
}

impl Drop for AllocationZoneGuard {
    fn drop(&mut self) {
        IN_NO_ALLOC_ZONE.store(self.was_active, Ordering::SeqCst);
    }
}

/// Information about an allocation that occurred in a no-alloc zone.
#[derive(Debug, Clone)]
pub struct AllocationViolation {
    /// Size of the allocation in bytes.
    pub size: usize,
    /// Context name of the no-alloc zone.
    pub context: &'static str,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_allocation_zone_guard_new() {
        let guard = AllocationZoneGuard::new("test");
        assert_eq!(guard.context(), "test");
        assert!(AllocationZoneGuard::is_active());
        drop(guard);
        assert!(!AllocationZoneGuard::is_active());
    }

    #[test]
    fn test_allocation_zone_guard_nested() {
        {
            let _outer = AllocationZoneGuard::new("outer");
            assert!(AllocationZoneGuard::is_active());
            {
                let _inner = AllocationZoneGuard::new("inner");
                assert!(AllocationZoneGuard::is_active());
            }
            assert!(AllocationZoneGuard::is_active());
        }
        assert!(!AllocationZoneGuard::is_active());
    }

    #[test]
    fn test_violation_count() {
        AllocationZoneGuard::reset_violations();
        assert_eq!(AllocationZoneGuard::violation_count(), 0);

        AllocationZoneGuard::record_violation();
        assert_eq!(AllocationZoneGuard::violation_count(), 1);

        AllocationZoneGuard::record_violation();
        assert_eq!(AllocationZoneGuard::violation_count(), 2);

        AllocationZoneGuard::reset_violations();
        assert_eq!(AllocationZoneGuard::violation_count(), 0);
    }

    #[test]
    fn test_allocation_violation_struct() {
        let violation = AllocationViolation {
            size: 1024,
            context: "test_zone",
        };
        assert_eq!(violation.size, 1024);
        assert_eq!(violation.context, "test_zone");
    }
}
