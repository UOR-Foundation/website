//! Backend type definitions and capabilities.

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Backend type identifier.
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub enum BackendType {
    /// CPU backend (x86_64, aarch64, etc.)
    Cpu,

    /// WebAssembly backend
    Wasm,

    /// CUDA backend (NVIDIA GPUs)
    Cuda,

    /// Metal backend (Apple GPUs)
    Metal,

    /// WebGPU backend (cross-platform GPU via browser/native)
    WebGpu,

    /// Custom backend
    Custom(String),
}

/// Buffer reference discriminant.
///
/// Identifies which buffer a particular operation should use.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BufferRef {
    /// Caller-provided input buffer
    Input(u32),

    /// Caller-provided output buffer
    Output(u32),

    /// Pre-allocated workspace at offset
    Workspace {
        /// Offset into workspace buffer
        offset: usize,
        /// Size in bytes
        size: usize,
    },

    /// Embedded constant data (zero-copy from plan)
    Constant {
        /// Offset into constant data
        offset: usize,
        /// Size in bytes
        size: usize,
    },
}

impl BufferRef {
    /// Validate this buffer reference against given capacities.
    ///
    /// # Arguments
    ///
    /// * `input_count` - Number of available input buffers
    /// * `output_count` - Number of available output buffers
    /// * `workspace_capacity` - Total workspace capacity in bytes
    /// * `constant_capacity` - Total constant data capacity in bytes
    ///
    /// # Errors
    ///
    /// Returns `InvalidBufferIndex` if input/output index is out of range.
    /// Returns `WorkspaceOverflow` if workspace offset+size exceeds capacity.
    /// Returns `ConstantOverflow` if constant offset+size exceeds capacity.
    pub fn validate(
        &self,
        input_count: usize,
        output_count: usize,
        workspace_capacity: usize,
        constant_capacity: usize,
    ) -> Result<()> {
        match self {
            Self::Input(idx) => {
                if (*idx as usize) >= input_count {
                    return Err(BackendError::InvalidBufferIndex {
                        kind: "input",
                        index: *idx,
                        count: input_count,
                    });
                }
            }
            Self::Output(idx) => {
                if (*idx as usize) >= output_count {
                    return Err(BackendError::InvalidBufferIndex {
                        kind: "output",
                        index: *idx,
                        count: output_count,
                    });
                }
            }
            Self::Workspace { offset, size } => {
                // Check for arithmetic overflow in offset + size
                let end = offset
                    .checked_add(*size)
                    .ok_or(BackendError::WorkspaceOverflow {
                        offset: *offset,
                        size: *size,
                        capacity: workspace_capacity,
                    })?;
                if end > workspace_capacity {
                    return Err(BackendError::WorkspaceOverflow {
                        offset: *offset,
                        size: *size,
                        capacity: workspace_capacity,
                    });
                }
            }
            Self::Constant { offset, size } => {
                // Check for arithmetic overflow in offset + size
                let end = offset
                    .checked_add(*size)
                    .ok_or(BackendError::ConstantOverflow {
                        offset: *offset,
                        size: *size,
                        capacity: constant_capacity,
                    })?;
                if end > constant_capacity {
                    return Err(BackendError::ConstantOverflow {
                        offset: *offset,
                        size: *size,
                        capacity: constant_capacity,
                    });
                }
            }
        }
        Ok(())
    }

    /// Returns true if this is an Input variant.
    #[must_use]
    pub const fn is_input(&self) -> bool {
        matches!(self, Self::Input(_))
    }

    /// Returns true if this is an Output variant.
    #[must_use]
    pub const fn is_output(&self) -> bool {
        matches!(self, Self::Output(_))
    }

    /// Returns true if this is a Workspace variant.
    #[must_use]
    pub const fn is_workspace(&self) -> bool {
        matches!(self, Self::Workspace { .. })
    }

    /// Returns true if this is a Constant variant.
    #[must_use]
    pub const fn is_constant(&self) -> bool {
        matches!(self, Self::Constant { .. })
    }

    /// Get the size in bytes if this is a Workspace or Constant variant.
    #[must_use]
    pub const fn size(&self) -> Option<usize> {
        match self {
            Self::Workspace { size, .. } | Self::Constant { size, .. } => Some(*size),
            Self::Input(_) | Self::Output(_) => None,
        }
    }

    /// Get the offset if this is a Workspace or Constant variant.
    #[must_use]
    pub const fn offset(&self) -> Option<usize> {
        match self {
            Self::Workspace { offset, .. } | Self::Constant { offset, .. } => Some(*offset),
            Self::Input(_) | Self::Output(_) => None,
        }
    }

    /// Get the buffer index if this is an Input or Output variant.
    #[must_use]
    pub const fn index(&self) -> Option<u32> {
        match self {
            Self::Input(idx) | Self::Output(idx) => Some(*idx),
            Self::Workspace { .. } | Self::Constant { .. } => None,
        }
    }
}

/// Context for validating buffer references.
///
/// Provides a reusable validation context that can check multiple
/// buffer references against the same capacities.
#[derive(Debug, Clone, Copy, Default)]
pub struct BufferValidationContext {
    /// Number of input buffers
    pub input_count: usize,
    /// Number of output buffers
    pub output_count: usize,
    /// Workspace capacity in bytes
    pub workspace_capacity: usize,
    /// Constant data capacity in bytes
    pub constant_capacity: usize,
}

impl BufferValidationContext {
    /// Create a new validation context.
    #[must_use]
    pub const fn new(
        input_count: usize,
        output_count: usize,
        workspace_capacity: usize,
        constant_capacity: usize,
    ) -> Self {
        Self {
            input_count,
            output_count,
            workspace_capacity,
            constant_capacity,
        }
    }

    /// Validate a buffer reference in this context.
    ///
    /// # Errors
    ///
    /// Returns error if the buffer reference is invalid for this context.
    pub fn validate(&self, buf: &BufferRef) -> Result<()> {
        buf.validate(
            self.input_count,
            self.output_count,
            self.workspace_capacity,
            self.constant_capacity,
        )
    }

    /// Validate multiple buffer references.
    ///
    /// # Errors
    ///
    /// Returns error on first invalid buffer reference found.
    pub fn validate_all(&self, bufs: &[BufferRef]) -> Result<()> {
        for buf in bufs {
            self.validate(buf)?;
        }
        Ok(())
    }
}

/// Backend error types.
#[derive(Debug, thiserror::Error)]
pub enum BackendError {
    /// Invalid buffer reference
    #[error("Invalid buffer reference: {0:?}")]
    InvalidBuffer(BufferRef),

    /// Invalid buffer index
    #[error("Invalid {kind} buffer index {index} (only {count} buffers available)")]
    InvalidBufferIndex {
        /// Buffer kind (input/output)
        kind: &'static str,
        /// Requested index
        index: u32,
        /// Number of available buffers
        count: usize,
    },

    /// Buffer size mismatch
    #[error("Buffer size mismatch: expected {expected}, got {actual}")]
    SizeMismatch {
        /// Expected size
        expected: usize,
        /// Actual size
        actual: usize,
    },

    /// Workspace overflow
    #[error("Workspace overflow: offset {offset} + size {size} exceeds capacity {capacity}")]
    WorkspaceOverflow {
        /// Requested offset
        offset: usize,
        /// Requested size
        size: usize,
        /// Workspace capacity
        capacity: usize,
    },

    /// Constant data overflow
    #[error("Constant overflow: offset {offset} + size {size} exceeds capacity {capacity}")]
    ConstantOverflow {
        /// Requested offset
        offset: usize,
        /// Requested size
        size: usize,
        /// Constants capacity
        capacity: usize,
    },

    /// Alignment error
    #[error("Alignment error: required {required}-byte alignment, got offset {actual}")]
    AlignmentError {
        /// Required alignment
        required: usize,
        /// Actual alignment offset
        actual: usize,
    },

    /// Unsupported instruction
    #[error("Unsupported instruction: {0}")]
    UnsupportedInstruction(String),

    /// Layer loading error
    #[error("Failed to load layer '{layer_id}': {reason}")]
    LayerLoadError {
        /// Layer identifier (truncated hash)
        layer_id: String,
        /// Error reason
        reason: String,
    },

    /// Layer content hash mismatch (corruption detected)
    #[error("Corrupted layer '{layer_id}': expected hash {expected}, got {actual}")]
    CorruptedLayer {
        /// Layer identifier (truncated hash)
        layer_id: String,
        /// Expected hash (hex)
        expected: String,
        /// Actual computed hash (hex)
        actual: String,
    },

    /// Feature not implemented
    #[error("Not implemented: {feature}")]
    NotImplemented {
        /// Feature description
        feature: String,
    },

    /// Execution error with instruction context
    #[error("Execution error at instruction {index}: {operation}: {message}")]
    InstructionError {
        /// Instruction index in the plan
        index: usize,
        /// Operation name
        operation: String,
        /// Error message
        message: String,
    },

    /// Execution error
    #[error("Execution error: {0}")]
    ExecutionError(String),

    /// I/O error
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),

    /// Format error from hologram-holo
    #[error("Format error: {0}")]
    Format(#[from] hologram_holo::HoloError),

    /// Other error
    #[error("{0}")]
    Other(String),
}

impl BackendError {
    /// Get actionable help text for this error.
    ///
    /// Returns guidance on how to resolve or investigate the error.
    #[must_use]
    pub fn help(&self) -> Option<&'static str> {
        match self {
            Self::InvalidBuffer(_) | Self::InvalidBufferIndex { .. } => Some(
                "Check that buffer indices match the plan's expected inputs and outputs.",
            ),
            Self::SizeMismatch { .. } => Some(
                "Ensure input buffer sizes match the model's expected dimensions. \
                 Use `hologram info` to check required sizes.",
            ),
            Self::WorkspaceOverflow { .. } => Some(
                "The operation requires more workspace than allocated. \
                 This may indicate a compilation issue or very large inputs.",
            ),
            Self::ConstantOverflow { .. } => Some(
                "Constant data access is out of bounds. The plan may be corrupted.",
            ),
            Self::AlignmentError { .. } => Some(
                "Buffer is not properly aligned. Ensure allocations use aligned_alloc or similar.",
            ),
            Self::UnsupportedInstruction(_) => Some(
                "This instruction is not supported on the current backend. \
                 Try a different backend or update to a newer version.",
            ),
            Self::LayerLoadError { .. } => Some(
                "Failed to load a dependent layer. Check registry configuration and network access.",
            ),
            Self::CorruptedLayer { .. } => Some(
                "Layer content hash mismatch indicates corruption. \
                 Try clearing the cache and re-downloading.",
            ),
            Self::NotImplemented { .. } => Some(
                "This feature is not yet available. Check the project roadmap for updates.",
            ),
            Self::InstructionError { .. } => Some(
                "An operation failed during execution. Check input data validity and buffer sizes.",
            ),
            _ => None,
        }
    }

    /// Check if this error is recoverable by retrying.
    #[must_use]
    pub fn is_retryable(&self) -> bool {
        matches!(self, Self::LayerLoadError { .. } | Self::Io(_))
    }

    /// Check if this error indicates a programming/usage error.
    #[must_use]
    pub fn is_usage_error(&self) -> bool {
        matches!(
            self,
            Self::InvalidBuffer(_)
                | Self::InvalidBufferIndex { .. }
                | Self::SizeMismatch { .. }
                | Self::AlignmentError { .. }
        )
    }
}

/// Result type for backend operations.
pub type Result<T> = std::result::Result<T, BackendError>;

/// Backend capabilities for compile-time planning.
///
/// Provides information about hardware features and limits
/// that can be used during the compilation pipeline.
#[derive(Debug, Clone)]
pub struct BackendCapabilities {
    /// Backend type
    pub backend_type: BackendType,

    /// SIMD width (8 for AVX2, 16 for AVX-512, 4 for ARM NEON)
    pub vector_width: usize,

    /// L1 cache size per core (bytes)
    pub l1_cache_size: usize,

    /// L2 cache size (bytes)
    pub l2_cache_size: usize,

    /// FMA (fused multiply-add) support
    pub has_fma: bool,

    /// SHA-NI (SHA extensions) support
    pub has_sha: bool,

    /// AES-NI (AES extensions) support
    pub has_aes: bool,
}

impl Default for BackendCapabilities {
    fn default() -> Self {
        Self {
            backend_type: BackendType::Cpu,
            vector_width: 8,           // AVX2
            l1_cache_size: 32 * 1024,  // 32 KB
            l2_cache_size: 256 * 1024, // 256 KB
            has_fma: false,
            has_sha: false,
            has_aes: false,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_backend_type_variants() {
        let cpu = BackendType::Cpu;
        let wasm = BackendType::Wasm;
        let cuda = BackendType::Cuda;
        let metal = BackendType::Metal;
        let custom = BackendType::Custom(String::from("test"));

        assert_eq!(cpu, BackendType::Cpu);
        assert_ne!(cpu, wasm);
        assert_ne!(wasm, cuda);
        assert_ne!(cuda, metal);
        assert_eq!(custom, BackendType::Custom(String::from("test")));
    }

    #[test]
    fn test_buffer_ref_variants() {
        let input = BufferRef::Input(0);
        let output = BufferRef::Output(1);
        let workspace = BufferRef::Workspace {
            offset: 0,
            size: 1024,
        };
        let constant = BufferRef::Constant {
            offset: 0,
            size: 512,
        };

        assert!(matches!(input, BufferRef::Input(0)));
        assert!(matches!(output, BufferRef::Output(1)));
        assert!(matches!(workspace, BufferRef::Workspace { .. }));
        assert!(matches!(constant, BufferRef::Constant { .. }));
    }

    #[test]
    fn test_capabilities_default() {
        let caps = BackendCapabilities::default();
        assert_eq!(caps.backend_type, BackendType::Cpu);
        assert_eq!(caps.vector_width, 8);
        assert_eq!(caps.l1_cache_size, 32 * 1024);
        assert_eq!(caps.l2_cache_size, 256 * 1024);
    }

    // ============================================================================
    // Error Message Quality Tests (TASK-051)
    // ============================================================================

    #[test]
    fn test_error_invalid_buffer_message() {
        let err = BackendError::InvalidBuffer(BufferRef::Input(5));
        let msg = err.to_string();

        // Error message should include buffer type and index
        assert!(msg.contains("Invalid buffer reference"));
        assert!(msg.contains("Input(5)"));
    }

    #[test]
    fn test_error_invalid_buffer_index_message() {
        let err = BackendError::InvalidBufferIndex {
            kind: "input",
            index: 3,
            count: 2,
        };
        let msg = err.to_string();

        // Error message should be human-readable with context
        assert!(msg.contains("Invalid"));
        assert!(msg.contains("input"));
        assert!(msg.contains("buffer index 3"));
        assert!(msg.contains("2 buffers available"));
    }

    #[test]
    fn test_error_size_mismatch_message() {
        let err = BackendError::SizeMismatch {
            expected: 1024,
            actual: 512,
        };
        let msg = err.to_string();

        // Error should clearly show expected vs actual
        assert!(msg.contains("size mismatch"));
        assert!(msg.contains("expected 1024"));
        assert!(msg.contains("got 512"));
    }

    #[test]
    fn test_error_workspace_overflow_message() {
        let err = BackendError::WorkspaceOverflow {
            offset: 1000,
            size: 500,
            capacity: 1024,
        };
        let msg = err.to_string();

        // Error should show all relevant values
        assert!(msg.contains("Workspace overflow"));
        assert!(msg.contains("offset 1000"));
        assert!(msg.contains("size 500"));
        assert!(msg.contains("capacity 1024"));
    }

    #[test]
    fn test_error_constant_overflow_message() {
        let err = BackendError::ConstantOverflow {
            offset: 100,
            size: 200,
            capacity: 256,
        };
        let msg = err.to_string();

        // Error should show all relevant values
        assert!(msg.contains("Constant overflow"));
        assert!(msg.contains("offset 100"));
        assert!(msg.contains("size 200"));
        assert!(msg.contains("capacity 256"));
    }

    #[test]
    fn test_error_alignment_message() {
        let err = BackendError::AlignmentError {
            required: 16,
            actual: 3,
        };
        let msg = err.to_string();

        // Error should explain alignment requirements
        assert!(msg.contains("Alignment error"));
        assert!(msg.contains("16-byte alignment"));
        assert!(msg.contains("offset 3"));
    }

    #[test]
    fn test_error_unsupported_instruction_message() {
        let err = BackendError::UnsupportedInstruction("CallLayer".to_string());
        let msg = err.to_string();

        // Error should name the unsupported instruction
        assert!(msg.contains("Unsupported instruction"));
        assert!(msg.contains("CallLayer"));
    }

    #[test]
    fn test_error_instruction_message() {
        let err = BackendError::InstructionError {
            index: 42,
            operation: "MatMul".to_string(),
            message: "buffer 3 out of bounds".to_string(),
        };
        let msg = err.to_string();

        // Error should show instruction context
        assert!(msg.contains("instruction 42"));
        assert!(msg.contains("MatMul"));
        assert!(msg.contains("buffer 3 out of bounds"));
    }

    #[test]
    fn test_error_execution_message() {
        let err = BackendError::ExecutionError("division by zero".to_string());
        let msg = err.to_string();

        // Error should include the details
        assert!(msg.contains("Execution error"));
        assert!(msg.contains("division by zero"));
    }

    #[test]
    fn test_error_other_message() {
        let err = BackendError::Other("custom error context".to_string());
        let msg = err.to_string();

        // Error should pass through the message
        assert!(msg.contains("custom error context"));
    }

    #[test]
    fn test_error_layer_load_message() {
        let err = BackendError::LayerLoadError {
            layer_id: "abc123".to_string(),
            reason: "file not found".to_string(),
        };
        let msg = err.to_string();

        // Error should include layer ID and reason
        assert!(msg.contains("abc123"));
        assert!(msg.contains("file not found"));
        assert!(msg.contains("Failed to load layer"));
    }

    #[test]
    fn test_error_corrupted_layer_message() {
        let err = BackendError::CorruptedLayer {
            layer_id: "abc123def456".to_string(),
            expected: "deadbeef12345678".to_string(),
            actual: "cafebabe87654321".to_string(),
        };
        let msg = err.to_string();

        // Error should include layer ID and both hashes
        assert!(msg.contains("Corrupted layer"));
        assert!(msg.contains("abc123def456"));
        assert!(msg.contains("deadbeef12345678"));
        assert!(msg.contains("cafebabe87654321"));
    }

    #[test]
    fn test_error_not_implemented_message() {
        let err = BackendError::NotImplemented {
            feature: "CUDA plan execution".to_string(),
        };
        let msg = err.to_string();

        // Error should describe the unimplemented feature
        assert!(msg.contains("Not implemented"));
        assert!(msg.contains("CUDA plan execution"));
    }

    #[test]
    fn test_error_debug_format() {
        // All error types should have Debug format
        let errors: Vec<BackendError> = vec![
            BackendError::InvalidBuffer(BufferRef::Input(0)),
            BackendError::InvalidBufferIndex {
                kind: "output",
                index: 5,
                count: 3,
            },
            BackendError::SizeMismatch {
                expected: 100,
                actual: 50,
            },
            BackendError::WorkspaceOverflow {
                offset: 0,
                size: 100,
                capacity: 50,
            },
            BackendError::ConstantOverflow {
                offset: 0,
                size: 100,
                capacity: 50,
            },
            BackendError::AlignmentError {
                required: 8,
                actual: 1,
            },
            BackendError::UnsupportedInstruction("Test".to_string()),
            BackendError::LayerLoadError {
                layer_id: "abc".to_string(),
                reason: "test".to_string(),
            },
            BackendError::CorruptedLayer {
                layer_id: "abc".to_string(),
                expected: "deadbeef".to_string(),
                actual: "cafebabe".to_string(),
            },
            BackendError::NotImplemented {
                feature: "Test feature".to_string(),
            },
            BackendError::InstructionError {
                index: 0,
                operation: "Test".to_string(),
                message: "test".to_string(),
            },
            BackendError::ExecutionError("Test".to_string()),
            BackendError::Other("Test".to_string()),
        ];

        for err in errors {
            // Debug format should not panic
            let debug_str = format!("{err:?}");
            assert!(!debug_str.is_empty());
        }
    }

    #[test]
    fn test_error_is_std_error() {
        // BackendError should implement std::error::Error
        fn assert_error<E: std::error::Error>(_: &E) {}

        let err = BackendError::Other("test".to_string());
        assert_error(&err);
    }

    #[test]
    fn test_result_type_alias() {
        // Result<T> should work correctly
        fn returns_ok() -> Result<i32> {
            Ok(42)
        }

        fn returns_err() -> Result<i32> {
            Err(BackendError::Other("fail".to_string()))
        }

        assert!(returns_ok().is_ok());
        assert!(returns_err().is_err());
    }

    // ========================================================================
    // Help and Classification Tests (TASK-166)
    // ========================================================================

    #[test]
    fn test_error_help_text() {
        let err = BackendError::SizeMismatch {
            expected: 1024,
            actual: 512,
        };
        let help = err.help();
        assert!(help.is_some());
        assert!(help.unwrap().contains("sizes"));
    }

    #[test]
    fn test_error_help_corrupted_layer() {
        let err = BackendError::CorruptedLayer {
            layer_id: "abc".to_string(),
            expected: "deadbeef".to_string(),
            actual: "cafebabe".to_string(),
        };
        let help = err.help();
        assert!(help.is_some());
        assert!(help.unwrap().contains("cache"));
    }

    #[test]
    fn test_error_is_retryable() {
        assert!(BackendError::LayerLoadError {
            layer_id: "abc".to_string(),
            reason: "network timeout".to_string(),
        }
        .is_retryable());

        assert!(!BackendError::SizeMismatch {
            expected: 100,
            actual: 50,
        }
        .is_retryable());
    }

    #[test]
    fn test_error_is_usage_error() {
        assert!(BackendError::InvalidBuffer(BufferRef::Input(0)).is_usage_error());
        assert!(BackendError::SizeMismatch {
            expected: 100,
            actual: 50,
        }
        .is_usage_error());
        assert!(BackendError::AlignmentError {
            required: 16,
            actual: 3,
        }
        .is_usage_error());

        // Not usage errors
        assert!(!BackendError::ExecutionError("test".to_string()).is_usage_error());
        assert!(!BackendError::NotImplemented {
            feature: "test".to_string()
        }
        .is_usage_error());
    }

    #[test]
    fn test_error_help_none_for_other() {
        let err = BackendError::Other("custom error".to_string());
        assert!(err.help().is_none());
    }

    // ========================================================================
    // Boundary Condition Tests (TASK-178)
    // ========================================================================

    #[test]
    fn test_size_mismatch_zero_expected() {
        let err = BackendError::SizeMismatch {
            expected: 0,
            actual: 100,
        };
        let msg = err.to_string();
        assert!(msg.contains("expected 0"));
        assert!(msg.contains("got 100"));
    }

    #[test]
    fn test_size_mismatch_zero_actual() {
        let err = BackendError::SizeMismatch {
            expected: 100,
            actual: 0,
        };
        let msg = err.to_string();
        assert!(msg.contains("expected 100"));
        assert!(msg.contains("got 0"));
    }

    #[test]
    fn test_size_mismatch_large_values() {
        let err = BackendError::SizeMismatch {
            expected: usize::MAX,
            actual: usize::MAX - 1,
        };
        let msg = err.to_string();
        // Should not panic with large values
        assert!(msg.contains("size mismatch"));
    }

    #[test]
    fn test_workspace_overflow_zero_offset() {
        let err = BackendError::WorkspaceOverflow {
            offset: 0,
            size: 100,
            capacity: 50,
        };
        let msg = err.to_string();
        assert!(msg.contains("offset 0"));
        assert!(msg.contains("size 100"));
        assert!(msg.contains("capacity 50"));
    }

    #[test]
    fn test_workspace_overflow_zero_capacity() {
        let err = BackendError::WorkspaceOverflow {
            offset: 0,
            size: 1,
            capacity: 0,
        };
        let msg = err.to_string();
        assert!(msg.contains("capacity 0"));
    }

    #[test]
    fn test_workspace_overflow_exact_boundary() {
        // offset + size = capacity + 1 (just over)
        let err = BackendError::WorkspaceOverflow {
            offset: 100,
            size: 101,
            capacity: 200,
        };
        let msg = err.to_string();
        assert!(msg.contains("Workspace overflow"));
    }

    #[test]
    fn test_constant_overflow_zero_offset() {
        let err = BackendError::ConstantOverflow {
            offset: 0,
            size: 100,
            capacity: 50,
        };
        let msg = err.to_string();
        assert!(msg.contains("offset 0"));
    }

    #[test]
    fn test_constant_overflow_zero_capacity() {
        let err = BackendError::ConstantOverflow {
            offset: 0,
            size: 1,
            capacity: 0,
        };
        let msg = err.to_string();
        assert!(msg.contains("capacity 0"));
    }

    #[test]
    fn test_alignment_error_power_of_two() {
        // Common alignment requirements
        for alignment in [2, 4, 8, 16, 32, 64, 128, 256] {
            let err = BackendError::AlignmentError {
                required: alignment,
                actual: 1,
            };
            let msg = err.to_string();
            assert!(msg.contains(&format!("{alignment}-byte alignment")));
        }
    }

    #[test]
    fn test_invalid_buffer_index_zero_count() {
        let err = BackendError::InvalidBufferIndex {
            kind: "input",
            index: 0,
            count: 0,
        };
        let msg = err.to_string();
        assert!(msg.contains("0 buffers available"));
    }

    #[test]
    fn test_invalid_buffer_index_output() {
        let err = BackendError::InvalidBufferIndex {
            kind: "output",
            index: 10,
            count: 5,
        };
        let msg = err.to_string();
        assert!(msg.contains("output"));
        assert!(msg.contains("index 10"));
        assert!(msg.contains("5 buffers"));
    }

    #[test]
    fn test_buffer_ref_workspace_zero_size() {
        let buf = BufferRef::Workspace { offset: 0, size: 0 };
        let err = BackendError::InvalidBuffer(buf);
        let msg = err.to_string();
        assert!(msg.contains("Workspace"));
        assert!(msg.contains("size: 0"));
    }

    #[test]
    fn test_buffer_ref_constant_large_offset() {
        let buf = BufferRef::Constant {
            offset: usize::MAX,
            size: 1,
        };
        let err = BackendError::InvalidBuffer(buf);
        // Should not panic
        let msg = err.to_string();
        assert!(msg.contains("Constant"));
    }

    #[test]
    fn test_instruction_error_zero_index() {
        let err = BackendError::InstructionError {
            index: 0,
            operation: "Add".to_string(),
            message: "first instruction failed".to_string(),
        };
        let msg = err.to_string();
        assert!(msg.contains("instruction 0"));
    }

    #[test]
    fn test_instruction_error_large_index() {
        let err = BackendError::InstructionError {
            index: usize::MAX,
            operation: "Mul".to_string(),
            message: "overflow".to_string(),
        };
        // Should not panic
        let msg = err.to_string();
        assert!(msg.contains("Mul"));
    }

    #[test]
    fn test_layer_load_error_empty_id() {
        let err = BackendError::LayerLoadError {
            layer_id: String::new(),
            reason: "invalid layer".to_string(),
        };
        let msg = err.to_string();
        assert!(msg.contains("''"));
    }

    #[test]
    fn test_corrupted_layer_same_hash() {
        // Edge case: expected equals actual (shouldn't happen but test the format)
        let err = BackendError::CorruptedLayer {
            layer_id: "test".to_string(),
            expected: "same".to_string(),
            actual: "same".to_string(),
        };
        let msg = err.to_string();
        assert!(msg.contains("Corrupted layer"));
    }

    // ========================================================================
    // From trait tests (Io and Format errors)
    // ========================================================================

    #[test]
    fn test_io_error_from_std() {
        use std::io::{Error, ErrorKind};

        let io_err = Error::new(ErrorKind::NotFound, "file not found");
        let backend_err: BackendError = io_err.into();

        assert!(matches!(backend_err, BackendError::Io(_)));
        let msg = backend_err.to_string();
        assert!(msg.contains("I/O error"));
    }

    #[test]
    fn test_io_error_permission_denied() {
        use std::io::{Error, ErrorKind};

        let io_err = Error::new(ErrorKind::PermissionDenied, "access denied");
        let backend_err: BackendError = io_err.into();

        assert!(matches!(backend_err, BackendError::Io(_)));
        assert!(backend_err.is_retryable()); // IO errors are retryable
    }

    #[test]
    fn test_format_error_from_holo() {
        let holo_err = hologram_holo::HoloError::InvalidFormat {
            expected: "HOLB".to_string(),
            found: "JUNK".to_string(),
        };
        let backend_err: BackendError = holo_err.into();

        assert!(matches!(backend_err, BackendError::Format(_)));
        let msg = backend_err.to_string();
        assert!(msg.contains("Format error"));
    }

    #[test]
    fn test_format_error_checksum() {
        let holo_err = hologram_holo::HoloError::ChecksumMismatch {
            expected: 0xDEAD_BEEF,
            computed: 0xCAFE_BABE,
        };
        let backend_err: BackendError = holo_err.into();

        assert!(matches!(backend_err, BackendError::Format(_)));
    }

    // ========================================================================
    // Help text exhaustive tests
    // ========================================================================

    #[test]
    fn test_help_for_all_variants_with_help() {
        let errors_with_help: Vec<BackendError> = vec![
            BackendError::InvalidBuffer(BufferRef::Input(0)),
            BackendError::InvalidBufferIndex {
                kind: "input",
                index: 0,
                count: 0,
            },
            BackendError::SizeMismatch {
                expected: 0,
                actual: 0,
            },
            BackendError::WorkspaceOverflow {
                offset: 0,
                size: 0,
                capacity: 0,
            },
            BackendError::ConstantOverflow {
                offset: 0,
                size: 0,
                capacity: 0,
            },
            BackendError::AlignmentError {
                required: 0,
                actual: 0,
            },
            BackendError::UnsupportedInstruction(String::new()),
            BackendError::LayerLoadError {
                layer_id: String::new(),
                reason: String::new(),
            },
            BackendError::CorruptedLayer {
                layer_id: String::new(),
                expected: String::new(),
                actual: String::new(),
            },
            BackendError::NotImplemented {
                feature: String::new(),
            },
            BackendError::InstructionError {
                index: 0,
                operation: String::new(),
                message: String::new(),
            },
        ];

        for err in errors_with_help {
            assert!(err.help().is_some(), "Expected help for error: {err:?}");
        }
    }

    #[test]
    fn test_help_for_variants_without_help() {
        let errors_without_help: Vec<BackendError> = vec![
            BackendError::ExecutionError(String::new()),
            BackendError::Other(String::new()),
        ];

        for err in errors_without_help {
            assert!(err.help().is_none(), "Expected no help for error: {err:?}");
        }
    }

    // ========================================================================
    // Error classification exhaustive tests
    // ========================================================================

    #[test]
    fn test_is_retryable_exhaustive() {
        // Retryable errors
        assert!(BackendError::LayerLoadError {
            layer_id: String::new(),
            reason: String::new()
        }
        .is_retryable());

        // IO errors are retryable
        let io_err = std::io::Error::new(std::io::ErrorKind::TimedOut, "timeout");
        assert!(BackendError::Io(io_err).is_retryable());

        // Non-retryable errors
        let non_retryable = vec![
            BackendError::InvalidBuffer(BufferRef::Input(0)),
            BackendError::SizeMismatch {
                expected: 0,
                actual: 0,
            },
            BackendError::WorkspaceOverflow {
                offset: 0,
                size: 0,
                capacity: 0,
            },
            BackendError::ConstantOverflow {
                offset: 0,
                size: 0,
                capacity: 0,
            },
            BackendError::AlignmentError {
                required: 0,
                actual: 0,
            },
            BackendError::UnsupportedInstruction(String::new()),
            BackendError::CorruptedLayer {
                layer_id: String::new(),
                expected: String::new(),
                actual: String::new(),
            },
            BackendError::NotImplemented {
                feature: String::new(),
            },
            BackendError::InstructionError {
                index: 0,
                operation: String::new(),
                message: String::new(),
            },
            BackendError::ExecutionError(String::new()),
            BackendError::Other(String::new()),
        ];

        for err in non_retryable {
            assert!(!err.is_retryable(), "Expected non-retryable: {err:?}");
        }
    }

    #[test]
    fn test_is_usage_error_exhaustive() {
        // Usage errors
        let usage_errors = vec![
            BackendError::InvalidBuffer(BufferRef::Input(0)),
            BackendError::InvalidBufferIndex {
                kind: "input",
                index: 0,
                count: 0,
            },
            BackendError::SizeMismatch {
                expected: 0,
                actual: 0,
            },
            BackendError::AlignmentError {
                required: 0,
                actual: 0,
            },
        ];

        for err in usage_errors {
            assert!(err.is_usage_error(), "Expected usage error: {err:?}");
        }

        // Non-usage errors
        let non_usage = vec![
            BackendError::WorkspaceOverflow {
                offset: 0,
                size: 0,
                capacity: 0,
            },
            BackendError::ConstantOverflow {
                offset: 0,
                size: 0,
                capacity: 0,
            },
            BackendError::UnsupportedInstruction(String::new()),
            BackendError::LayerLoadError {
                layer_id: String::new(),
                reason: String::new(),
            },
            BackendError::CorruptedLayer {
                layer_id: String::new(),
                expected: String::new(),
                actual: String::new(),
            },
            BackendError::NotImplemented {
                feature: String::new(),
            },
            BackendError::InstructionError {
                index: 0,
                operation: String::new(),
                message: String::new(),
            },
            BackendError::ExecutionError(String::new()),
            BackendError::Other(String::new()),
        ];

        for err in non_usage {
            assert!(!err.is_usage_error(), "Expected non-usage error: {err:?}");
        }
    }

    // ========================================================================
    // BufferRef Validation Tests (TASK-182)
    // ========================================================================

    #[test]
    fn test_buffer_ref_validate_input_valid() {
        let buf = BufferRef::Input(0);
        assert!(buf.validate(3, 2, 1024, 512).is_ok());

        let buf = BufferRef::Input(2);
        assert!(buf.validate(3, 2, 1024, 512).is_ok());
    }

    #[test]
    fn test_buffer_ref_validate_input_invalid_index() {
        let buf = BufferRef::Input(3);
        let result = buf.validate(3, 2, 1024, 512);
        assert!(result.is_err());

        let err = result.unwrap_err();
        assert!(matches!(
            err,
            BackendError::InvalidBufferIndex {
                kind: "input",
                index: 3,
                count: 3,
            }
        ));
    }

    #[test]
    fn test_buffer_ref_validate_input_zero_count() {
        let buf = BufferRef::Input(0);
        let result = buf.validate(0, 1, 1024, 512);
        assert!(result.is_err());

        let err = result.unwrap_err();
        assert!(matches!(
            err,
            BackendError::InvalidBufferIndex {
                kind: "input",
                index: 0,
                count: 0,
            }
        ));
    }

    #[test]
    fn test_buffer_ref_validate_output_valid() {
        let buf = BufferRef::Output(0);
        assert!(buf.validate(1, 3, 1024, 512).is_ok());

        let buf = BufferRef::Output(2);
        assert!(buf.validate(1, 3, 1024, 512).is_ok());
    }

    #[test]
    fn test_buffer_ref_validate_output_invalid_index() {
        let buf = BufferRef::Output(5);
        let result = buf.validate(2, 3, 1024, 512);
        assert!(result.is_err());

        let err = result.unwrap_err();
        assert!(matches!(
            err,
            BackendError::InvalidBufferIndex {
                kind: "output",
                index: 5,
                count: 3,
            }
        ));
    }

    #[test]
    fn test_buffer_ref_validate_output_zero_count() {
        let buf = BufferRef::Output(0);
        let result = buf.validate(1, 0, 1024, 512);
        assert!(result.is_err());
    }

    #[test]
    fn test_buffer_ref_validate_workspace_valid() {
        let buf = BufferRef::Workspace {
            offset: 0,
            size: 100,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_ok());

        // Exact boundary
        let buf = BufferRef::Workspace {
            offset: 924,
            size: 100,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_ok());
    }

    #[test]
    fn test_buffer_ref_validate_workspace_overflow() {
        let buf = BufferRef::Workspace {
            offset: 1000,
            size: 100,
        };
        let result = buf.validate(1, 1, 1024, 512);
        assert!(result.is_err());

        let err = result.unwrap_err();
        assert!(matches!(
            err,
            BackendError::WorkspaceOverflow {
                offset: 1000,
                size: 100,
                capacity: 1024,
            }
        ));
    }

    #[test]
    fn test_buffer_ref_validate_workspace_just_over_boundary() {
        let buf = BufferRef::Workspace {
            offset: 925,
            size: 100,
        };
        let result = buf.validate(1, 1, 1024, 512);
        assert!(result.is_err());

        let err = result.unwrap_err();
        assert!(matches!(err, BackendError::WorkspaceOverflow { .. }));
    }

    #[test]
    fn test_buffer_ref_validate_workspace_arithmetic_overflow() {
        let buf = BufferRef::Workspace {
            offset: usize::MAX,
            size: 1,
        };
        let result = buf.validate(1, 1, 1024, 512);
        assert!(result.is_err());

        let err = result.unwrap_err();
        assert!(matches!(err, BackendError::WorkspaceOverflow { .. }));
    }

    #[test]
    fn test_buffer_ref_validate_workspace_large_offset_large_size() {
        let buf = BufferRef::Workspace {
            offset: usize::MAX / 2,
            size: usize::MAX / 2 + 2,
        };
        let result = buf.validate(1, 1, usize::MAX, 512);
        assert!(result.is_err());
    }

    #[test]
    fn test_buffer_ref_validate_workspace_zero_capacity() {
        let buf = BufferRef::Workspace { offset: 0, size: 1 };
        let result = buf.validate(1, 1, 0, 512);
        assert!(result.is_err());

        let err = result.unwrap_err();
        assert!(matches!(
            err,
            BackendError::WorkspaceOverflow { capacity: 0, .. }
        ));
    }

    #[test]
    fn test_buffer_ref_validate_workspace_zero_size_valid() {
        // Zero-size workspace at any valid offset should be OK
        let buf = BufferRef::Workspace { offset: 0, size: 0 };
        assert!(buf.validate(1, 1, 1024, 512).is_ok());

        let buf = BufferRef::Workspace {
            offset: 1024,
            size: 0,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_ok());
    }

    #[test]
    fn test_buffer_ref_validate_constant_valid() {
        let buf = BufferRef::Constant {
            offset: 0,
            size: 100,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_ok());

        // Exact boundary
        let buf = BufferRef::Constant {
            offset: 412,
            size: 100,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_ok());
    }

    #[test]
    fn test_buffer_ref_validate_constant_overflow() {
        let buf = BufferRef::Constant {
            offset: 500,
            size: 100,
        };
        let result = buf.validate(1, 1, 1024, 512);
        assert!(result.is_err());

        let err = result.unwrap_err();
        assert!(matches!(
            err,
            BackendError::ConstantOverflow {
                offset: 500,
                size: 100,
                capacity: 512,
            }
        ));
    }

    #[test]
    fn test_buffer_ref_validate_constant_just_over_boundary() {
        let buf = BufferRef::Constant {
            offset: 413,
            size: 100,
        };
        let result = buf.validate(1, 1, 1024, 512);
        assert!(result.is_err());
    }

    #[test]
    fn test_buffer_ref_validate_constant_arithmetic_overflow() {
        let buf = BufferRef::Constant {
            offset: usize::MAX,
            size: 1,
        };
        let result = buf.validate(1, 1, 1024, 512);
        assert!(result.is_err());

        let err = result.unwrap_err();
        assert!(matches!(err, BackendError::ConstantOverflow { .. }));
    }

    #[test]
    fn test_buffer_ref_validate_constant_zero_capacity() {
        let buf = BufferRef::Constant { offset: 0, size: 1 };
        let result = buf.validate(1, 1, 1024, 0);
        assert!(result.is_err());

        let err = result.unwrap_err();
        assert!(matches!(
            err,
            BackendError::ConstantOverflow { capacity: 0, .. }
        ));
    }

    #[test]
    fn test_buffer_ref_validate_constant_zero_size_valid() {
        let buf = BufferRef::Constant { offset: 0, size: 0 };
        assert!(buf.validate(1, 1, 1024, 512).is_ok());
    }

    // ========================================================================
    // BufferRef Helper Method Tests (TASK-182)
    // ========================================================================

    #[test]
    fn test_buffer_ref_is_input() {
        assert!(BufferRef::Input(0).is_input());
        assert!(!BufferRef::Output(0).is_input());
        assert!(!BufferRef::Workspace { offset: 0, size: 0 }.is_input());
        assert!(!BufferRef::Constant { offset: 0, size: 0 }.is_input());
    }

    #[test]
    fn test_buffer_ref_is_output() {
        assert!(!BufferRef::Input(0).is_output());
        assert!(BufferRef::Output(0).is_output());
        assert!(!BufferRef::Workspace { offset: 0, size: 0 }.is_output());
        assert!(!BufferRef::Constant { offset: 0, size: 0 }.is_output());
    }

    #[test]
    fn test_buffer_ref_is_workspace() {
        assert!(!BufferRef::Input(0).is_workspace());
        assert!(!BufferRef::Output(0).is_workspace());
        assert!(BufferRef::Workspace { offset: 0, size: 0 }.is_workspace());
        assert!(!BufferRef::Constant { offset: 0, size: 0 }.is_workspace());
    }

    #[test]
    fn test_buffer_ref_is_constant() {
        assert!(!BufferRef::Input(0).is_constant());
        assert!(!BufferRef::Output(0).is_constant());
        assert!(!BufferRef::Workspace { offset: 0, size: 0 }.is_constant());
        assert!(BufferRef::Constant { offset: 0, size: 0 }.is_constant());
    }

    #[test]
    fn test_buffer_ref_size() {
        assert_eq!(BufferRef::Input(0).size(), None);
        assert_eq!(BufferRef::Output(0).size(), None);
        assert_eq!(
            BufferRef::Workspace {
                offset: 0,
                size: 100
            }
            .size(),
            Some(100)
        );
        assert_eq!(
            BufferRef::Constant {
                offset: 0,
                size: 200
            }
            .size(),
            Some(200)
        );
    }

    #[test]
    fn test_buffer_ref_offset() {
        assert_eq!(BufferRef::Input(0).offset(), None);
        assert_eq!(BufferRef::Output(0).offset(), None);
        assert_eq!(
            BufferRef::Workspace {
                offset: 50,
                size: 100
            }
            .offset(),
            Some(50)
        );
        assert_eq!(
            BufferRef::Constant {
                offset: 75,
                size: 200
            }
            .offset(),
            Some(75)
        );
    }

    #[test]
    fn test_buffer_ref_index() {
        assert_eq!(BufferRef::Input(5).index(), Some(5));
        assert_eq!(BufferRef::Output(10).index(), Some(10));
        assert_eq!(BufferRef::Workspace { offset: 0, size: 0 }.index(), None);
        assert_eq!(BufferRef::Constant { offset: 0, size: 0 }.index(), None);
    }

    // ========================================================================
    // BufferValidationContext Tests (TASK-182)
    // ========================================================================

    #[test]
    fn test_validation_context_new() {
        let ctx = BufferValidationContext::new(2, 3, 1024, 512);
        assert_eq!(ctx.input_count, 2);
        assert_eq!(ctx.output_count, 3);
        assert_eq!(ctx.workspace_capacity, 1024);
        assert_eq!(ctx.constant_capacity, 512);
    }

    #[test]
    fn test_validation_context_default() {
        let ctx = BufferValidationContext::default();
        assert_eq!(ctx.input_count, 0);
        assert_eq!(ctx.output_count, 0);
        assert_eq!(ctx.workspace_capacity, 0);
        assert_eq!(ctx.constant_capacity, 0);
    }

    #[test]
    fn test_validation_context_validate_valid() {
        let ctx = BufferValidationContext::new(2, 2, 1024, 512);

        assert!(ctx.validate(&BufferRef::Input(0)).is_ok());
        assert!(ctx.validate(&BufferRef::Input(1)).is_ok());
        assert!(ctx.validate(&BufferRef::Output(0)).is_ok());
        assert!(ctx.validate(&BufferRef::Output(1)).is_ok());
        assert!(ctx
            .validate(&BufferRef::Workspace {
                offset: 0,
                size: 1024
            })
            .is_ok());
        assert!(ctx
            .validate(&BufferRef::Constant {
                offset: 0,
                size: 512
            })
            .is_ok());
    }

    #[test]
    fn test_validation_context_validate_invalid() {
        let ctx = BufferValidationContext::new(2, 2, 1024, 512);

        assert!(ctx.validate(&BufferRef::Input(2)).is_err());
        assert!(ctx.validate(&BufferRef::Output(5)).is_err());
        assert!(ctx
            .validate(&BufferRef::Workspace {
                offset: 0,
                size: 2048
            })
            .is_err());
        assert!(ctx
            .validate(&BufferRef::Constant {
                offset: 500,
                size: 100
            })
            .is_err());
    }

    #[test]
    fn test_validation_context_validate_all_valid() {
        let ctx = BufferValidationContext::new(2, 2, 1024, 512);
        let bufs = vec![
            BufferRef::Input(0),
            BufferRef::Output(1),
            BufferRef::Workspace {
                offset: 0,
                size: 100,
            },
        ];

        assert!(ctx.validate_all(&bufs).is_ok());
    }

    #[test]
    fn test_validation_context_validate_all_fails_on_first_invalid() {
        let ctx = BufferValidationContext::new(1, 1, 1024, 512);
        let bufs = vec![
            BufferRef::Input(0),  // Valid
            BufferRef::Input(5),  // Invalid - should fail here
            BufferRef::Output(0), // Would be valid but not reached
        ];

        let result = ctx.validate_all(&bufs);
        assert!(result.is_err());

        let err = result.unwrap_err();
        assert!(matches!(
            err,
            BackendError::InvalidBufferIndex {
                kind: "input",
                index: 5,
                ..
            }
        ));
    }

    #[test]
    fn test_validation_context_validate_all_empty() {
        let ctx = BufferValidationContext::new(0, 0, 0, 0);
        assert!(ctx.validate_all(&[]).is_ok());
    }

    #[test]
    fn test_validation_context_clone() {
        let ctx = BufferValidationContext::new(2, 3, 1024, 512);
        let ctx2 = ctx;

        assert_eq!(ctx.input_count, ctx2.input_count);
        assert_eq!(ctx.output_count, ctx2.output_count);
        assert_eq!(ctx.workspace_capacity, ctx2.workspace_capacity);
        assert_eq!(ctx.constant_capacity, ctx2.constant_capacity);
    }

    // ========================================================================
    // Error Message Quality for Validation (TASK-182)
    // ========================================================================

    #[test]
    fn test_validation_error_message_input() {
        let buf = BufferRef::Input(10);
        let err = buf.validate(3, 2, 1024, 512).unwrap_err();
        let msg = err.to_string();

        assert!(msg.contains("input"));
        assert!(msg.contains('1'));
        assert!(msg.contains('3'));
    }

    #[test]
    fn test_validation_error_message_output() {
        let buf = BufferRef::Output(7);
        let err = buf.validate(2, 4, 1024, 512).unwrap_err();
        let msg = err.to_string();

        assert!(msg.contains("output"));
        assert!(msg.contains('7'));
        assert!(msg.contains('4'));
    }

    #[test]
    fn test_validation_error_message_workspace() {
        let buf = BufferRef::Workspace {
            offset: 800,
            size: 300,
        };
        let err = buf.validate(1, 1, 1024, 512).unwrap_err();
        let msg = err.to_string();

        assert!(msg.contains("Workspace overflow"));
        assert!(msg.contains("800"));
        assert!(msg.contains("300"));
        assert!(msg.contains("1024"));
    }

    #[test]
    fn test_validation_error_message_constant() {
        let buf = BufferRef::Constant {
            offset: 400,
            size: 200,
        };
        let err = buf.validate(1, 1, 1024, 512).unwrap_err();
        let msg = err.to_string();

        assert!(msg.contains("Constant overflow"));
        assert!(msg.contains("400"));
        assert!(msg.contains("200"));
        assert!(msg.contains("512"));
    }

    // ========================================================================
    // Edge Cases and Boundary Tests (TASK-182)
    // ========================================================================

    #[test]
    fn test_validation_max_valid_input_index() {
        let buf = BufferRef::Input(u32::MAX - 1);
        assert!(buf.validate(u32::MAX as usize, 1, 1024, 512).is_ok());
    }

    #[test]
    fn test_validation_max_valid_output_index() {
        let buf = BufferRef::Output(u32::MAX - 1);
        assert!(buf.validate(1, u32::MAX as usize, 1024, 512).is_ok());
    }

    #[test]
    fn test_validation_workspace_exact_fit() {
        let buf = BufferRef::Workspace {
            offset: 0,
            size: 1024,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_ok());
    }

    #[test]
    fn test_validation_workspace_one_byte_over() {
        let buf = BufferRef::Workspace {
            offset: 0,
            size: 1025,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_err());
    }

    #[test]
    fn test_validation_constant_exact_fit() {
        let buf = BufferRef::Constant {
            offset: 0,
            size: 512,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_ok());
    }

    #[test]
    fn test_validation_constant_one_byte_over() {
        let buf = BufferRef::Constant {
            offset: 0,
            size: 513,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_err());
    }

    #[test]
    fn test_validation_workspace_offset_at_end() {
        // offset = capacity, size = 0 should be valid
        let buf = BufferRef::Workspace {
            offset: 1024,
            size: 0,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_ok());
    }

    #[test]
    fn test_validation_constant_offset_at_end() {
        let buf = BufferRef::Constant {
            offset: 512,
            size: 0,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_ok());
    }

    #[test]
    fn test_validation_workspace_offset_past_end() {
        // offset > capacity, size > 0 should fail
        let buf = BufferRef::Workspace {
            offset: 2000,
            size: 1,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_err());
    }

    #[test]
    fn test_validation_constant_offset_past_end() {
        let buf = BufferRef::Constant {
            offset: 1000,
            size: 1,
        };
        assert!(buf.validate(1, 1, 1024, 512).is_err());
    }
}
