/**
 * Example C program using UOR C bindings
 *
 * Build:
 *   just ffi-c
 *   gcc -o example examples/c/example.c -I bindings/c -L target/release -luor_ffi -Wl,-rpath,target/release
 *
 * Run:
 *   ./example
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "uor.h"

#define ASSERT_EQ(actual, expected, msg) \
    do { \
        if ((actual) != (expected)) { \
            fprintf(stderr, "ASSERTION FAILED: %s (expected %u, got %u)\n", msg, (unsigned)(expected), (unsigned)(actual)); \
            return 1; \
        } \
    } while (0)

#define ASSERT_TRUE(cond, msg) \
    do { \
        if (!(cond)) { \
            fprintf(stderr, "ASSERTION FAILED: %s\n", msg); \
            return 1; \
        } \
    } while (0)

int main() {
    printf("=== UOR C Bindings Example ===\n\n");

    // Test constants
    printf("Constants:\n");
    uint32_t braille_base = uor_braille_base();
    printf("  Braille Base: U+%04X\n", braille_base);
    ASSERT_EQ(braille_base, 0x2800, "braille_base should be 0x2800");

    uint32_t braille_max = uor_braille_max();
    printf("  Braille Max:  U+%04X\n", braille_max);
    ASSERT_EQ(braille_max, 0x28FF, "braille_max should be 0x28FF");

    uint32_t triadic = uor_triadic_constant();
    printf("  Triadic (T):  %u\n", triadic);
    ASSERT_EQ(triadic, 3, "triadic constant should be 3");

    uint32_t octave = uor_octave_constant();
    printf("  Octave (O):   %u\n", octave);
    ASSERT_EQ(octave, 8, "octave constant should be 8");

    uint32_t state_taxons = uor_state_taxons();
    printf("  State Taxons: %u\n", state_taxons);
    ASSERT_EQ(state_taxons, 624, "state_taxons should be 624");

    uint32_t state_bits = uor_state_bits();
    printf("  State Bits:   %u\n\n", state_bits);
    ASSERT_EQ(state_bits, 4992, "state_bits should be 4992");

    // Test taxon operations
    printf("Taxon Operations:\n");
    unsigned char test_byte = 42;

    char* braille = uor_byte_to_braille(test_byte);
    printf("  Byte %u -> Braille: %s\n", test_byte, braille);
    ASSERT_TRUE(braille != NULL, "braille string should not be NULL");
    ASSERT_TRUE(strlen(braille) > 0, "braille string should not be empty");
    uor_string_free(braille);

    uint32_t codepoint = uor_byte_to_codepoint(test_byte);
    printf("  Byte %u -> Codepoint: U+%04X\n", test_byte, codepoint);
    ASSERT_TRUE(codepoint >= 0x2800 && codepoint <= 0x28FF, "codepoint should be in Braille range");
    ASSERT_EQ(codepoint, 0x2800 + test_byte, "codepoint should be base + byte");

    unsigned char domain = uor_byte_to_domain(test_byte);
    printf("  Byte %u -> Domain: %u\n", test_byte, domain);
    ASSERT_TRUE(domain <= 2, "domain should be 0, 1, or 2");

    unsigned char rank = uor_byte_rank(test_byte);
    printf("  Byte %u -> Rank: %u\n\n", test_byte, rank);
    ASSERT_TRUE(rank < 96, "rank should be less than 96");

    // Test ring operations
    printf("Ring Operations:\n");
    unsigned char succ = uor_byte_succ(test_byte);
    printf("  Byte %u -> Successor: %u\n", test_byte, succ);
    ASSERT_EQ(succ, 43, "succ(42) should be 43");

    unsigned char pred = uor_byte_pred(test_byte);
    printf("  Byte %u -> Predecessor: %u\n", test_byte, pred);
    ASSERT_EQ(pred, 41, "pred(42) should be 41");

    unsigned char neg = uor_byte_not(test_byte);
    printf("  Byte %u -> NOT: %u\n\n", test_byte, neg);
    ASSERT_TRUE(neg <= 255, "NOT result should be a valid byte");

    // Test view operations
    printf("View Operations:\n");

    // Create identity view
    struct UorView* identity = uor_view_identity();
    printf("  Created identity view\n");
    ASSERT_TRUE(identity != NULL, "identity view should not be NULL");

    // Apply to single byte
    unsigned char result = uor_view_apply(identity, test_byte);
    printf("  Identity(%u) = %u\n", test_byte, result);
    ASSERT_EQ(result, test_byte, "identity should preserve value");

    // Check if bijective
    bool is_bij = uor_view_is_bijective(identity);
    ASSERT_TRUE(is_bij, "identity view should be bijective");

    // Create constant view
    struct UorView* constant = uor_view_constant(99);
    ASSERT_TRUE(constant != NULL, "constant view should not be NULL");

    result = uor_view_apply(constant, test_byte);
    printf("  Constant(%u) = %u\n", test_byte, result);
    ASSERT_EQ(result, 99, "constant(99) should always return 99");

    // Check if bijective
    is_bij = uor_view_is_bijective(constant);
    printf("  Constant view is bijective: %s\n", is_bij ? "true" : "false");

    // Test view composition
    struct UorView* composed = uor_view_then(identity, identity);
    ASSERT_TRUE(composed != NULL, "composed view should not be NULL");

    result = uor_view_apply(composed, test_byte);
    printf("  Identity.then(Identity)(%u) = %u\n", test_byte, result);
    ASSERT_EQ(result, test_byte, "identity.then(identity) should preserve value");

    // Test view on array
    printf("\n  Applying identity view to array...\n");
    unsigned char input[8] = {0, 1, 2, 3, 4, 5, 6, 7};
    unsigned char output[8];

    uor_view_apply_slice(identity, input, 8, output);
    printf("  Input:  [");
    for (int i = 0; i < 8; i++) {
        printf("%u%s", input[i], i < 7 ? ", " : "");
    }
    printf("]\n  Output: [");
    for (int i = 0; i < 8; i++) {
        printf("%u%s", output[i], i < 7 ? ", " : "");
    }
    printf("]\n");

    // Verify array results
    for (int i = 0; i < 8; i++) {
        ASSERT_EQ(output[i], input[i], "identity should preserve array values");
    }

    // Clean up
    uor_view_free(identity);
    uor_view_free(constant);
    uor_view_free(composed);

    printf("\n=== All tests passed! ===\n");
    return 0;
}
