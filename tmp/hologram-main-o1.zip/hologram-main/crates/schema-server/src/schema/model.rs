//! Data models for schema entities.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Schema metadata for listing.
#[derive(Debug, Clone, Serialize)]
pub struct SchemaInfo {
    pub id: String,
    pub name: String,
    pub description: String,
    pub entity_count: usize,
}

/// Generic schema entity from JSON-LD.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SchemaEntity {
    #[serde(rename = "@id")]
    pub id: String,

    #[serde(rename = "@type")]
    pub entity_type: String,

    #[serde(flatten)]
    pub properties: HashMap<String, serde_json::Value>,
}

/// Taxon data transfer object.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaxonDto {
    pub value: u8,
    pub codepoint: u32,
    pub braille: String,
    pub domain: String,
    pub rank: u8,
    pub iri: String,
}

/// Domain data transfer object.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DomainDto {
    pub id: String,
    pub name: String,
    pub symbol: String,
    pub residue: u8,
    pub cardinality: u32,
    pub description: String,
}

/// Constant with derivation info.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Constant {
    pub name: String,
    pub symbol: String,
    pub value: i64,
    pub formula: Option<String>,
    pub derived_from: Vec<String>,
    pub description: String,
    pub is_mutable: bool,
}

/// Gauge tower level.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GaugeLevel {
    pub index: usize,
    pub modulus: u64,
    pub boundary: u64,
    pub primes: Vec<u32>,
    pub label: String,
}

/// Gauge tower structure.
#[derive(Debug, Clone, Serialize)]
pub struct GaugeTower {
    pub levels: Vec<GaugeLevel>,
    pub description: String,
}

/// Mutation request body.
#[derive(Debug, Clone, Deserialize)]
pub struct MutationRequest {
    pub value: i64,
}

/// Mutation preview showing cascade effects.
#[derive(Debug, Clone, Serialize)]
pub struct MutationPreview {
    pub target: String,
    pub old_value: i64,
    pub new_value: i64,
    pub cascade: Vec<CascadeEffect>,
}

/// Effect of a mutation on a derived constant.
#[derive(Debug, Clone, Serialize)]
pub struct CascadeEffect {
    pub constant: String,
    pub old_value: i64,
    pub new_value: i64,
}

/// Catalog constants from taxon-catalog.json.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CatalogConstants {
    #[serde(rename = "T")]
    pub t: i64,
    #[serde(rename = "O")]
    pub o: i64,
    #[serde(rename = "BYTE_CARDINALITY")]
    pub byte_cardinality: i64,
    #[serde(rename = "BRAILLE_BASE")]
    pub braille_base: i64,
    #[serde(rename = "BRAILLE_MAX")]
    pub braille_max: i64,
    #[serde(rename = "DOMAIN_CARDINALITIES")]
    pub domain_cardinalities: Vec<i64>,
}

/// Raw taxon from JSON.
#[derive(Debug, Clone, Deserialize)]
pub struct RawTaxon {
    #[serde(rename = "@id")]
    pub id: String,
    #[serde(rename = "@type")]
    pub entity_type: String,
    pub value: u8,
    pub codepoint: u32,
    pub braille: String,
    pub domain: String,
    pub rank: u8,
}

/// Raw domain from JSON.
#[derive(Debug, Clone, Deserialize)]
pub struct RawDomain {
    #[serde(rename = "@id")]
    pub id: String,
    #[serde(rename = "@type")]
    pub entity_type: String,
    pub residue: u8,
    pub symbol: String,
    pub name: String,
    pub cardinality: u32,
    pub description: String,
}

/// Taxon catalog structure.
#[derive(Debug, Clone, Deserialize)]
pub struct TaxonCatalog {
    #[serde(rename = "@context")]
    pub context: String,
    #[serde(rename = "@id")]
    pub id: String,
    #[serde(rename = "@type")]
    pub catalog_type: String,
    pub description: String,
    pub constants: CatalogConstants,
    pub domains: Vec<RawDomain>,
    #[serde(rename = "@graph")]
    pub graph: Vec<RawTaxon>,
}

/// API response for list endpoints with pagination.
#[derive(Debug, Clone, Serialize)]
pub struct ListResponse<T> {
    pub items: Vec<T>,
    pub total: usize,
    pub offset: usize,
    pub limit: usize,
}

impl<T> ListResponse<T> {
    pub fn new(items: Vec<T>, total: usize, offset: usize, limit: usize) -> Self {
        Self {
            items,
            total,
            offset,
            limit,
        }
    }
}
