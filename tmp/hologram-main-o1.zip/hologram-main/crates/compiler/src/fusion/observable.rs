//! Observable-based fusion pass.
//!
//! Fuses contiguous chains of categorical coordinate operations
//! (`Lift`, `OrbitClassify`) and annotates the surviving node.

use crate::graph::{CompileGraph, OpKind};

/// Observable annotation for a computation chain.
#[derive(Debug, Clone, Default)]
pub struct ObservableAnnotation {
    /// Expected stratum change for the chain.
    pub stratum_delta: i32,
    /// Maximum curvature estimate for the chain.
    pub max_curvature: u8,
    /// Number of categorical operations in the chain.
    pub categorical_op_count: usize,
    /// Whether the chain is pure (no side effects).
    pub is_pure: bool,
}

/// Apply observable-based fusion to categorical operation chains.
pub fn observable_fusion(graph: &mut CompileGraph) {
    let chains = find_categorical_chains(graph);
    for chain in chains {
        if chain.len() < 2 || !chain_valid(graph, &chain) {
            continue;
        }
        let annotation = compute_chain_annotation(graph, &chain);
        if annotation.is_pure {
            fuse_categorical_chain(graph, &chain, &annotation);
        }
    }
}

fn is_categorical(op: &OpKind) -> bool {
    matches!(op, OpKind::Lift | OpKind::OrbitClassify)
}

fn are_compatible(op1: &OpKind, op2: &OpKind) -> bool {
    is_categorical(op1) && is_categorical(op2)
}

fn find_categorical_chains(graph: &CompileGraph) -> Vec<Vec<u32>> {
    let mut chains = Vec::new();
    let mut visited = std::collections::HashSet::new();

    for (id, node) in graph.nodes() {
        if !is_categorical(&node.op) || visited.contains(&id) {
            continue;
        }

        let preds = graph.predecessors(id);
        let is_chain_start = preds
            .iter()
            .any(|&p| graph.get_node(p).is_none_or(|n| !is_categorical(&n.op)))
            || preds.is_empty();
        if !is_chain_start {
            continue;
        }

        let mut chain = vec![id];
        let mut current = id;
        visited.insert(id);

        loop {
            let succs = graph.successors(current);
            if succs.len() != 1 {
                break;
            }
            let next = succs[0];
            let Some(next_node) = graph.get_node(next) else {
                break;
            };
            if !are_compatible(
                &graph.get_node(current).expect("node exists").op,
                &next_node.op,
            ) {
                break;
            }
            let next_preds = graph.predecessors(next);
            if next_preds.len() != 1 || next_preds[0] != current {
                break;
            }
            chain.push(next);
            visited.insert(next);
            current = next;
        }

        if chain.len() >= 2 {
            chains.push(chain);
        }
    }

    chains.sort_by_key(|c| std::cmp::Reverse(c.len()));
    chains
}

fn chain_valid(graph: &CompileGraph, chain: &[u32]) -> bool {
    chain.iter().all(|&id| graph.get_node(id).is_some())
}

fn compute_chain_annotation(graph: &CompileGraph, chain: &[u32]) -> ObservableAnnotation {
    let mut annotation = ObservableAnnotation {
        max_curvature: 1,
        is_pure: true,
        ..ObservableAnnotation::default()
    };

    for &id in chain {
        if let Some(node) = graph.get_node(id) {
            match node.op {
                OpKind::Lift => annotation.categorical_op_count += 1,
                OpKind::OrbitClassify => {
                    annotation.categorical_op_count += 1;
                    annotation.stratum_delta -= 3;
                }
                _ => annotation.is_pure = false,
            }
        }
    }

    annotation
}

fn fuse_categorical_chain(
    graph: &mut CompileGraph,
    chain: &[u32],
    annotation: &ObservableAnnotation,
) {
    if chain.len() < 2 {
        return;
    }

    let first = chain[0];
    let last = *chain.last().unwrap_or(&first);

    let chain_ops: Vec<_> = chain
        .iter()
        .filter_map(|&id| graph.get_node(id).map(|n| format!("{:?}", n.op)))
        .collect();

    let fusion_name = format!(
        "categorical_fused:{} [ops={}, max_curv={}, stratum_delta={}]",
        chain_ops.join("->"),
        annotation.categorical_op_count,
        annotation.max_curvature,
        annotation.stratum_delta
    );

    if let Some(node) = graph.get_node_mut(last) {
        node.name = Some(fusion_name);
    }

    let first_preds = graph.predecessors(first);
    let second_to_last = chain[chain.len() - 2];
    for &pred in &first_preds {
        graph.replace_predecessor(last, second_to_last, pred);
    }

    for &id in &chain[..chain.len() - 1] {
        graph.remove_node(id);
    }
}

/// Estimate the variation cost of a chain.
#[must_use]
pub fn estimate_variation_cost(chain_ops: &[OpKind]) -> u64 {
    chain_ops
        .iter()
        .map(|op| match op {
            OpKind::Lift | OpKind::OrbitClassify => 1,
            _ => 10,
        })
        .sum()
}

/// Check if a chain can be verified via observables.
#[must_use]
pub fn is_verifiable_chain(ops: &[OpKind]) -> bool {
    ops.iter()
        .all(|op| matches!(op, OpKind::Lift | OpKind::OrbitClassify))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{CompileGraph, DType, OpNode, OperationGraph};

    #[test]
    fn verifiable_only_categorical() {
        assert!(is_verifiable_chain(&[OpKind::Lift, OpKind::OrbitClassify]));
        assert!(!is_verifiable_chain(&[OpKind::Lift, OpKind::Add]));
    }

    #[test]
    fn variation_cost_prefers_categorical() {
        let low = estimate_variation_cost(&[OpKind::Lift, OpKind::OrbitClassify]);
        let high = estimate_variation_cost(&[OpKind::Lift, OpKind::Add]);
        assert!(low < high);
    }

    #[test]
    fn fuses_simple_chain() {
        let mut op = OperationGraph::new();
        op.add_node(OpNode::new(0, OpKind::Input, vec![256], DType::U8));
        op.add_node(OpNode::new(1, OpKind::Lift, vec![256], DType::U8));
        op.add_node(OpNode::new(2, OpKind::OrbitClassify, vec![256], DType::U8));
        op.add_node(OpNode::new(3, OpKind::Output, vec![256], DType::U8));
        op.add_edge(0, 1);
        op.add_edge(1, 2);
        op.add_edge(2, 3);

        let mut g = CompileGraph::from_operation_graph(&op).expect("compile graph");
        observable_fusion(&mut g);

        assert!(g.get_node(1).is_none());
        assert!(g.get_node(2).is_some());
    }
}
