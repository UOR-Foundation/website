#!/usr/bin/env python3
"""
Python FFI Benchmarks (ctypes-based, target: <100ns/call)

Measures FFI call overhead and throughput using high-performance ctypes.

Performance target:
- C FFI: ~1-2ns/call
- Python ctypes: ~50-100ns/call (12x faster than UniFFI at ~1200ns)

Run:
    python3 examples/python/bench.py
"""

import time
from uor_ctypes import UOR, View

ITERATIONS = 1_000_000
WARMUP_ITERATIONS = 100_000


def bench_function(fn, name, iterations=ITERATIONS):
    """Benchmark a function and print results."""
    # Warmup
    for _ in range(WARMUP_ITERATIONS):
        fn()

    # Benchmark
    start = time.perf_counter_ns()
    for _ in range(iterations):
        fn()
    end = time.perf_counter_ns()

    total_ns = end - start
    per_call_ns = total_ns / iterations
    calls_per_sec_m = 1000.0 / per_call_ns

    print(f"  {name:30s}: {per_call_ns:8.2f} ns/call  ({calls_per_sec_m:7.2f} M calls/sec)")
    return per_call_ns


def main():
    print("=== UOR Python FFI Benchmarks (ctypes) ===\n")
    print("Target: < 100 ns per call (12x faster than UniFFI)")
    print(f"Iterations: {ITERATIONS:,} (after {WARMUP_ITERATIONS:,} warmup)\n")
    
    uor = UOR()
    
    # Taxon Operations
    print("Taxon Operations:")
    bench_function(lambda: uor.byte_to_braille(42), "byte_to_braille")
    bench_function(lambda: uor.byte_to_codepoint(42), "byte_to_codepoint")
    bench_function(lambda: uor.byte_to_domain(42), "byte_to_domain")
    bench_function(lambda: uor.byte_rank(42), "byte_rank")

    # Ring Operations
    print("\nRing Operations:")
    bench_function(lambda: uor.byte_succ(42), "byte_succ")
    bench_function(lambda: uor.byte_pred(42), "byte_pred")
    bench_function(lambda: uor.byte_not(42), "byte_not")

    # View Operations
    print("\nView Operations:")
    identity = View.identity()
    bench_function(lambda: identity.apply(42), "view_apply")

    # Batch Operations
    print("\nBatch Operations:")
    data = bytes(range(256)) * 4  # 1KB
    batch_iterations = ITERATIONS // 100

    def bench_batch():
        identity.apply_slice(data)

    batch_ns = bench_function(bench_batch, "view_apply_slice (1KB)", batch_iterations)
    throughput_mb = (1024.0 / batch_ns) * 1000.0
    print(f"  Throughput: {throughput_mb:.2f} MB/sec")

    print("\n=== Benchmarks Complete ===")


if __name__ == "__main__":
    main()
