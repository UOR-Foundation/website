/**
 * IdentityCreationFlow — "One Moment, One Identity"
 *
 * Auth-anchored identity creation:
 *  1. Authenticate (Google / Apple / Magic Link)
 *  2. Choose a name
 *  3. Crystallization animation
 *  4. Reveal → Dashboard
 */

import { useState, useRef, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Mail } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { toast } from "sonner";

type Phase = "auth" | "magic-sent" | "naming" | "creating" | "reveal";

export default function IdentityCreationFlow() {
  const navigate = useNavigate();
  const [phase, setPhase] = useState<Phase>("auth");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const nameRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Check if already authenticated → skip to naming
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        // Check if profile already exists
        supabase
          .from("profiles")
          .select("display_name")
          .eq("user_id", session.user.id)
          .maybeSingle()
          .then(({ data }) => {
            if (data) {
              navigate("/identity/explore");
            } else {
              // Pre-fill name from OAuth metadata if available
              const meta = session.user.user_metadata;
              if (meta?.full_name) setName(meta.full_name);
              else if (meta?.name) setName(meta.name);
              setPhase("naming");
            }
          });
      }
    });

    // Listen for auth changes (OAuth redirect / magic link)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" && session) {
        const meta = session.user.user_metadata;
        if (meta?.full_name) setName(meta.full_name);
        else if (meta?.name) setName(meta.name);
        setPhase("naming");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  // Auto-focus inputs
  useEffect(() => {
    if (phase === "auth") {
      const t = setTimeout(() => inputRef.current?.focus(), 600);
      return () => clearTimeout(t);
    }
    if (phase === "naming") {
      const t = setTimeout(() => nameRef.current?.focus(), 400);
      return () => clearTimeout(t);
    }
  }, [phase]);

  // Crystallization animation
  useEffect(() => {
    if (phase !== "creating") return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = canvas.offsetWidth * dpr;
    canvas.height = canvas.offsetHeight * dpr;
    ctx.scale(dpr, dpr);

    const w = canvas.offsetWidth;
    const h = canvas.offsetHeight;
    const cx = w / 2;
    const cy = h / 2;

    interface Particle {
      x: number; y: number; targetX: number; targetY: number;
      size: number; alpha: number; speed: number; hue: number;
    }

    const isMobile = w < 500;
    const count = isMobile ? 50 : 80;
    const baseRadius = isMobile ? 30 : 40;
    const particles: Particle[] = [];

    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const radius = baseRadius + Math.random() * (isMobile ? 20 : 30);
      particles.push({
        x: cx + (Math.random() - 0.5) * w,
        y: cy + (Math.random() - 0.5) * h,
        targetX: cx + Math.cos(angle) * radius,
        targetY: cy + Math.sin(angle) * radius,
        size: isMobile ? 1.2 + Math.random() * 1.5 : 1.5 + Math.random() * 2,
        alpha: 0,
        speed: 0.015 + Math.random() * 0.025,
        hue: 35 + Math.random() * 10,
      });
    }

    let progress = 0;
    let raf: number;

    const draw = () => {
      progress += 0.012;
      ctx.clearRect(0, 0, w, h);

      const glowAlpha = Math.min(progress * 0.8, 0.4);
      const gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, 80);
      gradient.addColorStop(0, `hsla(38, 60%, 60%, ${glowAlpha})`);
      gradient.addColorStop(1, `hsla(38, 60%, 60%, 0)`);
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, w, h);

      for (const p of particles) {
        const ease = Math.min(progress * p.speed * 60, 1);
        p.x += (p.targetX - p.x) * ease * 0.06;
        p.y += (p.targetY - p.y) * ease * 0.06;
        p.alpha = Math.min(progress * 1.5, 0.9);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${p.hue}, 60%, 60%, ${p.alpha})`;
        ctx.fill();
      }

      if (progress > 0.3) {
        const lineAlpha = Math.min((progress - 0.3) * 1.5, 0.15);
        ctx.strokeStyle = `hsla(38, 60%, 60%, ${lineAlpha})`;
        ctx.lineWidth = 0.5;
        for (let i = 0; i < particles.length; i++) {
          for (let j = i + 1; j < particles.length; j++) {
            const dx = particles[i].x - particles[j].x;
            const dy = particles[i].y - particles[j].y;
            if (dx * dx + dy * dy < 2500) {
              ctx.beginPath();
              ctx.moveTo(particles[i].x, particles[i].y);
              ctx.lineTo(particles[j].x, particles[j].y);
              ctx.stroke();
            }
          }
        }
      }

      if (progress < 1.0) {
        raf = requestAnimationFrame(draw);
      } else {
        setPhase("reveal");
      }
    };

    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [phase]);

  // ── Auth Handlers ──

  const handleGoogleSignIn = useCallback(async () => {
    const { error } = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin + "/identity/create",
    });
    if (error) toast.error("Could not sign in with Google");
  }, []);

  const handleAppleSignIn = useCallback(async () => {
    const { error } = await lovable.auth.signInWithOAuth("apple", {
      redirect_uri: window.location.origin + "/identity/create",
    });
    if (error) toast.error("Could not sign in with Apple");
  }, []);

  const handleMagicLink = useCallback(async () => {
    if (!email.trim()) return;
    const { error } = await supabase.auth.signInWithOtp({
      email: email.trim(),
      options: { emailRedirectTo: window.location.origin + "/identity/create" },
    });
    if (error) {
      toast.error("Could not send magic link");
    } else {
      setPhase("magic-sent");
    }
  }, [email]);

  // ── Profile Save ──

  const handleCreate = useCallback(async () => {
    if (!name.trim()) return;
    setPhase("creating");

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    const handle = `@${name.trim().toLowerCase().replace(/\s+/g, "")}.uor`;

    const { data: profileData } = await supabase.from("profiles").upsert({
      user_id: session.user.id,
      display_name: name.trim(),
      handle,
    }, { onConflict: "user_id" }).select("uor_id").single();

    // Mint genesis ceremony
    if (profileData?.uor_id) {
      await supabase.from("identity_ceremonies").insert({
        user_id: session.user.id,
        ceremony_type: "genesis",
        uor_id: profileData.uor_id,
        metadata: {
          display_name: name.trim(),
          handle,
          auth_provider: session.user.app_metadata?.provider || "email",
          created_at: new Date().toISOString(),
        },
      });
    }
  }, [name]);

  const handleFinish = useCallback(() => {
    navigate("/identity/explore");
  }, [navigate]);

  // ── Shared styles ──
  const radialBg = "radial-gradient(ellipse at 50% 40%, hsl(38 60% 60% / 0.04) 0%, transparent 70%)";

  // ── Auth Phase ──
  if (phase === "auth") {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-background">
        <div className="absolute inset-0 pointer-events-none" style={{ background: radialBg }} />

        <div className="relative z-10 w-full max-w-sm px-8 animate-fade-in">
          <div className="text-center mb-10">
            <h1 className="text-[28px] sm:text-4xl font-display font-semibold text-foreground leading-snug">
              Let's create something
              <br />
              <span className="text-primary">only yours.</span>
            </h1>
            <p className="text-sm text-muted-foreground mt-4">
              Sign in to anchor your identity.
            </p>
          </div>

          <div className="space-y-3">
            {/* Google */}
            <button
              onClick={handleGoogleSignIn}
              className="w-full min-h-[48px] flex items-center justify-center gap-3 px-6 py-3 rounded-full border border-border bg-card text-foreground text-base font-medium hover:bg-secondary active:scale-[0.98] transition-all duration-200"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5 shrink-0">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              Continue with Google
            </button>

            {/* Apple */}
            <button
              onClick={handleAppleSignIn}
              className="w-full min-h-[48px] flex items-center justify-center gap-3 px-6 py-3 rounded-full border border-border bg-card text-foreground text-base font-medium hover:bg-secondary active:scale-[0.98] transition-all duration-200"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5 shrink-0" fill="currentColor">
                <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
              </svg>
              Continue with Apple
            </button>

            {/* Divider */}
            <div className="flex items-center gap-4 py-2">
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs text-muted-foreground">or</span>
              <div className="flex-1 h-px bg-border" />
            </div>

            {/* Magic Link */}
            <div className="space-y-3">
              <input
                ref={inputRef}
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleMagicLink()}
                placeholder="your@email.com"
                className="w-full min-h-[48px] bg-transparent border border-border rounded-full px-6 py-3 text-base text-foreground text-center placeholder:text-muted-foreground/40 outline-none focus:border-primary transition-colors duration-200"
                autoComplete="email"
                enterKeyHint="send"
              />
              <div
                className="flex justify-center transition-all duration-500"
                style={{
                  opacity: email.trim() ? 1 : 0,
                  transform: email.trim() ? "translateY(0)" : "translateY(8px)",
                  pointerEvents: email.trim() ? "auto" : "none",
                }}
              >
                <button
                  onClick={handleMagicLink}
                  className="w-full min-h-[48px] flex items-center justify-center gap-2 px-6 py-3 rounded-full bg-primary text-primary-foreground text-base font-semibold active:scale-[0.98] hover:bg-primary/90 transition-all duration-200"
                >
                  <Mail className="w-4 h-4" />
                  Send magic link
                </button>
              </div>
            </div>
          </div>

          {/* Skip */}
          <div className="text-center mt-10">
            <button
              onClick={() => navigate("/identity")}
              className="min-h-[44px] px-4 text-sm text-muted-foreground/50 hover:text-muted-foreground active:text-muted-foreground transition-colors"
            >
              I'll explore first
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── Magic Link Sent ──
  if (phase === "magic-sent") {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-background">
        <div className="absolute inset-0 pointer-events-none" style={{ background: radialBg }} />
        <div className="relative z-10 text-center px-8 animate-fade-in space-y-6 max-w-sm">
          <div className="inline-flex items-center justify-center h-16 w-16 rounded-full border border-primary/20 mx-auto"
            style={{ background: "radial-gradient(circle, hsl(38 60% 60% / 0.12) 0%, transparent 70%)" }}
          >
            <Mail className="h-7 w-7 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-display font-semibold text-foreground">
              Check your email
            </h2>
            <p className="text-base text-muted-foreground mt-3 leading-relaxed">
              We sent a link to <span className="text-foreground font-medium">{email}</span>. Click it to continue.
            </p>
          </div>
          <button
            onClick={() => setPhase("auth")}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Use a different method
          </button>
        </div>
      </div>
    );
  }

  // ── Naming Phase ──
  if (phase === "naming") {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-background">
        <div className="absolute inset-0 pointer-events-none" style={{ background: radialBg }} />
        <div className="relative z-10 w-full max-w-md px-8 animate-fade-in">
          <div className="text-center mb-8 sm:mb-10">
            <h1 className="text-[28px] sm:text-4xl font-display font-semibold text-foreground leading-snug">
              What should we
              <br />
              <span className="text-primary">call you?</span>
            </h1>
          </div>

          <div className="space-y-6">
            <input
              ref={nameRef}
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && name.trim() && handleCreate()}
              placeholder="Choose a name"
              maxLength={30}
              className="w-full bg-transparent border-b-2 border-border focus:border-primary text-center text-xl sm:text-3xl font-display text-foreground placeholder:text-muted-foreground/40 py-4 outline-none transition-colors duration-300"
              autoComplete="off"
              spellCheck={false}
              enterKeyHint="done"
            />

            <div
              className="flex justify-center transition-all duration-500"
              style={{
                opacity: name.trim() ? 1 : 0,
                transform: name.trim() ? "translateY(0)" : "translateY(8px)",
                pointerEvents: name.trim() ? "auto" : "none",
              }}
            >
              <button
                onClick={handleCreate}
                className="min-w-[160px] min-h-[48px] px-10 py-3.5 rounded-full text-base font-semibold bg-primary text-primary-foreground active:scale-95 hover:bg-primary/90 transition-all duration-200 hover:shadow-lg hover:shadow-primary/20"
              >
                Create
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── Creating Phase (Animation) ──
  if (phase === "creating") {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background">
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" style={{ opacity: 0.9 }} />
        <div className="relative z-10 text-center animate-fade-in">
          <p className="text-lg sm:text-xl text-muted-foreground font-display">
            Creating your identity…
          </p>
        </div>
      </div>
    );
  }

  // ── Reveal Phase ──
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background">
      <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse at 50% 40%, hsl(38 60% 60% / 0.06) 0%, transparent 60%)" }} />
      <div className="relative z-10 text-center px-8 animate-fade-in space-y-6 sm:space-y-8">
        <div className="inline-flex items-center justify-center h-20 w-20 sm:h-24 sm:w-24 rounded-full border border-primary/20 mx-auto"
          style={{ background: "radial-gradient(circle, hsl(38 60% 60% / 0.12) 0%, transparent 70%)" }}
        >
          <span className="text-3xl sm:text-4xl font-display font-bold text-primary">
            {name.trim().charAt(0).toUpperCase()}
          </span>
        </div>
        <div>
          <h2 className="text-2xl sm:text-3xl font-display font-semibold text-foreground">
            {name.trim()}
          </h2>
          <p className="text-base text-muted-foreground mt-3 max-w-[280px] sm:max-w-xs mx-auto leading-relaxed">
            Your identity is ready. Everything is private by default.
          </p>
        </div>
        <button
          onClick={handleFinish}
          className="min-w-[160px] min-h-[48px] px-10 py-3.5 rounded-full text-base font-semibold bg-primary text-primary-foreground active:scale-95 hover:bg-primary/90 transition-all duration-200 hover:shadow-lg hover:shadow-primary/20"
        >
          Enter
        </button>
      </div>
    </div>
  );
}
