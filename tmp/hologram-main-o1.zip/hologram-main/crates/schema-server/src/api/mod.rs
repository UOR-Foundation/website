//! API handlers and routing.

pub mod handlers;
pub mod routes;

pub use routes::build_router;
