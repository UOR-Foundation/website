/**
 * Identity Engine — Pure Functions for Trust & Permission Logic
 * ═════════════════════════════════════════════════════════════
 *
 * Pure data. No classes. No side effects.
 * All transformations are deterministic projections.
 *
 * @module identity/engine
 */

import type {
  TrustAttestation,
  TrustLevel,
  TrustScore,
  Permission,
  PermissionAction,
  PermissionScope,
  PrivacyConsent,
  ConsentStatus,
} from "../types";

// ── Trust Computation ───────────────────────────────────────────────────────

const TRUST_WEIGHTS: Record<TrustLevel, number> = {
  unknown: 0,
  distrusted: -0.5,
  minimal: 0.15,
  basic: 0.35,
  verified: 0.7,
  sovereign: 1.0,
};

/** Compute aggregate trust score from attestations. */
export function computeTrustScore(
  identityId: string,
  attestations: readonly TrustAttestation[],
): TrustScore {
  const relevant = attestations.filter(
    (a) => a.toId === identityId && (!a.expiresAt || a.expiresAt > Date.now()),
  );

  if (relevant.length === 0) {
    return {
      identityId,
      score: 0,
      level: "unknown",
      attestationCount: 0,
      lastUpdated: Date.now(),
    };
  }

  const sum = relevant.reduce((acc, a) => acc + TRUST_WEIGHTS[a.level], 0);
  const raw = Math.max(0, Math.min(1, sum / relevant.length));
  const level = scoreToLevel(raw);

  return {
    identityId,
    score: raw,
    level,
    attestationCount: relevant.length,
    lastUpdated: Date.now(),
  };
}

function scoreToLevel(score: number): TrustLevel {
  if (score >= 0.9) return "sovereign";
  if (score >= 0.65) return "verified";
  if (score >= 0.35) return "basic";
  if (score >= 0.15) return "minimal";
  if (score < 0) return "distrusted";
  return "unknown";
}

// ── Permission Checking ─────────────────────────────────────────────────────

/** Check if an identity has a specific permission on a resource. */
export function hasPermission(
  permissions: readonly Permission[],
  identityId: string,
  resource: string,
  action: PermissionAction,
): boolean {
  return permissions.some(
    (p) =>
      p.identityId === identityId &&
      p.resource === resource &&
      p.action === action &&
      p.active &&
      (!p.expiresAt || p.expiresAt > Date.now()),
  );
}

/** Filter permissions by scope. */
export function permissionsByScope(
  permissions: readonly Permission[],
  scope: PermissionScope,
): readonly Permission[] {
  return permissions.filter((p) => p.scope === scope && p.active);
}

// ── Consent Checking ────────────────────────────────────────────────────────

/** Check if consent is active for a data category. */
export function isConsentActive(
  consents: readonly PrivacyConsent[],
  identityId: string,
  category: string,
): ConsentStatus {
  const consent = consents.find(
    (c) =>
      c.identityId === identityId &&
      c.category === category &&
      (!c.expiresAt || c.expiresAt > Date.now()),
  );

  return consent?.status ?? "pending";
}

/** Get all active consents for an identity. */
export function activeConsents(
  consents: readonly PrivacyConsent[],
  identityId: string,
): readonly PrivacyConsent[] {
  return consents.filter(
    (c) =>
      c.identityId === identityId &&
      c.status === "granted" &&
      (!c.expiresAt || c.expiresAt > Date.now()),
  );
}
