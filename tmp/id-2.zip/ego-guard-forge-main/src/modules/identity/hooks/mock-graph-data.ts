/**
 * Mock trust network data for development.
 * Demonstrates the variety of node types and edge relationships.
 */

import type { TrustGraphData } from "../components/TrustGraph";

export const MOCK_GRAPH_DATA: TrustGraphData = {
  nodes: [
    // Self — center of the universe
    { id: "self", name: "You", type: "self", trustLevel: 1, verified: true, description: "Your sovereign identity" },

    // People
    { id: "p1", name: "Elena Vasquez", type: "person", trustLevel: 0.92, verified: true, description: "Longtime collaborator", group: "inner-circle" },
    { id: "p2", name: "Marcus Chen", type: "person", trustLevel: 0.85, verified: true, description: "Research partner", group: "inner-circle" },
    { id: "p3", name: "Amara Okafor", type: "person", trustLevel: 0.78, verified: true, description: "Community builder", group: "community" },
    { id: "p4", name: "Liam Brennan", type: "person", trustLevel: 0.65, verified: false, description: "Met at Protocol Summit", group: "acquaintance" },
    { id: "p5", name: "Yuki Tanaka", type: "person", trustLevel: 0.71, verified: true, description: "Open-source contributor", group: "community" },
    { id: "p6", name: "Sofia Petrov", type: "person", trustLevel: 0.55, verified: false, description: "Introduced by Marcus", group: "acquaintance" },
    { id: "p7", name: "Raj Patel", type: "person", trustLevel: 0.88, verified: true, description: "Privacy advocate", group: "inner-circle" },
    { id: "p8", name: "Nina Hoffman", type: "person", trustLevel: 0.45, verified: false, description: "New connection", group: "acquaintance" },

    // Agents
    { id: "a1", name: "Guardian AI", type: "agent", trustLevel: 0.95, verified: true, description: "Personal privacy guardian" },
    { id: "a2", name: "Research Analyst", type: "agent", trustLevel: 0.80, verified: true, description: "Helps with deep research" },
    { id: "a3", name: "Code Companion", type: "agent", trustLevel: 0.88, verified: true, description: "Pair programming partner" },
    { id: "a4", name: "Community Moderator", type: "agent", trustLevel: 0.72, verified: false, description: "Manages community interactions" },
    { id: "a5", name: "Data Steward", type: "agent", trustLevel: 0.90, verified: true, description: "Manages data sovereignty" },

    // Experiences
    { id: "e1", name: "Protocol Summit '25", type: "experience", trustLevel: 0.82, description: "Decentralized identity conference" },
    { id: "e2", name: "Privacy Workshop", type: "experience", trustLevel: 0.75, description: "Hands-on privacy tools training" },
    { id: "e3", name: "Open Source Sprint", type: "experience", trustLevel: 0.90, description: "48-hour collaborative build" },
    { id: "e4", name: "Trust Ceremony", type: "experience", trustLevel: 0.95, verified: true, description: "Founding identity verification" },
    { id: "e5", name: "Community Governance", type: "experience", trustLevel: 0.68, description: "Participated in voting" },

    // Objects
    { id: "o1", name: "Identity Proof", type: "object", trustLevel: 0.98, verified: true, description: "Cryptographic identity attestation" },
    { id: "o2", name: "Privacy Manifest", type: "object", trustLevel: 0.85, description: "Published sovereignty declaration" },
    { id: "o3", name: "Research Paper", type: "object", trustLevel: 0.77, description: "Co-authored publication" },
    { id: "o4", name: "Community Charter", type: "object", trustLevel: 0.70, description: "Governance framework document" },
    { id: "o5", name: "Verification Badge", type: "object", trustLevel: 0.92, verified: true, description: "Earned through peer verification" },
  ],

  links: [
    // Self connections
    { source: "self", target: "p1", type: "trusts", strength: 0.9 },
    { source: "self", target: "p2", type: "trusts", strength: 0.85 },
    { source: "self", target: "p3", type: "trusts", strength: 0.7 },
    { source: "self", target: "p7", type: "trusts", strength: 0.88 },
    { source: "self", target: "a1", type: "trusts", strength: 0.95 },
    { source: "self", target: "a3", type: "trusts", strength: 0.85 },
    { source: "self", target: "a5", type: "trusts", strength: 0.9 },
    { source: "self", target: "o1", type: "created", strength: 0.98 },
    { source: "self", target: "o2", type: "created", strength: 0.85 },
    { source: "self", target: "e4", type: "interacted", strength: 0.95 },

    // Verified connections
    { source: "self", target: "p1", type: "verified", strength: 0.92 },
    { source: "self", target: "p2", type: "verified", strength: 0.85 },
    { source: "self", target: "p5", type: "verified", strength: 0.71 },
    { source: "p1", target: "p2", type: "verified", strength: 0.8 },
    { source: "p2", target: "p5", type: "verified", strength: 0.65 },

    // People connections
    { source: "p1", target: "p3", type: "trusts", strength: 0.6 },
    { source: "p2", target: "p6", type: "trusts", strength: 0.5 },
    { source: "p3", target: "p4", type: "interacted", strength: 0.4 },
    { source: "p3", target: "p5", type: "trusts", strength: 0.55 },
    { source: "p4", target: "p6", type: "interacted", strength: 0.3 },
    { source: "p7", target: "p1", type: "trusts", strength: 0.7 },
    { source: "p7", target: "p3", type: "trusts", strength: 0.6 },
    { source: "p8", target: "p4", type: "interacted", strength: 0.25 },

    // Agent connections
    { source: "a1", target: "a5", type: "interacted", strength: 0.85 },
    { source: "a2", target: "p2", type: "interacted", strength: 0.6 },
    { source: "a3", target: "p5", type: "interacted", strength: 0.5 },
    { source: "a4", target: "p3", type: "interacted", strength: 0.55 },
    { source: "self", target: "a2", type: "trusts", strength: 0.8 },
    { source: "self", target: "a4", type: "interacted", strength: 0.5 },

    // Experience connections
    { source: "self", target: "e1", type: "interacted", strength: 0.8 },
    { source: "self", target: "e2", type: "interacted", strength: 0.7 },
    { source: "self", target: "e3", type: "interacted", strength: 0.9 },
    { source: "self", target: "e5", type: "interacted", strength: 0.6 },
    { source: "p1", target: "e1", type: "interacted", strength: 0.75 },
    { source: "p2", target: "e3", type: "interacted", strength: 0.85 },
    { source: "p3", target: "e5", type: "interacted", strength: 0.65 },
    { source: "p4", target: "e1", type: "interacted", strength: 0.5 },
    { source: "p5", target: "e3", type: "interacted", strength: 0.8 },
    { source: "p7", target: "e2", type: "interacted", strength: 0.7 },

    // Object connections
    { source: "p1", target: "o3", type: "created", strength: 0.7 },
    { source: "self", target: "o3", type: "created", strength: 0.75 },
    { source: "p3", target: "o4", type: "created", strength: 0.6 },
    { source: "self", target: "o4", type: "witnessed", strength: 0.5 },
    { source: "e4", target: "o1", type: "created", strength: 0.98 },
    { source: "e4", target: "o5", type: "created", strength: 0.92 },
    { source: "self", target: "o5", type: "interacted", strength: 0.9 },
  ],
};
