//! Grouped convolution dispatcher and kernels.
//!
//! Grouped convolution divides input and output channels into G independent
//! groups, performing convolution within each group separately. This generalizes
//! both standard convolution (G=1) and depthwise convolution (G=C_in).
//!
//! # Group Convolution Properties
//!
//! For input [N, C_in, H, W] and kernel [C_out, C_in/G, KH, KW]:
//! - C_in must be divisible by G
//! - C_out must be divisible by G
//! - Each group processes C_in/G input channels to C_out/G output channels
//!
//! # Special Cases
//!
//! - G = 1: Standard convolution (full channel mixing)
//! - G = C_in = C_out: Depthwise convolution (no channel mixing)
//! - 1 < G < C_in: Partial channel mixing (used in ResNeXt, ShuffleNet)
//!
//! # Implementation
//!
//! This module dispatches to specialized implementations:
//! - Standard conv when G=148weM
//! - Depthwise conv when G=C_in
//! - Loop over G independent convolutions otherwise

use crate::layout::WinogradVariant;
use crate::transform_cache::{FilterId, TransformCache};
use crate::{BackendError, Conv2DParams, DepthwiseConv2DParams, GroupedConv2DParams};

use super::depthwise::depthwise_conv2d_f32;
use super::simd_dispatch::SimdDispatcher;
use super::winograd::{should_use_winograd, winograd_conv2d_f23};

// ============================================================================
// OPTIMIZATION CONSTANTS AND TYPES
// ============================================================================

/// Minimum total work (elements) to enable parallelization.
/// Below this threshold, parallelization overhead exceeds benefits.
const PARALLEL_THRESHOLD: usize = 4096;

/// Minimum GEMM work (m × k × n) to justify Im2col transformation.
/// For very small convolutions, direct loops may be faster.
const GEMM_MIN_WORK: usize = 256;

/// Algorithm selection for grouped convolution.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum GroupedConvAlgorithm {
    /// Standard convolution (G=1), delegate to simd_dispatch.
    Standard,
    /// Depthwise convolution (G=C_in), delegate to depthwise module.
    Depthwise,
    /// Winograd F(2,3) for 3x3 kernels with stride=1 (~2.25x fewer multiplications).
    /// Currently disabled due to filter transform overhead. Will be re-enabled with caching.
    #[allow(dead_code)]
    Winograd,
    /// 1x1 kernel: direct GEMM without im2col (no spatial rearrangement needed).
    Gemm1x1,
    /// Im2col + GEMM per group (general optimized path).
    Im2ColGemm,
    /// Direct nested loops with SIMD (fallback for small cases).
    DirectSimd,
    /// Direct nested loops scalar (final fallback).
    Direct,
}

/// Dimension to parallelize over.
#[derive(Debug, Clone, Copy)]
#[allow(dead_code)]
enum ParallelDim {
    /// Parallelize over groups only.
    Groups,
    /// Parallelize over (batch, group) pairs.
    BatchAndGroups,
    /// No parallelization.
    Sequential,
}

/// Configuration for grouped convolution execution.
#[derive(Debug)]
struct GroupedConvConfig {
    algorithm: GroupedConvAlgorithm,
    #[allow(dead_code)]
    use_parallel: bool,
    #[allow(dead_code)]
    parallel_dim: ParallelDim,
    im2col_buffer_size: usize,
}

/// Select optimal algorithm for grouped convolution.
fn select_algorithm(params: &GroupedConv2DParams) -> GroupedConvConfig {
    let groups = params.groups as usize;
    let batch = params.input_dims[0] as usize;
    let in_channels = params.input_dims[1] as usize;
    let out_channels = params.kernel_dims[0] as usize;
    let kernel_h = params.kernel_dims[2] as usize;
    let kernel_w = params.kernel_dims[3] as usize;
    let out_dims = params.output_dims();
    let out_h = out_dims[2] as usize;
    let out_w = out_dims[3] as usize;

    let in_ch_per_group = in_channels / groups;
    let out_ch_per_group = out_channels / groups;

    // Compute work metrics
    let spatial_size = out_h * out_w;
    let total_work = batch * groups * out_ch_per_group * spatial_size;

    // GEMM dimensions per group
    let m = out_ch_per_group;
    let k = in_ch_per_group * kernel_h * kernel_w;
    let n = spatial_size;
    let gemm_work = m * k;

    // Check if Winograd is applicable (3x3 kernel, stride=1, no dilation)
    let can_use_winograd = should_use_winograd(
        kernel_h,
        kernel_w,
        params.stride[0] as usize,
        params.stride[1] as usize,
        params.dilation[0] as usize,
        params.dilation[1] as usize,
        out_h,
        out_w,
    );

    // Check for 1x1 kernel (no padding/dilation needed, stride just changes output size)
    let is_1x1 = kernel_h == 1 && kernel_w == 1;

    // Algorithm selection priority:
    // 1. Standard (G=1) → existing optimized path
    // 2. Depthwise (G=C_in) → existing depthwise module
    // 3. Winograd for 3x3/stride=1 (2.25x fewer multiplications)
    // 4. 1x1 kernel → direct GEMM (no im2col needed)
    // 5. Im2Col+GEMM for large enough work
    // 6. DirectSimd for medium cases with SIMD
    // 7. Direct scalar for tiny cases
    //
    // NOTE: Winograd (can_use_winograd) is temporarily disabled due to filter
    // transform overhead. The current implementation is 6-20x slower than Im2Col.
    // Re-enable by caching transformed filters keyed by filter pointer + dimensions.
    let _ = can_use_winograd; // Silence unused warning until Winograd is re-enabled
    let algorithm = if params.is_standard() {
        GroupedConvAlgorithm::Standard
    } else if params.is_depthwise() {
        GroupedConvAlgorithm::Depthwise
    } else if is_1x1 {
        // 1x1 kernels always use direct GEMM (no im2col needed)
        GroupedConvAlgorithm::Gemm1x1
    } else if gemm_work >= GEMM_MIN_WORK {
        GroupedConvAlgorithm::Im2ColGemm
    } else if out_ch_per_group >= 8 {
        // Use SIMD for direct path when we have enough output channels
        GroupedConvAlgorithm::DirectSimd
    } else {
        GroupedConvAlgorithm::Direct
    };

    // Determine parallelization strategy
    let (use_parallel, parallel_dim) = if total_work >= PARALLEL_THRESHOLD {
        if batch * groups >= 4 {
            (true, ParallelDim::BatchAndGroups)
        } else if groups >= 4 {
            (true, ParallelDim::Groups)
        } else {
            (false, ParallelDim::Sequential)
        }
    } else {
        (false, ParallelDim::Sequential)
    };

    // Calculate im2col buffer size per group
    let im2col_buffer_size = k * n;

    GroupedConvConfig {
        algorithm,
        use_parallel,
        parallel_dim,
        im2col_buffer_size,
    }
}

// ============================================================================
// IM2COL TRANSFORMATION WITH CACHE BLOCKING
// ============================================================================

/// Spatial tile size for L1 cache efficiency.
/// 16x16 tiles = 256 elements × 4 bytes = 1KB per tile, fits easily in L1.
const IM2COL_TILE_H: usize = 16;
const IM2COL_TILE_W: usize = 16;

/// Per-group im2col transformation with cache blocking.
///
/// Transforms a convolution into a matrix multiplication by rearranging
/// input patches into columns. For each group g and batch n:
///
/// - Input slice: input[n, g*C_in/G : (g+1)*C_in/G, :, :]
/// - Output: col[K, N] where K = C_in/G × KH × KW, N = H_out × W_out
///
/// The output can then be multiplied: output = kernel @ col
///
/// Uses spatial tiling for better cache locality on large feature maps.
fn im2col_grouped_f32(
    col: &mut [f32],
    input: &[f32],
    group_idx: usize,
    batch_idx: usize,
    params: &GroupedConv2DParams,
) {
    let in_channels = params.input_dims[1] as usize;
    let in_height = params.input_dims[2] as usize;
    let in_width = params.input_dims[3] as usize;
    let kernel_h = params.kernel_dims[2] as usize;
    let kernel_w = params.kernel_dims[3] as usize;
    let out_dims = params.output_dims();
    let out_height = out_dims[2] as usize;
    let out_width = out_dims[3] as usize;
    let stride_h = params.stride[0] as usize;
    let stride_w = params.stride[1] as usize;
    let pad_h = params.padding[0] as usize;
    let pad_w = params.padding[1] as usize;
    let dilation_h = params.dilation[0] as usize;
    let dilation_w = params.dilation[1] as usize;
    let groups = params.groups as usize;
    let in_ch_per_group = in_channels / groups;

    let in_hw = in_height * in_width;
    let c_in_start = group_idx * in_ch_per_group;
    let n_dim = out_height * out_width;

    // Input offset for this batch
    let batch_offset = batch_idx * in_channels * in_hw;

    // For small spatial sizes, use direct loop (no tiling overhead)
    if out_height <= IM2COL_TILE_H && out_width <= IM2COL_TILE_W {
        im2col_direct(
            col,
            input,
            batch_offset,
            c_in_start,
            in_ch_per_group,
            in_height,
            in_width,
            in_hw,
            kernel_h,
            kernel_w,
            out_height,
            out_width,
            n_dim,
            stride_h,
            stride_w,
            pad_h,
            pad_w,
            dilation_h,
            dilation_w,
        );
        return;
    }

    // Cache-blocked im2col: process spatial tiles
    for oh_tile in (0..out_height).step_by(IM2COL_TILE_H) {
        let oh_end = (oh_tile + IM2COL_TILE_H).min(out_height);

        for ow_tile in (0..out_width).step_by(IM2COL_TILE_W) {
            let ow_end = (ow_tile + IM2COL_TILE_W).min(out_width);

            // Process this tile for all kernel rows
            for c in 0..in_ch_per_group {
                let c_global = c_in_start + c;

                for kh in 0..kernel_h {
                    for kw in 0..kernel_w {
                        let col_row = (c * kernel_h + kh) * kernel_w + kw;

                        // Process tile with improved cache locality
                        for oh in oh_tile..oh_end {
                            let ih_base =
                                (oh * stride_h + kh * dilation_h) as isize - pad_h as isize;

                            for ow in ow_tile..ow_end {
                                let iw =
                                    (ow * stride_w + kw * dilation_w) as isize - pad_w as isize;
                                let col_col = oh * out_width + ow;

                                let val = if ih_base >= 0
                                    && ih_base < in_height as isize
                                    && iw >= 0
                                    && iw < in_width as isize
                                {
                                    let in_idx = batch_offset
                                        + c_global * in_hw
                                        + ih_base as usize * in_width
                                        + iw as usize;
                                    input.get(in_idx).copied().unwrap_or(0.0)
                                } else {
                                    0.0
                                };

                                col[col_row * n_dim + col_col] = val;
                            }
                        }
                    }
                }
            }
        }
    }
}

/// Direct im2col without tiling overhead (for small spatial sizes).
#[allow(clippy::too_many_arguments)]
fn im2col_direct(
    col: &mut [f32],
    input: &[f32],
    batch_offset: usize,
    c_in_start: usize,
    in_ch_per_group: usize,
    in_height: usize,
    in_width: usize,
    in_hw: usize,
    kernel_h: usize,
    kernel_w: usize,
    out_height: usize,
    out_width: usize,
    n_dim: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
    dilation_h: usize,
    dilation_w: usize,
) {
    for c in 0..in_ch_per_group {
        let c_global = c_in_start + c;

        for kh in 0..kernel_h {
            for kw in 0..kernel_w {
                let col_row = (c * kernel_h + kh) * kernel_w + kw;

                for oh in 0..out_height {
                    let ih = (oh * stride_h + kh * dilation_h) as isize - pad_h as isize;

                    for ow in 0..out_width {
                        let iw = (ow * stride_w + kw * dilation_w) as isize - pad_w as isize;
                        let col_col = oh * out_width + ow;

                        let val = if ih >= 0
                            && ih < in_height as isize
                            && iw >= 0
                            && iw < in_width as isize
                        {
                            let in_idx = batch_offset
                                + c_global * in_hw
                                + ih as usize * in_width
                                + iw as usize;
                            input.get(in_idx).copied().unwrap_or(0.0)
                        } else {
                            0.0
                        };

                        col[col_row * n_dim + col_col] = val;
                    }
                }
            }
        }
    }
}

// ============================================================================
// IM2COL + GEMM IMPLEMENTATION
// ============================================================================

/// Sequential grouped convolution using Im2col + GEMM.
///
/// Converts convolution to matrix multiplication per group:
/// - For each group: output = kernel @ im2col(input)
/// - Reuses a single im2col buffer across groups (memory efficient)
/// - Uses SimdDispatcher for optimized GEMM (AVX2/NEON micro-kernels)
fn grouped_conv_im2col_sequential(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
    config: &GroupedConvConfig,
) -> Result<(), BackendError> {
    let batch = params.input_dims[0] as usize;
    let out_channels = params.kernel_dims[0] as usize;
    let kernel_h = params.kernel_dims[2] as usize;
    let kernel_w = params.kernel_dims[3] as usize;
    let out_dims = params.output_dims();
    let out_height = out_dims[2] as usize;
    let out_width = out_dims[3] as usize;
    let groups = params.groups as usize;
    let in_ch_per_group = params.input_dims[1] as usize / groups;
    let out_ch_per_group = out_channels / groups;

    let out_hw = out_height * out_width;
    let out_chw = out_channels * out_hw;

    // GEMM dimensions per group:
    // - m: output channels per group (rows of output)
    // - k: reduction dimension (C_in/G × KH × KW)
    // - n: spatial positions (H_out × W_out)
    let m = out_ch_per_group;
    let k = in_ch_per_group * kernel_h * kernel_w;
    let n = out_hw;

    // Single reusable im2col buffer (zero-copy optimization)
    let mut col = vec![0.0f32; config.im2col_buffer_size];
    let mut gemm_output = vec![0.0f32; m * n];

    let dispatcher = SimdDispatcher::new();

    for batch_idx in 0..batch {
        for group_idx in 0..groups {
            // Perform im2col (overwrites col buffer)
            im2col_grouped_f32(&mut col, input, group_idx, batch_idx, params);

            // Kernel slice for this group
            // Kernel layout: [C_out, C_in/G, KH, KW]
            // For group g, we need output channels [g*out_ch_per_group, (g+1)*out_ch_per_group)
            let kernel_offset = group_idx * out_ch_per_group * k;
            let kernel_slice = &kernel[kernel_offset..kernel_offset + m * k];

            // GEMM: gemm_output = kernel @ col
            // C = alpha * A @ B + beta * C
            // Here: gemm_output = 1.0 * kernel_slice @ col + 0.0 * gemm_output
            dispatcher.matmul_f32(&mut gemm_output, kernel_slice, &col, m, k, n, 1.0, 0.0)?;

            // Copy to output with bias addition
            let out_offset = batch_idx * out_chw + group_idx * out_ch_per_group * out_hw;
            let bias_offset = group_idx * out_ch_per_group;

            for oc in 0..out_ch_per_group {
                let bias_val = bias
                    .and_then(|b| b.get(bias_offset + oc).copied())
                    .unwrap_or(0.0);
                for spatial in 0..n {
                    let src_idx = oc * n + spatial;
                    let dst_idx = out_offset + oc * out_hw + spatial;
                    output[dst_idx] = gemm_output[src_idx] + bias_val;
                }
            }
        }
    }

    Ok(())
}

/// Parallel grouped convolution using Im2col + GEMM.
///
/// Parallelizes over (batch, group) pairs using Rayon.
/// Each thread allocates its own im2col buffer (no contention).
#[cfg(feature = "parallel")]
fn grouped_conv_im2col_parallel(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
    config: &GroupedConvConfig,
) -> Result<(), BackendError> {
    use rayon::prelude::*;

    let batch = params.input_dims[0] as usize;
    let out_channels = params.kernel_dims[0] as usize;
    let kernel_h = params.kernel_dims[2] as usize;
    let kernel_w = params.kernel_dims[3] as usize;
    let out_dims = params.output_dims();
    let out_height = out_dims[2] as usize;
    let out_width = out_dims[3] as usize;
    let groups = params.groups as usize;
    let in_ch_per_group = params.input_dims[1] as usize / groups;
    let out_ch_per_group = out_channels / groups;

    let out_hw = out_height * out_width;
    let out_chw = out_channels * out_hw;

    // GEMM dimensions per group
    let m = out_ch_per_group;
    let k = in_ch_per_group * kernel_h * kernel_w;
    let n = out_hw;

    // Output size per (batch, group) work item
    let work_item_size = out_ch_per_group * out_hw;

    // Create work items: (batch_idx, group_idx)
    let work_items: Vec<(usize, usize)> = (0..batch)
        .flat_map(|b| (0..groups).map(move |g| (b, g)))
        .collect();

    // Compute all GEMM results in parallel, collecting into a Vec
    let results: Vec<Result<Vec<f32>, BackendError>> = work_items
        .par_iter()
        .map(|&(batch_idx, group_idx)| {
            // Thread-local buffers
            let mut col = vec![0.0f32; config.im2col_buffer_size];
            let mut gemm_output = vec![0.0f32; m * n];

            let dispatcher = SimdDispatcher::new();

            // Compute im2col for this (batch, group)
            im2col_grouped_f32(&mut col, input, group_idx, batch_idx, params);

            // Kernel slice for this group
            let kernel_offset = group_idx * out_ch_per_group * k;
            let kernel_slice = &kernel[kernel_offset..kernel_offset + m * k];

            // GEMM
            dispatcher.matmul_f32(&mut gemm_output, kernel_slice, &col, m, k, n, 1.0, 0.0)?;

            // Add bias
            let bias_offset = group_idx * out_ch_per_group;
            for oc in 0..out_ch_per_group {
                let bias_val = bias
                    .and_then(|b| b.get(bias_offset + oc).copied())
                    .unwrap_or(0.0);
                if bias_val != 0.0 {
                    for spatial in 0..n {
                        gemm_output[oc * n + spatial] += bias_val;
                    }
                }
            }

            Ok(gemm_output)
        })
        .collect();

    // Check for errors and copy results to output
    for (idx, result) in results.into_iter().enumerate() {
        let gemm_output = result?;
        let (batch_idx, group_idx) = work_items[idx];
        let out_offset = batch_idx * out_chw + group_idx * out_ch_per_group * out_hw;

        // Copy to final output location
        let dst_end = (out_offset + work_item_size).min(output.len());
        let copy_len = dst_end.saturating_sub(out_offset);
        output[out_offset..out_offset + copy_len].copy_from_slice(&gemm_output[..copy_len]);
    }

    Ok(())
}

/// Fallback for non-parallel builds: just use sequential.
#[cfg(not(feature = "parallel"))]
fn grouped_conv_im2col_parallel(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
    config: &GroupedConvConfig,
) -> Result<(), BackendError> {
    grouped_conv_im2col_sequential(output, input, kernel, bias, params, config)
}

// ============================================================================
// WINOGRAD F(2,3) IMPLEMENTATION
// ============================================================================

/// Grouped convolution using Winograd F(2,3) for 3x3 kernels.
///
/// Winograd convolution trades multiplications for additions:
/// - F(2,3): 16 multiplications vs 36 for direct conv → 2.25x reduction
/// - Each group's filter is pre-transformed to Winograd domain
/// - Then winograd_conv2d_f23 is called per group
fn grouped_conv_winograd(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    let batch = params.input_dims[0] as usize;
    let in_channels = params.input_dims[1] as usize;
    let in_height = params.input_dims[2] as usize;
    let in_width = params.input_dims[3] as usize;
    let out_channels = params.kernel_dims[0] as usize;
    let out_dims = params.output_dims();
    let out_height = out_dims[2] as usize;
    let out_width = out_dims[3] as usize;
    let pad_h = params.padding[0] as usize;
    let pad_w = params.padding[1] as usize;
    let groups = params.groups as usize;
    let in_ch_per_group = in_channels / groups;
    let out_ch_per_group = out_channels / groups;

    let in_hw = in_height * in_width;
    let in_chw = in_channels * in_hw;
    let out_hw = out_height * out_width;
    let out_chw = out_channels * out_hw;

    // Pre-transform filters for all groups
    let mut cache = TransformCache::new();

    for g in 0..groups {
        // Extract kernel for this group
        // Kernel layout: [C_out, C_in/G, KH, KW]
        // For group g, output channels are [g*out_ch_per_group, (g+1)*out_ch_per_group)
        let kernel_offset = g * out_ch_per_group * in_ch_per_group * 9;
        let kernel_size = out_ch_per_group * in_ch_per_group * 9;
        let group_kernel = &kernel[kernel_offset..kernel_offset + kernel_size];

        cache.add_winograd_filter(
            FilterId(g as u32),
            group_kernel,
            [out_ch_per_group, in_ch_per_group, 3, 3],
            WinogradVariant::F23,
        );
    }

    // Process each (batch, group) pair
    for n in 0..batch {
        for g in 0..groups {
            let prepacked = cache
                .get_winograd_filter(FilterId(g as u32))
                .ok_or_else(|| BackendError::execution("Winograd filter not found"))?;

            // Extract input channels for this group
            // Input layout: [N, C_in, H, W]
            let in_offset = n * in_chw + g * in_ch_per_group * in_hw;
            let group_input = &input[in_offset..in_offset + in_ch_per_group * in_hw];

            // Temporary output buffer for this group
            let group_output_size = out_ch_per_group * out_hw;
            let mut group_output = vec![0.0f32; group_output_size];

            // Get bias slice for this group
            let group_bias = bias.map(|b| {
                let bias_offset = g * out_ch_per_group;
                &b[bias_offset..bias_offset + out_ch_per_group]
            });

            // Call Winograd convolution
            winograd_conv2d_f23(
                &mut group_output,
                group_input,
                prepacked,
                group_bias,
                1, // Single batch item (we're iterating over batch)
                in_ch_per_group,
                in_height,
                in_width,
                out_ch_per_group,
                out_height,
                out_width,
                pad_h,
                pad_w,
            );

            // Copy to final output
            let out_offset = n * out_chw + g * out_ch_per_group * out_hw;
            output[out_offset..out_offset + group_output_size].copy_from_slice(&group_output);
        }
    }

    Ok(())
}

// ============================================================================
// 1x1 KERNEL OPTIMIZATION (BYPASS IM2COL)
// ============================================================================

/// Sequential grouped convolution for 1x1 kernels using direct GEMM.
///
/// For 1x1 kernels, im2col is wasteful because each "patch" is just a single pixel.
/// Instead, we can directly perform GEMM:
/// - For each group: output = kernel @ input (viewed as matrices)
/// - Input [C_in/G, H*W] @ Kernel^T [C_in/G, C_out/G] = Output [C_out/G, H*W]
fn grouped_conv_1x1_sequential(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    let batch = params.input_dims[0] as usize;
    let in_channels = params.input_dims[1] as usize;
    let in_height = params.input_dims[2] as usize;
    let in_width = params.input_dims[3] as usize;
    let out_channels = params.kernel_dims[0] as usize;
    let out_dims = params.output_dims();
    let out_height = out_dims[2] as usize;
    let out_width = out_dims[3] as usize;
    let stride_h = params.stride[0] as usize;
    let stride_w = params.stride[1] as usize;
    let groups = params.groups as usize;
    let in_ch_per_group = in_channels / groups;
    let out_ch_per_group = out_channels / groups;

    let in_hw = in_height * in_width;
    let out_hw = out_height * out_width;
    let out_chw = out_channels * out_hw;

    // GEMM dimensions per group:
    // A (kernel): [C_out/G, C_in/G] - already in correct layout
    // B (input): [C_in/G, H*W] - need to handle striding
    // C (output): [C_out/G, H*W]
    let m = out_ch_per_group;
    let k = in_ch_per_group;
    let n = out_hw;

    let dispatcher = SimdDispatcher::new();

    // Preallocate buffers for strided input and GEMM output
    let needs_striding = stride_h > 1 || stride_w > 1;
    let mut strided_input = if needs_striding {
        vec![0.0f32; k * n]
    } else {
        Vec::new()
    };
    let mut gemm_output = vec![0.0f32; m * n];

    for batch_idx in 0..batch {
        for group_idx in 0..groups {
            // Kernel slice for this group: [C_out/G, C_in/G]
            let kernel_offset = group_idx * out_ch_per_group * in_ch_per_group;
            let kernel_slice = &kernel[kernel_offset..kernel_offset + m * k];

            // Input handling depends on stride
            let input_slice = if needs_striding {
                // Extract strided input samples
                let in_offset =
                    batch_idx * in_channels * in_hw + group_idx * in_ch_per_group * in_hw;
                for c in 0..k {
                    for oh in 0..out_height {
                        for ow in 0..out_width {
                            let ih = oh * stride_h;
                            let iw = ow * stride_w;
                            let in_idx = in_offset + c * in_hw + ih * in_width + iw;
                            let out_idx = c * n + oh * out_width + ow;
                            strided_input[out_idx] = input.get(in_idx).copied().unwrap_or(0.0);
                        }
                    }
                }
                &strided_input[..]
            } else {
                // Direct view - input is [C_in/G, H*W]
                let in_offset =
                    batch_idx * in_channels * in_hw + group_idx * in_ch_per_group * in_hw;
                &input[in_offset..in_offset + k * n]
            };

            // GEMM: gemm_output = kernel @ input
            dispatcher.matmul_f32(
                &mut gemm_output,
                kernel_slice,
                input_slice,
                m,
                k,
                n,
                1.0,
                0.0,
            )?;

            // Copy to output with bias addition
            let out_offset = batch_idx * out_chw + group_idx * out_ch_per_group * out_hw;
            let bias_offset = group_idx * out_ch_per_group;

            for oc in 0..out_ch_per_group {
                let bias_val = bias
                    .and_then(|b| b.get(bias_offset + oc).copied())
                    .unwrap_or(0.0);
                for spatial in 0..n {
                    let src_idx = oc * n + spatial;
                    let dst_idx = out_offset + oc * out_hw + spatial;
                    output[dst_idx] = gemm_output[src_idx] + bias_val;
                }
            }
        }
    }

    Ok(())
}

/// Parallel grouped convolution for 1x1 kernels.
#[cfg(feature = "parallel")]
fn grouped_conv_1x1_parallel(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    use rayon::prelude::*;

    let batch = params.input_dims[0] as usize;
    let in_channels = params.input_dims[1] as usize;
    let in_height = params.input_dims[2] as usize;
    let in_width = params.input_dims[3] as usize;
    let out_channels = params.kernel_dims[0] as usize;
    let out_dims = params.output_dims();
    let out_height = out_dims[2] as usize;
    let out_width = out_dims[3] as usize;
    let stride_h = params.stride[0] as usize;
    let stride_w = params.stride[1] as usize;
    let groups = params.groups as usize;
    let in_ch_per_group = in_channels / groups;
    let out_ch_per_group = out_channels / groups;

    let in_hw = in_height * in_width;
    let out_hw = out_height * out_width;
    let out_chw = out_channels * out_hw;

    let m = out_ch_per_group;
    let k = in_ch_per_group;
    let n = out_hw;

    let needs_striding = stride_h > 1 || stride_w > 1;

    // Create work items
    let work_items: Vec<(usize, usize)> = (0..batch)
        .flat_map(|b| (0..groups).map(move |g| (b, g)))
        .collect();

    // Parallel GEMM computation
    let results: Vec<Result<Vec<f32>, BackendError>> = work_items
        .par_iter()
        .map(|&(batch_idx, group_idx)| {
            let dispatcher = SimdDispatcher::new();
            let mut gemm_output = vec![0.0f32; m * n];

            // Kernel slice
            let kernel_offset = group_idx * out_ch_per_group * in_ch_per_group;
            let kernel_slice = &kernel[kernel_offset..kernel_offset + m * k];

            // Handle striding
            let input_data: Vec<f32>;
            let input_slice = if needs_striding {
                input_data = (0..k)
                    .flat_map(|c| {
                        let in_offset =
                            batch_idx * in_channels * in_hw + group_idx * in_ch_per_group * in_hw;
                        (0..out_height).flat_map(move |oh| {
                            (0..out_width).map(move |ow| {
                                let ih = oh * stride_h;
                                let iw = ow * stride_w;
                                let in_idx = in_offset + c * in_hw + ih * in_width + iw;
                                input.get(in_idx).copied().unwrap_or(0.0)
                            })
                        })
                    })
                    .collect();
                &input_data[..]
            } else {
                let in_offset =
                    batch_idx * in_channels * in_hw + group_idx * in_ch_per_group * in_hw;
                &input[in_offset..in_offset + k * n]
            };

            dispatcher.matmul_f32(
                &mut gemm_output,
                kernel_slice,
                input_slice,
                m,
                k,
                n,
                1.0,
                0.0,
            )?;

            // Add bias
            let bias_offset = group_idx * out_ch_per_group;
            for oc in 0..out_ch_per_group {
                let bias_val = bias
                    .and_then(|b| b.get(bias_offset + oc).copied())
                    .unwrap_or(0.0);
                if bias_val != 0.0 {
                    for spatial in 0..n {
                        gemm_output[oc * n + spatial] += bias_val;
                    }
                }
            }

            Ok(gemm_output)
        })
        .collect();

    // Copy results to output
    for (idx, result) in results.into_iter().enumerate() {
        let gemm_output = result?;
        let (batch_idx, group_idx) = work_items[idx];
        let out_offset = batch_idx * out_chw + group_idx * out_ch_per_group * out_hw;
        let copy_len = (out_ch_per_group * out_hw).min(gemm_output.len());
        output[out_offset..out_offset + copy_len].copy_from_slice(&gemm_output[..copy_len]);
    }

    Ok(())
}

/// Fallback for non-parallel builds.
#[cfg(not(feature = "parallel"))]
fn grouped_conv_1x1_parallel(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    grouped_conv_1x1_sequential(output, input, kernel, bias, params)
}

// ============================================================================
// DIRECT SIMD IMPLEMENTATION
// ============================================================================

/// Direct grouped convolution with SIMD vectorization.
///
/// For small cases that don't benefit from im2col, this uses SIMD to
/// vectorize over output channels.
fn grouped_conv_direct_simd(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    let cap = super::simd_dispatch::cpu_capability();

    match cap {
        #[cfg(target_arch = "x86_64")]
        super::simd_dispatch::SimdCapability::Avx512
        | super::simd_dispatch::SimdCapability::Avx2 => {
            // SAFETY: AVX2/AVX512 detected at runtime
            unsafe { grouped_conv_direct_avx2(output, input, kernel, bias, params) }
        }
        _ => grouped_conv_general(output, input, kernel, bias, params),
    }
}

/// AVX2 implementation of direct grouped convolution.
///
/// Vectorizes over 8 output channels at a time using FMA.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2", enable = "fma")]
#[allow(clippy::needless_range_loop)]
unsafe fn grouped_conv_direct_avx2(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    use core::arch::x86_64::*;

    let batch = params.input_dims[0] as usize;
    let in_channels = params.input_dims[1] as usize;
    let in_height = params.input_dims[2] as usize;
    let in_width = params.input_dims[3] as usize;
    let out_channels = params.kernel_dims[0] as usize;
    let kernel_h = params.kernel_dims[2] as usize;
    let kernel_w = params.kernel_dims[3] as usize;
    let out_dims = params.output_dims();
    let out_height = out_dims[2] as usize;
    let out_width = out_dims[3] as usize;
    let stride_h = params.stride[0] as usize;
    let stride_w = params.stride[1] as usize;
    let pad_h = params.padding[0] as usize;
    let pad_w = params.padding[1] as usize;
    let dilation_h = params.dilation[0] as usize;
    let dilation_w = params.dilation[1] as usize;
    let groups = params.groups as usize;
    let in_ch_per_group = in_channels / groups;
    let out_ch_per_group = out_channels / groups;

    let in_hw = in_height * in_width;
    let out_hw = out_height * out_width;

    // Process 8 output channels at a time
    const SIMD_WIDTH: usize = 8;

    for g in 0..groups {
        let c_in_start = g * in_ch_per_group;
        let c_out_start = g * out_ch_per_group;

        for n in 0..batch {
            // Process output channels in groups of 8
            let mut c_out_g = 0;
            while c_out_g + SIMD_WIDTH <= out_ch_per_group {
                let c_out_base = c_out_start + c_out_g;

                for oh in 0..out_height {
                    for ow in 0..out_width {
                        // Accumulator for 8 output channels
                        let mut sum = _mm256_setzero_ps();

                        // Convolution loop
                        for c_in_g in 0..in_ch_per_group {
                            let c_in = c_in_start + c_in_g;

                            for kh in 0..kernel_h {
                                for kw in 0..kernel_w {
                                    let ih = oh * stride_h + kh * dilation_h;
                                    let iw = ow * stride_w + kw * dilation_w;

                                    if ih >= pad_h
                                        && ih < in_height + pad_h
                                        && iw >= pad_w
                                        && iw < in_width + pad_w
                                    {
                                        let ih_adj = ih - pad_h;
                                        let iw_adj = iw - pad_w;

                                        let in_idx = (n * in_channels + c_in) * in_hw
                                            + ih_adj * in_width
                                            + iw_adj;

                                        if let Some(&in_val) = input.get(in_idx) {
                                            let in_vec = _mm256_set1_ps(in_val);

                                            // Load 8 kernel values for consecutive output channels
                                            // Kernel layout: [C_out, C_in/G, KH, KW]
                                            let mut k_vals = [0.0f32; 8];
                                            for i in 0..SIMD_WIDTH {
                                                let k_idx = ((c_out_base + i) * in_ch_per_group
                                                    + c_in_g)
                                                    * kernel_h
                                                    * kernel_w
                                                    + kh * kernel_w
                                                    + kw;
                                                k_vals[i] =
                                                    kernel.get(k_idx).copied().unwrap_or(0.0);
                                            }
                                            let k_vec = _mm256_loadu_ps(k_vals.as_ptr());

                                            sum = _mm256_fmadd_ps(in_vec, k_vec, sum);
                                        }
                                    }
                                }
                            }
                        }

                        // Add bias
                        if let Some(b) = bias {
                            let mut b_vals = [0.0f32; 8];
                            for i in 0..SIMD_WIDTH {
                                b_vals[i] = b.get(c_out_base + i).copied().unwrap_or(0.0);
                            }
                            let b_vec = _mm256_loadu_ps(b_vals.as_ptr());
                            sum = _mm256_add_ps(sum, b_vec);
                        }

                        // Store results
                        let mut results = [0.0f32; 8];
                        _mm256_storeu_ps(results.as_mut_ptr(), sum);
                        for i in 0..SIMD_WIDTH {
                            let out_idx =
                                (n * out_channels + c_out_base + i) * out_hw + oh * out_width + ow;
                            if out_idx < output.len() {
                                output[out_idx] = results[i];
                            }
                        }
                    }
                }
                c_out_g += SIMD_WIDTH;
            }

            // Handle remaining output channels with scalar code
            while c_out_g < out_ch_per_group {
                let c_out = c_out_start + c_out_g;

                for oh in 0..out_height {
                    for ow in 0..out_width {
                        let mut sum = 0.0f32;

                        for c_in_g in 0..in_ch_per_group {
                            let c_in = c_in_start + c_in_g;

                            for kh in 0..kernel_h {
                                for kw in 0..kernel_w {
                                    let ih = oh * stride_h + kh * dilation_h;
                                    let iw = ow * stride_w + kw * dilation_w;

                                    if ih >= pad_h
                                        && ih < in_height + pad_h
                                        && iw >= pad_w
                                        && iw < in_width + pad_w
                                    {
                                        let ih_adj = ih - pad_h;
                                        let iw_adj = iw - pad_w;

                                        let in_idx = (n * in_channels + c_in) * in_hw
                                            + ih_adj * in_width
                                            + iw_adj;
                                        let k_idx = (c_out * in_ch_per_group + c_in_g)
                                            * kernel_h
                                            * kernel_w
                                            + kh * kernel_w
                                            + kw;

                                        if let (Some(&in_v), Some(&k_v)) =
                                            (input.get(in_idx), kernel.get(k_idx))
                                        {
                                            sum += in_v * k_v;
                                        }
                                    }
                                }
                            }
                        }

                        // Add bias
                        if let Some(b) = bias {
                            if let Some(&bias_v) = b.get(c_out) {
                                sum += bias_v;
                            }
                        }

                        let out_idx = (n * out_channels + c_out) * out_hw + oh * out_width + ow;
                        if out_idx < output.len() {
                            output[out_idx] = sum;
                        }
                    }
                }
                c_out_g += 1;
            }
        }
    }

    Ok(())
}

/// Optimized grouped convolution dispatcher.
///
/// Selects the best algorithm based on parameters and executes it.
fn grouped_conv2d_f32_optimized(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    let config = select_algorithm(params);

    match config.algorithm {
        GroupedConvAlgorithm::Standard => {
            grouped_conv_standard(output, input, kernel, bias, params)
        }
        GroupedConvAlgorithm::Depthwise => {
            grouped_conv_depthwise(output, input, kernel, bias, params)
        }
        GroupedConvAlgorithm::Gemm1x1 => {
            if config.use_parallel {
                grouped_conv_1x1_parallel(output, input, kernel, bias, params)
            } else {
                grouped_conv_1x1_sequential(output, input, kernel, bias, params)
            }
        }
        GroupedConvAlgorithm::Im2ColGemm => {
            if config.use_parallel {
                grouped_conv_im2col_parallel(output, input, kernel, bias, params, &config)
            } else {
                grouped_conv_im2col_sequential(output, input, kernel, bias, params, &config)
            }
        }
        GroupedConvAlgorithm::DirectSimd => {
            grouped_conv_direct_simd(output, input, kernel, bias, params)
        }
        GroupedConvAlgorithm::Direct => grouped_conv_general(output, input, kernel, bias, params),
        GroupedConvAlgorithm::Winograd => {
            grouped_conv_winograd(output, input, kernel, bias, params)
        }
    }
}

// ============================================================================
// PUBLIC API
// ============================================================================

/// Grouped convolution dispatcher.
///
/// Routes to the most efficient implementation based on group count:
/// - G=1: standard convolution (via conv2d_f32 from simd_dispatch)
/// - G=C_in: depthwise convolution
/// - Other: G independent convolutions
pub fn grouped_conv2d_f32(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    // Validate group divisibility
    if !params.input_dims[1].is_multiple_of(params.groups) {
        return Err(BackendError::unsupported(format!(
            "input channels {} not divisible by groups {}",
            params.input_dims[1], params.groups
        )));
    }
    if !params.kernel_dims[0].is_multiple_of(params.groups) {
        return Err(BackendError::unsupported(format!(
            "output channels {} not divisible by groups {}",
            params.kernel_dims[0], params.groups
        )));
    }

    // Use optimized dispatcher which selects best algorithm
    grouped_conv2d_f32_optimized(output, input, kernel, bias, params)
}

/// Standard convolution (G=1).
fn grouped_conv_standard(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    // Convert to Conv2DParams and use standard convolution
    let conv_params = Conv2DParams::new(params.input_dims, params.kernel_dims, params.dtype)
        .with_stride(params.stride[0], params.stride[1])
        .with_padding(params.padding[0], params.padding[1])
        .with_dilation(params.dilation[0], params.dilation[1]);

    // Use existing conv2d implementation
    super::simd_dispatch::conv2d_f32_direct(output, input, kernel, bias, &conv_params)
}

/// Depthwise convolution (G=C_in).
fn grouped_conv_depthwise(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    let in_channels = params.input_dims[1];
    let out_channels = params.kernel_dims[0];
    let channel_mul = if in_channels > 0 {
        out_channels / in_channels
    } else {
        1
    };

    let depthwise_params = DepthwiseConv2DParams::new(
        params.input_dims,
        params.kernel_dims[2],
        params.kernel_dims[3],
        params.dtype,
    )
    .with_stride(params.stride[0], params.stride[1])
    .with_padding(params.padding[0], params.padding[1])
    .with_dilation(params.dilation[0], params.dilation[1])
    .with_multiplier(channel_mul);

    depthwise_conv2d_f32(output, input, kernel, bias, &depthwise_params)
}

/// General grouped convolution.
///
/// Processes G independent convolutions, each operating on C_in/G input
/// channels to produce C_out/G output channels.
fn grouped_conv_general(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    let batch = params.input_dims[0] as usize;
    let in_channels = params.input_dims[1] as usize;
    let in_height = params.input_dims[2] as usize;
    let in_width = params.input_dims[3] as usize;
    let out_channels = params.kernel_dims[0] as usize;
    let kernel_h = params.kernel_dims[2] as usize;
    let kernel_w = params.kernel_dims[3] as usize;
    let out_dims = params.output_dims();
    let out_height = out_dims[2] as usize;
    let out_width = out_dims[3] as usize;
    let stride_h = params.stride[0] as usize;
    let stride_w = params.stride[1] as usize;
    let pad_h = params.padding[0] as usize;
    let pad_w = params.padding[1] as usize;
    let dilation_h = params.dilation[0] as usize;
    let dilation_w = params.dilation[1] as usize;
    let groups = params.groups as usize;
    let in_ch_per_group = in_channels / groups;
    let out_ch_per_group = out_channels / groups;

    // Kernel layout: [C_out, C_in/G, KH, KW]
    // For group g:
    //   - Input channels: [g * in_ch_per_group, (g+1) * in_ch_per_group)
    //   - Output channels: [g * out_ch_per_group, (g+1) * out_ch_per_group)
    //   - Kernel slice: out_ch in [g * out_ch_per_group, (g+1) * out_ch_per_group)

    for g in 0..groups {
        let c_in_start = g * in_ch_per_group;
        let c_out_start = g * out_ch_per_group;

        for n in 0..batch {
            for c_out_g in 0..out_ch_per_group {
                let c_out = c_out_start + c_out_g;
                for oh in 0..out_height {
                    for ow in 0..out_width {
                        let mut sum = 0.0f32;

                        for c_in_g in 0..in_ch_per_group {
                            let c_in = c_in_start + c_in_g;
                            for kh in 0..kernel_h {
                                for kw in 0..kernel_w {
                                    let ih = oh * stride_h + kh * dilation_h;
                                    let iw = ow * stride_w + kw * dilation_w;

                                    if ih >= pad_h
                                        && ih < in_height + pad_h
                                        && iw >= pad_w
                                        && iw < in_width + pad_w
                                    {
                                        let ih_adj = ih - pad_h;
                                        let iw_adj = iw - pad_w;

                                        let in_idx = ((n * in_channels + c_in) * in_height
                                            + ih_adj)
                                            * in_width
                                            + iw_adj;

                                        // Kernel: [C_out, C_in/G, KH, KW]
                                        let k_idx = ((c_out * in_ch_per_group + c_in_g) * kernel_h
                                            + kh)
                                            * kernel_w
                                            + kw;

                                        if let (Some(&in_v), Some(&k_v)) =
                                            (input.get(in_idx), kernel.get(k_idx))
                                        {
                                            sum += in_v * k_v;
                                        }
                                    }
                                }
                            }
                        }

                        // Add bias
                        if let Some(b) = bias {
                            if let Some(&bias_v) = b.get(c_out) {
                                sum += bias_v;
                            }
                        }

                        let out_idx =
                            ((n * out_channels + c_out) * out_height + oh) * out_width + ow;
                        if out_idx < output.len() {
                            output[out_idx] = sum;
                        }
                    }
                }
            }
        }
    }

    Ok(())
}

/// Check if a GroupedConv2DParams represents valid parameters.
pub fn validate_grouped_params(params: &GroupedConv2DParams) -> Result<(), BackendError> {
    if params.groups == 0 {
        return Err(BackendError::unsupported("groups must be at least 1"));
    }
    if !params.input_dims[1].is_multiple_of(params.groups) {
        return Err(BackendError::unsupported(format!(
            "input channels {} not divisible by groups {}",
            params.input_dims[1], params.groups
        )));
    }
    if !params.kernel_dims[0].is_multiple_of(params.groups) {
        return Err(BackendError::unsupported(format!(
            "output channels {} not divisible by groups {}",
            params.kernel_dims[0], params.groups
        )));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_isa::Type;

    #[test]
    fn test_grouped_as_standard() {
        // G=1 should behave like standard convolution
        let params = GroupedConv2DParams::new([1, 2, 4, 4], [2, 2, 3, 3], 1, Type::F32);

        let input = vec![1.0f32; 32]; // 2 channels × 4×4
        let kernel = vec![1.0f32; 36]; // 2 out × 2 in × 3×3
        let mut output = vec![0.0f32; 8]; // 2 channels × 2×2

        grouped_conv2d_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Each output: sum of 2×9 = 18 ones
        for val in &output {
            assert!((val - 18.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_grouped_as_depthwise() {
        // G=C_in should behave like depthwise convolution
        let params = GroupedConv2DParams::new([1, 2, 4, 4], [2, 1, 3, 3], 2, Type::F32);

        let input = vec![1.0f32; 32];
        let kernel = vec![1.0f32; 18]; // 2 channels × 9
        let mut output = vec![0.0f32; 8];

        grouped_conv2d_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Each output: sum of 9 ones
        for val in &output {
            assert!((val - 9.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_grouped_two_groups() {
        // 4 input channels, 4 output channels, 2 groups
        // Each group processes 2→2 channels
        let params = GroupedConv2DParams::new([1, 4, 4, 4], [4, 2, 3, 3], 2, Type::F32);

        let input = vec![1.0f32; 64];
        let kernel = vec![1.0f32; 72]; // 4 out × 2 in × 3×3
        let mut output = vec![0.0f32; 16]; // 4 channels × 2×2

        grouped_conv2d_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Each output: sum of 2×9 = 18 ones
        for val in &output {
            assert!((val - 18.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_grouped_with_bias() {
        let params = GroupedConv2DParams::new([1, 2, 4, 4], [2, 1, 3, 3], 2, Type::F32);

        let input = vec![1.0f32; 32];
        let kernel = vec![1.0f32; 18];
        let bias = vec![10.0, 20.0]; // different bias per output channel
        let mut output = vec![0.0f32; 8];

        grouped_conv2d_f32(&mut output, &input, &kernel, Some(&bias), &params).unwrap();

        // Channel 0: 9 + 10 = 19
        // Channel 1: 9 + 20 = 29
        assert!((output[0] - 19.0).abs() < 1e-5);
        assert!((output[4] - 29.0).abs() < 1e-5);
    }

    #[test]
    fn test_validate_grouped_params() {
        // Valid params
        let valid = GroupedConv2DParams::new([1, 4, 4, 4], [4, 2, 3, 3], 2, Type::F32);
        assert!(validate_grouped_params(&valid).is_ok());

        // Invalid: input channels not divisible by groups
        let invalid_in = GroupedConv2DParams::new([1, 3, 4, 4], [3, 1, 3, 3], 2, Type::F32);
        assert!(validate_grouped_params(&invalid_in).is_err());

        // Invalid: output channels not divisible by groups
        let invalid_out = GroupedConv2DParams::new([1, 4, 4, 4], [3, 2, 3, 3], 2, Type::F32);
        assert!(validate_grouped_params(&invalid_out).is_err());
    }

    #[test]
    fn test_grouped_independence() {
        // Verify groups are independent: changing one group's input
        // should not affect another group's output
        let params = GroupedConv2DParams::new([1, 4, 2, 2], [4, 2, 1, 1], 2, Type::F32);

        // Group 0: channels 0,1 all ones
        // Group 1: channels 2,3 all zeros
        let mut input = vec![0.0f32; 16];
        for item in input.iter_mut().take(8) {
            *item = 1.0; // channels 0,1
        }

        let kernel = vec![1.0f32; 8]; // identity-ish
        let mut output = vec![0.0f32; 16];

        grouped_conv2d_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Group 0 outputs should be 2 (sum of 2 input channels)
        // Group 1 outputs should be 0
        for item in output.iter().take(8) {
            assert!((*item - 2.0).abs() < 1e-5, "group 0 should be 2");
        }
        for item in output.iter().take(16).skip(8) {
            assert!((*item).abs() < 1e-5, "group 1 should be 0");
        }
    }

    // ========================================================================
    // OPTIMIZATION PATH TESTS
    // ========================================================================

    #[test]
    fn test_algorithm_selection_standard() {
        // G=1 should select Standard algorithm
        let params = GroupedConv2DParams::new([1, 64, 56, 56], [64, 64, 3, 3], 1, Type::F32);
        let config = select_algorithm(&params);
        assert_eq!(config.algorithm, GroupedConvAlgorithm::Standard);
    }

    #[test]
    fn test_algorithm_selection_depthwise() {
        // G=C_in should select Depthwise algorithm
        let params = GroupedConv2DParams::new([1, 64, 56, 56], [64, 1, 3, 3], 64, Type::F32);
        let config = select_algorithm(&params);
        assert_eq!(config.algorithm, GroupedConvAlgorithm::Depthwise);
    }

    #[test]
    fn test_algorithm_selection_im2col_gemm() {
        // General grouped conv with enough work should select Im2ColGemm
        // Use 5x5 kernel to avoid Winograd (only 3x3 triggers Winograd)
        // Need gemm_work >= 256 (GEMM_MIN_WORK)
        // gemm_work = out_ch_per_group * k = out_ch_per_group * (in_ch_per_group * kh * kw)
        // With 8 groups, 64 in/out channels: out_ch_per_group=8, in_ch_per_group=8
        // k = 8 * 5 * 5 = 200, gemm_work = 8 * 200 = 1600 >= 256
        let params = GroupedConv2DParams::new([1, 64, 28, 28], [64, 8, 5, 5], 8, Type::F32);
        let config = select_algorithm(&params);
        assert_eq!(config.algorithm, GroupedConvAlgorithm::Im2ColGemm);
    }

    #[test]
    fn test_algorithm_selection_direct() {
        // Small grouped conv should fall back to Direct (scalar)
        // Conditions for Direct:
        // - Not 1x1 (would use Gemm1x1)
        // - gemm_work < 256 (won't use Im2ColGemm)
        // - out_ch_per_group < 8 (won't use DirectSimd)
        //
        // With 4 groups, 8 channels: out_ch_per_group=2, in_ch_per_group=2
        // Using 2x2 kernel: k = 2 * 4 = 8, gemm_work = 2 * 8 = 16 < 256
        let params = GroupedConv2DParams::new([1, 8, 4, 4], [8, 2, 2, 2], 4, Type::F32);
        let config = select_algorithm(&params);
        assert_eq!(config.algorithm, GroupedConvAlgorithm::Direct);
    }

    #[test]
    fn test_im2col_grouped_correctness() {
        // Test that im2col produces correct output for a simple case
        // Input: [1, 4, 3, 3] with 2 groups
        // Kernel: 3x3, so for each group: K = 2 * 3 * 3 = 18
        // Output: 1x1 (no padding), so N = 1
        let params = GroupedConv2DParams::new([1, 4, 3, 3], [4, 2, 3, 3], 2, Type::F32);

        // Create input where each channel has distinct values
        let mut input = vec![0.0f32; 36]; // 4 channels × 3×3
        for c in 0..4 {
            for h in 0..3 {
                for w in 0..3 {
                    input[c * 9 + h * 3 + w] = (c * 9 + h * 3 + w) as f32;
                }
            }
        }

        let out_dims = params.output_dims();
        let out_h = out_dims[2] as usize;
        let out_w = out_dims[3] as usize;
        let k = 2 * 3 * 3; // in_ch_per_group * kh * kw
        let n = out_h * out_w;

        let mut col = vec![0.0f32; k * n];
        im2col_grouped_f32(&mut col, &input, 0, 0, &params);

        // For group 0, we should have channels 0 and 1
        // With no padding and 3x3 input, 3x3 kernel, output is 1x1
        // The im2col should contain the flattened 2×3×3 = 18 values
        // from channels 0 and 1
        assert_eq!(col.len(), 18); // k=18, n=1
                                   // Channel 0 values: 0-8, Channel 1 values: 9-17
        for (i, item) in col.iter().enumerate().take(9) {
            assert_eq!(*item, i as f32, "Channel 0 element {}", i);
        }
        for i in 0..9 {
            assert_eq!(col[9 + i], (9 + i) as f32, "Channel 1 element {}", i);
        }
    }

    #[test]
    fn test_im2col_gemm_matches_direct() {
        // Test that Im2Col+GEMM produces same results as direct computation
        // Use parameters that trigger Im2ColGemm path
        let params =
            GroupedConv2DParams::new([1, 32, 8, 8], [32, 8, 3, 3], 4, Type::F32).with_padding(1, 1);

        let input: Vec<f32> = (0..32 * 8 * 8).map(|i| (i % 7) as f32 * 0.1).collect();
        let kernel: Vec<f32> = (0..32 * 8 * 9).map(|i| (i % 5) as f32 * 0.1).collect();
        let bias: Vec<f32> = (0..32).map(|i| i as f32 * 0.5).collect();

        let out_dims = params.output_dims();
        let out_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        // Compute with optimized path
        let mut output_opt = vec![0.0f32; out_size];
        grouped_conv2d_f32(&mut output_opt, &input, &kernel, Some(&bias), &params).unwrap();

        // Compute with direct path (bypass optimization)
        let mut output_direct = vec![0.0f32; out_size];
        grouped_conv_general(&mut output_direct, &input, &kernel, Some(&bias), &params).unwrap();

        // Compare results
        for (i, (opt, direct)) in output_opt.iter().zip(output_direct.iter()).enumerate() {
            assert!(
                (opt - direct).abs() < 1e-4,
                "Mismatch at {}: opt={}, direct={}",
                i,
                opt,
                direct
            );
        }
    }

    #[test]
    fn test_parallel_matches_sequential() {
        // Test that parallel and sequential paths produce identical results
        // Use large enough input to trigger parallel execution
        let params = GroupedConv2DParams::new([4, 64, 16, 16], [64, 16, 3, 3], 4, Type::F32)
            .with_padding(1, 1);

        let config = select_algorithm(&params);
        // Verify this would use parallel if enabled
        assert!(
            config.use_parallel,
            "Config should enable parallel for this size"
        );

        let input: Vec<f32> = (0..4 * 64 * 16 * 16)
            .map(|i| (i % 11) as f32 * 0.1)
            .collect();
        let kernel: Vec<f32> = (0..64 * 16 * 9).map(|i| (i % 7) as f32 * 0.1).collect();
        let bias: Vec<f32> = (0..64).map(|i| i as f32 * 0.25).collect();

        let out_dims = params.output_dims();
        let out_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        let mut output_parallel = vec![0.0f32; out_size];
        let mut output_sequential = vec![0.0f32; out_size];

        grouped_conv_im2col_parallel(
            &mut output_parallel,
            &input,
            &kernel,
            Some(&bias),
            &params,
            &config,
        )
        .unwrap();

        grouped_conv_im2col_sequential(
            &mut output_sequential,
            &input,
            &kernel,
            Some(&bias),
            &params,
            &config,
        )
        .unwrap();

        // Compare results
        for (i, (par, seq)) in output_parallel
            .iter()
            .zip(output_sequential.iter())
            .enumerate()
        {
            assert!(
                (par - seq).abs() < 1e-4,
                "Mismatch at {}: parallel={}, sequential={}",
                i,
                par,
                seq
            );
        }
    }

    #[test]
    fn test_grouped_conv_large_batch() {
        // Test with multiple batch items (no padding for simpler verification)
        let params = GroupedConv2DParams::new([8, 16, 8, 8], [16, 4, 3, 3], 4, Type::F32);

        let input = vec![1.0f32; 8 * 16 * 8 * 8];
        let kernel = vec![0.1f32; 16 * 4 * 9];

        let out_dims = params.output_dims();
        let out_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        let mut output = vec![0.0f32; out_size];
        grouped_conv2d_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // All outputs should be the same (uniform input, uniform kernel)
        // Each output = sum of (4 input channels × 9 kernel elements × 0.1 kernel value × 1.0 input)
        // = 4 × 9 × 0.1 = 3.6
        let expected = 4.0 * 9.0 * 0.1;
        for (i, val) in output.iter().enumerate() {
            assert!(
                (val - expected).abs() < 1e-4,
                "Output {} = {}, expected {}",
                i,
                val,
                expected
            );
        }
    }

    #[test]
    fn test_grouped_conv_with_stride() {
        // Test strided grouped convolution
        let params = GroupedConv2DParams::new([1, 8, 8, 8], [8, 2, 3, 3], 4, Type::F32)
            .with_stride(2, 2)
            .with_padding(1, 1);

        let input = vec![1.0f32; 8 * 8 * 8];
        let kernel = vec![1.0f32; 8 * 2 * 9];

        let out_dims = params.output_dims();
        assert_eq!(out_dims[2], 4); // Height should be 8/2 = 4
        assert_eq!(out_dims[3], 4); // Width should be 8/2 = 4

        let out_size = 8 * 4 * 4;
        let mut output = vec![0.0f32; out_size];

        grouped_conv2d_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Just verify it runs without error and produces non-zero output
        let sum: f32 = output.iter().sum();
        assert!(sum > 0.0, "Output should be non-zero");
    }

    #[test]
    fn test_grouped_conv_with_dilation() {
        // Test dilated grouped convolution
        let params = GroupedConv2DParams::new([1, 4, 8, 8], [4, 2, 3, 3], 2, Type::F32)
            .with_dilation(2, 2)
            .with_padding(2, 2);

        let input = vec![1.0f32; 4 * 8 * 8];
        let kernel = vec![1.0f32; 4 * 2 * 9];

        let out_dims = params.output_dims();
        let out_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        let mut output = vec![0.0f32; out_size];

        grouped_conv2d_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Just verify it runs without error
        let sum: f32 = output.iter().sum();
        assert!(sum > 0.0, "Output should be non-zero");
    }

    // ========================================================================
    // WINOGRAD PATH TESTS
    // ========================================================================

    #[test]
    fn test_algorithm_selection_winograd() {
        // 3x3 kernel with stride=1 and no dilation would use Winograd,
        // but Winograd is currently disabled due to filter transform overhead.
        // When Winograd is re-enabled with cached filters, this should select Winograd.
        let params = GroupedConv2DParams::new([1, 32, 14, 14], [32, 8, 3, 3], 4, Type::F32)
            .with_padding(1, 1);
        let config = select_algorithm(&params);
        // Currently falls back to Im2ColGemm since Winograd is disabled
        assert_eq!(
            config.algorithm,
            GroupedConvAlgorithm::Im2ColGemm,
            "3x3 grouped conv uses Im2ColGemm (Winograd disabled for perf)"
        );
    }

    #[test]
    fn test_algorithm_selection_no_winograd_stride() {
        // 3x3 kernel with stride > 1 should NOT use Winograd
        let params = GroupedConv2DParams::new([1, 32, 14, 14], [32, 8, 3, 3], 4, Type::F32)
            .with_stride(2, 2)
            .with_padding(1, 1);
        let config = select_algorithm(&params);
        assert_ne!(
            config.algorithm,
            GroupedConvAlgorithm::Winograd,
            "Strided conv should not use Winograd"
        );
    }

    #[test]
    fn test_algorithm_selection_no_winograd_dilation() {
        // 3x3 kernel with dilation > 1 should NOT use Winograd
        let params = GroupedConv2DParams::new([1, 32, 14, 14], [32, 8, 3, 3], 4, Type::F32)
            .with_dilation(2, 2)
            .with_padding(2, 2);
        let config = select_algorithm(&params);
        assert_ne!(
            config.algorithm,
            GroupedConvAlgorithm::Winograd,
            "Dilated conv should not use Winograd"
        );
    }

    #[test]
    fn test_algorithm_selection_no_winograd_5x5() {
        // 5x5 kernel should NOT use Winograd (only F(2,3) for 3x3 is implemented)
        let params = GroupedConv2DParams::new([1, 32, 14, 14], [32, 8, 5, 5], 4, Type::F32)
            .with_padding(2, 2);
        let config = select_algorithm(&params);
        assert_ne!(
            config.algorithm,
            GroupedConvAlgorithm::Winograd,
            "5x5 conv should not use Winograd F(2,3)"
        );
    }

    #[test]
    fn test_winograd_grouped_correctness() {
        // Test that Winograd produces correct results for grouped 3x3 conv
        // Compare against direct computation
        let params =
            GroupedConv2DParams::new([1, 16, 8, 8], [16, 4, 3, 3], 4, Type::F32).with_padding(1, 1);

        let input: Vec<f32> = (0..16 * 8 * 8).map(|i| (i % 7) as f32 * 0.1).collect();
        let kernel: Vec<f32> = (0..16 * 4 * 9).map(|i| (i % 5) as f32 * 0.1).collect();
        let bias: Vec<f32> = (0..16).map(|i| i as f32 * 0.25).collect();

        let out_dims = params.output_dims();
        let out_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        // Compute with Winograd
        let mut output_winograd = vec![0.0f32; out_size];
        grouped_conv_winograd(&mut output_winograd, &input, &kernel, Some(&bias), &params).unwrap();

        // Compute with direct path
        let mut output_direct = vec![0.0f32; out_size];
        grouped_conv_general(&mut output_direct, &input, &kernel, Some(&bias), &params).unwrap();

        // Compare results (Winograd has slightly different numerical properties)
        let mut max_diff = 0.0f32;
        for (i, (wino, direct)) in output_winograd.iter().zip(output_direct.iter()).enumerate() {
            let diff = (wino - direct).abs();
            max_diff = max_diff.max(diff);
            assert!(
                diff < 1e-3,
                "Mismatch at {}: winograd={}, direct={}, diff={}",
                i,
                wino,
                direct,
                diff
            );
        }
        // Log max difference for debugging
        assert!(
            max_diff < 1e-3,
            "Max difference {} exceeds tolerance",
            max_diff
        );
    }

    #[test]
    fn test_winograd_grouped_multiple_batches() {
        // Test Winograd with multiple batch items
        let params =
            GroupedConv2DParams::new([4, 8, 6, 6], [8, 2, 3, 3], 4, Type::F32).with_padding(1, 1);

        let input: Vec<f32> = (0..4 * 8 * 6 * 6).map(|i| (i % 11) as f32 * 0.1).collect();
        let kernel: Vec<f32> = (0..8 * 2 * 9).map(|i| (i % 7) as f32 * 0.1).collect();

        let out_dims = params.output_dims();
        let out_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        let mut output_winograd = vec![0.0f32; out_size];
        let mut output_direct = vec![0.0f32; out_size];

        grouped_conv_winograd(&mut output_winograd, &input, &kernel, None, &params).unwrap();
        grouped_conv_general(&mut output_direct, &input, &kernel, None, &params).unwrap();

        for (i, (wino, direct)) in output_winograd.iter().zip(output_direct.iter()).enumerate() {
            assert!(
                (wino - direct).abs() < 1e-3,
                "Batch mismatch at {}: winograd={}, direct={}",
                i,
                wino,
                direct
            );
        }
    }

    #[test]
    fn test_3x3_grouped_via_dispatcher() {
        // Test that the main dispatcher correctly routes 3x3 convolutions.
        // Note: Winograd is currently disabled due to filter transform overhead,
        // so this will use Im2ColGemm or Direct depending on size.
        let params = GroupedConv2DParams::new([1, 16, 10, 10], [16, 4, 3, 3], 4, Type::F32)
            .with_padding(1, 1);

        // With Winograd disabled, verify algorithm selection
        let config = select_algorithm(&params);
        // Small size (4 output channels per group) uses Direct
        assert_eq!(config.algorithm, GroupedConvAlgorithm::Direct);

        let input: Vec<f32> = (0..16 * 10 * 10).map(|i| (i % 13) as f32 * 0.1).collect();
        let kernel: Vec<f32> = (0..16 * 4 * 9).map(|i| (i % 5) as f32 * 0.1).collect();

        let out_dims = params.output_dims();
        let out_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        // Compute via main API
        let mut output_api = vec![0.0f32; out_size];
        grouped_conv2d_f32(&mut output_api, &input, &kernel, None, &params).unwrap();

        // Compute with direct for comparison
        let mut output_direct = vec![0.0f32; out_size];
        grouped_conv_general(&mut output_direct, &input, &kernel, None, &params).unwrap();

        for (i, (api, direct)) in output_api.iter().zip(output_direct.iter()).enumerate() {
            assert!(
                (api - direct).abs() < 1e-3,
                "Dispatcher mismatch at {}: api={}, direct={}",
                i,
                api,
                direct
            );
        }
    }

    // ========================================================================
    // 1x1 KERNEL FAST PATH TESTS
    // ========================================================================

    #[test]
    fn test_algorithm_selection_1x1() {
        // 1x1 kernel with enough work should select Gemm1x1
        // Need gemm_work >= 256: out_ch_per_group * in_ch_per_group >= 256
        // With 4 groups, 64 channels: out_ch_per_group=16, in_ch_per_group=16
        // gemm_work = 16 * 16 = 256 >= 256
        let params = GroupedConv2DParams::new([1, 64, 28, 28], [64, 16, 1, 1], 4, Type::F32);
        let config = select_algorithm(&params);
        assert_eq!(
            config.algorithm,
            GroupedConvAlgorithm::Gemm1x1,
            "1x1 grouped conv should use Gemm1x1"
        );
    }

    #[test]
    fn test_1x1_matches_direct() {
        // Test that 1x1 GEMM produces same results as direct computation
        let params = GroupedConv2DParams::new([2, 32, 8, 8], [32, 8, 1, 1], 4, Type::F32);

        // Verify 1x1 path is selected
        let config = select_algorithm(&params);
        assert_eq!(config.algorithm, GroupedConvAlgorithm::Gemm1x1);

        let input: Vec<f32> = (0..2 * 32 * 8 * 8).map(|i| (i % 7) as f32 * 0.1).collect();
        let kernel: Vec<f32> = (0..32 * 8).map(|i| (i % 5) as f32 * 0.1).collect();
        let bias: Vec<f32> = (0..32).map(|i| i as f32 * 0.25).collect();

        let out_dims = params.output_dims();
        let out_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        // Compute with 1x1 optimized path
        let mut output_opt = vec![0.0f32; out_size];
        grouped_conv2d_f32(&mut output_opt, &input, &kernel, Some(&bias), &params).unwrap();

        // Compute with direct path
        let mut output_direct = vec![0.0f32; out_size];
        grouped_conv_general(&mut output_direct, &input, &kernel, Some(&bias), &params).unwrap();

        // Compare results
        for (i, (opt, direct)) in output_opt.iter().zip(output_direct.iter()).enumerate() {
            assert!(
                (opt - direct).abs() < 1e-4,
                "1x1 mismatch at {}: opt={}, direct={}",
                i,
                opt,
                direct
            );
        }
    }

    #[test]
    fn test_1x1_with_stride() {
        // Test 1x1 convolution with stride > 1
        let params = GroupedConv2DParams::new([1, 32, 16, 16], [32, 8, 1, 1], 4, Type::F32)
            .with_stride(2, 2);

        let input: Vec<f32> = (0..32 * 16 * 16).map(|i| (i % 11) as f32 * 0.1).collect();
        let kernel: Vec<f32> = (0..32 * 8).map(|i| (i % 7) as f32 * 0.1).collect();

        let out_dims = params.output_dims();
        assert_eq!(out_dims[2], 8); // Height should be 16/2 = 8
        assert_eq!(out_dims[3], 8); // Width should be 16/2 = 8

        let out_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        let mut output_opt = vec![0.0f32; out_size];
        let mut output_direct = vec![0.0f32; out_size];

        grouped_conv2d_f32(&mut output_opt, &input, &kernel, None, &params).unwrap();
        grouped_conv_general(&mut output_direct, &input, &kernel, None, &params).unwrap();

        for (i, (opt, direct)) in output_opt.iter().zip(output_direct.iter()).enumerate() {
            assert!(
                (opt - direct).abs() < 1e-4,
                "1x1 stride mismatch at {}: opt={}, direct={}",
                i,
                opt,
                direct
            );
        }
    }

    // ========================================================================
    // DIRECT SIMD PATH TESTS
    // ========================================================================

    #[test]
    fn test_algorithm_selection_direct_simd() {
        // DirectSimd is used for non-1x1 kernels where:
        // - gemm_work < GEMM_MIN_WORK (256)
        // - out_ch_per_group >= 8
        // - Not Winograd-eligible (stride != 1 or dilation != 1 or not 3x3)
        //
        // 4 groups, 32 channels: out_ch_per_group=8, in_ch_per_group=8
        // 2x2 kernel (not 3x3, so no Winograd): k = 8 * 4 = 32
        // gemm_work = 8 * 32 = 256, exactly at threshold -> Im2ColGemm
        //
        // Let's use even smaller: 8 groups, 64 channels, 2x2 kernel
        // out_ch_per_group = 8, in_ch_per_group = 8
        // k = 8 * 4 = 32, gemm_work = 8 * 32 = 256 still at threshold
        //
        // Use 4 groups, 32 channels, 2x2 kernel with dilation=2 to disable Winograd
        // out_ch_per_group = 8, in_ch_per_group = 8
        // k = 8 * 4 = 32, gemm_work = 8 * 32 = 256 at threshold
        //
        // Need gemm_work < 256: use smaller kernel or fewer channels per group
        // 8 groups, 64 channels, 2x2: out_ch/g=8, in_ch/g=8, k=8*4=32, gemm_work=256
        // 16 groups, 64 channels, 2x2: out_ch/g=4, in_ch/g=4, k=4*4=16, gemm_work=64 < 256
        // But out_ch_per_group=4 < 8, so it would be Direct not DirectSimd
        //
        // Alternative: Use small 2x2 kernel with many groups
        // 2 groups, 16 channels: out_ch/g=8, in_ch/g=8, k=8*4=32, gemm=256 boundary
        // 2 groups, 12 channels: out_ch/g=6 < 8, won't work
        //
        // Use 3x3 with stride=2 to disable Winograd
        // 2 groups, 16 channels, 3x3, stride=2
        // k = 8 * 9 = 72, gemm_work = 8 * 72 = 576 >= 256 -> Im2ColGemm
        //
        // Let's use 2 groups, 16 channels, 2x2 kernel
        // k = 8 * 4 = 32, gemm_work = 8 * 32 = 256 exactly
        // Need gemm_work < 256, so use 1x2 kernel:
        // k = 8 * 2 = 16, gemm_work = 8 * 16 = 128 < 256, out_ch/g = 8 >= 8
        let params = GroupedConv2DParams::new([1, 16, 8, 8], [16, 8, 1, 2], 2, Type::F32);
        let config = select_algorithm(&params);
        assert_eq!(
            config.algorithm,
            GroupedConvAlgorithm::DirectSimd,
            "Small 1x2 grouped conv with 8+ out channels should use DirectSimd"
        );
    }

    #[test]
    fn test_direct_simd_matches_scalar() {
        // Test that DirectSimd produces same results as scalar
        let params =
            GroupedConv2DParams::new([1, 16, 4, 4], [16, 8, 3, 3], 2, Type::F32).with_padding(1, 1);

        let input: Vec<f32> = (0..16 * 4 * 4).map(|i| (i % 7) as f32 * 0.1).collect();
        let kernel: Vec<f32> = (0..16 * 8 * 9).map(|i| (i % 5) as f32 * 0.1).collect();
        let bias: Vec<f32> = (0..16).map(|i| i as f32 * 0.25).collect();

        let out_dims = params.output_dims();
        let out_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        // Compute via dispatcher (may use DirectSimd depending on CPU)
        let mut output_opt = vec![0.0f32; out_size];
        grouped_conv2d_f32(&mut output_opt, &input, &kernel, Some(&bias), &params).unwrap();

        // Compute with direct scalar
        let mut output_direct = vec![0.0f32; out_size];
        grouped_conv_general(&mut output_direct, &input, &kernel, Some(&bias), &params).unwrap();

        for (i, (opt, direct)) in output_opt.iter().zip(output_direct.iter()).enumerate() {
            assert!(
                (opt - direct).abs() < 1e-4,
                "DirectSimd mismatch at {}: opt={}, direct={}",
                i,
                opt,
                direct
            );
        }
    }
}
