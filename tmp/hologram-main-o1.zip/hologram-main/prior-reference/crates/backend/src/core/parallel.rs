//! Graph parallelism infrastructure for parallel execution of independent operations.
//!
//! This module provides dependency analysis and parallel execution infrastructure
//! that enables concurrent execution of independent operations in a computation graph.
//!
//! # Concept
//!
//! Operations in a graph can be organized into "execution levels" where all
//! operations at the same level have no dependencies on each other and can
//! run in parallel:
//!
//! ```text
//!      Input
//!      /   \
//!   MatMul  MatMul   ← Level 1 (parallel)
//!      \   /
//!      Add          ← Level 2 (sequential after level 1)
//!       |
//!     Output
//! ```
//!
//! # Usage
//!
//! ```ignore
//! use hologram_backend::core::parallel::{ExecutionLevel, DependencyGraph};
//!
//! // Build dependency graph from operations
//! let mut graph = DependencyGraph::new();
//! graph.add_op(0, &[]);           // Input - no deps
//! graph.add_op(1, &[0]);          // MatMul1 depends on input
//! graph.add_op(2, &[0]);          // MatMul2 depends on input
//! graph.add_op(3, &[1, 2]);       // Add depends on both MatMuls
//!
//! // Compute execution levels
//! let levels = graph.compute_levels();
//! // Level 0: [0]        - Input
//! // Level 1: [1, 2]     - MatMul1, MatMul2 (parallel)
//! // Level 2: [3]        - Add
//! ```

use rustc_hash::{FxHashMap, FxHashSet};

/// A unique identifier for an operation in the graph.
pub type OpId = u32;

/// An execution level containing operations that can run in parallel.
#[derive(Clone, Debug)]
pub struct ExecutionLevel {
    /// Operations at this level (can run in parallel).
    pub ops: Vec<OpId>,
    /// Whether this level has multiple ops (can benefit from parallelism).
    pub can_parallel: bool,
}

impl ExecutionLevel {
    /// Create a new execution level with the given operations.
    pub fn new(ops: Vec<OpId>) -> Self {
        let can_parallel = ops.len() > 1;
        Self { ops, can_parallel }
    }

    /// Check if this level is empty.
    pub fn is_empty(&self) -> bool {
        self.ops.is_empty()
    }

    /// Get the number of operations at this level.
    pub fn len(&self) -> usize {
        self.ops.len()
    }
}

/// A dependency graph for operations.
///
/// Tracks which operations depend on which other operations,
/// enabling computation of parallel execution levels.
#[derive(Clone, Debug, Default)]
pub struct DependencyGraph {
    /// Forward edges: op -> list of ops that depend on it
    dependents: FxHashMap<OpId, Vec<OpId>>,
    /// Backward edges: op -> list of ops it depends on
    dependencies: FxHashMap<OpId, Vec<OpId>>,
    /// All operation IDs in the graph
    all_ops: FxHashSet<OpId>,
}

impl DependencyGraph {
    /// Create a new empty dependency graph.
    pub fn new() -> Self {
        Self::default()
    }

    /// Add an operation with its dependencies.
    ///
    /// # Arguments
    ///
    /// * `op` - The operation ID to add
    /// * `deps` - IDs of operations this op depends on
    pub fn add_op(&mut self, op: OpId, deps: &[OpId]) {
        self.all_ops.insert(op);
        self.dependencies.insert(op, deps.to_vec());

        // Add forward edges
        for &dep in deps {
            self.all_ops.insert(dep);
            self.dependents.entry(dep).or_default().push(op);
        }

        // Ensure op has an entry in dependents even if empty
        self.dependents.entry(op).or_default();
    }

    /// Get the dependencies of an operation.
    pub fn get_dependencies(&self, op: OpId) -> &[OpId] {
        self.dependencies.get(&op).map_or(&[], |v| v.as_slice())
    }

    /// Get operations that depend on this operation.
    pub fn get_dependents(&self, op: OpId) -> &[OpId] {
        self.dependents.get(&op).map_or(&[], |v| v.as_slice())
    }

    /// Check if an operation has no dependencies (is a root/input).
    pub fn is_root(&self, op: OpId) -> bool {
        self.dependencies.get(&op).is_none_or(|d| d.is_empty())
    }

    /// Check if an operation has no dependents (is a leaf/output).
    pub fn is_leaf(&self, op: OpId) -> bool {
        self.dependents.get(&op).is_none_or(|d| d.is_empty())
    }

    /// Get all operation IDs in the graph.
    pub fn ops(&self) -> impl Iterator<Item = OpId> + '_ {
        self.all_ops.iter().copied()
    }

    /// Get the number of operations in the graph.
    pub fn len(&self) -> usize {
        self.all_ops.len()
    }

    /// Check if the graph is empty.
    pub fn is_empty(&self) -> bool {
        self.all_ops.is_empty()
    }

    /// Compute execution levels for parallel execution.
    ///
    /// Returns a list of levels, where operations within each level
    /// can be executed in parallel. Levels must be executed in order.
    pub fn compute_levels(&self) -> Vec<ExecutionLevel> {
        if self.all_ops.is_empty() {
            return Vec::new();
        }

        let mut levels = Vec::new();
        let mut remaining: FxHashSet<OpId> = self.all_ops.clone();
        let mut completed: FxHashSet<OpId> = FxHashSet::default();

        while !remaining.is_empty() {
            // Find all ops whose dependencies are all completed
            let ready: Vec<OpId> = remaining
                .iter()
                .filter(|&op| {
                    self.get_dependencies(*op)
                        .iter()
                        .all(|dep| completed.contains(dep))
                })
                .copied()
                .collect();

            if ready.is_empty() {
                // This shouldn't happen in a valid DAG - would indicate a cycle
                // For safety, break to avoid infinite loop
                break;
            }

            // These form a parallel execution level
            levels.push(ExecutionLevel::new(ready.clone()));

            // Mark as completed and remove from remaining
            for op in ready {
                remaining.remove(&op);
                completed.insert(op);
            }
        }

        levels
    }

    /// Compute the critical path length (longest dependency chain).
    ///
    /// This is useful for estimating the minimum execution time
    /// with unlimited parallelism.
    pub fn critical_path_length(&self) -> usize {
        self.compute_levels().len()
    }

    /// Compute the maximum available parallelism.
    ///
    /// Returns the maximum number of operations that can run
    /// in parallel at any level.
    pub fn max_parallelism(&self) -> usize {
        self.compute_levels()
            .iter()
            .map(|level| level.len())
            .max()
            .unwrap_or(0)
    }
}

/// Statistics about graph parallelism.
#[derive(Clone, Debug, Default)]
pub struct ParallelismStats {
    /// Total number of operations.
    pub total_ops: usize,
    /// Number of execution levels.
    pub num_levels: usize,
    /// Maximum parallelism (widest level).
    pub max_parallelism: usize,
    /// Average parallelism across levels.
    pub avg_parallelism: f32,
    /// Number of levels with parallelism > 1.
    pub parallel_levels: usize,
}

impl ParallelismStats {
    /// Compute statistics from a dependency graph.
    pub fn from_graph(graph: &DependencyGraph) -> Self {
        let levels = graph.compute_levels();
        let total_ops = graph.len();
        let num_levels = levels.len();
        let max_parallelism = levels.iter().map(|l| l.len()).max().unwrap_or(0);
        let parallel_levels = levels.iter().filter(|l| l.can_parallel).count();
        let avg_parallelism = if num_levels > 0 {
            total_ops as f32 / num_levels as f32
        } else {
            0.0
        };

        Self {
            total_ops,
            num_levels,
            max_parallelism,
            avg_parallelism,
            parallel_levels,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_empty_graph() {
        let graph = DependencyGraph::new();
        let levels = graph.compute_levels();
        assert!(levels.is_empty());
    }

    #[test]
    fn test_single_op() {
        let mut graph = DependencyGraph::new();
        graph.add_op(0, &[]);

        let levels = graph.compute_levels();
        assert_eq!(levels.len(), 1);
        assert_eq!(levels[0].ops, vec![0]);
        assert!(!levels[0].can_parallel);
    }

    #[test]
    fn test_sequential_chain() {
        let mut graph = DependencyGraph::new();
        graph.add_op(0, &[]);
        graph.add_op(1, &[0]);
        graph.add_op(2, &[1]);

        let levels = graph.compute_levels();
        assert_eq!(levels.len(), 3);
        assert_eq!(levels[0].ops, vec![0]);
        assert_eq!(levels[1].ops, vec![1]);
        assert_eq!(levels[2].ops, vec![2]);

        // No parallelism in a chain
        assert!(!levels.iter().any(|l| l.can_parallel));
    }

    #[test]
    fn test_parallel_ops() {
        let mut graph = DependencyGraph::new();
        graph.add_op(0, &[]); // Input
        graph.add_op(1, &[0]); // Branch 1
        graph.add_op(2, &[0]); // Branch 2
        graph.add_op(3, &[1, 2]); // Merge

        let levels = graph.compute_levels();
        assert_eq!(levels.len(), 3);

        // Level 0: Input
        assert_eq!(levels[0].ops, vec![0]);

        // Level 1: Both branches (parallel)
        assert_eq!(levels[1].ops.len(), 2);
        assert!(levels[1].ops.contains(&1));
        assert!(levels[1].ops.contains(&2));
        assert!(levels[1].can_parallel);

        // Level 2: Merge
        assert_eq!(levels[2].ops, vec![3]);
    }

    #[test]
    fn test_diamond_graph() {
        // Diamond: A -> B, C -> D
        //          A ---------> D
        let mut graph = DependencyGraph::new();
        graph.add_op(0, &[]); // A
        graph.add_op(1, &[0]); // B
        graph.add_op(2, &[0]); // C
        graph.add_op(3, &[1, 2]); // D

        let stats = ParallelismStats::from_graph(&graph);
        assert_eq!(stats.total_ops, 4);
        assert_eq!(stats.num_levels, 3);
        assert_eq!(stats.max_parallelism, 2);
        assert_eq!(stats.parallel_levels, 1);
    }

    #[test]
    fn test_wide_parallel() {
        // Many independent ops from single input
        let mut graph = DependencyGraph::new();
        graph.add_op(0, &[]); // Input
        for i in 1..=10 {
            graph.add_op(i, &[0]); // 10 parallel ops
        }
        graph.add_op(11, &[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]); // Merge

        let levels = graph.compute_levels();
        assert_eq!(levels.len(), 3);
        assert_eq!(levels[1].len(), 10);
        assert!(levels[1].can_parallel);
        assert_eq!(graph.max_parallelism(), 10);
    }

    #[test]
    fn test_critical_path() {
        let mut graph = DependencyGraph::new();
        // Long chain: 0 -> 1 -> 2 -> 3 -> 4
        for i in 0..5 {
            if i == 0 {
                graph.add_op(i, &[]);
            } else {
                graph.add_op(i, &[i - 1]);
            }
        }

        assert_eq!(graph.critical_path_length(), 5);
    }

    #[test]
    fn test_dependencies_and_dependents() {
        let mut graph = DependencyGraph::new();
        graph.add_op(0, &[]);
        graph.add_op(1, &[0]);
        graph.add_op(2, &[0]);
        graph.add_op(3, &[1, 2]);

        assert!(graph.is_root(0));
        assert!(!graph.is_root(1));
        assert!(graph.is_leaf(3));
        assert!(!graph.is_leaf(0));

        assert_eq!(graph.get_dependencies(3), &[1, 2]);
        assert!(graph.get_dependents(0).contains(&1));
        assert!(graph.get_dependents(0).contains(&2));
    }
}
