# Backlog & Icebox

This file tracks future work items that are not part of the current sprint.

## Backlog (Prioritized Future Work)

Items here are validated and ready to be pulled into a sprint when capacity allows.

---

### UniFFI Python Bindings

**Goal**: Add UniFFI support to `crates/ffi` for native Python bindings.

**Context**: Current FFI supports C (cbindgen) and WASM (wasm-bindgen). UniFFI would provide:
- Native Python bindings without ctypes overhead
- Ruby, Kotlin, Swift support
- Automatic type marshaling

**Blocked by**: Evaluating if ctypes-over-C is sufficient for Python use cases.

---

### GPU SHA-256 Mining Kernel (TASK-337)

**Goal**: Implement SHA-256 double-hash as CUDA kernel. Bitcoin mining inner loop maps perfectly to GPU: uniform control flow, no divergence, trivially parallel. Target: order-of-magnitude throughput over CPU on discrete GPU.

**Blocked by**: CUDA runtime not available in current development environment.

**Source**: Sprint 34 backlog.

---

### Stratum v2 Pool Protocol (TASK-338)

**Goal**: Implement Stratum v2 client for connecting to mining pools. Enables real-world mining benchmarking against actual difficulty targets and measures end-to-end throughput including network overhead.

**Blocked by**: Lower priority than core performance and codegen infrastructure.

**Source**: Sprint 34 backlog.

---

### Full GPU Backend Implementation

**Goal**: Implement actual CUDA/Metal kernel execution for ISA operations.

**Blocked by**: External SDKs not available in development environment.

**Current state**: GPU backends have skeleton implementations with kernel templates (17 tests each, all returning NotImplemented).

---

## Icebox (Ideas / Not Yet Validated)

Items here are ideas that need further investigation before becoming backlog items.

### ONNX Import Improvements

- Better operator coverage
- Custom op support
- Model optimization during import

### Distributed Execution Enhancements

- Actual P2P layer fetching (currently placeholder)
- Worker auto-discovery
- Load balancing strategies

### Performance Profiling Tools

- Flamegraph integration
- Memory usage analysis

### Documentation

- API reference generation
- Tutorial content
- Architecture diagrams

---

## Archive (Completed or Dropped)

### Dependency Audit (Moved to Sprint 27)

**Goal**: Audit all external dependencies and minimize supply chain surface.

**Task**: TASK-223 -- Expanded into TASK-270 through TASK-275 in Sprint 27.

---

Items moved here for historical reference.

### SHA-256 Self-Hosting (Completed - Sprint 25)

**Goal**: Replace external `sha2` crate with internal implementation.

**Result**: Created standalone `hologram-sha256` crate with hardware acceleration (SHA-NI on x86_64, ARM SHA-2 on aarch64). Integrated across 4 crates.

**Commits**: 22a37ab

---

### SHA-256 Reversible Compression Resolver (Completed - Sprint 25)

**Goal**: Implement UOR Framework Vector 2 - the SHA-256 reversible compression resolver.

**Result**: Created `hologram-resolver` crate with TypedDatum, CompressedReference, compress/decompress functions, entropy checks, roundtrip verification. Added ontology definitions to JSON-LD.

**Commits**: 6375d00

---

### Large Match Statement Refactoring (Completed)

**Goal**: Reduce duplicate ~400-line match statements in CPU `dispatch.rs` and WASM `wasm.rs`.

**Solution**: Created unified `InstructionDispatcher` trait with ~50 operation methods. Both CPU (`ExecutionContext`) and WASM (`WasmDispatcher`) implement this trait. Single `dispatch()` function works for any backend implementing the trait.

**Result**: ~370 lines of duplicate match code removed from WASM. CPU dispatch already used this pattern. Adding new backends now only requires implementing the trait.

**Completed**: Sprint 21, commit 00ea58d.

---

### Kernel Override Hooks (Completed)

**Goal**: Enable external crates to inject optimized kernel implementations without forking hologram.

**Solution**: Added `KernelOverride` trait to `hologram-backend`. External crates can register implementations for MatMul, BatchMatMul, Softmax, LayerNorm via `register_kernel_override()`.

**Completed**: Sprint 21, TASK-216. See `specs/plans/9-kernel-override.md`.
