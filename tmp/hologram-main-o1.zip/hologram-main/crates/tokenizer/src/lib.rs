//! Tokenization support for hologram.
//!
//! This crate provides SentencePiece/BPE tokenizers that compile to `.holo` format
//! and execute through the hologram backend. It enables unified deployment where
//! both tokenization and model inference use the same execution runtime.
//!
//! # Architecture
//!
//! Tokenization is implemented as a fused operation that performs:
//! 1. UTF-8 decoding
//! 2. Unicode normalization (lowercase, NFKC, etc.)
//! 3. Prefix trie matching for vocabulary lookup
//! 4. Viterbi dynamic programming for optimal tokenization
//!
//! # Example
//!
//! ```ignore
//! use hologram_tokenizer::{SentencePieceTokenizer, compile_tokenizer};
//!
//! // Compile tokenizer.json to .holo format
//! compile_tokenizer("tokenizer.json", "tokenizer.holo")?;
//!
//! // Load and use the compiled tokenizer
//! let tokenizer = hologram::load("tokenizer.holo")?;
//! let tokens = tokenizer.execute(b"Hello, world!")?;
//! ```

mod compile;
mod error;
mod normalize;
mod serialization;
mod trie;
mod viterbi;
mod vocab;

pub use compile::{compile_tokenizer, CompiledTokenizer, TokenizerBuilder};
pub use error::{Result, TokenizerError};
pub use normalize::{Normalizer, NormalizerConfig, NormalizerStep};
pub use serialization::{deserialize_tokenizer, serialize_tokenizer};
pub use trie::PrefixTrie;
pub use trie::TrieMatch;
pub use viterbi::{ViterbiResult, ViterbiTokenizer};
pub use vocab::{VocabEntry, Vocabulary};

/// Special token IDs commonly used in tokenizers.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SpecialTokens {
    /// Padding token ID (typically 0).
    pub pad: u32,
    /// End of sequence token ID (typically 1).
    pub eos: u32,
    /// Unknown token ID (typically 2 or 3).
    pub unk: u32,
    /// Beginning of sequence token ID (optional).
    pub bos: Option<u32>,
}

impl Default for SpecialTokens {
    fn default() -> Self {
        Self {
            pad: 0,
            eos: 1,
            unk: 2,
            bos: None,
        }
    }
}

/// Tokenizer configuration loaded from tokenizer.json.
#[derive(Debug, Clone)]
pub struct TokenizerConfig {
    /// Vocabulary size.
    pub vocab_size: usize,
    /// Maximum sequence length.
    pub max_length: usize,
    /// Special token IDs.
    pub special_tokens: SpecialTokens,
    /// Normalizer configuration.
    pub normalizer: NormalizerConfig,
    /// Tokenizer type (sentencepiece, bpe, wordpiece).
    pub tokenizer_type: TokenizerType,
}

/// Type of tokenizer algorithm.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TokenizerType {
    /// SentencePiece Unigram model (uses Viterbi).
    SentencePieceUnigram,
    /// Byte-Pair Encoding.
    BPE,
    /// WordPiece (BERT-style).
    WordPiece,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_special_tokens_default() {
        let tokens = SpecialTokens::default();
        assert_eq!(tokens.pad, 0);
        assert_eq!(tokens.eos, 1);
        assert_eq!(tokens.unk, 2);
        assert_eq!(tokens.bos, None);
    }
}
