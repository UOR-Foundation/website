//! Async registry client for pull/push/search operations.
//!
//! This module provides an async HTTP client for interacting with the
//! Hologram layer registry.

use crate::error::AsyncError;
use crate::Result;
use serde::{Deserialize, Serialize};
use std::path::Path;
use std::time::Duration;

/// Search result from the registry.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SearchResult {
    /// Layer ID.
    pub id: String,
    /// Layer name.
    pub name: String,
    /// Layer description.
    pub description: Option<String>,
    /// Layer tags.
    pub tags: Vec<String>,
    /// Download count.
    pub downloads: Option<u64>,
}

/// Layer metadata from the registry.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerMetadata {
    /// Layer ID.
    pub id: String,
    /// Layer name.
    pub name: String,
    /// Layer version.
    pub version: String,
    /// Content hash (SHA-256).
    pub content_hash: String,
    /// Size in bytes.
    pub size: u64,
    /// Description.
    pub description: Option<String>,
    /// Author.
    pub author: Option<String>,
    /// Creation timestamp.
    pub created_at: Option<u64>,
}

/// Async registry client for pull/push/search operations.
pub struct AsyncRegistry {
    base_url: String,
    client: reqwest::Client,
    token: Option<String>,
}

impl AsyncRegistry {
    /// Create a new async registry client.
    pub fn new(base_url: impl Into<String>) -> Self {
        Self {
            base_url: base_url.into().trim_end_matches('/').to_string(),
            client: reqwest::Client::builder()
                .no_proxy()
                .timeout(Duration::from_secs(30))
                .build()
                .expect("Failed to build HTTP client"),
            token: None,
        }
    }

    /// Create a new async registry client with custom timeout.
    pub fn with_timeout(base_url: impl Into<String>, timeout: Duration) -> Self {
        Self {
            base_url: base_url.into().trim_end_matches('/').to_string(),
            client: reqwest::Client::builder()
                .no_proxy()
                .timeout(timeout)
                .build()
                .expect("Failed to build HTTP client"),
            token: None,
        }
    }

    /// Set authentication token.
    pub fn with_token(mut self, token: impl Into<String>) -> Self {
        self.token = Some(token.into());
        self
    }

    /// Get the base URL.
    pub fn base_url(&self) -> &str {
        &self.base_url
    }

    /// Check if authentication is configured.
    pub fn has_auth(&self) -> bool {
        self.token.is_some()
    }

    /// Pull a layer from the registry.
    pub async fn pull(&self, layer_id: &str, dest: &Path) -> Result<()> {
        let (name, version) = parse_layer_id(layer_id)?;
        let url = format!("{}/v1/layers/{}/{}", self.base_url, name, version);

        let mut request = self.client.get(&url);
        if let Some(token) = &self.token {
            request = request.bearer_auth(token);
        }

        let response = request.send().await?;

        if !response.status().is_success() {
            return Err(AsyncError::Http(
                response.status().as_u16(),
                format!("Pull failed for layer {}", layer_id),
            ));
        }

        let bytes = response.bytes().await?;
        tokio::fs::write(dest, bytes).await?;

        Ok(())
    }

    /// Push a layer to the registry.
    pub async fn push(&self, layer_id: &str, src: &Path) -> Result<()> {
        if self.token.is_none() {
            return Err(AsyncError::Registry(
                "Authentication required for push".to_string(),
            ));
        }

        let (name, version) = parse_layer_id(layer_id)?;
        let url = format!("{}/v1/layers/{}/{}", self.base_url, name, version);
        let bytes = tokio::fs::read(src).await?;

        let mut request = self.client.put(&url).body(bytes);
        if let Some(token) = &self.token {
            request = request.bearer_auth(token);
        }

        let response = request.send().await?;

        if !response.status().is_success() {
            return Err(AsyncError::Http(
                response.status().as_u16(),
                format!("Push failed for layer {}", layer_id),
            ));
        }

        Ok(())
    }

    /// Search for layers.
    pub async fn search(&self, query: &str) -> Result<Vec<SearchResult>> {
        let url = format!("{}/v1/search?q={}", self.base_url, urlencoded(query));

        let response = self.client.get(&url).send().await?;

        if !response.status().is_success() {
            return Err(AsyncError::Http(
                response.status().as_u16(),
                "Search failed".to_string(),
            ));
        }

        let results: Vec<SearchResult> = response.json().await?;
        Ok(results)
    }

    /// Get layer metadata.
    pub async fn metadata(&self, layer_id: &str) -> Result<LayerMetadata> {
        let (name, version) = parse_layer_id(layer_id)?;
        let url = format!("{}/v1/layers/{}/{}/metadata", self.base_url, name, version);

        let mut request = self.client.get(&url);
        if let Some(token) = &self.token {
            request = request.bearer_auth(token);
        }

        let response = request.send().await?;

        if !response.status().is_success() {
            return Err(AsyncError::Http(
                response.status().as_u16(),
                format!("Failed to get metadata for {}", layer_id),
            ));
        }

        let metadata: LayerMetadata = response.json().await?;
        Ok(metadata)
    }

    /// Check if a layer exists in the registry.
    pub async fn exists(&self, layer_id: &str) -> Result<bool> {
        let (name, version) = parse_layer_id(layer_id)?;
        let url = format!("{}/v1/layers/{}/{}/metadata", self.base_url, name, version);

        let mut request = self.client.head(&url);
        if let Some(token) = &self.token {
            request = request.bearer_auth(token);
        }

        let response = request.send().await?;
        Ok(response.status().is_success())
    }

    /// Get available tags for a layer name.
    pub async fn tags(&self, name: &str) -> Result<Vec<String>> {
        let url = format!("{}/v1/layers/{}/tags", self.base_url, name);

        let response = self.client.get(&url).send().await?;

        if !response.status().is_success() {
            return Err(AsyncError::Http(
                response.status().as_u16(),
                format!("Failed to get tags for {}", name),
            ));
        }

        let tags: Vec<String> = response.json().await?;
        Ok(tags)
    }

    /// Delete a layer from the registry (requires authentication).
    pub async fn delete(&self, layer_id: &str) -> Result<()> {
        if self.token.is_none() {
            return Err(AsyncError::Registry(
                "Authentication required for delete".to_string(),
            ));
        }

        let (name, version) = parse_layer_id(layer_id)?;
        let url = format!("{}/v1/layers/{}/{}", self.base_url, name, version);

        let mut request = self.client.delete(&url);
        if let Some(token) = &self.token {
            request = request.bearer_auth(token);
        }

        let response = request.send().await?;

        if !response.status().is_success() {
            return Err(AsyncError::Http(
                response.status().as_u16(),
                format!("Delete failed for layer {}", layer_id),
            ));
        }

        Ok(())
    }
}

/// Parse a layer ID into name and version.
fn parse_layer_id(layer_id: &str) -> Result<(String, String)> {
    if layer_id.is_empty() {
        return Err(AsyncError::Registry("Empty layer ID".to_string()));
    }

    // Try @version format
    if let Some((name, version)) = layer_id.split_once('@') {
        if name.is_empty() || version.is_empty() {
            return Err(AsyncError::Registry(format!(
                "Invalid layer ID: {}",
                layer_id
            )));
        }
        return Ok((name.to_string(), version.to_string()));
    }

    // Try :tag format
    if let Some((name, tag)) = layer_id.split_once(':') {
        if name.is_empty() || tag.is_empty() {
            return Err(AsyncError::Registry(format!(
                "Invalid layer ID: {}",
                layer_id
            )));
        }
        return Ok((name.to_string(), tag.to_string()));
    }

    // No version specified, use "latest"
    Ok((layer_id.to_string(), "latest".to_string()))
}

/// URL-encode a string.
fn urlencoded(s: &str) -> String {
    let mut result = String::with_capacity(s.len() * 3);
    for c in s.chars() {
        match c {
            'a'..='z' | 'A'..='Z' | '0'..='9' | '-' | '_' | '.' | '~' => {
                result.push(c);
            }
            _ => {
                for byte in c.to_string().bytes() {
                    result.push('%');
                    result.push_str(&format!("{:02X}", byte));
                }
            }
        }
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_async_registry_new() {
        let registry = AsyncRegistry::new("https://registry.example.com");
        assert_eq!(registry.base_url(), "https://registry.example.com");
        assert!(!registry.has_auth());
    }

    #[test]
    fn test_async_registry_trailing_slash() {
        let registry = AsyncRegistry::new("https://registry.example.com/");
        assert_eq!(registry.base_url(), "https://registry.example.com");
    }

    #[test]
    fn test_async_registry_with_token() {
        let registry =
            AsyncRegistry::new("https://registry.example.com").with_token("secret-token");
        assert!(registry.has_auth());
    }

    #[test]
    fn test_async_registry_with_timeout() {
        let registry =
            AsyncRegistry::with_timeout("https://registry.example.com", Duration::from_secs(60));
        assert_eq!(registry.base_url(), "https://registry.example.com");
    }

    #[test]
    fn test_parse_layer_id_name_only() {
        let (name, version) = parse_layer_id("bert-base").unwrap();
        assert_eq!(name, "bert-base");
        assert_eq!(version, "latest");
    }

    #[test]
    fn test_parse_layer_id_at_version() {
        let (name, version) = parse_layer_id("bert-base@v1.0").unwrap();
        assert_eq!(name, "bert-base");
        assert_eq!(version, "v1.0");
    }

    #[test]
    fn test_parse_layer_id_colon_tag() {
        let (name, version) = parse_layer_id("bert-base:latest").unwrap();
        assert_eq!(name, "bert-base");
        assert_eq!(version, "latest");
    }

    #[test]
    fn test_parse_layer_id_empty() {
        assert!(parse_layer_id("").is_err());
    }

    #[test]
    fn test_parse_layer_id_invalid_at() {
        assert!(parse_layer_id("@v1.0").is_err());
        assert!(parse_layer_id("name@").is_err());
    }

    #[test]
    fn test_parse_layer_id_invalid_colon() {
        assert!(parse_layer_id(":tag").is_err());
        assert!(parse_layer_id("name:").is_err());
    }

    #[test]
    fn test_urlencoded_plain() {
        assert_eq!(urlencoded("hello"), "hello");
        assert_eq!(urlencoded("test-name_1.0"), "test-name_1.0");
    }

    #[test]
    fn test_urlencoded_special() {
        assert_eq!(urlencoded("hello world"), "hello%20world");
        assert_eq!(urlencoded("test@example"), "test%40example");
    }

    #[test]
    fn test_search_result_deserialize() {
        let json = r#"{
            "id": "abc123",
            "name": "bert-base",
            "description": "BERT base model",
            "tags": ["nlp", "transformer"],
            "downloads": 1000
        }"#;

        let result: SearchResult = serde_json::from_str(json).unwrap();
        assert_eq!(result.id, "abc123");
        assert_eq!(result.name, "bert-base");
        assert_eq!(result.description, Some("BERT base model".to_string()));
        assert_eq!(result.tags, vec!["nlp", "transformer"]);
        assert_eq!(result.downloads, Some(1000));
    }

    #[test]
    fn test_layer_metadata_deserialize() {
        let json = r#"{
            "id": "abc123",
            "name": "bert-base",
            "version": "v1.0",
            "content_hash": "sha256:...",
            "size": 1024000,
            "description": null,
            "author": "Example Corp",
            "created_at": 1704067200
        }"#;

        let metadata: LayerMetadata = serde_json::from_str(json).unwrap();
        assert_eq!(metadata.id, "abc123");
        assert_eq!(metadata.name, "bert-base");
        assert_eq!(metadata.version, "v1.0");
        assert_eq!(metadata.size, 1024000);
        assert_eq!(metadata.author, Some("Example Corp".to_string()));
    }

    // Note: Network tests would require a mock server or integration testing
    // The following tests verify the basic API structure

    #[tokio::test]
    async fn test_async_registry_push_requires_auth() {
        let registry = AsyncRegistry::new("https://registry.example.com");
        let result = registry
            .push("test@v1.0", Path::new("/tmp/test.holo"))
            .await;
        assert!(matches!(result, Err(AsyncError::Registry(_))));
    }

    #[tokio::test]
    async fn test_async_registry_delete_requires_auth() {
        let registry = AsyncRegistry::new("https://registry.example.com");
        let result = registry.delete("test@v1.0").await;
        assert!(matches!(result, Err(AsyncError::Registry(_))));
    }
}
