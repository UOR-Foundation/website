//! Runtime configuration for telemetry.
//!
//! This module provides configuration options for telemetry export and behavior,
//! which can be set via environment variables.
//!
//! # Environment Variables
//!
//! - `HOLOGRAM_TELEMETRY_EXPORT`: Export format (`console`, `json`, `otlp`)
//! - `HOLOGRAM_TELEMETRY_ENDPOINT`: OTLP endpoint URL (default: `http://localhost:4317`)
//! - `HOLOGRAM_TELEMETRY_LEVEL`: Log level filter (`trace`, `debug`, `info`, `warn`, `error`)
//! - `HOLOGRAM_TELEMETRY_SERVICE_NAME`: Service name for OTLP (default: `hologram`)

use std::env;
use std::path::PathBuf;

/// Export format for telemetry data.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum ExportFormat {
    /// Output to console (human-readable).
    #[default]
    Console,
    /// Output to JSON file.
    Json,
    /// Output via OTLP (OpenTelemetry Protocol).
    Otlp,
}

impl ExportFormat {
    /// Parse export format from string.
    ///
    /// Returns `None` if the string doesn't match any known format.
    #[must_use]
    pub fn parse(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "console" => Some(Self::Console),
            "json" => Some(Self::Json),
            "otlp" | "opentelemetry" => Some(Self::Otlp),
            _ => None,
        }
    }

    /// Get the format as a string.
    #[must_use]
    pub const fn as_str(&self) -> &'static str {
        match self {
            Self::Console => "console",
            Self::Json => "json",
            Self::Otlp => "otlp",
        }
    }
}

/// Log level filter for telemetry.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum LogLevel {
    /// Trace level (most verbose).
    Trace,
    /// Debug level.
    Debug,
    /// Info level (default).
    #[default]
    Info,
    /// Warning level.
    Warn,
    /// Error level (least verbose).
    Error,
}

impl LogLevel {
    /// Parse log level from string.
    ///
    /// Returns `None` if the string doesn't match any known level.
    #[must_use]
    pub fn parse(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "trace" => Some(Self::Trace),
            "debug" => Some(Self::Debug),
            "info" => Some(Self::Info),
            "warn" | "warning" => Some(Self::Warn),
            "error" => Some(Self::Error),
            _ => None,
        }
    }

    /// Get the level as a string.
    #[must_use]
    pub const fn as_str(&self) -> &'static str {
        match self {
            Self::Trace => "trace",
            Self::Debug => "debug",
            Self::Info => "info",
            Self::Warn => "warn",
            Self::Error => "error",
        }
    }

    /// Convert to tracing level filter.
    #[must_use]
    pub const fn to_tracing_level(&self) -> tracing::Level {
        match self {
            Self::Trace => tracing::Level::TRACE,
            Self::Debug => tracing::Level::DEBUG,
            Self::Info => tracing::Level::INFO,
            Self::Warn => tracing::Level::WARN,
            Self::Error => tracing::Level::ERROR,
        }
    }
}

/// Telemetry configuration loaded from environment variables.
#[derive(Debug, Clone)]
pub struct TelemetryConfig {
    /// Export format (console, json, or otlp).
    pub export_format: ExportFormat,
    /// OTLP endpoint URL.
    pub otlp_endpoint: String,
    /// Log level filter.
    pub level: LogLevel,
    /// Service name for OTLP.
    pub service_name: String,
    /// JSON output file path (when using JSON export).
    pub json_output_path: Option<PathBuf>,
    /// Whether to enable ANSI colors in console output.
    pub ansi_colors: bool,
}

impl Default for TelemetryConfig {
    fn default() -> Self {
        Self {
            export_format: ExportFormat::default(),
            otlp_endpoint: "http://localhost:4317".to_string(),
            level: LogLevel::default(),
            service_name: "hologram".to_string(),
            json_output_path: None,
            ansi_colors: true,
        }
    }
}

impl TelemetryConfig {
    /// Create a new configuration with default values.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Load configuration from environment variables.
    ///
    /// Environment variables:
    /// - `HOLOGRAM_TELEMETRY_EXPORT`: Export format
    /// - `HOLOGRAM_TELEMETRY_ENDPOINT`: OTLP endpoint
    /// - `HOLOGRAM_TELEMETRY_LEVEL`: Log level
    /// - `HOLOGRAM_TELEMETRY_SERVICE_NAME`: Service name
    /// - `HOLOGRAM_TELEMETRY_JSON_PATH`: JSON output file path
    /// - `NO_COLOR`: Disable ANSI colors
    #[must_use]
    pub fn from_env() -> Self {
        let mut config = Self::default();

        if let Ok(format) = env::var("HOLOGRAM_TELEMETRY_EXPORT") {
            if let Some(f) = ExportFormat::parse(&format) {
                config.export_format = f;
            }
        }

        if let Ok(endpoint) = env::var("HOLOGRAM_TELEMETRY_ENDPOINT") {
            config.otlp_endpoint = endpoint;
        }

        if let Ok(level) = env::var("HOLOGRAM_TELEMETRY_LEVEL") {
            if let Some(l) = LogLevel::parse(&level) {
                config.level = l;
            }
        }

        if let Ok(name) = env::var("HOLOGRAM_TELEMETRY_SERVICE_NAME") {
            config.service_name = name;
        }

        if let Ok(path) = env::var("HOLOGRAM_TELEMETRY_JSON_PATH") {
            config.json_output_path = Some(PathBuf::from(path));
        }

        // Check NO_COLOR environment variable (standard for disabling colors)
        if env::var("NO_COLOR").is_ok() {
            config.ansi_colors = false;
        }

        config
    }

    /// Set the export format.
    #[must_use]
    pub fn with_export_format(mut self, format: ExportFormat) -> Self {
        self.export_format = format;
        self
    }

    /// Set the OTLP endpoint.
    #[must_use]
    pub fn with_otlp_endpoint(mut self, endpoint: impl Into<String>) -> Self {
        self.otlp_endpoint = endpoint.into();
        self
    }

    /// Set the log level.
    #[must_use]
    pub fn with_level(mut self, level: LogLevel) -> Self {
        self.level = level;
        self
    }

    /// Set the service name.
    #[must_use]
    pub fn with_service_name(mut self, name: impl Into<String>) -> Self {
        self.service_name = name.into();
        self
    }

    /// Set the JSON output path.
    #[must_use]
    pub fn with_json_output_path(mut self, path: impl Into<PathBuf>) -> Self {
        self.json_output_path = Some(path.into());
        self
    }

    /// Enable or disable ANSI colors.
    #[must_use]
    pub fn with_ansi_colors(mut self, enabled: bool) -> Self {
        self.ansi_colors = enabled;
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_export_format_parse() {
        assert_eq!(ExportFormat::parse("console"), Some(ExportFormat::Console));
        assert_eq!(ExportFormat::parse("CONSOLE"), Some(ExportFormat::Console));
        assert_eq!(ExportFormat::parse("json"), Some(ExportFormat::Json));
        assert_eq!(ExportFormat::parse("otlp"), Some(ExportFormat::Otlp));
        assert_eq!(
            ExportFormat::parse("opentelemetry"),
            Some(ExportFormat::Otlp)
        );
        assert_eq!(ExportFormat::parse("invalid"), None);
    }

    #[test]
    fn test_log_level_parse() {
        assert_eq!(LogLevel::parse("trace"), Some(LogLevel::Trace));
        assert_eq!(LogLevel::parse("DEBUG"), Some(LogLevel::Debug));
        assert_eq!(LogLevel::parse("info"), Some(LogLevel::Info));
        assert_eq!(LogLevel::parse("warn"), Some(LogLevel::Warn));
        assert_eq!(LogLevel::parse("warning"), Some(LogLevel::Warn));
        assert_eq!(LogLevel::parse("error"), Some(LogLevel::Error));
        assert_eq!(LogLevel::parse("invalid"), None);
    }

    #[test]
    fn test_config_default() {
        let config = TelemetryConfig::default();
        assert_eq!(config.export_format, ExportFormat::Console);
        assert_eq!(config.level, LogLevel::Info);
        assert_eq!(config.service_name, "hologram");
        assert!(config.ansi_colors);
    }

    #[test]
    fn test_config_builder() {
        let config = TelemetryConfig::new()
            .with_export_format(ExportFormat::Json)
            .with_level(LogLevel::Debug)
            .with_service_name("test-service")
            .with_ansi_colors(false);

        assert_eq!(config.export_format, ExportFormat::Json);
        assert_eq!(config.level, LogLevel::Debug);
        assert_eq!(config.service_name, "test-service");
        assert!(!config.ansi_colors);
    }

    #[test]
    fn test_export_format_as_str() {
        assert_eq!(ExportFormat::Console.as_str(), "console");
        assert_eq!(ExportFormat::Json.as_str(), "json");
        assert_eq!(ExportFormat::Otlp.as_str(), "otlp");
    }

    #[test]
    fn test_log_level_as_str() {
        assert_eq!(LogLevel::Trace.as_str(), "trace");
        assert_eq!(LogLevel::Debug.as_str(), "debug");
        assert_eq!(LogLevel::Info.as_str(), "info");
        assert_eq!(LogLevel::Warn.as_str(), "warn");
        assert_eq!(LogLevel::Error.as_str(), "error");
    }

    #[test]
    fn test_log_level_to_tracing_level() {
        assert_eq!(LogLevel::Trace.to_tracing_level(), tracing::Level::TRACE);
        assert_eq!(LogLevel::Debug.to_tracing_level(), tracing::Level::DEBUG);
        assert_eq!(LogLevel::Info.to_tracing_level(), tracing::Level::INFO);
        assert_eq!(LogLevel::Warn.to_tracing_level(), tracing::Level::WARN);
        assert_eq!(LogLevel::Error.to_tracing_level(), tracing::Level::ERROR);
    }

    #[test]
    fn test_config_with_otlp_endpoint() {
        let config = TelemetryConfig::new().with_otlp_endpoint("http://custom:4317");
        assert_eq!(config.otlp_endpoint, "http://custom:4317");
    }

    #[test]
    fn test_config_with_json_output_path() {
        let config = TelemetryConfig::new().with_json_output_path("/tmp/metrics.json");
        assert_eq!(
            config.json_output_path,
            Some(PathBuf::from("/tmp/metrics.json"))
        );
    }
}
