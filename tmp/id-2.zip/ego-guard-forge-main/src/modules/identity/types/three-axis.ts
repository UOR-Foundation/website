/**
 * Three-Axis Separation Types — Φ_v5 = Φ_agent · Φ_data · Φ_inference
 * ════════════════════════════════════════════════════════════════════
 *
 * From V5 Pathway §2 (M1: Three-Axis Operationalisation):
 *
 * The sovereignty duality is NOT single-axis. Three orthogonal axes multiply:
 *
 *   | Axis      | Separation                  | What It Measures                |
 *   | Agent     | Swordsman ⊥ Mage            | Privacy boundary ⊥ delegation  |
 *   | Data      | Shielded ⊥ Public providers | Storage fragmentation          |
 *   | Inference | Generator ⊥ Solver          | Planning ⊥ execution split     |
 *
 * The product captures multiplicative sovereignty: missing ANY axis = vulnerable.
 *
 * From V5 §3.1 (Compression-as-Defence):
 *   R_v5(d) = R_v4(d) · (1 - 1/compression_ratio)
 *   Every token not emitted = a token the adversary cannot intercept.
 *
 * Pure data. No classes. No side effects.
 *
 * @module identity/types/three-axis
 */

// ── Agent Axis ──────────────────────────────────────────────────────────────

/** The 4×4 agent separation matrix Σ (Swordsman ⊥ Mage roles). */
export interface AgentSeparationMatrix {
  /** Matrix entries σ_ij (4×4 = 16 values, each 0–1). */
  readonly entries: readonly number[];
  /** Determinant of Σ — aggregate separation measure. */
  readonly determinant: number;
  /** The separation ratio S/M relative to optimal κ. */
  readonly separationRatio: number;
  /** κ — the optimal ratio (candidate: φ ≈ 1.618, or derived from BRAID). */
  readonly kappa: number;
}

/** Φ_agent = min(1.0, (S/M) / κ) · det(Σ) */
export interface AgentAxisMetrics {
  readonly phi: number;               // Φ_agent (0–1)
  readonly matrix: AgentSeparationMatrix;
  readonly guardianActive: boolean;    // privacy boundary key present
  readonly delegateActive: boolean;    // delegation key present
}

// ── Data Axis ───────────────────────────────────────────────────────────────

/** A data storage provider/backend. */
export interface DataProvider {
  readonly id: string;
  readonly name: string;
  readonly type: "local" | "cloud" | "decentralized" | "federated";
  readonly edgesCovered: number;       // how many boundary edges this provider holds
}

/** Φ_data = measure of provider fragmentation. */
export interface DataAxisMetrics {
  readonly phi: number;               // Φ_data (0–1)
  readonly providerCount: number;     // number of distinct backends
  readonly fragmentationIndex: number; // Shannon entropy of edge distribution
  readonly maxSingleProviderShare: number; // largest provider's share (lower = better)
  readonly providers: readonly DataProvider[];
  readonly shieldedFraction: number;  // fraction of edges held in local-only storage
}

// ── Inference Axis ──────────────────────────────────────────────────────────

/** Φ_inference = Generator/Solver split efficiency. */
export interface InferenceAxisMetrics {
  readonly phi: number;               // Φ_inference (0–1)
  /** Compression ratio: tokens_raw / tokens_emitted (e.g. 74× from BRAID). */
  readonly compressionRatio: number;
  /** Reconstruction risk reduction: (1 - 1/compressionRatio). */
  readonly reconstructionDefence: number;
  /** Generator fraction: what portion of reasoning is planning vs execution. */
  readonly generatorFraction: number;
  /** Solver fraction: 1 - generatorFraction. */
  readonly solverFraction: number;
  /** PPD — Performance Per Dollar (from BRAID benchmarks). */
  readonly ppd: number;
  /** Whether inference is bounded (BRAID-style) or unbounded. */
  readonly bounded: boolean;
}

// ── Three-Axis Product ──────────────────────────────────────────────────────

/** The complete V5 sovereignty duality measurement. */
export interface ThreeAxisSeparation {
  readonly identityId: string;
  /** Φ_v5 = Φ_agent · Φ_data · Φ_inference */
  readonly phi_v5: number;
  readonly agent: AgentAxisMetrics;
  readonly data: DataAxisMetrics;
  readonly inference: InferenceAxisMetrics;
  /** R_v5(d) = R_v4(d) · (1 - 1/compression_ratio) — reconstruction difficulty. */
  readonly reconstructionDifficulty: number;
  /** Which axis is weakest (bottleneck). */
  readonly weakestAxis: "agent" | "data" | "inference";
  /** Sovereignty classification based on Φ_v5. */
  readonly sovereigntyLevel: "exposed" | "partial" | "separated" | "sovereign";
  readonly timestamp: number;
}

/** Configuration for three-axis computation. */
export interface ThreeAxisConfig {
  /** κ — optimal agent separation ratio (default: φ ≈ 1.618). */
  readonly kappa: number;
  /** Target compression ratio for full Φ_inference (default: 74). */
  readonly targetCompression: number;
  /** Target provider count for full Φ_data (default: 3). */
  readonly targetProviderCount: number;
  /** Target fragmentation entropy for full Φ_data (default: ln(3) ≈ 1.099). */
  readonly targetEntropy: number;
}
