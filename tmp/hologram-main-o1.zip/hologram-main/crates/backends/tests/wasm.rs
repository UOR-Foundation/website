//! WebAssembly integration tests.
//!
//! These tests run in a browser environment via wasm-pack.
//! Run with: `wasm-pack test --headless --chrome`
//!
//! # Test Coverage
//!
//! - WasmMemory utilities (page calculation, memory estimation)
//! - WasmBackend execution (arithmetic, activations, categorical ops)

#![cfg(target_arch = "wasm32")]

use wasm_bindgen_test::*;

use hologram_backend::wasm::{WasmBackend, WasmMemory, WASM_DEFAULT_MAX_MEMORY, WASM_PAGE_SIZE};
use hologram_backend::Backend;
use hologram_holo::types::{BufferMetadata, BufferType};
use hologram_holo::{BackendPlan, IsaInstruction, PlanMetadata};

wasm_bindgen_test_configure!(run_in_browser);

// ============================================================================
// Helper Functions
// ============================================================================

fn make_plan(instructions: Vec<IsaInstruction>, buffers: Vec<BufferMetadata>) -> BackendPlan {
    BackendPlan {
        instructions,
        buffers,
        constants: vec![],
        workspace_size: 0,
        dependencies: vec![],
        metadata: PlanMetadata::default(),
        node_buffer_map: vec![],
    }
}

fn make_buffer(buffer_type: BufferType, size: usize) -> BufferMetadata {
    BufferMetadata {
        buffer_type,
        size,
        alignment: 4,
        fully_written: false,
    }
}

// ============================================================================
// WasmMemory Tests
// ============================================================================

#[wasm_bindgen_test]
fn test_wasm_page_size_in_browser() {
    assert_eq!(WASM_PAGE_SIZE, 65536);
}

#[wasm_bindgen_test]
fn test_wasm_pages_needed_in_browser() {
    assert_eq!(WasmMemory::pages_needed(1), 1);
    assert_eq!(WasmMemory::pages_needed(65536), 1);
    assert_eq!(WasmMemory::pages_needed(65537), 2);
}

#[wasm_bindgen_test]
fn test_wasm_estimate_plan_memory_in_browser() {
    let buffers = vec![
        make_buffer(BufferType::Input, 1024),
        make_buffer(BufferType::Output, 2048),
    ];

    let plan = BackendPlan {
        instructions: vec![],
        buffers,
        constants: vec![0u8; 512],
        workspace_size: 256,
        dependencies: vec![],
        metadata: PlanMetadata::default(),
        node_buffer_map: vec![],
    };

    let estimate = WasmMemory::estimate_plan_memory(&plan);
    assert_eq!(estimate, 3840);
}

#[wasm_bindgen_test]
fn test_wasm_plan_fits_in_browser() {
    let buffers = vec![make_buffer(BufferType::Input, 1024)];

    let plan = BackendPlan {
        instructions: vec![],
        buffers,
        constants: vec![],
        workspace_size: 0,
        dependencies: vec![],
        metadata: PlanMetadata::default(),
        node_buffer_map: vec![],
    };

    assert!(WasmMemory::plan_fits_default(&plan));
    assert!(!WasmMemory::plan_fits(&plan, 512));
}

// ============================================================================
// WasmBackend Execution Tests
// ============================================================================

#[wasm_bindgen_test]
fn test_wasm_backend_creation_in_browser() {
    let backend = WasmBackend::new();
    assert!(WasmBackend::is_available());
    assert_eq!(backend.capabilities().vector_width, 1);
}

#[wasm_bindgen_test]
fn test_wasm_execute_empty_plan_in_browser() {
    let backend = WasmBackend::new();
    let plan = make_plan(vec![], vec![]);

    let result = backend.execute_plan(&plan, &[], &mut []);
    assert!(result.is_ok());
}

#[wasm_bindgen_test]
fn test_wasm_add_in_browser() {
    let backend = WasmBackend::new();

    let buffers = vec![
        make_buffer(BufferType::Input, 16),
        make_buffer(BufferType::Input, 16),
        make_buffer(BufferType::Output, 16),
    ];

    let plan = make_plan(
        vec![IsaInstruction::Add {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        }],
        buffers,
    );

    let input_a: Vec<u8> = [1.0f32, 2.0, 3.0, 4.0]
        .iter()
        .flat_map(|f| f.to_le_bytes())
        .collect();
    let input_b: Vec<u8> = [10.0f32, 20.0, 30.0, 40.0]
        .iter()
        .flat_map(|f| f.to_le_bytes())
        .collect();
    let mut output = vec![0u8; 16];

    backend
        .execute_plan(&plan, &[&input_a, &input_b], &mut [&mut output])
        .unwrap();

    let result: Vec<f32> = output
        .chunks(4)
        .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
        .collect();

    assert_eq!(result, vec![11.0, 22.0, 33.0, 44.0]);
}

#[wasm_bindgen_test]
fn test_wasm_relu_in_browser() {
    let backend = WasmBackend::new();

    let buffers = vec![
        make_buffer(BufferType::Input, 16),
        make_buffer(BufferType::Output, 16),
    ];

    let plan = make_plan(
        vec![IsaInstruction::Relu {
            dst: 1,
            src: 0,
            count: 4,
        }],
        buffers,
    );

    let input: Vec<u8> = [-2.0f32, -1.0, 0.0, 3.0]
        .iter()
        .flat_map(|f| f.to_le_bytes())
        .collect();
    let mut output = vec![0u8; 16];

    backend
        .execute_plan(&plan, &[&input], &mut [&mut output])
        .unwrap();

    let result: Vec<f32> = output
        .chunks(4)
        .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
        .collect();

    assert_eq!(result, vec![0.0, 0.0, 0.0, 3.0]);
}

#[wasm_bindgen_test]
fn test_wasm_ring_add_in_browser() {
    let backend = WasmBackend::new();

    let buffers = vec![
        make_buffer(BufferType::Input, 4),
        make_buffer(BufferType::Input, 4),
        make_buffer(BufferType::Output, 4),
    ];

    let plan = make_plan(
        vec![IsaInstruction::RingAdd {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        }],
        buffers,
    );

    let input_a = vec![0u8, 50, 90, 95];
    let input_b = vec![10u8, 50, 10, 5];
    let mut output = vec![0u8; 4];

    backend
        .execute_plan(&plan, &[&input_a, &input_b], &mut [&mut output])
        .unwrap();

    // (a + b) % 96
    assert_eq!(output[0], 10); // (0 + 10) % 96 = 10
    assert_eq!(output[1], 4); // (50 + 50) % 96 = 4
    assert_eq!(output[2], 4); // (90 + 10) % 96 = 4
    assert_eq!(output[3], 4); // (95 + 5) % 96 = 4
}

#[wasm_bindgen_test]
fn test_wasm_orbit_classify_in_browser() {
    let backend = WasmBackend::new();

    let buffers = vec![
        make_buffer(BufferType::Input, 4),
        make_buffer(BufferType::Output, 4),
    ];

    let plan = make_plan(
        vec![IsaInstruction::OrbitClassify {
            dst: 1,
            src: 0,
            count: 4,
        }],
        buffers,
    );

    let input = vec![0u8, 7, 8, 255];
    let mut output = vec![0u8; 4];

    backend
        .execute_plan(&plan, &[&input], &mut [&mut output])
        .unwrap();

    // orbit_class = byte / 8
    assert_eq!(output[0], 0); // 0 / 8 = 0
    assert_eq!(output[1], 0); // 7 / 8 = 0
    assert_eq!(output[2], 1); // 8 / 8 = 1
    assert_eq!(output[3], 31); // 255 / 8 = 31
}
