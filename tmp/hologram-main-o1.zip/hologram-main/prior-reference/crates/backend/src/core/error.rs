//! Backend error types.
//!
//! This module defines error types for backend operations including
//! buffer management, program execution, and backend initialization.

use crate::BufferHandle;
use thiserror::Error;

/// Errors that can occur during backend operations.
#[derive(Debug, Error)]
pub enum BackendError {
    /// Invalid buffer handle.
    #[error("invalid buffer handle: {0:?}")]
    InvalidHandle(BufferHandle),

    /// Buffer-related error.
    #[error("buffer error: {0}")]
    BufferError(String),

    /// Buffer size mismatch.
    #[error("buffer size mismatch: expected {expected}, got {actual}")]
    SizeMismatch {
        /// Expected size in bytes.
        expected: usize,
        /// Actual size in bytes.
        actual: usize,
    },

    /// Buffer overflow.
    #[error(
        "buffer overflow: offset {offset} + length {length} exceeds buffer size {buffer_size}"
    )]
    BufferOverflow {
        /// Offset into the buffer.
        offset: usize,
        /// Length of the operation.
        length: usize,
        /// Total buffer size.
        buffer_size: usize,
    },

    /// Constant buffer size does not match kernel params.dims.
    /// This indicates a mismatch between the BackendPlan and the actual weight data.
    #[error(
        "constant buffer mismatch at op {op_index}: params.dims requires {required_bytes} bytes \
         but BufferRef.size is {buffer_size} bytes (offset={buffer_offset}, mmap_len={mmap_len})"
    )]
    ConstantBufferMismatch {
        /// Index of the operation in the plan.
        op_index: usize,
        /// Bytes required based on params.dims.
        required_bytes: usize,
        /// Actual buffer size from BufferRef.
        buffer_size: usize,
        /// Offset of the constant in the data source.
        buffer_offset: usize,
        /// Total length of the mmap or constant_data.
        mmap_len: usize,
    },

    /// Program execution error.
    #[error("execution error: {0}")]
    ExecutionError(String),

    /// Backend not supported.
    #[error("backend not supported: {0}")]
    Unsupported(String),

    /// Backend initialization error.
    #[error("initialization error: {0}")]
    InitializationError(String),

    /// Out of memory error.
    #[error("out of memory: requested {requested} bytes")]
    OutOfMemory {
        /// Number of bytes requested.
        requested: usize,
    },

    /// Invalid configuration.
    #[error("invalid configuration: {0}")]
    InvalidConfiguration(String),

    /// ISA instruction error.
    #[error("instruction error at index {index}: {message}")]
    InstructionError {
        /// Instruction index in the program.
        index: usize,
        /// Error message.
        message: String,
    },

    /// Type mismatch error.
    #[error("type mismatch: expected {expected}, got {actual}")]
    TypeMismatch {
        /// Expected type name.
        expected: String,
        /// Actual type name.
        actual: String,
    },

    /// Register error.
    #[error("register error: {0}")]
    RegisterError(String),

    /// Synchronization error.
    #[error("synchronization error: {0}")]
    SynchronizationError(String),

    /// Backend not available.
    #[error("backend not available: {0}")]
    NotAvailable(String),
}

impl BackendError {
    /// Create a new buffer error.
    #[must_use]
    pub fn buffer<S: Into<String>>(message: S) -> Self {
        Self::BufferError(message.into())
    }

    /// Create a new execution error.
    #[must_use]
    pub fn execution<S: Into<String>>(message: S) -> Self {
        Self::ExecutionError(message.into())
    }

    /// Create a new unsupported backend error.
    #[must_use]
    pub fn unsupported<S: Into<String>>(message: S) -> Self {
        Self::Unsupported(message.into())
    }

    /// Create a new initialization error.
    #[must_use]
    pub fn initialization<S: Into<String>>(message: S) -> Self {
        Self::InitializationError(message.into())
    }

    /// Create a new out of memory error.
    #[must_use]
    pub const fn out_of_memory(requested: usize) -> Self {
        Self::OutOfMemory { requested }
    }

    /// Create a new invalid configuration error.
    #[must_use]
    pub fn invalid_config<S: Into<String>>(message: S) -> Self {
        Self::InvalidConfiguration(message.into())
    }

    /// Create a new instruction error.
    #[must_use]
    pub fn instruction<S: Into<String>>(index: usize, message: S) -> Self {
        Self::InstructionError {
            index,
            message: message.into(),
        }
    }

    /// Create a new type mismatch error.
    #[must_use]
    pub fn type_mismatch<S1: Into<String>, S2: Into<String>>(expected: S1, actual: S2) -> Self {
        Self::TypeMismatch {
            expected: expected.into(),
            actual: actual.into(),
        }
    }

    /// Create a new register error.
    #[must_use]
    pub fn register<S: Into<String>>(message: S) -> Self {
        Self::RegisterError(message.into())
    }

    /// Create a new synchronization error.
    #[must_use]
    pub fn sync<S: Into<String>>(message: S) -> Self {
        Self::SynchronizationError(message.into())
    }

    /// Create a new not available error.
    #[must_use]
    pub fn not_available<S: Into<String>>(message: S) -> Self {
        Self::NotAvailable(message.into())
    }

    /// Create a constant buffer mismatch error.
    #[must_use]
    pub const fn constant_buffer_mismatch(
        op_index: usize,
        required_bytes: usize,
        buffer_size: usize,
        buffer_offset: usize,
        mmap_len: usize,
    ) -> Self {
        Self::ConstantBufferMismatch {
            op_index,
            required_bytes,
            buffer_size,
            buffer_offset,
            mmap_len,
        }
    }

    /// Check if this is a recoverable error.
    #[must_use]
    pub const fn is_recoverable(&self) -> bool {
        matches!(
            self,
            Self::BufferError(_)
                | Self::SizeMismatch { .. }
                | Self::BufferOverflow { .. }
                | Self::ConstantBufferMismatch { .. }
                | Self::InvalidConfiguration(_)
        )
    }

    /// Check if this is a fatal error.
    #[must_use]
    pub const fn is_fatal(&self) -> bool {
        matches!(
            self,
            Self::OutOfMemory { .. }
                | Self::Unsupported(_)
                | Self::InitializationError(_)
                | Self::NotAvailable(_)
        )
    }
}

/// Result type for backend operations.
pub type BackendResult<T> = Result<T, BackendError>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_buffer_error_display() {
        let err = BackendError::buffer("test error");
        assert_eq!(format!("{err}"), "buffer error: test error");
    }

    #[test]
    fn test_invalid_handle_display() {
        let err = BackendError::InvalidHandle(BufferHandle::new(42));
        assert!(format!("{err}").contains("42"));
    }

    #[test]
    fn test_size_mismatch_display() {
        let err = BackendError::SizeMismatch {
            expected: 100,
            actual: 50,
        };
        let msg = format!("{err}");
        assert!(msg.contains("100"));
        assert!(msg.contains("50"));
    }

    #[test]
    fn test_buffer_overflow_display() {
        let err = BackendError::BufferOverflow {
            offset: 10,
            length: 100,
            buffer_size: 50,
        };
        let msg = format!("{err}");
        assert!(msg.contains("10"));
        assert!(msg.contains("100"));
        assert!(msg.contains("50"));
    }

    #[test]
    fn test_execution_error() {
        let err = BackendError::execution("failed to execute");
        assert!(format!("{err}").contains("failed to execute"));
    }

    #[test]
    fn test_unsupported_error() {
        let err = BackendError::unsupported("Metal not available");
        assert!(format!("{err}").contains("Metal not available"));
    }

    #[test]
    fn test_initialization_error() {
        let err = BackendError::initialization("failed to init");
        assert!(format!("{err}").contains("failed to init"));
    }

    #[test]
    fn test_out_of_memory_error() {
        let err = BackendError::out_of_memory(1024);
        assert!(format!("{err}").contains("1024"));
    }

    #[test]
    fn test_invalid_config_error() {
        let err = BackendError::invalid_config("bad config");
        assert!(format!("{err}").contains("bad config"));
    }

    #[test]
    fn test_instruction_error() {
        let err = BackendError::instruction(5, "invalid opcode");
        let msg = format!("{err}");
        assert!(msg.contains("5"));
        assert!(msg.contains("invalid opcode"));
    }

    #[test]
    fn test_type_mismatch_error() {
        let err = BackendError::type_mismatch("F32", "I32");
        let msg = format!("{err}");
        assert!(msg.contains("F32"));
        assert!(msg.contains("I32"));
    }

    #[test]
    fn test_register_error() {
        let err = BackendError::register("invalid register r99");
        assert!(format!("{err}").contains("invalid register r99"));
    }

    #[test]
    fn test_sync_error() {
        let err = BackendError::sync("fence timeout");
        assert!(format!("{err}").contains("fence timeout"));
    }

    #[test]
    fn test_is_recoverable() {
        assert!(BackendError::buffer("test").is_recoverable());
        assert!(BackendError::SizeMismatch {
            expected: 1,
            actual: 2
        }
        .is_recoverable());
        assert!(BackendError::BufferOverflow {
            offset: 0,
            length: 10,
            buffer_size: 5
        }
        .is_recoverable());
        assert!(BackendError::invalid_config("test").is_recoverable());
        assert!(!BackendError::out_of_memory(100).is_recoverable());
        assert!(!BackendError::unsupported("test").is_recoverable());
    }

    #[test]
    fn test_is_fatal() {
        assert!(BackendError::out_of_memory(100).is_fatal());
        assert!(BackendError::unsupported("test").is_fatal());
        assert!(BackendError::initialization("test").is_fatal());
        assert!(!BackendError::buffer("test").is_fatal());
        assert!(!BackendError::execution("test").is_fatal());
    }

    #[test]
    fn test_error_debug_format() {
        let err = BackendError::buffer("debug test");
        let debug = format!("{err:?}");
        assert!(debug.contains("BufferError"));
        assert!(debug.contains("debug test"));
    }

    #[test]
    fn test_not_available_error() {
        let err = BackendError::not_available("Metal backend not compiled");
        assert!(format!("{err}").contains("Metal backend not compiled"));
    }

    #[test]
    fn test_not_available_is_fatal() {
        assert!(BackendError::not_available("test").is_fatal());
    }

    #[test]
    fn test_constant_buffer_mismatch() {
        let err = BackendError::constant_buffer_mismatch(42, 1024, 512, 0, 1000);
        let msg = format!("{err}");
        assert!(msg.contains("op 42"));
        assert!(msg.contains("1024 bytes"));
        assert!(msg.contains("512 bytes"));
        assert!(err.is_recoverable());
        assert!(!err.is_fatal());
    }
}
