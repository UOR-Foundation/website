/**
 * Hologram UI Compatibility Layer — Hooks Stubs
 * ═══════════════════════════════════════════════
 *
 * Thin stubs for hologram-ui hooks used by the identity module.
 * On merge: delete this file, update imports to @/modules/hologram-ui/hooks/*
 *
 * @module identity/compat/hooks
 */

// ── Attention Mode ──────────────────────────────────────────────────────────

export interface AttentionState {
  readonly aperture: number;      // 0.0 (diffuse) – 1.0 (deep focus)
  readonly preset: "open" | "balanced" | "deep";
  shouldShow(priority: number): boolean;
}

const DEFAULT_ATTENTION: AttentionState = {
  aperture: 0.5,
  preset: "balanced",
  shouldShow: (_priority: number) => true,
};

export function useAttentionMode(): AttentionState {
  return DEFAULT_ATTENTION;
}

// ── Screen Context ──────────────────────────────────────────────────────────

export type BeaconContentType = "audio" | "media" | "video" | "identity" | "text";

export interface ContextBeacon {
  readonly id: string;
  readonly title: string;
  readonly summary: string;
  readonly contentType: BeaconContentType;
  readonly metadata?: Record<string, unknown>;
  readonly priority: number;
}

export interface ScreenContextDigest {
  registerBeacon(beacon: ContextBeacon): void;
  removeBeacon(id: string): void;
}

export function useScreenContext(): ScreenContextDigest {
  return {
    registerBeacon: (_beacon: ContextBeacon) => { /* stub */ },
    removeBeacon: (_id: string) => { /* stub */ },
  };
}

// ── Focus Gate ──────────────────────────────────────────────────────────────

export function useFocusGate(priority: number): boolean {
  const attention = useAttentionMode();
  return attention.shouldShow(priority);
}
