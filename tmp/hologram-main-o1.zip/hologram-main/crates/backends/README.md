# hologram-backend

Execution backends for the Hologram ISA (Instruction Set Architecture).

## Overview

This crate provides backend implementations for executing compiled hologram plans (`.holb`/`.holo` files). Backends implement the `Backend` trait and execute `BackendPlan` instances loaded from archive files.

## Architecture

```
┌──────────────────────────┐
│ User Code / ONNX / Python│
└────────────┬─────────────┘
             │
┌────────────▼─────────────┐
│ OperationGraph (future)  │
└────────────┬─────────────┘
             │
┌────────────▼─────────────┐
│ CompilationPipeline (fut)│
└────────────┬─────────────┘
             │
┌────────────▼─────────────┐
│ BackendPlan (.holo file) │  ← hologram-holo crate
└────────────┬─────────────┘
             │
┌────────────▼─────────────┐
│ Backend::execute_plan()  │  ← THIS CRATE
└────────────┬─────────────┘
             │
  ┌──────────┴─────────────┐
  │                        │
┌─▼───────┐         ┌──────▼──┐
│ CPU     │   ...   │  WASM   │
│ Backend │         │ Backend │
└─────────┘         └─────────┘
```

## Backend Types

Currently implemented:
- **CPU**: Interface only (execution not yet implemented)
- **WASM**: Structure only (not yet implemented)

Planned:
- **CUDA**: NVIDIA GPU compute
- **Metal**: Apple GPU compute

## Adding a New Backend

### 1. Create Backend Module

Create a new module under `src/backends/`:

```rust
// src/backends/my_backend/mod.rs
use hologram_holo::{BackendPlan, IsaInstruction};
use crate::backends::Backend;
use crate::types::{BackendCapabilities, BackendError, BackendType, Result};

pub struct MyBackend {
    capabilities: BackendCapabilities,
}

impl MyBackend {
    pub fn new() -> Self {
        Self {
            capabilities: BackendCapabilities {
                backend_type: BackendType::Custom(String::from("MyBackend")),
                vector_width: 8,  // Your SIMD width
                l1_cache_size: 32 * 1024,
                l2_cache_size: 256 * 1024,
                has_fma: false,
                has_sha: false,
                has_aes: false,
            },
        }
    }
}
```

### 2. Implement the Backend Trait

The `Backend` trait requires three methods:

```rust
impl Backend for MyBackend {
    fn backend_type(&self) -> BackendType {
        self.capabilities.backend_type.clone()
    }

    fn execute_plan(
        &self,
        plan: &BackendPlan,
        inputs: &[&[u8]],
        outputs: &mut [&mut [u8]],
    ) -> Result<()> {
        // Allocate workspace
        let mut workspace = vec![0u8; plan.workspace_size];

        // Execute each instruction
        for instruction in &plan.instructions {
            match instruction {
                IsaInstruction::Add { dst, a, b, count } => {
                    self.execute_add(&mut workspace, inputs, outputs, *dst, *a, *b, *count)?;
                }
                // ... implement other instructions
                _ => {
                    return Err(BackendError::UnsupportedInstruction(format!("{instruction:?}")));
                }
            }
        }

        Ok(())
    }

    fn capabilities(&self) -> &BackendCapabilities {
        &self.capabilities
    }
}
```

### 3. Implement Instruction Handlers

Each ISA instruction needs a corresponding handler method:

```rust
impl MyBackend {
    fn execute_add(
        &self,
        workspace: &mut [u8],
        inputs: &[&[u8]],
        outputs: &mut [&mut [u8]],
        dst: u32,
        a: u32,
        b: u32,
        count: usize,
    ) -> Result<()> {
        // 1. Resolve buffer references
        let a_buf = self.resolve_buffer(a, inputs, workspace, &plan.constants)?;
        let b_buf = self.resolve_buffer(b, inputs, workspace, &plan.constants)?;
        let dst_buf = self.resolve_buffer_mut(dst, outputs, workspace)?;

        // 2. Perform operation (example: element-wise addition)
        for i in 0..count {
            dst_buf[i] = a_buf[i].wrapping_add(b_buf[i]);
        }

        Ok(())
    }

    // Buffer resolution helpers
    fn resolve_buffer<'a>(
        &self,
        idx: u32,
        inputs: &'a [&[u8]],
        workspace: &'a [u8],
        constants: &'a [u8],
    ) -> Result<&'a [u8]> {
        // Map buffer index to actual buffer
        // (simplified - real implementation needs metadata)
        if (idx as usize) < inputs.len() {
            Ok(inputs[idx as usize])
        } else {
            Err(BackendError::InvalidBuffer(BufferRef::Input(idx)))
        }
    }
}
```

### 4. Add Tests

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use hologram_holo::PlanMetadata;

    #[test]
    fn test_my_backend_creation() {
        let backend = MyBackend::new();
        assert_eq!(backend.backend_type(), BackendType::Custom(String::from("MyBackend")));
    }

    #[test]
    fn test_execute_empty_plan() {
        let backend = MyBackend::new();
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
        };

        let inputs = &[];
        let outputs: &mut [&mut [u8]] = &mut [];
        assert!(backend.execute_plan(&plan, inputs, outputs).is_ok());
    }
}
```

### 5. Register Backend

Add your backend to `src/backends/mod.rs`:

```rust
pub mod my_backend;

// Re-export
pub use my_backend::MyBackend;
```

### 6. Add Benchmarks

Create `benches/my_backend.rs`:

```rust
use criterion::{criterion_group, criterion_main, Criterion, Throughput};
use hologram_backend::*;

fn bench_my_backend_add(c: &mut Criterion) {
    let mut group = c.benchmark_group("my_backend_add");
    group.throughput(Throughput::Elements(1024));

    let backend = my_backend::MyBackend::new();
    // ... benchmark setup

    group.bench_function("add_1024", |b| {
        b.iter(|| {
            // Execute operation
        });
    });

    group.finish();
}

criterion_group!(benches, bench_my_backend_add);
criterion_main!(benches);
```

## ISA Instruction Set

The following instructions must be supported:

### Arithmetic Operations
- `Add { dst, a, b, count }` - Element-wise addition
- `Sub { dst, a, b, count }` - Element-wise subtraction
- `Mul { dst, a, b, count }` - Element-wise multiplication

### Activation Functions
- `Sigmoid { dst, src, count }` - Sigmoid activation
- `Tanh { dst, src, count }` - Hyperbolic tangent
- `Relu { dst, src, count }` - Rectified linear unit

### Linear Algebra
- `MatMul { c, a, b, m, k, n }` - Matrix multiplication

### Reduction Operations
- `Sum { dst, src, count }` - Sum reduction
- `Max { dst, src, count }` - Max reduction
- `Min { dst, src, count }` - Min reduction

### Categorical (UOR-specific)
- `Lift { dst, src, count }` - Lift bytes to torus coordinates
- `OrbitClassify { dst, src, count }` - Orbit classification

### Control Flow
- `Load { buffer, offset, size }` - Load data into buffer
- `Store { buffer, offset, size }` - Store data from buffer
- `Copy { dst, src, size }` - Copy between buffers

### Composition
- `CallLayer { layer_id, inputs, outputs }` - Call another layer

## Performance Targets

Backends should aim for:
- **Zero-copy**: Use memory-mapped plans directly (no deserialization)
- **O(1) operations**: Constant-time lookups where possible
- **SIMD**: Use vector instructions for element-wise ops
- **Parallelization**: Use Rayon for data-parallel operations (>4096 element threshold)

Example CPU backend targets:
- Element-wise ops: < 5 cycles per element (SIMD)
- MatMul: Approach BLAS performance
- Reductions: < 10 cycles total for 624-element state

## Zero-Copy Guarantees

Backends must preserve zero-copy semantics:

1. **Memory-mapped plans**: `BackendPlan` may be an archived reference into mmap
2. **Constant access**: `plan.constants` is a zero-copy slice into the plan
3. **Workspace**: Pre-allocated once, size known at compile time
4. **No heap allocation**: Hot paths should avoid dynamic allocation

## Thread Safety

Backends must be `Send + Sync`. Execution should be thread-safe.

## Future Extensions

The current `Backend` trait is intentionally minimal. Based on the prior-reference implementation (`prior-reference/crates/backend/`), the following extensions may be added as needed:

### Buffer Management Methods

The prior implementation's `ProgramBackend` trait included explicit buffer management:

```rust
fn allocate_buffer(&self, size: usize) -> Result<BufferHandle, BackendError>;
fn free_buffer(&self, handle: BufferHandle) -> Result<(), BackendError>;
fn copy_to_buffer(&self, handle: BufferHandle, data: &[u8]) -> Result<(), BackendError>;
fn copy_from_buffer(&self, handle: BufferHandle, data: &mut [u8]) -> Result<(), BackendError>;
fn buffer_size(&self, handle: BufferHandle) -> Result<usize, BackendError>;
fn get_buffer_ptr(&self, handle: BufferHandle) -> Option<*mut u8>;
fn synchronize(&self) -> Result<(), BackendError>;
```

**When to add**: When implementing GPU backends or when explicit buffer lifetime management is needed.

### ComputeBackend Extension Trait

The prior implementation had a `ComputeBackend` trait extending `ProgramBackend` with SIMD operations:

```rust
pub trait ComputeBackend: Backend {
    // Vector operations
    fn vector_add(&self, dst: BufferHandle, a: BufferHandle, b: BufferHandle, count: usize) -> Result<()>;
    fn vector_mul(&self, dst: BufferHandle, a: BufferHandle, b: BufferHandle, count: usize) -> Result<()>;

    // Matrix operations
    fn matmul(&self, c: BufferHandle, a: BufferHandle, b: BufferHandle, params: &MatMulParams) -> Result<()>;
    fn batch_matmul(&self, c: BufferHandle, a: BufferHandle, b: BufferHandle, batch: u32, params: &MatMulParams) -> Result<()>;

    // Convolution
    fn conv2d(&self, output: BufferHandle, input: BufferHandle, kernel: BufferHandle, params: &Conv2DParams) -> Result<()>;

    // Activations
    fn sigmoid(&self, dst: BufferHandle, src: BufferHandle, count: usize) -> Result<()>;
    fn tanh(&self, dst: BufferHandle, src: BufferHandle, count: usize) -> Result<()>;
    fn relu(&self, dst: BufferHandle, src: BufferHandle, count: usize) -> Result<()>;
}
```

**When to add**: When implementing optimized SIMD kernels or when the compiler needs to select between different operation implementations.

**Design note**: All `ComputeBackend` methods had CPU fallback implementations in `common_ops.rs`, allowing backends to selectively override only the operations they can accelerate.

### Hardware Capability Detection

The prior `BackendType` enum had methods for runtime capability detection:

```rust
impl BackendType {
    pub fn is_gpu(&self) -> bool {
        matches!(self, Self::Metal | Self::Cuda | Self::WebGpu)
    }

    pub fn is_available(&self) -> bool {
        match self {
            Self::Cpu => true,
            Self::Wasm => cfg!(feature = "wasm"),
            Self::Metal => cfg!(all(target_os = "macos", feature = "metal")),
            Self::Cuda => cfg!(feature = "cuda"),
            Self::WebGpu => cfg!(feature = "webgpu"),
            Self::Custom(_) => true,
        }
    }
}
```

**When to add**: When supporting multiple hardware targets and needing to select backends at runtime.

### Const Providers (Data Loading Abstraction)

The prior implementation had a `ConstProvider` trait for loading constant data from various sources:

```rust
pub trait ConstProvider {
    fn load_chunk(&self, offset: usize, size: usize) -> Result<Vec<u8>>;
}

// Implementations:
// - MmapConstProvider: Memory-mapped files
// - HttpConstProvider: Load from HTTP endpoints
// - PeerHttpConstProvider: P2P constant loading
// - XorEncryptedConstProvider: Encrypted data
// - SharedMmapProvider: Shared memory-mapped data across processes
```

**When to add**: When weights need to be loaded from sources other than embedded plan constants (e.g., network loading, encrypted weights, shared memory).

**Current status**: `hologram-holo` loads plans from files. Const providers would extend this to load weights from HTTP, P2P networks, or encrypted storage.

### Tensor Layout and Operation Parameters

The prior implementation defined rich parameter types for operations:

```rust
pub struct TensorLayout {
    pub dtype: Type,
    pub dims: [u32; 4],      // NCHW format
    pub strides: [u32; 4],
    pub alignment: usize,
}

pub struct Conv2DParams {
    pub input_dims: [u32; 4],
    pub kernel_dims: [u32; 4],
    pub stride: [u32; 2],
    pub padding: [u32; 2],
    pub dilation: [u32; 2],
    pub dtype: Type,
}

pub struct MatMulParams {
    pub m: u32,
    pub k: u32,
    pub n: u32,
    pub alpha: f64,
    pub beta: f64,
    pub trans_a: bool,
    pub trans_b: bool,
    pub dtype: Type,
}
```

**When to add**: When implementing the `ComputeBackend` trait or when the ISA needs to represent complex operations like convolution.

### Common Ops Fallback Module

The prior implementation provided CPU fallback implementations for all operations:

```rust
pub mod common_ops {
    pub fn vector_add(backend: &impl ProgramBackend, dst: BufferHandle, a: BufferHandle, b: BufferHandle, count: usize) -> Result<()> {
        // Portable CPU implementation
    }

    pub fn matmul(backend: &impl ProgramBackend, c: BufferHandle, a: BufferHandle, b: BufferHandle, params: &MatMulParams) -> Result<()> {
        // Portable CPU implementation with cache tiling
    }

    // ... all other operations
}
```

**When to add**: When implementing `ComputeBackend` to provide default trait implementations that backends can override.

**Design pattern**: Default trait methods delegate to `common_ops`, allowing backends to:
1. Use defaults for correctness
2. Selectively override with hardware-specific kernels
3. Maintain a consistent API across all backends

### Execution Infrastructure

The prior implementation had extensive execution infrastructure:

- **Parallel execution** (`parallel.rs`, `threading.rs`): Thread pool management, work stealing
- **Streaming executor** (`streaming_executor.rs`): Batch processing with overlap
- **Plan caching** (`transform_cache.rs`): Cache compiled plans
- **Context management** (`context.rs`): Execution context with scoped lifetimes
- **Provenance tracking** (`provenance.rs`): Track data lineage
- **Inspector** (`inspector.rs`): Debug and profiling hooks

**When to add**: As performance and debugging needs evolve. The current simple `execute_plan()` interface is sufficient for initial implementation.

## Migration Path from Prior Implementation

If migrating code from `prior-reference/crates/backend/`:

1. **ProgramBackend → Backend**: The core trait is similar, but our version currently only has `execute_plan()` and `capabilities()`. Buffer management methods can be added when needed.

2. **ComputeBackend**: Create as extension trait when SIMD operations are implemented.

3. **Providers**: Use `hologram-holo::HoloLoader` for file-based loading. Add const providers if network/encrypted loading is needed.

4. **Common ops**: Implement as helper functions or default trait methods when `ComputeBackend` is added.

5. **Execution infrastructure**: Add incrementally as profiling identifies performance bottlenecks.

## Design Philosophy

**Start simple, add complexity only when measured**:

- The current `Backend` trait is minimal by design
- Prior implementation accumulated features over time
- We should only add functionality when benchmarks prove it's needed
- Preserve zero-copy and O(1) guarantees above all else

**References**:
- Prior backend trait: `prior-reference/crates/backend/src/core/traits.rs`
- Prior providers: `prior-reference/crates/backend/src/providers/`
- Prior common ops: `prior-reference/crates/backend/src/core/common_ops.rs`

## See Also

- `hologram-holo` crate for `.holo` file format and loading
- `uor` crate for low-level wavefront execution (CPU backends can delegate to `UorStep`)
- `specs/project.md` for overall architecture
- `specs/FUTURE_PLANS.md` for compilation pipeline design
- `prior-reference/crates/backend/` for reference implementation
