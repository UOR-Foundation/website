//! Hologram Network - P2P content distribution and distributed execution.
//!
//! This crate provides:
//! - **P2P networking**: Peer discovery, content-addressed storage, message transport
//! - **Distributed execution**: Task scheduling across worker nodes (future)
//!
//! # Features
//!
//! - `async` (default): Enables async operations with tokio
//! - `iroh`: Enables production-ready P2P networking using Iroh with QUIC
//!   transport and built-in encryption. **Recommended for production use.**
//! - `http`: Enables HTTP-based content fetching
//!
//! # Transport Options
//!
//! This crate provides two transport implementations:
//!
//! ## Simple MessageBus (default)
//!
//! An in-memory message bus suitable for testing and single-process scenarios.
//!
//! ## Iroh Transport (feature = "iroh")
//!
//! Production-ready P2P networking using [Iroh](https://iroh.computer/):
//! - QUIC transport with encryption by default
//! - NAT traversal and hole punching
//! - Relay server fallback
//! - Content-addressed blob transfer
//!
//! ```no_run
//! # #[cfg(feature = "iroh")]
//! # async fn example() -> Result<(), Box<dyn std::error::Error>> {
//! use hologram_network::p2p::{IrohTransport, IrohConfig};
//!
//! // Create an Iroh transport with default config
//! let transport = IrohTransport::new().await?;
//!
//! // Get our node address to share with peers
//! let addr = transport.node_addr().await;
//! println!("Node ID: {}", transport.node_id());
//!
//! // Connect to a peer (requires their NodeAddr)
//! // let conn = transport.connect(peer_addr).await?;
//! # Ok(())
//! # }
//! ```

#![warn(missing_docs)]
#![warn(clippy::all)]
#![warn(clippy::pedantic)]
#![allow(clippy::module_name_repetitions)]
#![allow(clippy::missing_errors_doc)]
#![allow(clippy::missing_panics_doc)]
#![allow(clippy::doc_markdown)]

pub mod distributed;
mod error;
pub mod p2p;

pub use error::NetworkError;

// Re-export commonly used types
pub use p2p::{ContentId, Discovery, Message, MessageType, Node, NodeConfig, NodeError, PeerId};

#[cfg(feature = "async")]
pub use p2p::{MessageBus, TransportError};

// Iroh transport (production-ready P2P with QUIC)
#[cfg(feature = "iroh")]
pub use p2p::{
    IrohBlobStore, IrohConfig, IrohError, IrohTransport, NodeAddr, NodeId, SecretKey, HOLOGRAM_ALPN,
};

// Distributed execution
#[cfg(feature = "async")]
pub use distributed::{
    ExecutionRequest, ExecutionResult, Executor, ExecutorConfig, ExecutorError, ExecutorStats,
    LocalPoolConfig, LocalPoolError, LocalWorkerPool, PartitionExecutor, PartitionExecutorConfig,
    PartitionExecutorStats, PartitionRequest, PartitionResult, Scheduler, SchedulerConfig,
    SchedulerError, WorkerId, WorkerState,
};
