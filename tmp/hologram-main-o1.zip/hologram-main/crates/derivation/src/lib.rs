//! Derivation chains and proof formats for UOR computations.
//!
//! This crate provides structures for recording and verifying computation
//! derivations, including the dihedral factorization oracle.
//!
//! # Derivation Chains
//!
//! A derivation chain is a sequence of steps that records how a computation
//! proceeds from input to output. Each step documents the operation performed,
//! the input values, the output values, and any assertions made.
//!
//! # Observable Proofs
//!
//! Derivations can be combined with monodromy observables to create certified
//! proofs. The [`observable_proof`] module provides:
//!
//! - [`ObservableProof`]: A derivation with monodromy signature
//! - [`TracedDerivation`]: A derivation with per-step observable tracking
//! - [`verify_observable_proof`]: Verify proofs by recomputing observables
//!
//! # Example: Factorization
//!
//! ```
//! use hologram_derivation::{factorize_semiprime, FactorizationResult};
//!
//! let result = factorize_semiprime(10403, 32).unwrap();
//! assert_eq!(result.p, 101);
//! assert_eq!(result.q, 103);
//! assert_eq!(result.p * result.q, 10403);
//! ```
//!
//! # Example: Observable Proof
//!
//! ```
//! use hologram_derivation::{DerivationChain, DerivationStep, StepKind};
//! use hologram_derivation::observable_proof::{ObservableProof, verify_observable_proof};
//!
//! let chain = DerivationChain::new("test", "Example");
//! let path = vec![1u64, 2, 3, 4, 5];
//! let proof = ObservableProof::with_path(chain, &path, 8);
//!
//! // Verify the proof
//! let result = verify_observable_proof(&proof, &path);
//! assert!(result.is_valid());
//! ```

mod chain;
pub mod datum;
mod emit;
mod factorize;
pub mod observable_proof;
mod verify;

pub use chain::{DerivationChain, DerivationStep, StepKind};
pub use emit::{emit_factorization_proof, ToJsonLd};
pub use factorize::{factorization_derivation, factorize_semiprime, gcd, FactorizationResult};
pub use observable_proof::{
    certification_step, verify_observable_proof, ObservableProof, ObservableValues,
    ObservableVerification, StepObservable, TracedDerivation,
};
pub use verify::{
    verify_derivation_chain, verify_factorization, VerificationCheck, VerificationResult,
};

// Re-export ontology-gen types for convenience
pub use ontology_gen::{all_q1_datums, Datum16, CARDINALITY, PRECISION_BITS, QUANTUM_LEVEL};

// Re-export datum integration
pub use datum::{datum_derivation_chain, emit_datum_batch, emit_datum_proof, Datum16Proof};
