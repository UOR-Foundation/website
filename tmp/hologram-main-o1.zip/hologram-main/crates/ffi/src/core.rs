//! Core FFI implementations - thin wrappers over uor crate.

use std::sync::Arc;
use uor::{Domain, ElementWiseView, Taxon, UorState, BRAILLE_BASE, BRAILLE_MAX, O, T};

// ============================================================================
// ERROR TYPES
// ============================================================================

/// FFI-friendly error type
#[derive(Debug, thiserror::Error)]
pub enum FfiError {
    #[error("Invalid size: expected {expected}, got {actual}")]
    InvalidSize { expected: usize, actual: usize },

    #[error("View is not bijective (not invertible)")]
    NotBijective,

    #[error("Invalid value: {0}")]
    InvalidValue(String),

    #[error("Execution error: {0}")]
    ExecutionError(String),
}

// ============================================================================
// CORE TYPES
// ============================================================================

/// Taxon with all metadata
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FfiTaxon {
    pub value: u8,
    pub codepoint: u32,
    pub braille: String,
    pub domain: u8,
    pub rank: u8,
}

/// Domain enumeration
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FfiDomain {
    Theta,
    Psi,
    Delta,
}

impl From<Domain> for FfiDomain {
    fn from(domain: Domain) -> Self {
        match domain {
            Domain::Theta => Self::Theta,
            Domain::Psi => Self::Psi,
            Domain::Delta => Self::Delta,
        }
    }
}

/// State wrapper (624 taxons = 4992 bits)
#[derive(Debug, Clone)]
pub struct FfiState {
    /// Inner UorState
    inner: UorState,
}

impl FfiState {
    /// Create zero state
    pub fn new() -> Self {
        Self {
            inner: UorState::zero(),
        }
    }

    /// Create state from byte slice
    pub fn from_bytes(data: Vec<u8>) -> Result<Self, FfiError> {
        if data.len() != 624 {
            return Err(FfiError::InvalidSize {
                expected: 624,
                actual: data.len(),
            });
        }

        let mut state = UorState::zero();
        // Copy bytes into state via as_taxons_mut
        let taxons = state.as_taxons_mut();
        for (i, &byte) in data.iter().enumerate() {
            taxons[i] = Taxon::new(byte);
        }
        Ok(Self { inner: state })
    }

    /// Get state as bytes
    pub fn as_bytes(&self) -> Vec<u8> {
        self.inner.as_taxons().iter().map(|t| t.value()).collect()
    }

    /// Get state length in taxons
    pub fn len(&self) -> u32 {
        624
    }

    /// Check if state is empty (always false for fixed-size state)
    pub fn is_empty(&self) -> bool {
        false
    }

    /// Check if state is all zeros
    pub fn is_zero(&self) -> bool {
        self.inner.as_taxons().iter().all(|t| t.value() == 0)
    }

    /// Get a taxon at index
    pub fn get_taxon(&self, index: usize) -> Result<u8, FfiError> {
        if index >= 624 {
            return Err(FfiError::InvalidValue(format!(
                "Index {} out of bounds (max 623)",
                index
            )));
        }
        Ok(self.inner.as_taxons()[index].value())
    }

    /// Set a taxon at index
    pub fn set_taxon(&mut self, index: usize, value: u8) -> Result<(), FfiError> {
        if index >= 624 {
            return Err(FfiError::InvalidValue(format!(
                "Index {} out of bounds (max 623)",
                index
            )));
        }
        self.inner.as_taxons_mut()[index] = Taxon::new(value);
        Ok(())
    }

    /// Get access to inner UorState
    pub fn inner(&self) -> &UorState {
        &self.inner
    }

    /// Get mutable access to inner UorState
    pub fn inner_mut(&mut self) -> &mut UorState {
        &mut self.inner
    }
}

impl Default for FfiState {
    fn default() -> Self {
        Self {
            inner: UorState::zero(),
        }
    }
}

/// ElementWiseView wrapper (256-byte lookup table)
#[derive(Debug, Clone)]
pub struct FfiView {
    inner: ElementWiseView,
}

impl FfiView {
    /// Create identity view (renamed to match UDL)
    pub fn identity() -> Self {
        Self {
            inner: ElementWiseView::identity(),
        }
    }

    /// Create constant view (all inputs map to same output)
    pub fn constant(value: u8) -> Result<Self, FfiError> {
        Ok(Self {
            inner: ElementWiseView::constant(value),
        })
    }

    /// Apply view to single byte
    pub fn apply(&self, byte_value: u8) -> u8 {
        self.inner.apply(byte_value)
    }

    /// Apply view to byte array
    pub fn apply_slice(&self, input: Vec<u8>) -> Vec<u8> {
        let mut output = input;
        // Note: ElementWiseView::apply_slice takes &mut [u8]
        // For FFI, we work with Vec<u8>
        self.inner.apply_slice(&mut output);
        output
    }

    /// Compose two views
    pub fn then(self: Arc<Self>, other: Arc<Self>) -> Arc<Self> {
        Arc::new(Self {
            inner: self.inner.then(&other.inner),
        })
    }

    /// Check if view is bijective
    pub fn is_bijective(&self) -> bool {
        self.inner.is_bijective()
    }

    /// Get inverse view (if bijective)
    pub fn inverse(&self) -> Result<Arc<Self>, FfiError> {
        self.inner
            .inverse()
            .map(|inv| Arc::new(Self { inner: inv }))
            .ok_or(FfiError::NotBijective)
    }

    /// Get underlying lookup table
    pub fn table(&self) -> Vec<u8> {
        self.inner.table().to_vec()
    }
}

impl Default for FfiView {
    fn default() -> Self {
        Self {
            inner: ElementWiseView::identity(),
        }
    }
}

// ============================================================================
// NAMESPACE FUNCTIONS (top-level API)
// ============================================================================

/// Get braille character for byte value
pub fn byte_to_braille(value: u8) -> String {
    let taxon = Taxon::new(value);
    taxon.braille().to_string()
}

/// Get codepoint for byte value
pub fn byte_to_codepoint(value: u8) -> u32 {
    let taxon = Taxon::new(value);
    taxon.codepoint()
}

/// Get domain for byte value (0=Theta, 1=Psi, 2=Delta)
pub fn byte_to_domain(value: u8) -> u8 {
    let taxon = Taxon::new(value);
    match taxon.domain() {
        Domain::Theta => 0,
        Domain::Psi => 1,
        Domain::Delta => 2,
    }
}

/// Get rank within domain
pub fn byte_rank(value: u8) -> u8 {
    let taxon = Taxon::new(value);
    taxon.rank()
}

/// Successor in ring
pub fn byte_succ(value: u8) -> u8 {
    let taxon = Taxon::new(value);
    taxon.succ().value()
}

/// Predecessor in ring
pub fn byte_pred(value: u8) -> u8 {
    let taxon = Taxon::new(value);
    taxon.pred().value()
}

/// Bitwise NOT
pub fn byte_not(value: u8) -> u8 {
    let taxon = Taxon::new(value);
    taxon.not().value()
}

// ============================================================================
// CONSTANTS
// ============================================================================

/// Braille base codepoint (U+2800)
pub fn braille_base() -> u32 {
    BRAILLE_BASE
}

/// Braille max codepoint (U+28FF)
pub fn braille_max() -> u32 {
    BRAILLE_MAX
}

/// Triadic constant (T = 3)
pub fn triadic_constant() -> u8 {
    T as u8
}

/// Octave constant (O = 8)
pub fn octave_constant() -> u8 {
    O as u8
}

/// State taxons (624)
pub fn state_taxons() -> u16 {
    uor::STATE_TAXONS as u16
}

/// State bits (4992)
pub fn state_bits() -> u16 {
    uor::STATE_TAXONS as u16 * 8
}

// ============================================================================
// TESTS
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_byte_to_braille() {
        assert_eq!(byte_to_braille(0), "⠀");
        assert_eq!(byte_to_braille(1), "⠁");
        assert_eq!(byte_to_braille(255), "⣿");
    }

    #[test]
    fn test_byte_to_codepoint() {
        assert_eq!(byte_to_codepoint(0), 0x2800);
        assert_eq!(byte_to_codepoint(1), 0x2801);
        assert_eq!(byte_to_codepoint(255), 0x28FF);
    }

    #[test]
    fn test_byte_to_domain() {
        // 0 is Theta
        assert_eq!(byte_to_domain(0), 0);
        // 1 is Psi
        assert_eq!(byte_to_domain(1), 1);
        // 2 is Delta
        assert_eq!(byte_to_domain(2), 2);
    }

    #[test]
    fn test_byte_ring_operations() {
        // Successor/predecessor cycle
        let value = 42u8;
        assert_eq!(byte_pred(byte_succ(value)), value);

        // NOT involution
        assert_eq!(byte_not(byte_not(value)), value);
    }

    #[test]
    fn test_constants() {
        assert_eq!(braille_base(), 0x2800);
        assert_eq!(braille_max(), 0x28FF);
        assert_eq!(triadic_constant(), 3);
        assert_eq!(octave_constant(), 8);
        assert_eq!(state_taxons(), 624);
        assert_eq!(state_bits(), 4992);
    }

    #[test]
    fn test_ffi_state_creation() {
        let state = FfiState::new();
        assert_eq!(state.len(), 624);
        assert!(state.is_zero());
    }

    #[test]
    fn test_ffi_state_from_bytes() {
        let mut data = vec![0u8; 624];
        data[0] = 42;
        data[100] = 255;
        data[623] = 17;

        let state = FfiState::from_bytes(data.clone()).unwrap();
        let bytes = state.as_bytes();

        assert_eq!(bytes.len(), 624);
        assert_eq!(bytes[0], 42);
        assert_eq!(bytes[100], 255);
        assert_eq!(bytes[623], 17);
        assert!(!state.is_zero());
    }

    #[test]
    fn test_ffi_state_get_set_taxon() {
        let mut state = FfiState::new();

        // Set and get
        state.set_taxon(42, 123).unwrap();
        assert_eq!(state.get_taxon(42).unwrap(), 123);

        // Out of bounds
        assert!(state.get_taxon(624).is_err());
        assert!(state.set_taxon(624, 0).is_err());
    }

    #[test]
    fn test_ffi_state_invalid_size() {
        let data = vec![0u8; 100]; // Wrong size
        assert!(FfiState::from_bytes(data).is_err());
    }

    #[test]
    fn test_ffi_view_identity() {
        let view = FfiView::identity();
        assert_eq!(view.apply(42), 42);
        assert_eq!(view.apply(0), 0);
        assert_eq!(view.apply(255), 255);
    }

    #[test]
    fn test_ffi_view_constant() {
        let view = FfiView::constant(17).unwrap();
        assert_eq!(view.apply(0), 17);
        assert_eq!(view.apply(42), 17);
        assert_eq!(view.apply(255), 17);
    }

    #[test]
    fn test_ffi_view_composition() {
        let inc = Arc::new(FfiView::identity());
        let inv = Arc::new(FfiView::identity());
        let composed = inc.then(inv);

        // Identity composed with identity is identity
        assert_eq!(composed.apply(42), 42);
    }

    #[test]
    fn test_ffi_view_bijection() {
        let id = FfiView::identity();
        assert!(id.is_bijective());

        let constant = FfiView::constant(0).unwrap();
        assert!(!constant.is_bijective());
    }

    #[test]
    fn test_ffi_view_inverse() {
        let id = FfiView::identity();
        let inv = id.inverse().unwrap();
        assert_eq!(inv.apply(42), 42);

        let constant = FfiView::constant(0).unwrap();
        assert!(constant.inverse().is_err());
    }

    #[test]
    fn test_ffi_view_apply_slice() {
        let view = FfiView::identity();
        let input = vec![1, 2, 3, 4, 5];
        let output = view.apply_slice(input.clone());
        assert_eq!(output, input);
    }
}
