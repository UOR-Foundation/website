//! Async model loader with progress reporting.
//!
//! This module provides async model loading with progress callbacks.

use crate::error::AsyncError;
use crate::Result;
use hologram_compiler::Manifest;
use std::path::Path;
use std::sync::Arc;

/// Progress information for model loading.
#[derive(Debug, Clone)]
pub struct LoadProgress {
    /// Current loading stage.
    pub stage: LoadStage,
    /// Bytes loaded so far.
    pub bytes_loaded: usize,
    /// Total bytes to load (if known).
    pub total_bytes: Option<usize>,
    /// Name of the current layer being loaded.
    pub layer_name: Option<String>,
    /// Progress percentage (0-100).
    pub percentage: Option<u8>,
}

impl LoadProgress {
    /// Create a new progress update.
    pub fn new(stage: LoadStage) -> Self {
        Self {
            stage,
            bytes_loaded: 0,
            total_bytes: None,
            layer_name: None,
            percentage: None,
        }
    }

    /// Set the bytes loaded.
    pub fn with_bytes(mut self, loaded: usize, total: Option<usize>) -> Self {
        self.bytes_loaded = loaded;
        self.total_bytes = total;
        if let Some(t) = total {
            if t > 0 {
                self.percentage = Some(((loaded as f64 / t as f64) * 100.0).min(100.0) as u8);
            }
        }
        self
    }

    /// Set the layer name.
    pub fn with_layer(mut self, name: impl Into<String>) -> Self {
        self.layer_name = Some(name.into());
        self
    }
}

/// Loading stage.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LoadStage {
    /// Reading the manifest file.
    ReadingManifest,
    /// Loading a layer.
    LoadingLayer,
    /// Loading weights.
    LoadingWeights,
    /// Validating the model.
    Validating,
    /// Loading complete.
    Complete,
}

impl std::fmt::Display for LoadStage {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            LoadStage::ReadingManifest => write!(f, "Reading manifest"),
            LoadStage::LoadingLayer => write!(f, "Loading layer"),
            LoadStage::LoadingWeights => write!(f, "Loading weights"),
            LoadStage::Validating => write!(f, "Validating"),
            LoadStage::Complete => write!(f, "Complete"),
        }
    }
}

/// Callback type for progress reporting.
pub type ProgressCallback = Arc<dyn Fn(LoadProgress) + Send + Sync>;

/// Async model loader with progress reporting.
pub struct AsyncLoader {
    progress_callback: Option<ProgressCallback>,
}

impl Default for AsyncLoader {
    fn default() -> Self {
        Self::new()
    }
}

impl AsyncLoader {
    /// Create a new async loader.
    pub fn new() -> Self {
        Self {
            progress_callback: None,
        }
    }

    /// Set a progress callback.
    pub fn with_progress<F>(mut self, callback: F) -> Self
    where
        F: Fn(LoadProgress) + Send + Sync + 'static,
    {
        self.progress_callback = Some(Arc::new(callback));
        self
    }

    /// Report progress to the callback if set.
    fn report_progress(&self, progress: LoadProgress) {
        if let Some(callback) = &self.progress_callback {
            callback(progress);
        }
    }

    /// Load a manifest from a directory.
    pub async fn load_manifest(&self, path: &Path) -> Result<Manifest> {
        self.report_progress(LoadProgress::new(LoadStage::ReadingManifest));

        let manifest_path = path.join("manifest.toml");
        let manifest_content = tokio::fs::read_to_string(&manifest_path).await?;
        let manifest: Manifest = toml::from_str(&manifest_content)?;

        Ok(manifest)
    }

    /// Load a single layer file.
    pub async fn load_layer(&self, path: &Path, layer_name: &str) -> Result<Vec<u8>> {
        self.report_progress(LoadProgress::new(LoadStage::LoadingLayer).with_layer(layer_name));

        let bytes = tokio::fs::read(path).await?;

        self.report_progress(
            LoadProgress::new(LoadStage::LoadingLayer)
                .with_layer(layer_name)
                .with_bytes(bytes.len(), Some(bytes.len())),
        );

        Ok(bytes)
    }

    /// Load weights from a file.
    pub async fn load_weights(&self, path: &Path) -> Result<Vec<u8>> {
        self.report_progress(LoadProgress::new(LoadStage::LoadingWeights));

        let bytes = tokio::fs::read(path).await?;

        self.report_progress(
            LoadProgress::new(LoadStage::LoadingWeights).with_bytes(bytes.len(), Some(bytes.len())),
        );

        Ok(bytes)
    }

    /// Load all layers from a manifest.
    pub async fn load_all_layers(
        &self,
        base_path: &Path,
        manifest: &Manifest,
    ) -> Result<Vec<Vec<u8>>> {
        let mut layers = Vec::new();
        let total_layers = manifest.layers.len();

        for (i, layer_entry) in manifest.layers.iter().enumerate() {
            self.report_progress(
                LoadProgress::new(LoadStage::LoadingLayer)
                    .with_layer(&layer_entry.name)
                    .with_bytes(i, Some(total_layers)),
            );

            let layer_path = base_path.join(&layer_entry.holo_path);
            let layer_bytes = tokio::fs::read(&layer_path).await?;
            layers.push(layer_bytes);
        }

        self.report_progress(LoadProgress::new(LoadStage::Complete));

        Ok(layers)
    }

    /// Load a complete model directory.
    pub async fn load_model_dir(&self, path: &Path) -> Result<(Manifest, Vec<Vec<u8>>)> {
        let manifest = self.load_manifest(path).await?;
        let layers = self.load_all_layers(path, &manifest).await?;
        Ok((manifest, layers))
    }

    /// Validate a manifest.
    pub async fn validate_manifest(&self, manifest: &Manifest) -> Result<()> {
        self.report_progress(LoadProgress::new(LoadStage::Validating));

        // Basic validation
        if manifest.layers.is_empty() {
            return Err(AsyncError::Manifest("Manifest has no layers".to_string()));
        }

        for layer in &manifest.layers {
            if layer.name.is_empty() {
                return Err(AsyncError::Manifest("Layer has empty name".to_string()));
            }
            if layer.holo_path.is_empty() {
                return Err(AsyncError::Manifest(format!(
                    "Layer {} has empty holo_path",
                    layer.name
                )));
            }
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};

    #[test]
    fn test_load_stage_display() {
        assert_eq!(LoadStage::ReadingManifest.to_string(), "Reading manifest");
        assert_eq!(LoadStage::LoadingLayer.to_string(), "Loading layer");
        assert_eq!(LoadStage::LoadingWeights.to_string(), "Loading weights");
        assert_eq!(LoadStage::Validating.to_string(), "Validating");
        assert_eq!(LoadStage::Complete.to_string(), "Complete");
    }

    #[test]
    fn test_load_progress_new() {
        let progress = LoadProgress::new(LoadStage::ReadingManifest);
        assert_eq!(progress.stage, LoadStage::ReadingManifest);
        assert_eq!(progress.bytes_loaded, 0);
        assert!(progress.total_bytes.is_none());
        assert!(progress.layer_name.is_none());
    }

    #[test]
    fn test_load_progress_with_bytes() {
        let progress = LoadProgress::new(LoadStage::LoadingLayer).with_bytes(50, Some(100));
        assert_eq!(progress.bytes_loaded, 50);
        assert_eq!(progress.total_bytes, Some(100));
        assert_eq!(progress.percentage, Some(50));
    }

    #[test]
    fn test_load_progress_with_layer() {
        let progress = LoadProgress::new(LoadStage::LoadingLayer).with_layer("embedding");
        assert_eq!(progress.layer_name, Some("embedding".to_string()));
    }

    #[test]
    fn test_load_progress_percentage_calculation() {
        let progress = LoadProgress::new(LoadStage::LoadingLayer).with_bytes(75, Some(100));
        assert_eq!(progress.percentage, Some(75));

        let progress = LoadProgress::new(LoadStage::LoadingLayer).with_bytes(100, Some(100));
        assert_eq!(progress.percentage, Some(100));

        let progress = LoadProgress::new(LoadStage::LoadingLayer).with_bytes(150, Some(100));
        assert_eq!(progress.percentage, Some(100)); // Capped at 100
    }

    #[test]
    fn test_async_loader_new() {
        let loader = AsyncLoader::new();
        assert!(loader.progress_callback.is_none());
    }

    #[test]
    fn test_async_loader_default() {
        let loader = AsyncLoader::default();
        assert!(loader.progress_callback.is_none());
    }

    #[test]
    fn test_async_loader_with_progress() {
        let call_count = Arc::new(AtomicUsize::new(0));
        let count_clone = call_count.clone();

        let loader = AsyncLoader::new().with_progress(move |_| {
            count_clone.fetch_add(1, Ordering::SeqCst);
        });

        assert!(loader.progress_callback.is_some());

        // Trigger a progress report
        loader.report_progress(LoadProgress::new(LoadStage::ReadingManifest));
        assert_eq!(call_count.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn test_async_loader_load_manifest_not_found() {
        let loader = AsyncLoader::new();
        let result = loader.load_manifest(Path::new("/nonexistent/path")).await;
        assert!(result.is_err());
    }

    #[tokio::test]
    async fn test_async_loader_load_layer_not_found() {
        let loader = AsyncLoader::new();
        let result = loader
            .load_layer(Path::new("/nonexistent/layer.holo"), "test")
            .await;
        assert!(result.is_err());
    }

    #[tokio::test]
    async fn test_async_loader_load_weights_not_found() {
        let loader = AsyncLoader::new();
        let result = loader
            .load_weights(Path::new("/nonexistent/weights.bin"))
            .await;
        assert!(result.is_err());
    }

    #[tokio::test]
    async fn test_async_loader_validate_empty_manifest() {
        let loader = AsyncLoader::new();
        let manifest = Manifest::new("test");
        let result = loader.validate_manifest(&manifest).await;
        assert!(matches!(result, Err(AsyncError::Manifest(_))));
    }

    #[tokio::test]
    async fn test_async_loader_validate_layer_no_name() {
        let loader = AsyncLoader::new();
        let mut manifest = Manifest::new("test");
        manifest.add_layer(hologram_compiler::Layer {
            name: "".to_string(),
            holo_path: "test.holo".to_string(),
            ..Default::default()
        });
        let result = loader.validate_manifest(&manifest).await;
        assert!(matches!(result, Err(AsyncError::Manifest(_))));
    }

    #[tokio::test]
    async fn test_async_loader_validate_layer_no_path() {
        let loader = AsyncLoader::new();
        let mut manifest = Manifest::new("test");
        manifest.add_layer(hologram_compiler::Layer {
            name: "test".to_string(),
            holo_path: "".to_string(),
            ..Default::default()
        });
        let result = loader.validate_manifest(&manifest).await;
        assert!(matches!(result, Err(AsyncError::Manifest(_))));
    }

    #[tokio::test]
    async fn test_async_loader_validate_valid_manifest() {
        let loader = AsyncLoader::new();
        let mut manifest = Manifest::new("test");
        manifest.add_layer(hologram_compiler::Layer {
            name: "embedding".to_string(),
            holo_path: "layers/embedding.holo".to_string(),
            ..Default::default()
        });
        let result = loader.validate_manifest(&manifest).await;
        assert!(result.is_ok());
    }
}
