//! Run command: execute a .holb file with inputs.

use std::path::{Path, PathBuf};

use clap::Args;
use hologram_backend::cpu::CpuBackend;
use hologram_backend::Backend;

use crate::error::{CliError, CliResult};
use crate::reader::read_holb;

/// Arguments for the run command.
#[derive(Args, Debug)]
pub struct RunArgs {
    /// Input .holb file to execute
    #[arg(value_name = "MODEL")]
    pub model: PathBuf,

    /// Input data file (JSON array or raw bytes)
    #[arg(short, long, value_name = "INPUT")]
    pub input: PathBuf,

    /// Output file path
    #[arg(short, long, value_name = "OUTPUT")]
    pub output: Option<PathBuf>,

    /// Input format (json, raw)
    #[arg(long, default_value = "json")]
    pub input_format: String,

    /// Output format (json, raw)
    #[arg(long, default_value = "json")]
    pub output_format: String,
}

/// Execute the run command.
pub fn execute(args: RunArgs, verbose: bool) -> CliResult<()> {
    // Verify model file exists
    if !args.model.exists() {
        return Err(CliError::FileNotFound(args.model));
    }

    // Verify input file exists
    if !args.input.exists() {
        return Err(CliError::FileNotFound(args.input));
    }

    if verbose {
        println!("Running {}", args.model.display());
        println!("  Input: {} ({})", args.input.display(), args.input_format);
        if let Some(ref output) = args.output {
            println!("  Output: {} ({})", output.display(), args.output_format);
        }
    }

    // Load model
    if verbose {
        println!("  Loading model...");
    }
    let plan = read_holb(&args.model)?;

    if verbose {
        println!(
            "  Model: {} v{} ({} instructions, {} buffers)",
            plan.metadata.name,
            plan.metadata.version,
            plan.instructions.len(),
            plan.buffers.len()
        );
    }

    // Load input data
    if verbose {
        println!("  Loading input data...");
    }
    let input_data = load_input(&args.input, &args.input_format)?;

    // Determine output buffer size
    let output_size = compute_output_size(&plan);

    if verbose {
        println!(
            "  Input: {} bytes, Output: {} bytes",
            input_data.len(),
            output_size
        );
    }

    // Execute using CPU backend
    if verbose {
        println!("  Executing...");
    }

    let backend = CpuBackend::new();
    let inputs: &[&[u8]] = &[&input_data];
    let mut output_buf = vec![0u8; output_size];
    let outputs: &mut [&mut [u8]] = &mut [&mut output_buf];

    backend
        .execute_plan(&plan, inputs, outputs)
        .map_err(|e| CliError::ExecutionFailed(format!("backend execution failed: {e}")))?;

    // Write output
    if let Some(output_path) = args.output {
        write_output(&output_path, &output_buf, &args.output_format)?;
        if verbose {
            println!("  Output written to {}", output_path.display());
        }
    } else {
        // Print to stdout
        println!("{}", format_output(&output_buf, &args.output_format)?);
    }

    Ok(())
}

/// Compute output buffer size from plan buffers.
fn compute_output_size(plan: &hologram_holo::BackendPlan) -> usize {
    // Find output buffers (typically the last buffer or buffers marked as output)
    // For now, use the last buffer's size as output
    plan.buffers.last().map_or(1024, |b| b.size)
}

/// Load input data from file.
fn load_input(path: &Path, format: &str) -> CliResult<Vec<u8>> {
    let bytes = std::fs::read(path)?;

    match format {
        "raw" => Ok(bytes),
        "json" => {
            let values: Vec<f32> = serde_json::from_slice(&bytes)?;
            Ok(values.iter().flat_map(|f| f.to_le_bytes()).collect())
        }
        _ => Err(CliError::UnsupportedFormat(format.to_string())),
    }
}

/// Write output to file.
fn write_output(path: &Path, data: &[u8], format: &str) -> CliResult<()> {
    let bytes = match format {
        "raw" => data.to_vec(),
        "json" => format_output(data, format)?.into_bytes(),
        _ => return Err(CliError::UnsupportedFormat(format.to_string())),
    };
    std::fs::write(path, bytes)?;
    Ok(())
}

/// Format output data as string.
fn format_output(data: &[u8], format: &str) -> CliResult<String> {
    match format {
        "raw" => Ok(format!("{data:?}")),
        "json" => {
            let floats: Vec<f32> = data
                .chunks_exact(4)
                .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
                .collect();
            Ok(serde_json::to_string_pretty(&floats)?)
        }
        _ => Err(CliError::UnsupportedFormat(format.to_string())),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_backend::BackendPlan;
    use hologram_holo::PlanMetadata;
    use tempfile::tempdir;

    use crate::writer::write_holb;

    #[test]
    fn test_load_json_input() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("input.json");

        // Write test data
        std::fs::write(&path, "[1.0, 2.0, 3.0, 4.0]").unwrap();

        let data = load_input(&path, "json").unwrap();
        assert_eq!(data.len(), 16); // 4 f32 values * 4 bytes each

        // Verify values
        let f1 = f32::from_le_bytes([data[0], data[1], data[2], data[3]]);
        assert!((f1 - 1.0).abs() < f32::EPSILON);
    }

    #[test]
    fn test_load_raw_input() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("input.raw");

        let raw_data = vec![1, 2, 3, 4, 5, 6, 7, 8];
        std::fs::write(&path, &raw_data).unwrap();

        let data = load_input(&path, "raw").unwrap();
        assert_eq!(data, raw_data);
    }

    #[test]
    fn test_format_output_json() {
        let data: Vec<u8> = [1.0f32, 2.0f32]
            .iter()
            .flat_map(|f| f.to_le_bytes())
            .collect();

        let output = format_output(&data, "json").unwrap();
        assert!(output.contains("1.0"));
        assert!(output.contains("2.0"));
    }

    #[test]
    fn test_compute_output_size() {
        use hologram_holo::types::{BufferMetadata, BufferType};

        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![
                BufferMetadata {
                    size: 100,
                    alignment: 4,
                    buffer_type: BufferType::Input,
                    fully_written: false,
                },
                BufferMetadata {
                    size: 200,
                    alignment: 4,
                    buffer_type: BufferType::Output,
                    fully_written: false,
                },
            ],
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        let size = compute_output_size(&plan);
        assert_eq!(size, 200); // Last buffer size
    }

    #[test]
    fn test_run_simple_plan() {
        use hologram_holo::types::{BufferMetadata, BufferType};

        let dir = tempdir().unwrap();
        let model_path = dir.path().join("simple.holb");
        let input_path = dir.path().join("input.json");
        let output_path = dir.path().join("output.json");

        // Create a simple plan with input and output buffers (no instructions)
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![
                BufferMetadata {
                    size: 16,
                    alignment: 4,
                    buffer_type: BufferType::Input,
                    fully_written: false,
                },
                BufferMetadata {
                    size: 16,
                    alignment: 4,
                    buffer_type: BufferType::Output,
                    fully_written: false,
                },
            ],
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };
        write_holb(&plan, &model_path).unwrap();

        // Create input (4 f32 values = 16 bytes)
        std::fs::write(&input_path, "[1.0, 2.0, 3.0, 4.0]").unwrap();

        let args = RunArgs {
            model: model_path,
            input: input_path,
            output: Some(output_path.clone()),
            input_format: "json".to_string(),
            output_format: "json".to_string(),
        };

        // Should succeed with simple plan
        let result = execute(args, false);
        assert!(result.is_ok(), "execute failed: {result:?}");

        // Verify output file exists
        assert!(output_path.exists());
    }
}
