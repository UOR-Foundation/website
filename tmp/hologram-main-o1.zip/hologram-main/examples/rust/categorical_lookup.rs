//! Categorical lookup example.
//!
//! Demonstrates UOR categorical operations: Lift, OrbitClassify, and Ring arithmetic.
//!
//! Run with: `cargo run --example categorical_lookup`

use hologram_backend::{cpu::CpuBackend, Backend};
use hologram_holo::types::BufferType;
use hologram_holo::{BackendPlan, BufferMetadata, IsaInstruction, PlanMetadata};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("=== Categorical Lookup Example ===\n");

    // Create backend
    let backend = CpuBackend::new();

    // Example 1: Lift operation (maps bytes to torus coordinates)
    println!("--- Lift Operation ---");
    run_lift_example(&backend)?;

    // Example 2: Orbit classification
    println!("\n--- Orbit Classification ---");
    run_orbit_classify_example(&backend)?;

    // Example 3: Ring arithmetic (mod 96)
    println!("\n--- Ring Arithmetic (mod 96) ---");
    run_ring_arithmetic_example(&backend)?;

    Ok(())
}

/// Demonstrates the Lift operation.
fn run_lift_example(backend: &CpuBackend) -> Result<(), Box<dyn std::error::Error>> {
    // Lift maps each byte to its torus coordinate
    // This is a pure lookup table operation

    let input: Vec<u8> = vec![0, 1, 17, 96, 255];
    println!("Input bytes: {:?}", input);

    let plan = BackendPlan {
        instructions: vec![IsaInstruction::Lift {
            dst: 1,
            src: 0,
            count: 5,
        }],
        buffers: vec![
            BufferMetadata {
                size: 5,
                alignment: 32,
                buffer_type: BufferType::Input,
                fully_written: false,
            },
            BufferMetadata {
                size: 10, // 2 bytes per input (offset + page)
                alignment: 32,
                buffer_type: BufferType::Output,
                fully_written: false,
            },
        ],
        constants: vec![],
        workspace_size: 0,
        dependencies: vec![],
        metadata: PlanMetadata::default(),
        node_buffer_map: vec![],
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let mut output = vec![0u8; 10]; // 2 bytes per input
    backend.execute_plan(&plan, &[&input], &mut [&mut output])?;

    // Parse output as (offset, page) pairs
    println!("Lifted coordinates:");
    for (i, byte) in input.iter().enumerate() {
        let offset = output[i * 2];
        let page = output[i * 2 + 1];
        println!("  {} -> (offset={}, page={})", byte, offset, page);
    }
    println!("(Each byte maps to its position on the 48×256 torus)");

    Ok(())
}

/// Demonstrates orbit classification.
fn run_orbit_classify_example(backend: &CpuBackend) -> Result<(), Box<dyn std::error::Error>> {
    // OrbitClassify assigns each byte to one of 32 orbit classes.
    // Class = byte / 8, giving classes 0..31.

    let input: Vec<u8> = vec![0, 1, 2, 17, 96, 255];
    println!("Input bytes: {:?}", input);

    let plan = BackendPlan {
        instructions: vec![IsaInstruction::OrbitClassify {
            dst: 1,
            src: 0,
            count: 6,
        }],
        buffers: vec![
            BufferMetadata {
                size: 6,
                alignment: 32,
                buffer_type: BufferType::Input,
                fully_written: false,
            },
            BufferMetadata {
                size: 6,
                alignment: 32,
                buffer_type: BufferType::Output,
                fully_written: false,
            },
        ],
        constants: vec![],
        workspace_size: 0,
        dependencies: vec![],
        metadata: PlanMetadata::default(),
        node_buffer_map: vec![],
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let mut output = vec![0u8; 6];
    backend.execute_plan(&plan, &[&input], &mut [&mut output])?;

    println!("Orbit classes: {:?}", output);
    println!("(Class = byte / 8, giving 0..31)");

    Ok(())
}

/// Demonstrates ring arithmetic modulo 96.
fn run_ring_arithmetic_example(backend: &CpuBackend) -> Result<(), Box<dyn std::error::Error>> {
    // Ring operations work modulo 96 (the resonance modulus R = T × B = 3 × 32)

    let a: Vec<u8> = vec![10, 50, 90, 95];
    let b: Vec<u8> = vec![20, 60, 10, 5];
    println!("A: {:?}", a);
    println!("B: {:?}", b);

    // Ring addition: (a + b) mod 96
    let add_plan = BackendPlan {
        instructions: vec![IsaInstruction::RingAdd {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        }],
        buffers: vec![
            BufferMetadata {
                size: 4,
                alignment: 32,
                buffer_type: BufferType::Input,
                fully_written: false,
            },
            BufferMetadata {
                size: 4,
                alignment: 32,
                buffer_type: BufferType::Input,
                fully_written: false,
            },
            BufferMetadata {
                size: 4,
                alignment: 32,
                buffer_type: BufferType::Output,
                fully_written: false,
            },
        ],
        constants: vec![],
        workspace_size: 0,
        dependencies: vec![],
        metadata: PlanMetadata::default(),
        node_buffer_map: vec![],
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let mut add_result = vec![0u8; 4];
    backend.execute_plan(&add_plan, &[&a, &b], &mut [&mut add_result])?;

    println!("\nRing Addition (mod 96):");
    for i in 0..4 {
        println!(
            "  {} + {} = {} (mod 96) = {}",
            a[i],
            b[i],
            a[i] as u16 + b[i] as u16,
            add_result[i]
        );
    }

    // Ring multiplication: (a * b) mod 96
    let mul_plan = BackendPlan {
        instructions: vec![IsaInstruction::RingMul {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        }],
        buffers: vec![
            BufferMetadata {
                size: 4,
                alignment: 32,
                buffer_type: BufferType::Input,
                fully_written: false,
            },
            BufferMetadata {
                size: 4,
                alignment: 32,
                buffer_type: BufferType::Input,
                fully_written: false,
            },
            BufferMetadata {
                size: 4,
                alignment: 32,
                buffer_type: BufferType::Output,
                fully_written: false,
            },
        ],
        constants: vec![],
        workspace_size: 0,
        dependencies: vec![],
        metadata: PlanMetadata::default(),
        node_buffer_map: vec![],
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let mut mul_result = vec![0u8; 4];
    backend.execute_plan(&mul_plan, &[&a, &b], &mut [&mut mul_result])?;

    println!("\nRing Multiplication (mod 96):");
    for i in 0..4 {
        println!(
            "  {} * {} = {} (mod 96) = {}",
            a[i],
            b[i],
            a[i] as u16 * b[i] as u16,
            mul_result[i]
        );
    }

    Ok(())
}
