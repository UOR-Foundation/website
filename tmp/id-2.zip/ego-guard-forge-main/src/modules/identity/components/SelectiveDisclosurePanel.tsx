/**
 * SelectiveDisclosurePanel — Choose exactly what to share.
 *
 * Plain language, visual, intuitive. No cryptographic jargon.
 * Users pick categories, generate a shareable proof, done.
 */

import { useState, useCallback } from "react";
import { Eye, EyeOff, ShieldCheck, Loader2, Copy, Check } from "lucide-react";
import type { SovereigntySurface, BoundaryEdge } from "../types";
import type { DisclosureProof } from "../engine/disclosure-engine";
import {
  createDisclosureProof,
  verifyDisclosureProof,
  proofSummary,
} from "../engine/disclosure-engine";
import { SOVEREIGNTY_DIMENSIONS, edgesByDimension } from "../engine/sovereignty-engine";

interface Props {
  readonly surface: SovereigntySurface;
}

/* Human-friendly dimension labels */
const DIM_LABELS: Record<string, string> = {
  identity: "Who you are",
  data: "Your data",
  compute: "Your devices",
  social: "Your connections",
  economic: "Your finances",
  governance: "Your decisions",
};

export default function SelectiveDisclosurePanel({ surface }: Props) {
  const [selectedEdges, setSelectedEdges] = useState<Set<number>>(new Set());
  const [proof, setProof] = useState<DisclosureProof | null>(null);
  const [verified, setVerified] = useState<boolean | null>(null);
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const toggleDimension = useCallback(
    (dimId: string) => {
      const dimEdges = edgesByDimension(surface, dimId as any);
      const dimIndices = dimEdges.map((e) => e.index);
      const allSelected = dimIndices.every((i) => selectedEdges.has(i));

      setSelectedEdges((prev) => {
        const next = new Set(prev);
        for (const idx of dimIndices) {
          if (allSelected) next.delete(idx);
          else next.add(idx);
        }
        return next;
      });
      setProof(null);
      setVerified(null);
    },
    [surface, selectedEdges],
  );

  const handleGenerate = useCallback(async () => {
    if (selectedEdges.size === 0) return;
    setGenerating(true);
    try {
      const p = await createDisclosureProof(surface, Array.from(selectedEdges));
      setProof(p);
      setVerified(null);
    } finally {
      setGenerating(false);
    }
  }, [surface, selectedEdges]);

  const handleVerify = useCallback(async () => {
    if (!proof) return;
    const result = await verifyDisclosureProof(proof);
    setVerified(result.valid);
  }, [proof]);

  const handleCopy = useCallback(() => {
    if (!proof) return;
    navigator.clipboard.writeText(JSON.stringify(proof, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [proof]);

  const summary = proof ? proofSummary(proof) : null;

  return (
    <div className="rounded-2xl border border-border/15 bg-card/30 p-6 animate-fade-in space-y-5">
      <p className="text-sm text-muted-foreground/50">
        Pick the categories you'd like to share. Everything else stays completely private.
      </p>

      {/* Category toggles */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {SOVEREIGNTY_DIMENSIONS.map((dim) => {
          const dimEdges = edgesByDimension(surface, dim.id);
          const dimIndices = dimEdges.map((e: BoundaryEdge) => e.index);
          const selectedCount = dimIndices.filter((i) => selectedEdges.has(i)).length;
          const allSelected = selectedCount === dimIndices.length && dimIndices.length > 0;

          return (
            <button
              key={dim.id}
              onClick={() => toggleDimension(dim.id)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-500 border
                ${allSelected
                  ? "bg-primary/10 border-primary/25 text-primary"
                  : selectedCount > 0
                    ? "bg-primary/5 border-primary/15 text-primary/70"
                    : "bg-muted/20 border-border/15 text-muted-foreground/50 hover:border-border/30 hover:text-foreground/70"
                }`}
            >
              {allSelected ? (
                <Eye className="h-4 w-4 shrink-0" />
              ) : (
                <EyeOff className="h-4 w-4 shrink-0" />
              )}
              <span className="text-sm font-medium">{DIM_LABELS[dim.id] || dim.label}</span>
            </button>
          );
        })}
      </div>

      {/* Share button */}
      <div className="flex gap-2 pt-1">
        <button
          onClick={handleGenerate}
          disabled={selectedEdges.size === 0 || generating}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium bg-primary text-primary-foreground disabled:opacity-30 transition-all duration-500"
        >
          {generating ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <ShieldCheck className="h-3.5 w-3.5" />
          )}
          Share selected ({selectedEdges.size})
        </button>

        {proof && (
          <>
            <button
              onClick={handleVerify}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm border border-border/20 text-foreground/70 hover:text-foreground hover:bg-muted/20 transition-all duration-500"
            >
              <ShieldCheck className="h-3.5 w-3.5" />
              Check
            </button>
            <button
              onClick={handleCopy}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm border border-border/20 text-muted-foreground/50 hover:text-foreground transition-all duration-500"
            >
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? "Copied" : "Copy"}
            </button>
          </>
        )}
      </div>

      {/* Result */}
      {proof && summary && (
        <div className="rounded-xl border border-border/15 bg-muted/20 p-5 space-y-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-primary/60" />
            <span className="text-sm font-medium text-foreground">Ready to share</span>
            {verified !== null && (
              <span
                className={`ml-auto text-xs font-medium px-2.5 py-0.5 rounded-full ${
                  verified
                    ? "bg-primary/10 text-primary"
                    : "bg-destructive/10 text-destructive"
                }`}
              >
                {verified ? "✓ Verified" : "✗ Problem found"}
              </span>
            )}
          </div>

          <p className="text-xs text-muted-foreground/50">
            Sharing {summary.revealedCount} of {summary.totalEdges} data points ({summary.disclosurePercent}%). 
            Everything else remains completely hidden.
          </p>
        </div>
      )}
    </div>
  );
}
