//! Operation benchmarks for prism stdlib.

use criterion::{black_box, criterion_group, criterion_main, Criterion, Throughput};
use prism::prelude::*;

fn bench_state_creation(c: &mut Criterion) {
    let mut group = c.benchmark_group("state_creation");
    group.throughput(Throughput::Elements(1));

    group.bench_function("zeros", |b| {
        b.iter(|| black_box(State::zeros()));
    });

    group.bench_function("ones", |b| {
        b.iter(|| black_box(State::ones()));
    });

    group.bench_function("from_bytes_624", |b| {
        let data = [0xAB_u8; 624];
        b.iter(|| black_box(State::from_bytes(black_box(&data))));
    });

    group.finish();
}

fn bench_elementwise(c: &mut Criterion) {
    let mut group = c.benchmark_group("elementwise");
    group.throughput(Throughput::Bytes(624));

    let a = State::from_bytes(&[0xAA; 624]);
    let b = State::from_bytes(&[0x55; 624]);

    group.bench_function("xor", |bench| {
        bench.iter(|| black_box(xor(black_box(a), black_box(b))));
    });

    group.bench_function("and", |bench| {
        bench.iter(|| black_box(and(black_box(a), black_box(b))));
    });

    group.bench_function("or", |bench| {
        bench.iter(|| black_box(or(black_box(a), black_box(b))));
    });

    group.bench_function("not", |bench| {
        bench.iter(|| black_box(not(black_box(a))));
    });

    group.bench_function("add", |bench| {
        bench.iter(|| black_box(add(black_box(a), black_box(b))));
    });

    group.bench_function("sub", |bench| {
        bench.iter(|| black_box(sub(black_box(a), black_box(b))));
    });

    group.bench_function("shl_8", |bench| {
        bench.iter(|| black_box(shl(black_box(a), 8)));
    });

    group.bench_function("shr_8", |bench| {
        bench.iter(|| black_box(shr(black_box(a), 8)));
    });

    group.bench_function("rotl_7", |bench| {
        bench.iter(|| black_box(rotl(black_box(a), 7)));
    });

    group.bench_function("rotr_7", |bench| {
        bench.iter(|| black_box(rotr(black_box(a), 7)));
    });

    group.finish();
}

fn bench_reduce(c: &mut Criterion) {
    let mut group = c.benchmark_group("reduce");
    group.throughput(Throughput::Bytes(624));

    let s = State::from_bytes(&[0xDE; 624]);

    group.bench_function("xor_reduce", |bench| {
        bench.iter(|| black_box(xor_reduce(black_box(&s))));
    });

    group.bench_function("sum", |bench| {
        bench.iter(|| black_box(sum(black_box(&s))));
    });

    group.bench_function("max", |bench| {
        bench.iter(|| black_box(max(black_box(&s))));
    });

    group.bench_function("min", |bench| {
        bench.iter(|| black_box(min(black_box(&s))));
    });

    group.finish();
}

fn bench_shuffle(c: &mut Criterion) {
    let mut group = c.benchmark_group("shuffle");
    group.throughput(Throughput::Bytes(624));

    let s = State::from_bytes(&[0xCD; 624]);

    // Identity shuffle indices
    let mut indices = [0u8; State::LEN];
    #[allow(clippy::cast_possible_truncation)]
    for (i, item) in indices.iter_mut().enumerate().take(State::LEN) {
        *item = i as u8;
    }

    group.bench_function("shuffle_identity", |bench| {
        bench.iter(|| black_box(shuffle(black_box(&s), black_box(&indices))));
    });

    group.bench_function("broadcast_0", |bench| {
        bench.iter(|| black_box(broadcast(black_box(&s), 0)));
    });

    group.finish();
}

fn bench_programs(c: &mut Criterion) {
    let mut group = c.benchmark_group("programs");
    group.throughput(Throughput::Elements(1));

    group.bench_function("sha256_compress", |bench| {
        let mut s = State::zeros();
        bench.iter(|| {
            sha256_compress(black_box(&mut s));
        });
    });

    group.bench_function("aes128_encrypt", |bench| {
        let mut s = State::zeros();
        bench.iter(|| {
            aes128_encrypt(black_box(&mut s));
        });
    });

    group.bench_function("aes256_encrypt", |bench| {
        let mut s = State::zeros();
        bench.iter(|| {
            aes256_encrypt(black_box(&mut s));
        });
    });

    group.finish();
}

criterion_group!(
    benches,
    bench_state_creation,
    bench_elementwise,
    bench_reduce,
    bench_shuffle,
    bench_programs
);
criterion_main!(benches);
