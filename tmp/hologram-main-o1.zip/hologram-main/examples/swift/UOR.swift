/**
 * UOR Swift Bindings (C Interop, ~5-10ns/call)
 *
 * High-level Swift wrapper around C FFI bindings.
 *
 * Usage:
 *     import UOR
 *     let uor = UOR()
 *     let braille = uor.byteToBraille(42)
 */

import Foundation
import CUOR

public class UOR {
    public init() {}

    // Constants
    public var brailleBase: UInt32 { uor_braille_base() }
    public var brailleMax: UInt32 { uor_braille_max() }
    public var triadicConstant: UInt32 { uor_triadic_constant() }
    public var octaveConstant: UInt32 { uor_octave_constant() }
    public var stateTaxons: UInt32 { uor_state_taxons() }
    public var stateBits: UInt32 { uor_state_bits() }

    // Taxon Operations
    public func byteToBraille(_ value: UInt8) -> String {
        let cString = uor_byte_to_braille(value)
        defer { uor_string_free(UnsafeMutablePointer(mutating: cString)) }
        return String(cString: cString!)
    }

    public func byteToCodepoint(_ value: UInt8) -> UInt32 {
        uor_byte_to_codepoint(value)
    }

    public func byteToDomain(_ value: UInt8) -> UInt8 {
        uor_byte_to_domain(value)
    }

    public func byteRank(_ value: UInt8) -> UInt8 {
        uor_byte_rank(value)
    }

    // Ring Operations
    public func byteSucc(_ value: UInt8) -> UInt8 {
        uor_byte_succ(value)
    }

    public func bytePred(_ value: UInt8) -> UInt8 {
        uor_byte_pred(value)
    }

    public func byteNot(_ value: UInt8) -> UInt8 {
        uor_byte_not(value)
    }

    // View Operations
    public func viewIdentity() -> View {
        View(ptr: uor_view_identity())
    }

    public func viewConstant(_ value: UInt8) -> View? {
        guard let ptr = uor_view_constant(value) else { return nil }
        return View(ptr: ptr)
    }
}

public class View {
    private var ptr: OpaquePointer?

    init(ptr: OpaquePointer?) {
        self.ptr = ptr
    }

    deinit {
        if let ptr = ptr {
            uor_view_free(UnsafeMutablePointer(mutating: ptr))
        }
    }

    public func apply(_ value: UInt8) -> UInt8 {
        guard let ptr = ptr else { return 0 }
        return uor_view_apply(ptr, value)
    }

    public func applySlice(_ data: [UInt8]) -> [UInt8] {
        guard let ptr = ptr else { return [] }
        var output = [UInt8](repeating: 0, count: data.count)
        data.withUnsafeBytes { inputPtr in
            output.withUnsafeMutableBytes { outputPtr in
                uor_view_apply_slice(ptr, inputPtr.baseAddress!.assumingMemoryBound(to: UInt8.self), data.count, outputPtr.baseAddress!.assumingMemoryBound(to: UInt8.self))
            }
        }
        return output
    }

    public func isBijective() -> Bool {
        guard let ptr = ptr else { return false }
        return uor_view_is_bijective(ptr)
    }

    public func inverse() -> View? {
        guard let ptr = ptr else { return nil }
        guard let invPtr = uor_view_inverse(ptr) else { return nil }
        return View(ptr: invPtr)
    }

    public func then(_ other: View) -> View? {
        guard let ptr = ptr, let otherPtr = other.ptr else { return nil }
        guard let composedPtr = uor_view_then(ptr, otherPtr) else { return nil }
        return View(ptr: composedPtr)
    }
}
