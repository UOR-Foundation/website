//! SHA-256 hasher with incremental update support.

use crate::compress::H0;
use crate::simd::compress; // Use SIMD-optimized compress with SHA-NI auto-dispatch

/// SHA-256 digest (32 bytes).
#[derive(Clone, Copy, PartialEq, Eq, Hash)]
pub struct Sha256Digest(pub [u8; 32]);

impl Sha256Digest {
    /// Create a digest from raw bytes.
    #[must_use]
    pub const fn from_bytes(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }

    /// Get the digest as a byte slice.
    #[must_use]
    pub const fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }

    /// Convert to hex string.
    #[must_use]
    pub fn to_hex(&self) -> String {
        self.0.iter().map(|b| format!("{b:02x}")).collect()
    }

    /// Get length in bytes.
    #[must_use]
    pub const fn len(&self) -> usize {
        32
    }

    /// Check if empty (always false for digest).
    #[must_use]
    pub const fn is_empty(&self) -> bool {
        false
    }
}

impl AsRef<[u8]> for Sha256Digest {
    fn as_ref(&self) -> &[u8] {
        &self.0
    }
}

impl From<[u8; 32]> for Sha256Digest {
    fn from(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }
}

impl From<Sha256Digest> for [u8; 32] {
    fn from(digest: Sha256Digest) -> [u8; 32] {
        digest.0
    }
}

impl std::fmt::Debug for Sha256Digest {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Sha256Digest({})", self.to_hex())
    }
}

impl std::fmt::Display for Sha256Digest {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.to_hex())
    }
}

/// SHA-256 hasher with incremental update support.
///
/// # Example
///
/// ```
/// use hologram_sha256::Sha256;
///
/// let mut hasher = Sha256::new();
/// hasher.update(b"hello ");
/// hasher.update(b"world");
/// let hash = hasher.finalize();
/// ```
#[derive(Clone)]
pub struct Sha256 {
    /// Current hash state (8 x 32-bit words).
    state: [u32; 8],
    /// Buffer for incomplete block.
    buffer: [u8; 64],
    /// Number of bytes in buffer.
    buffer_len: usize,
    /// Total message length in bits (for padding).
    total_len: u64,
}

impl Default for Sha256 {
    fn default() -> Self {
        Self::new()
    }
}

impl Sha256 {
    /// Create a new SHA-256 hasher.
    #[must_use]
    pub fn new() -> Self {
        Self {
            state: H0,
            buffer: [0u8; 64],
            buffer_len: 0,
            total_len: 0,
        }
    }

    /// Update the hasher with input data.
    pub fn update(&mut self, data: &[u8]) {
        self.total_len += (data.len() as u64) * 8;
        let mut offset = 0;

        // If we have buffered data, try to complete a block
        if self.buffer_len > 0 {
            let needed = 64 - self.buffer_len;
            if data.len() >= needed {
                self.buffer[self.buffer_len..64].copy_from_slice(&data[..needed]);
                compress(&mut self.state, &self.buffer);
                self.buffer_len = 0;
                offset = needed;
            } else {
                self.buffer[self.buffer_len..self.buffer_len + data.len()].copy_from_slice(data);
                self.buffer_len += data.len();
                return;
            }
        }

        // Process complete blocks
        while offset + 64 <= data.len() {
            compress(
                &mut self.state,
                data[offset..offset + 64].try_into().unwrap(),
            );
            offset += 64;
        }

        // Buffer remaining data
        if offset < data.len() {
            let remaining = data.len() - offset;
            self.buffer[..remaining].copy_from_slice(&data[offset..]);
            self.buffer_len = remaining;
        }
    }

    /// Finalize and return the digest, consuming the hasher.
    #[must_use]
    pub fn finalize(mut self) -> Sha256Digest {
        // Pad the message
        self.pad();

        // Convert state to bytes (big-endian)
        let mut digest = [0u8; 32];
        for (i, word) in self.state.iter().enumerate() {
            digest[i * 4..(i + 1) * 4].copy_from_slice(&word.to_be_bytes());
        }

        Sha256Digest(digest)
    }

    /// Compute the SHA-256 digest of data in one shot.
    #[must_use]
    pub fn digest(data: &[u8]) -> Sha256Digest {
        let mut hasher = Self::new();
        hasher.update(data);
        hasher.finalize()
    }

    /// Apply SHA-256 padding.
    fn pad(&mut self) {
        // Append 1 bit (0x80 byte)
        self.buffer[self.buffer_len] = 0x80;
        self.buffer_len += 1;

        // If not enough room for length, process and start new block
        if self.buffer_len > 56 {
            self.buffer[self.buffer_len..64].fill(0);
            compress(&mut self.state, &self.buffer);
            self.buffer_len = 0;
        }

        // Pad with zeros up to length field
        self.buffer[self.buffer_len..56].fill(0);

        // Append message length in bits (big-endian)
        self.buffer[56..64].copy_from_slice(&self.total_len.to_be_bytes());

        // Process final block
        compress(&mut self.state, &self.buffer);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_incremental_same_as_oneshot() {
        let mut hasher = Sha256::new();
        hasher.update(b"hello ");
        hasher.update(b"world");
        let hash1 = hasher.finalize();

        let hash2 = Sha256::digest(b"hello world");
        assert_eq!(hash1, hash2);
    }

    #[test]
    fn test_empty_string() {
        let hash = Sha256::digest(b"");
        assert_eq!(
            hash.to_hex(),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
    }

    #[test]
    fn test_digest_len() {
        let hash = Sha256::digest(b"test");
        assert_eq!(hash.len(), 32);
        assert!(!hash.is_empty());
    }

    #[test]
    fn test_digest_debug_display() {
        let hash = Sha256::digest(b"test");
        let hex = hash.to_hex();
        assert!(format!("{:?}", hash).contains(&hex));
        assert_eq!(format!("{}", hash), hex);
    }
}
