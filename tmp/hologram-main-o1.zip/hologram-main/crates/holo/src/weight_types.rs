//! Weight tensor types and metadata.
//!
//! This module provides types for describing weight tensors in `.holo` bundles,
//! including data types, quantization parameters, and tensor metadata.
//!
//! # Example
//!
//! ```rust
//! use hologram_holo::weight_types::{TensorMetadata, WeightDType, QuantizationScheme};
//!
//! let tensor = TensorMetadata::builder()
//!     .name("encoder.weight")
//!     .shape(vec![768, 512])
//!     .dtype(WeightDType::F32)
//!     .offset(0)
//!     .size(768 * 512 * 4)
//!     .build()
//!     .unwrap();
//!
//! assert_eq!(tensor.element_count(), 768 * 512);
//! assert!(!tensor.has_symbolic_dims());
//! ```

use rkyv::{Archive, Deserialize, Serialize};

use crate::error::BuilderError;

// ============================================================================
// Data Type Enum
// ============================================================================

/// Supported data types for weight tensors.
///
/// Each variant maps to a specific byte representation used in model weights.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
#[repr(u8)]
pub enum WeightDType {
    /// 32-bit floating point (IEEE 754)
    #[default]
    F32 = 0,
    /// 64-bit floating point (IEEE 754)
    F64 = 1,
    /// 16-bit floating point (IEEE 754)
    F16 = 2,
    /// Brain floating point (16-bit, truncated mantissa)
    BF16 = 3,
    /// 8-bit signed integer
    I8 = 4,
    /// 8-bit unsigned integer
    U8 = 5,
    /// 16-bit signed integer
    I16 = 6,
    /// 32-bit signed integer
    I32 = 7,
    /// 64-bit signed integer
    I64 = 8,
    /// 4-bit signed integer (packed, 2 elements per byte)
    I4 = 9,
}

impl WeightDType {
    /// Returns the number of bytes per element.
    ///
    /// Returns 0 for sub-byte types (e.g., I4) where multiple elements
    /// are packed into a single byte.
    #[must_use]
    pub const fn bytes_per_element(self) -> usize {
        match self {
            Self::F32 | Self::I32 => 4,
            Self::F64 | Self::I64 => 8,
            Self::F16 | Self::BF16 | Self::I16 => 2,
            Self::I8 | Self::U8 => 1,
            Self::I4 => 0, // 2 elements per byte
        }
    }

    /// Returns the number of bits per element.
    #[must_use]
    pub const fn bits_per_element(self) -> usize {
        match self {
            Self::F64 | Self::I64 => 64,
            Self::F32 | Self::I32 => 32,
            Self::F16 | Self::BF16 | Self::I16 => 16,
            Self::I8 | Self::U8 => 8,
            Self::I4 => 4,
        }
    }

    /// Returns true if this is a floating-point type.
    #[must_use]
    pub const fn is_float(self) -> bool {
        matches!(self, Self::F32 | Self::F64 | Self::F16 | Self::BF16)
    }

    /// Returns true if this is a sub-byte type (packed elements).
    #[must_use]
    pub const fn is_packed(self) -> bool {
        matches!(self, Self::I4)
    }
}

// ============================================================================
// Quantization Types
// ============================================================================

/// Quantization scheme for weight tensors.
///
/// Different schemes trade off between accuracy, memory savings, and
/// computational complexity.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
#[repr(u8)]
pub enum QuantizationScheme {
    /// No quantization (full precision)
    #[default]
    None = 0,
    /// Symmetric per-tensor quantization (single scale, `zero_point`=0)
    SymmetricPerTensor = 1,
    /// Asymmetric per-tensor quantization (single scale and `zero_point`)
    AsymmetricPerTensor = 2,
    /// Symmetric per-channel quantization (one scale per output channel)
    SymmetricPerChannel = 3,
    /// Asymmetric per-channel quantization (scale and `zero_point` per channel)
    AsymmetricPerChannel = 4,
    /// Group-wise quantization (e.g., GPTQ, AWQ)
    GroupWise = 5,
}

/// Quantization parameters for a weight tensor.
///
/// These parameters define how quantized integer values map to floating-point
/// values during dequantization: `float_value = (int_value - zero_point) * scale`
#[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct QuantizationParams {
    /// Quantization scheme identifier
    pub scheme: QuantizationScheme,
    /// Scale factor(s) for dequantization
    pub scale: Vec<f32>,
    /// Zero point(s) for asymmetric quantization
    pub zero_point: Vec<i32>,
    /// Minimum observed value (calibration data)
    pub min: Option<f32>,
    /// Maximum observed value (calibration data)
    pub max: Option<f32>,
    /// Group size for group-wise quantization (0 = per-tensor)
    pub group_size: u32,
}

impl Default for QuantizationParams {
    fn default() -> Self {
        Self {
            scheme: QuantizationScheme::None,
            scale: Vec::new(),
            zero_point: Vec::new(),
            min: None,
            max: None,
            group_size: 0,
        }
    }
}

impl QuantizationParams {
    /// Create quantization params for symmetric per-tensor quantization.
    #[must_use]
    pub fn symmetric_per_tensor(scale: f32) -> Self {
        Self {
            scheme: QuantizationScheme::SymmetricPerTensor,
            scale: vec![scale],
            zero_point: vec![0],
            min: None,
            max: None,
            group_size: 0,
        }
    }

    /// Create quantization params for asymmetric per-tensor quantization.
    #[must_use]
    pub fn asymmetric_per_tensor(scale: f32, zero_point: i32) -> Self {
        Self {
            scheme: QuantizationScheme::AsymmetricPerTensor,
            scale: vec![scale],
            zero_point: vec![zero_point],
            min: None,
            max: None,
            group_size: 0,
        }
    }

    /// Create quantization params for per-channel quantization.
    #[must_use]
    pub fn per_channel(scales: Vec<f32>, zero_points: Vec<i32>, symmetric: bool) -> Self {
        Self {
            scheme: if symmetric {
                QuantizationScheme::SymmetricPerChannel
            } else {
                QuantizationScheme::AsymmetricPerChannel
            },
            scale: scales,
            zero_point: zero_points,
            min: None,
            max: None,
            group_size: 0,
        }
    }

    /// Create quantization params for group-wise quantization.
    #[must_use]
    pub fn group_wise(scales: Vec<f32>, zero_points: Vec<i32>, group_size: u32) -> Self {
        Self {
            scheme: QuantizationScheme::GroupWise,
            scale: scales,
            zero_point: zero_points,
            min: None,
            max: None,
            group_size,
        }
    }

    /// Set calibration range.
    #[must_use]
    pub fn with_range(mut self, min: f32, max: f32) -> Self {
        self.min = Some(min);
        self.max = Some(max);
        self
    }
}

// ============================================================================
// Tensor Metadata
// ============================================================================

/// Complete metadata for a single weight tensor.
///
/// Describes the tensor's location within the weights blob, its data type,
/// shape, and optional quantization parameters.
#[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct TensorMetadata {
    /// Unique tensor name/identifier (e.g., "encoder.layer.0.weight")
    pub name: String,
    /// Shape specification. Negative values indicate symbolic dimensions:
    /// -1 = batch, -2 = sequence length, etc.
    pub shape: Vec<i64>,
    /// Data type
    pub dtype: WeightDType,
    /// Offset within weights blob (bytes)
    pub offset: u64,
    /// Size in bytes
    pub size: u64,
    /// Optional quantization parameters
    pub quantization: Option<QuantizationParams>,
    /// CRC32 checksum of tensor data
    pub checksum: u32,
}

impl TensorMetadata {
    /// Create a builder for constructing tensor metadata.
    #[must_use]
    pub fn builder() -> TensorMetadataBuilder {
        TensorMetadataBuilder::new()
    }

    /// Calculate element count from shape (excludes symbolic dimensions).
    #[must_use]
    #[allow(clippy::cast_sign_loss, clippy::cast_possible_truncation)]
    pub fn element_count(&self) -> usize {
        self.shape
            .iter()
            .filter(|&&d| d > 0)
            .map(|&d| {
                // Safe: we filtered to positive values only, and shape dims
                // won't exceed usize on any practical platform
                d as usize
            })
            .product()
    }

    /// Check if shape contains symbolic dimensions.
    #[must_use]
    pub fn has_symbolic_dims(&self) -> bool {
        self.shape.iter().any(|&d| d < 0)
    }

    /// Check if the tensor is quantized.
    #[must_use]
    pub fn is_quantized(&self) -> bool {
        self.quantization
            .as_ref()
            .is_some_and(|q| q.scheme != QuantizationScheme::None)
    }

    /// Get the end offset (offset + size).
    #[must_use]
    pub fn end_offset(&self) -> u64 {
        self.offset + self.size
    }
}

// ============================================================================
// Builder Pattern
// ============================================================================

/// Builder for constructing `TensorMetadata`.
#[derive(Debug, Default)]
pub struct TensorMetadataBuilder {
    name: Option<String>,
    shape: Option<Vec<i64>>,
    dtype: Option<WeightDType>,
    offset: Option<u64>,
    size: Option<u64>,
    quantization: Option<QuantizationParams>,
    checksum: Option<u32>,
}

impl TensorMetadataBuilder {
    /// Create a new builder with default values.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the tensor name.
    #[must_use]
    pub fn name(mut self, name: impl Into<String>) -> Self {
        self.name = Some(name.into());
        self
    }

    /// Set the tensor shape.
    #[must_use]
    pub fn shape(mut self, shape: impl Into<Vec<i64>>) -> Self {
        self.shape = Some(shape.into());
        self
    }

    /// Set the data type.
    #[must_use]
    pub fn dtype(mut self, dtype: WeightDType) -> Self {
        self.dtype = Some(dtype);
        self
    }

    /// Set the offset within the weights blob.
    #[must_use]
    pub fn offset(mut self, offset: u64) -> Self {
        self.offset = Some(offset);
        self
    }

    /// Set the size in bytes.
    #[must_use]
    pub fn size(mut self, size: u64) -> Self {
        self.size = Some(size);
        self
    }

    /// Set quantization parameters.
    #[must_use]
    pub fn quantization(mut self, params: QuantizationParams) -> Self {
        self.quantization = Some(params);
        self
    }

    /// Set the CRC32 checksum.
    #[must_use]
    pub fn checksum(mut self, checksum: u32) -> Self {
        self.checksum = Some(checksum);
        self
    }

    /// Build the `TensorMetadata`, returning an error if required fields are missing.
    ///
    /// # Errors
    ///
    /// Returns `BuilderError::MissingField` if name, shape, dtype, offset, or size
    /// is not set.
    pub fn build(self) -> Result<TensorMetadata, BuilderError> {
        Ok(TensorMetadata {
            name: self.name.ok_or(BuilderError::missing_field("name"))?,
            shape: self.shape.ok_or(BuilderError::missing_field("shape"))?,
            dtype: self.dtype.ok_or(BuilderError::missing_field("dtype"))?,
            offset: self.offset.ok_or(BuilderError::missing_field("offset"))?,
            size: self.size.ok_or(BuilderError::missing_field("size"))?,
            quantization: self.quantization,
            checksum: self.checksum.unwrap_or(0),
        })
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    // ------------------------------------------------------------------------
    // WeightDType Tests
    // ------------------------------------------------------------------------

    #[test]
    fn test_dtype_bytes_per_element() {
        assert_eq!(WeightDType::F32.bytes_per_element(), 4);
        assert_eq!(WeightDType::F64.bytes_per_element(), 8);
        assert_eq!(WeightDType::F16.bytes_per_element(), 2);
        assert_eq!(WeightDType::BF16.bytes_per_element(), 2);
        assert_eq!(WeightDType::I8.bytes_per_element(), 1);
        assert_eq!(WeightDType::U8.bytes_per_element(), 1);
        assert_eq!(WeightDType::I16.bytes_per_element(), 2);
        assert_eq!(WeightDType::I32.bytes_per_element(), 4);
        assert_eq!(WeightDType::I64.bytes_per_element(), 8);
        assert_eq!(WeightDType::I4.bytes_per_element(), 0);
    }

    #[test]
    fn test_dtype_bits_per_element() {
        assert_eq!(WeightDType::F32.bits_per_element(), 32);
        assert_eq!(WeightDType::F64.bits_per_element(), 64);
        assert_eq!(WeightDType::F16.bits_per_element(), 16);
        assert_eq!(WeightDType::I4.bits_per_element(), 4);
    }

    #[test]
    fn test_dtype_is_float() {
        assert!(WeightDType::F32.is_float());
        assert!(WeightDType::F64.is_float());
        assert!(WeightDType::F16.is_float());
        assert!(WeightDType::BF16.is_float());
        assert!(!WeightDType::I8.is_float());
        assert!(!WeightDType::I4.is_float());
    }

    #[test]
    fn test_dtype_is_packed() {
        assert!(WeightDType::I4.is_packed());
        assert!(!WeightDType::I8.is_packed());
        assert!(!WeightDType::F32.is_packed());
    }

    #[test]
    fn test_dtype_default() {
        assert_eq!(WeightDType::default(), WeightDType::F32);
    }

    // ------------------------------------------------------------------------
    // QuantizationParams Tests
    // ------------------------------------------------------------------------

    #[test]
    fn test_quantization_symmetric_per_tensor() {
        let params = QuantizationParams::symmetric_per_tensor(0.5);
        assert_eq!(params.scheme, QuantizationScheme::SymmetricPerTensor);
        assert_eq!(params.scale, vec![0.5]);
        assert_eq!(params.zero_point, vec![0]);
    }

    #[test]
    fn test_quantization_asymmetric_per_tensor() {
        let params = QuantizationParams::asymmetric_per_tensor(0.25, 128);
        assert_eq!(params.scheme, QuantizationScheme::AsymmetricPerTensor);
        assert_eq!(params.scale, vec![0.25]);
        assert_eq!(params.zero_point, vec![128]);
    }

    #[test]
    fn test_quantization_per_channel() {
        let params = QuantizationParams::per_channel(vec![0.1, 0.2, 0.3], vec![0, 0, 0], true);
        assert_eq!(params.scheme, QuantizationScheme::SymmetricPerChannel);
        assert_eq!(params.scale.len(), 3);
    }

    #[test]
    fn test_quantization_group_wise() {
        let params = QuantizationParams::group_wise(vec![0.1; 8], vec![0; 8], 128);
        assert_eq!(params.scheme, QuantizationScheme::GroupWise);
        assert_eq!(params.group_size, 128);
    }

    #[test]
    fn test_quantization_with_range() {
        let params = QuantizationParams::symmetric_per_tensor(1.0).with_range(-1.0, 1.0);
        assert_eq!(params.min, Some(-1.0));
        assert_eq!(params.max, Some(1.0));
    }

    #[test]
    fn test_quantization_default() {
        let params = QuantizationParams::default();
        assert_eq!(params.scheme, QuantizationScheme::None);
        assert!(params.scale.is_empty());
        assert!(params.zero_point.is_empty());
    }

    // ------------------------------------------------------------------------
    // TensorMetadata Tests
    // ------------------------------------------------------------------------

    #[test]
    fn test_tensor_metadata_builder() {
        let tensor = TensorMetadata::builder()
            .name("encoder.weight")
            .shape(vec![768, 512])
            .dtype(WeightDType::F32)
            .offset(0)
            .size(768 * 512 * 4)
            .checksum(0xDEAD_BEEF)
            .build()
            .unwrap();

        assert_eq!(tensor.name, "encoder.weight");
        assert_eq!(tensor.shape, vec![768, 512]);
        assert_eq!(tensor.dtype, WeightDType::F32);
        assert_eq!(tensor.offset, 0);
        assert_eq!(tensor.size, 768 * 512 * 4);
        assert_eq!(tensor.checksum, 0xDEAD_BEEF);
        assert!(tensor.quantization.is_none());
    }

    #[test]
    fn test_tensor_metadata_builder_with_quantization() {
        let quant = QuantizationParams::symmetric_per_tensor(0.01);
        let tensor = TensorMetadata::builder()
            .name("layer.weight")
            .shape(vec![256, 256])
            .dtype(WeightDType::I8)
            .offset(1024)
            .size(256 * 256)
            .quantization(quant)
            .build()
            .unwrap();

        assert!(tensor.quantization.is_some());
        assert!(tensor.is_quantized());
    }

    #[test]
    fn test_tensor_metadata_builder_missing_name() {
        let result = TensorMetadata::builder()
            .shape(vec![100])
            .dtype(WeightDType::F32)
            .offset(0)
            .size(400)
            .build();

        assert!(matches!(result, Err(BuilderError::MissingField("name"))));
    }

    #[test]
    fn test_tensor_metadata_builder_missing_shape() {
        let result = TensorMetadata::builder()
            .name("test")
            .dtype(WeightDType::F32)
            .offset(0)
            .size(400)
            .build();

        assert!(matches!(result, Err(BuilderError::MissingField("shape"))));
    }

    #[test]
    fn test_tensor_metadata_builder_missing_dtype() {
        let result = TensorMetadata::builder()
            .name("test")
            .shape(vec![100])
            .offset(0)
            .size(400)
            .build();

        assert!(matches!(result, Err(BuilderError::MissingField("dtype"))));
    }

    #[test]
    fn test_tensor_metadata_builder_missing_offset() {
        let result = TensorMetadata::builder()
            .name("test")
            .shape(vec![100])
            .dtype(WeightDType::F32)
            .size(400)
            .build();

        assert!(matches!(result, Err(BuilderError::MissingField("offset"))));
    }

    #[test]
    fn test_tensor_metadata_builder_missing_size() {
        let result = TensorMetadata::builder()
            .name("test")
            .shape(vec![100])
            .dtype(WeightDType::F32)
            .offset(0)
            .build();

        assert!(matches!(result, Err(BuilderError::MissingField("size"))));
    }

    #[test]
    fn test_tensor_metadata_builder_default_checksum() {
        let tensor = TensorMetadata::builder()
            .name("test")
            .shape(vec![100])
            .dtype(WeightDType::F32)
            .offset(0)
            .size(400)
            .build()
            .unwrap();

        assert_eq!(tensor.checksum, 0);
    }

    #[test]
    fn test_tensor_metadata_element_count() {
        let tensor = TensorMetadata::builder()
            .name("test")
            .shape(vec![10, 20, 30])
            .dtype(WeightDType::F32)
            .offset(0)
            .size(10 * 20 * 30 * 4)
            .build()
            .unwrap();

        assert_eq!(tensor.element_count(), 10 * 20 * 30);
    }

    #[test]
    fn test_tensor_metadata_element_count_with_symbolic() {
        let tensor = TensorMetadata::builder()
            .name("test")
            .shape(vec![-1, 512]) // batch x features
            .dtype(WeightDType::F32)
            .offset(0)
            .size(512 * 4)
            .build()
            .unwrap();

        // Symbolic dims excluded
        assert_eq!(tensor.element_count(), 512);
    }

    #[test]
    fn test_tensor_metadata_has_symbolic_dims() {
        let fixed = TensorMetadata::builder()
            .name("fixed")
            .shape(vec![100, 200])
            .dtype(WeightDType::F32)
            .offset(0)
            .size(100 * 200 * 4)
            .build()
            .unwrap();
        assert!(!fixed.has_symbolic_dims());

        let symbolic = TensorMetadata::builder()
            .name("symbolic")
            .shape(vec![-1, 200])
            .dtype(WeightDType::F32)
            .offset(0)
            .size(200 * 4)
            .build()
            .unwrap();
        assert!(symbolic.has_symbolic_dims());
    }

    #[test]
    fn test_tensor_metadata_is_quantized() {
        let fp = TensorMetadata::builder()
            .name("fp")
            .shape(vec![100])
            .dtype(WeightDType::F32)
            .offset(0)
            .size(400)
            .build()
            .unwrap();
        assert!(!fp.is_quantized());

        let quant = TensorMetadata::builder()
            .name("quant")
            .shape(vec![100])
            .dtype(WeightDType::I8)
            .offset(0)
            .size(100)
            .quantization(QuantizationParams::symmetric_per_tensor(0.01))
            .build()
            .unwrap();
        assert!(quant.is_quantized());
    }

    #[test]
    fn test_tensor_metadata_end_offset() {
        let tensor = TensorMetadata::builder()
            .name("test")
            .shape(vec![100])
            .dtype(WeightDType::F32)
            .offset(1000)
            .size(400)
            .build()
            .unwrap();

        assert_eq!(tensor.end_offset(), 1400);
    }

    // ------------------------------------------------------------------------
    // Serialization Roundtrip Tests
    // ------------------------------------------------------------------------

    #[test]
    fn test_weight_dtype_rkyv_roundtrip() {
        for dtype in [
            WeightDType::F32,
            WeightDType::F64,
            WeightDType::F16,
            WeightDType::BF16,
            WeightDType::I8,
            WeightDType::U8,
            WeightDType::I16,
            WeightDType::I32,
            WeightDType::I64,
            WeightDType::I4,
        ] {
            let bytes = rkyv::to_bytes::<_, 16>(&dtype).unwrap();
            let restored: WeightDType = rkyv::from_bytes(&bytes).unwrap();
            assert_eq!(dtype, restored);
        }
    }

    #[test]
    fn test_quantization_params_rkyv_roundtrip() {
        let params =
            QuantizationParams::group_wise(vec![0.1, 0.2], vec![10, 20], 64).with_range(-5.0, 5.0);

        let bytes = rkyv::to_bytes::<_, 256>(&params).unwrap();
        let restored: QuantizationParams = rkyv::from_bytes(&bytes).unwrap();

        assert_eq!(params.scheme, restored.scheme);
        assert_eq!(params.scale, restored.scale);
        assert_eq!(params.zero_point, restored.zero_point);
        assert_eq!(params.min, restored.min);
        assert_eq!(params.max, restored.max);
        assert_eq!(params.group_size, restored.group_size);
    }

    #[test]
    fn test_tensor_metadata_rkyv_roundtrip() {
        let tensor = TensorMetadata::builder()
            .name("encoder.layer.0.self_attn.weight")
            .shape(vec![768, 768])
            .dtype(WeightDType::F16)
            .offset(4096)
            .size(768 * 768 * 2)
            .quantization(QuantizationParams::symmetric_per_tensor(0.001))
            .checksum(0xCAFE_BABE)
            .build()
            .unwrap();

        let bytes = rkyv::to_bytes::<_, 512>(&tensor).unwrap();
        let restored: TensorMetadata = rkyv::from_bytes(&bytes).unwrap();

        assert_eq!(tensor.name, restored.name);
        assert_eq!(tensor.shape, restored.shape);
        assert_eq!(tensor.dtype, restored.dtype);
        assert_eq!(tensor.offset, restored.offset);
        assert_eq!(tensor.size, restored.size);
        assert_eq!(tensor.checksum, restored.checksum);
        assert!(restored.quantization.is_some());
    }
}
