import React, { useState } from 'react';
import GraphExplorer from './components/GraphExplorer';
import CodecDemo from './components/CodecDemo';
import TSPDemo from './components/TSPDemo';
import FactorizationDemo from './components/FactorizationDemo';
import BoundaryDemo from './components/BoundaryDemo';
import {
  Code,
  BookOpen,
  Menu,
  X,
  Layers,
  Cpu,
  Key,
  Grid3X3
} from 'lucide-react';

// Sections definition
enum Section {
  HOME = 'HOME',
  GRAPH = 'GRAPH',
  CODEC = 'CODEC',
  TSP = 'TSP',
  FACTOR = 'FACTOR',
  BOUNDARY = 'BOUNDARY'
}

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<Section>(Section.GRAPH);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const NavItem = ({ section, label, icon: Icon }: any) => (
    <button
      onClick={() => {
        setActiveSection(section);
        setMobileMenuOpen(false);
      }}
      className={`flex items-center gap-3 px-4 py-3 w-full rounded-lg transition-all duration-200 ${
        activeSection === section 
          ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30' 
          : 'text-slate-400 hover:bg-slate-800 hover:text-white'
      }`}
    >
      <Icon className="w-5 h-5" />
      <span className="font-medium">{label}</span>
    </button>
  );

  return (
    <div className="flex h-screen bg-slate-950 text-slate-200 font-sans overflow-hidden">
      
      {/* Sidebar Navigation */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 border-r border-slate-800 transform transition-transform duration-300 ease-in-out
        ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
        md:translate-x-0 md:static md:flex-shrink-0
      `}>
        <div className="p-6 border-b border-slate-800 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Layers className="w-8 h-8 text-blue-500" />
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight leading-none">UOR</h1>
              <span className="text-xs text-blue-400 font-mono uppercase tracking-widest">Framework</span>
            </div>
          </div>
          <button 
            onClick={() => setMobileMenuOpen(false)}
            className="md:hidden text-slate-400"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <nav className="p-4 space-y-2">
          <div className="px-4 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Explore
          </div>
          <NavItem section={Section.GRAPH} label="Framework Primer" icon={BookOpen} />
          
          <div className="mt-6 px-4 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Utilities
          </div>
          <NavItem section={Section.CODEC} label="Categorical Codec" icon={Code} />
          <NavItem section={Section.BOUNDARY} label="Boundary (WASM)" icon={Grid3X3} />
          <NavItem section={Section.TSP} label="Complexity Solver" icon={Cpu} />
          <NavItem section={Section.FACTOR} label="Gauge Factorization" icon={Key} />

          <div className="mt-auto pt-8 px-4">
             <div className="bg-slate-800/50 rounded p-3 border border-slate-700/50">
                <p className="text-xs text-slate-400 leading-relaxed">
                   <strong>Status:</strong> Active<br/>
                   <strong>Version:</strong> 1.0.0<br/>
                   <strong>Gauge:</strong> Ω_2,3,5
                </p>
             </div>
          </div>
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-950 relative">
        {/* Mobile Header */}
        <div className="md:hidden h-16 border-b border-slate-800 flex items-center px-4 bg-slate-900">
           <button onClick={() => setMobileMenuOpen(true)} className="text-white">
             <Menu className="w-6 h-6" />
           </button>
           <span className="ml-4 font-bold text-white">The UOR Framework</span>
        </div>

        {/* Content Viewport */}
        <div className="flex-1 overflow-hidden relative">
            {activeSection === Section.GRAPH && <GraphExplorer />}
            {activeSection === Section.CODEC && <CodecDemo />}
            {activeSection === Section.BOUNDARY && <BoundaryDemo />}
            {activeSection === Section.TSP && <TSPDemo />}
            {activeSection === Section.FACTOR && <FactorizationDemo />}

            {/* Fallback/Home content if needed, currently redirected to Graph */}
        </div>
      </main>
    </div>
  );
};

export default App;