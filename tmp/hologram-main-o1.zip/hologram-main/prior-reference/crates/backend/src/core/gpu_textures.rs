//! GPU texture support for activation table lookups.
//!
//! This module provides infrastructure for using GPU textures as activation
//! lookup tables. Texture fetches are highly optimized on GPUs, providing
//! fast, cached access to pre-computed activation values.
//!
//! # Performance Benefits
//!
//! GPU textures provide several advantages over buffer-based lookups:
//!
//! | Feature | Texture | Buffer |
//! |---------|---------|--------|
//! | Cache | Dedicated texture cache | Shared L1/L2 |
//! | Interpolation | Hardware filtering | Manual |
//! | Out-of-bounds | Clamp/wrap modes | Explicit checks |
//! | Broadcast | Efficient | Memory traffic |
//!
//! # Backend Support
//!
//! | Backend | Texture Type | Max Table Size | Notes |
//! |---------|--------------|----------------|-------|
//! | CUDA | cudaTextureObject_t | 256 bytes | tex1Dfetch for optimal cache |
//! | Metal | MTLTexture (1D) | 256 bytes | Dedicated texture cache |
//! | WebGPU | GPUTexture | 256 bytes | Uses storage buffers on some devices |
//!
//! # Usage
//!
//! Each backend (CUDA, Metal, WebGPU) creates textures from the activation
//! tables defined in `hologram_lookup::fusion::activation`. The textures
//! are then bound during kernel execution for epilogue operations.
//!
//! # Note
//!
//! The activation table registry functions are re-exported from
//! `hologram_lookup::fusion::registry` which is the single source of truth.

use hologram_lookup::fusion::activation::{GELU_U8, RELU_U8, SIGMOID_U8, SILU_U8, TANH_U8};
use hologram_lookup::fusion::inverse::{RELU_INVERSE_U8, SIGMOID_INVERSE_U8, TANH_INVERSE_U8};
use rustc_hash::FxHashMap;

// Re-export table_id and registry functions from hologram_lookup as the single source of truth
pub use hologram_lookup::fusion::registry::table_id;

/// Trait for backends that support texture-based activation lookups.
pub trait TextureActivation {
    /// Handle type for texture objects.
    type TextureHandle: Clone;

    /// Create a texture from an activation table.
    ///
    /// # Arguments
    ///
    /// * `table_id` - The activation table ID from `activation_table_id`
    ///
    /// # Returns
    ///
    /// A handle to the GPU texture, or None if textures aren't supported.
    fn create_activation_texture(&mut self, table_id: u32) -> Option<Self::TextureHandle>;

    /// Get an existing activation texture by ID.
    fn get_activation_texture(&self, table_id: u32) -> Option<&Self::TextureHandle>;

    /// Check if texture-based activations are supported.
    fn supports_texture_activations(&self) -> bool {
        true
    }

    /// Create all standard activation textures.
    ///
    /// This preloads sigmoid, tanh, relu, gelu, and silu textures.
    fn preload_standard_textures(&mut self) {
        for &id in &[
            table_id::SIGMOID,
            table_id::TANH,
            table_id::RELU,
            table_id::GELU,
            table_id::SILU,
        ] {
            let _ = self.create_activation_texture(id);
        }
    }

    /// Create all inverse activation textures.
    fn preload_inverse_textures(&mut self) {
        for &id in &[
            table_id::SIGMOID_INVERSE,
            table_id::TANH_INVERSE,
            table_id::RELU_INVERSE,
        ] {
            let _ = self.create_activation_texture(id);
        }
    }
}

/// Standard activation tables paired with their IDs.
pub const ACTIVATION_TABLES: [(u32, &[u8; 256]); 5] = [
    (table_id::SIGMOID, &SIGMOID_U8),
    (table_id::TANH, &TANH_U8),
    (table_id::RELU, &RELU_U8),
    (table_id::GELU, &GELU_U8),
    (table_id::SILU, &SILU_U8),
];

/// Inverse activation tables paired with their IDs.
pub const INVERSE_ACTIVATION_TABLES: [(u32, &[u8; 256]); 3] = [
    (table_id::SIGMOID_INVERSE, &SIGMOID_INVERSE_U8),
    (table_id::TANH_INVERSE, &TANH_INVERSE_U8),
    (table_id::RELU_INVERSE, &RELU_INVERSE_U8),
];

/// All activation tables (forward + inverse).
pub const ALL_ACTIVATION_TABLES: [(u32, &[u8; 256]); 8] = [
    (table_id::SIGMOID, &SIGMOID_U8),
    (table_id::TANH, &TANH_U8),
    (table_id::RELU, &RELU_U8),
    (table_id::GELU, &GELU_U8),
    (table_id::SILU, &SILU_U8),
    (table_id::SIGMOID_INVERSE, &SIGMOID_INVERSE_U8),
    (table_id::TANH_INVERSE, &TANH_INVERSE_U8),
    (table_id::RELU_INVERSE, &RELU_INVERSE_U8),
];

// Re-export registry functions from hologram_lookup (single source of truth)
pub use hologram_lookup::fusion::registry::{
    get_forward_id as get_forward_table_id, get_inverse_id as get_inverse_table_id,
    get_table_by_id as get_activation_table, id_to_name as get_table_name_by_id,
    name_to_id as get_table_id_by_name,
};

/// Statistics about texture usage.
#[derive(Clone, Debug, Default)]
pub struct TextureStats {
    /// Number of texture lookups performed.
    pub lookups: u64,
    /// Number of texture cache hits (if available).
    pub cache_hits: u64,
    /// Number of texture cache misses (if available).
    pub cache_misses: u64,
    /// Number of textures created.
    pub textures_created: u32,
    /// Total texture memory in bytes.
    pub texture_memory_bytes: u64,
}

impl TextureStats {
    /// Record a lookup operation.
    #[inline]
    pub fn record_lookup(&mut self) {
        self.lookups += 1;
    }

    /// Record a cache hit.
    #[inline]
    pub fn record_cache_hit(&mut self) {
        self.cache_hits += 1;
    }

    /// Record a cache miss.
    #[inline]
    pub fn record_cache_miss(&mut self) {
        self.cache_misses += 1;
    }

    /// Record texture creation.
    #[inline]
    pub fn record_texture_created(&mut self, size_bytes: u64) {
        self.textures_created += 1;
        self.texture_memory_bytes += size_bytes;
    }

    /// Get cache hit rate (0.0 to 1.0).
    pub fn cache_hit_rate(&self) -> f64 {
        let total = self.cache_hits + self.cache_misses;
        if total == 0 {
            0.0
        } else {
            self.cache_hits as f64 / total as f64
        }
    }
}

/// Generic texture cache for any backend.
///
/// This provides a common implementation for texture caching that
/// backends can use to avoid redundant texture creation.
pub struct TextureCache<H: Clone> {
    textures: FxHashMap<u32, H>,
    stats: TextureStats,
}

impl<H: Clone> Default for TextureCache<H> {
    fn default() -> Self {
        Self::new()
    }
}

impl<H: Clone> TextureCache<H> {
    /// Create a new empty cache.
    pub fn new() -> Self {
        Self {
            textures: FxHashMap::default(),
            stats: TextureStats::default(),
        }
    }

    /// Get a cached texture by ID.
    pub fn get(&self, table_id: u32) -> Option<&H> {
        self.textures.get(&table_id)
    }

    /// Insert a texture into the cache.
    pub fn insert(&mut self, table_id: u32, handle: H) {
        self.textures.insert(table_id, handle);
        self.stats.record_texture_created(256); // Standard table size
    }

    /// Get or create a texture using the provided factory.
    pub fn get_or_create<F>(&mut self, table_id: u32, factory: F) -> Option<&H>
    where
        F: FnOnce(u32) -> Option<H>,
    {
        if !self.textures.contains_key(&table_id) {
            if let Some(handle) = factory(table_id) {
                self.insert(table_id, handle);
            }
        }
        self.textures.get(&table_id)
    }

    /// Check if a texture is cached.
    pub fn contains(&self, table_id: u32) -> bool {
        self.textures.contains_key(&table_id)
    }

    /// Get statistics.
    pub fn stats(&self) -> &TextureStats {
        &self.stats
    }

    /// Get mutable statistics for recording.
    pub fn stats_mut(&mut self) -> &mut TextureStats {
        &mut self.stats
    }

    /// Clear all cached textures.
    pub fn clear(&mut self) {
        self.textures.clear();
    }

    /// Number of cached textures.
    pub fn len(&self) -> usize {
        self.textures.len()
    }

    /// Check if cache is empty.
    pub fn is_empty(&self) -> bool {
        self.textures.is_empty()
    }
}

/// Texture descriptor for creating GPU textures.
#[derive(Clone, Debug)]
pub struct TextureDescriptor {
    /// Width of the texture (number of elements).
    pub width: u32,
    /// Pixel format (R8Unorm for activation tables).
    pub format: TextureFormat,
    /// Usage flags.
    pub usage: TextureUsage,
    /// Address mode for out-of-bounds access.
    pub address_mode: TextureAddressMode,
    /// Filter mode for texture sampling.
    pub filter_mode: TextureFilterMode,
}

impl Default for TextureDescriptor {
    fn default() -> Self {
        Self::activation_table()
    }
}

impl TextureDescriptor {
    /// Create a descriptor for 256-byte activation tables.
    pub fn activation_table() -> Self {
        Self {
            width: 256,
            format: TextureFormat::R8Unorm,
            usage: TextureUsage::SHADER_READ,
            address_mode: TextureAddressMode::ClampToEdge,
            filter_mode: TextureFilterMode::Nearest,
        }
    }
}

/// Texture pixel format.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TextureFormat {
    /// 8-bit unsigned normalized (0-255 -> 0.0-1.0).
    R8Unorm,
    /// 8-bit unsigned integer.
    R8Uint,
    /// 32-bit float.
    R32Float,
}

/// Texture usage flags.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct TextureUsage(u32);

impl TextureUsage {
    /// Texture can be read in shaders.
    pub const SHADER_READ: Self = Self(1);
    /// Texture can be written in shaders.
    pub const SHADER_WRITE: Self = Self(2);
    /// Texture can be used as a copy source.
    pub const COPY_SRC: Self = Self(4);
    /// Texture can be used as a copy destination.
    pub const COPY_DST: Self = Self(8);
}

/// Texture address mode for out-of-bounds access.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TextureAddressMode {
    /// Clamp to edge values.
    ClampToEdge,
    /// Wrap around.
    Repeat,
    /// Mirror and wrap.
    MirrorRepeat,
}

/// Texture filter mode.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TextureFilterMode {
    /// Nearest neighbor (no interpolation).
    Nearest,
    /// Linear interpolation.
    Linear,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_get_activation_table() {
        // Forward activations use table_id:: (re-exported from hologram_lookup)
        assert!(get_activation_table(table_id::SIGMOID).is_some());
        assert!(get_activation_table(table_id::TANH).is_some());
        assert!(get_activation_table(table_id::RELU).is_some());
        assert!(get_activation_table(table_id::GELU).is_some());
        assert!(get_activation_table(table_id::SILU).is_some());
        assert!(get_activation_table(999).is_none());
    }

    #[test]
    fn test_get_inverse_activation_table() {
        assert!(get_activation_table(table_id::SIGMOID_INVERSE).is_some());
        assert!(get_activation_table(table_id::TANH_INVERSE).is_some());
        assert!(get_activation_table(table_id::RELU_INVERSE).is_some());
    }

    #[test]
    fn test_activation_tables_constant() {
        assert_eq!(ACTIVATION_TABLES.len(), 5);
        for (id, table) in &ACTIVATION_TABLES {
            assert_eq!(table.len(), 256);
            assert!(get_activation_table(*id).is_some());
        }
    }

    #[test]
    fn test_inverse_activation_tables_constant() {
        assert_eq!(INVERSE_ACTIVATION_TABLES.len(), 3);
        for (id, table) in &INVERSE_ACTIVATION_TABLES {
            assert_eq!(table.len(), 256);
            assert!(get_activation_table(*id).is_some());
        }
    }

    #[test]
    fn test_all_activation_tables_constant() {
        assert_eq!(ALL_ACTIVATION_TABLES.len(), 8);
    }

    #[test]
    fn test_inverse_table_id_mapping() {
        assert_eq!(
            get_inverse_table_id(table_id::SIGMOID),
            Some(table_id::SIGMOID_INVERSE)
        );
        assert_eq!(
            get_inverse_table_id(table_id::TANH),
            Some(table_id::TANH_INVERSE)
        );
        assert_eq!(
            get_inverse_table_id(table_id::RELU),
            Some(table_id::RELU_INVERSE)
        );
        assert_eq!(get_inverse_table_id(table_id::GELU), None); // No inverse
    }

    #[test]
    fn test_forward_table_id_mapping() {
        assert_eq!(
            get_forward_table_id(table_id::SIGMOID_INVERSE),
            Some(table_id::SIGMOID)
        );
        assert_eq!(
            get_forward_table_id(table_id::TANH_INVERSE),
            Some(table_id::TANH)
        );
        assert_eq!(
            get_forward_table_id(table_id::RELU_INVERSE),
            Some(table_id::RELU)
        );
        assert_eq!(get_forward_table_id(999), None);
    }

    #[test]
    fn test_table_id_by_name() {
        // Forward activations
        assert_eq!(get_table_id_by_name("sigmoid"), Some(table_id::SIGMOID));
        assert_eq!(get_table_id_by_name("tanh"), Some(table_id::TANH));
        assert_eq!(get_table_id_by_name("relu"), Some(table_id::RELU));
        assert_eq!(get_table_id_by_name("gelu"), Some(table_id::GELU));
        assert_eq!(get_table_id_by_name("silu"), Some(table_id::SILU));
        assert_eq!(get_table_id_by_name("swish"), Some(table_id::SILU)); // Alias

        // Inverse activations
        assert_eq!(
            get_table_id_by_name("inverse_sigmoid"),
            Some(table_id::SIGMOID_INVERSE)
        );
        assert_eq!(
            get_table_id_by_name("logit"),
            Some(table_id::SIGMOID_INVERSE)
        ); // Alias
        assert_eq!(
            get_table_id_by_name("inverse_tanh"),
            Some(table_id::TANH_INVERSE)
        );
        assert_eq!(get_table_id_by_name("atanh"), Some(table_id::TANH_INVERSE)); // Alias
        assert_eq!(
            get_table_id_by_name("inverse_relu"),
            Some(table_id::RELU_INVERSE)
        );

        // Unknown
        assert_eq!(get_table_id_by_name("unknown"), None);
    }

    #[test]
    fn test_table_name_by_id() {
        assert_eq!(get_table_name_by_id(table_id::SIGMOID), Some("sigmoid"));
        assert_eq!(get_table_name_by_id(table_id::TANH), Some("tanh"));
        assert_eq!(get_table_name_by_id(table_id::RELU), Some("relu"));
        assert_eq!(get_table_name_by_id(table_id::GELU), Some("gelu"));
        assert_eq!(get_table_name_by_id(table_id::SILU), Some("silu"));
        assert_eq!(
            get_table_name_by_id(table_id::SIGMOID_INVERSE),
            Some("inverse_sigmoid")
        );
        assert_eq!(get_table_name_by_id(999), None);
    }

    #[test]
    fn test_texture_stats() {
        let mut stats = TextureStats::default();

        stats.record_lookup();
        assert_eq!(stats.lookups, 1);

        stats.record_cache_hit();
        stats.record_cache_miss();
        assert_eq!(stats.cache_hit_rate(), 0.5);

        stats.record_texture_created(256);
        assert_eq!(stats.textures_created, 1);
        assert_eq!(stats.texture_memory_bytes, 256);
    }

    #[test]
    fn test_texture_cache() {
        let mut cache: TextureCache<u32> = TextureCache::new();

        assert!(cache.is_empty());
        assert!(!cache.contains(0));

        cache.insert(0, 42);
        assert!(!cache.is_empty());
        assert!(cache.contains(0));
        assert_eq!(cache.get(0), Some(&42u32));
        assert_eq!(cache.len(), 1);

        // Test get_or_create
        let result = cache.get_or_create(1, |_| Some(100));
        assert_eq!(result, Some(&100));
        assert_eq!(cache.len(), 2);

        // Already exists, shouldn't call factory
        let result = cache.get_or_create(1, |_| Some(999));
        assert_eq!(result, Some(&100)); // Original value

        cache.clear();
        assert!(cache.is_empty());
    }

    #[test]
    fn test_texture_descriptor() {
        let desc = TextureDescriptor::activation_table();
        assert_eq!(desc.width, 256);
        assert_eq!(desc.format, TextureFormat::R8Unorm);
        assert_eq!(desc.filter_mode, TextureFilterMode::Nearest);
    }
}
