/**
 * SovereignInferencePanel — Privacy-Preserving AI Chat Interface
 *
 * The AI sees ONLY boundary attestations constructed from the sovereignty surface.
 * Raw user data never leaves the client — the attestation engine replaces it
 * with cryptographic proofs and dimension-level claims.
 *
 * Conversations persist locally with attestation snapshots.
 */

import { useState, useCallback, useRef, useEffect, useMemo } from "react";
import {
  Send, Shield, ShieldOff, ShieldAlert,
  Lock, Loader2, AlertTriangle, Cpu, ShieldCheck,
} from "lucide-react";
import type { SovereigntySurface } from "../types";
import type { BoundaryAttestation, DimensionClaim } from "../engine/attestation-engine";
import { buildSanitizedContext } from "../engine/attestation-engine";
import { disclosureRatio } from "../engine/sovereignty-engine";
import { detectViolations, redactViolations, getShieldedDimensions, type ViolationReport } from "../engine/boundary-violation-detector";
import { useSovereignConversations } from "../hooks/useSovereignConversations";
import type { ChatMessage } from "../hooks/useSovereignConversations";
import ConversationSidebar from "./ConversationSidebar";
import ViolationAlert from "./ViolationAlert";
import GlossaryTooltip from "./GlossaryTooltip";

interface Props {
  readonly surface: SovereigntySurface;
}

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

const DIM_ICON: Record<string, typeof Shield> = {
  shielded: Shield,
  partial: ShieldAlert,
  disclosed: ShieldOff,
};

const DIM_STYLE: Record<string, string> = {
  shielded: "text-primary bg-primary/10",
  partial: "text-accent-foreground bg-accent/10",
  disclosed: "text-muted-foreground bg-muted",
};

function DimensionBadge({ claim }: { claim: DimensionClaim }) {
  const Icon = DIM_ICON[claim.state] ?? Shield;
  const stateLabel = claim.state === "shielded" ? "Private" : claim.state === "partial" ? "Limited" : "Shared";
  return (
    <span
      className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-mono ${DIM_STYLE[claim.state]}`}
      title={`${claim.dimension}: ${claim.openEdges} of ${claim.edgeCount} data points shared`}
    >
      <Icon className="h-2.5 w-2.5" />
      {claim.dimension.slice(0, 4)}
    </span>
  );
}

function AttestationHeader({ attestation }: { attestation: BoundaryAttestation | null }) {
  if (!attestation) return null;
  return (
    <div className="border-b border-border px-4 py-2 space-y-1.5">
      <div className="flex items-center justify-between">
        <span className="text-[9px] font-mono text-muted-foreground">
          Session: {attestation.commitmentHash.slice(0, 12)}…
        </span>
        <span className="text-[9px] font-mono text-muted-foreground">
          {attestation.proofSummary.disclosurePercent}% shared with AI
        </span>
      </div>
      <div className="flex items-center gap-1 flex-wrap">
        {attestation.dimensions.map((claim) => (
          <DimensionBadge key={claim.dimension} claim={claim} />
        ))}
        <span className="text-[8px] text-muted-foreground ml-auto">
          Protection: {((1 - attestation.sovereignty.phi_v5) * 100).toFixed(0)}%
        </span>
      </div>
    </div>
  );
}

export default function SovereignInferencePanel({ surface }: Props) {
  const {
    conversations,
    activeConversation,
    activeId,
    setActiveId,
    createConversation,
    updateConversation,
    deleteConversation,
  } = useSovereignConversations();

  const messages = activeConversation?.messages ?? [];
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [attestation, setAttestation] = useState<BoundaryAttestation | null>(
    activeConversation?.attestation ?? null,
  );
  const [violationReports, setViolationReports] = useState<Record<string, ViolationReport>>({});
  const [autoRedact, setAutoRedact] = useState(true);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const disclosure = useMemo(() => disclosureRatio(surface), [surface]);

  // Sync attestation when switching conversations
  useEffect(() => {
    setAttestation(activeConversation?.attestation ?? null);
  }, [activeId, activeConversation?.attestation]);

  // Auto-scroll
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Update attestation when surface changes
  useEffect(() => {
    buildSanitizedContext(surface, "").then((ctx) => {
      setAttestation(ctx.attestation);
    });
  }, [surface]);

  const persistMessages = useCallback(
    (newMessages: ChatMessage[], newAttestation: BoundaryAttestation | null) => {
      if (!activeId) return;
      updateConversation(activeId, newMessages, newAttestation);
    },
    [activeId, updateConversation],
  );

  const handleNewConversation = useCallback(() => {
    createConversation();
    setError(null);
  }, [createConversation]);

  const sendMessage = useCallback(async () => {
    const text = input.trim();
    if (!text || isStreaming) return;

    // Auto-create conversation if none active
    let convId = activeId;
    if (!convId) {
      convId = createConversation();
    }

    setInput("");
    setError(null);

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: text,
      timestamp: Date.now(),
    };
    const updatedMessages = [...messages, userMsg];
    updateConversation(convId, updatedMessages, attestation);
    setIsStreaming(true);

    try {
      const sanitized = await buildSanitizedContext(surface, text);
      setAttestation(sanitized.attestation);

      const allMessages = updatedMessages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const resp = await fetch(`${SUPABASE_URL}/functions/v1/sovereign-inference`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${SUPABASE_KEY}`,
        },
        body: JSON.stringify({
          systemPrompt: sanitized.systemPrompt,
          messages: allMessages,
          attestation: sanitized.attestation,
        }),
      });

      if (!resp.ok) {
        const errData = await resp.json().catch(() => ({ error: `HTTP ${resp.status}` }));
        throw new Error(errData.error || `HTTP ${resp.status}`);
      }

      if (!resp.body) throw new Error("No response body");

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let assistantContent = "";
      const assistantId = `assistant-${Date.now()}`;

      const shieldedDims = getShieldedDimensions(sanitized.attestation);

      const flushToken = (content: string) => {
        assistantContent += content;

        // Real-time violation scanning during streaming
        let displayContent = assistantContent;
        if (shieldedDims.length > 0) {
          const report = detectViolations(assistantContent, assistantId, shieldedDims);
          if (!report.isClean) {
            setViolationReports((prev) => ({ ...prev, [assistantId]: report }));
            if (autoRedact) {
              displayContent = redactViolations(assistantContent, report);
            }
          }
        }

        const finalMessages: ChatMessage[] = [
          ...updatedMessages,
          { id: assistantId, role: "assistant", content: displayContent, timestamp: Date.now() },
        ];
        updateConversation(convId!, finalMessages, sanitized.attestation);
      };

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let newlineIdx: number;
        while ((newlineIdx = buffer.indexOf("\n")) !== -1) {
          let line = buffer.slice(0, newlineIdx);
          buffer = buffer.slice(newlineIdx + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") break;
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (content) flushToken(content);
          } catch {
            buffer = line + "\n" + buffer;
            break;
          }
        }
      }

      // Final buffer flush
      if (buffer.trim()) {
        for (let raw of buffer.split("\n")) {
          if (!raw) continue;
          if (raw.endsWith("\r")) raw = raw.slice(0, -1);
          if (!raw.startsWith("data: ")) continue;
          const jsonStr = raw.slice(6).trim();
          if (jsonStr === "[DONE]") continue;
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (content) flushToken(content);
          } catch { /* ignore */ }
        }
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unknown error");
    } finally {
      setIsStreaming(false);
    }
  }, [input, isStreaming, messages, surface, activeId, createConversation, updateConversation, attestation, autoRedact]);

  return (
    <div className="rounded-lg border border-border bg-card animate-fade-in flex" style={{ height: "480px" }}>
      {/* Conversation sidebar */}
      <ConversationSidebar
        conversations={conversations}
        activeId={activeId}
        onSelect={setActiveId}
        onCreate={handleNewConversation}
        onDelete={deleteConversation}
      />

      {/* Chat area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
            <Cpu className="h-3.5 w-3.5" />
            Private AI Chat
          </h3>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setAutoRedact((v) => !v)}
              className={`flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-semibold transition-colors ${
                autoRedact
                  ? "bg-primary/10 text-primary"
                  : "bg-muted text-muted-foreground"
              }`}
              title={autoRedact ? "Auto-redact is on — flagged content is censored" : "Auto-redact is off — violations show alerts only"}
            >
              <ShieldCheck className="h-3 w-3" />
              {autoRedact ? "Auto-redact on" : "Auto-redact off"}
            </button>
            <Lock className="h-3 w-3 text-primary" />
          </div>
        </div>

        {/* Attestation bar */}
        <AttestationHeader attestation={attestation} />

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center space-y-3">
              <Shield className="h-8 w-8 text-primary/30" />
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">
                  Your data stays on your device
                </p>
                <p className="text-[10px] text-muted-foreground/60">
                  The AI only sees privacy summaries — never your actual data.
                  {disclosure === 0 && " Everything is currently private."}
                </p>
              </div>
            </div>
          )}

          {messages.map((msg) => (
            <div key={msg.id}>
              <div
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] rounded-lg px-3 py-2 text-sm ${
                    msg.role === "user"
                      ? "bg-primary/10 text-foreground"
                      : "bg-muted text-foreground"
                  }`}
                >
                  <p className="whitespace-pre-wrap break-words">{msg.content}</p>
                  <span className="text-[8px] text-muted-foreground mt-1 block">
                    {new Date(msg.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              </div>
              {msg.role === "assistant" && violationReports[msg.id] && (
                <div className="flex justify-start mt-1">
                  <div className="max-w-[85%]">
                    <ViolationAlert report={violationReports[msg.id]} />
                  </div>
                </div>
              )}
            </div>
          ))}

          {isStreaming && messages[messages.length - 1]?.role !== "assistant" && (
            <div className="flex justify-start">
              <div className="rounded-lg bg-muted px-3 py-2">
                <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />
              </div>
            </div>
          )}

          {error && (
            <div className="flex items-start gap-2 rounded-md border border-destructive/20 bg-destructive/5 p-2">
              <AlertTriangle className="h-3.5 w-3.5 text-destructive mt-0.5 shrink-0" />
              <p className="text-[10px] text-destructive">{error}</p>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Input */}
        <div className="border-t border-border px-4 py-3">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
              placeholder={
                disclosure === 0
                  ? "Everything is private — AI has minimal context"
                  : "Ask a question…"
              }
              className="flex-1 bg-muted rounded-md px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 outline-none focus:ring-1 focus:ring-primary/30"
              disabled={isStreaming}
            />
            <button
              onClick={sendMessage}
              disabled={isStreaming || !input.trim()}
              className="p-2 rounded-md bg-primary/10 text-primary hover:bg-primary/20 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
            >
              {isStreaming ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </button>
          </div>
          <div className="flex items-center gap-2 mt-1.5">
            <span className="text-[8px] text-muted-foreground">
              {attestation
                ? <>{attestation.proofSummary.revealedCount} data points shared · {attestation.sovereignty.compressionRatio.toFixed(0)}× <GlossaryTooltip term="Privacy compression">privacy compression</GlossaryTooltip> · NIST Level {attestation.nistLevel} <GlossaryTooltip term="Quantum-safe">quantum-safe</GlossaryTooltip> encryption</>
                : "Preparing privacy summary…"}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
