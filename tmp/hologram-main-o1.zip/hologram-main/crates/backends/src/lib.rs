//! Execution backends for hologram ISA.
//!
//! This crate provides backend implementations for executing compiled
//! hologram plans (`.holb`/`.holo` files). Backends implement the `Backend`
//! trait and execute `BackendPlan` instances loaded from archive files.
//!
//! # Backend Types
//!
//! - **CPU**: x86_64 (AMD Zen 3), aarch64 (ARM NEON)
//! - **WASM**: WebAssembly runtime (fully implemented)
//! - **CUDA**: NVIDIA GPU compute (skeleton)
//! - **Metal**: Apple GPU compute (skeleton)
//! - **WebGPU**: Cross-platform GPU via browser/native (skeleton)
//!
//! # Example
//!
//! ```rust,no_run
//! # use hologram_backend::*;
//! # use hologram_holo::{HoloLoader, PlanMetadata, ObservableMetadata, LutSection};
//! # fn example() -> Result<()> {
//! // Create a CPU backend
//! let backend = cpu::CpuBackend::new();
//!
//! // Create a simple plan
//! let plan = BackendPlan {
//!     instructions: vec![],
//!     buffers: vec![],
//!     constants: vec![],
//!     workspace_size: 0,
//!     dependencies: vec![],
//!     metadata: PlanMetadata::default(),
//!     node_buffer_map: vec![],
//!     observable_metadata: ObservableMetadata::default(),
//!     lut_section: LutSection::new(),
//! };
//!
//! // Execute the plan
//! let input = vec![0u8; 1024];
//! let mut output = vec![0u8; 1024];
//! backend.execute_plan(
//!     &plan,
//!     &[&input],
//!     &mut [&mut output],
//! )?;
//! # Ok(())
//! # }
//! ```

#![deny(missing_docs)]
#![deny(clippy::all)]
#![warn(clippy::pedantic)]
#![allow(clippy::module_name_repetitions)]
#![allow(clippy::missing_errors_doc)]
#![allow(clippy::missing_panics_doc)]
#![allow(clippy::doc_markdown)]
#![allow(clippy::unused_self)]
#![allow(clippy::too_many_arguments)]
#![allow(clippy::unnecessary_wraps)]

use std::sync::OnceLock;

pub mod backends;
pub mod codec;
pub mod layer;
pub mod microcode;
pub mod target;
pub mod types;

// Re-exports
pub use backends::cuda::CudaBackend;
pub use backends::gpu::{GpuBackend, GpuBuffer, GpuDevice, KernelConfig};
pub use backends::kernel::{
    classify_instruction, grid_size, recommended_block_size, CategoricalKernels, CategoricalParams,
    ElementWiseKernels, ElementWiseParams, GpuKernels, KernelCategory, KernelOverride,
    MatMulParams, MatrixKernels, MemoryKernels, MemoryParams, ReductionKernels, ReductionParams,
};
pub use backends::kernels::{
    ElementWiseTemplate, KernelLanguage, MatMulTemplate, ReductionTemplate,
};
pub use backends::metal::MetalBackend;
pub use backends::wasm::{WasmBackend, WasmMemory, WASM_DEFAULT_MAX_MEMORY, WASM_PAGE_SIZE};
pub use backends::webgpu::{WebGpuBackend, WebGpuLimits};
pub use backends::{cpu, cuda, gpu, kernel, kernels, metal, wasm, webgpu, Backend};
pub use layer::{FileSystemLoader, LayerCache, LayerLoader};
pub use target::{
    auto_select_target, backend_registry, cached_target, BackendCategory, BackendInfo,
    BackendRegistry, BackendTarget, NativeOverride, ScalarTarget, SelectedTarget, Simd128Target,
    Simd256Target, TargetCapabilities,
};
pub use types::{BackendCapabilities, BackendError, BackendType, BufferRef, Result};

// Re-export from hologram-holo for convenience
pub use hologram_holo::{BackendPlan, HoloLoader, IsaInstruction};

// System BLAS override (feature-gated)
#[cfg(any(feature = "accelerate", feature = "openblas"))]
pub use backends::cpu::blas;

// ============================================================================
// Kernel Override Registration
// ============================================================================

/// Global kernel override provider.
///
/// This is set once at application startup via [`register_kernel_override`].
/// Accessing it after initialization is essentially free (single atomic load).
static KERNEL_OVERRIDE: OnceLock<Box<dyn KernelOverride>> = OnceLock::new();

/// Register a kernel override provider for optimized kernel implementations.
///
/// This function uses a singleton pattern: it can only be called once per process,
/// and subsequent calls return an error. The registered provider is stored in a
/// `OnceLock` and remains available for the lifetime of the process.
///
/// # When to Call
///
/// Call this function **once** at application startup, **before**:
/// - Spawning worker threads that execute plans
/// - Calling any `Backend::execute_plan()` methods
/// - Any other code that might invoke kernel dispatch
///
/// The typical pattern is to call this in your `main()` or initialization function:
///
/// ```ignore
/// fn main() -> Result<()> {
///     // 1. Register kernel overrides FIRST
///     hologram_ai::init()?;  // Calls register_kernel_override internally
///
///     // 2. Then create backends and execute plans
///     let backend = CpuBackend::new();
///     backend.execute_plan(&plan, &inputs, &mut outputs)?;
///     Ok(())
/// }
/// ```
///
/// # Thread Safety
///
/// The registration itself is thread-safe (protected by `OnceLock`), but you should
/// register before spawning worker threads to ensure all threads see the override.
/// Once registered, the override is immutably borrowed for `'static` lifetime.
///
/// # Example
///
/// ```ignore
/// use hologram_backend::{register_kernel_override, KernelOverride, Result};
///
/// struct CublasKernels {
///     handle: cublas::Handle,
/// }
///
/// impl KernelOverride for CublasKernels {
///     fn matmul(&self, a: &[f32], b: &[f32], c: &mut [f32],
///               m: usize, k: usize, n: usize) -> Option<Result<()>> {
///         Some(self.handle.sgemm(a, b, c, m, k, n))
///     }
/// }
///
/// fn init() -> std::result::Result<(), &'static str> {
///     let kernels = Box::new(CublasKernels::new());
///     register_kernel_override(kernels)
/// }
/// ```
///
/// # Errors
///
/// Returns `Err("kernel override already registered")` if called more than once.
pub fn register_kernel_override(
    provider: Box<dyn KernelOverride>,
) -> std::result::Result<(), &'static str> {
    KERNEL_OVERRIDE
        .set(provider)
        .map_err(|_| "kernel override already registered")
}

/// Get the registered kernel override, if any.
///
/// Returns `None` if no override has been registered via [`register_kernel_override`].
///
/// # Usage in Dispatch Layer
///
/// This function is called by the kernel dispatch layer to check for overrides
/// before falling back to hologram's default implementations:
///
/// ```ignore
/// fn dispatch_matmul(a: &[f32], b: &[f32], c: &mut [f32], m: usize, k: usize, n: usize) -> Result<()> {
///     // Check for override first
///     if let Some(provider) = kernel_override() {
///         if let Some(result) = provider.matmul(a, b, c, m, k, n) {
///             return result;  // Override handled it
///         }
///     }
///     // No override or override returned None - use default
///     default_matmul(a, b, c, m, k, n)
/// }
/// ```
///
/// # Why Static Reference?
///
/// Returns `&'static dyn KernelOverride` because:
/// - The `OnceLock` lives for the entire process
/// - Avoids allocation on each call
/// - Allows the override to be used safely across threads
///
/// # Performance
///
/// - First call: single atomic load to check if initialized
/// - Subsequent calls: same (no caching needed, atomic loads are cheap)
/// - Total overhead: ~1-2 nanoseconds per call (negligible vs kernel execution)
#[must_use]
pub fn kernel_override() -> Option<&'static dyn KernelOverride> {
    KERNEL_OVERRIDE.get().map(Box::as_ref)
}
