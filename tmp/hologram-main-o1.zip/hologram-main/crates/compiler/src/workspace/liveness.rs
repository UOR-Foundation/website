//! Liveness analysis for buffer allocation.
//!
//! Computes when each buffer is "live" (in use) during execution,
//! enabling buffer reuse for non-overlapping lifetimes.

use crate::graph::CompileGraph;
use std::collections::HashMap;

/// Liveness interval for a buffer.
///
/// Represents the range of topological indices during which
/// a buffer must be kept in memory.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct LivenessInterval {
    /// First use (topological index).
    pub start: usize,
    /// Last use (topological index).
    pub end: usize,
}

impl LivenessInterval {
    /// Create a new liveness interval.
    #[must_use]
    pub const fn new(start: usize, end: usize) -> Self {
        Self { start, end }
    }

    /// Check if two intervals overlap.
    ///
    /// Two intervals overlap if either starts before or when the other ends.
    #[must_use]
    pub const fn overlaps(&self, other: &Self) -> bool {
        self.start <= other.end && other.start <= self.end
    }

    /// Get the length of the interval.
    #[must_use]
    pub const fn len(&self) -> usize {
        self.end - self.start + 1
    }

    /// Check if the interval is empty (should never happen for valid buffers).
    #[must_use]
    pub const fn is_empty(&self) -> bool {
        self.end < self.start
    }
}

/// Buffer information for workspace planning.
#[derive(Debug, Clone)]
pub struct BufferInfo {
    /// Original node ID.
    pub node_id: u32,
    /// Required size in bytes.
    pub size: usize,
    /// Required alignment in bytes.
    pub alignment: usize,
    /// Liveness interval.
    pub interval: LivenessInterval,
}

/// Compute liveness intervals for all intermediate buffers.
///
/// Returns a map from node ID to buffer info. Only includes nodes
/// that need workspace allocation (excludes I/O and constants).
#[must_use]
pub fn compute_liveness(graph: &CompileGraph) -> HashMap<u32, BufferInfo> {
    let topo_order = graph.topo_order();
    let topo_index: HashMap<u32, usize> = topo_order
        .iter()
        .enumerate()
        .map(|(idx, &id)| (id, idx))
        .collect();

    let mut buffers = HashMap::new();

    for (id, node) in graph.nodes() {
        // Skip I/O and constant nodes - they don't need workspace
        if is_io_node(&node.op) {
            continue;
        }

        // Get the topological index for this node
        let Some(&def_index) = topo_index.get(&id) else {
            continue;
        };

        // Find last use: the maximum topo index among all successors
        let successors = graph.successors(id);
        let last_use = successors
            .iter()
            .filter_map(|&succ| topo_index.get(&succ))
            .max()
            .copied()
            .unwrap_or(def_index);

        // Compute buffer size from shape and dtype
        let element_size = dtype_size(node.dtype);
        let element_count: usize = node.shape.iter().product();
        let size = element_count * element_size;

        // Get alignment from layout if assigned, otherwise use default
        let alignment = if node.layout.is_some() { 32 } else { 8 };

        buffers.insert(
            id,
            BufferInfo {
                node_id: id,
                size,
                alignment,
                interval: LivenessInterval::new(def_index, last_use),
            },
        );
    }

    buffers
}

/// Check if an operation is I/O (doesn't need workspace).
fn is_io_node(op: &crate::graph::OpKind) -> bool {
    matches!(
        op,
        crate::graph::OpKind::Input | crate::graph::OpKind::Output | crate::graph::OpKind::Constant
    )
}

/// Get the size of a dtype in bytes.
fn dtype_size(dtype: crate::graph::DType) -> usize {
    use crate::graph::DType;
    match dtype {
        DType::F32 | DType::I32 | DType::U32 => 4,
        DType::F64 | DType::I64 | DType::U64 => 8,
        DType::I8 | DType::U8 | DType::Bool => 1,
        DType::I16 | DType::U16 => 2,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpKind, OpNode, OperationGraph};

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    #[test]
    fn test_interval_overlaps() {
        let a = LivenessInterval::new(0, 5);
        let b = LivenessInterval::new(3, 8);
        let c = LivenessInterval::new(6, 10);

        assert!(a.overlaps(&b));
        assert!(!a.overlaps(&c));
        assert!(b.overlaps(&c));
    }

    #[test]
    fn test_interval_adjacent() {
        let a = LivenessInterval::new(0, 5);
        let b = LivenessInterval::new(5, 10);

        // Adjacent intervals do overlap at the boundary
        assert!(a.overlaps(&b));
    }

    #[test]
    fn test_interval_len() {
        let interval = LivenessInterval::new(2, 5);
        assert_eq!(interval.len(), 4);
    }

    #[test]
    fn test_compute_liveness_empty_graph() {
        let graph = make_graph(vec![], vec![]);
        let liveness = compute_liveness(&graph);
        assert!(liveness.is_empty());
    }

    #[test]
    fn test_compute_liveness_io_excluded() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1)],
        );

        let liveness = compute_liveness(&graph);
        // I/O nodes should not be in the liveness map
        assert!(liveness.is_empty());
    }

    #[test]
    fn test_compute_liveness_simple_chain() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64, 64], DType::F32),
                OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3)],
        );

        let liveness = compute_liveness(&graph);

        // Relu (node 1) should have interval [1, 2] (used by Sigmoid)
        let relu_info = liveness.get(&1).unwrap();
        assert_eq!(relu_info.interval.start, 1);
        assert_eq!(relu_info.interval.end, 2);

        // Sigmoid (node 2) should have interval [2, 3] (used by Output)
        let sigmoid_info = liveness.get(&2).unwrap();
        assert_eq!(sigmoid_info.interval.start, 2);
        assert_eq!(sigmoid_info.interval.end, 3);
    }

    #[test]
    fn test_compute_liveness_diamond_pattern() {
        // Input -> [Relu, Sigmoid] -> Add -> Output
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64, 64], DType::F32),
                OpNode::new(3, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(4, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (0, 2), (1, 3), (2, 3), (3, 4)],
        );

        let liveness = compute_liveness(&graph);

        // Both Relu and Sigmoid are used by Add
        // Their intervals should overlap
        let relu_info = liveness.get(&1).unwrap();
        let sigmoid_info = liveness.get(&2).unwrap();

        assert!(relu_info.interval.overlaps(&sigmoid_info.interval));
    }

    #[test]
    fn test_compute_liveness_buffer_size() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let liveness = compute_liveness(&graph);

        let relu_info = liveness.get(&1).unwrap();
        // 64 * 64 * 4 bytes = 16384 bytes
        assert_eq!(relu_info.size, 16384);
    }

    #[test]
    fn test_compute_liveness_different_dtypes() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![100], DType::F64),
                OpNode::new(1, OpKind::Relu, vec![100], DType::F64),
                OpNode::new(2, OpKind::Output, vec![100], DType::F64),
            ],
            vec![(0, 1), (1, 2)],
        );

        let liveness = compute_liveness(&graph);

        let relu_info = liveness.get(&1).unwrap();
        // 100 * 8 bytes = 800 bytes
        assert_eq!(relu_info.size, 800);
    }

    #[test]
    fn test_non_overlapping_sequential_ops() {
        // Input -> Relu -> Sigmoid -> Tanh -> Output
        // Each intermediate buffer has a sequential, non-overlapping lifetime
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64], DType::F32),
                OpNode::new(3, OpKind::Tanh, vec![64], DType::F32),
                OpNode::new(4, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3), (3, 4)],
        );

        let liveness = compute_liveness(&graph);

        // Relu [1, 2] and Tanh [3, 4] should NOT overlap
        let relu_info = liveness.get(&1).unwrap();
        let tanh_info = liveness.get(&3).unwrap();
        assert!(!relu_info.interval.overlaps(&tanh_info.interval));
    }
}
