//! Content-addressed caching for compiled plans.
//!
//! This module provides content-addressed caching for `BackendPlan`s,
//! allowing reuse of compiled plans when the same `OperationGraph` is
//! compiled multiple times.
//!
//! # Statistics Tracking
//!
//! All cache implementations track hit/miss statistics for monitoring:
//!
//! ```
//! use hologram_compiler::cache::{MemoryCache, CompileCache};
//!
//! let cache = MemoryCache::new();
//! println!("Hit rate: {:?}", cache.stats().hit_rate());
//! ```

use std::collections::HashMap;
use std::fmt;
use std::hash::{Hash, Hasher};
use std::sync::atomic::{AtomicU64, Ordering};

use hologram_holo::BackendPlan;

use crate::graph::{DType, OpKind, OperationGraph};

/// Cache statistics for monitoring and debugging.
#[derive(Debug, Default)]
pub struct CacheStats {
    hits: AtomicU64,
    misses: AtomicU64,
}

impl CacheStats {
    /// Number of cache hits.
    #[must_use]
    pub fn hits(&self) -> u64 {
        self.hits.load(Ordering::Relaxed)
    }

    /// Number of cache misses.
    #[must_use]
    pub fn misses(&self) -> u64 {
        self.misses.load(Ordering::Relaxed)
    }

    /// Total number of requests (hits + misses).
    #[must_use]
    pub fn total_requests(&self) -> u64 {
        self.hits() + self.misses()
    }

    /// Cache hit rate (0.0 to 1.0).
    ///
    /// Returns `None` if no requests have been made.
    #[must_use]
    #[allow(clippy::cast_precision_loss)] // Precision loss acceptable for statistics
    pub fn hit_rate(&self) -> Option<f64> {
        let total = self.total_requests();
        if total == 0 {
            None
        } else {
            Some(self.hits() as f64 / total as f64)
        }
    }

    /// Cache miss rate (0.0 to 1.0).
    ///
    /// Returns `None` if no requests have been made.
    #[must_use]
    pub fn miss_rate(&self) -> Option<f64> {
        self.hit_rate().map(|hr| 1.0 - hr)
    }

    /// Reset all statistics to zero.
    pub fn reset(&self) {
        self.hits.store(0, Ordering::Relaxed);
        self.misses.store(0, Ordering::Relaxed);
    }

    fn record_hit(&self) {
        self.hits.fetch_add(1, Ordering::Relaxed);
    }

    fn record_miss(&self) {
        self.misses.fetch_add(1, Ordering::Relaxed);
    }
}

/// Content-based identifier for an `OperationGraph`.
///
/// The `LayerId` is computed from the structural content of the graph,
/// including node operations, shapes, dtypes, and edge connectivity.
/// Two graphs with identical structure will have identical `LayerId`s.
#[derive(Clone, Copy, PartialEq, Eq, Hash)]
pub struct LayerId([u8; 32]);

impl LayerId {
    /// Compute the `LayerId` for an `OperationGraph`.
    ///
    /// The hash is computed from:
    /// - Number of nodes
    /// - For each node (in ID order): op kind, shape, dtype
    /// - All edges (sorted)
    /// - Named inputs and outputs
    #[must_use]
    pub fn from_graph(graph: &OperationGraph) -> Self {
        use std::collections::hash_map::DefaultHasher;

        let mut hasher = DefaultHasher::new();

        // Hash node count
        graph.node_count().hash(&mut hasher);

        // Hash nodes in ID order
        let mut nodes: Vec<_> = graph.nodes.iter().collect();
        nodes.sort_by_key(|n| n.id);

        for node in &nodes {
            node.id.hash(&mut hasher);
            hash_op_kind(&node.op, &mut hasher);
            node.shape.hash(&mut hasher);
            hash_dtype(node.dtype, &mut hasher);
        }

        // Hash edges (sorted for determinism)
        let mut edges = graph.edges.clone();
        edges.sort_unstable();
        for (src, dst) in &edges {
            src.hash(&mut hasher);
            dst.hash(&mut hasher);
        }

        // Hash named inputs
        let mut inputs: Vec<_> = graph.inputs.iter().collect();
        inputs.sort_by_key(|(name, _)| name.as_str());
        for (name, id) in &inputs {
            name.hash(&mut hasher);
            id.hash(&mut hasher);
        }

        // Hash named outputs
        let mut outputs: Vec<_> = graph.outputs.iter().collect();
        outputs.sort_by_key(|(name, _)| name.as_str());
        for (name, id) in &outputs {
            name.hash(&mut hasher);
            id.hash(&mut hasher);
        }

        // Convert to 32-byte array (padding with zeros)
        let hash = hasher.finish();
        let mut bytes = [0u8; 32];
        bytes[..8].copy_from_slice(&hash.to_le_bytes());
        // Use hash again with different seed for more entropy
        hash.wrapping_mul(0x517c_c1b7_2722_0a95).hash(&mut hasher);
        let hash2 = hasher.finish();
        bytes[8..16].copy_from_slice(&hash2.to_le_bytes());
        hash2.wrapping_mul(0x517c_c1b7_2722_0a95).hash(&mut hasher);
        let hash3 = hasher.finish();
        bytes[16..24].copy_from_slice(&hash3.to_le_bytes());
        hash3.wrapping_mul(0x517c_c1b7_2722_0a95).hash(&mut hasher);
        let hash4 = hasher.finish();
        bytes[24..32].copy_from_slice(&hash4.to_le_bytes());

        Self(bytes)
    }

    /// Get the raw bytes of the `LayerId`.
    #[must_use]
    pub const fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }

    /// Create a `LayerId` from raw bytes.
    #[must_use]
    pub const fn from_bytes(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }
}

impl fmt::Debug for LayerId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "LayerId({:016x}...)",
            u64::from_le_bytes(self.0[..8].try_into().unwrap())
        )
    }
}

impl fmt::Display for LayerId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in &self.0 {
            write!(f, "{byte:02x}")?;
        }
        Ok(())
    }
}

/// Hash an `OpKind` variant.
fn hash_op_kind<H: Hasher>(op: &OpKind, hasher: &mut H) {
    std::mem::discriminant(op).hash(hasher);
    if let OpKind::MatMul { m, k, n } = op {
        m.hash(hasher);
        k.hash(hasher);
        n.hash(hasher);
    }
    if let OpKind::CallLayer { layer_id } = op {
        layer_id.hash(hasher);
    }
}

/// Hash a `DType` variant.
fn hash_dtype<H: Hasher>(dtype: DType, hasher: &mut H) {
    std::mem::discriminant(&dtype).hash(hasher);
}

/// Trait for caching compiled plans.
///
/// Implementations can store plans in memory, on disk, or in a distributed cache.
/// All implementations track hit/miss statistics via `stats()`.
pub trait CompileCache {
    /// Retrieve a cached plan by its `LayerId`.
    ///
    /// Returns `None` if the plan is not in the cache.
    /// Updates hit/miss statistics.
    fn get(&self, id: &LayerId) -> Option<BackendPlan>;

    /// Store a plan in the cache.
    ///
    /// The plan is associated with the given `LayerId` for future retrieval.
    fn put(&mut self, id: LayerId, plan: BackendPlan);

    /// Check if a plan exists in the cache without retrieving it.
    ///
    /// Does NOT update statistics (use `get()` for tracked lookups).
    fn contains(&self, id: &LayerId) -> bool;

    /// Remove a plan from the cache.
    ///
    /// Returns the removed plan if it existed.
    fn remove(&mut self, id: &LayerId) -> Option<BackendPlan>;

    /// Clear all entries from the cache.
    fn clear(&mut self);

    /// Get the number of entries in the cache.
    fn len(&self) -> usize;

    /// Check if the cache is empty.
    fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Get cache statistics.
    fn stats(&self) -> &CacheStats;
}

/// In-memory cache for compiled plans.
///
/// This is a simple `HashMap`-based cache suitable for single-process use.
/// For production use, consider implementing `CompileCache` with persistent storage.
///
/// # Statistics
///
/// The cache tracks hit/miss statistics:
///
/// ```
/// use hologram_compiler::cache::{MemoryCache, CompileCache};
///
/// let cache = MemoryCache::new();
/// // After some operations...
/// if let Some(rate) = cache.stats().hit_rate() {
///     println!("Cache hit rate: {:.1}%", rate * 100.0);
/// }
/// ```
#[derive(Debug, Default)]
pub struct MemoryCache {
    entries: HashMap<LayerId, BackendPlan>,
    stats: CacheStats,
}

impl MemoryCache {
    /// Create a new empty cache.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Create a cache with pre-allocated capacity.
    #[must_use]
    pub fn with_capacity(capacity: usize) -> Self {
        Self {
            entries: HashMap::with_capacity(capacity),
            stats: CacheStats::default(),
        }
    }
}

impl CompileCache for MemoryCache {
    fn get(&self, id: &LayerId) -> Option<BackendPlan> {
        let result = self.entries.get(id).cloned();
        if result.is_some() {
            self.stats.record_hit();
        } else {
            self.stats.record_miss();
        }
        result
    }

    fn put(&mut self, id: LayerId, plan: BackendPlan) {
        self.entries.insert(id, plan);
    }

    fn contains(&self, id: &LayerId) -> bool {
        self.entries.contains_key(id)
    }

    fn remove(&mut self, id: &LayerId) -> Option<BackendPlan> {
        self.entries.remove(id)
    }

    fn clear(&mut self) {
        self.entries.clear();
    }

    fn len(&self) -> usize {
        self.entries.len()
    }

    fn stats(&self) -> &CacheStats {
        &self.stats
    }
}

/// Two-tier disk-backed cache for compiled plans.
///
/// This cache stores plans both in memory and on disk. Memory provides fast
/// access for hot plans, while disk provides persistence across process restarts.
///
/// # Statistics
///
/// Statistics track combined hit/miss across both tiers. A "hit" is recorded
/// when the plan is found in either memory or disk.
///
/// # Example
///
/// ```no_run
/// use hologram_compiler::cache::{DiskCache, CompileCache, LayerId};
///
/// let mut cache = DiskCache::new().unwrap();
///
/// // Plans are stored in memory and on disk
/// // cache.put(id, plan);
///
/// // First check memory, then disk
/// // let plan = cache.get(&id);
///
/// // Check statistics
/// println!("Hit rate: {:?}", cache.stats().hit_rate());
/// ```
#[derive(Debug)]
pub struct DiskCache {
    /// In-memory cache for hot plans.
    memory: MemoryCache,
    /// Disk cache for persistence.
    disk: hologram_registry::PlanCache,
    /// Combined statistics for both tiers.
    stats: CacheStats,
}

impl DiskCache {
    /// Create a new disk cache at the default location.
    ///
    /// The default location is `~/.hologram/cache/plans/`.
    ///
    /// # Errors
    ///
    /// Returns an error if the cache directory cannot be created.
    pub fn new() -> Result<Self, hologram_registry::RegistryError> {
        Ok(Self {
            memory: MemoryCache::new(),
            disk: hologram_registry::PlanCache::default_location()?,
            stats: CacheStats::default(),
        })
    }

    /// Create a disk cache at a custom location.
    ///
    /// # Errors
    ///
    /// Returns an error if the cache directory cannot be created.
    pub fn with_path(
        path: impl Into<std::path::PathBuf>,
    ) -> Result<Self, hologram_registry::RegistryError> {
        Ok(Self {
            memory: MemoryCache::new(),
            disk: hologram_registry::PlanCache::new(path)?,
            stats: CacheStats::default(),
        })
    }

    /// Get the underlying disk cache.
    #[must_use]
    pub fn disk(&self) -> &hologram_registry::PlanCache {
        &self.disk
    }

    /// Get the number of entries in the memory cache.
    #[must_use]
    pub fn memory_len(&self) -> usize {
        self.memory.entries.len()
    }

    /// Get the number of entries in the disk cache.
    ///
    /// Note: This requires scanning the disk, which may be slow.
    #[must_use]
    pub fn disk_len(&self) -> usize {
        self.disk.list().map(|v| v.len()).unwrap_or(0)
    }
}

impl CompileCache for DiskCache {
    fn get(&self, id: &LayerId) -> Option<BackendPlan> {
        // Check memory first (don't count memory stats separately)
        if let Some(plan) = self.memory.entries.get(id).cloned() {
            self.stats.record_hit();
            return Some(plan);
        }

        // Check disk
        let result = self.disk.get(id.as_bytes());
        if result.is_some() {
            self.stats.record_hit();
        } else {
            self.stats.record_miss();
        }
        result
    }

    fn put(&mut self, id: LayerId, plan: BackendPlan) {
        // Store in memory
        self.memory.entries.insert(id, plan.clone());

        // Store on disk (ignore errors)
        let _ = self.disk.put(id.as_bytes(), &plan);
    }

    fn contains(&self, id: &LayerId) -> bool {
        self.memory.entries.contains_key(id) || self.disk.contains(id.as_bytes())
    }

    fn remove(&mut self, id: &LayerId) -> Option<BackendPlan> {
        let plan = self.memory.entries.remove(id);
        let _ = self.disk.remove(id.as_bytes());
        plan
    }

    fn clear(&mut self) {
        self.memory.entries.clear();
        let _ = self.disk.clear();
    }

    fn len(&self) -> usize {
        // Memory len is the primary view
        self.memory.entries.len()
    }

    fn stats(&self) -> &CacheStats {
        &self.stats
    }
}

/// Compile with caching support.
///
/// If the graph's `LayerId` is found in the cache, returns the cached plan.
/// Otherwise, compiles the graph and stores the result in the cache.
pub fn compile_cached<C: CompileCache>(
    graph: &OperationGraph,
    config: &crate::pipeline::CompilerConfig,
    cache: &mut C,
) -> crate::Result<BackendPlan> {
    let layer_id = LayerId::from_graph(graph);

    // Check cache first
    if let Some(plan) = cache.get(&layer_id) {
        return Ok(plan);
    }

    // Compile and cache
    let plan = crate::pipeline::compile(graph, config)?;
    cache.put(layer_id, plan.clone());

    Ok(plan)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::OpNode;
    use hologram_holo::PlanMetadata;

    fn make_empty_plan() -> BackendPlan {
        BackendPlan {
            instructions: Vec::new(),
            buffers: Vec::new(),
            constants: Vec::new(),
            workspace_size: 0,
            dependencies: Vec::new(),
            metadata: PlanMetadata::default(),
            node_buffer_map: Vec::new(),
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        }
    }

    fn make_simple_graph() -> OperationGraph {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph
    }

    #[test]
    fn test_layer_id_deterministic() {
        let graph = make_simple_graph();
        let id1 = LayerId::from_graph(&graph);
        let id2 = LayerId::from_graph(&graph);
        assert_eq!(id1, id2);
    }

    #[test]
    fn test_layer_id_different_graphs() {
        let graph1 = make_simple_graph();

        let mut graph2 = OperationGraph::new();
        graph2.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph2.add_node(OpNode::new(1, OpKind::Sigmoid, vec![2, 3], DType::F32)); // Different op
        graph2.add_node(OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32));
        graph2.add_edge(0, 1);
        graph2.add_edge(1, 2);

        let id1 = LayerId::from_graph(&graph1);
        let id2 = LayerId::from_graph(&graph2);
        assert_ne!(id1, id2);
    }

    #[test]
    fn test_layer_id_different_shapes() {
        let graph1 = make_simple_graph();

        let mut graph2 = OperationGraph::new();
        graph2.add_node(OpNode::new(0, OpKind::Input, vec![4, 5], DType::F32)); // Different shape
        graph2.add_node(OpNode::new(1, OpKind::Relu, vec![4, 5], DType::F32));
        graph2.add_node(OpNode::new(2, OpKind::Output, vec![4, 5], DType::F32));
        graph2.add_edge(0, 1);
        graph2.add_edge(1, 2);

        let id1 = LayerId::from_graph(&graph1);
        let id2 = LayerId::from_graph(&graph2);
        assert_ne!(id1, id2);
    }

    #[test]
    fn test_layer_id_different_dtype() {
        let graph1 = make_simple_graph();

        let mut graph2 = OperationGraph::new();
        graph2.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F64)); // Different dtype
        graph2.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F64));
        graph2.add_node(OpNode::new(2, OpKind::Output, vec![2, 3], DType::F64));
        graph2.add_edge(0, 1);
        graph2.add_edge(1, 2);

        let id1 = LayerId::from_graph(&graph1);
        let id2 = LayerId::from_graph(&graph2);
        assert_ne!(id1, id2);
    }

    #[test]
    fn test_layer_id_different_edges() {
        let mut graph1 = OperationGraph::new();
        graph1.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph1.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
        graph1.add_node(OpNode::new(2, OpKind::Sigmoid, vec![2, 3], DType::F32));
        graph1.add_node(OpNode::new(3, OpKind::Output, vec![2, 3], DType::F32));
        graph1.add_edge(0, 1);
        graph1.add_edge(1, 2);
        graph1.add_edge(2, 3);

        let mut graph2 = OperationGraph::new();
        graph2.add_node(OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32));
        graph2.add_node(OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32));
        graph2.add_node(OpNode::new(2, OpKind::Sigmoid, vec![2, 3], DType::F32));
        graph2.add_node(OpNode::new(3, OpKind::Output, vec![2, 3], DType::F32));
        graph2.add_edge(0, 1);
        graph2.add_edge(0, 2); // Different edge!
        graph2.add_edge(1, 3);
        graph2.add_edge(2, 3);

        let id1 = LayerId::from_graph(&graph1);
        let id2 = LayerId::from_graph(&graph2);
        assert_ne!(id1, id2);
    }

    #[test]
    fn test_layer_id_display() {
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);
        let display = format!("{id}");
        assert_eq!(display.len(), 64); // 32 bytes * 2 hex chars
    }

    #[test]
    fn test_layer_id_debug() {
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);
        let debug = format!("{id:?}");
        assert!(debug.starts_with("LayerId("));
    }

    #[test]
    fn test_layer_id_bytes_roundtrip() {
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);
        let bytes = *id.as_bytes();
        let id2 = LayerId::from_bytes(bytes);
        assert_eq!(id, id2);
    }

    #[test]
    fn test_memory_cache_new() {
        let cache = MemoryCache::new();
        assert!(cache.is_empty());
        assert_eq!(cache.len(), 0);
    }

    #[test]
    fn test_memory_cache_put_get() {
        let mut cache = MemoryCache::new();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        let plan = make_empty_plan();
        cache.put(id, plan.clone());

        assert!(cache.contains(&id));
        assert_eq!(cache.len(), 1);

        let retrieved = cache.get(&id);
        assert!(retrieved.is_some());
    }

    #[test]
    fn test_memory_cache_miss() {
        let cache = MemoryCache::new();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        assert!(!cache.contains(&id));
        assert!(cache.get(&id).is_none());
    }

    #[test]
    fn test_memory_cache_remove() {
        let mut cache = MemoryCache::new();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        let plan = make_empty_plan();
        cache.put(id, plan);

        let removed = cache.remove(&id);
        assert!(removed.is_some());
        assert!(!cache.contains(&id));
        assert!(cache.is_empty());
    }

    #[test]
    fn test_memory_cache_clear() {
        let mut cache = MemoryCache::new();

        for i in 0_usize..5 {
            let mut graph = OperationGraph::new();
            graph.add_node(OpNode::new(0, OpKind::Input, vec![i], DType::F32));
            let id = LayerId::from_graph(&graph);
            cache.put(id, make_empty_plan());
        }

        assert_eq!(cache.len(), 5);

        cache.clear();
        assert!(cache.is_empty());
    }

    #[test]
    fn test_memory_cache_overwrite() {
        let mut cache = MemoryCache::new();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        let plan1 = make_empty_plan();
        cache.put(id, plan1);
        assert_eq!(cache.len(), 1);

        let plan2 = make_empty_plan();
        cache.put(id, plan2);
        assert_eq!(cache.len(), 1); // Still 1, not 2
    }

    #[test]
    fn test_compile_cached_miss() {
        let mut cache = MemoryCache::new();
        let graph = make_simple_graph();
        let config = crate::pipeline::CompilerConfig::default();

        let result = compile_cached(&graph, &config, &mut cache);
        assert!(result.is_ok());
        assert_eq!(cache.len(), 1);
    }

    #[test]
    fn test_compile_cached_hit() {
        let mut cache = MemoryCache::new();
        let graph = make_simple_graph();
        let config = crate::pipeline::CompilerConfig::default();

        // First compile - cache miss
        let result1 = compile_cached(&graph, &config, &mut cache);
        assert!(result1.is_ok());
        assert_eq!(cache.len(), 1);

        // Second compile - cache hit
        let result2 = compile_cached(&graph, &config, &mut cache);
        assert!(result2.is_ok());
        assert_eq!(cache.len(), 1); // No new entry
    }

    #[test]
    fn test_layer_id_matmul() {
        let mut graph1 = OperationGraph::new();
        graph1.add_node(OpNode::new(0, OpKind::Input, vec![8, 16], DType::F32));
        graph1.add_node(OpNode::new(1, OpKind::Input, vec![16, 32], DType::F32));
        graph1.add_node(OpNode::new(
            2,
            OpKind::MatMul { m: 8, k: 16, n: 32 },
            vec![8, 32],
            DType::F32,
        ));
        graph1.add_edge(0, 2);
        graph1.add_edge(1, 2);

        let mut graph2 = OperationGraph::new();
        graph2.add_node(OpNode::new(0, OpKind::Input, vec![8, 16], DType::F32));
        graph2.add_node(OpNode::new(1, OpKind::Input, vec![16, 32], DType::F32));
        graph2.add_node(OpNode::new(
            2,
            OpKind::MatMul { m: 8, k: 16, n: 64 }, // Different n!
            vec![8, 64],
            DType::F32,
        ));
        graph2.add_edge(0, 2);
        graph2.add_edge(1, 2);

        let id1 = LayerId::from_graph(&graph1);
        let id2 = LayerId::from_graph(&graph2);
        assert_ne!(id1, id2);
    }

    #[test]
    fn test_layer_id_named_io() {
        let mut graph1 = make_simple_graph();
        graph1.add_input("x", 0);
        graph1.add_output("y", 2);

        let mut graph2 = make_simple_graph();
        graph2.add_input("a", 0); // Different name
        graph2.add_output("b", 2);

        let id1 = LayerId::from_graph(&graph1);
        let id2 = LayerId::from_graph(&graph2);
        assert_ne!(id1, id2);
    }

    #[test]
    fn test_disk_cache_new() {
        let temp = tempfile::TempDir::new().unwrap();
        let cache = DiskCache::with_path(temp.path()).unwrap();
        assert!(cache.is_empty());
        assert_eq!(cache.len(), 0);
        assert_eq!(cache.memory_len(), 0);
    }

    #[test]
    fn test_disk_cache_put_get() {
        let temp = tempfile::TempDir::new().unwrap();
        let mut cache = DiskCache::with_path(temp.path()).unwrap();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        let plan = make_empty_plan();
        cache.put(id, plan.clone());

        assert!(cache.contains(&id));
        assert_eq!(cache.len(), 1);

        let retrieved = cache.get(&id);
        assert!(retrieved.is_some());
    }

    #[test]
    fn test_disk_cache_persists() {
        let temp = tempfile::TempDir::new().unwrap();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        // Store in first cache instance
        {
            let mut cache = DiskCache::with_path(temp.path()).unwrap();
            let plan = make_empty_plan();
            cache.put(id, plan);
        }

        // Retrieve from new cache instance (simulates restart)
        {
            let cache = DiskCache::with_path(temp.path()).unwrap();
            // Not in memory, but should be on disk
            assert!(cache.disk.contains(id.as_bytes()));

            let retrieved = cache.get(&id);
            assert!(retrieved.is_some());
        }
    }

    #[test]
    fn test_disk_cache_miss() {
        let temp = tempfile::TempDir::new().unwrap();
        let cache = DiskCache::with_path(temp.path()).unwrap();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        assert!(!cache.contains(&id));
        assert!(cache.get(&id).is_none());
    }

    #[test]
    fn test_disk_cache_remove() {
        let temp = tempfile::TempDir::new().unwrap();
        let mut cache = DiskCache::with_path(temp.path()).unwrap();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        let plan = make_empty_plan();
        cache.put(id, plan);

        let removed = cache.remove(&id);
        assert!(removed.is_some());
        assert!(!cache.contains(&id));
    }

    #[test]
    fn test_disk_cache_clear() {
        let temp = tempfile::TempDir::new().unwrap();
        let mut cache = DiskCache::with_path(temp.path()).unwrap();

        for i in 0_usize..3 {
            let mut graph = OperationGraph::new();
            graph.add_node(OpNode::new(0, OpKind::Input, vec![i], DType::F32));
            let id = LayerId::from_graph(&graph);
            cache.put(id, make_empty_plan());
        }

        assert_eq!(cache.len(), 3);

        cache.clear();
        assert!(cache.is_empty());
    }

    #[test]
    fn test_compile_cached_disk() {
        let temp = tempfile::TempDir::new().unwrap();
        let mut cache = DiskCache::with_path(temp.path()).unwrap();
        let graph = make_simple_graph();
        let config = crate::pipeline::CompilerConfig::default();

        // First compile - cache miss
        let result1 = compile_cached(&graph, &config, &mut cache);
        assert!(result1.is_ok());
        assert_eq!(cache.len(), 1);

        // Second compile - cache hit
        let result2 = compile_cached(&graph, &config, &mut cache);
        assert!(result2.is_ok());
        assert_eq!(cache.len(), 1); // No new entry
    }

    // ========================================================================
    // Cache Statistics Tests (TASK-168)
    // ========================================================================

    #[test]
    fn test_cache_stats_initial() {
        let stats = CacheStats::default();
        assert_eq!(stats.hits(), 0);
        assert_eq!(stats.misses(), 0);
        assert_eq!(stats.total_requests(), 0);
        assert!(stats.hit_rate().is_none());
        assert!(stats.miss_rate().is_none());
    }

    #[test]
    fn test_memory_cache_stats_hit_miss() {
        let mut cache = MemoryCache::new();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        // Miss
        let _ = cache.get(&id);
        assert_eq!(cache.stats().misses(), 1);
        assert_eq!(cache.stats().hits(), 0);

        // Put and hit
        cache.put(id, make_empty_plan());
        let _ = cache.get(&id);
        assert_eq!(cache.stats().hits(), 1);
        assert_eq!(cache.stats().misses(), 1);

        // Hit rate should be 0.5
        let hit_rate = cache.stats().hit_rate().unwrap();
        assert!((hit_rate - 0.5).abs() < 0.01);
    }

    #[test]
    fn test_memory_cache_stats_reset() {
        let mut cache = MemoryCache::new();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        cache.put(id, make_empty_plan());
        let _ = cache.get(&id);
        assert!(cache.stats().total_requests() > 0);

        cache.stats().reset();
        assert_eq!(cache.stats().hits(), 0);
        assert_eq!(cache.stats().misses(), 0);
    }

    #[test]
    fn test_disk_cache_stats_hit_miss() {
        let temp = tempfile::TempDir::new().unwrap();
        let mut cache = DiskCache::with_path(temp.path()).unwrap();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        // Miss
        let _ = cache.get(&id);
        assert_eq!(cache.stats().misses(), 1);
        assert_eq!(cache.stats().hits(), 0);

        // Put and hit
        cache.put(id, make_empty_plan());
        let _ = cache.get(&id);
        assert_eq!(cache.stats().hits(), 1);
        assert_eq!(cache.stats().misses(), 1);
    }

    #[test]
    fn test_cache_stats_miss_rate() {
        let cache = MemoryCache::new();
        let graph = make_simple_graph();
        let id = LayerId::from_graph(&graph);

        // All misses
        for _ in 0..4 {
            let _ = cache.get(&id);
        }

        let miss_rate = cache.stats().miss_rate().unwrap();
        assert!((miss_rate - 1.0).abs() < 0.01);
    }

    #[test]
    fn test_compile_cached_tracks_stats() {
        let mut cache = MemoryCache::new();
        let graph = make_simple_graph();
        let config = crate::pipeline::CompilerConfig::default();

        // First compile - cache miss
        let _ = compile_cached(&graph, &config, &mut cache);
        assert_eq!(cache.stats().misses(), 1);
        assert_eq!(cache.stats().hits(), 0);

        // Second compile - cache hit
        let _ = compile_cached(&graph, &config, &mut cache);
        assert_eq!(cache.stats().hits(), 1);
        assert_eq!(cache.stats().misses(), 1);
    }
}
