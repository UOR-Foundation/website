//! Registry benchmarks.

use criterion::{black_box, criterion_group, criterion_main, Criterion, Throughput};
use hologram_registry::{hash_data, LayerReference, LocalRegistry, PlanCache};
use tempfile::TempDir;

fn bench_hash(c: &mut Criterion) {
    let mut group = c.benchmark_group("registry/hash");

    for size in [1024, 64 * 1024, 1024 * 1024] {
        let data: Vec<u8> = (0..size).map(|i| (i % 256) as u8).collect();
        group.throughput(Throughput::Bytes(size as u64));

        group.bench_function(format!("{size}b"), |b| {
            b.iter(|| hash_data(black_box(&data)));
        });
    }

    group.finish();
}

fn bench_store(c: &mut Criterion) {
    let mut group = c.benchmark_group("registry/store");

    let temp = TempDir::new().unwrap();
    let registry = LocalRegistry::new(temp.path()).unwrap();

    for size in [1024, 64 * 1024] {
        let data: Vec<u8> = (0..size).map(|i| (i % 256) as u8).collect();
        group.throughput(Throughput::Bytes(size as u64));

        group.bench_function(format!("{size}b"), |b| {
            b.iter(|| {
                // Make data unique each iteration to avoid idempotent path
                let mut unique_data = data.clone();
                unique_data[0] = rand_byte();
                registry.store(black_box(&unique_data))
            });
        });
    }

    group.finish();
}

fn bench_fetch(c: &mut Criterion) {
    let mut group = c.benchmark_group("registry/fetch");

    let temp = TempDir::new().unwrap();
    let registry = LocalRegistry::new(temp.path()).unwrap();

    for size in [1024, 64 * 1024] {
        let data: Vec<u8> = (0..size).map(|i| (i % 256) as u8).collect();
        let hash = registry.store(&data).unwrap();

        group.throughput(Throughput::Bytes(size as u64));

        group.bench_function(format!("{size}b"), |b| {
            b.iter(|| registry.fetch(black_box(&hash)));
        });
    }

    group.finish();
}

fn bench_layer_ref_parse(c: &mut Criterion) {
    let mut group = c.benchmark_group("registry/parse");

    let refs = vec![
        ("hash", format!("blake3:{}", "ab".repeat(32))),
        ("name", "my-model:v1.0".to_string()),
        ("path", "./models/test.holb".to_string()),
    ];

    for (name, ref_str) in refs {
        group.bench_function(name, |b| {
            b.iter(|| {
                let _: LayerReference = black_box(&ref_str).parse().unwrap();
            });
        });
    }

    group.finish();
}

fn bench_plan_cache(c: &mut Criterion) {
    use hologram_holo::{BackendPlan, PlanMetadata};

    let mut group = c.benchmark_group("registry/plan_cache");

    let temp = TempDir::new().unwrap();
    let cache = PlanCache::new(temp.path()).unwrap();

    let plan = BackendPlan {
        instructions: vec![],
        buffers: vec![],
        constants: vec![0u8; 10_000],
        workspace_size: 1024,
        dependencies: vec![],
        metadata: PlanMetadata::default(),
        node_buffer_map: vec![],
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let hash = [0xab; 32];
    cache.put(&hash, &plan).unwrap();

    group.bench_function("get_hit", |b| {
        b.iter(|| cache.get(black_box(&hash)));
    });

    group.bench_function("get_miss", |b| {
        let miss_hash = [0x00; 32];
        b.iter(|| cache.get(black_box(&miss_hash)));
    });

    group.bench_function("put", |b| {
        let mut i = 0u8;
        b.iter(|| {
            i = i.wrapping_add(1);
            let mut h = hash;
            h[0] = i;
            cache.put(black_box(&h), black_box(&plan))
        });
    });

    group.finish();
}

/// Simple pseudo-random byte for unique data.
fn rand_byte() -> u8 {
    use std::time::{SystemTime, UNIX_EPOCH};
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .subsec_nanos();
    (nanos % 256) as u8
}

criterion_group!(
    benches,
    bench_hash,
    bench_store,
    bench_fetch,
    bench_layer_ref_parse,
    bench_plan_cache,
);
criterion_main!(benches);
