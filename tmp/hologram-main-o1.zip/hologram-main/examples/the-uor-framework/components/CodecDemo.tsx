import React, { useState } from 'react';
import { encodeCategoricalX, runBijectivityTestSuite } from '../services/codec';
import { EncodedArtifact } from '../types';
import { ONTOLOGY_DATA } from '../constants';
import { ArrowRightLeft, Database, ShieldCheck, AlertTriangle, CheckCircle, Activity } from 'lucide-react';

const CodecDemo: React.FC = () => {
  const [input, setInput] = useState("Categorical X");
  const [artifact, setArtifact] = useState<EncodedArtifact | null>(null);
  const [testStats, setTestStats] = useState<{total: number, passed: number} | null>(null);

  const handleEncode = () => {
    const result = encodeCategoricalX(input);
    setArtifact(result);
    setTestStats(null);
  };

  const handleRunSuite = () => {
    const results = runBijectivityTestSuite(1000);
    setTestStats({ total: results.total, passed: results.passed });
  };

  // Helper to get ontology name for level
  const getLevelName = (level: number) => {
    // Try to find matching tower level
    const towerNode = ONTOLOGY_DATA["@graph"].find(n => n["@id"] === `cxs:tower/levels/${level}`);
    if (towerNode) return towerNode.label;
    
    // Fallback for higher levels
    if (level === 0) return "Reals (R)";
    if (level === 1) return "Complex (C)";
    if (level === 2) return "Quaternions (H)";
    if (level === 3) return "Octonions (O)";
    if (level === 4) return "Sedenions (S)";
    if (level === 5) return "Pathions (P)";
    
    return `Higher Gauge (${level})`;
  };

  React.useEffect(() => {
    handleEncode();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-y-auto">
      <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-lg">
        <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
          <Database className="w-6 h-6 text-blue-400" />
          Categorical X Codec
        </h2>
        <p className="text-slate-400 mb-6">
          Complete hierarchical encoder/decoder. Proof of bijectivity at arbitrary scales using Mixed Radix Decomposition mapped to the Cayley-Dickson Tower.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-4">
            <label className="block text-sm font-medium text-slate-300">Input Sequence (ASCII)</label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="w-full h-32 bg-slate-900 border border-slate-600 rounded-lg p-3 text-white font-mono focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              placeholder="Enter text to encode..."
            />
            <div className="flex justify-between items-center">
              <button
                onClick={handleRunSuite}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm font-medium rounded-lg transition-colors flex items-center gap-2"
              >
                <Activity className="w-4 h-4" />
                Run Bijectivity Proof (1k)
              </button>

              <button
                onClick={handleEncode}
                className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg transition-colors flex items-center gap-2"
              >
                <ArrowRightLeft className="w-4 h-4" />
                Encode / Verify
              </button>
            </div>
            
            {testStats && (
                <div className="bg-slate-900/50 p-2 rounded border border-emerald-500/20 flex items-center gap-2 text-sm text-emerald-400">
                    <CheckCircle className="w-4 h-4" />
                    <span>Passed {testStats.passed} / {testStats.total} randomized roundtrip tests.</span>
                </div>
            )}
          </div>

          {/* Verification Stats */}
          <div className="bg-slate-900 rounded-lg p-4 border border-slate-700 flex flex-col justify-center space-y-4">
             <div>
                <span className="text-xs uppercase text-slate-500 font-semibold tracking-wider">Artifact Status</span>
                <div className="flex items-center gap-2 mt-1">
                    {artifact?.verification ? (
                        <>
                            <ShieldCheck className="w-6 h-6 text-emerald-400" />
                            <span className="text-lg font-bold text-emerald-400">Bijective Verification Passed</span>
                        </>
                    ) : (
                        <>
                            <AlertTriangle className="w-6 h-6 text-red-400" />
                            <span className="text-lg font-bold text-red-400">Verification Failed</span>
                        </>
                    )}
                </div>
             </div>
             <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-800 p-3 rounded">
                    <span className="text-xs text-slate-500 block">Max Tower Level</span>
                    <span className="text-xl font-mono text-purple-400">{artifact?.gaugeLevel ?? 0}</span>
                </div>
                 <div className="bg-slate-800 p-3 rounded">
                    <span className="text-xs text-slate-500 block">Char Length</span>
                    <span className="text-xl font-mono text-blue-400">{input.length}</span>
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* Artifact Details */}
      {artifact && (
        <div className="grid grid-cols-1 gap-6">
            <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <h3 className="text-lg font-semibold text-white mb-4">Hierarchical Gauge Decomposition</h3>
                <div className="overflow-x-auto">
                    <div className="min-w-full inline-block align-middle">
                        <div className="border border-slate-700 rounded overflow-hidden max-h-96 overflow-y-auto">
                            <table className="min-w-full divide-y divide-slate-700">
                                <thead className="bg-slate-900 sticky top-0">
                                    <tr>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Level (k)</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Ontology Label</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Modulus (m_k)</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Coefficient (d_k)</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-slate-800 divide-y divide-slate-700">
                                    {artifact.coordinates.map((coord) => (
                                        <tr key={coord.level}>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">{coord.level}</td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-purple-300 font-medium">
                                                {getLevelName(coord.level)}
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">
                                                {coord.modulus}
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-blue-300">{coord.remainder}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <h3 className="text-lg font-semibold text-white mb-2">Intermediate BigInt Representation</h3>
                <p className="text-xs text-slate-400 mb-4">The exact integer value of the input sequence mapped to the 96-character categorical alphabet.</p>
                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 overflow-x-auto">
                    <code className="text-xs font-mono text-emerald-500 break-all">
                        {artifact.bigIntRep}
                    </code>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default CodecDemo;
