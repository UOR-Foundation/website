/**
 * ConversationSidebar — Lists past sovereign conversations with attestation metadata.
 */

import { Plus, Trash2, MessageSquare, Clock } from "lucide-react";
import type { ConversationSnapshot } from "../hooks/useSovereignConversations";

interface Props {
  conversations: ConversationSnapshot[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onCreate: () => void;
  onDelete: (id: string) => void;
}

export default function ConversationSidebar({
  conversations,
  activeId,
  onSelect,
  onCreate,
  onDelete,
}: Props) {
  return (
    <div className="flex flex-col h-full border-r border-border bg-muted/30 w-56 shrink-0">
      <div className="flex items-center justify-between px-3 py-2 border-b border-border">
        <span className="text-[9px] font-mono text-muted-foreground uppercase tracking-wider">
          Past chats
        </span>
        <button
          onClick={onCreate}
          className="p-1 rounded hover:bg-primary/10 text-primary transition-colors"
          title="New conversation"
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {conversations.length === 0 && (
          <div className="px-3 py-6 text-center">
            <MessageSquare className="h-5 w-5 text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-[10px] text-muted-foreground/50">No conversations yet</p>
          </div>
        )}

        {conversations.map((convo) => (
          <button
            key={convo.id}
            onClick={() => onSelect(convo.id)}
            className={`w-full text-left px-3 py-2 border-b border-border/50 transition-colors group ${
              convo.id === activeId
                ? "bg-primary/5 border-l-2 border-l-primary"
                : "hover:bg-muted/50 border-l-2 border-l-transparent"
            }`}
          >
            <p className="text-[11px] text-foreground truncate leading-tight">
              {convo.title}
            </p>
            <div className="flex items-center justify-between mt-1">
              <span className="text-[8px] text-muted-foreground flex items-center gap-1">
                <Clock className="h-2 w-2" />
                {new Date(convo.updatedAt).toLocaleDateString()}
              </span>
              <div className="flex items-center gap-1">
                {convo.attestation && (
                  <span className="text-[7px] font-mono text-primary/60">
                    {convo.attestation.proofSummary.disclosurePercent}% shared
                  </span>
                )}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(convo.id);
                  }}
                  className="p-0.5 rounded opacity-0 group-hover:opacity-100 hover:bg-destructive/10 text-destructive/60 hover:text-destructive transition-all"
                  title="Delete conversation"
                >
                  <Trash2 className="h-2.5 w-2.5" />
                </button>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
