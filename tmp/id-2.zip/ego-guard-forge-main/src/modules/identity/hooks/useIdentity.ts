/**
 * useIdentity — Manages identity module state.
 *
 * Standalone hook with mock data for development.
 * On merge: wire to real persistence via hologram-ui hooks.
 *
 * @module identity/hooks/useIdentity
 */

import { useState, useCallback, useEffect, useRef } from "react";
import type {
  IdentityProfile,
  TrustScore,
  Permission,
  PrivacyConsent,
  PrivacyPolicy,
  IdentityModuleState,
  CeremonyRecord,
  CeremonyIdentityProfile,
  SovereigntySurface,
  EdgeState,
  BoundaryCommitment,
} from "../types";
import { computeTrustScore, createDefaultSurface, flipEdge, flipEdges, edgesForDataCategory, createBoundaryCommitment } from "../engine";
import { useScreenContext } from "../compat";
import { MOCK_PROFILE, MOCK_ATTESTATIONS, MOCK_PERMISSIONS, MOCK_CONSENTS, MOCK_POLICY, MOCK_CEREMONIES } from "./mock-data";
import { supabase } from "@/integrations/supabase/client";

export function useIdentity(): IdentityModuleState & {
  surface: SovereigntySurface;
  commitmentHistory: BoundaryCommitment[];
  exploredFacets: Set<string>;
  markFacetExplored: (facetId: string) => void;
  updateProfile: (partial: Partial<IdentityProfile>) => void;
  togglePermission: (permissionId: string) => void;
  updateConsent: (consentId: string, status: "granted" | "denied") => void;
  addCeremony: (ceremony: CeremonyRecord) => void;
  flipSurfaceEdge: (edgeId: string, newState: EdgeState) => void;
} {
  const [profile, setProfile] = useState<CeremonyIdentityProfile>(MOCK_PROFILE);
  const [permissions, setPermissions] = useState<Permission[]>([...MOCK_PERMISSIONS]);
  const [consents, setConsents] = useState<PrivacyConsent[]>([...MOCK_CONSENTS]);
  const [trustScore, setTrustScore] = useState<TrustScore | null>(null);
  const [privacyPolicy] = useState<PrivacyPolicy>(MOCK_POLICY);
  const [ceremonies, setCeremonies] = useState<CeremonyRecord[]>([...MOCK_CEREMONIES]);
  const [surface, setSurface] = useState<SovereigntySurface>(() => createDefaultSurface(MOCK_PROFILE.id));
  const [exploredFacets, setExploredFacets] = useState<Set<string>>(new Set());

  // Load profile + explored facets from database if authenticated
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) return;
      supabase
        .from("profiles")
        .select("display_name, handle, uor_id, cover_image_url, avatar_url, explored_facets")
        .eq("user_id", session.user.id)
        .maybeSingle()
        .then(({ data }) => {
          if (data) {
            setProfile((prev) => ({
              ...prev,
              displayName: data.display_name,
              handle: data.handle,
              id: data.uor_id || prev.id,
              coverImageUrl: data.cover_image_url || undefined,
              avatarUrl: data.avatar_url || undefined,
            }));
            if (data.explored_facets && (data.explored_facets as string[]).length > 0) {
              setExploredFacets(new Set(data.explored_facets as string[]));
            }
          }
        });
    });
  }, []);
  const [commitmentHistory, setCommitmentHistory] = useState<BoundaryCommitment[]>([]);
  const prevSurfaceRef = useRef(surface);

  const ctx = useScreenContext();

  // Register as screen beacon
  useEffect(() => {
    ctx.registerBeacon({
      id: "identity:profile",
      title: profile.displayName,
      summary: `Identity: ${profile.handle}`,
      contentType: "identity",
      metadata: { identityId: profile.id },
      priority: 2,
    });
    return () => ctx.removeBeacon("identity:profile");
  }, [profile.displayName, profile.handle, profile.id]);

  // Compute trust score
  useEffect(() => {
    const score = computeTrustScore(profile.id, MOCK_ATTESTATIONS);
    setTrustScore(score);
  }, [profile.id]);

  // Record boundary commitment whenever surface changes
  useEffect(() => {
    if (prevSurfaceRef.current === surface) return;
    prevSurfaceRef.current = surface;
    createBoundaryCommitment(surface).then((commitment) => {
      setCommitmentHistory((prev) => [...prev, commitment]);
    });
  }, [surface]);

  const updateProfile = useCallback((partial: Partial<IdentityProfile>) => {
    setProfile((prev) => ({ ...prev, ...partial, updatedAt: Date.now() }));
  }, []);

  const togglePermission = useCallback((permissionId: string) => {
    setPermissions((prev) =>
      prev.map((p) =>
        p.id === permissionId ? { ...p, active: !p.active } : p
      )
    );
  }, []);

  const updateConsent = useCallback((consentId: string, status: "granted" | "denied") => {
    setConsents((prev) => {
      const updated = prev.map((c) =>
        c.id === consentId
          ? { ...c, status, grantedAt: status === "granted" ? Date.now() : c.grantedAt }
          : c
      );

      // Find the consent's category and flip corresponding sovereignty edges
      const consent = prev.find((c) => c.id === consentId);
      if (consent) {
        const newEdgeState: EdgeState = status === "granted" ? "disclosed" : "shielded";
        setSurface((prevSurface) => {
          const affectedEdges = edgesForDataCategory(prevSurface, consent.category);
          if (affectedEdges.length === 0) return prevSurface;
          return flipEdges(prevSurface, affectedEdges.map((e) => ({ edgeId: e.id, newState: newEdgeState })));
        });
      }

      return updated;
    });
  }, []);

  const addCeremony = useCallback((ceremony: CeremonyRecord) => {
    setCeremonies((prev) => [...prev, ceremony]);
  }, []);

  const flipSurfaceEdge = useCallback((edgeId: string, newState: EdgeState) => {
    setSurface((prev) => flipEdge(prev, edgeId, newState));
  }, []);

  const markFacetExplored = useCallback(async (facetId: string) => {
    setExploredFacets((prev) => {
      if (prev.has(facetId)) return prev;
      const next = new Set(prev);
      next.add(facetId);
      // Persist to DB
      supabase.auth.getSession().then(({ data: { session } }) => {
        if (!session) return;
        supabase
          .from("profiles")
          .update({ explored_facets: Array.from(next) } as any)
          .eq("user_id", session.user.id)
          .then(() => {});
      });
      return next;
    });
  }, []);

  return {
    profile,
    trustScore,
    permissions,
    consents,
    privacyPolicy,
    ceremonies,
    surface,
    commitmentHistory,
    exploredFacets,
    markFacetExplored,
    updateProfile,
    togglePermission,
    updateConsent,
    addCeremony,
    flipSurfaceEdge,
  };
}
