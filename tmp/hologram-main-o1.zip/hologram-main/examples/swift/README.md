# UOR Swift Bindings Example

Example Swift program demonstrating UOR Swift bindings via UniFFI.

## Prerequisites

- Swift 5.5+ (Xcode or Swift toolchain)
- macOS or Linux with Swift installed
- UOR library built in release mode

## Building

Generate Swift bindings:

```bash
just ffi-swift
```

This creates:
- `bindings/swift/uor.swift` - Swift interface
- `bindings/swift/uorFFI.h` - C header for bridging
- Native library in `target/release/`

## Compiling

### Command Line

```bash
cd examples/swift

# Copy bindings to local directory
cp ../../bindings/swift/uor.swift .

# Compile
swiftc -I ../../bindings/swift \
       -L ../../target/release \
       -luor_ffi \
       Example.swift -o example
```

### Run

```bash
# Set library path
LD_LIBRARY_PATH=../../target/release ./example

# Or on macOS
DYLD_LIBRARY_PATH=../../target/release ./example
```

## Swift Package Manager

Create `Package.swift`:

```swift
// swift-tools-version:5.5
import PackageDescription

let package = Package(
    name: "UORExample",
    targets: [
        .systemLibrary(
            name: "UorFFI",
            path: "bindings/swift",
            pkgConfig: "uor"
        ),
        .target(
            name: "UORExample",
            dependencies: ["UorFFI"],
            path: "examples/swift"
        )
    ]
)
```

Then run:

```bash
swift build
swift run
```

## Features Demonstrated

- **Constants**: Braille codepoints, triadic/octave constants, state dimensions
- **Taxon Operations**: Byte-to-Braille conversion, codepoints, domains, ranks
- **Ring Operations**: Successor, predecessor, bitwise NOT
- **View Operations**: Identity, constant, composition, bijection checks
- **Array Operations**: Batch processing with `applySlice()`

## API Usage

### Basic Operations

```swift
import UOR  // In a real Swift package

// Convert byte to Braille
let braille = byteToBraille(value: 42)  // "⠪"

// Get codepoint
let codepoint = byteToCodepoint(value: 42)  // 0x282A

// Get domain (returns enum)
let domain = byteToDomain(value: 42)  // .theta
```

### View Operations

```swift
// Create views
let identity = FfiView.identity()
let constant = try FfiView.constant(value: 99)

// Apply to single byte
let result = identity.apply(byteValue: 42)  // 42

// Apply to data
let data = Data([1, 2, 3, 4])
let output = identity.applySlice(input: data)

// Compose views
let composed = identity.then(other: constant)
let result = composed.apply(byteValue: 42)  // 99

// Check bijectivity
let isBij = identity.isBijective()  // true
```

## Type System

UniFFI provides idiomatic Swift types:

- **Enums**: `FfiDomain` (.theta, .psi, .delta)
- **Classes**: `FfiView` conforming to protocols
- **Functions**: Top-level functions with UInt8 parameters
- **Data**: Uses Foundation's `Data` for byte arrays
- **Errors**: Swift error handling with `throws`

## Error Handling

```swift
do {
    let view = try FfiView.constant(value: 256)  // Invalid byte
} catch let error as FfiError {
    print("Error: \(error)")
}
```

## Memory Management

UniFFI uses Swift's ARC (Automatic Reference Counting) for memory management.
Native resources are automatically cleaned up when Swift objects are deallocated.

## Xcode Integration

1. Generate bindings: `just ffi-swift`
2. Add `bindings/swift/uor.swift` to your Xcode project
3. Add `target/release/libuor_ffi.dylib` to "Link Binary With Libraries"
4. Set "Library Search Paths" to `$(PROJECT_DIR)/target/release`

## Publishing

Swift packages are typically published via GitHub tags:

```bash
# Create a release tag
git tag -a v0.1.0 -m 'Release v0.1.0'
git push origin v0.1.0
```

Users can then add via Swift Package Manager:

```swift
dependencies: [
    .package(url: "https://github.com/UOR-Foundation/hologram", from: "0.1.0")
]
```

See `just publish-swift` for more details.
