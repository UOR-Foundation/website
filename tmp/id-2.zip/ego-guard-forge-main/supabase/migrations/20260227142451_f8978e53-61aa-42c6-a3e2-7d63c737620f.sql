
-- Add cover_image_url to profiles
ALTER TABLE public.profiles ADD COLUMN cover_image_url text;

-- Create storage bucket for cover images
INSERT INTO storage.buckets (id, name, public) VALUES ('cover-images', 'cover-images', true);

-- Allow authenticated users to upload their own cover images
CREATE POLICY "Users can upload their own cover image"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'cover-images'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Allow authenticated users to update their own cover images
CREATE POLICY "Users can update their own cover image"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'cover-images'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Allow authenticated users to delete their own cover images
CREATE POLICY "Users can delete their own cover image"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'cover-images'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Allow public read access to cover images
CREATE POLICY "Cover images are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'cover-images');
