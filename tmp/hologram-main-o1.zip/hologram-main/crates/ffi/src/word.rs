//! Word type FFI wrappers — data containers exposed across the FFI boundary.
//!
//! Wraps `uor::Word2`, `uor::Word4`, `uor::Word8` for C and WASM consumers.

use crate::core::FfiError;
use uor::{Word2, Word4, Word8};

// ============================================================================
// FfiWord2 (16-bit)
// ============================================================================

/// FFI wrapper for Word2 (16-bit, 2 taxons).
#[derive(Debug, Clone)]
pub struct FfiWord2 {
    inner: Word2,
}

impl FfiWord2 {
    /// Create from a u16 value.
    pub fn new(value: u16) -> Self {
        Self {
            inner: Word2::new(value),
        }
    }

    /// Get the underlying u16 value.
    pub fn value(&self) -> u16 {
        self.inner.value()
    }

    /// Get taxon byte at index (0 = most significant, 1 = least significant).
    pub fn taxon(&self, index: u32) -> Result<u8, FfiError> {
        let idx = index as usize;
        if idx >= 2 {
            return Err(FfiError::InvalidValue(format!(
                "Word2 index {} out of bounds (max 1)",
                index
            )));
        }
        Ok(self.inner.taxon(idx).value())
    }

    /// Create from a byte slice (big-endian, must be exactly 2 bytes).
    pub fn from_bytes(bytes: Vec<u8>) -> Result<Self, FfiError> {
        if bytes.len() != 2 {
            return Err(FfiError::InvalidSize {
                expected: 2,
                actual: bytes.len(),
            });
        }
        Ok(Self {
            inner: Word2::from_bytes([bytes[0], bytes[1]]),
        })
    }

    /// Convert to byte array (big-endian).
    pub fn to_bytes(&self) -> Vec<u8> {
        self.inner.to_bytes().to_vec()
    }

    /// Check if word is zero.
    pub fn is_zero(&self) -> bool {
        self.inner.is_zero()
    }
}

// ============================================================================
// FfiWord4 (32-bit)
// ============================================================================

/// FFI wrapper for Word4 (32-bit, 4 taxons).
#[derive(Debug, Clone)]
pub struct FfiWord4 {
    inner: Word4,
}

impl FfiWord4 {
    /// Create from a u32 value.
    pub fn new(value: u32) -> Self {
        Self {
            inner: Word4::new(value),
        }
    }

    /// Get the underlying u32 value.
    pub fn value(&self) -> u32 {
        self.inner.value()
    }

    /// Get taxon byte at index (0 = most significant, 3 = least significant).
    pub fn taxon(&self, index: u32) -> Result<u8, FfiError> {
        let idx = index as usize;
        if idx >= 4 {
            return Err(FfiError::InvalidValue(format!(
                "Word4 index {} out of bounds (max 3)",
                index
            )));
        }
        Ok(self.inner.taxon(idx).value())
    }

    /// Create from a byte slice (big-endian, must be exactly 4 bytes).
    pub fn from_bytes(bytes: Vec<u8>) -> Result<Self, FfiError> {
        if bytes.len() != 4 {
            return Err(FfiError::InvalidSize {
                expected: 4,
                actual: bytes.len(),
            });
        }
        Ok(Self {
            inner: Word4::from_bytes([bytes[0], bytes[1], bytes[2], bytes[3]]),
        })
    }

    /// Convert to byte array (big-endian).
    pub fn to_bytes(&self) -> Vec<u8> {
        self.inner.to_bytes().to_vec()
    }

    /// Check if word is zero.
    pub fn is_zero(&self) -> bool {
        self.inner.is_zero()
    }
}

// ============================================================================
// FfiWord8 (64-bit)
// ============================================================================

/// FFI wrapper for Word8 (64-bit, 8 taxons).
#[derive(Debug, Clone)]
pub struct FfiWord8 {
    inner: Word8,
}

impl FfiWord8 {
    /// Create from a u64 value.
    pub fn new(value: u64) -> Self {
        Self {
            inner: Word8::new(value),
        }
    }

    /// Get the underlying u64 value.
    pub fn value(&self) -> u64 {
        self.inner.value()
    }

    /// Get taxon byte at index (0 = most significant, 7 = least significant).
    pub fn taxon(&self, index: u32) -> Result<u8, FfiError> {
        let idx = index as usize;
        if idx >= 8 {
            return Err(FfiError::InvalidValue(format!(
                "Word8 index {} out of bounds (max 7)",
                index
            )));
        }
        Ok(self.inner.taxon(idx).value())
    }

    /// Create from a byte slice (big-endian, must be exactly 8 bytes).
    pub fn from_bytes(bytes: Vec<u8>) -> Result<Self, FfiError> {
        if bytes.len() != 8 {
            return Err(FfiError::InvalidSize {
                expected: 8,
                actual: bytes.len(),
            });
        }
        Ok(Self {
            inner: Word8::from_bytes([
                bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7],
            ]),
        })
    }

    /// Convert to byte array (big-endian).
    pub fn to_bytes(&self) -> Vec<u8> {
        self.inner.to_bytes().to_vec()
    }

    /// Check if word is zero.
    pub fn is_zero(&self) -> bool {
        self.inner.is_zero()
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    // Word2 tests
    #[test]
    fn test_word2_new() {
        let w = FfiWord2::new(0x1234);
        assert_eq!(w.value(), 0x1234);
    }

    #[test]
    fn test_word2_taxon() {
        let w = FfiWord2::new(0x1234);
        assert_eq!(w.taxon(0).unwrap(), 0x12);
        assert_eq!(w.taxon(1).unwrap(), 0x34);
        assert!(w.taxon(2).is_err());
    }

    #[test]
    fn test_word2_from_bytes() {
        let w = FfiWord2::from_bytes(vec![0x12, 0x34]).unwrap();
        assert_eq!(w.value(), 0x1234);
        assert!(FfiWord2::from_bytes(vec![0x12]).is_err());
    }

    #[test]
    fn test_word2_to_bytes() {
        let w = FfiWord2::new(0x1234);
        assert_eq!(w.to_bytes(), vec![0x12, 0x34]);
    }

    #[test]
    fn test_word2_is_zero() {
        assert!(FfiWord2::new(0).is_zero());
        assert!(!FfiWord2::new(1).is_zero());
    }

    // Word4 tests
    #[test]
    fn test_word4_new() {
        let w = FfiWord4::new(0xDEADBEEF);
        assert_eq!(w.value(), 0xDEADBEEF);
    }

    #[test]
    fn test_word4_taxon() {
        let w = FfiWord4::new(0x12345678);
        assert_eq!(w.taxon(0).unwrap(), 0x12);
        assert_eq!(w.taxon(1).unwrap(), 0x34);
        assert_eq!(w.taxon(2).unwrap(), 0x56);
        assert_eq!(w.taxon(3).unwrap(), 0x78);
        assert!(w.taxon(4).is_err());
    }

    #[test]
    fn test_word4_from_bytes() {
        let w = FfiWord4::from_bytes(vec![0xDE, 0xAD, 0xBE, 0xEF]).unwrap();
        assert_eq!(w.value(), 0xDEADBEEF);
        assert!(FfiWord4::from_bytes(vec![0x12, 0x34]).is_err());
    }

    #[test]
    fn test_word4_to_bytes() {
        let w = FfiWord4::new(0xDEADBEEF);
        assert_eq!(w.to_bytes(), vec![0xDE, 0xAD, 0xBE, 0xEF]);
    }

    #[test]
    fn test_word4_is_zero() {
        assert!(FfiWord4::new(0).is_zero());
        assert!(!FfiWord4::new(1).is_zero());
    }

    // Word8 tests
    #[test]
    fn test_word8_new() {
        let w = FfiWord8::new(0x123456789ABCDEF0);
        assert_eq!(w.value(), 0x123456789ABCDEF0);
    }

    #[test]
    fn test_word8_taxon() {
        let w = FfiWord8::new(0x123456789ABCDEF0);
        assert_eq!(w.taxon(0).unwrap(), 0x12);
        assert_eq!(w.taxon(7).unwrap(), 0xF0);
        assert!(w.taxon(8).is_err());
    }

    #[test]
    fn test_word8_from_bytes() {
        let w = FfiWord8::from_bytes(vec![0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0]).unwrap();
        assert_eq!(w.value(), 0x123456789ABCDEF0);
        assert!(FfiWord8::from_bytes(vec![0x12, 0x34]).is_err());
    }

    #[test]
    fn test_word8_to_bytes() {
        let w = FfiWord8::new(0x123456789ABCDEF0);
        assert_eq!(
            w.to_bytes(),
            vec![0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0]
        );
    }

    #[test]
    fn test_word8_is_zero() {
        assert!(FfiWord8::new(0).is_zero());
        assert!(!FfiWord8::new(1).is_zero());
    }

    // Roundtrip tests
    #[test]
    fn test_word2_roundtrip() {
        for v in [0u16, 1, 0x1234, 0xFFFF] {
            let w = FfiWord2::new(v);
            let w2 = FfiWord2::from_bytes(w.to_bytes()).unwrap();
            assert_eq!(w.value(), w2.value());
        }
    }

    #[test]
    fn test_word4_roundtrip() {
        for v in [0u32, 1, 0xDEADBEEF, u32::MAX] {
            let w = FfiWord4::new(v);
            let w2 = FfiWord4::from_bytes(w.to_bytes()).unwrap();
            assert_eq!(w.value(), w2.value());
        }
    }

    #[test]
    fn test_word8_roundtrip() {
        for v in [0u64, 1, 0xDEADBEEFCAFEBABE, u64::MAX] {
            let w = FfiWord8::new(v);
            let w2 = FfiWord8::from_bytes(w.to_bytes()).unwrap();
            assert_eq!(w.value(), w2.value());
        }
    }
}
