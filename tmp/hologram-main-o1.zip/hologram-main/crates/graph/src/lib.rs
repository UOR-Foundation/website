//! Graph data structures with generational IDs and algorithms.
//!
//! This crate provides an arena-based directed acyclic graph (DAG) implementation
//! with generational indices for safe node references. It is generic over the
//! operation type, allowing different backends to define their own operations
//! while sharing graph structure and algorithms.
//!
//! # Core Types
//!
//! - [`NodeId`]: Generational identifier for safe node references
//! - [`Node`]: A graph node with operation, inputs, and metadata
//! - [`ComputeGraph`]: Arena-based DAG with O(1) node access
//! - [`GraphBuilder`]: Ergonomic builder for graph construction
//!
//! # Algorithms
//!
//! - [`toposort`]: Topological ordering (Kahn's algorithm)
//! - [`find_cycle`]: Cycle detection (DFS with coloring)
//! - [`levels`]: Parallel execution level assignment
//! - [`reachable_from`]: Forward reachability
//! - [`reaching`]: Backward reachability
//! - [`immediate_dominators`]: Dominance analysis
//!
//! # Example
//!
//! ```
//! use hologram_graph::{ComputeGraph, GraphBuilder, toposort};
//!
//! #[derive(Clone)]
//! enum Op { Input, Add, Output }
//!
//! let graph: ComputeGraph<Op> = GraphBuilder::new()
//!     .node(Op::Input)
//!     .node_with_inputs(Op::Add, &[0])
//!     .node_with_inputs(Op::Output, &[1])
//!     .build();
//!
//! let order = toposort(&graph).expect("acyclic graph");
//! assert_eq!(order.len(), 3);
//! ```

mod algorithms;
mod builder;
mod graph;
mod ids;
mod node;

// Re-export main types
pub use algorithms::{
    dominance_frontiers, extract_subgraph, find_cycle, immediate_dominators, is_acyclic,
    is_ancestor, levels, node_depths, reachable_from, reaching, toposort, CycleError,
};
pub use builder::{BuilderExt, GraphBuilder};
pub use graph::{connect, connect_graph_input, ComputeGraph};
pub use ids::{GroupId, NodeId, SubgraphId};
pub use node::{InputSlot, InputSource, Node};

/// Prelude module for convenient imports.
pub mod prelude {
    pub use crate::algorithms::{
        find_cycle, is_acyclic, levels, node_depths, reachable_from, reaching, toposort,
    };
    pub use crate::builder::GraphBuilder;
    pub use crate::graph::ComputeGraph;
    pub use crate::ids::{GroupId, NodeId};
    pub use crate::node::{InputSlot, InputSource, Node};
}

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Debug, Clone, PartialEq)]
    enum TestOp {
        Input,
        Add,
        Output,
    }

    #[test]
    fn test_crate_example() {
        let graph: ComputeGraph<TestOp> = GraphBuilder::new()
            .node(TestOp::Input)
            .node_with_inputs(TestOp::Add, &[0])
            .node_with_inputs(TestOp::Output, &[1])
            .build();

        let order = toposort(&graph).expect("acyclic graph");
        assert_eq!(order.len(), 3);
    }

    #[test]
    fn test_prelude_imports() {
        use prelude::*;

        let graph: ComputeGraph<TestOp> = GraphBuilder::new().node(TestOp::Input).build();

        assert!(is_acyclic(&graph));
    }

    #[test]
    fn test_all_exports_accessible() {
        // Verify all public items are exported
        let _ = NodeId::new(0, 0);
        let _ = GroupId::new(0);
        let _ = SubgraphId::new(0);
        let _ = InputSource::None;
        let _ = InputSlot::default();
        let _: ComputeGraph<TestOp> = ComputeGraph::new();
        let _: GraphBuilder<TestOp> = GraphBuilder::new();
    }
}
