//! Shared fallback implementations for backend compute operations.
//!
//! These helpers provide CPU-based reference implementations for every
//! [`ComputeBackend`](crate::ComputeBackend) method using only the
//! [`ProgramBackend`](crate::ProgramBackend) buffer interface. Backends can
//! delegate to these functions to get a correct, portable baseline and then
//! override individual operations with hardware-optimized kernels.

use crate::backends::cpu::aspect_gemm::aspect_aware_matmul_f32;
use crate::backends::cpu::compute::{cpu_batch_matmul_f32, cpu_conv2d_f32, cpu_matmul_f32};
use crate::backends::cpu::depthwise::depthwise_conv2d_f32;
use crate::backends::cpu::grouped::grouped_conv2d_f32;
use crate::backends::cpu::pointwise::pointwise_conv_f32;
use crate::{
    AspectAwareMatMulParams, BackendError, BufferHandle, Conv2DParams, DepthwiseConv2DParams,
    GroupedConv2DParams, MatMulParams, PointwiseConvParams, ProgramBackend,
};
use hologram_isa::Type;

const F32_SIZE: usize = std::mem::size_of::<f32>();

fn product(dims: &[u32]) -> usize {
    dims.iter().map(|&d| d as usize).product()
}

fn read_f32_buffer<B: ProgramBackend + ?Sized>(
    backend: &B,
    handle: BufferHandle,
    expected_elements: usize,
) -> Result<Vec<f32>, BackendError> {
    let expected_bytes = expected_elements * F32_SIZE;
    let actual_bytes = backend.buffer_size(handle)?;
    if actual_bytes < expected_bytes {
        return Err(BackendError::SizeMismatch {
            expected: expected_bytes,
            actual: actual_bytes,
        });
    }

    let mut bytes = vec![0u8; expected_bytes];
    backend.copy_from_buffer(handle, &mut bytes)?;

    Ok(bytes
        .chunks_exact(F32_SIZE)
        .map(|chunk| f32::from_le_bytes(chunk.try_into().expect("chunk size matches f32 size")))
        .collect())
}

fn maybe_read_f32_buffer<B: ProgramBackend + ?Sized>(
    backend: &B,
    handle: BufferHandle,
    expected_elements: usize,
) -> Result<Option<Vec<f32>>, BackendError> {
    if handle.is_null() || expected_elements == 0 {
        return Ok(None);
    }
    read_f32_buffer(backend, handle, expected_elements).map(Some)
}

fn write_f32_buffer<B: ProgramBackend + ?Sized>(
    backend: &B,
    handle: BufferHandle,
    data: &[f32],
) -> Result<(), BackendError> {
    let expected_bytes = data.len() * F32_SIZE;
    let actual_bytes = backend.buffer_size(handle)?;
    if actual_bytes < expected_bytes {
        return Err(BackendError::SizeMismatch {
            expected: expected_bytes,
            actual: actual_bytes,
        });
    }

    let mut bytes = Vec::with_capacity(expected_bytes);
    for value in data {
        bytes.extend_from_slice(&value.to_le_bytes());
    }
    backend.copy_to_buffer(handle, &bytes)
}

fn clamp_len<B: ProgramBackend + ?Sized>(
    backend: &B,
    handles: &[BufferHandle],
    requested: usize,
) -> Result<usize, BackendError> {
    handles.iter().try_fold(requested, |len, handle| {
        Ok(len.min(backend.buffer_size(*handle)?))
    })
}

/// Fused multiply-add for CRT batch using host slices.
pub fn fma_scalar_crt_batch(target: &mut [u8], a: &[u8], k: u64) -> Result<(), BackendError> {
    for (dst, src) in target.iter_mut().zip(a.iter()) {
        *dst = ((*src as u64).wrapping_mul(k) % 256) as u8;
    }
    Ok(())
}

/// Byte-wise vector addition implemented with host copies.
pub fn vector_add<B: ProgramBackend + ?Sized>(
    backend: &B,
    dst: BufferHandle,
    a: BufferHandle,
    b: BufferHandle,
    count: usize,
) -> Result<(), BackendError> {
    let len = clamp_len(backend, &[dst, a, b], count)?;
    let mut a_buf = vec![0u8; len];
    let mut b_buf = vec![0u8; len];
    backend.copy_from_buffer(a, &mut a_buf)?;
    backend.copy_from_buffer(b, &mut b_buf)?;

    let mut out = vec![0u8; len];
    for i in 0..len {
        out[i] = a_buf[i].wrapping_add(b_buf[i]);
    }
    backend.copy_to_buffer(dst, &out)
}

/// Byte-wise vector multiplication implemented with host copies.
pub fn vector_mul<B: ProgramBackend + ?Sized>(
    backend: &B,
    dst: BufferHandle,
    a: BufferHandle,
    b: BufferHandle,
    count: usize,
) -> Result<(), BackendError> {
    let len = clamp_len(backend, &[dst, a, b], count)?;
    let mut a_buf = vec![0u8; len];
    let mut b_buf = vec![0u8; len];
    backend.copy_from_buffer(a, &mut a_buf)?;
    backend.copy_from_buffer(b, &mut b_buf)?;

    let mut out = vec![0u8; len];
    for i in 0..len {
        out[i] = a_buf[i].wrapping_mul(b_buf[i]);
    }
    backend.copy_to_buffer(dst, &out)
}

/// CPU-backed matrix multiplication fallback.
pub fn matmul<B: ProgramBackend + ?Sized>(
    backend: &B,
    c: BufferHandle,
    a: BufferHandle,
    b: BufferHandle,
    params: &MatMulParams,
) -> Result<(), BackendError> {
    if params.dtype != Type::F32 {
        return Err(BackendError::unsupported(format!(
            "matmul only supports F32 fallback, got {:?}",
            params.dtype
        )));
    }

    let a_elements = (params.m * params.k) as usize;
    let b_elements = (params.k * params.n) as usize;
    let c_elements = (params.m * params.n) as usize;

    let a_data = read_f32_buffer(backend, a, a_elements)?;
    let b_data = read_f32_buffer(backend, b, b_elements)?;
    let mut c_data = read_f32_buffer(backend, c, c_elements)?;

    cpu_matmul_f32(&mut c_data, &a_data, &b_data, params);
    write_f32_buffer(backend, c, &c_data)
}

/// CPU-backed batched matrix multiplication fallback.
pub fn batch_matmul<B: ProgramBackend + ?Sized>(
    backend: &B,
    c: BufferHandle,
    a: BufferHandle,
    b: BufferHandle,
    batch: u32,
    params: &MatMulParams,
) -> Result<(), BackendError> {
    if params.dtype != Type::F32 {
        return Err(BackendError::unsupported(format!(
            "batch_matmul only supports F32 fallback, got {:?}",
            params.dtype
        )));
    }

    let batch = batch as usize;
    let a_elements = batch * (params.m * params.k) as usize;
    let b_elements = batch * (params.k * params.n) as usize;
    let c_elements = batch * (params.m * params.n) as usize;

    let a_data = read_f32_buffer(backend, a, a_elements)?;
    let b_data = read_f32_buffer(backend, b, b_elements)?;
    let mut c_data = read_f32_buffer(backend, c, c_elements)?;

    cpu_batch_matmul_f32(&mut c_data, &a_data, &b_data, batch, params);
    write_f32_buffer(backend, c, &c_data)
}

/// CPU-backed 2D convolution fallback.
pub fn conv2d<B: ProgramBackend + ?Sized>(
    backend: &B,
    output: BufferHandle,
    input: BufferHandle,
    kernel: BufferHandle,
    bias: BufferHandle,
    params: &Conv2DParams,
) -> Result<(), BackendError> {
    if params.dtype != Type::F32 {
        return Err(BackendError::unsupported(format!(
            "conv2d only supports F32 fallback, got {:?}",
            params.dtype
        )));
    }

    let input_elements = product(&params.input_dims);
    let kernel_elements = product(&params.kernel_dims);
    let bias_elements = params.kernel_dims[0] as usize;
    let output_elements = product(&params.output_dims());

    let input_data = read_f32_buffer(backend, input, input_elements)?;
    let kernel_data = read_f32_buffer(backend, kernel, kernel_elements)?;
    let bias_data = maybe_read_f32_buffer(backend, bias, bias_elements)?;
    let mut output_data = vec![0.0f32; output_elements];

    cpu_conv2d_f32(
        &mut output_data,
        &input_data,
        &kernel_data,
        bias_data.as_deref(),
        params,
    );

    write_f32_buffer(backend, output, &output_data)
}

/// CPU-backed depthwise convolution fallback.
pub fn depthwise_conv2d<B: ProgramBackend + ?Sized>(
    backend: &B,
    output: BufferHandle,
    input: BufferHandle,
    kernel: BufferHandle,
    bias: BufferHandle,
    params: &DepthwiseConv2DParams,
) -> Result<(), BackendError> {
    if params.dtype != Type::F32 {
        return Err(BackendError::unsupported(format!(
            "depthwise_conv2d only supports F32 fallback, got {:?}",
            params.dtype
        )));
    }

    let input_elements = product(&params.input_dims);
    let kernel_elements = product(&params.kernel_dims);
    let bias_elements = params.output_channels() as usize;
    let output_elements = product(&params.output_dims());

    let input_data = read_f32_buffer(backend, input, input_elements)?;
    let kernel_data = read_f32_buffer(backend, kernel, kernel_elements)?;
    let bias_data = maybe_read_f32_buffer(backend, bias, bias_elements)?;
    let mut output_data = vec![0.0f32; output_elements];

    depthwise_conv2d_f32(
        &mut output_data,
        &input_data,
        &kernel_data,
        bias_data.as_deref(),
        params,
    )?;

    write_f32_buffer(backend, output, &output_data)
}

/// CPU-backed pointwise convolution fallback.
pub fn pointwise_conv<B: ProgramBackend + ?Sized>(
    backend: &B,
    output: BufferHandle,
    input: BufferHandle,
    kernel: BufferHandle,
    bias: BufferHandle,
    params: &PointwiseConvParams,
) -> Result<(), BackendError> {
    if params.dtype != Type::F32 {
        return Err(BackendError::unsupported(format!(
            "pointwise_conv only supports F32 fallback, got {:?}",
            params.dtype
        )));
    }

    let input_elements = product(&params.input_dims);
    let kernel_elements = (params.input_channels() * params.out_channels) as usize;
    let bias_elements = params.out_channels as usize;
    let output_elements = product(&params.output_dims());

    let input_data = read_f32_buffer(backend, input, input_elements)?;
    let kernel_data = read_f32_buffer(backend, kernel, kernel_elements)?;
    let bias_data = maybe_read_f32_buffer(backend, bias, bias_elements)?;
    let mut output_data = vec![0.0f32; output_elements];

    pointwise_conv_f32(
        &mut output_data,
        &input_data,
        &kernel_data,
        bias_data.as_deref(),
        params,
    )?;

    write_f32_buffer(backend, output, &output_data)
}

/// CPU-backed grouped convolution fallback.
pub fn grouped_conv2d<B: ProgramBackend + ?Sized>(
    backend: &B,
    output: BufferHandle,
    input: BufferHandle,
    kernel: BufferHandle,
    bias: BufferHandle,
    params: &GroupedConv2DParams,
) -> Result<(), BackendError> {
    if params.dtype != Type::F32 {
        return Err(BackendError::unsupported(format!(
            "grouped_conv2d only supports F32 fallback, got {:?}",
            params.dtype
        )));
    }

    let input_elements = product(&params.input_dims);
    let kernel_elements = product(&params.kernel_dims);
    let bias_elements = params.kernel_dims[0] as usize;
    let output_elements = product(&params.output_dims());

    let input_data = read_f32_buffer(backend, input, input_elements)?;
    let kernel_data = read_f32_buffer(backend, kernel, kernel_elements)?;
    let bias_data = maybe_read_f32_buffer(backend, bias, bias_elements)?;
    let mut output_data = vec![0.0f32; output_elements];

    grouped_conv2d_f32(
        &mut output_data,
        &input_data,
        &kernel_data,
        bias_data.as_deref(),
        params,
    )?;

    write_f32_buffer(backend, output, &output_data)
}

/// CPU-backed aspect-aware matmul fallback.
pub fn aspect_aware_matmul<B: ProgramBackend + ?Sized>(
    backend: &B,
    c: BufferHandle,
    a: BufferHandle,
    b: BufferHandle,
    params: &AspectAwareMatMulParams,
) -> Result<(), BackendError> {
    if params.base.dtype != Type::F32 {
        return Err(BackendError::unsupported(format!(
            "aspect_aware_matmul only supports F32 fallback, got {:?}",
            params.base.dtype
        )));
    }

    let a_elements = (params.base.m * params.base.k) as usize;
    let b_elements = (params.base.k * params.base.n) as usize;
    let c_elements = (params.base.m * params.base.n) as usize;

    let a_data = read_f32_buffer(backend, a, a_elements)?;
    let b_data = read_f32_buffer(backend, b, b_elements)?;
    let mut c_data = read_f32_buffer(backend, c, c_elements)?;

    aspect_aware_matmul_f32(&mut c_data, &a_data, &b_data, params)?;
    write_f32_buffer(backend, c, &c_data)
}
