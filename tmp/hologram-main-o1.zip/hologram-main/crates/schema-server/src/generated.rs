//! Generated query-layer resolvers and DTOs.
//!
//! Auto-generated from `descriptors/shells/{datum,ring,activation,observable}.shell`.
//! See `specs/research/shell-dsl-isa-codegen.md` for the code generation pipeline.

#![allow(dead_code)]

include!(concat!(env!("OUT_DIR"), "/generated_query.rs"));
