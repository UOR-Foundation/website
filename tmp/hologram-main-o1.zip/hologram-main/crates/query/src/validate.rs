//! Query validation against generated schema.
//!
//! Checks that field names, argument types, and root selections map to
//! known generated types.

use crate::ast::*;
use crate::generated::{ActivationDto, ByteDto, ElementDto, PathDto};

/// Root-level domain names mapped to validation rules.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DomainType {
    Byte,
    Ring,
    Activation,
    Observable,
}

impl DomainType {
    fn from_name(name: &str) -> Option<Self> {
        match name {
            "byte" | "byteRange" => Some(Self::Byte),
            "ring" | "ringRange" => Some(Self::Ring),
            "activation" | "activationRange" => Some(Self::Activation),
            "observable" | "path" => Some(Self::Observable),
            _ => None,
        }
    }

    fn is_range(name: &str) -> bool {
        matches!(name, "byteRange" | "ringRange" | "activationRange")
    }

    fn is_observable(name: &str) -> bool {
        matches!(name, "observable" | "path")
    }

    fn fields(self) -> &'static [&'static str] {
        match self {
            Self::Byte => ByteDto::FIELDS,
            Self::Ring => ElementDto::FIELDS,
            Self::Activation => ActivationDto::FIELDS,
            Self::Observable => PathDto::FIELDS,
        }
    }

    fn param_fields(self) -> &'static [&'static str] {
        match self {
            Self::Byte => ByteDto::PARAM_FIELDS,
            Self::Ring => ElementDto::PARAM_FIELDS,
            Self::Activation => ActivationDto::PARAM_FIELDS,
            Self::Observable => PathDto::PARAM_FIELDS,
        }
    }
}

/// Validation error.
#[derive(Debug, thiserror::Error)]
pub enum ValidateError {
    #[error("unknown root type: {0}")]
    UnknownRoot(String),
    #[error("missing required argument 'value' on {0}")]
    MissingValue(String),
    #[error("argument 'value' must be an integer on {0}")]
    ValueNotInt(String),
    #[error("unknown field '{field}' on type '{domain}'")]
    UnknownField { domain: String, field: String },
    #[error("field '{field}' requires arguments on '{domain}'")]
    MissingArgs { domain: String, field: String },
    #[error("missing required argument '{arg}' on {domain}")]
    MissingArg { domain: String, arg: String },
    #[error("argument '{arg}' must be an integer on {domain}")]
    ArgNotInt { domain: String, arg: String },
    #[error("mutation root must be 'translate', got '{0}'")]
    InvalidMutationRoot(String),
    #[error("translate missing required argument: {0}")]
    TranslateMissingArg(String),
}

/// Validate a parsed document against the generated schema.
pub fn validate(doc: &Document) -> Result<(), ValidateError> {
    match doc.op {
        OpType::Query => validate_query(&doc.selections),
        OpType::Mutation => validate_mutation(&doc.selections),
    }
}

fn validate_query(selections: &[Selection]) -> Result<(), ValidateError> {
    for sel in selections {
        let domain = DomainType::from_name(&sel.field)
            .ok_or_else(|| ValidateError::UnknownRoot(sel.field.clone()))?;

        if DomainType::is_range(&sel.field) {
            validate_range_args(sel)?;
        } else if DomainType::is_observable(&sel.field) {
            validate_observable_args(sel)?;
        } else {
            validate_value_arg(sel)?;
        }
        validate_children(&sel.field, domain, &sel.children)?;
    }
    Ok(())
}

fn validate_observable_args(sel: &Selection) -> Result<(), ValidateError> {
    // Observable requires `path` (list) and `quantum` (int)
    let has_path = sel.arguments.iter().any(|(n, _)| n == "path");
    if !has_path {
        return Err(ValidateError::MissingArg {
            domain: sel.field.clone(),
            arg: "path".to_string(),
        });
    }
    let has_quantum = sel.arguments.iter().any(|(n, _)| n == "quantum");
    if !has_quantum {
        return Err(ValidateError::MissingArg {
            domain: sel.field.clone(),
            arg: "quantum".to_string(),
        });
    }
    Ok(())
}

fn validate_value_arg(sel: &Selection) -> Result<(), ValidateError> {
    let value_arg = sel.arguments.iter().find(|(name, _)| name == "value");
    match value_arg {
        None => Err(ValidateError::MissingValue(sel.field.clone())),
        Some((_, QueryValue::Int(_))) => Ok(()),
        Some(_) => Err(ValidateError::ValueNotInt(sel.field.clone())),
    }
}

fn validate_range_args(sel: &Selection) -> Result<(), ValidateError> {
    for arg_name in ["from", "to"] {
        let arg = sel.arguments.iter().find(|(name, _)| name == arg_name);
        match arg {
            None => {
                return Err(ValidateError::MissingArg {
                    domain: sel.field.clone(),
                    arg: arg_name.to_string(),
                })
            }
            Some((_, QueryValue::Int(_))) => {}
            Some(_) => {
                return Err(ValidateError::ArgNotInt {
                    domain: sel.field.clone(),
                    arg: arg_name.to_string(),
                })
            }
        }
    }
    Ok(())
}

fn validate_children(
    domain_name: &str,
    domain: DomainType,
    children: &[Selection],
) -> Result<(), ValidateError> {
    let fields = domain.fields();
    let param_fields = domain.param_fields();

    for child in children {
        // Check if it's a nested group (like `torus { page, offset }`)
        let has_children = !child.children.is_empty();
        if has_children {
            // Validate nested children with dot-notation
            for nested in &child.children {
                let dot_name = format!("{}.{}", child.field, nested.field);
                if !fields.contains(&dot_name.as_str()) {
                    return Err(ValidateError::UnknownField {
                        domain: domain_name.to_string(),
                        field: dot_name,
                    });
                }
            }
            continue;
        }

        let name = &child.field;
        let is_simple = fields.contains(&name.as_str());
        let is_param = param_fields.contains(&name.as_str());

        if !is_simple && !is_param {
            return Err(ValidateError::UnknownField {
                domain: domain_name.to_string(),
                field: name.clone(),
            });
        }

        if is_param && child.arguments.is_empty() {
            return Err(ValidateError::MissingArgs {
                domain: domain_name.to_string(),
                field: name.clone(),
            });
        }
    }
    Ok(())
}

fn validate_mutation(selections: &[Selection]) -> Result<(), ValidateError> {
    for sel in selections {
        match sel.field.as_str() {
            "translate" => {
                for required in ["domain", "value", "op", "by"] {
                    if !sel.arguments.iter().any(|(n, _)| n == required) {
                        return Err(ValidateError::TranslateMissingArg(required.to_string()));
                    }
                }
            }
            "pipeline" | "chain" => {
                if !sel.arguments.iter().any(|(n, _)| n == "value") {
                    return Err(ValidateError::TranslateMissingArg("value".to_string()));
                }
            }
            "translateWhere" => {
                for required in ["from", "to", "op", "by"] {
                    if !sel.arguments.iter().any(|(n, _)| n == required) {
                        return Err(ValidateError::TranslateMissingArg(required.to_string()));
                    }
                }
            }
            _ => return Err(ValidateError::InvalidMutationRoot(sel.field.clone())),
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parse::parse;

    #[test]
    fn valid_byte_query() {
        let doc = parse("query { byte(value: 42) { stratum, curvature } }").unwrap();
        validate(&doc).unwrap();
    }

    #[test]
    fn valid_ring_query() {
        let doc = parse("query { ring(value: 10) { add(other: 5) } }").unwrap();
        validate(&doc).unwrap();
    }

    #[test]
    fn valid_activation_query() {
        let doc = parse("query { activation(value: 128) { sigmoid, relu } }").unwrap();
        validate(&doc).unwrap();
    }

    #[test]
    fn valid_mutation() {
        let doc = parse(
            "mutation { translate(domain: byte, value: 42, op: add, by: 10) { value, stratum } }",
        )
        .unwrap();
        validate(&doc).unwrap();
    }

    #[test]
    fn unknown_root_type() {
        let doc = parse("query { foo(value: 1) { bar } }").unwrap();
        let err = validate(&doc).unwrap_err();
        assert!(err.to_string().contains("unknown root type: foo"));
    }

    #[test]
    fn missing_value_arg() {
        let doc = parse("query { byte(name: 1) { stratum } }").unwrap();
        let err = validate(&doc).unwrap_err();
        assert!(err
            .to_string()
            .contains("missing required argument 'value'"));
    }

    #[test]
    fn unknown_field() {
        let doc = parse("query { byte(value: 1) { nonexistent } }").unwrap();
        let err = validate(&doc).unwrap_err();
        assert!(err.to_string().contains("unknown field"));
    }

    #[test]
    fn param_field_missing_args() {
        let doc = parse("query { ring(value: 1) { add } }").unwrap();
        let err = validate(&doc).unwrap_err();
        assert!(err.to_string().contains("requires arguments"));
    }

    #[test]
    fn mutation_invalid_root() {
        let doc = parse("mutation { foo(domain: byte, value: 1, op: add, by: 1) { x } }").unwrap();
        let err = validate(&doc).unwrap_err();
        assert!(err.to_string().contains("must be 'translate'"));
    }

    #[test]
    fn mutation_missing_arg() {
        let doc = parse("mutation { translate(domain: byte, value: 42) { stratum } }").unwrap();
        let err = validate(&doc).unwrap_err();
        assert!(err.to_string().contains("missing required argument"));
    }

    #[test]
    fn nested_torus_valid() {
        let doc = parse("query { byte(value: 0) { torus { page, offset } } }").unwrap();
        validate(&doc).unwrap();
    }

    // Range query tests

    #[test]
    fn valid_byte_range() {
        let doc = parse("query { byteRange(from: 0, to: 7) { stratum, curvature } }").unwrap();
        validate(&doc).unwrap();
    }

    #[test]
    fn valid_ring_range() {
        let doc = parse("query { ringRange(from: 0, to: 10) { add(other: 5) } }").unwrap();
        validate(&doc).unwrap();
    }

    #[test]
    fn valid_activation_range() {
        let doc = parse("query { activationRange(from: 0, to: 255) { sigmoid, relu } }").unwrap();
        validate(&doc).unwrap();
    }

    #[test]
    fn range_missing_from() {
        let doc = parse("query { byteRange(to: 7) { stratum } }").unwrap();
        let err = validate(&doc).unwrap_err();
        assert!(err.to_string().contains("missing required argument 'from'"));
    }

    #[test]
    fn range_missing_to() {
        let doc = parse("query { byteRange(from: 0) { stratum } }").unwrap();
        let err = validate(&doc).unwrap_err();
        assert!(err.to_string().contains("missing required argument 'to'"));
    }

    #[test]
    fn range_with_nested_torus() {
        let doc = parse("query { byteRange(from: 0, to: 3) { torus { page, offset } } }").unwrap();
        validate(&doc).unwrap();
    }

    // Observable validation tests

    #[test]
    fn valid_observable_query() {
        let doc =
            parse("query { observable(path: [1, 2, 3], quantum: 8) { winding, total_variation } }")
                .unwrap();
        validate(&doc).unwrap();
    }

    #[test]
    fn observable_missing_path() {
        let doc = parse("query { observable(quantum: 8) { winding } }").unwrap();
        let err = validate(&doc).unwrap_err();
        assert!(err.to_string().contains("path"));
    }

    #[test]
    fn observable_missing_quantum() {
        let doc = parse("query { observable(path: [1, 2]) { winding } }").unwrap();
        let err = validate(&doc).unwrap_err();
        assert!(err.to_string().contains("quantum"));
    }
}
