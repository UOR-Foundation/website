//! Streaming executor for parallel execution of execution groups.
//!
//! This module provides [`StreamingExecutor`] for executing computation graphs
//! with parallel execution groups. It enables:
//!
//! - **Parallel execution**: Groups at the same level run concurrently
//! - **Memory prefetching**: OS-level prefetch hints for upcoming groups
//! - **Memory release**: Release pages after group completion
//! - **Low-memory mode**: Layer-by-layer execution for large models
//!
//! # Design
//!
//! The executor takes a compiled graph with execution groups and runs
//! groups in parallel based on their dependency levels:
//!
//! ```text
//! Level 0: [input_group]              → Execute first
//! Level 1: [Q_group, K_group, V_group] → Execute in parallel (3 threads)
//! Level 2: [attention_group]           → Execute after Level 1 completes
//! ```
//!
//! # Example
//!
//! ```rust,ignore
//! use hologram_backend::streaming_executor::StreamingExecutor;
//!
//! // Create executor with parallel levels
//! let executor = StreamingExecutor::new(sub_executors, group_levels, &backend)?;
//!
//! // Execute with automatic parallelization (thread-safe backend)
//! executor.execute(&inputs, &outputs, &backend)?;
//! ```

use crate::error::{BackendError, BackendResult};
use crate::executor::PlanExecutor;
use crate::plan::BackendPlan;
use crate::traits::ProgramBackend;
use crate::BufferHandle;
use rayon::prelude::*;
use std::sync::Mutex;

/// Execution group metadata.
#[derive(Debug, Clone)]
pub struct ExecutionGroupInfo {
    /// Group identifier.
    pub id: u64,
    /// Index of the sub-executor for this group.
    pub executor_idx: usize,
    /// Names of input buffers this group needs.
    pub input_names: Vec<String>,
    /// Names of output buffers this group produces.
    pub output_names: Vec<String>,
}

/// Streaming executor for parallel group execution.
///
/// This executor manages multiple sub-plans (one per execution group)
/// and runs them in parallel based on dependency levels. Groups within
/// the same level have no dependencies on each other and execute
/// concurrently using rayon's thread pool.
pub struct StreamingExecutor {
    /// Sub-executors for each group (indexed by group ID).
    /// Each executor has its own workspace, enabling parallel execution.
    executors: Vec<Mutex<PlanExecutor>>,
    /// Execution levels: each level contains groups that can run in parallel.
    levels: Vec<Vec<ExecutionGroupInfo>>,
    /// Whether prefetching is enabled.
    prefetch_enabled: bool,
    /// Whether to release memory after group completion.
    release_enabled: bool,
    /// Execution statistics (Mutex for thread-safe updates during parallel execution).
    stats: Mutex<StreamingStats>,
}

/// Statistics for streaming execution.
#[derive(Debug, Clone, Default)]
pub struct StreamingStats {
    /// Total execution time in nanoseconds.
    pub total_ns: u64,
    /// Time spent per level in nanoseconds.
    pub level_times_ns: Vec<u64>,
    /// Maximum concurrent groups executed.
    pub max_concurrent_groups: usize,
    /// Number of groups executed.
    pub groups_executed: usize,
}

impl StreamingExecutor {
    /// Create a new streaming executor.
    ///
    /// # Arguments
    ///
    /// * `plans` - Backend plans for each execution group
    /// * `levels` - Execution levels (groups at same level run in parallel)
    /// * `backend` - Backend to allocate workspaces
    ///
    /// # Returns
    ///
    /// A new streaming executor ready for parallel execution.
    pub fn new(
        plans: Vec<BackendPlan>,
        levels: Vec<Vec<ExecutionGroupInfo>>,
        backend: &dyn ProgramBackend,
    ) -> BackendResult<Self> {
        // Create executors for each plan
        let executors: Result<Vec<_>, _> = plans
            .into_iter()
            .map(|plan| {
                let executor = PlanExecutor::new(plan, backend)?;
                Ok(Mutex::new(executor))
            })
            .collect();

        let executors = executors?;

        // Calculate max concurrent groups
        let max_concurrent = levels.iter().map(|l| l.len()).max().unwrap_or(0);

        tracing::info!(
            "StreamingExecutor created: {} executors, {} levels, max {} concurrent groups",
            executors.len(),
            levels.len(),
            max_concurrent
        );

        Ok(Self {
            executors,
            levels,
            prefetch_enabled: true,
            release_enabled: true,
            stats: Mutex::new(StreamingStats {
                max_concurrent_groups: max_concurrent,
                ..Default::default()
            }),
        })
    }

    /// Enable or disable prefetching.
    pub fn set_prefetch(&mut self, enabled: bool) {
        self.prefetch_enabled = enabled;
    }

    /// Enable or disable memory release after group completion.
    pub fn set_release(&mut self, enabled: bool) {
        self.release_enabled = enabled;
    }

    /// Get execution statistics.
    ///
    /// Returns a clone of the current statistics. Thread-safe.
    pub fn stats(&self) -> StreamingStats {
        self.stats.lock().map(|s| s.clone()).unwrap_or_default()
    }

    /// Execute all groups with parallel execution at each level.
    ///
    /// Groups within the same level execute in parallel using rayon.
    /// The executor waits for all groups in a level to complete before
    /// moving to the next level.
    ///
    /// # Arguments
    ///
    /// * `inputs` - Input buffer handles
    /// * `outputs` - Output buffer handles
    /// * `backend` - Backend to execute on (thread-safe via interior mutability)
    pub fn execute(
        &self,
        inputs: &[BufferHandle],
        outputs: &[BufferHandle],
        backend: &dyn ProgramBackend,
    ) -> BackendResult<()> {
        let start = std::time::Instant::now();
        let mut level_times = Vec::with_capacity(self.levels.len());
        let mut groups_executed = 0;

        for (level_idx, level) in self.levels.iter().enumerate() {
            let level_start = std::time::Instant::now();

            // Prefetch next level if enabled
            if self.prefetch_enabled && level_idx + 1 < self.levels.len() {
                self.prefetch_level(level_idx + 1);
            }

            // Execute all groups in this level in parallel
            if level.len() == 1 {
                // Single group - no parallelism needed
                let group = &level[0];
                self.execute_group(group, inputs, outputs, backend)?;
            } else {
                // Multiple groups - execute in parallel using rayon
                self.execute_level_parallel(level, inputs, outputs, backend)?;
            }

            groups_executed += level.len();

            // Release previous level's memory if enabled
            if self.release_enabled && level_idx > 0 {
                self.release_level(level_idx - 1);
            }

            level_times.push(level_start.elapsed().as_nanos() as u64);

            tracing::debug!(
                "Level {} completed: {} groups in {:?}",
                level_idx,
                level.len(),
                level_start.elapsed()
            );
        }

        // Update stats thread-safely
        if let Ok(mut stats) = self.stats.lock() {
            stats.total_ns = start.elapsed().as_nanos() as u64;
            stats.level_times_ns = level_times;
            stats.groups_executed = groups_executed;
        }

        tracing::info!(
            "StreamingExecutor completed: {} groups in {:?}",
            groups_executed,
            start.elapsed()
        );

        Ok(())
    }

    /// Execute a single group.
    ///
    /// Each group has a dedicated executor with its own workspace, so groups
    /// can execute concurrently without conflicts.
    fn execute_group(
        &self,
        group: &ExecutionGroupInfo,
        inputs: &[BufferHandle],
        outputs: &[BufferHandle],
        backend: &dyn ProgramBackend,
    ) -> BackendResult<()> {
        let mut executor = self.executors[group.executor_idx]
            .lock()
            .map_err(|_| BackendError::buffer("Failed to lock executor"))?;

        executor.execute(inputs, outputs, backend)
    }

    /// Execute a level with multiple groups in parallel using rayon.
    ///
    /// Groups within a level have no dependencies on each other by construction.
    /// Each group has a dedicated executor with its own workspace, and the backend
    /// uses interior mutability for thread-safe buffer access. This enables true
    /// parallel execution across CPU cores.
    fn execute_level_parallel(
        &self,
        level: &[ExecutionGroupInfo],
        inputs: &[BufferHandle],
        outputs: &[BufferHandle],
        backend: &dyn ProgramBackend,
    ) -> BackendResult<()> {
        level
            .par_iter()
            .try_for_each(|group| self.execute_group(group, inputs, outputs, backend))
    }

    /// Prefetch the next level's data.
    fn prefetch_level(&self, level_idx: usize) {
        if level_idx >= self.levels.len() {
            return;
        }

        // Use madvise(MADV_WILLNEED) to hint to OS about upcoming memory access
        // This is a no-op on platforms that don't support it
        for group in &self.levels[level_idx] {
            if let Ok(executor) = self.executors[group.executor_idx].lock() {
                if let Some(workspace) = executor.workspace() {
                    // Advise the OS that we'll need this memory soon
                    let size = workspace.total_size();
                    if size > 0 && !workspace.is_null() {
                        #[cfg(unix)]
                        unsafe {
                            // Get the raw pointer from a zero-offset region
                            let ptr = workspace.region_ptr(0);
                            if !ptr.is_null() {
                                libc::madvise(ptr as *mut libc::c_void, size, libc::MADV_WILLNEED);
                            }
                        }
                    }
                }
            }
        }

        tracing::trace!("Prefetched level {}", level_idx);
    }

    /// Release a level's memory back to OS.
    fn release_level(&self, level_idx: usize) {
        if level_idx >= self.levels.len() {
            return;
        }

        // Use madvise(MADV_DONTNEED) to tell OS we don't need these pages
        // This allows the OS to reclaim memory without actual deallocation
        for group in &self.levels[level_idx] {
            if let Ok(executor) = self.executors[group.executor_idx].lock() {
                if let Some(workspace) = executor.workspace() {
                    let size = workspace.total_size();
                    if size > 0 && !workspace.is_null() {
                        #[cfg(unix)]
                        unsafe {
                            let ptr = workspace.region_ptr(0);
                            if !ptr.is_null() {
                                libc::madvise(ptr as *mut libc::c_void, size, libc::MADV_DONTNEED);
                            }
                        }
                    }
                }
            }
        }

        tracing::trace!("Released level {}", level_idx);
    }
}

/// Builder for creating streaming executors from IR graphs.
pub struct StreamingExecutorBuilder {
    /// Execution levels from IR graph.
    levels: Vec<Vec<u64>>,
    /// Group dependencies.
    dependencies: Vec<(u64, u64)>,
}

impl StreamingExecutorBuilder {
    /// Create a new builder.
    pub fn new() -> Self {
        Self {
            levels: Vec::new(),
            dependencies: Vec::new(),
        }
    }

    /// Set execution levels from parallel_groups() output.
    pub fn with_levels(mut self, levels: Vec<Vec<u64>>) -> Self {
        self.levels = levels;
        self
    }

    /// Add group dependencies.
    pub fn with_dependencies(mut self, deps: Vec<(u64, u64)>) -> Self {
        self.dependencies = deps;
        self
    }

    /// Build the streaming executor.
    ///
    /// # Arguments
    ///
    /// * `plans` - Backend plans indexed by group ID
    /// * `backend` - Backend for workspace allocation
    pub fn build(
        self,
        plans: Vec<BackendPlan>,
        backend: &dyn ProgramBackend,
    ) -> BackendResult<StreamingExecutor> {
        // Convert levels to ExecutionGroupInfo
        let levels: Vec<Vec<ExecutionGroupInfo>> = self
            .levels
            .into_iter()
            .map(|level| {
                level
                    .into_iter()
                    .map(|group_id| ExecutionGroupInfo {
                        id: group_id,
                        executor_idx: group_id as usize,
                        input_names: Vec::new(),
                        output_names: Vec::new(),
                    })
                    .collect()
            })
            .collect();

        StreamingExecutor::new(plans, levels, backend)
    }
}

impl Default for StreamingExecutorBuilder {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_streaming_stats_default() {
        let stats = StreamingStats::default();
        assert_eq!(stats.total_ns, 0);
        assert_eq!(stats.groups_executed, 0);
    }

    #[test]
    fn test_execution_group_info() {
        let info = ExecutionGroupInfo {
            id: 1,
            executor_idx: 0,
            input_names: vec!["input".to_string()],
            output_names: vec!["output".to_string()],
        };
        assert_eq!(info.id, 1);
        assert_eq!(info.executor_idx, 0);
    }

    #[test]
    fn test_builder_creation() {
        let builder = StreamingExecutorBuilder::new()
            .with_levels(vec![vec![0], vec![1, 2, 3], vec![4]])
            .with_dependencies(vec![(1, 0), (2, 0), (3, 0), (4, 1), (4, 2), (4, 3)]);

        assert_eq!(builder.levels.len(), 3);
        assert_eq!(builder.dependencies.len(), 6);
    }
}
