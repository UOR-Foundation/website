//! UOR FFI: High-performance foreign function interface for Universal Object Reference.
//!
//! This crate provides zero-overhead FFI bindings via:
//!
//! - **C bindings** (cbindgen): ~1-2ns overhead
//!   - Direct use from C/C++
//!   - Python via ctypes (~50-100ns)
//!   - Swift via module.modulemap (~5-10ns)
//! - **WASM bindings** (wasm-bindgen): ~5ns overhead
//!   - Browser, Deno, Node.js
//!   - TypeScript with full type safety
//!
//! # API Surface
//!
//! The FFI exposes core UOR functionality:
//! - Taxon operations (byte identity, domain, rank)
//! - State management (624 taxons = 4992 bits)
//! - ElementWiseView (256-byte lookup tables)
//! - Ring operations (successor, predecessor, bitwise NOT)
//!
//! # Build Examples
//!
//! ```bash
//! # C bindings - generates header file
//! cargo build -p uor-ffi --release
//! cbindgen crates/ffi --output bindings/c/uor.h
//!
//! # WASM - generates TypeScript/npm package
//! wasm-pack build --target web --features wasm crates/ffi --out-dir bindings/typescript/pkg
//!
//! # Python - uses ctypes to load C bindings
//! # Swift - uses module.modulemap to import C bindings
//! ```
#![cfg_attr(feature = "uniffi", allow(clippy::empty_line_after_doc_comments))]

// Core FFI implementation
mod core;

// C bindings (always enabled, zero-overhead)
pub mod c;

// LUT wrappers (Q0 observables and activation functions)
pub mod lut;

// Word type wrappers (Word2, Word4, Word8)
pub mod word;

// Datum16 and derivation proof wrappers
pub mod datum;

// Codec registry (available in all builds)
pub mod codec;

// Re-export core functions for direct use
pub use core::{
    braille_base, braille_max, byte_not, byte_pred, byte_rank, byte_succ, byte_to_braille,
    byte_to_codepoint, byte_to_domain, octave_constant, state_bits, state_taxons, triadic_constant,
    FfiDomain, FfiError, FfiState, FfiTaxon, FfiView,
};

// Re-export LUT functions
pub use lut::{
    abs_lut, curvature_q0, curvature_q1, domain_q0, exp_lut, gelu_lut, log_lut, orbit_class_q0,
    rank_q0, relu_lut, sigmoid_lut, silu_lut, sqrt_lut, stratum_q0, stratum_q1, tanh_lut,
    torus_offset_q0, torus_page_q0,
};

// Re-export Word types
pub use word::{FfiWord2, FfiWord4, FfiWord8};

// Re-export Datum types
pub use datum::{FfiDatum16, FfiDatum16Proof};
