//! Weight index section for partial tensor loading.
//!
//! This module provides a section type that indexes weight tensors within a
//! `.holb` bundle, enabling partial/lazy loading of specific tensors without
//! reading the entire weights blob.
//!
//! # Example
//!
//! ```rust
//! use hologram_holo::weight_index::WeightIndexSection;
//! use hologram_holo::weight_types::{TensorMetadata, WeightDType};
//!
//! let mut index = WeightIndexSection::new();
//!
//! let tensor = TensorMetadata::builder()
//!     .name("encoder.weight")
//!     .shape(vec![768, 512])
//!     .dtype(WeightDType::F32)
//!     .offset(0)
//!     .size(768 * 512 * 4)
//!     .build()
//!     .unwrap();
//!
//! index.add_tensor(tensor);
//!
//! assert!(index.get_tensor("encoder.weight").is_some());
//! assert!(index.get_tensor("nonexistent").is_none());
//! ```

use rkyv::{Archive, Deserialize, Serialize};

use crate::compression::CompressionMetadata;
use crate::traits::{EmbeddableSection, FromEmbeddedSection};
use crate::weight_types::TensorMetadata;
use crate::{HoloError, Result};

// ============================================================================
// Weight Index Section
// ============================================================================

/// Section containing the weight index for partial tensor loading.
///
/// This section maps tensor names to their offsets and metadata within
/// the weights blob, enabling:
/// - Partial loading of specific tensors
/// - Tensor metadata queries without decompression
/// - Efficient lookup by name
#[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct WeightIndexSection {
    /// All tensor metadata entries
    pub tensors: Vec<TensorMetadata>,
    /// Optional compression metadata (if weights are compressed)
    pub compression: Option<CompressionMetadata>,
}

impl WeightIndexSection {
    /// Section identifier for embedding in bundles.
    pub const SECTION_ID: &'static str = "weight_index";

    /// Content type for weight index sections.
    pub const CONTENT_TYPE: &'static str = "application/vnd.hologram.weight-index";

    /// Current format version.
    pub const VERSION: u32 = 1;

    /// Create an empty weight index section.
    #[must_use]
    pub fn new() -> Self {
        Self {
            tensors: Vec::new(),
            compression: None,
        }
    }

    /// Create a weight index section with tensors.
    #[must_use]
    pub fn with_tensors(tensors: Vec<TensorMetadata>) -> Self {
        Self {
            tensors,
            compression: None,
        }
    }

    /// Add a tensor to the index.
    pub fn add_tensor(&mut self, metadata: TensorMetadata) {
        self.tensors.push(metadata);
    }

    /// Set compression metadata.
    pub fn set_compression(&mut self, compression: CompressionMetadata) {
        self.compression = Some(compression);
    }

    /// Get a tensor by name.
    #[must_use]
    pub fn get_tensor(&self, name: &str) -> Option<&TensorMetadata> {
        self.tensors.iter().find(|t| t.name == name)
    }

    /// Get a mutable tensor reference by name.
    #[must_use]
    pub fn get_tensor_mut(&mut self, name: &str) -> Option<&mut TensorMetadata> {
        self.tensors.iter_mut().find(|t| t.name == name)
    }

    /// Find tensor index by name.
    #[must_use]
    pub fn find_tensor_index(&self, name: &str) -> Option<usize> {
        self.tensors.iter().position(|t| t.name == name)
    }

    /// Get the number of tensors in the index.
    #[must_use]
    pub fn len(&self) -> usize {
        self.tensors.len()
    }

    /// Check if the index is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.tensors.is_empty()
    }

    /// Check if weights are compressed.
    #[must_use]
    pub fn is_compressed(&self) -> bool {
        self.compression
            .as_ref()
            .is_some_and(|c| c.algorithm != crate::compression::CompressionAlgorithm::None)
    }

    /// Iterate over all tensors.
    pub fn iter(&self) -> impl Iterator<Item = &TensorMetadata> {
        self.tensors.iter()
    }

    /// Get all tensor names.
    #[must_use]
    pub fn tensor_names(&self) -> Vec<&str> {
        self.tensors.iter().map(|t| t.name.as_str()).collect()
    }

    /// Calculate total uncompressed size of all tensors.
    #[must_use]
    pub fn total_size(&self) -> u64 {
        self.tensors.iter().map(|t| t.size).sum()
    }

    /// Sort tensors by offset for efficient sequential access.
    pub fn sort_by_offset(&mut self) {
        self.tensors.sort_by_key(|t| t.offset);
    }

    /// Validate the index for consistency.
    ///
    /// # Errors
    ///
    /// Returns error if:
    /// - Tensors overlap
    /// - Duplicate tensor names exist
    pub fn validate(&self) -> Result<()> {
        self.check_no_duplicates()?;
        self.check_no_overlaps()?;
        Ok(())
    }

    fn check_no_duplicates(&self) -> Result<()> {
        let mut seen = std::collections::HashSet::new();
        for tensor in &self.tensors {
            if !seen.insert(&tensor.name) {
                return Err(HoloError::Other(format!(
                    "Duplicate tensor name: {}",
                    tensor.name
                )));
            }
        }
        Ok(())
    }

    fn check_no_overlaps(&self) -> Result<()> {
        let mut sorted: Vec<_> = self.tensors.iter().collect();
        sorted.sort_by_key(|t| t.offset);

        for window in sorted.windows(2) {
            let a = window[0];
            let b = window[1];
            if a.end_offset() > b.offset {
                return Err(HoloError::overlapping_tensors(&a.name, &b.name));
            }
        }
        Ok(())
    }
}

impl Default for WeightIndexSection {
    fn default() -> Self {
        Self::new()
    }
}

impl EmbeddableSection for WeightIndexSection {
    fn section_id(&self) -> &'static str {
        Self::SECTION_ID
    }

    fn to_bytes(&self) -> Vec<u8> {
        rkyv::to_bytes::<_, 1024>(self)
            .map(|bytes| bytes.to_vec())
            .unwrap_or_default()
    }

    fn content_type(&self) -> &'static str {
        Self::CONTENT_TYPE
    }

    fn version(&self) -> u32 {
        Self::VERSION
    }
}

impl FromEmbeddedSection for WeightIndexSection {
    const SECTION_ID: &'static str = "weight_index";

    fn from_bytes(bytes: &[u8]) -> Result<Self> {
        rkyv::from_bytes::<Self>(bytes)
            .map_err(|e| HoloError::Deserialization(format!("weight index: {e}")))
    }

    fn expected_version() -> u32 {
        Self::VERSION
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::compression::{CompressionAlgorithm, CompressionMetadata};
    use crate::weight_types::WeightDType;

    fn make_tensor(name: &str, offset: u64, size: u64) -> TensorMetadata {
        TensorMetadata::builder()
            .name(name)
            .shape(vec![100])
            .dtype(WeightDType::F32)
            .offset(offset)
            .size(size)
            .build()
            .unwrap()
    }

    #[test]
    fn test_weight_index_new() {
        let index = WeightIndexSection::new();
        assert!(index.is_empty());
        assert_eq!(index.len(), 0);
        assert!(!index.is_compressed());
    }

    #[test]
    fn test_weight_index_add_tensor() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("weight1", 0, 400));
        index.add_tensor(make_tensor("weight2", 400, 800));

        assert_eq!(index.len(), 2);
        assert!(!index.is_empty());
    }

    #[test]
    fn test_weight_index_get_tensor() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("encoder.weight", 0, 1000));
        index.add_tensor(make_tensor("decoder.weight", 1000, 2000));

        let tensor = index.get_tensor("encoder.weight");
        assert!(tensor.is_some());
        assert_eq!(tensor.unwrap().offset, 0);

        let tensor = index.get_tensor("decoder.weight");
        assert!(tensor.is_some());
        assert_eq!(tensor.unwrap().offset, 1000);

        assert!(index.get_tensor("nonexistent").is_none());
    }

    #[test]
    fn test_weight_index_get_tensor_mut() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("weight", 0, 400));

        if let Some(tensor) = index.get_tensor_mut("weight") {
            tensor.checksum = 0xDEAD_BEEF;
        }

        assert_eq!(index.get_tensor("weight").unwrap().checksum, 0xDEAD_BEEF);
    }

    #[test]
    fn test_weight_index_find_tensor_index() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("a", 0, 100));
        index.add_tensor(make_tensor("b", 100, 100));
        index.add_tensor(make_tensor("c", 200, 100));

        assert_eq!(index.find_tensor_index("a"), Some(0));
        assert_eq!(index.find_tensor_index("b"), Some(1));
        assert_eq!(index.find_tensor_index("c"), Some(2));
        assert_eq!(index.find_tensor_index("d"), None);
    }

    #[test]
    fn test_weight_index_tensor_names() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("encoder", 0, 100));
        index.add_tensor(make_tensor("decoder", 100, 100));

        let names = index.tensor_names();
        assert_eq!(names, vec!["encoder", "decoder"]);
    }

    #[test]
    fn test_weight_index_total_size() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("a", 0, 100));
        index.add_tensor(make_tensor("b", 100, 200));
        index.add_tensor(make_tensor("c", 300, 300));

        assert_eq!(index.total_size(), 600);
    }

    #[test]
    fn test_weight_index_sort_by_offset() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("c", 200, 100));
        index.add_tensor(make_tensor("a", 0, 100));
        index.add_tensor(make_tensor("b", 100, 100));

        index.sort_by_offset();

        let names: Vec<_> = index.iter().map(|t| t.name.as_str()).collect();
        assert_eq!(names, vec!["a", "b", "c"]);
    }

    #[test]
    fn test_weight_index_with_compression() {
        let mut index = WeightIndexSection::new();
        let compression = CompressionMetadata {
            algorithm: CompressionAlgorithm::Zstd,
            level: 3,
            uncompressed_size: 1000,
            compressed_size: 500,
            uncompressed_checksum: 0xABCD_1234,
        };
        index.set_compression(compression);

        assert!(index.is_compressed());
        assert!(index.compression.is_some());
    }

    #[test]
    fn test_weight_index_not_compressed() {
        let index = WeightIndexSection::new();
        assert!(!index.is_compressed());
    }

    #[test]
    fn test_weight_index_validate_success() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("a", 0, 100));
        index.add_tensor(make_tensor("b", 100, 100));
        index.add_tensor(make_tensor("c", 200, 100));

        assert!(index.validate().is_ok());
    }

    #[test]
    fn test_weight_index_validate_duplicate_names() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("same", 0, 100));
        index.add_tensor(make_tensor("same", 100, 100));

        let result = index.validate();
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("Duplicate"));
    }

    #[test]
    fn test_weight_index_validate_overlapping() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("a", 0, 150));
        index.add_tensor(make_tensor("b", 100, 100)); // Overlaps with a

        let result = index.validate();
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("Overlapping"));
    }

    #[test]
    fn test_weight_index_validate_adjacent_ok() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("a", 0, 100));
        index.add_tensor(make_tensor("b", 100, 100)); // Exactly adjacent

        assert!(index.validate().is_ok());
    }

    #[test]
    fn test_weight_index_with_tensors() {
        let tensors = vec![make_tensor("a", 0, 100), make_tensor("b", 100, 100)];
        let index = WeightIndexSection::with_tensors(tensors);

        assert_eq!(index.len(), 2);
        assert!(index.get_tensor("a").is_some());
    }

    #[test]
    fn test_weight_index_iter() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("a", 0, 100));
        index.add_tensor(make_tensor("b", 100, 100));

        let count = index.iter().count();
        assert_eq!(count, 2);
    }

    // ------------------------------------------------------------------------
    // EmbeddableSection Tests
    // ------------------------------------------------------------------------

    #[test]
    fn test_weight_index_section_metadata() {
        let index = WeightIndexSection::new();

        assert_eq!(index.section_id(), "weight_index");
        assert_eq!(
            index.content_type(),
            "application/vnd.hologram.weight-index"
        );
        assert_eq!(index.version(), 1);
    }

    #[test]
    fn test_weight_index_section_roundtrip() {
        let mut index = WeightIndexSection::new();
        index.add_tensor(make_tensor("encoder.weight", 0, 1000));
        index.add_tensor(make_tensor("decoder.weight", 1000, 2000));
        index.set_compression(CompressionMetadata {
            algorithm: CompressionAlgorithm::Lz4,
            level: 1,
            uncompressed_size: 3000,
            compressed_size: 1500,
            uncompressed_checksum: 0x1234_5678,
        });

        let bytes = index.to_bytes();
        assert!(!bytes.is_empty());

        let restored = WeightIndexSection::from_bytes(&bytes).unwrap();
        assert_eq!(restored.len(), 2);
        assert!(restored.is_compressed());
        assert!(restored.get_tensor("encoder.weight").is_some());
        assert!(restored.get_tensor("decoder.weight").is_some());
    }

    #[test]
    fn test_weight_index_section_empty_roundtrip() {
        let index = WeightIndexSection::new();
        let bytes = index.to_bytes();
        let restored = WeightIndexSection::from_bytes(&bytes).unwrap();

        assert!(restored.is_empty());
        assert!(!restored.is_compressed());
    }

    #[test]
    fn test_weight_index_from_embedded_section_constants() {
        assert_eq!(
            <WeightIndexSection as FromEmbeddedSection>::SECTION_ID,
            "weight_index"
        );
        assert_eq!(WeightIndexSection::expected_version(), 1);
    }
}
