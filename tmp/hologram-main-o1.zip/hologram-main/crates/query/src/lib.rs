//! Runtime query engine for hologram's typed domain system.
//!
//! Provides a GraphQL-like query language over the UOR domain types (byte, ring,
//! activation). Queries select specific fields from LUT-resolved values. Mutations
//! apply typed transforms and return before/after/delta snapshots.
//!
//! # Architecture
//!
//! ```text
//! Query string → [parse] → AST → [validate] → [resolve] → JSON
//! ```
//!
//! - **Parse**: nom combinators convert query text into a typed AST
//! - **Validate**: checks field names and argument types against generated schema
//! - **Resolve**: dispatches to build-time generated `resolve_field()` methods
//!
//! # Example
//!
//! ```
//! use hologram_query::{parse, execute};
//!
//! let result = execute(&parse("query { byte(value: 42) { stratum, curvature } }").unwrap()).unwrap();
//! assert!(result["stratum"].is_number());
//! ```

pub mod ast;
#[allow(dead_code, clippy::all)]
mod generated;
pub mod parse;
pub mod pipeline;
pub mod resolve;
pub mod translate;
pub mod validate;

pub use ast::{Document, OpType, QueryValue, Selection};
pub use parse::parse;
pub use resolve::{execute, execute_rows, to_ndjson};
