/**
 * C FFI Benchmarks
 *
 * Measures FFI call overhead and throughput
 *
 * Build and run:
 *   make bench
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "uor.h"

#define ITERATIONS 1000000
#define WARMUP_ITERATIONS 100000

double get_time_ns() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1e9 + ts.tv_nsec;
}

double bench_function(void (*fn)(void), const char* name, int iterations) {
    // Warmup
    for (int i = 0; i < WARMUP_ITERATIONS; i++) {
        fn();
    }

    // Benchmark
    double start = get_time_ns();
    for (int i = 0; i < iterations; i++) {
        fn();
    }
    double end = get_time_ns();

    double total_ns = end - start;
    double per_call_ns = total_ns / iterations;

    printf("  %-30s: %8.2f ns/call  (%7.2f M calls/sec)\n",
           name, per_call_ns, 1000.0 / per_call_ns);

    return per_call_ns;
}

// Benchmark functions
void bench_byte_to_braille() {
    char* result = uor_byte_to_braille(42);
    uor_string_free(result);
}

void bench_byte_to_codepoint() {
    volatile uint32_t result = uor_byte_to_codepoint(42);
    (void)result;
}

void bench_byte_to_domain() {
    volatile unsigned char result = uor_byte_to_domain(42);
    (void)result;
}

void bench_byte_rank() {
    volatile unsigned char result = uor_byte_rank(42);
    (void)result;
}

void bench_byte_succ() {
    volatile unsigned char result = uor_byte_succ(42);
    (void)result;
}

void bench_byte_pred() {
    volatile unsigned char result = uor_byte_pred(42);
    (void)result;
}

void bench_byte_not() {
    volatile unsigned char result = uor_byte_not(42);
    (void)result;
}

void bench_view_apply() {
    static struct UorView* view = NULL;
    if (!view) {
        view = uor_view_identity();
    }
    volatile unsigned char result = uor_view_apply(view, 42);
    (void)result;
}

void bench_view_apply_slice_1kb() {
    static struct UorView* view = NULL;
    static unsigned char input[1024];
    static unsigned char output[1024];

    if (!view) {
        view = uor_view_identity();
        for (int i = 0; i < 1024; i++) {
            input[i] = i & 0xFF;
        }
    }

    uor_view_apply_slice(view, input, 1024, output);
}

int main() {
    printf("=== UOR C FFI Benchmarks ===\n\n");
    printf("Target: < 10 ns per call\n");
    printf("Iterations: %d (after %d warmup)\n\n", ITERATIONS, WARMUP_ITERATIONS);

    printf("Taxon Operations:\n");
    bench_function(bench_byte_to_braille, "byte_to_braille", ITERATIONS);
    bench_function(bench_byte_to_codepoint, "byte_to_codepoint", ITERATIONS);
    bench_function(bench_byte_to_domain, "byte_to_domain", ITERATIONS);
    bench_function(bench_byte_rank, "byte_rank", ITERATIONS);

    printf("\nRing Operations:\n");
    bench_function(bench_byte_succ, "byte_succ", ITERATIONS);
    bench_function(bench_byte_pred, "byte_pred", ITERATIONS);
    bench_function(bench_byte_not, "byte_not", ITERATIONS);

    printf("\nView Operations:\n");
    bench_function(bench_view_apply, "view_apply", ITERATIONS);

    printf("\nBatch Operations:\n");
    int batch_iterations = ITERATIONS / 100;
    double batch_ns = bench_function(bench_view_apply_slice_1kb, "view_apply_slice (1KB)", batch_iterations);
    printf("  Throughput: %.2f MB/sec\n", (1024.0 / batch_ns) * 1000.0);

    printf("\n=== Benchmarks Complete ===\n");
    return 0;
}
