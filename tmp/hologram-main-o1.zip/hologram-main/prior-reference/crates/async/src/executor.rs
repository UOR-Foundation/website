//! Async executor wrapper around the synchronous Executor.
//!
//! This module provides an async-friendly interface to the hologram-core Executor.

use crate::error::AsyncError;
use crate::Result;
use hologram_core::{BackendType, Buffer, Executor, LaunchConfig, Program};
use std::sync::Arc;
use tokio::sync::Mutex;

/// An async wrapper around the synchronous Executor.
///
/// This executor offloads blocking operations to tokio's blocking thread pool
/// to avoid blocking the async runtime.
pub struct AsyncExecutor {
    inner: Arc<Mutex<Executor>>,
    backend_type: BackendType,
}

impl AsyncExecutor {
    /// Create a new async executor with auto-detected backend.
    pub async fn new() -> Result<Self> {
        let (executor, backend_type) = tokio::task::spawn_blocking(|| {
            let exec = Executor::new()?;
            let backend_type = exec.backend_type();
            Ok::<_, hologram_core::BackendError>((exec, backend_type))
        })
        .await??;

        Ok(Self {
            inner: Arc::new(Mutex::new(executor)),
            backend_type,
        })
    }

    /// Create an async executor with a specific backend.
    pub async fn with_backend(backend_type: BackendType) -> Result<Self> {
        let bt = backend_type.clone();
        let executor =
            tokio::task::spawn_blocking(move || Executor::with_backend(backend_type)).await??;

        Ok(Self {
            inner: Arc::new(Mutex::new(executor)),
            backend_type: bt,
        })
    }

    /// Get the backend type of this executor.
    pub fn backend_type(&self) -> BackendType {
        self.backend_type.clone()
    }

    /// Allocate a typed buffer asynchronously.
    pub async fn allocate<T: Copy + Send + 'static>(&self, count: usize) -> Result<Buffer<T>> {
        let inner = self.inner.clone();
        tokio::task::spawn_blocking(move || {
            let mut guard = futures::executor::block_on(inner.lock());
            guard.allocate::<T>(count)
        })
        .await?
        .map_err(AsyncError::from)
    }

    /// Free a buffer asynchronously.
    pub async fn free<T: Copy + Send + 'static>(&self, buffer: Buffer<T>) -> Result<()> {
        let inner = self.inner.clone();
        tokio::task::spawn_blocking(move || {
            let mut guard = futures::executor::block_on(inner.lock());
            guard.free(buffer)
        })
        .await?
        .map_err(AsyncError::from)
    }

    /// Execute a program asynchronously.
    pub async fn execute(&self, program: Program, config: LaunchConfig) -> Result<()> {
        let inner = self.inner.clone();
        tokio::task::spawn_blocking(move || {
            let mut guard = futures::executor::block_on(inner.lock());
            guard.execute(&program, &config)
        })
        .await?
        .map_err(AsyncError::from)
    }

    /// Copy data to a buffer asynchronously.
    pub async fn copy_to_buffer<T: Copy + Send + 'static>(
        &self,
        buffer: &Buffer<T>,
        data: Vec<T>,
    ) -> Result<()> {
        let inner = self.inner.clone();
        let buf = *buffer;
        tokio::task::spawn_blocking(move || {
            let mut guard = futures::executor::block_on(inner.lock());
            buf.copy_from_slice(&mut guard, &data)
        })
        .await?
        .map_err(AsyncError::from)
    }

    /// Read data from a buffer asynchronously.
    pub async fn read_buffer<T: Copy + Send + 'static>(
        &self,
        buffer: &Buffer<T>,
    ) -> Result<Vec<T>> {
        let inner = self.inner.clone();
        let buf = *buffer;
        tokio::task::spawn_blocking(move || {
            let guard = futures::executor::block_on(inner.lock());
            buf.to_vec(&guard)
        })
        .await?
        .map_err(AsyncError::from)
    }

    /// Fill a buffer with a value asynchronously.
    pub async fn fill_buffer<T: Copy + Send + 'static>(
        &self,
        buffer: &Buffer<T>,
        value: T,
    ) -> Result<()> {
        let inner = self.inner.clone();
        let buf = *buffer;
        tokio::task::spawn_blocking(move || {
            let mut guard = futures::executor::block_on(inner.lock());
            buf.fill(&mut guard, value)
        })
        .await?
        .map_err(AsyncError::from)
    }

    /// Get a clone of the inner executor arc for advanced use cases.
    pub fn inner(&self) -> Arc<Mutex<Executor>> {
        self.inner.clone()
    }
}

impl Clone for AsyncExecutor {
    fn clone(&self) -> Self {
        Self {
            inner: self.inner.clone(),
            backend_type: self.backend_type.clone(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_async_executor_new() {
        let exec = AsyncExecutor::new().await;
        assert!(exec.is_ok());
    }

    #[tokio::test]
    async fn test_async_executor_with_backend() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await;
        assert!(exec.is_ok());
        assert_eq!(exec.unwrap().backend_type(), BackendType::Cpu);
    }

    #[tokio::test]
    async fn test_async_executor_allocate() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let buffer = exec.allocate::<f32>(1024).await;
        assert!(buffer.is_ok());
        assert_eq!(buffer.unwrap().len(), 1024);
    }

    #[tokio::test]
    async fn test_async_executor_allocate_and_free() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let buffer = exec.allocate::<f32>(1024).await.unwrap();
        let result = exec.free(buffer).await;
        assert!(result.is_ok());
    }

    #[tokio::test]
    async fn test_async_executor_copy_and_read() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let buffer = exec.allocate::<i32>(4).await.unwrap();

        let data = vec![1, 2, 3, 4];
        exec.copy_to_buffer(&buffer, data.clone()).await.unwrap();

        let result = exec.read_buffer(&buffer).await.unwrap();
        assert_eq!(result, data);
    }

    #[tokio::test]
    async fn test_async_executor_fill() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let buffer = exec.allocate::<u8>(8).await.unwrap();

        exec.fill_buffer(&buffer, 42u8).await.unwrap();

        let result = exec.read_buffer(&buffer).await.unwrap();
        assert_eq!(result, vec![42u8; 8]);
    }

    #[tokio::test]
    async fn test_async_executor_clone() {
        let exec1 = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let exec2 = exec1.clone();

        assert_eq!(exec1.backend_type(), exec2.backend_type());
    }

    #[tokio::test]
    async fn test_async_executor_execute() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let program = Program::default();
        let config = LaunchConfig::default();
        let result = exec.execute(program, config).await;
        assert!(result.is_ok());
    }

    #[tokio::test]
    async fn test_async_executor_concurrent_allocations() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();

        let handles: Vec<_> = (0..10)
            .map(|i| {
                let e = exec.clone();
                tokio::spawn(async move { e.allocate::<f32>(100 * (i + 1)).await })
            })
            .collect();

        for handle in handles {
            let result = handle.await.unwrap();
            assert!(result.is_ok());
        }
    }

    #[tokio::test]
    async fn test_async_executor_inner() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let inner = exec.inner();
        assert!(Arc::strong_count(&inner) >= 2);
    }
}
