//! Fluent builders for complex ISA instruction variants.
//!
//! Generated from `descriptors/shells/isa.shell` — see `specs/research/shell-dsl-isa-codegen.md`.
//!
//! These builders provide an ergonomic API for constructing instructions with
//! many fields, reducing errors from field ordering and providing sensible defaults.
//!
//! # Example
//!
//! ```
//! use hologram_holo::{IsaInstruction, Conv2dBuilder};
//!
//! let conv = IsaInstruction::conv2d()
//!     .dst(0)
//!     .input(1)
//!     .weight(2)
//!     .kernel(3, 3)
//!     .input_shape(1, 64, 28, 28)
//!     .output_shape(128, 26, 26)
//!     .build()
//!     .expect("valid conv2d");
//! ```

use crate::error::BuilderError;
use crate::instruction::IsaInstruction;

// Generated from descriptors/shells/isa.shell — see specs/research/shell-dsl-isa-codegen.md
include!(concat!(env!("OUT_DIR"), "/generated_builder.rs"));

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_conv2d_builder_full() {
        let instr = Conv2dBuilder::new()
            .dst(0)
            .input(1)
            .weight(2)
            .bias(3)
            .kernel(5, 5)
            .stride(2, 2)
            .padding(1, 1)
            .dilation(2, 2)
            .groups(4)
            .input_shape(8, 64, 32, 32)
            .output_shape(128, 15, 15)
            .build()
            .unwrap();

        match instr {
            IsaInstruction::Conv2d {
                dst,
                input,
                weight,
                bias,
                kernel_h,
                kernel_w,
                stride_h,
                stride_w,
                pad_h,
                pad_w,
                dilation_h,
                dilation_w,
                groups,
                batch,
                in_channels,
                out_channels,
                in_h,
                in_w,
                out_h,
                out_w,
            } => {
                assert_eq!(dst, 0);
                assert_eq!(input, 1);
                assert_eq!(weight, 2);
                assert_eq!(bias, Some(3));
                assert_eq!(kernel_h, 5);
                assert_eq!(kernel_w, 5);
                assert_eq!(stride_h, 2);
                assert_eq!(stride_w, 2);
                assert_eq!(pad_h, 1);
                assert_eq!(pad_w, 1);
                assert_eq!(dilation_h, 2);
                assert_eq!(dilation_w, 2);
                assert_eq!(groups, 4);
                assert_eq!(batch, 8);
                assert_eq!(in_channels, 64);
                assert_eq!(out_channels, 128);
                assert_eq!(in_h, 32);
                assert_eq!(in_w, 32);
                assert_eq!(out_h, 15);
                assert_eq!(out_w, 15);
            }
            _ => panic!("expected Conv2d"),
        }
    }

    #[test]
    fn test_conv2d_builder_defaults() {
        let instr = Conv2dBuilder::new()
            .dst(0)
            .input(1)
            .weight(2)
            .input_shape(1, 3, 28, 28)
            .output_shape(32, 26, 26)
            .build()
            .unwrap();

        match instr {
            IsaInstruction::Conv2d {
                bias,
                kernel_h,
                kernel_w,
                stride_h,
                stride_w,
                pad_h,
                pad_w,
                dilation_h,
                dilation_w,
                groups,
                ..
            } => {
                assert_eq!(bias, None);
                assert_eq!(kernel_h, 3);
                assert_eq!(kernel_w, 3);
                assert_eq!(stride_h, 1);
                assert_eq!(stride_w, 1);
                assert_eq!(pad_h, 0);
                assert_eq!(pad_w, 0);
                assert_eq!(dilation_h, 1);
                assert_eq!(dilation_w, 1);
                assert_eq!(groups, 1);
            }
            _ => panic!("expected Conv2d"),
        }
    }

    #[test]
    fn test_conv2d_builder_missing_field() {
        let result = Conv2dBuilder::new().dst(0).input(1).build();
        assert!(result.is_err());
        assert_eq!(result.unwrap_err(), BuilderError::MissingField("weight"));
    }

    #[test]
    fn test_batch_norm_builder_full() {
        let instr = BatchNormBuilder::new()
            .dst(0)
            .input(1)
            .scale(2)
            .bias(3)
            .mean(4)
            .var(5)
            .epsilon(1e-6)
            .shape(8, 64, 1024)
            .build()
            .unwrap();

        match instr {
            IsaInstruction::BatchNorm {
                dst,
                input,
                scale,
                bias,
                mean,
                var,
                epsilon,
                batch,
                channels,
                spatial,
            } => {
                assert_eq!(dst, 0);
                assert_eq!(input, 1);
                assert_eq!(scale, 2);
                assert_eq!(bias, 3);
                assert_eq!(mean, 4);
                assert_eq!(var, 5);
                assert!((epsilon - 1e-6).abs() < 1e-10);
                assert_eq!(batch, 8);
                assert_eq!(channels, 64);
                assert_eq!(spatial, 1024);
            }
            _ => panic!("expected BatchNorm"),
        }
    }

    #[test]
    fn test_batch_norm_builder_default_epsilon() {
        let instr = BatchNormBuilder::new()
            .dst(0)
            .input(1)
            .scale(2)
            .bias(3)
            .mean(4)
            .var(5)
            .shape(1, 32, 256)
            .build()
            .unwrap();

        match instr {
            IsaInstruction::BatchNorm { epsilon, .. } => {
                assert!((epsilon - 1e-5).abs() < 1e-10);
            }
            _ => panic!("expected BatchNorm"),
        }
    }

    #[test]
    fn test_batch_norm_builder_missing_field() {
        let result = BatchNormBuilder::new()
            .dst(0)
            .input(1)
            .scale(2)
            .bias(3)
            .mean(4)
            .shape(1, 32, 256)
            .build();
        assert!(result.is_err());
        assert_eq!(result.unwrap_err(), BuilderError::MissingField("var"));
    }

    #[test]
    fn test_max_pool2d_builder_full() {
        let instr = MaxPool2dBuilder::new()
            .dst(0)
            .src(1)
            .kernel(3, 3)
            .stride(2, 2)
            .padding(1, 1)
            .input_shape(8, 64, 32, 32)
            .output_shape(16, 16)
            .build()
            .unwrap();

        match instr {
            IsaInstruction::MaxPool2d {
                dst,
                src,
                kernel_h,
                kernel_w,
                stride_h,
                stride_w,
                pad_h,
                pad_w,
                batch,
                channels,
                in_h,
                in_w,
                out_h,
                out_w,
            } => {
                assert_eq!(dst, 0);
                assert_eq!(src, 1);
                assert_eq!(kernel_h, 3);
                assert_eq!(kernel_w, 3);
                assert_eq!(stride_h, 2);
                assert_eq!(stride_w, 2);
                assert_eq!(pad_h, 1);
                assert_eq!(pad_w, 1);
                assert_eq!(batch, 8);
                assert_eq!(channels, 64);
                assert_eq!(in_h, 32);
                assert_eq!(in_w, 32);
                assert_eq!(out_h, 16);
                assert_eq!(out_w, 16);
            }
            _ => panic!("expected MaxPool2d"),
        }
    }

    #[test]
    fn test_max_pool2d_builder_missing_field() {
        // Both kernel and stride are required
        let result = MaxPool2dBuilder::new()
            .dst(0)
            .src(1)
            .kernel(2, 2)
            .input_shape(1, 64, 32, 32)
            .output_shape(16, 16)
            .build();
        assert!(result.is_err());
        assert_eq!(result.unwrap_err(), BuilderError::MissingField("stride"));
    }

    #[test]
    fn test_avg_pool2d_builder_full() {
        let instr = AvgPool2dBuilder::new()
            .dst(0)
            .src(1)
            .kernel(3, 3)
            .stride(2, 2)
            .padding(1, 1)
            .input_shape(8, 64, 32, 32)
            .output_shape(16, 16)
            .build()
            .unwrap();

        match instr {
            IsaInstruction::AvgPool2d {
                dst,
                src,
                kernel_h,
                kernel_w,
                stride_h,
                stride_w,
                ..
            } => {
                assert_eq!(dst, 0);
                assert_eq!(src, 1);
                assert_eq!(kernel_h, 3);
                assert_eq!(kernel_w, 3);
                assert_eq!(stride_h, 2);
                assert_eq!(stride_w, 2);
            }
            _ => panic!("expected AvgPool2d"),
        }
    }
}
