//! Build script for ontology-gen.
//!
//! Generates Rust types from JSON-LD schema definitions and SHACL shapes
//! at compile time.

use std::env;
use std::fs;
use std::path::Path;

fn main() {
    let out_dir = env::var("OUT_DIR").unwrap();
    let manifest_dir = env::var("CARGO_MANIFEST_DIR").unwrap();
    let workspace_root = Path::new(&manifest_dir).parent().unwrap().parent().unwrap();

    println!("cargo:rerun-if-changed=build.rs");

    generate_q1_schema(&out_dir, workspace_root);
    generate_shacl_types(&out_dir, workspace_root);
}

fn generate_q1_schema(out_dir: &str, workspace_root: &Path) {
    let q1_schema_path = workspace_root.join("descriptors/q1/schema.jsonld");
    println!("cargo:rerun-if-changed={}", q1_schema_path.display());

    let code = match fs::read_to_string(&q1_schema_path) {
        Ok(schema_content) => generate_from_schema(&schema_content),
        Err(e) => {
            eprintln!(
                "Warning: Q1 schema not found at {}: {}",
                q1_schema_path.display(),
                e
            );
            generate_stub()
        }
    };

    let output_path = Path::new(out_dir).join("generated.rs");
    fs::write(&output_path, code).expect("Failed to write generated.rs");
}

fn generate_shacl_types(out_dir: &str, workspace_root: &Path) {
    use hologram_shell::emit_shacl::{EmitConfig, ExistingTypeMapping, FieldAccessor};

    let shacl_dir = workspace_root.join("descriptors/shacl");
    let config = EmitConfig {
        existing_types: vec![ExistingTypeMapping {
            target_class: "Q1Datum".into(),
            rust_type: "Datum16".into(),
            field_map: vec![
                ("value".into(), FieldAccessor::Field("value".into())),
                ("stratum".into(), FieldAccessor::Method("stratum".into())),
                (
                    "curvature".into(),
                    FieldAccessor::Method("curvature".into()),
                ),
                ("highByte".into(), FieldAccessor::Method("high_byte".into())),
                ("lowByte".into(), FieldAccessor::Method("low_byte".into())),
            ],
        }],
    };

    let mut combined = String::from(
        "// Auto-generated from descriptors/shacl/*.ttl\n\
         // DO NOT EDIT - regenerate by rebuilding the crate\n\n",
    );

    // Emit ShaclViolation type once
    combined.push_str(&hologram_shell::emit_shacl::emit_preamble());
    combined.push('\n');

    let shape_files = [
        "datum-shapes",
        "derivation-shapes",
        "observable-shapes",
        "mining-shapes",
    ];
    for name in shape_files {
        let path = shacl_dir.join(format!("{name}.ttl"));
        println!("cargo:rerun-if-changed={}", path.display());

        let input = match fs::read_to_string(&path) {
            Ok(s) => s,
            Err(e) => {
                eprintln!("Warning: SHACL file not found at {}: {e}", path.display());
                continue;
            }
        };

        let shapes = hologram_shell::parse_shacl::parse_shacl_file(&input)
            .unwrap_or_else(|e| panic!("failed to parse {name}.ttl: {e}"));

        let code = hologram_shell::emit_shacl::emit_all(&shapes, &config);
        combined.push_str(&format!("// --- {name}.ttl ---\n\n{code}\n\n"));
    }

    let output_path = Path::new(out_dir).join("generated_shacl.rs");
    fs::write(&output_path, combined).expect("Failed to write generated_shacl.rs");
}

fn generate_stub() -> String {
    r#"// No Q1 schema found - stub implementation
use uor::lut::{stratum_q1, curvature_q1};

/// Q1 Datum (16-bit) - stub when schema not available.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Datum16 {
    pub value: u16,
}

impl Datum16 {
    pub const fn from_value(value: u16) -> Self {
        Self { value }
    }

    /// Uses O(1) LUT lookup.
    pub const fn stratum(&self) -> u8 { stratum_q1(self.value) }
    /// Uses O(1) LUT lookup.
    pub const fn curvature(&self) -> u8 { curvature_q1(self.value) }
    pub const fn high_byte(&self) -> u8 { (self.value >> 8) as u8 }
    pub const fn low_byte(&self) -> u8 { self.value as u8 }
}
"#
    .to_string()
}

fn generate_from_schema(schema_content: &str) -> String {
    // Parse schema to extract metadata
    let schema: serde_json::Value = match serde_json::from_str(schema_content) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("Warning: Failed to parse Q1 schema: {}", e);
            return generate_stub();
        }
    };

    // Extract class metadata from @graph
    let graph = schema.get("@graph").and_then(|g| g.as_array());
    let mut quantum_level = 1u8;
    let mut precision_bits = 16u8;
    let mut cardinality = 65536u32;

    if let Some(nodes) = graph {
        for node in nodes {
            let id = node.get("@id").and_then(|v| v.as_str()).unwrap_or("");
            if id == "datum:Q1Datum" {
                if let Some(q) = node.get("datum:quantumLevel").and_then(|v| v.as_u64()) {
                    quantum_level = q as u8;
                }
                if let Some(p) = node.get("datum:precisionBits").and_then(|v| v.as_u64()) {
                    precision_bits = p as u8;
                }
                if let Some(c) = node.get("datum:cardinality").and_then(|v| v.as_u64()) {
                    cardinality = c as u32;
                }
            }
        }
    }

    // Generate Rust code
    let mut code = String::new();

    code.push_str("// Auto-generated from descriptors/q1/schema.jsonld\n");
    code.push_str("// DO NOT EDIT - regenerate by rebuilding the crate\n\n");

    // Constants from schema
    code.push_str("/// Quantum level for Q1 datums.\n");
    code.push_str(&format!(
        "pub const QUANTUM_LEVEL: u8 = {};\n\n",
        quantum_level
    ));
    code.push_str("/// Precision bits for Q1 datums.\n");
    code.push_str(&format!(
        "pub const PRECISION_BITS: u8 = {};\n\n",
        precision_bits
    ));
    code.push_str("/// Total number of Q1 datums.\n");
    code.push_str(&format!(
        "pub const CARDINALITY: u32 = {};\n\n",
        cardinality
    ));

    // Braille base constant
    code.push_str("/// Braille block base codepoint (U+2800).\n");
    code.push_str("const BRAILLE_BASE: u32 = 0x2800;\n\n");

    // Import O(1) LUT functions
    code.push_str("use uor::lut::{stratum_q1, curvature_q1};\n\n");

    // Datum16 struct
    code.push_str(
        r#"/// Q1 Datum representing a 16-bit value with computed observables.
///
/// Each datum has:
/// - `value`: The raw 16-bit unsigned integer (0-65535)
/// - `stratum()`: Hamming weight (0-16) via O(1) LUT
/// - `spectrum()`: Bit positions of 1-bits
/// - `glyph()`: Two Braille codepoints representing high/low bytes
/// - `curvature()`: Hamming distance to successor via O(1) LUT
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub struct Datum16 {
    /// The raw 16-bit value.
    pub value: u16,
}

impl Datum16 {
    /// Create a datum from a 16-bit value.
    #[inline]
    pub const fn from_value(value: u16) -> Self {
        Self { value }
    }

    /// Create a datum from high and low bytes.
    #[inline]
    pub const fn from_bytes(high: u8, low: u8) -> Self {
        Self {
            value: ((high as u16) << 8) | (low as u16),
        }
    }

    /// Stratum: Hamming weight (number of 1-bits).
    /// Uses O(1) LUT lookup via `stratum_q1`.
    #[inline]
    pub const fn stratum(&self) -> u8 {
        stratum_q1(self.value)
    }

    /// Curvature: Hamming distance to successor.
    /// Uses O(1) LUT lookup via `curvature_q1`.
    #[inline]
    pub const fn curvature(&self) -> u8 {
        curvature_q1(self.value)
    }

    /// High byte (bits 8-15).
    #[inline]
    pub const fn high_byte(&self) -> u8 {
        (self.value >> 8) as u8
    }

    /// Low byte (bits 0-7).
    #[inline]
    pub const fn low_byte(&self) -> u8 {
        self.value as u8
    }

    /// Spectrum: bit positions of 1-bits as a sorted vector.
    pub fn spectrum(&self) -> Vec<u8> {
        let mut positions = Vec::with_capacity(16);
        for i in 0..16 {
            if (self.value >> i) & 1 == 1 {
                positions.push(i);
            }
        }
        positions
    }

    /// Spectrum as comma-separated string of bit positions.
    pub fn spectrum_string(&self) -> String {
        self.spectrum()
            .iter()
            .map(|p| p.to_string())
            .collect::<Vec<_>>()
            .join(",")
    }

    /// Glyph: two Braille codepoints representing high and low bytes.
    pub fn glyph(&self) -> String {
        let high_char = char::from_u32(BRAILLE_BASE + self.high_byte() as u32).unwrap();
        let low_char = char::from_u32(BRAILLE_BASE + self.low_byte() as u32).unwrap();
        format!("{}{}", high_char, low_char)
    }

    /// Convert to JSON-LD representation.
    pub fn to_jsonld(&self) -> serde_json::Value {
        serde_json::json!({
            "@type": "datum:Q1Datum",
            "datum:value": self.value,
            "datum:stratum": self.stratum(),
            "datum:spectrum": self.spectrum_string(),
            "datum:glyph": self.glyph(),
            "datum:curvature": self.curvature(),
            "datum:highByte": self.high_byte(),
            "datum:lowByte": self.low_byte()
        })
    }
}

impl From<u16> for Datum16 {
    fn from(value: u16) -> Self {
        Self::from_value(value)
    }
}

impl From<Datum16> for u16 {
    fn from(datum: Datum16) -> Self {
        datum.value
    }
}

/// Iterator over all Q1 datums (0..65536).
pub struct AllDatums {
    current: u32,
}

impl AllDatums {
    pub fn new() -> Self {
        Self { current: 0 }
    }
}

impl Default for AllDatums {
    fn default() -> Self {
        Self::new()
    }
}

impl Iterator for AllDatums {
    type Item = Datum16;

    fn next(&mut self) -> Option<Self::Item> {
        if self.current < CARDINALITY {
            let datum = Datum16::from_value(self.current as u16);
            self.current += 1;
            Some(datum)
        } else {
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let remaining = (CARDINALITY - self.current) as usize;
        (remaining, Some(remaining))
    }
}

impl ExactSizeIterator for AllDatums {}

/// Returns an iterator over all Q1 datums.
pub fn all_q1_datums() -> AllDatums {
    AllDatums::new()
}
"#,
    );

    code
}
