//! SHA-256 benchmarks.

use criterion::{black_box, criterion_group, criterion_main, Criterion, Throughput};
use hologram_sha256::{double_sha256, sha256, MiningState};

fn bench_sha256(c: &mut Criterion) {
    let mut group = c.benchmark_group("sha256");

    // Empty input
    group.throughput(Throughput::Bytes(0));
    group.bench_function("empty", |b| {
        b.iter(|| sha256(black_box(b"")));
    });

    // Short input (< 55 bytes, single block after padding)
    let short = b"hello world";
    group.throughput(Throughput::Bytes(short.len() as u64));
    group.bench_function("short_11B", |b| {
        b.iter(|| sha256(black_box(short)));
    });

    // Single block input (64 bytes)
    let single_block = [0u8; 64];
    group.throughput(Throughput::Bytes(64));
    group.bench_function("single_block_64B", |b| {
        b.iter(|| sha256(black_box(&single_block)));
    });

    // Bitcoin block header (80 bytes)
    let header = [0u8; 80];
    group.throughput(Throughput::Bytes(80));
    group.bench_function("bitcoin_header_80B", |b| {
        b.iter(|| sha256(black_box(&header)));
    });

    // Multi-block input (256 bytes = 4 blocks)
    let multi_block = [0xABu8; 256];
    group.throughput(Throughput::Bytes(256));
    group.bench_function("multi_block_256B", |b| {
        b.iter(|| sha256(black_box(&multi_block)));
    });

    // 1KB input
    let kb = [0xCDu8; 1024];
    group.throughput(Throughput::Bytes(1024));
    group.bench_function("1KB", |b| {
        b.iter(|| sha256(black_box(&kb)));
    });

    group.finish();
}

fn bench_double_sha256(c: &mut Criterion) {
    let mut group = c.benchmark_group("double_sha256");

    // Bitcoin block header (primary use case)
    let header = [0u8; 80];
    group.throughput(Throughput::Bytes(80));
    group.bench_function("bitcoin_header_80B", |b| {
        b.iter(|| double_sha256(black_box(&header)));
    });

    // Transaction-sized input
    let tx = [0xEFu8; 250];
    group.throughput(Throughput::Bytes(250));
    group.bench_function("transaction_250B", |b| {
        b.iter(|| double_sha256(black_box(&tx)));
    });

    group.finish();
}

fn bench_vs_sha2_crate(c: &mut Criterion) {
    use sha2::Digest;

    let mut group = c.benchmark_group("vs_sha2_crate");

    let header = [0u8; 80];
    group.throughput(Throughput::Bytes(80));

    // Our implementation
    group.bench_function("hologram_sha256", |b| {
        b.iter(|| sha256(black_box(&header)));
    });

    // Reference sha2 crate
    group.bench_function("sha2_crate", |b| {
        b.iter(|| sha2::Sha256::digest(black_box(&header)));
    });

    group.finish();
}

fn bench_mining_range(c: &mut Criterion) {
    let mut group = c.benchmark_group("mining");

    let header = [0u8; 80];
    let target = [0xff; 32];
    let count = 1000;

    group.throughput(Throughput::Elements(count as u64));

    // Baseline: simple loop over double_sha256
    group.bench_function("baseline_loop", |b| {
        b.iter(|| {
            let mut h = header;
            for i in 0..count {
                h[76..80].copy_from_slice(&(i as u32).to_le_bytes());
                black_box(double_sha256(black_box(&h)));
            }
        });
    });

    // Optimization 1: Midstate caching (check_nonce)
    let state = MiningState::new(&header);
    group.bench_function("midstate_check_nonce", |b| {
        b.iter(|| {
            for i in 0..count {
                black_box(state.check_nonce(black_box(i as u32), black_box(&target)));
            }
        })
    });

    // Optimization 2: 4-way ILP (check_range)
    group.bench_function("midstate_check_range_4way", |b| {
        b.iter(|| {
            black_box(state.check_range(black_box(0), black_box(count as u32), black_box(&target)));
        })
    });

    group.finish();
}

criterion_group!(
    benches,
    bench_sha256,
    bench_double_sha256,
    bench_vs_sha2_crate,
    bench_mining_range
);
criterion_main!(benches);
