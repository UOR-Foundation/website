//! Hardware-accelerated SHA-256 compression.
//!
//! This module provides SHA-256 compression using hardware instructions:
//! - **x86_64**: Intel/AMD SHA-NI instructions
//! - **aarch64**: ARM SHA-2 cryptographic extensions (NEON)
//!
//! Falls back to pure-Rust implementation when hardware acceleration unavailable.
//!
//! # Performance
//!
//! Hardware SHA can achieve 2-4 GB/s throughput compared to ~300 MB/s for pure Rust.

use crate::compress::{compress as compress_scalar, state_to_bytes, H0};

#[cfg(any(target_arch = "x86_64", target_arch = "aarch64"))]
use crate::compress::K;
#[cfg(any(target_arch = "x86_64", target_arch = "aarch64"))]
use std::sync::OnceLock;

// ============================================================================
// Feature Detection
// ============================================================================

/// Cached SHA-NI feature detection (x86_64).
#[cfg(target_arch = "x86_64")]
static SHA_NI_SUPPORTED: OnceLock<bool> = OnceLock::new();

/// Cached SHA-2 feature detection (aarch64).
#[cfg(target_arch = "aarch64")]
static SHA2_SUPPORTED: OnceLock<bool> = OnceLock::new();

/// Check if hardware SHA acceleration is available.
///
/// - x86_64: Returns true if SHA-NI is supported
/// - aarch64: Returns true if SHA-2 cryptographic extensions are available
/// - Other: Always returns false
#[inline]
pub fn has_sha_ni() -> bool {
    #[cfg(target_arch = "x86_64")]
    {
        *SHA_NI_SUPPORTED.get_or_init(|| is_x86_feature_detected!("sha"))
    }
    #[cfg(target_arch = "aarch64")]
    {
        *SHA2_SUPPORTED.get_or_init(|| std::arch::is_aarch64_feature_detected!("sha2"))
    }
    #[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
    {
        false
    }
}

/// SHA-256 compression with automatic hardware dispatch.
///
/// Uses hardware SHA instructions when available, otherwise falls back to scalar.
#[inline]
pub fn compress(state: &mut [u32; 8], block: &[u8; 64]) {
    #[cfg(target_arch = "x86_64")]
    {
        if has_sha_ni() {
            unsafe {
                compress_sha_ni(state, block);
            }
            return;
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_sha_ni() {
            unsafe {
                compress_sha2_asm(state, block);
            }
            return;
        }
    }
    compress_scalar(state, block);
}

/// SHA-NI accelerated compression function.
///
/// # Safety
///
/// Caller must ensure SHA-NI is supported (`has_sha_ni()` returns true).
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "sha", enable = "sse4.1")]
pub unsafe fn compress_sha_ni(state: &mut [u32; 8], block: &[u8; 64]) {
    use std::arch::x86_64::*;

    // Load initial state
    // Intel SHA-NI state layout:
    //   STATE0 (xmm) = [d, c, b, a] (d in high bits)
    //   STATE1 (xmm) = [h, g, f, e] (h in high bits)
    let mut state0 = _mm_loadu_si128(state.as_ptr() as *const __m128i);
    let mut state1 = _mm_loadu_si128(state.as_ptr().add(4) as *const __m128i);

    // Shuffle from [a,b,c,d] to [d,c,b,a] and [e,f,g,h] to [h,g,f,e]
    let shuf_mask = _mm_set_epi64x(
        0x0c0d0e0f_08090a0b_u64 as i64,
        0x04050607_00010203_u64 as i64,
    );
    state0 = _mm_shuffle_epi8(state0, shuf_mask);
    state1 = _mm_shuffle_epi8(state1, shuf_mask);

    // Save original state for final addition
    let orig_state0 = state0;
    let orig_state1 = state1;

    // Load message block (big-endian to little-endian conversion)
    let be_mask = _mm_set_epi64x(
        0x08090a0b_0c0d0e0f_u64 as i64,
        0x00010203_04050607_u64 as i64,
    );

    let mut msg0 = _mm_shuffle_epi8(_mm_loadu_si128(block.as_ptr() as *const __m128i), be_mask);
    let mut msg1 = _mm_shuffle_epi8(
        _mm_loadu_si128(block.as_ptr().add(16) as *const __m128i),
        be_mask,
    );
    let mut msg2 = _mm_shuffle_epi8(
        _mm_loadu_si128(block.as_ptr().add(32) as *const __m128i),
        be_mask,
    );
    let mut msg3 = _mm_shuffle_epi8(
        _mm_loadu_si128(block.as_ptr().add(48) as *const __m128i),
        be_mask,
    );

    // Rounds 0-3
    let mut msg = _mm_add_epi32(msg0, _mm_loadu_si128(K.as_ptr() as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg0 = _mm_sha256msg1_epu32(msg0, msg1);

    // Rounds 4-7
    msg = _mm_add_epi32(msg1, _mm_loadu_si128(K.as_ptr().add(4) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg1 = _mm_sha256msg1_epu32(msg1, msg2);

    // Rounds 8-11
    msg = _mm_add_epi32(msg2, _mm_loadu_si128(K.as_ptr().add(8) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg2 = _mm_sha256msg1_epu32(msg2, msg3);

    // Rounds 12-15
    msg = _mm_add_epi32(msg3, _mm_loadu_si128(K.as_ptr().add(12) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg3, msg2, 4);
    msg0 = _mm_add_epi32(msg0, tmp);
    msg0 = _mm_sha256msg2_epu32(msg0, msg3);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg3 = _mm_sha256msg1_epu32(msg3, msg0);

    // Rounds 16-19
    msg = _mm_add_epi32(msg0, _mm_loadu_si128(K.as_ptr().add(16) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg0, msg3, 4);
    msg1 = _mm_add_epi32(msg1, tmp);
    msg1 = _mm_sha256msg2_epu32(msg1, msg0);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg0 = _mm_sha256msg1_epu32(msg0, msg1);

    // Rounds 20-23
    msg = _mm_add_epi32(msg1, _mm_loadu_si128(K.as_ptr().add(20) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg1, msg0, 4);
    msg2 = _mm_add_epi32(msg2, tmp);
    msg2 = _mm_sha256msg2_epu32(msg2, msg1);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg1 = _mm_sha256msg1_epu32(msg1, msg2);

    // Rounds 24-27
    msg = _mm_add_epi32(msg2, _mm_loadu_si128(K.as_ptr().add(24) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg2, msg1, 4);
    msg3 = _mm_add_epi32(msg3, tmp);
    msg3 = _mm_sha256msg2_epu32(msg3, msg2);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg2 = _mm_sha256msg1_epu32(msg2, msg3);

    // Rounds 28-31
    msg = _mm_add_epi32(msg3, _mm_loadu_si128(K.as_ptr().add(28) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg3, msg2, 4);
    msg0 = _mm_add_epi32(msg0, tmp);
    msg0 = _mm_sha256msg2_epu32(msg0, msg3);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg3 = _mm_sha256msg1_epu32(msg3, msg0);

    // Rounds 32-35
    msg = _mm_add_epi32(msg0, _mm_loadu_si128(K.as_ptr().add(32) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg0, msg3, 4);
    msg1 = _mm_add_epi32(msg1, tmp);
    msg1 = _mm_sha256msg2_epu32(msg1, msg0);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg0 = _mm_sha256msg1_epu32(msg0, msg1);

    // Rounds 36-39
    msg = _mm_add_epi32(msg1, _mm_loadu_si128(K.as_ptr().add(36) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg1, msg0, 4);
    msg2 = _mm_add_epi32(msg2, tmp);
    msg2 = _mm_sha256msg2_epu32(msg2, msg1);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg1 = _mm_sha256msg1_epu32(msg1, msg2);

    // Rounds 40-43
    msg = _mm_add_epi32(msg2, _mm_loadu_si128(K.as_ptr().add(40) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg2, msg1, 4);
    msg3 = _mm_add_epi32(msg3, tmp);
    msg3 = _mm_sha256msg2_epu32(msg3, msg2);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg2 = _mm_sha256msg1_epu32(msg2, msg3);

    // Rounds 44-47
    msg = _mm_add_epi32(msg3, _mm_loadu_si128(K.as_ptr().add(44) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg3, msg2, 4);
    msg0 = _mm_add_epi32(msg0, tmp);
    msg0 = _mm_sha256msg2_epu32(msg0, msg3);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);
    msg3 = _mm_sha256msg1_epu32(msg3, msg0);

    // Rounds 48-51
    msg = _mm_add_epi32(msg0, _mm_loadu_si128(K.as_ptr().add(48) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg0, msg3, 4);
    msg1 = _mm_add_epi32(msg1, tmp);
    msg1 = _mm_sha256msg2_epu32(msg1, msg0);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);

    // Rounds 52-55
    msg = _mm_add_epi32(msg1, _mm_loadu_si128(K.as_ptr().add(52) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg1, msg0, 4);
    msg2 = _mm_add_epi32(msg2, tmp);
    msg2 = _mm_sha256msg2_epu32(msg2, msg1);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);

    // Rounds 56-59
    msg = _mm_add_epi32(msg2, _mm_loadu_si128(K.as_ptr().add(56) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    let tmp = _mm_alignr_epi8(msg2, msg1, 4);
    msg3 = _mm_add_epi32(msg3, tmp);
    msg3 = _mm_sha256msg2_epu32(msg3, msg2);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);

    // Rounds 60-63
    msg = _mm_add_epi32(msg3, _mm_loadu_si128(K.as_ptr().add(60) as *const __m128i));
    state1 = _mm_sha256rnds2_epu32(state1, state0, msg);
    msg = _mm_shuffle_epi32(msg, 0x0E);
    state0 = _mm_sha256rnds2_epu32(state0, state1, msg);

    // Add original state back
    state0 = _mm_add_epi32(state0, orig_state0);
    state1 = _mm_add_epi32(state1, orig_state1);

    // Shuffle back from [d,c,b,a] to [a,b,c,d]
    state0 = _mm_shuffle_epi8(state0, shuf_mask);
    state1 = _mm_shuffle_epi8(state1, shuf_mask);

    // Store result
    _mm_storeu_si128(state.as_mut_ptr() as *mut __m128i, state0);
    _mm_storeu_si128(state.as_mut_ptr().add(4) as *mut __m128i, state1);
}

// ============================================================================
// ARM SHA-2 NEON Implementation (aarch64)
// ============================================================================

/// Intrinsic-based SHA-2 NEON compression (retained for asm validation tests).
#[cfg(all(target_arch = "aarch64", test))]
#[target_feature(enable = "sha2", enable = "neon")]
unsafe fn compress_sha2_neon(state: &mut [u32; 8], block: &[u8; 64]) {
    use std::arch::aarch64::*;

    // Load initial state into NEON registers
    // ARM SHA-2 uses: ABCD in one register, EFGH in another
    let mut abcd = vld1q_u32(state.as_ptr());
    let mut efgh = vld1q_u32(state.as_ptr().add(4));

    // Save original state for final addition
    let abcd_orig = abcd;
    let efgh_orig = efgh;

    // Load message block (big-endian to native conversion)
    // Load 4 128-bit vectors (16 u32 words total)
    let mut msg0 = vreinterpretq_u32_u8(vrev32q_u8(vld1q_u8(block.as_ptr())));
    let mut msg1 = vreinterpretq_u32_u8(vrev32q_u8(vld1q_u8(block.as_ptr().add(16))));
    let mut msg2 = vreinterpretq_u32_u8(vrev32q_u8(vld1q_u8(block.as_ptr().add(32))));
    let mut msg3 = vreinterpretq_u32_u8(vrev32q_u8(vld1q_u8(block.as_ptr().add(48))));

    // Rounds 0-3
    let mut tmp = vaddq_u32(msg0, vld1q_u32(K.as_ptr()));
    let mut tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg0 = vsha256su0q_u32(msg0, msg1);

    // Rounds 4-7
    tmp = vaddq_u32(msg1, vld1q_u32(K.as_ptr().add(4)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg0 = vsha256su1q_u32(msg0, msg2, msg3);
    msg1 = vsha256su0q_u32(msg1, msg2);

    // Rounds 8-11
    tmp = vaddq_u32(msg2, vld1q_u32(K.as_ptr().add(8)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg1 = vsha256su1q_u32(msg1, msg3, msg0);
    msg2 = vsha256su0q_u32(msg2, msg3);

    // Rounds 12-15
    tmp = vaddq_u32(msg3, vld1q_u32(K.as_ptr().add(12)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg2 = vsha256su1q_u32(msg2, msg0, msg1);
    msg3 = vsha256su0q_u32(msg3, msg0);

    // Rounds 16-19
    tmp = vaddq_u32(msg0, vld1q_u32(K.as_ptr().add(16)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg3 = vsha256su1q_u32(msg3, msg1, msg2);
    msg0 = vsha256su0q_u32(msg0, msg1);

    // Rounds 20-23
    tmp = vaddq_u32(msg1, vld1q_u32(K.as_ptr().add(20)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg0 = vsha256su1q_u32(msg0, msg2, msg3);
    msg1 = vsha256su0q_u32(msg1, msg2);

    // Rounds 24-27
    tmp = vaddq_u32(msg2, vld1q_u32(K.as_ptr().add(24)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg1 = vsha256su1q_u32(msg1, msg3, msg0);
    msg2 = vsha256su0q_u32(msg2, msg3);

    // Rounds 28-31
    tmp = vaddq_u32(msg3, vld1q_u32(K.as_ptr().add(28)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg2 = vsha256su1q_u32(msg2, msg0, msg1);
    msg3 = vsha256su0q_u32(msg3, msg0);

    // Rounds 32-35
    tmp = vaddq_u32(msg0, vld1q_u32(K.as_ptr().add(32)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg3 = vsha256su1q_u32(msg3, msg1, msg2);
    msg0 = vsha256su0q_u32(msg0, msg1);

    // Rounds 36-39
    tmp = vaddq_u32(msg1, vld1q_u32(K.as_ptr().add(36)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg0 = vsha256su1q_u32(msg0, msg2, msg3);
    msg1 = vsha256su0q_u32(msg1, msg2);

    // Rounds 40-43
    tmp = vaddq_u32(msg2, vld1q_u32(K.as_ptr().add(40)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg1 = vsha256su1q_u32(msg1, msg3, msg0);
    msg2 = vsha256su0q_u32(msg2, msg3);

    // Rounds 44-47
    tmp = vaddq_u32(msg3, vld1q_u32(K.as_ptr().add(44)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg2 = vsha256su1q_u32(msg2, msg0, msg1);
    msg3 = vsha256su0q_u32(msg3, msg0);

    // Rounds 48-51
    tmp = vaddq_u32(msg0, vld1q_u32(K.as_ptr().add(48)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);
    msg3 = vsha256su1q_u32(msg3, msg1, msg2);

    // Rounds 52-55
    tmp = vaddq_u32(msg1, vld1q_u32(K.as_ptr().add(52)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);

    // Rounds 56-59
    tmp = vaddq_u32(msg2, vld1q_u32(K.as_ptr().add(56)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);

    // Rounds 60-63
    tmp = vaddq_u32(msg3, vld1q_u32(K.as_ptr().add(60)));
    tmp2 = abcd;
    abcd = vsha256hq_u32(abcd, efgh, tmp);
    efgh = vsha256h2q_u32(efgh, tmp2, tmp);

    // Add original state back
    abcd = vaddq_u32(abcd, abcd_orig);
    efgh = vaddq_u32(efgh, efgh_orig);

    // Store result
    vst1q_u32(state.as_mut_ptr(), abcd);
    vst1q_u32(state.as_mut_ptr().add(4), efgh);
}

// ============================================================================
// ARM SHA-2 Inline Assembly (aarch64)
// ============================================================================

/// SHA-2 compression using inline assembly for aarch64.
///
/// Replaces intrinsic-based `compress_sha2_neon` with hand-tuned `asm!` blocks.
/// Benefits: explicit register allocation, eliminates intrinsic function call
/// overhead, enables precise instruction scheduling for SHA-2 + message schedule
/// overlap.
///
/// # Safety
///
/// Caller must ensure SHA-2 is supported (`has_sha_ni()` returns true on aarch64).
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "sha2", enable = "neon")]
unsafe fn compress_sha2_asm(state: &mut [u32; 8], block: &[u8; 64]) {
    use std::arch::asm;

    let k_ptr = K.as_ptr();

    asm!(
        // Load state: v0 = ABCD, v1 = EFGH
        "ld1 {{v0.4s, v1.4s}}, [{state}]",

        // Save original state for final addition
        "mov v16.16b, v0.16b",
        "mov v17.16b, v1.16b",

        // Load message block with byte reversal (BE → native)
        "ld1 {{v4.16b, v5.16b, v6.16b, v7.16b}}, [{block}]",
        "rev32 v4.16b, v4.16b",
        "rev32 v5.16b, v5.16b",
        "rev32 v6.16b, v6.16b",
        "rev32 v7.16b, v7.16b",

        // Load K constants (rounds 0-15)
        "ld1 {{v20.4s, v21.4s, v22.4s, v23.4s}}, [{k}], #64",

        // Rounds 0-3
        "add v18.4s, v4.4s, v20.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su0 v4.4s, v5.4s",

        // Rounds 4-7
        "add v18.4s, v5.4s, v21.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v4.4s, v6.4s, v7.4s",
        "sha256su0 v5.4s, v6.4s",

        // Rounds 8-11
        "add v18.4s, v6.4s, v22.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v5.4s, v7.4s, v4.4s",
        "sha256su0 v6.4s, v7.4s",

        // Rounds 12-15
        "add v18.4s, v7.4s, v23.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v6.4s, v4.4s, v5.4s",
        "sha256su0 v7.4s, v4.4s",

        // Load K constants (rounds 16-31)
        "ld1 {{v20.4s, v21.4s, v22.4s, v23.4s}}, [{k}], #64",

        // Rounds 16-19
        "add v18.4s, v4.4s, v20.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v7.4s, v5.4s, v6.4s",
        "sha256su0 v4.4s, v5.4s",

        // Rounds 20-23
        "add v18.4s, v5.4s, v21.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v4.4s, v6.4s, v7.4s",
        "sha256su0 v5.4s, v6.4s",

        // Rounds 24-27
        "add v18.4s, v6.4s, v22.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v5.4s, v7.4s, v4.4s",
        "sha256su0 v6.4s, v7.4s",

        // Rounds 28-31
        "add v18.4s, v7.4s, v23.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v6.4s, v4.4s, v5.4s",
        "sha256su0 v7.4s, v4.4s",

        // Load K constants (rounds 32-47)
        "ld1 {{v20.4s, v21.4s, v22.4s, v23.4s}}, [{k}], #64",

        // Rounds 32-35
        "add v18.4s, v4.4s, v20.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v7.4s, v5.4s, v6.4s",
        "sha256su0 v4.4s, v5.4s",

        // Rounds 36-39
        "add v18.4s, v5.4s, v21.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v4.4s, v6.4s, v7.4s",
        "sha256su0 v5.4s, v6.4s",

        // Rounds 40-43
        "add v18.4s, v6.4s, v22.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v5.4s, v7.4s, v4.4s",
        "sha256su0 v6.4s, v7.4s",

        // Rounds 44-47
        "add v18.4s, v7.4s, v23.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v6.4s, v4.4s, v5.4s",
        "sha256su0 v7.4s, v4.4s",

        // Load K constants (rounds 48-63)
        "ld1 {{v20.4s, v21.4s, v22.4s, v23.4s}}, [{k}], #64",

        // Rounds 48-51
        "add v18.4s, v4.4s, v20.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",
        "sha256su1 v7.4s, v5.4s, v6.4s",

        // Rounds 52-55
        "add v18.4s, v5.4s, v21.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",

        // Rounds 56-59
        "add v18.4s, v6.4s, v22.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",

        // Rounds 60-63
        "add v18.4s, v7.4s, v23.4s",
        "mov v19.16b, v0.16b",
        "sha256h q0, q1, v18.4s",
        "sha256h2 q1, q19, v18.4s",

        // Add original state
        "add v0.4s, v0.4s, v16.4s",
        "add v1.4s, v1.4s, v17.4s",

        // Store result
        "st1 {{v0.4s, v1.4s}}, [{state}]",

        state = in(reg) state.as_mut_ptr(),
        block = in(reg) block.as_ptr(),
        k = inout(reg) k_ptr => _,
        // Clobbered NEON registers
        out("v0") _, out("v1") _,
        out("v4") _, out("v5") _, out("v6") _, out("v7") _,
        out("v16") _, out("v17") _,
        out("v18") _, out("v19") _,
        out("v20") _, out("v21") _, out("v22") _, out("v23") _,
        options(nostack),
    );
}

/// Second-hash compression returning raw state words (no byte conversion).
///
/// Returns `[u32; 8]` state directly, avoiding the ~2 ns `state_to_bytes()`
/// conversion when only the raw state is needed.
#[inline]
pub fn compress_second_hash_state(first_hash_state: &[u32; 8]) -> [u32; 8] {
    #[cfg(target_arch = "x86_64")]
    {
        if has_sha_ni() {
            return compress_second_hash_hw_state(first_hash_state);
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_sha_ni() {
            return compress_second_hash_hw_state(first_hash_state);
        }
    }
    crate::compress::compress_second_hash_state(first_hash_state)
}

/// HW-accelerated second-hash returning raw state words.
#[cfg(any(target_arch = "x86_64", target_arch = "aarch64"))]
#[inline]
fn compress_second_hash_hw_state(first_hash_state: &[u32; 8]) -> [u32; 8] {
    let mut block = [0u8; 64];
    for (i, &word) in first_hash_state.iter().enumerate() {
        block[i * 4..(i + 1) * 4].copy_from_slice(&word.to_be_bytes());
    }
    block[32] = 0x80;
    block[62] = 0x01;
    block[63] = 0x00;
    let mut state = H0;
    compress(&mut state, &block);
    state
}

/// Second-hash compression with automatic hardware dispatch.
///
/// Takes the first hash state as u32 words and produces the double-SHA256
/// output bytes. On SIMD platforms, builds the block and uses hardware
/// compression. On scalar, uses the optimized direct-u32 path.
#[inline]
pub fn compress_second_hash(first_hash_state: &[u32; 8]) -> [u8; 32] {
    state_to_bytes(&compress_second_hash_state(first_hash_state))
}

/// SHA-256 double hash with hardware acceleration.
///
/// Computes SHA256(SHA256(data)) efficiently.
#[inline]
pub fn double_sha256_fast(data: &[u8]) -> [u8; 32] {
    // First hash
    let mut state = H0;
    let mut offset = 0;

    // Process complete 64-byte blocks
    while offset + 64 <= data.len() {
        let block: &[u8; 64] = data[offset..offset + 64].try_into().unwrap();
        compress(&mut state, block);
        offset += 64;
    }

    // Pad and process remaining data
    let remaining = data.len() - offset;
    let total_bits = (data.len() as u64) * 8;

    let mut final_block = [0u8; 64];
    if remaining > 0 {
        final_block[..remaining].copy_from_slice(&data[offset..]);
    }
    final_block[remaining] = 0x80;

    if remaining >= 56 {
        // Need two blocks for padding
        compress(&mut state, &final_block);
        final_block = [0u8; 64];
    }

    // Add length in bits (big-endian)
    final_block[56..64].copy_from_slice(&total_bits.to_be_bytes());
    compress(&mut state, &final_block);

    // Second hash: pass state directly, skip state→bytes→block roundtrip
    compress_second_hash(&state)
}
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_compress_matches_scalar() {
        let block = [0x61u8; 64]; // 'a' repeated

        let mut state_scalar = H0;
        compress_scalar(&mut state_scalar, &block);

        let mut state_simd = H0;
        compress(&mut state_simd, &block);

        assert_eq!(state_scalar, state_simd, "SIMD compress must match scalar");
    }

    #[test]
    fn test_double_sha256_fast() {
        let data = b"hello world";
        let hash = double_sha256_fast(data);

        // Compare with standard implementation
        let expected = crate::double_sha256(data);
        assert_eq!(hash, expected.0, "double_sha256_fast must match standard");
    }

    /// Test that traces the complete state transformation for Bitcoin genesis block.
    /// This proves we're doing the actual double SHA-256 correctly.
    #[test]
    fn test_bitcoin_genesis_state_transformation() {
        // Bitcoin genesis block header (80 bytes)
        let genesis_header: [u8; 80] = [
            // Version (4 bytes, little-endian): 1
            0x01, 0x00, 0x00, 0x00,
            // Previous block hash (32 bytes): all zeros for genesis
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, // Merkle root (32 bytes)
            0x3b, 0xa3, 0xed, 0xfd, 0x7a, 0x7b, 0x12, 0xb2, 0x7a, 0xc7, 0x2c, 0x3e, 0x67, 0x76,
            0x8f, 0x61, 0x7f, 0xc8, 0x1b, 0xc3, 0x88, 0x8a, 0x51, 0x32, 0x3a, 0x9f, 0xb8, 0xaa,
            0x4b, 0x1e, 0x5e, 0x4a, // Timestamp (4 bytes): 2009-01-03 18:15:05
            0x29, 0xab, 0x5f, 0x49, // Bits/target (4 bytes): difficulty 1
            0xff, 0xff, 0x00, 0x1d, // Nonce (4 bytes): 2083236893
            0x1d, 0xac, 0x2b, 0x7c,
        ];

        // === FIRST SHA-256 ===
        // State starts at H0
        let mut state1 = H0;
        println!("Initial state (H0): {:08x?}", state1);

        // Block 1: First 64 bytes of header
        let mut block1 = [0u8; 64];
        block1.copy_from_slice(&genesis_header[..64]);
        compress(&mut state1, &block1);
        println!("After block 1 (bytes 0-63): {:08x?}", state1);

        // Block 2: Remaining 16 bytes + padding + length
        let mut block2 = [0u8; 64];
        block2[..16].copy_from_slice(&genesis_header[64..80]);
        block2[16] = 0x80; // Padding bit
                           // Length = 80 * 8 = 640 bits = 0x280
        block2[62] = 0x02;
        block2[63] = 0x80;
        compress(&mut state1, &block2);
        println!("After block 2 (padding): {:08x?}", state1);

        // Convert to first hash bytes
        let mut first_hash = [0u8; 32];
        for (i, word) in state1.iter().enumerate() {
            first_hash[i * 4..(i + 1) * 4].copy_from_slice(&word.to_be_bytes());
        }
        println!("First SHA-256 hash: {}", hex_encode(&first_hash));

        // === SECOND SHA-256 ===
        let mut state2 = H0;
        println!("\nSecond hash initial state (H0): {:08x?}", state2);

        // Single block: 32-byte hash + padding
        let mut final_block = [0u8; 64];
        final_block[..32].copy_from_slice(&first_hash);
        final_block[32] = 0x80;
        // Length = 256 bits = 0x100
        final_block[62] = 0x01;
        final_block[63] = 0x00;
        compress(&mut state2, &final_block);
        println!("After final compression: {:08x?}", state2);

        // Convert to final hash bytes
        let mut final_hash = [0u8; 32];
        for (i, word) in state2.iter().enumerate() {
            final_hash[i * 4..(i + 1) * 4].copy_from_slice(&word.to_be_bytes());
        }

        // Bitcoin displays hashes in reverse byte order
        let mut display_hash = final_hash;
        display_hash.reverse();
        println!(
            "Final double-SHA256 (display order): {}",
            hex_encode(&display_hash)
        );

        // Verify against known genesis block hash
        let expected = "000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f";
        assert_eq!(
            hex_encode(&display_hash),
            expected,
            "Genesis block hash mismatch!"
        );

        // Also verify double_sha256_fast produces the same result
        let fast_hash = double_sha256_fast(&genesis_header);
        assert_eq!(fast_hash, final_hash, "double_sha256_fast mismatch");
    }

    fn hex_encode(bytes: &[u8]) -> String {
        bytes.iter().map(|b| format!("{:02x}", b)).collect()
    }

    #[test]
    fn test_sha_ni_detection() {
        // Just ensure detection doesn't panic
        let _has_ni = has_sha_ni();
        println!("SHA-NI supported: {}", has_sha_ni());
    }

    #[test]
    #[cfg(target_arch = "x86_64")]
    fn test_sha_ni_if_available() {
        if has_sha_ni() {
            let block = [0u8; 64];
            let mut state = H0;
            unsafe {
                compress_sha_ni(&mut state, &block);
            }

            // Verify it changed state
            assert_ne!(state, H0);

            // Verify it matches scalar
            let mut state_scalar = H0;
            compress_scalar(&mut state_scalar, &block);
            assert_eq!(state, state_scalar);
        }
    }

    #[test]
    #[cfg(target_arch = "aarch64")]
    fn test_sha2_neon_if_available() {
        if has_sha_ni() {
            let block = [0u8; 64];
            let mut state = H0;
            unsafe {
                compress_sha2_neon(&mut state, &block);
            }

            // Verify it changed state
            assert_ne!(state, H0);

            // Verify it matches scalar
            let mut state_scalar = H0;
            compress_scalar(&mut state_scalar, &block);
            assert_eq!(state, state_scalar);
        }
    }

    #[test]
    #[cfg(target_arch = "aarch64")]
    fn test_sha2_neon_bitcoin_genesis() {
        if has_sha_ni() {
            // Bitcoin genesis block header
            let genesis_header: [u8; 80] = [
                0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3b, 0xa3, 0xed, 0xfd, 0x7a, 0x7b,
                0x12, 0xb2, 0x7a, 0xc7, 0x2c, 0x3e, 0x67, 0x76, 0x8f, 0x61, 0x7f, 0xc8, 0x1b, 0xc3,
                0x88, 0x8a, 0x51, 0x32, 0x3a, 0x9f, 0xb8, 0xaa, 0x4b, 0x1e, 0x5e, 0x4a, 0x29, 0xab,
                0x5f, 0x49, 0xff, 0xff, 0x00, 0x1d, 0x1d, 0xac, 0x2b, 0x7c,
            ];

            let fast_hash = double_sha256_fast(&genesis_header);
            let mut display_hash = fast_hash;
            display_hash.reverse();

            let expected = "000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f";
            let actual: String = display_hash.iter().map(|b| format!("{:02x}", b)).collect();
            assert_eq!(
                actual, expected,
                "SHA-2 NEON should produce correct Bitcoin genesis hash"
            );
        }
    }

    #[test]
    #[cfg(target_arch = "aarch64")]
    fn test_asm_matches_intrinsics_single() {
        if !has_sha_ni() {
            return;
        }
        // Verify asm compress matches intrinsic compress for many blocks
        for seed in 0..100u8 {
            let block: [u8; 64] = std::array::from_fn(|i| seed.wrapping_add(i as u8));
            let mut state_asm = H0;
            let mut state_intrinsic = H0;
            unsafe {
                compress_sha2_asm(&mut state_asm, &block);
                compress_sha2_neon(&mut state_intrinsic, &block);
            }
            assert_eq!(
                state_asm, state_intrinsic,
                "asm vs intrinsic mismatch at seed={seed}"
            );
        }
    }
}
