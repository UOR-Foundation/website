//! Peer-to-peer networking layer.
//!
//! This module provides the P2P infrastructure for content distribution
//! and peer discovery.
//!
//! # Feature Flags
//!
//! - `iroh`: Enables production-ready P2P networking using Iroh with QUIC
//!   transport and built-in encryption. This is the recommended transport
//!   for production use.
//!
//! # Architecture
//!
//! The P2P layer is organized into several components:
//!
//! - **Protocol**: Message types and serialization (`protocol.rs`)
//! - **Transport**: Message delivery (`transport.rs` or `iroh_transport.rs`)
//! - **Discovery**: Peer and layer discovery (`discovery.rs`)
//! - **Content Store**: Content-addressed storage (`content_store.rs`)
//! - **Node**: High-level P2P node (`node.rs`)

mod content_store;
mod discovery;
mod node;
mod protocol;
mod transport;

#[cfg(feature = "iroh")]
mod iroh_transport;

pub use content_store::{
    ContentId, ContentMetadata, ContentStoreError, LocalBlobStore, LocalBlobStoreConfig,
};
pub use discovery::{Discovery, DiscoveryEvent, LayerRecord};
pub use node::{Node, NodeConfig, NodeError};
pub use protocol::{Message, MessageType, PeerId};
pub use transport::{MessageBus, TransportError};

// Iroh-based transport (production)
#[cfg(feature = "iroh")]
pub use iroh_transport::{IrohBlobStore, IrohConfig, IrohError, IrohTransport, HOLOGRAM_ALPN};

// Re-export iroh types for convenience when using the iroh feature
#[cfg(feature = "iroh")]
pub use iroh::{NodeAddr, NodeId, SecretKey};
