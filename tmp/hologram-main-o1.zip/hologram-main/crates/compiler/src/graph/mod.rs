//! Graph data structures for the compilation pipeline.
//!
//! This module provides two graph representations:
//! - [`OperationGraph`]: The user-facing input graph (immutable)
//! - [`CompileGraph`]: The internal compiler graph (mutable, uses `hologram-graph`)
//!
//! # Conversion
//!
//! Use [`crate::convert_ir`] to convert an `OperationGraph` to a `CompileGraph`
//! with full validation.

mod node;
mod properties;
mod traverse;

pub use node::{ConstantData, DType, OpKind, OpNode, OperationGraph, PadMode};
pub use properties::OpCategory;
pub use traverse::{CompileGraph, CompileOp, EpilogueChain};
