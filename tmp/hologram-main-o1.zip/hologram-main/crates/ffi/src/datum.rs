//! Datum16 FFI wrappers — Q1 datum observables and proofs across the FFI boundary.
//!
//! Wraps `ontology_gen::Datum16` and `hologram_derivation::Datum16Proof`
//! for C and WASM consumers.

use crate::core::FfiError;
use hologram_derivation::datum::Datum16Proof;
use ontology_gen::Datum16;

// ============================================================================
// FfiDatum16
// ============================================================================

/// FFI wrapper for Datum16 (Q1 16-bit datum with O(1) observables).
#[derive(Debug, Clone)]
pub struct FfiDatum16 {
    inner: Datum16,
}

impl FfiDatum16 {
    /// Create from a u16 value.
    pub fn new(value: u16) -> Self {
        Self {
            inner: Datum16::from_value(value),
        }
    }

    /// Get the underlying u16 value.
    pub fn value(&self) -> u16 {
        self.inner.value
    }

    /// O(1) stratum (Hamming weight, 0-16).
    pub fn stratum(&self) -> u8 {
        self.inner.stratum()
    }

    /// O(1) curvature (Hamming distance to successor).
    pub fn curvature(&self) -> u8 {
        self.inner.curvature()
    }

    /// High byte of the 16-bit value.
    pub fn high_byte(&self) -> u8 {
        self.inner.high_byte()
    }

    /// Low byte of the 16-bit value.
    pub fn low_byte(&self) -> u8 {
        self.inner.low_byte()
    }

    /// Braille glyph representation (two Braille characters).
    pub fn glyph(&self) -> String {
        self.inner.glyph()
    }

    /// Bit positions where the value has a 1-bit.
    pub fn spectrum(&self) -> Vec<u8> {
        self.inner.spectrum()
    }

    /// Serialize to JSON-LD string.
    pub fn to_json(&self) -> String {
        serde_json::to_string(&self.inner.to_jsonld()).unwrap_or_default()
    }
}

// ============================================================================
// FfiDatum16Proof
// ============================================================================

/// FFI wrapper for Datum16Proof (certified Q1 datum proof).
#[derive(Debug, Clone)]
pub struct FfiDatum16Proof {
    inner: Datum16Proof,
}

impl FfiDatum16Proof {
    /// Create a proof from a datum value, computing all observables.
    pub fn from_datum(value: u16) -> Self {
        Self {
            inner: Datum16Proof::from_value(value),
        }
    }

    /// Get the datum value.
    pub fn value(&self) -> u16 {
        self.inner.value
    }

    /// Get the stratum.
    pub fn stratum(&self) -> u8 {
        self.inner.stratum
    }

    /// Get the curvature.
    pub fn curvature(&self) -> u8 {
        self.inner.curvature
    }

    /// Get the glyph string.
    pub fn glyph(&self) -> String {
        self.inner.glyph.clone()
    }

    /// Get the spectrum (bit positions).
    pub fn spectrum(&self) -> Vec<u8> {
        self.inner.spectrum.clone()
    }

    /// Verify the proof by recomputing all observables.
    pub fn is_valid(&self) -> bool {
        self.inner.verify()
    }

    /// Serialize to JSON-LD string.
    pub fn to_json(&self) -> Result<String, FfiError> {
        use hologram_derivation::ToJsonLd;
        serde_json::to_string(&self.inner.to_jsonld())
            .map_err(|e| FfiError::ExecutionError(e.to_string()))
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_datum16_new() {
        let d = FfiDatum16::new(0x1234);
        assert_eq!(d.value(), 0x1234);
    }

    #[test]
    fn test_datum16_stratum() {
        assert_eq!(FfiDatum16::new(0).stratum(), 0);
        assert_eq!(FfiDatum16::new(0xFFFF).stratum(), 16);
        assert_eq!(FfiDatum16::new(0x00FF).stratum(), 8);
    }

    #[test]
    fn test_datum16_curvature() {
        assert_eq!(FfiDatum16::new(0).curvature(), 1);
        assert_eq!(FfiDatum16::new(0xFFFF).curvature(), 16);
    }

    #[test]
    fn test_datum16_bytes() {
        let d = FfiDatum16::new(0x1234);
        assert_eq!(d.high_byte(), 0x12);
        assert_eq!(d.low_byte(), 0x34);
    }

    #[test]
    fn test_datum16_glyph() {
        let d = FfiDatum16::new(0x0000);
        let glyph = d.glyph();
        assert_eq!(glyph.chars().count(), 2);
    }

    #[test]
    fn test_datum16_spectrum() {
        let d = FfiDatum16::new(0b0000_0000_0000_0101); // bits 0 and 2
        let spectrum = d.spectrum();
        assert_eq!(spectrum, vec![0, 2]);
    }

    #[test]
    fn test_datum16_to_json() {
        let d = FfiDatum16::new(0x1234);
        let json = d.to_json();
        assert!(json.contains("1234") || json.contains("4660")); // hex or decimal
    }

    // Proof tests
    #[test]
    fn test_proof_from_datum() {
        let p = FfiDatum16Proof::from_datum(0x1234);
        assert_eq!(p.value(), 0x1234);
        assert_eq!(p.stratum(), 5); // popcount(0x1234) = 5
    }

    #[test]
    fn test_proof_is_valid() {
        let p = FfiDatum16Proof::from_datum(0xFFFF);
        assert!(p.is_valid());
    }

    #[test]
    fn test_proof_observables() {
        let p = FfiDatum16Proof::from_datum(0x00FF);
        assert_eq!(p.stratum(), 8);
        assert_eq!(p.curvature(), 9); // 0xFF -> 0x100: 9 bits flip
        assert_eq!(p.spectrum().len(), 8);
    }

    #[test]
    fn test_proof_to_json() {
        let p = FfiDatum16Proof::from_datum(0x1234);
        let json = p.to_json().unwrap();
        assert!(json.contains("DatumProof"));
    }

    #[test]
    fn test_proof_glyph() {
        let p = FfiDatum16Proof::from_datum(0x0102);
        let glyph = p.glyph();
        assert!(!glyph.is_empty());
    }

    // Roundtrip: all proofs verify
    #[test]
    fn test_all_proofs_valid() {
        for v in [0u16, 1, 255, 256, 0x1234, 0xFFFF] {
            let p = FfiDatum16Proof::from_datum(v);
            assert!(p.is_valid(), "Proof invalid for value {}", v);
        }
    }
}
