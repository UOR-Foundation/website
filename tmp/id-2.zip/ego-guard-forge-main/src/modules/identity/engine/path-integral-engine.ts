/**
 * Path Integral Engine — Structured Graph Traversal for Sovereignty Value
 * ════════════════════════════════════════════════════════════════════════
 *
 * Implements T_∫(π) = 1 + β · ∫_π F(γ) dγ
 *
 * The sovereignty surface's 96 boundary edges are projected onto a 6-node
 * directed graph (the dimension torus). Each graph edge aggregates the 16
 * boundary edges between its adjacent dimension pair into a value density F(γ).
 *
 * The path integral traverses this graph:
 *   1. Start at any dimension (default: identity — the sovereign origin)
 *   2. At each node, run a verification checkpoint (is the boundary disclosure
 *      above threshold? If not, feedback loop reduces value)
 *   3. Walk to the next adjacent dimension via the value edge
 *   4. Accumulate F(γ) along the path
 *   5. Complete the circuit (6 nodes = full torus traversal)
 *
 * Key insight from V5 pathway: the path integral is NOT an additive sum.
 * Value density varies based on verification status, feedback history,
 * and the edge state distribution — a checkpoint that fails and then
 * passes after feedback carries less value than one that passes immediately.
 *
 * Pure data. No classes. No side effects.
 *
 * @module identity/engine/path-integral
 */

import type { SovereigntySurface, SovereigntyDimensionId, EdgeState } from "../types";
import type {
  ValueNode,
  ValueEdge,
  VerificationStatus,
  PathStep,
  SovereigntyValueGraph,
  PathIntegralResult,
  PathIntegralConfig,
} from "../types/path-integral";
import { SOVEREIGNTY_DIMENSIONS } from "./sovereignty-engine";

// ── Default Configuration ───────────────────────────────────────────────────

export const DEFAULT_PATH_INTEGRAL_CONFIG: PathIntegralConfig = {
  beta: 0.5,
  feedbackDecay: 0.7,
  verificationThreshold: 0.25,
  maxFeedbackIterations: 3,
};

// ── Adjacent Pairs (Torus Topology) ─────────────────────────────────────────

interface AdjacentPair {
  readonly from: SovereigntyDimensionId;
  readonly to: SovereigntyDimensionId;
  readonly pairIndex: number;
}

function getAdjacentPairs(): readonly AdjacentPair[] {
  const ids = SOVEREIGNTY_DIMENSIONS.map((d) => d.id);
  return ids.map((id, i) => ({
    from: id,
    to: ids[(i + 1) % ids.length],
    pairIndex: i,
  }));
}

const ADJACENT_PAIRS = getAdjacentPairs();

// ── Value Density Computation ───────────────────────────────────────────────

/**
 * Compute the value density F(γ) for a single graph edge.
 *
 * F(γ) is NOT a simple ratio. It accounts for:
 * - The disclosure distribution (how many of 16 edges are open)
 * - The dominant state (selective > disclosed for value — controlled exposure
 *   demonstrates sovereignty more than blanket disclosure)
 * - Feedback weight from prior verification failures
 *
 * The key V5 insight: "selective" edges carry MORE sovereignty value than
 * "disclosed" edges, because selective disclosure via ZKP proves you CHOSE
 * to reveal — the constraint creates value.
 */
function computeValueDensity(
  edgeStates: readonly EdgeState[],
  feedbackWeight: number,
): number {
  if (edgeStates.length === 0) return 0;

  // Count states
  const shielded = edgeStates.filter((s) => s === "shielded").length;
  const selective = edgeStates.filter((s) => s === "selective").length;
  const disclosed = edgeStates.filter((s) => s === "disclosed").length;

  // Value weights: selective > disclosed > shielded
  // Shielded = privacy preserved (base state, value = 0 — no assertion made)
  // Disclosed = open (value exists but unconstrained — 0.6 per edge)
  // Selective = ZKP-gated (maximum value — 1.0 per edge — proves sovereignty)
  const rawValue =
    (selective * 1.0 + disclosed * 0.6 + shielded * 0.0) / edgeStates.length;

  // Apply feedback decay
  return rawValue * feedbackWeight;
}

/** Determine the dominant state of a set of edges. */
function dominantState(edgeStates: readonly EdgeState[]): EdgeState {
  const counts: Record<EdgeState, number> = { shielded: 0, selective: 0, disclosed: 0 };
  for (const s of edgeStates) counts[s]++;

  if (counts.selective >= counts.disclosed && counts.selective >= counts.shielded) return "selective";
  if (counts.disclosed >= counts.shielded) return "disclosed";
  return "shielded";
}

// ── Graph Construction ──────────────────────────────────────────────────────

/**
 * Build the sovereignty value graph from a surface.
 * Projects 96 boundary edges onto a 6-node directed graph.
 */
export function buildValueGraph(
  surface: SovereigntySurface,
  config: PathIntegralConfig = DEFAULT_PATH_INTEGRAL_CONFIG,
): SovereigntyValueGraph {
  // Build value edges from adjacent pairs
  const valueEdges: ValueEdge[] = ADJACENT_PAIRS.map((pair) => {
    // Get the 16 boundary edges for this dimension pair
    const startIdx = pair.pairIndex * 16;
    const pairEdges = surface.edges.slice(startIdx, startIdx + 16);
    const states = pairEdges.map((e) => e.state);
    const nonShielded = states.filter((s) => s !== "shielded").length;

    return {
      id: `value-${pair.from}-${pair.to}`,
      from: pair.from,
      to: pair.to,
      valueDensity: computeValueDensity(states, 1.0), // initial: no feedback
      edgeCount: nonShielded,
      totalEdges: 16,
      dominantState: dominantState(states),
      feedbackWeight: 1.0,
      isActive: nonShielded > 0,
    };
  });

  // Build value nodes — each dimension is a verification checkpoint
  const valueNodes: ValueNode[] = SOVEREIGNTY_DIMENSIONS.map((dim) => {
    // A node's checkpoint value = average value density of its incoming/outgoing edges
    const connectedEdges = valueEdges.filter(
      (e) => e.from === dim.id || e.to === dim.id,
    );
    const avgDensity =
      connectedEdges.length > 0
        ? connectedEdges.reduce((sum, e) => sum + e.valueDensity, 0) / connectedEdges.length
        : 0;

    // Verification: passes if disclosure ratio exceeds threshold
    const status: VerificationStatus =
      avgDensity >= config.verificationThreshold ? "verified" : "unverified";

    return {
      id: dim.id,
      label: dim.label,
      verificationStatus: status,
      checkpointValue: avgDensity,
      feedbackCount: 0,
      lastVerifiedAt: status === "verified" ? Date.now() : 0,
    };
  });

  return {
    identityId: surface.identityId,
    nodes: valueNodes,
    edges: valueEdges,
    totalNodes: 6,
    totalEdges: 6,
    timestamp: Date.now(),
  };
}

// ── Path Integral Computation ───────────────────────────────────────────────

/**
 * Compute T_∫(π) = 1 + β · ∫_π F(γ) dγ
 *
 * The path traverses the full torus: identity → data → compute →
 * social → economic → governance → (back to identity).
 *
 * At each step:
 * 1. Evaluate the value edge's F(γ) (value density)
 * 2. Check the destination node's verification status
 * 3. If verification fails: trigger feedback loop
 *    - Reduce the edge's value density by feedbackDecay
 *    - Re-check up to maxFeedbackIterations times
 *    - If it eventually passes: mark as "reverified" (reduced value)
 *    - If it never passes: mark as "failed" (zero value contribution)
 * 4. Accumulate the integral
 *
 * This is fundamentally different from additive edge counting because:
 * - Feedback loops create path-dependent value (history matters)
 * - Verification gates the value (not all edges contribute equally)
 * - The constraint (bounded graph) IS the value source
 */
export function computePathIntegral(
  surface: SovereigntySurface,
  config: PathIntegralConfig = DEFAULT_PATH_INTEGRAL_CONFIG,
): PathIntegralResult {
  const graph = buildValueGraph(surface, config);
  const path: PathStep[] = [];
  let rawIntegral = 0;
  let feedbackLoops = 0;
  let verifiedCheckpoints = 0;

  // Mutable copies for feedback iteration
  const nodeStates = new Map<SovereigntyDimensionId, ValueNode>(
    graph.nodes.map((n) => [n.id, { ...n }]),
  );
  const edgeDensities = new Map<string, number>(
    graph.edges.map((e) => [e.id, e.valueDensity]),
  );

  // Traverse the torus: walk all 6 edges
  for (const pair of ADJACENT_PAIRS) {
    const edge = graph.edges.find((e) => e.from === pair.from && e.to === pair.to)!;
    const destNode = nodeStates.get(pair.to)!;

    let currentDensity = edgeDensities.get(edge.id) ?? 0;
    let verified = destNode.verificationStatus === "verified";
    let feedbackApplied = false;

    // Feedback loop: if destination checkpoint fails verification,
    // reduce value and retry (bounded by maxFeedbackIterations)
    if (!verified && currentDensity > 0) {
      let attempts = 0;
      let decayedDensity = currentDensity;

      while (attempts < config.maxFeedbackIterations) {
        decayedDensity *= config.feedbackDecay;
        attempts++;
        feedbackLoops++;
        feedbackApplied = true;

        // Re-check: does the decayed density meet threshold?
        // After feedback, we use a softer threshold (halved)
        if (decayedDensity >= config.verificationThreshold * 0.5) {
          verified = true;
          currentDensity = decayedDensity;
          nodeStates.set(pair.to, {
            ...destNode,
            verificationStatus: "reverified",
            feedbackCount: attempts,
            lastVerifiedAt: Date.now(),
          });
          break;
        }
      }

      if (!verified) {
        // Verification failed even after feedback — zero value from this segment
        currentDensity = 0;
        nodeStates.set(pair.to, {
          ...destNode,
          verificationStatus: "failed",
          feedbackCount: attempts,
        });
      }
    }

    if (verified) verifiedCheckpoints++;

    rawIntegral += currentDensity;

    path.push({
      fromNode: pair.from,
      toNode: pair.to,
      edgeId: edge.id,
      valueDensity: currentDensity,
      cumulativeValue: rawIntegral,
      verified,
      feedbackApplied,
    });
  }

  // Boundary utilization: fraction of all 96 edges that are non-shielded
  const activeEdges = surface.edges.filter((e) => e.state !== "shielded").length;
  const boundaryUtilization = activeEdges / surface.edges.length;

  return {
    identityId: surface.identityId,
    integralValue: 1 + config.beta * rawIntegral,
    rawIntegral,
    beta: config.beta,
    path,
    verifiedCheckpoints,
    feedbackLoops,
    boundaryUtilization,
    timestamp: Date.now(),
  };
}

// ── Queries ─────────────────────────────────────────────────────────────────

/** Get the value contribution of each dimension pair. */
export function pairValueBreakdown(
  result: PathIntegralResult,
): readonly { from: SovereigntyDimensionId; to: SovereigntyDimensionId; density: number; verified: boolean }[] {
  return result.path.map((step) => ({
    from: step.fromNode,
    to: step.toNode,
    density: step.valueDensity,
    verified: step.verified,
  }));
}

/** Get the strongest value path segment. */
export function strongestSegment(
  result: PathIntegralResult,
): PathStep | null {
  if (result.path.length === 0) return null;
  return result.path.reduce((best, step) =>
    step.valueDensity > best.valueDensity ? step : best,
  );
}

/** Get the weakest (bottleneck) path segment. */
export function weakestSegment(
  result: PathIntegralResult,
): PathStep | null {
  if (result.path.length === 0) return null;
  return result.path.reduce((worst, step) =>
    step.valueDensity < worst.valueDensity ? step : worst,
  );
}

/** Compute the path efficiency: actual value vs theoretical maximum. */
export function pathEfficiency(result: PathIntegralResult): number {
  // Maximum: all 6 edges at density 1.0, no feedback, beta applied
  const maxIntegral = 1 + result.beta * 6.0;
  return result.integralValue / maxIntegral;
}
