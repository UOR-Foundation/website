//! Hologram `.holo` archive format parsing and serialization.
//!
//! This crate provides zero-copy deserialization of `.holb` (single model) and
//! `.holo` (multi-model pipeline) archive formats using rkyv and memory-mapping.
//!
//! # File Extensions
//!
//! - `.holb` - HOLB (Hologram Unified Bundle): Single model with embedded weights
//! - `.holo` - HOLM (Hologram Pipeline Bundle): Multi-model pipeline with index
//! - `.tar.gz` - Multi-layer archive with manifest.toml
//!
//! # Zero-Copy Guarantee
//!
//! When memory-mapped from `.holo` files, `ArchivedBackendPlan` provides direct
//! access to instructions and constant data without deserialization.
//!
//! # Example
//!
//! ```rust,no_run
//! # use hologram_holo::*;
//! # fn example() -> Result<()> {
//! // Load a .holb file synchronously
//! let loaded = HoloLoader::load("model.holb")?;
//!
//! // Access plan instructions (zero-copy from mmap)
//! println!("Plan has {} instructions", loaded.plan().instructions.len());
//! # Ok(())
//! # }
//! ```

#![deny(missing_docs)]
#![deny(clippy::all)]
#![warn(clippy::pedantic)]
#![allow(clippy::module_name_repetitions)]
#![allow(clippy::missing_errors_doc)]
#![allow(clippy::missing_panics_doc)]
#![allow(clippy::used_underscore_binding)]

pub mod builder;
pub mod compression;
pub mod error;
pub mod format;
pub mod instruction;
pub mod layer_header;
pub mod partition;
pub mod pipeline;
pub mod reader;
pub mod section;
pub mod traits;
pub mod types;
pub mod weight_index;
pub mod weight_types;
pub mod writer;

#[cfg(feature = "async")]
pub mod loader;

// Re-exports
pub use builder::{AvgPool2dBuilder, BatchNormBuilder, Conv2dBuilder, MaxPool2dBuilder};
pub use compression::{
    compress_weights, compress_with_metadata, decompress_weights, CompressionAlgorithm,
    CompressionMetadata,
};
pub use error::{BuilderError, HoloError};
pub use format::{
    align_to_page, crc32, detect_holb_version, HolbHeader, HolbHeaderV2, HolmHeader,
    ModelIndexEntry, PipelineModelEntry, HOLB_HEADER_SIZE_V1, HOLB_HEADER_SIZE_V2, HOLB_MAGIC,
    HOLM_HEADER_SIZE, HOLM_MAGIC, PAGE_SIZE,
};
pub use instruction::{BackendPlan, IsaInstruction, LayerLocation, LayerRef, PlanMetadata};
pub use layer_header::{
    LayerDescriptor, LayerEntrypoint, LayerHeader, LayerHeaderError, LayerHeaderSection, LayerId,
    TensorPort,
};
pub use partition::{PartitionValidationError, PartitionedPlan, PlanPartition};
pub use pipeline::{HolmReader, HolmWriter};
pub use reader::HolbReader;
pub use section::{
    deserialize_sections_table, sections_table_size, serialize_sections_table, SectionTableEntry,
};
pub use traits::{CloneableSection, EmbeddableSection, FromEmbeddedSection};
pub use types::{
    lut_sizes, BufferMetadata, CategoricalOpType, FusedChain, LutSection, ObservableMetadata,
};
pub use weight_index::WeightIndexSection;
pub use weight_types::{
    QuantizationParams, QuantizationScheme, TensorMetadata, TensorMetadataBuilder, WeightDType,
};
pub use writer::HolbWriter;

#[cfg(feature = "async")]
pub use loader::{HoloLoader, LoadedPipeline, LoadedPlan, PipelineEntry};

/// Result type for holo operations.
pub type Result<T> = std::result::Result<T, HoloError>;
