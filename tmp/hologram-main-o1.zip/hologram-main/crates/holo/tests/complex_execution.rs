//! Integration tests for complex compiled graph execution.
//!
//! Tests the full pipeline from OperationGraph → compile → execute:
//! 1. Build complex operation graphs
//! 2. Compile to BackendPlan
//! 3. Execute on CpuBackend
//! 4. Verify results
//!
//! Note: Serialization/loading round-trips are tested in bundle_integration.rs.
//! These tests focus on execution correctness with complex graph structures.

use hologram_backend::backends::cpu::CpuBackend;
use hologram_backend::backends::Backend;
use hologram_compiler::{compile, CompilerConfig, DType, OpKind, OpNode, OperationGraph};

// ============================================================================
// Helper Functions
// ============================================================================

/// Convert f32 slice to byte buffer.
fn f32_to_bytes(data: &[f32]) -> Vec<u8> {
    data.iter().flat_map(|f| f.to_ne_bytes()).collect()
}

/// Convert byte buffer to f32 slice.
fn bytes_to_f32(data: &[u8]) -> Vec<f32> {
    data.chunks_exact(4)
        .map(|c| f32::from_ne_bytes([c[0], c[1], c[2], c[3]]))
        .collect()
}

/// Create a simple add graph.
fn create_add_graph(size: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![size], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![size], DType::F32);
    let add = OpNode::new(2, OpKind::Add, vec![size], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![size], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(add);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("a", 0);
    graph.add_input("b", 1);
    graph.add_output("result", 3);

    graph
}

/// Create an activation chain graph (relu -> sigmoid -> tanh).
fn create_activation_chain_graph(size: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();

    let input = OpNode::new(0, OpKind::Input, vec![size], DType::F32);
    let relu = OpNode::new(1, OpKind::Relu, vec![size], DType::F32);
    let sigmoid = OpNode::new(2, OpKind::Sigmoid, vec![size], DType::F32);
    let tanh = OpNode::new(3, OpKind::Tanh, vec![size], DType::F32);
    let output = OpNode::new(4, OpKind::Output, vec![size], DType::F32);

    graph.add_node(input);
    graph.add_node(relu);
    graph.add_node(sigmoid);
    graph.add_node(tanh);
    graph.add_node(output);

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph.add_edge(3, 4);

    graph.add_input("x", 0);
    graph.add_output("y", 4);

    graph
}

/// Create a deep chain graph (N sequential ReLU operations).
fn create_deep_chain_graph(size: usize, depth: u32) -> OperationGraph {
    let mut graph = OperationGraph::new();

    // Input
    let input = OpNode::new(0, OpKind::Input, vec![size], DType::F32);
    graph.add_node(input);
    graph.add_input("x", 0);

    // Chain of ReLU nodes
    for i in 1..=depth {
        let relu = OpNode::new(i, OpKind::Relu, vec![size], DType::F32);
        graph.add_node(relu);
        graph.add_edge(i - 1, i);
    }

    // Output
    let output = OpNode::new(depth + 1, OpKind::Output, vec![size], DType::F32);
    graph.add_node(output);
    graph.add_edge(depth, depth + 1);
    graph.add_output("y", depth + 1);

    graph
}

/// Create a MatMul graph (A * B).
fn create_matmul_graph(m: usize, k: usize, n: usize) -> OperationGraph {
    let mut graph = OperationGraph::new();

    let input_a = OpNode::new(0, OpKind::Input, vec![m, k], DType::F32);
    let input_b = OpNode::new(1, OpKind::Input, vec![k, n], DType::F32);
    let matmul = OpNode::new(2, OpKind::MatMul { m, k, n }, vec![m, n], DType::F32);
    let output = OpNode::new(3, OpKind::Output, vec![m, n], DType::F32);

    graph.add_node(input_a);
    graph.add_node(input_b);
    graph.add_node(matmul);
    graph.add_node(output);

    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    graph.add_input("A", 0);
    graph.add_input("B", 1);
    graph.add_output("result", 3);

    graph
}

// ============================================================================
// Add Chain Tests
// ============================================================================

#[test]
fn test_add_chain_small() {
    let size = 64;
    let graph = create_add_graph(size);
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Prepare test data
    let a_data: Vec<f32> = (0..size).map(|i| i as f32).collect();
    let b_data: Vec<f32> = (0..size).map(|i| (size - i) as f32).collect();
    let a = f32_to_bytes(&a_data);
    let b = f32_to_bytes(&b_data);

    // Execute
    let backend = CpuBackend::new();
    let mut output = vec![0u8; size * 4];
    backend
        .execute_plan(&plan, &[&a, &b], &mut [&mut output])
        .expect("execution failed");

    // Verify: a[i] + b[i] = i + (size - i) = size for all i
    let result = bytes_to_f32(&output);
    for (i, &val) in result.iter().enumerate() {
        let expected = a_data[i] + b_data[i];
        assert!(
            (val - expected).abs() < 1e-6,
            "Mismatch at index {i}: got {val}, expected {expected}"
        );
    }
}

#[test]
fn test_add_chain_large() {
    let size = 16384;
    let graph = create_add_graph(size);
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Prepare test data
    let a_data: Vec<f32> = (0..size).map(|i| (i as f32) * 0.001).collect();
    let b_data: Vec<f32> = (0..size).map(|i| (i as f32) * 0.002).collect();
    let a = f32_to_bytes(&a_data);
    let b = f32_to_bytes(&b_data);

    // Execute
    let backend = CpuBackend::new();
    let mut output = vec![0u8; size * 4];
    backend
        .execute_plan(&plan, &[&a, &b], &mut [&mut output])
        .expect("execution failed");

    // Verify: a[i] + b[i] = i*0.001 + i*0.002 = i*0.003
    let result = bytes_to_f32(&output);
    for (i, &val) in result.iter().enumerate() {
        let expected = a_data[i] + b_data[i];
        assert!(
            (val - expected).abs() < 1e-5,
            "Mismatch at index {i}: got {val}, expected {expected}"
        );
    }
}

// ============================================================================
// Activation Chain Tests
// ============================================================================

#[test]
fn test_activation_chain_small() {
    let size = 64;
    let graph = create_activation_chain_graph(size);
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Prepare test data: values centered around 0
    let x_data: Vec<f32> = (0..size)
        .map(|i| (i as f32 - size as f32 / 2.0) / 10.0)
        .collect();
    let x = f32_to_bytes(&x_data);

    // Execute
    let backend = CpuBackend::new();
    let mut output = vec![0u8; size * 4];
    backend
        .execute_plan(&plan, &[&x], &mut [&mut output])
        .expect("execution failed");

    // Verify output values are valid (tanh output range is [-1, 1])
    // Note: Exact chain execution order verification is complex due to
    // how the compiler may optimize/reorder operations. We verify the
    // output is a valid tanh result.
    let result = bytes_to_f32(&output);
    assert_eq!(result.len(), size, "Output length mismatch");
    for (i, &val) in result.iter().enumerate() {
        assert!(val.is_finite(), "Output at index {i} is not finite: {val}");
        assert!(
            (-1.0..=1.0).contains(&val),
            "Output at index {i} is outside tanh range: {val}"
        );
    }
}

#[test]
fn test_activation_chain_large() {
    let size = 4096;
    let graph = create_activation_chain_graph(size);
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Prepare test data
    let x_data: Vec<f32> = (0..size)
        .map(|i| (i as f32 - size as f32 / 2.0) / 100.0)
        .collect();
    let x = f32_to_bytes(&x_data);

    // Execute
    let backend = CpuBackend::new();
    let mut output = vec![0u8; size * 4];
    backend
        .execute_plan(&plan, &[&x], &mut [&mut output])
        .expect("execution failed");

    // Verify output is in valid range for tanh (between -1 and 1)
    let result = bytes_to_f32(&output);
    for (i, &val) in result.iter().enumerate() {
        assert!(
            (-1.0..=1.0).contains(&val),
            "Output at index {i} is out of tanh range: {val}"
        );
    }
}

// ============================================================================
// Deep Chain Tests
// ============================================================================

#[test]
fn test_deep_chain_5() {
    let size = 256;
    let depth = 5;
    let graph = create_deep_chain_graph(size, depth);
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Prepare test data (mix of positive and negative values)
    let x_data: Vec<f32> = (0..size).map(|i| i as f32 - 128.0).collect();
    let x = f32_to_bytes(&x_data);

    // Execute
    let backend = CpuBackend::new();
    let mut output = vec![0u8; size * 4];
    backend
        .execute_plan(&plan, &[&x], &mut [&mut output])
        .expect("execution failed");

    // After 5 ReLUs, all values should be max(0, x)
    // (Multiple ReLUs on already-ReLU'd values don't change anything)
    let result = bytes_to_f32(&output);
    for (i, &val) in result.iter().enumerate() {
        let expected = x_data[i].max(0.0);
        assert!(
            (val - expected).abs() < 1e-6,
            "Mismatch at index {i}: got {val}, expected {expected}"
        );
    }
}

#[test]
fn test_deep_chain_20() {
    let size = 1024;
    let depth = 20;
    let graph = create_deep_chain_graph(size, depth);
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Prepare test data
    let x_data: Vec<f32> = (0..size).map(|i| i as f32 - 512.0).collect();
    let x = f32_to_bytes(&x_data);

    // Execute
    let backend = CpuBackend::new();
    let mut output = vec![0u8; size * 4];
    backend
        .execute_plan(&plan, &[&x], &mut [&mut output])
        .expect("execution failed");

    // Verify output
    let result = bytes_to_f32(&output);
    for (i, &val) in result.iter().enumerate() {
        let expected = x_data[i].max(0.0);
        assert!(
            (val - expected).abs() < 1e-6,
            "Mismatch at index {i}: got {val}, expected {expected}"
        );
    }
}

// ============================================================================
// MatMul Tests
// ============================================================================

#[test]
fn test_matmul_small() {
    let m = 4;
    let k = 4;
    let n = 4;
    let graph = create_matmul_graph(m, k, n);
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Create identity matrices
    let mut a_data = vec![0.0f32; m * k];
    let mut b_data = vec![0.0f32; k * n];
    for i in 0..m.min(k) {
        a_data[i * k + i] = 1.0;
    }
    for i in 0..k.min(n) {
        b_data[i * n + i] = 1.0;
    }

    let a = f32_to_bytes(&a_data);
    let b = f32_to_bytes(&b_data);

    // Execute
    let backend = CpuBackend::new();
    let mut output = vec![0u8; m * n * 4];
    backend
        .execute_plan(&plan, &[&a, &b], &mut [&mut output])
        .expect("execution failed");

    // I * I = I
    let result = bytes_to_f32(&output);
    for i in 0..m {
        for j in 0..n {
            let expected = if i == j { 1.0 } else { 0.0 };
            let val = result[i * n + j];
            assert!(
                (val - expected).abs() < 1e-6,
                "Mismatch at ({i}, {j}): got {val}, expected {expected}"
            );
        }
    }
}

#[test]
fn test_matmul_rectangular() {
    let m = 8;
    let k = 16;
    let n = 4;
    let graph = create_matmul_graph(m, k, n);
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Create test matrices
    let a_data: Vec<f32> = (0..m * k).map(|i| (i % 10) as f32).collect();
    let b_data: Vec<f32> = (0..k * n).map(|i| ((i + 5) % 10) as f32).collect();

    let a = f32_to_bytes(&a_data);
    let b = f32_to_bytes(&b_data);

    // Execute
    let backend = CpuBackend::new();
    let mut output = vec![0u8; m * n * 4];
    backend
        .execute_plan(&plan, &[&a, &b], &mut [&mut output])
        .expect("execution failed");

    // Verify against naive matmul
    let result = bytes_to_f32(&output);
    for i in 0..m {
        for j in 0..n {
            let mut expected = 0.0f32;
            for p in 0..k {
                expected += a_data[i * k + p] * b_data[p * n + j];
            }
            let val = result[i * n + j];
            assert!(
                (val - expected).abs() < 1e-3,
                "Mismatch at ({i}, {j}): got {val}, expected {expected}"
            );
        }
    }
}

#[test]
fn test_matmul_large() {
    let m = 64;
    let k = 64;
    let n = 64;
    let graph = create_matmul_graph(m, k, n);
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    // Create random-ish matrices
    let a_data: Vec<f32> = (0..m * k).map(|i| ((i * 7) % 100) as f32 / 100.0).collect();
    let b_data: Vec<f32> = (0..k * n)
        .map(|i| ((i * 11) % 100) as f32 / 100.0)
        .collect();

    let a = f32_to_bytes(&a_data);
    let b = f32_to_bytes(&b_data);

    // Execute
    let backend = CpuBackend::new();
    let mut output = vec![0u8; m * n * 4];
    backend
        .execute_plan(&plan, &[&a, &b], &mut [&mut output])
        .expect("execution failed");

    // Spot-check a few elements against naive matmul
    let result = bytes_to_f32(&output);
    for (i, j) in [
        (0, 0),
        (0, n - 1),
        (m - 1, 0),
        (m - 1, n - 1),
        (m / 2, n / 2),
    ] {
        let mut expected = 0.0f32;
        for p in 0..k {
            expected += a_data[i * k + p] * b_data[p * n + j];
        }
        let val = result[i * n + j];
        assert!(
            (val - expected).abs() < 1e-2,
            "Mismatch at ({i}, {j}): got {val}, expected {expected}"
        );
    }
}
