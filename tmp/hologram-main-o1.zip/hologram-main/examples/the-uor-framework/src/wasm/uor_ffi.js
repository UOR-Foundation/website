/* @ts-self-types="./uor_ffi.d.ts" */

/**
 * A cell address on the toroidal boundary (index in [0, 12287]).
 */
export class Cell {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(Cell.prototype);
        obj.__wbg_ptr = ptr;
        CellFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CellFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_cell_free(ptr, 0);
    }
    /**
     * Calculate the distance to another cell.
     * @param {Cell} other
     * @returns {number}
     */
    distanceTo(other) {
        _assertClass(other, Cell);
        const ret = wasm.cell_distanceTo(this.__wbg_ptr, other.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Create a new cell with the given index.
     * The index wraps around at 12288 (BOUNDARY_SIZE).
     * @param {number} index
     */
    constructor(index) {
        const ret = wasm.cell_new(index);
        this.__wbg_ptr = ret >>> 0;
        CellFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Get the next cell (wraps around).
     * @returns {Cell}
     */
    next() {
        const ret = wasm.cell_next(this.__wbg_ptr);
        return Cell.__wrap(ret);
    }
    /**
     * Offset the cell by a signed delta.
     * @param {number} delta
     * @returns {Cell}
     */
    offset(delta) {
        const ret = wasm.cell_offset(this.__wbg_ptr, delta);
        return Cell.__wrap(ret);
    }
    /**
     * Get the previous cell (wraps around).
     * @returns {Cell}
     */
    prev() {
        const ret = wasm.cell_prev(this.__wbg_ptr);
        return Cell.__wrap(ret);
    }
    /**
     * The cell index (0-12287).
     * @returns {number}
     */
    get index() {
        const ret = wasm.__wbg_get_cell_index(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) Cell.prototype[Symbol.dispose] = Cell.prototype.free;

/**
 * Registry of available codecs.
 *
 * This is a placeholder - full codec support will be implemented later.
 */
export class CodecRegistry {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CodecRegistryFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_codecregistry_free(ptr, 0);
    }
    /**
     * Get a codec by name.
     *
     * Always returns None (placeholder).
     * @param {string} _name
     * @returns {FfiCodec | undefined}
     */
    getCodec(_name) {
        const ptr0 = passStringToWasm0(_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.codecregistry_getCodec(this.__wbg_ptr, ptr0, len0);
        return ret === 0 ? undefined : FfiCodec.__wrap(ret);
    }
    /**
     * List available codec names.
     *
     * Returns an empty array (placeholder).
     * @returns {any[]}
     */
    listCodecs() {
        const ret = wasm.codecregistry_listCodecs(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Create a new codec registry.
     */
    constructor() {
        const ret = wasm.codecregistry_new();
        this.__wbg_ptr = ret >>> 0;
        CodecRegistryFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) CodecRegistry.prototype[Symbol.dispose] = CodecRegistry.prototype.free;

/**
 * A codec for encoding/decoding data.
 *
 * This is a placeholder - full codec support will be implemented later.
 */
export class FfiCodec {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(FfiCodec.prototype);
        obj.__wbg_ptr = ptr;
        FfiCodecFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FfiCodecFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fficodec_free(ptr, 0);
    }
    /**
     * Decode data using this codec.
     *
     * Returns input unchanged (placeholder).
     * @param {Uint8Array} data
     * @returns {Uint8Array}
     */
    decode(data) {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.fficodec_decode(this.__wbg_ptr, ptr0, len0);
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * Encode data using this codec.
     *
     * Returns input unchanged (placeholder).
     * @param {Uint8Array} data
     * @returns {Uint8Array}
     */
    encode(data) {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.fficodec_encode(this.__wbg_ptr, ptr0, len0);
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * Get the codec name.
     * @returns {string}
     */
    get name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.fficodec_name(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) FfiCodec.prototype[Symbol.dispose] = FfiCodec.prototype.free;

/**
 * Factory for creating mutation JSON strings for WASM.
 */
export class MutationFactory {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        MutationFactoryFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_mutationfactory_free(ptr, 0);
    }
    /**
     * Create an Add mutation JSON string.
     * @param {number} cell
     * @param {number} delta
     * @returns {string}
     */
    static add(cell, delta) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_add(cell, delta);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a BitwiseAnd mutation JSON string.
     * @param {number} source
     * @param {number} target
     * @returns {string}
     */
    static bitwiseAnd(source, target) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_bitwiseAnd(source, target);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a BitwiseNot mutation JSON string.
     * @param {number} cell
     * @returns {string}
     */
    static bitwiseNot(cell) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_bitwiseNot(cell);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a BitwiseOr mutation JSON string.
     * @param {number} source
     * @param {number} target
     * @returns {string}
     */
    static bitwiseOr(source, target) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_bitwiseOr(source, target);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a BitwiseXor mutation JSON string.
     * @param {number} source
     * @param {number} target
     * @returns {string}
     */
    static bitwiseXor(source, target) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_bitwiseXor(source, target);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a Fma mutation JSON string.
     * @param {number} a
     * @param {number} b
     * @param {number} target
     * @returns {string}
     */
    static fma(a, b, target) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_fma(a, b, target);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create an IndexedCopy mutation JSON string.
     * @param {number} index_cell
     * @param {number} source
     * @returns {string}
     */
    static indexedCopy(index_cell, source) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_indexedCopy(index_cell, source);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create an IndexedWrite mutation JSON string.
     * @param {number} index_cell
     * @param {number} value
     * @returns {string}
     */
    static indexedWrite(index_cell, value) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_indexedWrite(index_cell, value);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create an IndirectMulFrom mutation JSON string.
     * @param {number} base_cell
     * @param {number} offset
     * @param {number} target
     * @returns {string}
     */
    static indirectMulFrom(base_cell, offset, target) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_indirectMulFrom(base_cell, offset, target);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create an IndirectRead mutation JSON string.
     * @param {number} base_cell
     * @param {number} offset
     * @param {number} target
     * @returns {string}
     */
    static indirectRead(base_cell, offset, target) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_indirectRead(base_cell, offset, target);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a Mirror mutation JSON string.
     * @param {number} cell
     * @returns {string}
     */
    static mirror(cell) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_mirror(cell);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a Mul mutation JSON string.
     * @param {number} cell
     * @param {number} scalar
     * @returns {string}
     */
    static mul(cell, scalar) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_mul(cell, scalar);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a MulFrom mutation JSON string.
     * @param {number} source
     * @param {number} target
     * @returns {string}
     */
    static mulFrom(source, target) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_mulFrom(source, target);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a Multiply mutation JSON string.
     * @param {number} cell
     * @param {number} scalar
     * @returns {string}
     */
    static multiply(cell, scalar) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_multiply(cell, scalar);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a Set mutation JSON string.
     * @param {number} cell
     * @param {number} value
     * @returns {string}
     */
    static set(cell, value) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_set(cell, value);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a ShiftLeft mutation JSON string.
     * @param {number} cell
     * @param {number} amount
     * @returns {string}
     */
    static shiftLeft(cell, amount) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_shiftLeft(cell, amount);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a ShiftRight mutation JSON string.
     * @param {number} cell
     * @param {number} amount
     * @returns {string}
     */
    static shiftRight(cell, amount) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_shiftRight(cell, amount);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a Swap mutation JSON string.
     * @param {number} cell1
     * @param {number} cell2
     * @returns {string}
     */
    static swap(cell1, cell2) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.mutationfactory_swap(cell1, cell2);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) MutationFactory.prototype[Symbol.dispose] = MutationFactory.prototype.free;

/**
 * A mod-96 residue value (value in [0, 95]).
 */
export class Res96 {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(Res96.prototype);
        obj.__wbg_ptr = ptr;
        Res96Finalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Res96Finalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_res96_free(ptr, 0);
    }
    /**
     * The residue value (0-95).
     * @returns {number}
     */
    get value() {
        const ret = wasm.__wbg_get_cell_index(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Add another Res96 value (mod 96).
     * @param {Res96} other
     * @returns {Res96}
     */
    add(other) {
        _assertClass(other, Res96);
        const ret = wasm.res96_add(this.__wbg_ptr, other.__wbg_ptr);
        return Res96.__wrap(ret);
    }
    /**
     * Check if this is a unit (has a multiplicative inverse).
     * @returns {boolean}
     */
    isUnit() {
        const ret = wasm.res96_isUnit(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Multiply by another Res96 value (mod 96).
     * @param {Res96} other
     * @returns {Res96}
     */
    mul(other) {
        _assertClass(other, Res96);
        const ret = wasm.res96_mul(this.__wbg_ptr, other.__wbg_ptr);
        return Res96.__wrap(ret);
    }
    /**
     * Negate the value (mod 96).
     * @returns {Res96}
     */
    neg() {
        const ret = wasm.res96_neg(this.__wbg_ptr);
        return Res96.__wrap(ret);
    }
    /**
     * Create a new Res96 value (automatically reduced mod 96).
     * @param {number} value
     */
    constructor(value) {
        const ret = wasm.res96_new(value);
        this.__wbg_ptr = ret >>> 0;
        Res96Finalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * The one value (multiplicative identity).
     * @returns {Res96}
     */
    static get one() {
        const ret = wasm.res96_one();
        return Res96.__wrap(ret);
    }
    /**
     * Subtract another Res96 value (mod 96).
     * @param {Res96} other
     * @returns {Res96}
     */
    sub(other) {
        _assertClass(other, Res96);
        const ret = wasm.res96_sub(this.__wbg_ptr, other.__wbg_ptr);
        return Res96.__wrap(ret);
    }
    /**
     * Get the multiplicative inverse if it exists.
     * @returns {Res96 | undefined}
     */
    tryInverse() {
        const ret = wasm.res96_tryInverse(this.__wbg_ptr);
        return ret === 0 ? undefined : Res96.__wrap(ret);
    }
    /**
     * The zero value.
     * @returns {Res96}
     */
    static get zero() {
        const ret = wasm.res96_zero();
        return Res96.__wrap(ret);
    }
}
if (Symbol.dispose) Res96.prototype[Symbol.dispose] = Res96.prototype.free;

/**
 * The 12,288-cell toroidal boundary execution substrate.
 */
export class ToroidalBoundary {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ToroidalBoundary.prototype);
        obj.__wbg_ptr = ptr;
        ToroidalBoundaryFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ToroidalBoundaryFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_toroidalboundary_free(ptr, 0);
    }
    /**
     * Apply a batch of mutations (JSON array string).
     * @param {string} json
     */
    applyBatch(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.toroidalboundary_applyBatch(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Apply a single mutation (JSON string).
     * @param {string} json
     */
    applyMutation(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.toroidalboundary_applyMutation(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Clear all cells to zero.
     */
    clear() {
        wasm.toroidalboundary_clear(this.__wbg_ptr);
    }
    /**
     * Create a boundary from a Uint8Array.
     * @param {Uint8Array} data
     * @returns {ToroidalBoundary}
     */
    static fromUint8Array(data) {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.toroidalboundary_fromUint8Array(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ToroidalBoundary.__wrap(ret[0]);
    }
    /**
     * Get the value at a cell.
     * @param {Cell} cell
     * @returns {Res96}
     */
    get(cell) {
        _assertClass(cell, Cell);
        const ret = wasm.toroidalboundary_get(this.__wbg_ptr, cell.__wbg_ptr);
        return Res96.__wrap(ret);
    }
    /**
     * Create a new boundary with all cells set to a specific value.
     * @param {Res96} value
     * @returns {ToroidalBoundary}
     */
    static newFill(value) {
        _assertClass(value, Res96);
        const ret = wasm.toroidalboundary_newFill(value.__wbg_ptr);
        return ToroidalBoundary.__wrap(ret);
    }
    /**
     * Create a new boundary with all cells set to one.
     * @returns {ToroidalBoundary}
     */
    static newOne() {
        const ret = wasm.toroidalboundary_newOne();
        return ToroidalBoundary.__wrap(ret);
    }
    /**
     * Create a new boundary with all cells set to zero.
     * @returns {ToroidalBoundary}
     */
    static newZero() {
        const ret = wasm.toroidalboundary_newZero();
        return ToroidalBoundary.__wrap(ret);
    }
    /**
     * Set the value at a cell.
     * @param {Cell} cell
     * @param {Res96} value
     */
    set(cell, value) {
        _assertClass(cell, Cell);
        _assertClass(value, Res96);
        wasm.toroidalboundary_set(this.__wbg_ptr, cell.__wbg_ptr, value.__wbg_ptr);
    }
    /**
     * Calculate the signed budget (treating values > 47 as negative).
     * @returns {bigint}
     */
    signedBudget() {
        const ret = wasm.toroidalboundary_signedBudget(this.__wbg_ptr);
        return ret;
    }
    /**
     * Convert to a Uint8Array.
     * @returns {Uint8Array}
     */
    toUint8Array() {
        const ret = wasm.toroidalboundary_toUint8Array(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Calculate the total budget (sum of all cell values).
     * @returns {bigint}
     */
    totalBudget() {
        const ret = wasm.toroidalboundary_totalBudget(this.__wbg_ptr);
        return ret;
    }
    /**
     * Create a new boundary with all cells set to zero.
     */
    constructor() {
        const ret = wasm.toroidalboundary_newZero();
        this.__wbg_ptr = ret >>> 0;
        ToroidalBoundaryFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) ToroidalBoundary.prototype[Symbol.dispose] = ToroidalBoundary.prototype.free;

export class WasmView {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmView.prototype);
        obj.__wbg_ptr = ptr;
        WasmViewFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmViewFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmview_free(ptr, 0);
    }
    /**
     * @param {number} byte_value
     * @returns {number}
     */
    apply(byte_value) {
        const ret = wasm.wasmview_apply(this.__wbg_ptr, byte_value);
        return ret;
    }
    /**
     * @param {Uint8Array} input
     * @returns {Uint8Array}
     */
    applySlice(input) {
        const ptr0 = passArray8ToWasm0(input, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmview_applySlice(this.__wbg_ptr, ptr0, len0);
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * @param {number} value
     * @returns {WasmView}
     */
    static constant(value) {
        const ret = wasm.wasmview_constant(value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmView.__wrap(ret[0]);
    }
    constructor() {
        const ret = wasm.wasmview_identity();
        this.__wbg_ptr = ret >>> 0;
        WasmViewFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {WasmView}
     */
    inverse() {
        const ret = wasm.wasmview_inverse(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmView.__wrap(ret[0]);
    }
    /**
     * @returns {boolean}
     */
    isBijective() {
        const ret = wasm.wasmview_isBijective(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {Uint8Array}
     */
    table() {
        const ret = wasm.wasmview_table(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @param {WasmView} other
     * @returns {WasmView}
     */
    then(other) {
        _assertClass(other, WasmView);
        const ret = wasm.wasmview_then(this.__wbg_ptr, other.__wbg_ptr);
        return WasmView.__wrap(ret);
    }
}
if (Symbol.dispose) WasmView.prototype[Symbol.dispose] = WasmView.prototype.free;

/**
 * @returns {number}
 */
export function braille_base() {
    const ret = wasm.braille_base();
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function braille_max() {
    const ret = wasm.braille_max();
    return ret >>> 0;
}

/**
 * Initialize the WASM module.
 *
 * This sets up panic hooks for better error messages in the browser console.
 */
export function init() {
    wasm.init();
}

/**
 * @returns {number}
 */
export function octave_constant() {
    const ret = wasm.octave_constant();
    return ret;
}

/**
 * @returns {number}
 */
export function state_bits() {
    const ret = wasm.state_bits();
    return ret;
}

/**
 * @returns {number}
 */
export function state_taxons() {
    const ret = wasm.state_taxons();
    return ret;
}

/**
 * @returns {number}
 */
export function triadic_constant() {
    const ret = wasm.triadic_constant();
    return ret;
}

/**
 * @param {number} value
 * @returns {number}
 */
export function wasm_byte_not(value) {
    const ret = wasm.wasm_byte_not(value);
    return ret;
}

/**
 * @param {number} value
 * @returns {number}
 */
export function wasm_byte_pred(value) {
    const ret = wasm.wasm_byte_pred(value);
    return ret;
}

/**
 * @param {number} value
 * @returns {number}
 */
export function wasm_byte_rank(value) {
    const ret = wasm.wasm_byte_rank(value);
    return ret;
}

/**
 * @param {number} value
 * @returns {number}
 */
export function wasm_byte_succ(value) {
    const ret = wasm.wasm_byte_succ(value);
    return ret;
}

/**
 * @param {number} value
 * @returns {string}
 */
export function wasm_byte_to_braille(value) {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.wasm_byte_to_braille(value);
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

/**
 * @param {number} value
 * @returns {number}
 */
export function wasm_byte_to_codepoint(value) {
    const ret = wasm.wasm_byte_to_codepoint(value);
    return ret >>> 0;
}

/**
 * @param {number} value
 * @returns {number}
 */
export function wasm_byte_to_domain(value) {
    const ret = wasm.wasm_byte_to_domain(value);
    return ret;
}

function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_throw_be289d5034ed271b: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_error_7534b8e9a36f1ab4: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.error(getStringFromWasm0(arg0, arg1));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_new_8a6f238a6ece86ea: function() {
            const ret = new Error();
            return ret;
        },
        __wbg_stack_0ed75d68575b0f3c: function(arg0, arg1) {
            const ret = arg1.stack;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbindgen_cast_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./uor_ffi_bg.js": import0,
    };
}

const CellFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_cell_free(ptr >>> 0, 1));
const CodecRegistryFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_codecregistry_free(ptr >>> 0, 1));
const FfiCodecFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fficodec_free(ptr >>> 0, 1));
const MutationFactoryFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_mutationfactory_free(ptr >>> 0, 1));
const Res96Finalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_res96_free(ptr >>> 0, 1));
const ToroidalBoundaryFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_toroidalboundary_free(ptr >>> 0, 1));
const WasmViewFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmview_free(ptr >>> 0, 1));

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasm;
function __wbg_finalize_init(instance, module) {
    wasm = instance.exports;
    wasmModule = module;
    cachedDataViewMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = module.ok && expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('uor_ffi_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
