/**
 * IdentityDashboard — Your soul sanctuary.
 *
 * Full-width, immersive, warm. Every visit should feel like coming home.
 */

import { useState, useEffect, useMemo, useCallback, lazy, Suspense } from "react";
import {
  ArrowLeft,
  LogOut,
  Sun,
  Moon,
  Pencil,
  Copy,
  Check,
  BadgeCheck,
  Network,
  X,
  Loader2,
  Users,
  Sparkles,
  Link2,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useIdentity } from "../hooks";
import { useTheme } from "@/hooks/use-theme";
import { SovereigntyMap } from "../components";
import CoverImage from "../components/CoverImage";
import { AvatarUpload } from "../components/AvatarUpload";
import { IdentityJourney } from "../components/IdentityJourney";
import { EditProfileDialog } from "../components/EditProfileDialog";

const TrustGraphPage = lazy(() => import("./TrustGraphPage"));

/* ── Helpers ── */

function CopyableField({ value, label }: { value: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }, [value]);
  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-2 group text-muted-foreground/50 hover:text-muted-foreground/70 transition-colors duration-500"
    >
      <span className="text-base font-mono truncate max-w-[280px] sm:max-w-md">
        {label ? `${label}: ` : ""}{value}
      </span>
      {copied ? <Check className="h-3.5 w-3.5 text-primary" /> : <Copy className="h-3.5 w-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />}
    </button>
  );
}

export default function IdentityDashboard() {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const [entered, setEntered] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [graphOpen, setGraphOpen] = useState(false);
  const {
    profile,
    trustScore,
    surface,
    flipSurfaceEdge,
    permissions,
    togglePermission,
    ceremonies,
    updateProfile,
    exploredFacets,
    markFacetExplored,
  } = useIdentity();

  useEffect(() => {
    const t = setTimeout(() => setEntered(true), 80);
    return () => clearTimeout(t);
  }, []);

  // Verified if user has completed at least one trust ceremony (beyond founding)
  const isVerified = ceremonies.some((c) => c.type !== "founding");

  const shieldedCount = surface.edges.filter((e) => e.state === "shielded").length;
  const privacyPercent = Math.round((shieldedCount / surface.edges.length) * 100);

  return (
    <div className="min-h-screen bg-background">
      {/* ── Cover ── */}
      <div
        className="transition-opacity duration-[3s] ease-out"
        style={{ opacity: entered ? 1 : 0 }}
      >
        <CoverImage
          src={(profile as any).coverImageUrl}
          onImageChange={(url) => updateProfile({ coverImageUrl: url } as any)}
        />
      </div>

      {/* ── Header — compact on mobile ── */}
      <header
        className="fixed top-0 left-0 right-0 z-40 transition-opacity duration-[1.5s]"
        style={{ opacity: entered ? 1 : 0 }}
      >
        <div className="w-full px-4 sm:px-10 lg:px-16 h-14 sm:h-16 flex items-center">
          <button
            onClick={() => navigate("/")}
            className="p-2 -ml-2 text-foreground/40 hover:text-foreground transition-colors duration-500"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex-1" />
          <button
            onClick={toggleTheme}
            className="p-2.5 text-foreground/40 hover:text-foreground transition-colors duration-500"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
          <button
            onClick={async () => {
              await supabase.auth.signOut();
              navigate("/");
            }}
            className="flex items-center gap-2 ml-1 p-2 text-foreground/40 hover:text-foreground transition-colors duration-500"
          >
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline text-sm">Sign out</span>
          </button>
        </div>
      </header>

      {/* ── Profile Section ── */}
      <section
        className="relative z-10 w-full px-4 sm:px-10 lg:px-16 -mt-16 sm:-mt-24 pb-4 sm:pb-6 transition-all duration-[2.5s] ease-out"
        style={{
          opacity: entered ? 1 : 0,
          transform: entered ? "translateY(0)" : "translateY(40px)",
        }}
      >
        <div className="max-w-6xl mx-auto">
          {/* Avatar + Edit */}
          <div className="flex items-end justify-between mb-4 sm:mb-6">
            <AvatarUpload
              avatarUrl={(profile as any).avatarUrl}
              onAvatarChange={(url) => updateProfile({ avatarUrl: url } as any)}
            />
            <button
              onClick={() => setEditOpen(true)}
              className="flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-2.5 rounded-full border border-border/20 text-sm text-foreground/50 hover:text-foreground hover:border-border/40 transition-all duration-500"
            >
              <Pencil className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Edit profile</span>
              <span className="sm:hidden">Edit</span>
            </button>
          </div>

          {/* Name + UOR ID */}
          <div className="mb-4 sm:mb-6">
            <h1 className="text-2xl sm:text-4xl font-bold text-foreground leading-tight inline-flex items-center gap-2">
              {profile.displayName}
              {isVerified && <BadgeCheck className="h-5 sm:h-6 w-5 sm:w-6 text-primary fill-primary/20" />}
            </h1>
            <div className="mt-1.5 sm:mt-2">
              <CopyableField value={profile.id} label="UOR" />
            </div>
          </div>

          {/* Bio — hidden on very small screens if empty */}
          <div className="mb-4 sm:mb-5 max-w-3xl">
            {profile.bio ? (
              <p className="text-base sm:text-lg text-foreground/80 leading-relaxed">
                {profile.bio}
              </p>
            ) : (
              <button
                onClick={() => setEditOpen(true)}
                className="text-base sm:text-lg text-primary/40 hover:text-primary/70 transition-colors duration-500 italic"
              >
                Tell people about yourself →
              </button>
            )}
          </div>

          {/* Meta line — condensed on mobile */}
          <div className="flex flex-wrap items-center gap-x-3 sm:gap-x-4 gap-y-1 text-sm sm:text-base text-muted-foreground/50 mb-3 sm:mb-4">
            <CopyableField value={profile.handle.startsWith("@") ? profile.handle : `@${profile.handle}`} />
            <span className="text-muted-foreground/20">·</span>
            <span>{privacyPercent}% Private</span>
            <span className="hidden sm:inline text-muted-foreground/20">·</span>
            <span className="hidden sm:inline">Joined {new Date(profile.createdAt).toLocaleDateString(undefined, { month: "long", year: "numeric" })}</span>
          </div>

          {/* Social counts */}
          <div className="flex items-center gap-x-4 sm:gap-x-5 text-sm sm:text-base">
            <span>
              <strong className="text-foreground">0</strong>{" "}
              <span className="text-muted-foreground/50">Following</span>
            </span>
            <span>
              <strong className="text-foreground">0</strong>{" "}
              <span className="text-muted-foreground/50">Followers</span>
            </span>
          </div>
        </div>
      </section>

      {/* ── Divider ── */}
      <div className="w-full px-4 sm:px-10 lg:px-16 py-5 sm:py-8">
        <div className="max-w-6xl mx-auto">
          <div className="h-px bg-border/10" />
        </div>
      </div>

      {/* ── Journey ── */}
      <section
        className="relative z-10 w-full px-4 sm:px-10 lg:px-16 pb-12 sm:pb-20 transition-all duration-[2.5s] ease-out delay-150"
        style={{
          opacity: entered ? 1 : 0,
          transform: entered ? "translateY(0)" : "translateY(24px)",
        }}
      >
        <div className="max-w-6xl mx-auto">
          <IdentityJourney
            permissions={permissions}
            togglePermission={togglePermission}
            trustScore={trustScore}
            ceremonies={ceremonies}
            surface={surface}
            exploredFacets={exploredFacets}
            onFacetExplored={markFacetExplored}
          />
        </div>
      </section>

      {/* ── Privacy ── */}
      <section
        className="relative z-10 w-full px-4 sm:px-10 lg:px-16 py-12 sm:py-32 transition-all duration-[2.8s] ease-out delay-300"
        style={{
          opacity: entered ? 1 : 0,
          transform: entered ? "translateY(0)" : "translateY(24px)",
        }}
      >
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-24 items-center">
            {/* Left — Story */}
            <div className="flex flex-col justify-center">
              <p className="text-xs tracking-[0.35em] uppercase text-muted-foreground/25 mb-4 sm:mb-8">
                Your privacy
              </p>
              <h2 className="text-2xl sm:text-4xl font-display text-foreground mb-4 sm:mb-6 leading-snug">
                Your data belongs to you
              </h2>
              <p className="hidden sm:block text-lg text-muted-foreground/50 leading-relaxed mb-12">
                Every piece of information you share creates a trace. This map gives you full visibility and control.
              </p>

              {/* Steps — hidden on mobile for brevity */}
              <div className="hidden sm:block space-y-6 mb-12">
                {[
                  { n: "1", text: "Your identity spans 6 dimensions — Identity, Data, Social, Compute, Economic, and Governance." },
                  { n: "2", text: "Each dot represents a data point you control. Click any dot to change its state." },
                  { n: "3", text: "Tap a dimension label to see what's private, limited, or shared." },
                ].map((step) => (
                  <div key={step.n} className="flex items-start gap-4">
                    <div className="w-7 h-7 rounded-full bg-muted/50 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-semibold text-foreground/50">{step.n}</span>
                    </div>
                    <p className="text-base text-muted-foreground/40 leading-relaxed">
                      {step.text}
                    </p>
                  </div>
                ))}
              </div>

              {/* Legend */}
              <div className="flex flex-wrap gap-4 sm:gap-6 mb-6 sm:mb-0">
                {[
                  { color: "hsl(38, 15%, 20%)", label: "Private" },
                  { color: "hsl(38, 50%, 40%)", label: "Limited" },
                  { color: "hsl(38, 60%, 60%)", label: "Shared" },
                ].map((item) => (
                  <div key={item.label} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-xs sm:text-sm text-muted-foreground/40">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right — Map */}
            <div>
              <SovereigntyMap surface={surface} onFlipEdge={flipSurfaceEdge} />
            </div>
          </div>
        </div>
      </section>

      {/* ── Divider ── */}
      <div className="w-full px-4 sm:px-10 lg:px-16">
        <div className="max-w-6xl mx-auto">
          <div className="h-px bg-border/10" />
        </div>
      </div>

      {/* ── Trust Network CTA ── */}
      <section
        className="relative z-10 w-full px-4 sm:px-10 lg:px-16 py-12 sm:py-32 transition-all duration-[2.8s] ease-out delay-500"
        style={{
          opacity: entered ? 1 : 0,
          transform: entered ? "translateY(0)" : "translateY(24px)",
        }}
      >
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-24 items-center">
            {/* Left — Why → How → What */}
            <div className="flex flex-col justify-center">
              <p className="text-xs sm:text-sm tracking-[0.35em] uppercase text-foreground/30 mb-4 sm:mb-8">
                Your network
              </p>

              <h2 className="text-2xl sm:text-5xl font-display text-foreground mb-4 sm:mb-6 leading-tight">
                Trust is everything
              </h2>
              <p className="text-base sm:text-2xl text-foreground/60 leading-relaxed mb-8 sm:mb-14">
                Your trust network makes invisible bonds visible — so you can understand, protect, and grow them.
              </p>

              {/* HOW — condensed on mobile */}
              <p className="hidden sm:block text-sm tracking-[0.3em] uppercase text-foreground/35 mb-6 font-medium">
                How it works
              </p>
              <div className="hidden sm:block space-y-6 mb-14">
                {[
                  { icon: Users, text: "Add the people, agents, and experiences that matter to you." },
                  { icon: Link2, text: "Draw connections between them to map how trust flows." },
                  { icon: Sparkles, text: "Star your most important nodes into personal constellations." },
                ].map((step, i) => (
                  <div key={i} className="flex items-start gap-5">
                    <div className="w-10 h-10 rounded-full bg-primary/8 border border-primary/15 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <step.icon className="h-4 w-4 text-primary/70" />
                    </div>
                    <p className="text-lg sm:text-xl text-foreground/55 leading-relaxed">
                      {step.text}
                    </p>
                  </div>
                ))}
              </div>

              {/* CTA */}
              <button
                onClick={() => setGraphOpen(true)}
                className="self-start px-8 sm:px-10 py-3 sm:py-4 rounded-full border border-primary/25 text-base sm:text-lg font-medium text-primary hover:bg-primary/5 hover:border-primary/40 transition-all duration-500 group"
              >
                <span className="inline-flex items-center gap-2 sm:gap-3">
                  <Network className="h-4 sm:h-5 w-4 sm:w-5 opacity-60 group-hover:opacity-100 transition-opacity" />
                  Open Trust Network
                </span>
              </button>
            </div>

            {/* Right — Preview graphic — hidden on mobile */}
            <div
              onClick={() => setGraphOpen(true)}
              className="hidden sm:flex relative cursor-pointer group rounded-2xl border border-border/10 bg-card/30 backdrop-blur-sm flex-col items-center justify-center min-h-[420px] hover:border-border/20 hover:bg-card/50 transition-all duration-700 overflow-hidden"
            >
              {/* Animated orbital rings */}
              <div className="absolute inset-6 rounded-full border border-border/[0.04] animate-[spin_60s_linear_infinite]" />
              <div className="absolute inset-14 rounded-full border border-border/[0.06] animate-[spin_45s_linear_infinite_reverse]" />
              <div className="absolute inset-24 rounded-full border border-primary/[0.08] animate-[spin_30s_linear_infinite]" />

              {/* Ambient glow */}
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,hsl(var(--primary)/0.04),transparent_70%)]" />

              {/* Floating nodes with pulse */}
              {[
                { top: "15%", right: "25%", size: "w-3 h-3", opacity: "bg-primary/30", delay: "0s" },
                { top: "25%", left: "18%", size: "w-2.5 h-2.5", opacity: "bg-primary/20", delay: "1s" },
                { bottom: "30%", right: "15%", size: "w-2 h-2", opacity: "bg-primary/25", delay: "0.5s" },
                { bottom: "20%", left: "25%", size: "w-3.5 h-3.5", opacity: "bg-primary/15", delay: "1.5s" },
                { top: "40%", left: "12%", size: "w-2 h-2", opacity: "bg-primary/35", delay: "2s" },
                { top: "60%", right: "20%", size: "w-2.5 h-2.5", opacity: "bg-primary/20", delay: "0.8s" },
              ].map((dot, i) => (
                <div
                  key={i}
                  className={`absolute ${dot.size} rounded-full ${dot.opacity}`}
                  style={{
                    ...dot,
                    opacity: 0,
                    animation: `dot-entrance 1.2s ease-out ${0.3 + i * 0.15}s forwards, pulse 3s ease-in-out ${dot.delay} infinite`,
                  } as any}
                />
              ))}

              {/* Faint connection lines */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-[0.06]">
                <line x1="25%" y1="15%" x2="50%" y2="50%" stroke="currentColor" strokeWidth="1" className="text-primary" />
                <line x1="18%" y1="40%" x2="50%" y2="50%" stroke="currentColor" strokeWidth="1" className="text-primary" />
                <line x1="80%" y1="30%" x2="50%" y2="50%" stroke="currentColor" strokeWidth="1" className="text-primary" />
                <line x1="25%" y1="70%" x2="50%" y2="50%" stroke="currentColor" strokeWidth="1" className="text-primary" />
              </svg>

              {/* Center content */}
              <div className="relative z-10 text-center">
                <div className="w-16 h-16 rounded-full bg-primary/5 border border-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Network className="h-7 w-7 text-primary/40" />
                </div>
                <p className="text-lg font-display text-foreground/70 mb-1">Your network awaits</p>
                <p className="text-sm text-muted-foreground/30">Add your first connection to begin</p>
              </div>

              {/* Hover hint */}
              <div className="absolute bottom-6 left-0 right-0 text-center opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <p className="text-sm text-primary/40 tracking-wide font-medium">Click to explore →</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Whisper ── */}
      <div className="w-full px-4 sm:px-10 lg:px-16 pb-16 sm:pb-24">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-xs sm:text-sm tracking-[0.4em] uppercase text-muted-foreground/12 font-display">
            Your sovereign sanctuary
          </p>
        </div>
      </div>

      {/* ── Trust Graph Slide-out Panel ── */}
      {/* Backdrop */}
      <div
        className={`fixed inset-0 z-50 bg-background/80 backdrop-blur-sm transition-opacity duration-500 ${graphOpen ? "opacity-100" : "opacity-0 pointer-events-none"}`}
        onClick={() => setGraphOpen(false)}
      />
      {/* Panel */}
      <div
        className={`fixed inset-0 z-50 bg-background border-r border-border/15 shadow-2xl transition-transform duration-500 ease-out ${graphOpen ? "translate-x-0" : "-translate-x-full"}`}
      >
        {/* Close strip */}
        <button
          onClick={() => setGraphOpen(false)}
          className="absolute top-5 right-5 z-10 p-2.5 rounded-full bg-card/80 backdrop-blur-sm border border-border/20 text-foreground/50 hover:text-foreground hover:border-border/40 transition-all duration-300"
        >
          <X className="h-5 w-5" />
        </button>

        {graphOpen && (
          <Suspense fallback={
            <div className="h-full w-full flex items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-primary/40" />
            </div>
          }>
            <TrustGraphPage />
          </Suspense>
        )}
      </div>

      {/* ── Edit Dialog ── */}
      <EditProfileDialog
        open={editOpen}
        onClose={() => setEditOpen(false)}
        displayName={profile.displayName}
        handle={profile.handle}
        bio={profile.bio}
        onSaved={(updates) => updateProfile(updates)}
      />
    </div>
  );
}
