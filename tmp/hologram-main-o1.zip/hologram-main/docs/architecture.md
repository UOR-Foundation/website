# Hologram Architecture

This document describes the internal architecture of the Hologram framework, including the compilation pipeline, ISA, backend execution model, and file formats.

## Overview

Hologram transforms operation graphs into executable plans through a multi-stage compilation pipeline. The architecture follows three core principles:

1. **Zero-Copy Execution**: Plans and constants accessed directly from memory-mapped files
2. **Unified ISA**: All backends execute the same instruction set; hardware-specific implementations vary
3. **Compile-Time Decisions**: All optimization decisions made at compile time for O(1) runtime dispatch

```
OperationGraph (lazy DAG)
        ↓
CompilationPipeline (8 stages)
        ↓
BackendPlan (frozen, executable)
        ↓
.holb / .holm file (serialized)
        ↓
Backend::execute_plan()
        ↓
Results
```

## Compilation Pipeline

The compiler transforms `OperationGraph` DAGs into frozen `BackendPlan` executables through an 8-stage pipeline.

### Stage Overview

| Stage | Name | Purpose |
|-------|------|---------|
| 1 | IR Conversion | Validate graph, detect cycles, compute topological order |
| 2 | Fusion Passes | Constant folding, CSE, activation fusion, batch fusion |
| 3 | Kernel Selection | Map operations to hardware-specific kernels |
| 4 | Layout Planning | Plan memory layouts, alignment, tiling |
| 5 | Workspace Planning | Liveness analysis, buffer offset computation |
| 6 | Thread Partitioning | Build parallel levels, static thread assignment |
| 7 | Epilogue Fusion | Fuse post-ops into kernel writeback |
| 8 | Plan Assembly | Emit frozen `BackendPlan` |

### Stage Details

**Stage 1: IR Conversion**

Converts the user-provided `OperationGraph` to the internal `CompileGraph` representation. Validates structure, detects cycles, and computes topological ordering.

**Stage 2: Fusion Passes**

Applies graph optimizations:
- **Constant Folding**: Evaluate operations with all-constant inputs
- **CSE (Common Subexpression Elimination)**: Deduplicate identical operations
- **Activation Fusion**: Chain activations into lookup tables
- **Batch Fusion**: Combine sequential lookups into SIMD batches

**Stage 3: Kernel Selection**

Maps each operation to an optimal kernel based on backend capabilities (SIMD width, cache size, feature flags). Uses a cost model to choose between kernel variants.

**Stage 4: Layout Planning**

Determines memory layouts for tensor buffers:
- Memory ordering (row-major, column-major, blocked)
- Alignment requirements (32-byte for AVX2, 64-byte for AVX-512)
- Tile sizes for SIMD micro-kernels

**Stage 5: Workspace Planning**

Computes static memory offsets for intermediate buffers:
- Liveness analysis determines which buffers are active simultaneously
- Non-overlapping buffers share memory regions
- Offset assignment minimizes total workspace size

**Stage 6: Thread Partitioning**

Partitions work across threads with static assignment:
- Builds parallel levels (nodes within a level have no dependencies)
- Assigns thread IDs based on work balance
- Respects `parallel_threshold` to avoid overhead on small tasks

**Stage 7: Epilogue Fusion**

Fuses post-operations (bias addition, activation, scaling) into kernel writeback phase. Instead of separate memory passes, the kernel applies them during its final write.

**Stage 8: Plan Assembly**

Assembles the final `BackendPlan`:
- Emits ISA instructions from topological order
- Computes buffer metadata from layout decisions
- Embeds constant data (weights, lookup tables)
- Sets workspace size from workspace planning

### Compiler Configuration

```rust
CompilerConfig {
    opt_level: 2,              // 0=none, 1=basic, 2=full, 3=aggressive
    parallel_threshold: 4096,  // Min elements for parallelization
    capabilities: BackendCapabilities { ... },
}
```

## ISA (Instruction Set Architecture)

The portable ISA defines all operations that backends execute. All instructions use buffer indices that map to a unified buffer space.

### Instruction Categories

**Arithmetic Operations**
```
Add { dst, a, b, count }  // dst[i] = a[i] + b[i]
Sub { dst, a, b, count }  // dst[i] = a[i] - b[i]
Mul { dst, a, b, count }  // dst[i] = a[i] * b[i]
```

**Activation Functions**
```
Sigmoid { dst, src, count }  // dst[i] = 1 / (1 + exp(-src[i]))
Tanh    { dst, src, count }  // dst[i] = tanh(src[i])
Relu    { dst, src, count }  // dst[i] = max(0, src[i])
```

**Linear Algebra**
```
MatMul { c, a, b, m, k, n }  // C[M×N] = A[M×K] @ B[K×N]
```

**Reduction Operations**
```
Sum { dst, src, count }  // dst[0] = sum(src[i])
Max { dst, src, count }  // dst[0] = max(src[i])
Min { dst, src, count }  // dst[0] = min(src[i])
```

**Categorical Operations (UOR-specific)**
```
Lift         { dst, src, count }  // Map bytes to torus coordinates
OrbitClassify { dst, src, count } // Assign orbit class to each byte
RingAdd      { dst, a, b, count } // (a[i] + b[i]) % 96
RingMul      { dst, a, b, count } // (a[i] * b[i]) % 96
```

**Memory Operations**
```
Load  { buffer, offset, size }  // Load data into buffer
Store { buffer, offset, size }  // Store data from buffer
Copy  { dst, src, size }        // Copy between buffers
```

**Composition**
```
CallLayer { layer_id, inputs, outputs }  // Invoke sub-layer
```

**Codec Operations**
```
Encode { dst, src, codec_id, count }  // Transform through codec
Decode { dst, src, codec_id, count }  // Reverse codec transform
```

### Serialization

All instructions serialize with `rkyv` for zero-copy deserialization from memory-mapped `.holo` files.

## Backend Execution Model

The `Backend` trait defines the core execution interface:

```rust
pub trait Backend: Send + Sync {
    fn backend_type(&self) -> BackendType;

    fn execute_plan(
        &self,
        plan: &BackendPlan,
        inputs: &[&[u8]],
        outputs: &mut [&mut [u8]],
    ) -> Result<()>;

    fn capabilities(&self) -> &BackendCapabilities;
}
```

### Backend Types

| Backend | Target | Implementation |
|---------|--------|----------------|
| CPU | x86_64 (AVX2), aarch64 (NEON) | Uses `uor::arch` executors |
| WASM | WebAssembly | Linear memory model |
| CUDA | NVIDIA GPU | Direct GPU kernels |
| Metal | Apple GPU | Direct GPU kernels |

### Zero-Copy Contract

- `plan` may be an archived reference into memory-mapped file
- `plan.constants` provides zero-copy access to embedded weights
- Workspace allocated on stack or pre-allocated arena
- No heap allocation on hot paths

### Buffer Management

The `BufferManager` provides unified buffer space for plan execution:

```
Buffer Types:
├── Input     - Data copied from caller at construction
├── Output    - Data filled during execution, extracted post-execution
├── Workspace - Intermediate results, allocated per WorkspaceLayout
└── Constant  - Embedded in plan, read-only, zero-copy
```

**Lifecycle:**
1. Construction: Copy inputs, allocate workspace/outputs
2. Execution: Read/write buffers via unified index
3. Extraction: Copy output buffers back to caller

## File Formats

### HOLB Format (Single Model)

```
┌─────────────────────────────────────┐
│ HOLB Header (48-80 bytes)           │
├─────────────────────────────────────┤
│ BackendPlan (rkyv serialized)       │
├─────────────────────────────────────┤
│ Sections Table (V2 only, optional)  │
├───────────────────────────────[4KB]─┤
│ Weights (page-aligned)              │
└─────────────────────────────────────┘
```

**Header Fields:**
- Magic: `"HOLB"` (4 bytes)
- Version: 1 or 2 (u32)
- Graph offset/size (u64, u64)
- Weights offset/size (u64, u64)
- CRC32 checksums for graph and weights

### HOLM Format (Multi-Model Pipeline)

```
┌─────────────────────────────────────┐
│ HOLM Header (64 bytes)              │
├───────────────────────────────[4KB]─┤
│ Model Index Table (page-aligned)    │
├───────────────────────────────[4KB]─┤
│ Model 0 (HOLB bundle, page-aligned) │
├───────────────────────────────[4KB]─┤
│ Model 1 (HOLB bundle, page-aligned) │
├─────────────────────────────────────┤
│ ...                                 │
└─────────────────────────────────────┘
```

**Model Index Entry:**
- Name (UTF-8, length-prefixed)
- Layer ID (32-byte SHA-256 hash)
- Offset (u64, page-aligned)
- Size (u64)
- CRC32 checksum

### Design Decisions

- **Page alignment (4KB)**: Optimizes mmap access for large files
- **CRC32 checksums**: Validates data integrity
- **rkyv serialization**: Enables zero-copy deserialization
- **Content addressing**: Layers identified by SHA-256 hash

## Crate Structure

```
hologram/
├── crates/
│   ├── uor/          # Core math primitives (zero deps)
│   │   └── arch/     # Hardware executors (Zen3, NEON, Scalar)
│   ├── holo/         # .holb/.holm format, ISA definitions
│   ├── compiler/     # 8-stage compilation pipeline
│   ├── backends/     # Backend implementations
│   │   └── cpu/      # Uses uor::arch internally
│   ├── registry/     # Content-addressed layer storage
│   └── cli/          # Command-line interface
└── docs/             # Documentation
```

### Dependency Direction

```
uor (zero deps)
 ↑
holo ← compiler
 ↑        ↑
backends ←┘
 ↑
cli
```

The `uor` crate has zero external dependencies. All other crates build on top of it.
