//! System BLAS kernel override using CBLAS interface.
//!
//! Provides `cblas_sgemm` for matrix multiplication via system BLAS libraries:
//! - **macOS**: Apple Accelerate framework (`feature = "accelerate"`)
//! - **Linux**: OpenBLAS (`feature = "openblas"`)
//!
//! System BLAS implementations are highly optimized for each platform and
//! typically outperform our BLIS-packed parallel path for large matrices.
//!
//! # Usage
//!
//! ```ignore
//! // At application startup, before spawning worker threads:
//! hologram_backend::blas::register_blas_override()
//!     .expect("failed to register BLAS override");
//! ```

use crate::backends::kernel::KernelOverride;
use crate::types::Result;

// ============================================================================
// CBLAS FFI Constants
// ============================================================================

/// CBLAS row-major order (C-style layout).
const CBLAS_ROW_MAJOR: i32 = 101;

/// CBLAS no-transpose.
const CBLAS_NO_TRANS: i32 = 111;

// ============================================================================
// Platform-specific CBLAS Linking
// ============================================================================

// Accelerate framework (macOS) takes priority if both features are enabled.
#[cfg(all(feature = "accelerate", target_vendor = "apple"))]
#[link(name = "Accelerate", kind = "framework")]
extern "C" {
    fn cblas_sgemm(
        order: i32,
        trans_a: i32,
        trans_b: i32,
        m: i32,
        n: i32,
        k: i32,
        alpha: f32,
        a: *const f32,
        lda: i32,
        b: *const f32,
        ldb: i32,
        beta: f32,
        c: *mut f32,
        ldc: i32,
    );
}

// OpenBLAS (Linux) — available if:
// 1. openblas feature is enabled and accelerate is not, OR
// 2. accelerate feature is enabled but we're not on Apple (fallback)
#[cfg(any(
    all(feature = "openblas", not(feature = "accelerate")),
    all(feature = "accelerate", not(target_vendor = "apple"))
))]
#[link(name = "openblas")]
extern "C" {
    fn cblas_sgemm(
        order: i32,
        trans_a: i32,
        trans_b: i32,
        m: i32,
        n: i32,
        k: i32,
        alpha: f32,
        a: *const f32,
        lda: i32,
        b: *const f32,
        ldb: i32,
        beta: f32,
        c: *mut f32,
        ldc: i32,
    );
}

// ============================================================================
// BLAS Override Implementation
// ============================================================================

/// System BLAS kernel override.
///
/// Delegates matrix multiplication to the platform's optimized BLAS library
/// (Accelerate on macOS, OpenBLAS on Linux). All other operations fall through
/// to hologram's default implementations.
pub struct BlasOverride;

impl BlasOverride {
    /// Perform SGEMM via system BLAS.
    ///
    /// C = alpha * A @ B + beta * C, where:
    /// - A is M x K, row-major
    /// - B is K x N, row-major
    /// - C is M x N, row-major
    #[inline]
    #[allow(clippy::many_single_char_names)]
    fn sgemm(a: &[f32], b: &[f32], c: &mut [f32], m: usize, k: usize, n: usize) {
        #[allow(clippy::cast_possible_truncation, clippy::cast_possible_wrap)]
        unsafe {
            cblas_sgemm(
                CBLAS_ROW_MAJOR,
                CBLAS_NO_TRANS,
                CBLAS_NO_TRANS,
                m as i32,
                n as i32,
                k as i32,
                1.0, // alpha
                a.as_ptr(),
                k as i32, // lda = K for row-major A
                b.as_ptr(),
                n as i32, // ldb = N for row-major B
                0.0,      // beta
                c.as_mut_ptr(),
                n as i32, // ldc = N for row-major C
            );
        }
    }
}

impl KernelOverride for BlasOverride {
    #[allow(clippy::many_single_char_names)]
    fn matmul(
        &self,
        a: &[f32],
        b: &[f32],
        c: &mut [f32],
        m: usize,
        k: usize,
        n: usize,
    ) -> Option<Result<()>> {
        Self::sgemm(a, b, c, m, k, n);
        Some(Ok(()))
    }

    #[allow(clippy::many_single_char_names)]
    fn batch_matmul(
        &self,
        a: &[f32],
        b: &[f32],
        c: &mut [f32],
        batch: usize,
        m: usize,
        k: usize,
        n: usize,
    ) -> Option<Result<()>> {
        let a_stride = m * k;
        let b_stride = k * n;
        let c_stride = m * n;
        for i in 0..batch {
            let a_slice = &a[i * a_stride..(i + 1) * a_stride];
            let b_slice = &b[i * b_stride..(i + 1) * b_stride];
            let c_slice = &mut c[i * c_stride..(i + 1) * c_stride];
            Self::sgemm(a_slice, b_slice, c_slice, m, k, n);
        }
        Some(Ok(()))
    }
}

/// Register the system BLAS kernel override.
///
/// Call this once at application startup before spawning worker threads.
/// Returns `Err` if an override has already been registered.
///
/// # Example
///
/// ```ignore
/// hologram_backend::blas::register_blas_override()
///     .expect("failed to register BLAS override");
/// ```
pub fn register_blas_override() -> std::result::Result<(), &'static str> {
    crate::register_kernel_override(Box::new(BlasOverride))
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_blas_override_is_send_sync() {
        fn assert_send_sync<T: Send + Sync>() {}
        assert_send_sync::<BlasOverride>();
    }

    #[test]
    fn test_blas_matmul_basic() {
        let provider = BlasOverride;

        // 2x2 @ 2x2 identity multiplication
        // A = [[1, 0], [0, 1]]
        // B = [[5, 6], [7, 8]]
        // C = [[5, 6], [7, 8]]
        let a = [1.0, 0.0, 0.0, 1.0f32];
        let b = [5.0, 6.0, 7.0, 8.0f32];
        let mut c = [0.0f32; 4];

        let result = provider.matmul(&a, &b, &mut c, 2, 2, 2);
        assert!(result.is_some());
        assert!(result.unwrap().is_ok());
        assert!((c[0] - 5.0).abs() < 1e-5);
        assert!((c[1] - 6.0).abs() < 1e-5);
        assert!((c[2] - 7.0).abs() < 1e-5);
        assert!((c[3] - 8.0).abs() < 1e-5);
    }

    #[test]
    fn test_blas_matmul_nonsquare() {
        let provider = BlasOverride;

        // A[1x3] @ B[3x2] = C[1x2]
        // A = [[1, 2, 3]]
        // B = [[1, 4], [2, 5], [3, 6]]
        // C = [[1*1+2*2+3*3, 1*4+2*5+3*6]] = [[14, 32]]
        let a = [1.0, 2.0, 3.0f32];
        let b = [1.0, 4.0, 2.0, 5.0, 3.0, 6.0f32];
        let mut c = [0.0f32; 2];

        let result = provider.matmul(&a, &b, &mut c, 1, 3, 2);
        assert!(result.is_some());
        assert!(result.unwrap().is_ok());
        assert!((c[0] - 14.0).abs() < 1e-5);
        assert!((c[1] - 32.0).abs() < 1e-5);
    }

    #[test]
    fn test_blas_batch_matmul() {
        let provider = BlasOverride;

        // Batch of 2: each is 2x2 @ 2x2
        // Batch 0: [[1,0],[0,1]] @ [[1,2],[3,4]] = [[1,2],[3,4]]
        // Batch 1: [[2,0],[0,2]] @ [[1,2],[3,4]] = [[2,4],[6,8]]
        let a = [1.0, 0.0, 0.0, 1.0, 2.0, 0.0, 0.0, 2.0f32];
        let b = [1.0, 2.0, 3.0, 4.0, 1.0, 2.0, 3.0, 4.0f32];
        let mut c = [0.0f32; 8];

        let result = provider.batch_matmul(&a, &b, &mut c, 2, 2, 2, 2);
        assert!(result.is_some());
        assert!(result.unwrap().is_ok());

        // Batch 0
        assert!((c[0] - 1.0).abs() < 1e-5);
        assert!((c[1] - 2.0).abs() < 1e-5);
        assert!((c[2] - 3.0).abs() < 1e-5);
        assert!((c[3] - 4.0).abs() < 1e-5);

        // Batch 1
        assert!((c[4] - 2.0).abs() < 1e-5);
        assert!((c[5] - 4.0).abs() < 1e-5);
        assert!((c[6] - 6.0).abs() < 1e-5);
        assert!((c[7] - 8.0).abs() < 1e-5);
    }

    #[test]
    fn test_blas_other_ops_return_none() {
        let provider = BlasOverride;

        // All non-matmul ops should return None (fall through to defaults)
        let mut f = [0.0f32; 4];
        assert!(provider
            .layer_norm(&[1.0], &[1.0], &[0.0], &mut f, 1, 1, 1e-5)
            .is_none());
        assert!(provider.softmax(&[1.0, 2.0], &mut f, 1, 2, 1).is_none());

        let mut u = [0u8; 4];
        assert!(provider.ring_add(&[1, 2], &[3, 4], &mut u).is_none());
    }

    #[test]
    fn test_blas_matmul_transformer_size() {
        let provider = BlasOverride;

        // Realistic transformer shape: 1x768x768
        let rows_m = 1;
        let inner_k = 768;
        let cols_n = 768;

        let matrix_a: Vec<f32> = (0..rows_m * inner_k)
            .map(|index| {
                let value = u8::try_from(index % 17).unwrap();
                f32::from(value) * 0.01
            })
            .collect();
        let matrix_b: Vec<f32> = (0..inner_k * cols_n)
            .map(|index| {
                let value = u8::try_from(index % 13).unwrap();
                f32::from(value) * 0.01
            })
            .collect();
        let mut blas_output = vec![0.0f32; rows_m * cols_n];
        let mut reference_output = vec![0.0f32; rows_m * cols_n];

        // BLAS result
        let result = provider.matmul(
            &matrix_a,
            &matrix_b,
            &mut blas_output,
            rows_m,
            inner_k,
            cols_n,
        );
        assert!(result.is_some());
        assert!(result.unwrap().is_ok());

        // Naive reference
        for row in 0..rows_m {
            for col in 0..cols_n {
                let mut sum = 0.0f32;
                for inner in 0..inner_k {
                    sum += matrix_a[row * inner_k + inner] * matrix_b[inner * cols_n + col];
                }
                reference_output[row * cols_n + col] = sum;
            }
        }

        // Compare with tolerance (f32 accumulation order differs)
        for idx in 0..rows_m * cols_n {
            let diff = (blas_output[idx] - reference_output[idx]).abs();
            let scale = reference_output[idx].abs().max(1.0);
            assert!(
                diff / scale < 1e-3,
                "mismatch at {idx}: blas={} ref={} diff={}",
                blas_output[idx],
                reference_output[idx],
                diff
            );
        }
    }
}
