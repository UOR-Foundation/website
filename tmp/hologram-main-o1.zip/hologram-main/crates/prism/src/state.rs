//! State wrapper around [`uor::UorState`].
//!
//! Provides a safe API over the raw 624-taxon state used by UOR
//! wavefront execution.
//!
//! # Example
//!
//! ```
//! use prism::state::State;
//!
//! let state = State::zeros();
//! assert_eq!(state.as_bytes().len(), State::LEN);
//! ```

use uor::UorState;

/// 624 taxons (4992 bits) — the primary data container.
///
/// Wraps [`UorState`] with a safe API. All operations in [`crate::ops`]
/// operate on this type.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(transparent)]
pub struct State(pub(crate) UorState);

impl State {
    /// Number of taxons (bytes) in a state.
    pub const LEN: usize = uor::STATE_TAXONS;

    /// Number of bits in a state.
    pub const BITS: usize = Self::LEN * 8;

    /// Create a zero-initialized state.
    ///
    /// ```
    /// use prism::state::State;
    ///
    /// let s = State::zeros();
    /// assert!(s.as_bytes().iter().all(|&b| b == 0));
    /// ```
    #[inline]
    #[must_use]
    pub const fn zeros() -> Self {
        Self(UorState::zero())
    }

    /// Create a state with all bytes set to `0xFF`.
    ///
    /// ```
    /// use prism::state::State;
    ///
    /// let s = State::ones();
    /// assert!(s.as_bytes().iter().all(|&b| b == 0xFF));
    /// ```
    #[inline]
    #[must_use]
    pub fn ones() -> Self {
        let mut s = Self::zeros();
        for b in s.as_bytes_mut() {
            *b = 0xFF;
        }
        s
    }

    /// Create a state from a byte slice.
    ///
    /// Copies up to [`Self::LEN`] bytes. If `bytes` is shorter than 624,
    /// the remainder is zero-padded. If longer, excess bytes are ignored.
    ///
    /// ```
    /// use prism::state::State;
    ///
    /// let data = [1u8, 2, 3];
    /// let s = State::from_bytes(&data);
    /// assert_eq!(s.as_bytes()[0], 1);
    /// assert_eq!(s.as_bytes()[1], 2);
    /// assert_eq!(s.as_bytes()[2], 3);
    /// assert_eq!(s.as_bytes()[3], 0); // zero-padded
    /// ```
    #[inline]
    #[must_use]
    pub fn from_bytes(bytes: &[u8]) -> Self {
        let mut s = Self::zeros();
        let len = bytes.len().min(Self::LEN);
        s.as_bytes_mut()[..len].copy_from_slice(&bytes[..len]);
        s
    }

    /// View the state as a byte slice.
    ///
    /// ```
    /// use prism::state::State;
    ///
    /// let s = State::zeros();
    /// assert_eq!(s.as_bytes().len(), 624);
    /// ```
    #[inline]
    #[must_use]
    pub fn as_bytes(&self) -> &[u8] {
        // SAFETY: UorState is composed entirely of Taxon which is repr(transparent)
        // over u8, so the entire struct is a contiguous array of u8 values.
        let ptr = (&raw const self.0).cast::<u8>();
        unsafe { core::slice::from_raw_parts(ptr, Self::LEN) }
    }

    /// View the state as a mutable byte slice.
    ///
    /// ```
    /// use prism::state::State;
    ///
    /// let mut s = State::zeros();
    /// s.as_bytes_mut()[0] = 42;
    /// assert_eq!(s.as_bytes()[0], 42);
    /// ```
    #[inline]
    #[must_use]
    pub fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SAFETY: Same layout guarantee as as_bytes().
        let ptr = (&raw mut self.0).cast::<u8>();
        unsafe { core::slice::from_raw_parts_mut(ptr, Self::LEN) }
    }

    /// Borrow the inner [`UorState`].
    ///
    /// ```
    /// use prism::state::State;
    ///
    /// let s = State::zeros();
    /// let inner = s.inner();
    /// assert_eq!(inner.as_taxons().len(), 624);
    /// ```
    #[inline]
    #[must_use]
    pub const fn inner(&self) -> &UorState {
        &self.0
    }

    /// Mutably borrow the inner [`UorState`].
    ///
    /// ```
    /// use prism::state::State;
    /// use uor::Taxon;
    ///
    /// let mut s = State::zeros();
    /// s.inner_mut().ymm_mut(0)[0] = Taxon::new(99);
    /// assert_eq!(s.as_bytes()[0], 99);
    /// ```
    #[inline]
    #[must_use]
    pub fn inner_mut(&mut self) -> &mut UorState {
        &mut self.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_state_zeros() {
        let s = State::zeros();
        assert!(s.as_bytes().iter().all(|&b| b == 0));
    }

    #[test]
    fn test_state_len() {
        assert_eq!(State::LEN, 624);
        assert_eq!(State::BITS, 4992);
    }

    #[test]
    fn test_state_as_bytes_length() {
        let s = State::zeros();
        assert_eq!(s.as_bytes().len(), State::LEN);
    }

    #[test]
    fn test_state_copy() {
        let a = State::zeros();
        let b = a;
        assert_eq!(a, b);
    }

    #[test]
    fn test_state_transparent_layout() {
        assert_eq!(
            core::mem::size_of::<State>(),
            core::mem::size_of::<UorState>()
        );
    }

    #[test]
    fn test_ones_all_ff() {
        let s = State::ones();
        assert!(s.as_bytes().iter().all(|&b| b == 0xFF));
    }

    #[test]
    #[allow(clippy::cast_possible_truncation)]
    fn test_from_bytes_exact() {
        let data: Vec<u8> = (0..State::LEN).map(|i| i as u8).collect();
        let s = State::from_bytes(&data);
        assert_eq!(s.as_bytes(), data.as_slice());
    }

    #[test]
    fn test_from_bytes_short_zero_pad() {
        let data = [10u8, 20, 30];
        let s = State::from_bytes(&data);
        assert_eq!(s.as_bytes()[0], 10);
        assert_eq!(s.as_bytes()[1], 20);
        assert_eq!(s.as_bytes()[2], 30);
        assert!(s.as_bytes()[3..].iter().all(|&b| b == 0));
    }

    #[test]
    fn test_from_bytes_truncates() {
        let data = vec![0xAB; State::LEN + 100];
        let s = State::from_bytes(&data);
        assert!(s.as_bytes().iter().all(|&b| b == 0xAB));
    }

    #[test]
    fn test_from_bytes_empty() {
        let s = State::from_bytes(&[]);
        assert_eq!(s, State::zeros());
    }

    #[test]
    fn test_as_bytes_mut_roundtrip() {
        let mut s = State::zeros();
        s.as_bytes_mut()[100] = 0xDE;
        assert_eq!(s.as_bytes()[100], 0xDE);
    }

    #[test]
    fn test_inner_access() {
        let s = State::zeros();
        assert_eq!(s.inner().as_taxons().len(), State::LEN);
    }

    #[test]
    fn test_inner_mut_access() {
        let mut s = State::zeros();
        s.inner_mut().ymm_mut(0)[0] = uor::Taxon::new(77);
        assert_eq!(s.as_bytes()[0], 77);
    }
}
