//! Content-addressed blob storage.

use crate::error::NetworkError;
use hologram_sha256::Sha256;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::PathBuf;
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use thiserror::Error;

/// 32-byte content identifier (SHA-256 hash).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ContentId(pub [u8; 32]);

impl ContentId {
    /// Create a content ID from bytes.
    #[must_use]
    pub const fn from_bytes(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }

    /// Compute content ID from data.
    #[must_use]
    pub fn from_data(data: &[u8]) -> Self {
        Self(Sha256::digest(data).into())
    }

    /// Get the content ID as bytes.
    #[must_use]
    pub const fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }

    /// Convert to hex string.
    #[must_use]
    pub fn to_hex(&self) -> String {
        hex_encode(&self.0)
    }

    /// Parse from hex string.
    #[must_use]
    pub fn from_hex(s: &str) -> Option<Self> {
        if s.len() != 64 {
            return None;
        }

        let mut bytes = [0u8; 32];
        for (i, chunk) in s.as_bytes().chunks(2).enumerate() {
            if i >= 32 {
                return None;
            }
            let hex_str = std::str::from_utf8(chunk).ok()?;
            bytes[i] = u8::from_str_radix(hex_str, 16).ok()?;
        }
        Some(Self(bytes))
    }
}

impl std::fmt::Display for ContentId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", &self.to_hex()[..12])
    }
}

/// Content metadata.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContentMetadata {
    /// Content size in bytes.
    pub size: u64,
    /// Creation timestamp (Unix epoch seconds).
    pub created_at: u64,
    /// Last access timestamp (Unix epoch seconds).
    pub last_access: u64,
    /// Access count.
    pub access_count: u64,
    /// Optional human-readable label.
    pub label: Option<String>,
}

impl ContentMetadata {
    /// Create new metadata for content.
    #[must_use]
    pub fn new(size: u64) -> Self {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);

        Self {
            size,
            created_at: now,
            last_access: now,
            access_count: 1,
            label: None,
        }
    }

    /// Set a label for the content.
    #[must_use]
    pub fn with_label(mut self, label: impl Into<String>) -> Self {
        self.label = Some(label.into());
        self
    }

    /// Record an access to this content.
    pub fn record_access(&mut self) {
        self.last_access = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        self.access_count += 1;
    }

    /// Get the age of the content.
    #[must_use]
    pub fn age(&self) -> Duration {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        Duration::from_secs(now.saturating_sub(self.last_access))
    }
}

/// Content store error.
#[derive(Debug, Error)]
pub enum ContentStoreError {
    /// Content not found.
    #[error("content not found: {0}")]
    NotFound(String),

    /// Hash mismatch.
    #[error("hash mismatch: expected {expected}, got {actual}")]
    HashMismatch {
        /// Expected hash.
        expected: String,
        /// Actual hash.
        actual: String,
    },

    /// Storage full.
    #[error("storage full: max size {max_size} bytes")]
    StorageFull {
        /// Maximum storage size.
        max_size: u64,
    },

    /// IO error.
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),
}

impl From<ContentStoreError> for NetworkError {
    fn from(err: ContentStoreError) -> Self {
        match err {
            ContentStoreError::NotFound(id) => NetworkError::ContentNotFound(id),
            ContentStoreError::HashMismatch { expected, actual } => {
                NetworkError::HashMismatch { expected, actual }
            }
            ContentStoreError::StorageFull { max_size } => {
                NetworkError::StorageFull { capacity: max_size }
            }
            ContentStoreError::Io(e) => NetworkError::Io(e),
        }
    }
}

/// Configuration for local blob store.
#[derive(Debug, Clone)]
pub struct LocalBlobStoreConfig {
    /// Storage directory.
    pub storage_dir: PathBuf,
    /// Maximum storage size in bytes.
    pub max_size: u64,
    /// Maximum age for content (for eviction).
    pub max_age: Option<Duration>,
    /// Target size after eviction (percentage of `max_size`).
    pub eviction_target: f64,
}

impl Default for LocalBlobStoreConfig {
    fn default() -> Self {
        Self {
            storage_dir: PathBuf::from("/tmp/hologram-content"),
            max_size: 1024 * 1024 * 1024, // 1 GB
            max_age: None,
            eviction_target: 0.75,
        }
    }
}

impl LocalBlobStoreConfig {
    /// Create a new config with the given storage directory.
    #[must_use]
    pub fn new(storage_dir: impl Into<PathBuf>) -> Self {
        Self {
            storage_dir: storage_dir.into(),
            ..Self::default()
        }
    }

    /// Set the maximum storage size.
    #[must_use]
    pub const fn with_max_size(mut self, max_size: u64) -> Self {
        self.max_size = max_size;
        self
    }

    /// Set the maximum content age.
    #[must_use]
    pub fn with_max_age(mut self, max_age: Duration) -> Self {
        self.max_age = Some(max_age);
        self
    }

    /// Set the eviction target.
    #[must_use]
    pub fn with_eviction_target(mut self, target: f64) -> Self {
        self.eviction_target = target.clamp(0.0, 1.0);
        self
    }
}

/// Local content-addressed blob storage.
///
/// # Errors
///
/// Methods that return `Result` may fail with:
/// - `ContentStoreError::NotFound` - content not in store
/// - `ContentStoreError::HashMismatch` - data corruption detected
/// - `ContentStoreError::StorageFull` - no space available
/// - `ContentStoreError::Io` - filesystem errors
pub struct LocalBlobStore {
    config: LocalBlobStoreConfig,
    metadata: parking_lot::RwLock<HashMap<ContentId, ContentMetadata>>,
    current_size: std::sync::atomic::AtomicU64,
}

impl LocalBlobStore {
    /// Create a new local blob store.
    ///
    /// # Errors
    ///
    /// Returns an error if the storage directory cannot be created.
    pub fn new(config: LocalBlobStoreConfig) -> Result<Self, ContentStoreError> {
        std::fs::create_dir_all(&config.storage_dir)?;

        let store = Self {
            config,
            metadata: parking_lot::RwLock::new(HashMap::new()),
            current_size: std::sync::atomic::AtomicU64::new(0),
        };

        // Scan existing storage
        store.scan_storage()?;

        Ok(store)
    }

    /// Create an in-memory store (for testing).
    #[must_use]
    pub fn in_memory() -> Self {
        Self {
            config: LocalBlobStoreConfig::default(),
            metadata: parking_lot::RwLock::new(HashMap::new()),
            current_size: std::sync::atomic::AtomicU64::new(0),
        }
    }

    /// Store content and return its ID.
    ///
    /// # Errors
    ///
    /// Returns an error if storage is full or a filesystem error occurs.
    pub fn put(&self, data: &[u8]) -> Result<ContentId, ContentStoreError> {
        let id = ContentId::from_data(data);
        self.put_with_id(id, data)?;
        Ok(id)
    }

    /// Store content with a label.
    pub fn put_labeled(
        &self,
        data: &[u8],
        label: impl Into<String>,
    ) -> Result<ContentId, ContentStoreError> {
        let id = ContentId::from_data(data);
        let path = self.content_path(&id);

        // Check capacity
        let new_size =
            self.current_size.load(std::sync::atomic::Ordering::Relaxed) + data.len() as u64;
        if new_size > self.config.max_size {
            self.evict_old();
        }

        // Write content
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(&path, data)?;

        // Update metadata
        let metadata = ContentMetadata::new(data.len() as u64).with_label(label);
        self.metadata.write().insert(id, metadata);
        self.current_size
            .fetch_add(data.len() as u64, std::sync::atomic::Ordering::Relaxed);

        Ok(id)
    }

    /// Store content with a known ID.
    fn put_with_id(&self, id: ContentId, data: &[u8]) -> Result<(), ContentStoreError> {
        // Verify hash
        let computed = ContentId::from_data(data);
        if computed != id {
            return Err(ContentStoreError::HashMismatch {
                expected: id.to_hex(),
                actual: computed.to_hex(),
            });
        }

        let path = self.content_path(&id);

        // Check if already exists
        if path.exists() {
            // Update access time
            if let Some(meta) = self.metadata.write().get_mut(&id) {
                meta.record_access();
            }
            return Ok(());
        }

        // Check capacity
        let new_size =
            self.current_size.load(std::sync::atomic::Ordering::Relaxed) + data.len() as u64;
        if new_size > self.config.max_size {
            self.evict_old();
        }

        // Write content
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(&path, data)?;

        // Update metadata
        let metadata = ContentMetadata::new(data.len() as u64);
        self.metadata.write().insert(id, metadata);
        self.current_size
            .fetch_add(data.len() as u64, std::sync::atomic::Ordering::Relaxed);

        Ok(())
    }

    /// Get content by ID.
    pub fn get(&self, id: &ContentId) -> Result<Vec<u8>, ContentStoreError> {
        let path = self.content_path(id);

        if !path.exists() {
            return Err(ContentStoreError::NotFound(id.to_hex()));
        }

        let data = std::fs::read(&path)?;

        // Verify hash
        let computed = ContentId::from_data(&data);
        if computed != *id {
            return Err(ContentStoreError::HashMismatch {
                expected: id.to_hex(),
                actual: computed.to_hex(),
            });
        }

        // Update access time
        if let Some(meta) = self.metadata.write().get_mut(id) {
            meta.record_access();
        }

        Ok(data)
    }

    /// Check if content exists.
    #[must_use]
    pub fn contains(&self, id: &ContentId) -> bool {
        self.content_path(id).exists()
    }

    /// Remove content by ID.
    pub fn remove(&self, id: &ContentId) -> Result<(), ContentStoreError> {
        let path = self.content_path(id);

        if !path.exists() {
            return Ok(());
        }

        let size = std::fs::metadata(&path).map(|m| m.len()).unwrap_or(0);
        std::fs::remove_file(&path)?;

        self.metadata.write().remove(id);
        self.current_size
            .fetch_sub(size, std::sync::atomic::Ordering::Relaxed);

        Ok(())
    }

    /// Get metadata for content.
    #[must_use]
    pub fn metadata(&self, id: &ContentId) -> Option<ContentMetadata> {
        self.metadata.read().get(id).cloned()
    }

    /// Get current storage size.
    #[must_use]
    pub fn current_size(&self) -> u64 {
        self.current_size.load(std::sync::atomic::Ordering::Relaxed)
    }

    /// Get number of items in storage.
    #[must_use]
    pub fn len(&self) -> usize {
        self.metadata.read().len()
    }

    /// Check if storage is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.metadata.read().is_empty()
    }

    /// Evict old content to make room.
    #[allow(
        clippy::cast_possible_truncation,
        clippy::cast_sign_loss,
        clippy::cast_precision_loss
    )]
    fn evict_old(&self) {
        let target_size = (self.config.max_size as f64 * self.config.eviction_target) as u64;
        let mut current = self.current_size.load(std::sync::atomic::Ordering::Relaxed);

        if current <= target_size {
            return;
        }

        // Get items sorted by last access (oldest first)
        let mut items: Vec<_> = self
            .metadata
            .read()
            .iter()
            .map(|(k, v)| (*k, v.clone()))
            .collect();
        items.sort_by_key(|(_, m)| m.last_access);

        // Evict oldest until under target
        for (id, _) in items {
            if current <= target_size {
                break;
            }
            if self.remove(&id).is_ok() {
                current = self.current_size.load(std::sync::atomic::Ordering::Relaxed);
            }
        }
    }

    /// Scan storage directory and rebuild metadata.
    fn scan_storage(&self) -> Result<(), ContentStoreError> {
        if !self.config.storage_dir.exists() {
            return Ok(());
        }

        let mut total_size = 0u64;
        let mut metadata = HashMap::new();

        for entry in std::fs::read_dir(&self.config.storage_dir)? {
            let entry = entry?;
            if entry.file_type()?.is_dir() {
                for subentry in std::fs::read_dir(entry.path())? {
                    let subentry = subentry?;
                    if subentry.file_type()?.is_file() {
                        if let Some(id) =
                            ContentId::from_hex(subentry.file_name().to_string_lossy().as_ref())
                        {
                            let size = subentry.metadata()?.len();
                            total_size += size;
                            metadata.insert(id, ContentMetadata::new(size));
                        }
                    }
                }
            }
        }

        *self.metadata.write() = metadata;
        self.current_size
            .store(total_size, std::sync::atomic::Ordering::Relaxed);

        Ok(())
    }

    /// Get the path for a content ID.
    fn content_path(&self, id: &ContentId) -> PathBuf {
        let hex = id.to_hex();
        self.config.storage_dir.join(&hex[..2]).join(&hex)
    }
}

/// Encode bytes as hexadecimal string.
fn hex_encode(data: &[u8]) -> String {
    const HEX_CHARS: &[u8; 16] = b"0123456789abcdef";
    let mut result = String::with_capacity(data.len() * 2);
    for byte in data {
        result.push(HEX_CHARS[(byte >> 4) as usize] as char);
        result.push(HEX_CHARS[(byte & 0x0f) as usize] as char);
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[test]
    fn test_content_id_from_data() {
        let data = b"hello world";
        let id = ContentId::from_data(data);
        let id2 = ContentId::from_data(data);
        assert_eq!(id, id2);

        let id3 = ContentId::from_data(b"different");
        assert_ne!(id, id3);
    }

    #[test]
    fn test_content_id_hex() {
        let id = ContentId::from_bytes([0xab; 32]);
        let hex = id.to_hex();
        assert_eq!(hex.len(), 64);

        let parsed = ContentId::from_hex(&hex).unwrap();
        assert_eq!(id, parsed);
    }

    #[test]
    fn test_content_id_display() {
        let id = ContentId::from_bytes([0xde; 32]);
        let display = format!("{id}");
        assert_eq!(display.len(), 12); // First 12 hex chars
    }

    #[test]
    fn test_content_metadata() {
        let mut meta = ContentMetadata::new(1024);
        assert_eq!(meta.size, 1024);
        assert_eq!(meta.access_count, 1);

        std::thread::sleep(std::time::Duration::from_millis(10));
        meta.record_access();
        assert_eq!(meta.access_count, 2);
    }

    #[test]
    fn test_local_blob_store_put_get() {
        let dir = tempdir().unwrap();
        let config = LocalBlobStoreConfig::new(dir.path());
        let store = LocalBlobStore::new(config).unwrap();

        let data = b"test content";
        let id = store.put(data).unwrap();

        assert!(store.contains(&id));
        let retrieved = store.get(&id).unwrap();
        assert_eq!(retrieved, data);
    }

    #[test]
    fn test_local_blob_store_labeled() {
        let dir = tempdir().unwrap();
        let config = LocalBlobStoreConfig::new(dir.path());
        let store = LocalBlobStore::new(config).unwrap();

        let data = b"labeled content";
        let id = store.put_labeled(data, "my-label").unwrap();

        let meta = store.metadata(&id).unwrap();
        assert_eq!(meta.label, Some("my-label".to_string()));
    }

    #[test]
    fn test_local_blob_store_remove() {
        let dir = tempdir().unwrap();
        let config = LocalBlobStoreConfig::new(dir.path());
        let store = LocalBlobStore::new(config).unwrap();

        let data = b"to be removed";
        let id = store.put(data).unwrap();

        assert!(store.contains(&id));
        store.remove(&id).unwrap();
        assert!(!store.contains(&id));
    }

    #[test]
    fn test_local_blob_store_hash_mismatch() {
        let dir = tempdir().unwrap();
        let config = LocalBlobStoreConfig::new(dir.path());
        let store = LocalBlobStore::new(config).unwrap();

        // Try to put with wrong ID
        let data = b"content";
        let wrong_id = ContentId::from_bytes([0xff; 32]);
        let result = store.put_with_id(wrong_id, data);

        assert!(matches!(
            result,
            Err(ContentStoreError::HashMismatch { .. })
        ));
    }

    #[test]
    fn test_content_store_config() {
        let config = LocalBlobStoreConfig::new("/tmp/test")
            .with_max_size(1024 * 1024)
            .with_max_age(Duration::from_secs(3600))
            .with_eviction_target(0.8);

        assert_eq!(config.max_size, 1024 * 1024);
        assert_eq!(config.max_age, Some(Duration::from_secs(3600)));
        assert!((config.eviction_target - 0.8).abs() < f64::EPSILON);
    }
}
