//! .holb file reader for loading BackendPlan.

use std::path::Path;

use hologram_holo::{BackendPlan, HolbHeader, HOLB_MAGIC};
use rkyv::Deserialize;

use crate::error::{CliError, CliResult};

/// Load a BackendPlan from a .holb file.
pub fn read_holb(path: &Path) -> CliResult<BackendPlan> {
    let bytes = std::fs::read(path)?;

    // Check minimum size
    let header_size = HolbHeader::header_size();
    if bytes.len() < header_size {
        return Err(CliError::InvalidInput(format!(
            "file too small: {} bytes (minimum: {header_size})",
            bytes.len()
        )));
    }

    // Parse header
    let header = unsafe {
        // SAFETY: We verified file is large enough for header
        #[allow(clippy::cast_ptr_alignment)]
        &*(bytes.as_ptr().cast::<HolbHeader>())
    };

    // Verify magic
    if !header.is_valid() {
        return Err(CliError::InvalidInput(format!(
            "invalid magic bytes: expected {:?}, got {:?}",
            HOLB_MAGIC, &header.magic
        )));
    }

    // Verify version
    if header.version != 1 {
        return Err(CliError::InvalidInput(format!(
            "unsupported version: {} (expected 1)",
            header.version
        )));
    }

    // Verify graph bounds
    let graph_start = header.graph_offset as usize;
    let graph_end = graph_start
        .checked_add(header.graph_size as usize)
        .ok_or_else(|| CliError::InvalidInput("graph offset overflow".to_string()))?;

    if graph_end > bytes.len() {
        return Err(CliError::InvalidInput(format!(
            "graph extends beyond file: offset={graph_start}, size={}, file_size={}",
            header.graph_size,
            bytes.len()
        )));
    }

    // Verify graph checksum
    let graph_bytes = &bytes[graph_start..graph_end];
    let computed_checksum = crc32fast::hash(graph_bytes);
    if computed_checksum != header.graph_checksum {
        return Err(CliError::InvalidInput(format!(
            "graph checksum mismatch: expected {:#x}, computed {:#x}",
            header.graph_checksum, computed_checksum
        )));
    }

    // Deserialize the archived plan
    let archived = unsafe {
        // SAFETY: We verified checksum and bounds
        rkyv::archived_root::<BackendPlan>(graph_bytes)
    };

    // Convert archived plan to owned BackendPlan
    let plan: BackendPlan = archived.deserialize(&mut rkyv::Infallible).map_err(|_| {
        CliError::InvalidInput("failed to deserialize plan (infallible error)".to_string())
    })?;

    Ok(plan)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::writer::write_holb;
    use hologram_holo::PlanMetadata;
    use tempfile::tempdir;

    #[test]
    fn test_read_write_roundtrip() {
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![1, 2, 3, 4],
            workspace_size: 1024,
            dependencies: vec![],
            metadata: PlanMetadata {
                name: "test-model".to_string(),
                version: "1.0.0".to_string(),
                author: Some("Test Author".to_string()),
                description: Some("Test description".to_string()),
            },
            node_buffer_map: vec![Some(0), None, Some(1)],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        let dir = tempdir().unwrap();
        let path = dir.path().join("roundtrip.holb");

        // Write
        write_holb(&plan, &path).unwrap();

        // Read
        let loaded = read_holb(&path).unwrap();

        // Verify
        assert_eq!(loaded.instructions.len(), plan.instructions.len());
        assert_eq!(loaded.buffers.len(), plan.buffers.len());
        assert_eq!(loaded.constants, plan.constants);
        assert_eq!(loaded.workspace_size, plan.workspace_size);
        assert_eq!(loaded.metadata.name, plan.metadata.name);
        assert_eq!(loaded.metadata.version, plan.metadata.version);
        assert_eq!(loaded.node_buffer_map, plan.node_buffer_map);
    }

    #[test]
    fn test_read_invalid_magic() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("invalid.holb");

        // Write invalid data (need at least header_size bytes)
        let mut data = vec![0u8; 64];
        data[0..4].copy_from_slice(b"JUNK");
        std::fs::write(&path, &data).unwrap();

        let result = read_holb(&path);
        assert!(result.is_err());
        let err_msg = result.unwrap_err().to_string();
        assert!(
            err_msg.contains("invalid magic"),
            "Expected error to contain 'invalid magic', got: {err_msg}"
        );
    }

    #[test]
    fn test_read_too_small() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("small.holb");

        // Write data smaller than header
        std::fs::write(&path, b"HOL").unwrap();

        let result = read_holb(&path);
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("too small"));
    }
}
