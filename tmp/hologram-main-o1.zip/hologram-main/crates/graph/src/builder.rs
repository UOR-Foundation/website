//! Ergonomic builder for constructing compute graphs.
//!
//! The builder pattern provides a fluent API for graph construction,
//! reducing boilerplate and improving readability.

use crate::graph::ComputeGraph;
use crate::ids::{GroupId, NodeId};
use crate::node::InputSlot;

/// A builder for constructing `ComputeGraph` instances.
///
/// # Example
///
/// ```
/// use hologram_graph::{GraphBuilder, ComputeGraph};
///
/// #[derive(Clone)]
/// enum Op { Input, Add, Output }
///
/// let graph: ComputeGraph<Op> = GraphBuilder::new()
///     .node(Op::Input)
///     .node_with_inputs(Op::Add, &[0])
///     .node_with_inputs(Op::Output, &[1])
///     .build();
///
/// assert_eq!(graph.node_count(), 3);
/// ```
pub struct GraphBuilder<Op> {
    graph: ComputeGraph<Op>,
    /// Map from builder indices to node IDs.
    index_to_id: Vec<NodeId>,
}

impl<Op> Default for GraphBuilder<Op> {
    fn default() -> Self {
        Self::new()
    }
}

impl<Op> GraphBuilder<Op> {
    /// Create a new graph builder.
    #[must_use]
    pub fn new() -> Self {
        Self {
            graph: ComputeGraph::new(),
            index_to_id: Vec::new(),
        }
    }

    /// Add a node with no inputs.
    #[must_use]
    pub fn node(mut self, op: Op) -> Self {
        let id = self.graph.add_node(op);
        self.index_to_id.push(id);
        self
    }

    /// Add a node with inputs from previously added nodes.
    ///
    /// Input indices refer to the order nodes were added to the builder.
    #[must_use]
    pub fn node_with_inputs(mut self, op: Op, inputs: &[usize]) -> Self {
        let id = self.graph.add_node(op);
        self.index_to_id.push(id);

        // Collect source IDs first to avoid borrowing issues
        let sources: Vec<_> = inputs
            .iter()
            .filter_map(|&idx| self.index_to_id.get(idx).copied())
            .collect();

        // Connect inputs
        if let Some(node) = self.graph.get_mut(id) {
            for source_id in sources {
                node.inputs.push(InputSlot::from_node(source_id));
            }
        }
        self
    }

    /// Add a node with a specific group.
    #[must_use]
    pub fn node_in_group(mut self, op: Op, group: GroupId) -> Self {
        let id = self.graph.add_node(op);
        self.graph.set_group(id, group);
        self.index_to_id.push(id);
        self
    }

    /// Add an edge from source to target by builder indices.
    #[must_use]
    pub fn edge(mut self, source: usize, target: usize) -> Self {
        if let (Some(&src_id), Some(&tgt_id)) =
            (self.index_to_id.get(source), self.index_to_id.get(target))
        {
            self.graph.add_edge(src_id, tgt_id);
        }
        self
    }

    /// Register a named graph input.
    #[must_use]
    pub fn input(mut self, name: impl Into<String>) -> Self {
        self.graph.add_input(name);
        self
    }

    /// Register a named graph output by builder index.
    #[must_use]
    pub fn output(mut self, name: impl Into<String>, node_index: usize) -> Self {
        if let Some(&id) = self.index_to_id.get(node_index) {
            self.graph.add_output(name, id);
        }
        self
    }

    /// Get the node ID for a builder index.
    #[must_use]
    pub fn get_id(&self, index: usize) -> Option<NodeId> {
        self.index_to_id.get(index).copied()
    }

    /// Get the number of nodes added so far.
    #[must_use]
    pub fn len(&self) -> usize {
        self.index_to_id.len()
    }

    /// Check if no nodes have been added.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.index_to_id.is_empty()
    }

    /// Build the final graph.
    #[must_use]
    pub fn build(self) -> ComputeGraph<Op> {
        self.graph
    }
}

/// Extension trait for chained graph building.
pub trait BuilderExt<Op> {
    /// Create a builder pre-populated with this graph's contents.
    fn into_builder(self) -> GraphBuilder<Op>;
}

impl<Op: Clone> BuilderExt<Op> for ComputeGraph<Op> {
    fn into_builder(self) -> GraphBuilder<Op> {
        let index_to_id: Vec<_> = self.nodes().map(|n| n.id).collect();
        GraphBuilder {
            graph: self,
            index_to_id,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Debug, Clone, PartialEq)]
    enum TestOp {
        Input,
        Add,
        Mul,
        Output,
    }

    #[test]
    fn test_builder_simple() {
        let graph: ComputeGraph<TestOp> = GraphBuilder::new()
            .node(TestOp::Input)
            .node(TestOp::Add)
            .edge(0, 1)
            .build();

        assert_eq!(graph.node_count(), 2);
        assert_eq!(graph.edges().len(), 1);
    }

    #[test]
    fn test_builder_with_inputs() {
        let graph = GraphBuilder::new()
            .node(TestOp::Input)
            .node(TestOp::Input)
            .node_with_inputs(TestOp::Add, &[0, 1])
            .build();

        assert_eq!(graph.node_count(), 3);

        // The Add node should have 2 inputs
        let add_node = graph.nodes().find(|n| n.op == TestOp::Add).unwrap();
        assert_eq!(add_node.inputs.len(), 2);
    }

    #[test]
    fn test_builder_named_io() {
        let graph = GraphBuilder::new()
            .input("x")
            .input("y")
            .node(TestOp::Input)
            .node(TestOp::Output)
            .output("result", 1)
            .build();

        assert_eq!(graph.inputs().len(), 2);
        assert_eq!(graph.outputs().len(), 1);
        assert_eq!(graph.outputs()[0].0, "result");
    }

    #[test]
    fn test_builder_groups() {
        let graph = GraphBuilder::new()
            .node_in_group(TestOp::Add, GroupId::new(1))
            .node_in_group(TestOp::Mul, GroupId::new(2))
            .build();

        let nodes: Vec<_> = graph.nodes().collect();
        assert_eq!(nodes[0].group, GroupId::new(1));
        assert_eq!(nodes[1].group, GroupId::new(2));
    }

    #[test]
    fn test_builder_get_id() {
        let builder: GraphBuilder<TestOp> =
            GraphBuilder::new().node(TestOp::Input).node(TestOp::Add);

        assert!(builder.get_id(0).is_some());
        assert!(builder.get_id(1).is_some());
        assert!(builder.get_id(2).is_none());
    }

    #[test]
    fn test_builder_len() {
        let builder: GraphBuilder<TestOp> = GraphBuilder::new();
        assert!(builder.is_empty());
        assert_eq!(builder.len(), 0);

        let builder = builder.node(TestOp::Input);
        assert!(!builder.is_empty());
        assert_eq!(builder.len(), 1);
    }

    #[test]
    fn test_builder_default() {
        let builder: GraphBuilder<TestOp> = GraphBuilder::default();
        assert!(builder.is_empty());
    }

    #[test]
    fn test_into_builder() {
        let mut graph: ComputeGraph<TestOp> = ComputeGraph::new();
        graph.add_node(TestOp::Input);
        graph.add_node(TestOp::Output);

        let builder = graph.into_builder().node(TestOp::Add);

        let final_graph = builder.build();
        assert_eq!(final_graph.node_count(), 3);
    }

    #[test]
    fn test_builder_diamond() {
        let graph: ComputeGraph<TestOp> = GraphBuilder::new()
            .node(TestOp::Input) // 0
            .node_with_inputs(TestOp::Add, &[0]) // 1
            .node_with_inputs(TestOp::Mul, &[0]) // 2
            .node_with_inputs(TestOp::Output, &[1, 2]) // 3
            .build();

        assert_eq!(graph.node_count(), 4);

        // Output node has 2 inputs
        let out = graph.nodes().find(|n| n.op == TestOp::Output).unwrap();
        assert_eq!(out.inputs.len(), 2);

        // Sources and sinks
        assert_eq!(graph.sources().len(), 1);
        assert_eq!(graph.sinks().len(), 1);
    }

    #[test]
    fn test_builder_invalid_edge() {
        let graph = GraphBuilder::new()
            .node(TestOp::Input)
            // Invalid target index - should be silently ignored
            .edge(0, 99)
            .build();

        assert_eq!(graph.edges().len(), 0);
    }

    #[test]
    fn test_builder_invalid_output() {
        let graph = GraphBuilder::new()
            .node(TestOp::Input)
            // Invalid index - should be silently ignored
            .output("result", 99)
            .build();

        assert!(graph.outputs().is_empty());
    }
}
