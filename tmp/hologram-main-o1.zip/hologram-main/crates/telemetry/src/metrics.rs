//! Metrics collection for performance monitoring.
//!
//! This module provides:
//! - Global metrics registry
//! - Counters for tracking occurrences
//! - Histograms for tracking distributions

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Duration;

use dashmap::DashMap;
use parking_lot::Mutex;

/// Global metrics registry for collecting counters and histograms.
///
/// The registry is thread-safe and can be accessed from multiple threads.
pub struct MetricsRegistry {
    counters: DashMap<&'static str, AtomicU64>,
    histograms: DashMap<&'static str, Histogram>,
}

impl MetricsRegistry {
    /// Get the global metrics registry.
    ///
    /// This is a singleton that persists for the lifetime of the program.
    pub fn global() -> &'static Self {
        use std::sync::OnceLock;
        static REGISTRY: OnceLock<MetricsRegistry> = OnceLock::new();
        REGISTRY.get_or_init(|| MetricsRegistry {
            counters: DashMap::new(),
            histograms: DashMap::new(),
        })
    }

    /// Create a new metrics registry.
    ///
    /// This is useful for testing or when you need isolated metrics.
    #[must_use]
    pub fn new() -> Self {
        Self {
            counters: DashMap::new(),
            histograms: DashMap::new(),
        }
    }

    /// Increment a counter by the given value.
    ///
    /// # Example
    ///
    /// ```rust
    /// use hologram_telemetry::MetricsRegistry;
    ///
    /// let registry = MetricsRegistry::new();
    /// registry.increment("requests", 1);
    /// registry.increment("requests", 5);
    /// ```
    pub fn increment(&self, name: &'static str, value: u64) {
        self.counters
            .entry(name)
            .or_insert_with(|| AtomicU64::new(0))
            .fetch_add(value, Ordering::Relaxed);
    }

    /// Get the current value of a counter.
    #[must_use]
    pub fn get_counter(&self, name: &'static str) -> u64 {
        self.counters
            .get(name)
            .map(|c| c.load(Ordering::Relaxed))
            .unwrap_or(0)
    }

    /// Record a histogram value.
    ///
    /// # Example
    ///
    /// ```rust
    /// use hologram_telemetry::MetricsRegistry;
    ///
    /// let registry = MetricsRegistry::new();
    /// registry.record("latency_ms", 42.5);
    /// ```
    pub fn record(&self, name: &'static str, value: f64) {
        self.histograms.entry(name).or_default().record(value);
    }

    /// Record a duration in milliseconds.
    ///
    /// # Example
    ///
    /// ```rust
    /// use hologram_telemetry::MetricsRegistry;
    /// use std::time::Duration;
    ///
    /// let registry = MetricsRegistry::new();
    /// registry.record_duration("operation_ms", Duration::from_millis(100));
    /// ```
    pub fn record_duration(&self, name: &'static str, duration: Duration) {
        self.record(name, duration.as_secs_f64() * 1000.0);
    }

    /// Get all counter values.
    #[must_use]
    pub fn counters(&self) -> Vec<(&'static str, u64)> {
        self.counters
            .iter()
            .map(|r| (*r.key(), r.value().load(Ordering::Relaxed)))
            .collect()
    }

    /// Get all histogram summaries.
    #[must_use]
    pub fn histograms(&self) -> Vec<(&'static str, HistogramSummary)> {
        self.histograms
            .iter()
            .map(|r| (*r.key(), r.value().summary()))
            .collect()
    }

    /// Get a specific histogram summary.
    #[must_use]
    pub fn get_histogram(&self, name: &'static str) -> Option<HistogramSummary> {
        self.histograms.get(name).map(|h| h.summary())
    }

    /// Reset all metrics.
    ///
    /// This is primarily useful for testing.
    pub fn reset(&self) {
        self.counters.clear();
        self.histograms.clear();
    }

    /// Get the number of registered counters.
    #[must_use]
    pub fn counter_count(&self) -> usize {
        self.counters.len()
    }

    /// Get the number of registered histograms.
    #[must_use]
    pub fn histogram_count(&self) -> usize {
        self.histograms.len()
    }
}

impl Default for MetricsRegistry {
    fn default() -> Self {
        Self::new()
    }
}

/// A simple histogram for recording distributions.
///
/// This implementation stores all values in memory, which is suitable for
/// development and testing. For production use with high-volume metrics,
/// consider using a more sophisticated histogram implementation.
pub struct Histogram {
    values: Mutex<Vec<f64>>,
}

impl Histogram {
    /// Create a new empty histogram.
    #[must_use]
    pub fn new() -> Self {
        Self {
            values: Mutex::new(Vec::new()),
        }
    }

    /// Record a value in the histogram.
    pub fn record(&self, value: f64) {
        self.values.lock().push(value);
    }

    /// Get a summary of the histogram.
    #[must_use]
    pub fn summary(&self) -> HistogramSummary {
        let values = self.values.lock();
        if values.is_empty() {
            return HistogramSummary::default();
        }

        let mut sorted = values.clone();
        sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));

        let count = sorted.len();
        let sum: f64 = sorted.iter().sum();
        let mean = sum / count as f64;
        let min = sorted[0];
        let max = sorted[count - 1];
        let p50 = percentile(&sorted, 0.50);
        let p95 = percentile(&sorted, 0.95);
        let p99 = percentile(&sorted, 0.99);

        HistogramSummary {
            count: count as u64,
            sum,
            mean,
            min,
            max,
            p50,
            p95,
            p99,
        }
    }

    /// Get the number of recorded values.
    #[must_use]
    pub fn count(&self) -> usize {
        self.values.lock().len()
    }

    /// Clear all recorded values.
    pub fn clear(&self) {
        self.values.lock().clear();
    }
}

impl Default for Histogram {
    fn default() -> Self {
        Self::new()
    }
}

/// Summary statistics for a histogram.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct HistogramSummary {
    /// Number of recorded values.
    pub count: u64,
    /// Sum of all values.
    pub sum: f64,
    /// Mean (average) value.
    pub mean: f64,
    /// Minimum value.
    pub min: f64,
    /// Maximum value.
    pub max: f64,
    /// 50th percentile (median).
    pub p50: f64,
    /// 95th percentile.
    pub p95: f64,
    /// 99th percentile.
    pub p99: f64,
}

impl HistogramSummary {
    /// Check if the histogram is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.count == 0
    }
}

/// Calculate a percentile from a sorted slice.
fn percentile(sorted: &[f64], p: f64) -> f64 {
    if sorted.is_empty() {
        return 0.0;
    }
    let idx = ((sorted.len() as f64 - 1.0) * p).round() as usize;
    sorted[idx.min(sorted.len() - 1)]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_metrics_registry_new() {
        let registry = MetricsRegistry::new();
        assert_eq!(registry.counter_count(), 0);
        assert_eq!(registry.histogram_count(), 0);
    }

    #[test]
    fn test_counter_increment() {
        let registry = MetricsRegistry::new();
        registry.increment("test_counter", 1);
        assert_eq!(registry.get_counter("test_counter"), 1);

        registry.increment("test_counter", 5);
        assert_eq!(registry.get_counter("test_counter"), 6);
    }

    #[test]
    fn test_counter_multiple() {
        let registry = MetricsRegistry::new();
        registry.increment("counter_a", 10);
        registry.increment("counter_b", 20);

        let counters = registry.counters();
        assert_eq!(counters.len(), 2);

        let a = counters.iter().find(|(n, _)| *n == "counter_a");
        let b = counters.iter().find(|(n, _)| *n == "counter_b");

        assert_eq!(a.map(|(_, v)| *v), Some(10));
        assert_eq!(b.map(|(_, v)| *v), Some(20));
    }

    #[test]
    fn test_histogram_record() {
        let histogram = Histogram::new();
        histogram.record(10.0);
        histogram.record(20.0);
        histogram.record(30.0);

        assert_eq!(histogram.count(), 3);
    }

    #[test]
    fn test_histogram_summary() {
        let histogram = Histogram::new();
        for i in 1..=100 {
            histogram.record(i as f64);
        }

        let summary = histogram.summary();
        assert_eq!(summary.count, 100);
        assert!((summary.min - 1.0).abs() < 0.001);
        assert!((summary.max - 100.0).abs() < 0.001);
        assert!((summary.mean - 50.5).abs() < 0.001);
    }

    #[test]
    fn test_histogram_empty_summary() {
        let histogram = Histogram::new();
        let summary = histogram.summary();

        assert_eq!(summary.count, 0);
        assert!(summary.is_empty());
    }

    #[test]
    fn test_histogram_percentiles() {
        let histogram = Histogram::new();
        for i in 1..=100 {
            histogram.record(i as f64);
        }

        let summary = histogram.summary();
        // p50 should be around 50
        assert!((summary.p50 - 50.0).abs() < 2.0);
        // p95 should be around 95
        assert!((summary.p95 - 95.0).abs() < 2.0);
        // p99 should be around 99
        assert!((summary.p99 - 99.0).abs() < 2.0);
    }

    #[test]
    fn test_registry_record_duration() {
        let registry = MetricsRegistry::new();
        registry.record_duration("operation_ms", Duration::from_millis(100));

        let summary = registry.get_histogram("operation_ms").unwrap();
        assert_eq!(summary.count, 1);
        assert!((summary.mean - 100.0).abs() < 0.1);
    }

    #[test]
    fn test_registry_reset() {
        let registry = MetricsRegistry::new();
        registry.increment("counter", 10);
        registry.record("histogram", 5.0);

        assert_eq!(registry.counter_count(), 1);
        assert_eq!(registry.histogram_count(), 1);

        registry.reset();

        assert_eq!(registry.counter_count(), 0);
        assert_eq!(registry.histogram_count(), 0);
    }

    #[test]
    fn test_histogram_clear() {
        let histogram = Histogram::new();
        histogram.record(10.0);
        histogram.record(20.0);
        assert_eq!(histogram.count(), 2);

        histogram.clear();
        assert_eq!(histogram.count(), 0);
    }

    #[test]
    fn test_global_registry_singleton() {
        let r1 = MetricsRegistry::global();
        let r2 = MetricsRegistry::global();

        // They should be the same instance
        assert!(std::ptr::eq(r1, r2));
    }

    #[test]
    fn test_percentile_function() {
        let values = vec![1.0, 2.0, 3.0, 4.0, 5.0];
        assert!((percentile(&values, 0.0) - 1.0).abs() < 0.001);
        assert!((percentile(&values, 0.5) - 3.0).abs() < 0.001);
        assert!((percentile(&values, 1.0) - 5.0).abs() < 0.001);
    }

    #[test]
    fn test_percentile_empty() {
        let values: Vec<f64> = vec![];
        assert!((percentile(&values, 0.5)).abs() < 0.001);
    }

    #[test]
    fn test_histogram_summary_partial_eq() {
        let s1 = HistogramSummary::default();
        let s2 = HistogramSummary::default();
        assert_eq!(s1, s2);
    }

    #[test]
    fn test_get_counter_nonexistent() {
        let registry = MetricsRegistry::new();
        assert_eq!(registry.get_counter("nonexistent"), 0);
    }

    #[test]
    fn test_get_histogram_nonexistent() {
        let registry = MetricsRegistry::new();
        assert!(registry.get_histogram("nonexistent").is_none());
    }
}
