# UOR Python Bindings Example

Example Python program demonstrating UOR Python bindings via UniFFI.

## Prerequisites

- Python 3.8 or later
- UOR library built in release mode

## Building

Generate Python bindings:

```bash
just ffi-python
```

This creates:
- `bindings/python/uor.py` - Python module
- `bindings/python/*.so` - Native library

## Running

```bash
python3 examples/python/example.py
```

Or with proper PYTHONPATH:

```bash
PYTHONPATH=bindings/python python3 examples/python/example.py
```

## Features Demonstrated

- **Constants**: Braille codepoints, triadic/octave constants, state dimensions
- **Taxon Operations**: Byte-to-Braille conversion, codepoints, domains, ranks
- **Ring Operations**: Successor, predecessor, bitwise NOT
- **View Operations**: Identity, constant, composition, bijection checks
- **Array Operations**: Batch processing with `apply_slice()`

## API Usage

### Basic Operations

```python
from uor import byte_to_braille, byte_to_codepoint, FfiDomain

# Convert byte to Braille
braille = byte_to_braille(42)  # Returns "⠪"

# Get codepoint
codepoint = byte_to_codepoint(42)  # Returns 0x282A

# Get domain (returns enum)
domain = byte_to_domain(42)  # Returns FfiDomain.THETA
```

### View Operations

```python
from uor import FfiView

# Create views
identity = FfiView.identity()
constant = FfiView.constant(99)

# Apply to single byte
result = identity.apply(42)  # Returns 42

# Apply to byte array
data = bytes([1, 2, 3, 4])
output = identity.apply_slice(data)  # Returns bytes

# Compose views
composed = identity.then(constant)
result = composed.apply(42)  # Returns 99

# Check bijectivity
is_bij = identity.is_bijective()  # Returns True
```

## Type System

UniFFI provides full Python type hints:

- **Enums**: `FfiDomain` (Theta, Psi, Delta)
- **Classes**: `FfiView` with methods
- **Functions**: All top-level functions with proper signatures

## Error Handling

```python
from uor import FfiView, FfiError

try:
    view = FfiView.constant(256)  # Invalid byte value
except FfiError as e:
    print(f"Error: {e}")
```
