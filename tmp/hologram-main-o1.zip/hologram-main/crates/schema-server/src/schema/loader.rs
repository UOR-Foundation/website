//! Load and parse JSON-LD schema files.

use crate::config::Config;
use crate::error::Result;
use crate::schema::model::{Constant, DomainDto, GaugeLevel, GaugeTower, TaxonCatalog, TaxonDto};
use std::fs;

/// Loaded schema data from all files.
pub struct LoadedSchemas {
    pub uor_context: serde_json::Value,
    pub uor_schema: serde_json::Value,
    pub taxon_catalog: TaxonCatalog,
    pub hologram: serde_json::Value,
    pub taxons: Vec<TaxonDto>,
    pub domains: Vec<DomainDto>,
    pub constants: Vec<Constant>,
    pub gauge_tower: GaugeTower,
}

/// Load all schema files from config paths.
pub fn load_schemas(config: &Config) -> Result<LoadedSchemas> {
    let uor_context: serde_json::Value =
        serde_json::from_str(&fs::read_to_string(&config.uor_jsonld)?)?;
    let uor_schema: serde_json::Value =
        serde_json::from_str(&fs::read_to_string(&config.uor_schema)?)?;
    let taxon_catalog: TaxonCatalog =
        serde_json::from_str(&fs::read_to_string(&config.taxon_catalog)?)?;
    let hologram: serde_json::Value =
        serde_json::from_str(&fs::read_to_string(&config.hologram_jsonld)?)?;

    let taxons = extract_taxons(&taxon_catalog);
    let domains = extract_domains(&taxon_catalog);
    let constants = extract_constants(&taxon_catalog, &hologram);
    let gauge_tower = extract_gauge_tower(&hologram);

    Ok(LoadedSchemas {
        uor_context,
        uor_schema,
        taxon_catalog,
        hologram,
        taxons,
        domains,
        constants,
        gauge_tower,
    })
}

fn extract_taxons(catalog: &TaxonCatalog) -> Vec<TaxonDto> {
    catalog
        .graph
        .iter()
        .map(|t| TaxonDto {
            value: t.value,
            codepoint: t.codepoint,
            braille: t.braille.clone(),
            domain: t.domain.clone(),
            rank: t.rank,
            iri: t.id.clone(),
        })
        .collect()
}

fn extract_domains(catalog: &TaxonCatalog) -> Vec<DomainDto> {
    catalog
        .domains
        .iter()
        .map(|d| DomainDto {
            id: d.id.clone(),
            name: d.name.clone(),
            symbol: d.symbol.clone(),
            residue: d.residue,
            cardinality: d.cardinality,
            description: d.description.clone(),
        })
        .collect()
}

fn extract_constants(catalog: &TaxonCatalog, hologram: &serde_json::Value) -> Vec<Constant> {
    let mut constants = vec![
        // Fundamental axioms (immutable)
        Constant {
            name: "U".to_string(),
            symbol: "U".to_string(),
            value: 1,
            formula: None,
            derived_from: vec![],
            description: "Identity axiom".to_string(),
            is_mutable: false,
        },
        Constant {
            name: "D".to_string(),
            symbol: "D".to_string(),
            value: 2,
            formula: None,
            derived_from: vec![],
            description: "Duality axiom".to_string(),
            is_mutable: false,
        },
        // From catalog
        Constant {
            name: "T".to_string(),
            symbol: "T".to_string(),
            value: catalog.constants.t,
            formula: Some("U + D".to_string()),
            derived_from: vec!["U".to_string(), "D".to_string()],
            description: "Triality - three-fold symmetry".to_string(),
            is_mutable: true,
        },
        Constant {
            name: "O".to_string(),
            symbol: "O".to_string(),
            value: catalog.constants.o,
            formula: Some("D^T".to_string()),
            derived_from: vec!["D".to_string(), "T".to_string()],
            description: "Octave - Bott periodicity".to_string(),
            is_mutable: true,
        },
        Constant {
            name: "B".to_string(),
            symbol: "B".to_string(),
            value: 32,
            formula: Some("2^(O-T)".to_string()),
            derived_from: vec!["O".to_string(), "T".to_string()],
            description: "Binary depth - powers of 2 from octave-triality gap".to_string(),
            is_mutable: true,
        },
        Constant {
            name: "R".to_string(),
            symbol: "R".to_string(),
            value: 96,
            formula: Some("T * B".to_string()),
            derived_from: vec!["T".to_string(), "B".to_string()],
            description: "Resonance modulus - the algebraic workspace".to_string(),
            is_mutable: true,
        },
        Constant {
            name: "BYTE_CARDINALITY".to_string(),
            symbol: "2^O".to_string(),
            value: catalog.constants.byte_cardinality,
            formula: Some("2^O".to_string()),
            derived_from: vec!["O".to_string()],
            description: "Total number of taxons".to_string(),
            is_mutable: false,
        },
        Constant {
            name: "BRAILLE_BASE".to_string(),
            symbol: "U+2800".to_string(),
            value: catalog.constants.braille_base,
            formula: None,
            derived_from: vec![],
            description: "Unicode Braille block start".to_string(),
            is_mutable: false,
        },
    ];

    // Extract additional constants from hologram.jsonld if present
    if let Some(graph) = hologram.get("@graph").and_then(|g| g.as_array()) {
        for item in graph {
            if let Some(item_type) = item.get("@type").and_then(|t| t.as_str()) {
                if item_type == "Axiom" || item_type == "DerivedConstant" {
                    if let (Some(id), Some(value)) = (
                        item.get("@id").and_then(|i| i.as_str()),
                        item.get("value").and_then(|v| v.as_i64()),
                    ) {
                        let name = id.split(':').next_back().unwrap_or(id).to_string();
                        // Skip if already defined
                        if !constants.iter().any(|c| c.name == name) {
                            let formula = item
                                .get("formula")
                                .and_then(|f| f.as_str())
                                .map(String::from);
                            let description = item
                                .get("description")
                                .and_then(|d| d.as_str())
                                .unwrap_or("")
                                .to_string();
                            constants.push(Constant {
                                name: name.clone(),
                                symbol: name,
                                value,
                                formula,
                                derived_from: vec![],
                                description,
                                is_mutable: item_type == "DerivedConstant",
                            });
                        }
                    }
                }
            }
        }
    }

    constants
}

fn extract_gauge_tower(hologram: &serde_json::Value) -> GaugeTower {
    let mut levels = vec![
        GaugeLevel {
            index: 0,
            modulus: 96,
            boundary: 12_288,
            primes: vec![2, 3],
            label: "Base level".to_string(),
        },
        GaugeLevel {
            index: 1,
            modulus: 480,
            boundary: 61_440,
            primes: vec![2, 3, 5],
            label: "Level 1 (+5)".to_string(),
        },
        GaugeLevel {
            index: 2,
            modulus: 3_360,
            boundary: 430_080,
            primes: vec![2, 3, 5, 7],
            label: "Level 2 (+7)".to_string(),
        },
        GaugeLevel {
            index: 3,
            modulus: 36_960,
            boundary: 4_730_880,
            primes: vec![2, 3, 5, 7, 11],
            label: "Level 3 (+11)".to_string(),
        },
        GaugeLevel {
            index: 4,
            modulus: 480_480,
            boundary: 61_501_440,
            primes: vec![2, 3, 5, 7, 11, 13],
            label: "Level 4 (+13)".to_string(),
        },
        GaugeLevel {
            index: 5,
            modulus: 8_168_160,
            boundary: 1_045_524_480,
            primes: vec![2, 3, 5, 7, 11, 13, 17],
            label: "Level 5 (+17)".to_string(),
        },
    ];

    // Try to extract from hologram if available
    if let Some(graph) = hologram.get("@graph").and_then(|g| g.as_array()) {
        for item in graph {
            if let Some(item_type) = item.get("@type").and_then(|t| t.as_str()) {
                if item_type == "TowerLevel" {
                    if let (Some(index), Some(modulus), Some(boundary)) = (
                        item.get("index").and_then(|i| i.as_u64()),
                        item.get("modulus").and_then(|m| m.as_u64()),
                        item.get("boundary").and_then(|b| b.as_u64()),
                    ) {
                        let idx = index as usize;
                        if idx < levels.len() {
                            levels[idx].modulus = modulus;
                            levels[idx].boundary = boundary;
                        }
                    }
                }
            }
        }
    }

    GaugeTower {
        levels,
        description: "Hierarchical addressing system with CRT-derived moduli".to_string(),
    }
}
