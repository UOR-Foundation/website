# UOR FFI Bindings Examples

Comprehensive examples demonstrating UOR bindings across all supported languages and platforms.

## Overview

UOR provides complete FFI coverage for multiple languages through three different binding strategies:

| Strategy | Languages | Build Command |
|----------|-----------|---------------|
| **UniFFI** | Python, Ruby, Kotlin, Swift | `just ffi-uniffi` |
| **WASM** | JavaScript/TypeScript (Browser, Node.js, Bundler) | `just ffi-wasm` |
| **C** | C/C++ | `just ffi-c` |

## Quick Start

Build all bindings:

```bash
just ffi-all
```

Or build specific targets:

```bash
just ffi-python    # Python bindings
just ffi-ruby      # Ruby bindings
just ffi-kotlin    # Kotlin bindings
just ffi-swift     # Swift bindings
just ffi-wasm      # All WASM targets
just ffi-c         # C bindings
```

## Examples by Language

### [C](c/)

**Platform:** Cross-platform (Linux, macOS, Windows)
**Build:** `just ffi-c`

```bash
cd examples/c
make run
```

Example demonstrates direct C API with minimal overhead, manual memory management, opaque pointer types for safety, and cross-platform linking.

[View C Example →](c/README.md)

---

### [Python](python/)

**Platform:** CPython 3.8+
**Build:** `just ffi-python`

```bash
python3 examples/python/example.py
```

Example demonstrates Pythonic API via UniFFI, automatic memory management, type hints and enums, and exception handling.

[View Python Example →](python/README.md)

---

### [Ruby](ruby/)

**Platform:** Ruby 2.7+
**Build:** `just ffi-ruby`

```bash
ruby examples/ruby/example.rb
```

Example demonstrates idiomatic Ruby API, symbol-based enums, automatic garbage collection, and module namespacing.

[View Ruby Example →](ruby/README.md)

---

### [Kotlin](kotlin/)

**Platform:** JVM 11+
**Build:** `just ffi-kotlin`

```bash
cd examples/kotlin
kotlinc -classpath ../../bindings/kotlin Example.kt -include-runtime -d example.jar
LD_LIBRARY_PATH=../../target/release java -jar example.jar
```

Example demonstrates type-safe Kotlin API, unsigned byte types (UByte), enum classes, and list-based collections.

[View Kotlin Example →](kotlin/README.md)

---

### [Swift](swift/)

**Platform:** macOS, Linux (Swift 5.5+)
**Build:** `just ffi-swift`

```bash
cd examples/swift
swiftc -I ../../bindings/swift -L ../../target/release -luor_ffi Example.swift -o example
LD_LIBRARY_PATH=../../target/release ./example
```

Example demonstrates Swift-native API, ARC memory management, error handling with throws, and Foundation Data types.

[View Swift Example →](swift/README.md)

---

### [JavaScript/TypeScript](javascript/)

**Platforms:** Browser, Node.js, Bundlers (Webpack/Vite)
**Build:** `just ffi-wasm`

#### Node.js
```bash
node examples/javascript/example-node.js
```

#### Browser
```bash
python3 -m http.server 8000
# Open http://localhost:8000/examples/javascript/example-web.html
```

Example demonstrates three WASM targets (bundler, web, nodejs), TypeScript type definitions, manual memory management for WASM objects, and ES modules + CommonJS support.

[View JavaScript Example →](javascript/README.md)

## Features Demonstrated

All examples demonstrate the same core functionality including constants, taxon operations, ring operations, and view operations with composition and bijectivity checks.

## License

All examples are licensed under MIT OR Apache-2.0, same as the UOR library.
