/**
 * OnboardingWalkthrough — Gentle, progressive reveal for new users.
 *
 * Instead of a heavy tour, this shows a single, dismissible welcome
 * hint that fades away naturally. The dashboard speaks for itself.
 */

import { useState, useEffect, useCallback } from "react";
import { X } from "lucide-react";

const STORAGE_KEY = "hologram:identity:onboarding-complete";

export default function OnboardingWalkthrough() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const done = localStorage.getItem(STORAGE_KEY);
    if (!done) {
      const t = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(t);
    }
  }, []);

  // Listen for manual restart
  useEffect(() => {
    const handler = () => setVisible(true);
    window.addEventListener("hologram:restart-onboarding", handler);
    return () => window.removeEventListener("hologram:restart-onboarding", handler);
  }, []);

  const dismiss = useCallback(() => {
    setVisible(false);
    localStorage.setItem(STORAGE_KEY, "true");
  }, []);

  if (!visible) return null;

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[9999] w-[90vw] max-w-md animate-fade-in">
      <div className="rounded-2xl border border-border bg-card/95 backdrop-blur-sm shadow-2xl p-5">
        <div className="flex items-start gap-4">
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-foreground">
              Everything is private by default.
            </p>
            <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">
              Explore at your own pace. Hover over
              <span className="border-b border-dotted border-muted-foreground/40 mx-1">dotted terms</span>
              for quick definitions.
            </p>
          </div>
          <button
            onClick={dismiss}
            className="shrink-0 p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            aria-label="Dismiss"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
