import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { lazy, Suspense } from "react";
import NotFound from "./pages/NotFound";
import { HologramOsLayout } from "@/modules/hologram-ui";
import { ThemeProvider } from "@/hooks/use-theme";
import { AuthProvider } from "@/hooks/use-auth";

const HologramConsolePage = lazy(() => import("@/modules/hologram-ui/pages/HologramConsolePage"));
const IdentityHome = lazy(() => import("@/modules/identity/pages/IdentityHome"));
const IdentityDashboard = lazy(() => import("@/modules/identity/pages/IdentityDashboard"));
const IdentityCreationFlow = lazy(() => import("@/modules/identity/components/IdentityCreationFlow"));

const queryClient = new QueryClient();

const App = () => (
  <ThemeProvider>
    <AuthProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Suspense fallback={<div className="min-h-screen bg-background" />}>
              <HologramOsLayout>
                <Routes>
                  <Route path="/" element={<HologramConsolePage />} />
                  <Route path="/identity" element={<IdentityHome />} />
                  <Route path="/identity/explore" element={<IdentityDashboard />} />
                  <Route path="/identity/create" element={<IdentityCreationFlow />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </HologramOsLayout>
            </Suspense>
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    </AuthProvider>
  </ThemeProvider>
);

export default App;
