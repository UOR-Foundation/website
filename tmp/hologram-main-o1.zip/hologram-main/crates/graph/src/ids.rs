//! Generational identifiers for safe graph references.
//!
//! Generational IDs solve the ABA problem: when a node is removed and a new
//! node takes its slot, the generation counter ensures stale references fail
//! validation rather than pointing to the wrong node.

/// A node identifier with generational indexing.
///
/// The index provides O(1) lookup into the node arena. The generation counter
/// ensures that stale references (to nodes that have been removed) fail
/// validation rather than silently returning the wrong node.
#[derive(Debug, Copy, Clone, Eq, PartialEq, Hash, Default)]
pub struct NodeId {
    index: u32,
    generation: u32,
}

impl NodeId {
    /// Create a new node ID with the given index and generation.
    #[must_use]
    pub const fn new(index: u32, generation: u32) -> Self {
        Self { index, generation }
    }

    /// Create a null/invalid node ID.
    #[must_use]
    pub const fn null() -> Self {
        Self {
            index: u32::MAX,
            generation: u32::MAX,
        }
    }

    /// Check if this is a null/invalid node ID.
    #[must_use]
    pub const fn is_null(&self) -> bool {
        self.index == u32::MAX && self.generation == u32::MAX
    }

    /// Get the index component.
    #[must_use]
    pub const fn index(&self) -> u32 {
        self.index
    }

    /// Get the generation component.
    #[must_use]
    pub const fn generation(&self) -> u32 {
        self.generation
    }
}

/// A group identifier for parallel execution groups.
///
/// Nodes in the same group can be executed together without dependencies.
#[derive(Debug, Copy, Clone, Eq, PartialEq, Hash, Default)]
pub struct GroupId(pub u32);

impl GroupId {
    /// Create a new group ID.
    #[must_use]
    pub const fn new(id: u32) -> Self {
        Self(id)
    }

    /// Get the raw ID value.
    #[must_use]
    pub const fn raw(&self) -> u32 {
        self.0
    }
}

/// A subgraph identifier for nested graph references.
#[derive(Debug, Copy, Clone, Eq, PartialEq, Hash, Default)]
pub struct SubgraphId(pub u32);

impl SubgraphId {
    /// Create a new subgraph ID.
    #[must_use]
    pub const fn new(id: u32) -> Self {
        Self(id)
    }

    /// Get the raw ID value.
    #[must_use]
    pub const fn raw(&self) -> u32 {
        self.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_node_id_creation() {
        let id = NodeId::new(42, 7);
        assert_eq!(id.index(), 42);
        assert_eq!(id.generation(), 7);
        assert!(!id.is_null());
    }

    #[test]
    fn test_node_id_null() {
        let null = NodeId::null();
        assert!(null.is_null());
        assert_eq!(null.index(), u32::MAX);
        assert_eq!(null.generation(), u32::MAX);
    }

    #[test]
    fn test_node_id_default_is_not_null() {
        let default = NodeId::default();
        assert!(!default.is_null());
        assert_eq!(default.index(), 0);
        assert_eq!(default.generation(), 0);
    }

    #[test]
    fn test_node_id_equality() {
        let a = NodeId::new(1, 2);
        let b = NodeId::new(1, 2);
        let c = NodeId::new(1, 3);
        let d = NodeId::new(2, 2);

        assert_eq!(a, b);
        assert_ne!(a, c); // Different generation
        assert_ne!(a, d); // Different index
    }

    #[test]
    fn test_node_id_hash() {
        use std::collections::HashSet;

        let mut set = HashSet::new();
        set.insert(NodeId::new(1, 1));
        set.insert(NodeId::new(1, 2));
        set.insert(NodeId::new(2, 1));

        assert_eq!(set.len(), 3);
        assert!(set.contains(&NodeId::new(1, 1)));
        assert!(!set.contains(&NodeId::new(3, 3)));
    }

    #[test]
    fn test_group_id() {
        let g = GroupId::new(5);
        assert_eq!(g.raw(), 5);
        assert_eq!(g, GroupId(5));
    }

    #[test]
    fn test_subgraph_id() {
        let s = SubgraphId::new(10);
        assert_eq!(s.raw(), 10);
        assert_eq!(s, SubgraphId(10));
    }
}
