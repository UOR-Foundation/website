//! Roundtrip tests: Compile -> serialize -> deserialize -> verify.
//!
//! These tests verify that compiled `BackendPlan`s can be serialized with rkyv,
//! deserialized, and retain their full structure and content.

use hologram_compiler::{compile, CompilerConfig, DType, OpKind, OpNode, OperationGraph};
use hologram_holo::{BackendPlan, HolbHeader, PlanMetadata, HOLB_MAGIC};

/// Serialize a `BackendPlan` to bytes using rkyv.
fn serialize_plan(plan: &BackendPlan) -> Vec<u8> {
    rkyv::to_bytes::<_, 1024>(plan)
        .expect("serialization failed")
        .to_vec()
}

/// Deserialize bytes back to `BackendPlan`.
fn deserialize_plan(bytes: &[u8]) -> BackendPlan {
    let archived = unsafe { rkyv::archived_root::<BackendPlan>(bytes) };
    rkyv::Deserialize::deserialize(archived, &mut rkyv::Infallible).expect("deserialization failed")
}

/// Create a simple linear graph: Input -> Relu -> Output.
fn make_linear_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32));
    graph.add_node(OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32));
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph
}

/// Create a `MatMul` graph: A, B -> MatMul -> Output.
fn make_matmul_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![64, 128], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Input, vec![128, 256], DType::F32));
    graph.add_node(OpNode::new(
        2,
        OpKind::MatMul {
            m: 64,
            k: 128,
            n: 256,
        },
        vec![64, 256],
        DType::F32,
    ));
    graph.add_node(OpNode::new(3, OpKind::Output, vec![64, 256], DType::F32));
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph
}

/// Create a diamond graph with parallel branches.
fn make_diamond_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![128, 128], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Relu, vec![128, 128], DType::F32));
    graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![128, 128], DType::F32));
    graph.add_node(OpNode::new(3, OpKind::Add, vec![128, 128], DType::F32));
    graph.add_node(OpNode::new(4, OpKind::Output, vec![128, 128], DType::F32));
    graph.add_edge(0, 1);
    graph.add_edge(0, 2);
    graph.add_edge(1, 3);
    graph.add_edge(2, 3);
    graph.add_edge(3, 4);
    graph
}

/// Create a simple CNN block: Input -> Conv2d -> BatchNorm -> Relu -> MaxPool -> Output.
fn make_cnn_block_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();
    // Input: [1, 3, 32, 32]
    graph.add_node(OpNode::new(
        0,
        OpKind::Input,
        vec![1, 3, 32, 32],
        DType::F32,
    ));
    // Conv2d: [1, 64, 32, 32]
    graph.add_node(OpNode::new(
        1,
        OpKind::Conv2d {
            kernel: (3, 3),
            stride: (1, 1),
            padding: (1, 1),
            dilation: (1, 1),
            groups: 1,
        },
        vec![1, 64, 32, 32],
        DType::F32,
    ));
    // BatchNorm: [1, 64, 32, 32]
    graph.add_node(OpNode::new(
        2,
        OpKind::BatchNormalization { epsilon: 1e-5 },
        vec![1, 64, 32, 32],
        DType::F32,
    ));
    // Relu: [1, 64, 32, 32]
    graph.add_node(OpNode::new(
        3,
        OpKind::Relu,
        vec![1, 64, 32, 32],
        DType::F32,
    ));
    // MaxPool: [1, 64, 16, 16]
    graph.add_node(OpNode::new(
        4,
        OpKind::MaxPool {
            kernel: (2, 2),
            stride: (2, 2),
            padding: (0, 0),
        },
        vec![1, 64, 16, 16],
        DType::F32,
    ));
    // Output
    graph.add_node(OpNode::new(
        5,
        OpKind::Output,
        vec![1, 64, 16, 16],
        DType::F32,
    ));

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph.add_edge(3, 4);
    graph.add_edge(4, 5);
    graph
}

/// Create a classifier head: Input -> GlobalAveragePool -> Flatten -> Output.
fn make_classifier_head_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();
    // Input: [1, 512, 7, 7]
    graph.add_node(OpNode::new(
        0,
        OpKind::Input,
        vec![1, 512, 7, 7],
        DType::F32,
    ));
    // GlobalAveragePool: [1, 512, 1, 1]
    graph.add_node(OpNode::new(
        1,
        OpKind::GlobalAveragePool,
        vec![1, 512, 1, 1],
        DType::F32,
    ));
    // Flatten: [1, 512]
    graph.add_node(OpNode::new(
        2,
        OpKind::Flatten { start_dim: 1 },
        vec![1, 512],
        DType::F32,
    ));
    // Output
    graph.add_node(OpNode::new(3, OpKind::Output, vec![1, 512], DType::F32));

    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph
}

#[test]
fn test_roundtrip_empty_plan() {
    let plan = BackendPlan {
        instructions: Vec::new(),
        buffers: Vec::new(),
        constants: Vec::new(),
        workspace_size: 0,
        dependencies: Vec::new(),
        metadata: PlanMetadata::default(),
        node_buffer_map: Vec::new(),
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(restored.instructions.len(), 0);
    assert_eq!(restored.buffers.len(), 0);
    assert_eq!(restored.constants.len(), 0);
    assert_eq!(restored.workspace_size, 0);
    assert_eq!(restored.metadata.name, "unnamed");
    assert_eq!(restored.metadata.version, "0.1.0");
}

#[test]
fn test_roundtrip_linear_graph() {
    let graph = make_linear_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(restored.instructions.len(), plan.instructions.len());
    assert_eq!(restored.buffers.len(), plan.buffers.len());
    assert_eq!(restored.workspace_size, plan.workspace_size);
}

#[test]
fn test_roundtrip_matmul_graph() {
    let graph = make_matmul_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(restored.instructions.len(), plan.instructions.len());
    assert_eq!(restored.buffers.len(), plan.buffers.len());
    assert_eq!(restored.workspace_size, plan.workspace_size);
}

#[test]
fn test_roundtrip_diamond_graph() {
    let graph = make_diamond_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(restored.instructions.len(), plan.instructions.len());
    assert_eq!(restored.buffers.len(), plan.buffers.len());
}

#[test]
fn test_roundtrip_preserves_instructions() {
    let graph = make_linear_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    // Verify each instruction matches
    assert_eq!(plan.instructions, restored.instructions);
}

#[test]
fn test_roundtrip_preserves_buffers() {
    let graph = make_matmul_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    // Verify each buffer matches
    for (orig, rest) in plan.buffers.iter().zip(restored.buffers.iter()) {
        assert_eq!(orig.size, rest.size);
        assert_eq!(orig.alignment, rest.alignment);
    }
}

#[test]
fn test_roundtrip_preserves_metadata() {
    let graph = make_linear_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(plan.metadata.name, restored.metadata.name);
    assert_eq!(plan.metadata.version, restored.metadata.version);
}

#[test]
fn test_roundtrip_with_constants() {
    // Create a plan with constant data
    let plan = BackendPlan {
        instructions: Vec::new(),
        buffers: Vec::new(),
        constants: vec![1, 2, 3, 4, 5, 6, 7, 8],
        workspace_size: 0,
        dependencies: Vec::new(),
        metadata: PlanMetadata::default(),
        node_buffer_map: Vec::new(),
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(restored.constants, vec![1, 2, 3, 4, 5, 6, 7, 8]);
}

#[test]
fn test_roundtrip_large_constants() {
    // 1KB of constant data
    let constants: Vec<u8> = (0..1024).map(|i| (i % 256) as u8).collect();

    let plan = BackendPlan {
        instructions: Vec::new(),
        buffers: Vec::new(),
        constants: constants.clone(),
        workspace_size: 0,
        dependencies: Vec::new(),
        metadata: PlanMetadata::default(),
        node_buffer_map: Vec::new(),
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    };

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(restored.constants, constants);
}

#[test]
fn test_holb_header_roundtrip() {
    let header = HolbHeader {
        magic: *HOLB_MAGIC,
        version: 1,
        graph_offset: 64,
        graph_size: 1024,
        weights_offset: 4096,
        weights_size: 8192,
        graph_checksum: 0xDEAD_BEEF,
        weights_checksum: 0xCAFE_BABE,
    };

    let bytes = rkyv::to_bytes::<_, 128>(&header).expect("serialization failed");
    let archived = unsafe { rkyv::archived_root::<HolbHeader>(&bytes) };
    let restored: HolbHeader =
        rkyv::Deserialize::deserialize(archived, &mut rkyv::Infallible).expect("deser failed");

    assert_eq!(restored.magic, *HOLB_MAGIC);
    assert_eq!(restored.version, 1);
    assert_eq!(restored.graph_offset, 64);
    assert_eq!(restored.graph_size, 1024);
    assert_eq!(restored.weights_offset, 4096);
    assert_eq!(restored.weights_size, 8192);
    assert_eq!(restored.graph_checksum, 0xDEAD_BEEF);
    assert_eq!(restored.weights_checksum, 0xCAFE_BABE);
}

#[test]
fn test_multiple_roundtrips() {
    // Verify that multiple serialize/deserialize cycles produce identical results
    let graph = make_diamond_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let bytes1 = serialize_plan(&plan);
    let restored1 = deserialize_plan(&bytes1);

    let bytes2 = serialize_plan(&restored1);
    let restored2 = deserialize_plan(&bytes2);

    assert_eq!(restored1.instructions, restored2.instructions);
    assert_eq!(restored1.buffers.len(), restored2.buffers.len());
    assert_eq!(restored1.workspace_size, restored2.workspace_size);
}

#[test]
fn test_roundtrip_different_opt_levels() {
    let graph = make_matmul_graph();

    for opt_level in 0..=3 {
        let config = CompilerConfig {
            opt_level,
            ..Default::default()
        };

        let plan = compile(&graph, &config).expect("compilation failed");
        let bytes = serialize_plan(&plan);
        let restored = deserialize_plan(&bytes);

        assert_eq!(
            plan.instructions.len(),
            restored.instructions.len(),
            "Mismatch at opt_level {opt_level}"
        );
    }
}

#[test]
fn test_roundtrip_cnn_block() {
    let graph = make_cnn_block_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(restored.instructions.len(), plan.instructions.len());
    assert_eq!(restored.buffers.len(), plan.buffers.len());
}

#[test]
fn test_roundtrip_classifier_head() {
    let graph = make_classifier_head_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(restored.instructions.len(), plan.instructions.len());
    assert_eq!(restored.buffers.len(), plan.buffers.len());
}

/// Create a full ResNet18 classifier: Input -> GlobalAveragePool -> Flatten -> MatMul + Bias -> Output.
///
/// This tests the full pipeline that was failing with shape mismatch (node 273).
fn make_resnet18_classifier_graph() -> OperationGraph {
    use hologram_compiler::ConstantData;

    let mut graph = OperationGraph::new();

    // Input: [1, 512, 7, 7] (final conv output from ResNet18)
    graph.add_node(OpNode::new(
        0,
        OpKind::Input,
        vec![1, 512, 7, 7],
        DType::F32,
    ));

    // GlobalAveragePool: [1, 512, 1, 1]
    graph.add_node(OpNode::new(
        1,
        OpKind::GlobalAveragePool,
        vec![1, 512, 1, 1],
        DType::F32,
    ));

    // Flatten: [1, 512]
    graph.add_node(OpNode::new(
        2,
        OpKind::Flatten { start_dim: 1 },
        vec![1, 512],
        DType::F32,
    ));

    // Weight: [512, 1000] (constant)
    graph.add_node(OpNode::new(
        3,
        OpKind::Constant,
        vec![512, 1000],
        DType::F32,
    ));

    // MatMul: [1, 1000] - note m=1, output is [1, 1000] not [1000]
    graph.add_node(OpNode::new(
        4,
        OpKind::MatMul {
            m: 1,
            k: 512,
            n: 1000,
        },
        vec![1, 1000],
        DType::F32,
    ));

    // Bias: [1000] (constant) - broadcasts with [1, 1000]
    graph.add_node(OpNode::new(5, OpKind::Constant, vec![1000], DType::F32));

    // Add (with broadcasting): [1, 1000]
    graph.add_node(OpNode::new(6, OpKind::Add, vec![1, 1000], DType::F32));

    // Output
    graph.add_node(OpNode::new(7, OpKind::Output, vec![1, 1000], DType::F32));

    // Edges
    graph.add_edge(0, 1); // Input -> GlobalAveragePool
    graph.add_edge(1, 2); // GlobalAveragePool -> Flatten
    graph.add_edge(2, 4); // Flatten -> MatMul
    graph.add_edge(3, 4); // Weight -> MatMul
    graph.add_edge(4, 6); // MatMul -> Add
    graph.add_edge(5, 6); // Bias -> Add
    graph.add_edge(6, 7); // Add -> Output

    // Constants (weight: 512*1000 floats, bias: 1000 floats)
    graph.add_constant_for_node(3, ConstantData::F32(vec![0.0; 512 * 1000]));
    graph.add_constant_for_node(5, ConstantData::F32(vec![0.0; 1000]));

    graph
}

#[test]
fn test_roundtrip_resnet18_classifier() {
    // This test verifies the fix for ResNet18 shape mismatch bug:
    // - GlobalAveragePool: [N, C, H, W] -> [N, C, 1, 1]
    // - Flatten with start_dim=1: preserves batch dimension
    // - MatMul with m=1: produces [1, n] not [n]
    // - Add with broadcasting: [1, 1000] + [1000] -> [1, 1000]
    let graph = make_resnet18_classifier_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("ResNet18 classifier compilation failed");

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(restored.instructions.len(), plan.instructions.len());
    assert_eq!(restored.buffers.len(), plan.buffers.len());
}

// ============================================================================
// SHA-256 compiler pipeline tests
// ============================================================================

/// Create SHA-256 graph: Input(80 bytes) -> Sha256 -> Output(32 bytes).
fn make_sha256_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![80], DType::U8));
    graph.sha256(1, 0, 80);
    graph.add_node(OpNode::new(2, OpKind::Output, vec![32], DType::U8));
    graph.add_edge(1, 2);
    graph
}

/// Create double SHA-256 graph: Input(80 bytes) -> DoubleSha256 -> Output(32 bytes).
fn make_double_sha256_graph() -> OperationGraph {
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![80], DType::U8));
    graph.double_sha256(1, 0, 80);
    graph.add_node(OpNode::new(2, OpKind::Output, vec![32], DType::U8));
    graph.add_edge(1, 2);
    graph
}

#[test]
fn test_compile_sha256() {
    let graph = make_sha256_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("SHA-256 compilation failed");

    // Should contain a Sha256 instruction
    let has_sha256 = plan
        .instructions
        .iter()
        .any(|i| matches!(i, hologram_holo::IsaInstruction::Sha256 { src_len: 80, .. }));
    assert!(has_sha256, "Plan should contain Sha256 instruction");
}

#[test]
fn test_compile_double_sha256() {
    let graph = make_double_sha256_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("DoubleSha256 compilation failed");

    // Should contain a DoubleSha256 instruction
    let has_double = plan.instructions.iter().any(|i| {
        matches!(
            i,
            hologram_holo::IsaInstruction::DoubleSha256 { src_len: 80, .. }
        )
    });
    assert!(has_double, "Plan should contain DoubleSha256 instruction");
}

#[test]
fn test_roundtrip_sha256() {
    let graph = make_sha256_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(restored.instructions.len(), plan.instructions.len());
    assert_eq!(restored.buffers.len(), plan.buffers.len());
}

#[test]
fn test_roundtrip_double_sha256() {
    let graph = make_double_sha256_graph();
    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("compilation failed");

    let bytes = serialize_plan(&plan);
    let restored = deserialize_plan(&bytes);

    assert_eq!(restored.instructions.len(), plan.instructions.len());
    assert_eq!(restored.buffers.len(), plan.buffers.len());
}

#[test]
fn test_sha256_different_input_sizes() {
    // SHA-256 output is always 32 bytes regardless of input size
    for input_size in [32, 64, 80, 128, 256] {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![input_size], DType::U8));
        graph.sha256(1, 0, input_size);
        graph.add_node(OpNode::new(2, OpKind::Output, vec![32], DType::U8));
        graph.add_edge(1, 2);

        let config = CompilerConfig::default();
        let plan = compile(&graph, &config)
            .unwrap_or_else(|e| panic!("SHA-256 with {input_size}-byte input failed: {e}"));

        let sha_instr = plan
            .instructions
            .iter()
            .find(|i| matches!(i, hologram_holo::IsaInstruction::Sha256 { .. }));
        assert!(
            sha_instr.is_some(),
            "Missing Sha256 instruction for {input_size}-byte input"
        );
    }
}

#[test]
fn test_sha256_chain_fuses_to_double() {
    // Input -> Sha256(80) -> Sha256(32) -> Output
    // Fusion pass should produce: Input -> DoubleSha256(80) -> Output
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![80], DType::U8));
    graph.sha256(1, 0, 80);
    graph.sha256(2, 1, 32);
    graph.add_node(OpNode::new(3, OpKind::Output, vec![32], DType::U8));
    graph.add_edge(2, 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).expect("SHA-256 chain compilation failed");

    // Should have fused into DoubleSha256
    let has_double = plan.instructions.iter().any(|i| {
        matches!(
            i,
            hologram_holo::IsaInstruction::DoubleSha256 { src_len: 80, .. }
        )
    });
    assert!(
        has_double,
        "SHA-256 chain should fuse into DoubleSha256 instruction"
    );

    // Should NOT have separate Sha256 instructions
    let sha256_count = plan
        .instructions
        .iter()
        .filter(|i| matches!(i, hologram_holo::IsaInstruction::Sha256 { .. }))
        .count();
    assert_eq!(
        sha256_count, 0,
        "Fused chain should not have separate Sha256 instructions"
    );
}
