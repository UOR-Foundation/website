//! C-compatible ABI for dynamic kernel loading.
//!
//! This module defines the stable interface between hologram and external native kernels.
//! All structures must be `#[repr(C)]` to adhere to the standard platform ABI.

/// Magic number to identify hologram kernel libraries ("HOLO_KER").
pub const KERNEL_MAGIC: u64 = 0x484F_4C4F_5F4B_4552;

/// Current ABI version (1.0).
pub const KERNEL_ABI_VERSION: u64 = 1;

/// Function pointer types for kernel operations.
///
/// These match the signatures in `KernelOverride` but use C-compatible types.
/// Note: slices are passed as (pointer, length).
pub type MatMulFn = unsafe extern "C" fn(
    a: *const f32,
    b: *const f32,
    c: *mut f32,
    m: usize,
    k: usize,
    n: usize,
) -> i32;

/// Function pointer for batch matrix multiplication.
///
/// Same as `MatMulFn` but with an additional batch dimension.
pub type BatchMatMulFn = unsafe extern "C" fn(
    a: *const f32,
    b: *const f32,
    c: *mut f32,
    batch: usize,
    m: usize,
    k: usize,
    n: usize,
) -> i32;

/// The VTable exported by external kernel libraries.
#[repr(C)]
pub struct KernelVTable {
    /// Magic number (must match `KERNEL_MAGIC`).
    pub magic: u64,
    /// ABI version (must match `KERNEL_ABI_VERSION`).
    pub version: u64,

    // Matrix Operations
    /// Matrix multiplication kernel (optional).
    pub matmul: Option<MatMulFn>,
    /// Batch matrix multiplication kernel (optional).
    pub batch_matmul: Option<BatchMatMulFn>,

    /// Future expansion: reserved fields to maintain ABI compatibility.
    pub reserved: [Option<unsafe extern "C" fn()>; 16],
}
