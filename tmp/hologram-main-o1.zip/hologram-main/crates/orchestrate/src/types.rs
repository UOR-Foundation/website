//! Core types for orchestration.

use hologram_backend::BackendType;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::PathBuf;
use std::time::Duration;

/// Unique identifier for a provisioned worker instance.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct WorkerHandle(pub u64);

impl WorkerHandle {
    /// Create a new worker handle with the given ID.
    #[must_use]
    pub const fn new(id: u64) -> Self {
        Self(id)
    }

    /// Get the raw ID value.
    #[must_use]
    pub const fn id(&self) -> u64 {
        self.0
    }
}

impl std::fmt::Display for WorkerHandle {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "worker-{:08x}", self.0)
    }
}

impl From<u64> for WorkerHandle {
    fn from(id: u64) -> Self {
        Self(id)
    }
}

/// Current state of a worker instance.
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum WorkerState {
    /// Worker is being provisioned.
    #[default]
    Provisioning,
    /// Worker is running and should be joining the P2P network.
    Running,
    /// Worker is being terminated.
    Terminating,
    /// Worker has been terminated.
    Terminated,
    /// Worker encountered an error.
    Failed {
        /// Error message describing the failure.
        message: String,
    },
}

impl WorkerState {
    /// Check if this is a terminal state.
    #[must_use]
    pub fn is_terminal(&self) -> bool {
        matches!(self, Self::Terminated | Self::Failed { .. })
    }

    /// Check if this is a running state.
    #[must_use]
    pub fn is_running(&self) -> bool {
        matches!(self, Self::Running)
    }

    /// Check if this is a failed state.
    #[must_use]
    pub fn is_failed(&self) -> bool {
        matches!(self, Self::Failed { .. })
    }

    /// Get the failure message if in failed state.
    #[must_use]
    pub fn failure_message(&self) -> Option<&str> {
        match self {
            Self::Failed { message } => Some(message),
            _ => None,
        }
    }
}

impl std::fmt::Display for WorkerState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Provisioning => write!(f, "Provisioning"),
            Self::Running => write!(f, "Running"),
            Self::Terminating => write!(f, "Terminating"),
            Self::Terminated => write!(f, "Terminated"),
            Self::Failed { message } => write!(f, "Failed: {message}"),
        }
    }
}

/// Resource allocation for a worker.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkerResources {
    /// Number of vCPUs.
    pub vcpus: u32,
    /// Memory in MiB.
    pub memory_mib: u32,
    /// Optional GPU allocation.
    pub gpu: Option<GpuAllocation>,
}

impl Default for WorkerResources {
    fn default() -> Self {
        Self {
            vcpus: 2,
            memory_mib: 4096,
            gpu: None,
        }
    }
}

impl WorkerResources {
    /// Create new worker resources with default values.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the number of vCPUs.
    #[must_use]
    pub const fn with_vcpus(mut self, vcpus: u32) -> Self {
        self.vcpus = vcpus;
        self
    }

    /// Set the memory in MiB.
    #[must_use]
    pub const fn with_memory_mib(mut self, memory_mib: u32) -> Self {
        self.memory_mib = memory_mib;
        self
    }

    /// Set the GPU allocation.
    #[must_use]
    pub fn with_gpu(mut self, gpu: GpuAllocation) -> Self {
        self.gpu = Some(gpu);
        self
    }

    /// Check if GPU is allocated.
    #[must_use]
    pub const fn has_gpu(&self) -> bool {
        self.gpu.is_some()
    }
}

/// GPU allocation for a worker.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GpuAllocation {
    /// GPU device type (e.g., "nvidia-tesla-v100").
    pub device_type: String,
    /// Number of GPUs.
    pub count: u32,
    /// Memory per GPU in MiB.
    pub memory_mib: u32,
}

impl GpuAllocation {
    /// Create a new GPU allocation.
    #[must_use]
    pub fn new(device_type: impl Into<String>, count: u32, memory_mib: u32) -> Self {
        Self {
            device_type: device_type.into(),
            count,
            memory_mib,
        }
    }

    /// Create a GPU allocation for NVIDIA Tesla V100.
    #[must_use]
    pub fn nvidia_v100(count: u32) -> Self {
        Self::new("nvidia-tesla-v100", count, 16384) // 16 GB
    }

    /// Create a GPU allocation for NVIDIA A100.
    #[must_use]
    pub fn nvidia_a100(count: u32) -> Self {
        Self::new("nvidia-a100", count, 40960) // 40 GB
    }
}

/// Worker image specification.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum WorkerImage {
    /// Firecracker kernel + rootfs.
    Firecracker {
        /// Path to the kernel image.
        kernel_path: PathBuf,
        /// Path to the root filesystem image.
        rootfs_path: PathBuf,
    },
    /// Container image for Kubernetes.
    Container {
        /// Container image name.
        image: String,
        /// Image tag.
        tag: String,
    },
}

impl Default for WorkerImage {
    fn default() -> Self {
        Self::Container {
            image: "ghcr.io/uor-foundation/hologram-worker".to_string(),
            tag: "latest".to_string(),
        }
    }
}

impl WorkerImage {
    /// Create a Firecracker image specification.
    #[must_use]
    pub fn firecracker(kernel_path: impl Into<PathBuf>, rootfs_path: impl Into<PathBuf>) -> Self {
        Self::Firecracker {
            kernel_path: kernel_path.into(),
            rootfs_path: rootfs_path.into(),
        }
    }

    /// Create a container image specification.
    #[must_use]
    pub fn container(image: impl Into<String>, tag: impl Into<String>) -> Self {
        Self::Container {
            image: image.into(),
            tag: tag.into(),
        }
    }

    /// Check if this is a Firecracker image.
    #[must_use]
    pub const fn is_firecracker(&self) -> bool {
        matches!(self, Self::Firecracker { .. })
    }

    /// Check if this is a container image.
    #[must_use]
    pub const fn is_container(&self) -> bool {
        matches!(self, Self::Container { .. })
    }
}

/// Configuration for provisioning a worker.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProvisionConfig {
    /// Desired backend type.
    pub backend_type: BackendType,
    /// Resource requirements.
    pub resources: WorkerResources,
    /// Bootstrap peers for P2P network joining.
    pub bootstrap_peers: Vec<String>,
    /// Worker image/kernel to use.
    pub image: WorkerImage,
    /// Environment variables to pass.
    pub env: HashMap<String, String>,
    /// Timeout for provisioning in seconds.
    pub timeout_secs: u64,
    /// Labels for worker identification.
    pub labels: HashMap<String, String>,
}

impl Default for ProvisionConfig {
    fn default() -> Self {
        Self {
            backend_type: BackendType::Cpu,
            resources: WorkerResources::default(),
            bootstrap_peers: Vec::new(),
            image: WorkerImage::default(),
            env: HashMap::new(),
            timeout_secs: 120,
            labels: HashMap::new(),
        }
    }
}

impl ProvisionConfig {
    /// Create a new provision config with default settings.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the backend type.
    #[must_use]
    pub fn with_backend(mut self, backend: BackendType) -> Self {
        self.backend_type = backend;
        self
    }

    /// Set the resources.
    #[must_use]
    pub fn with_resources(mut self, resources: WorkerResources) -> Self {
        self.resources = resources;
        self
    }

    /// Add a bootstrap peer.
    #[must_use]
    pub fn with_bootstrap_peer(mut self, peer: impl Into<String>) -> Self {
        self.bootstrap_peers.push(peer.into());
        self
    }

    /// Set bootstrap peers.
    #[must_use]
    pub fn with_bootstrap_peers(mut self, peers: Vec<String>) -> Self {
        self.bootstrap_peers = peers;
        self
    }

    /// Set the worker image.
    #[must_use]
    pub fn with_image(mut self, image: WorkerImage) -> Self {
        self.image = image;
        self
    }

    /// Add an environment variable.
    #[must_use]
    pub fn with_env(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        self.env.insert(key.into(), value.into());
        self
    }

    /// Set the provisioning timeout.
    #[must_use]
    pub fn with_timeout(mut self, timeout: Duration) -> Self {
        self.timeout_secs = timeout.as_secs();
        self
    }

    /// Add a label.
    #[must_use]
    pub fn with_label(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        self.labels.insert(key.into(), value.into());
        self
    }

    /// Get the timeout as a Duration.
    #[must_use]
    pub const fn timeout(&self) -> Duration {
        Duration::from_secs(self.timeout_secs)
    }
}

/// Information about a provisioned worker.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkerInfo {
    /// Unique handle for this worker.
    pub handle: WorkerHandle,
    /// Current state.
    pub state: WorkerState,
    /// Backend-specific instance ID (e.g., Firecracker VM ID, K8s pod name).
    pub instance_id: String,
    /// Network address where worker is reachable (for P2P bootstrap).
    pub address: Option<String>,
    /// P2P peer ID once the worker has joined the network.
    pub peer_id: Option<String>,
    /// Backend type (CPU, Metal, CUDA, etc.) of the worker.
    pub backend_type: BackendType,
    /// Resource allocation.
    pub resources: WorkerResources,
    /// Creation timestamp (Unix epoch seconds).
    pub created_at: u64,
    /// Labels.
    pub labels: HashMap<String, String>,
}

impl WorkerInfo {
    /// Create a new worker info.
    #[must_use]
    pub fn new(
        handle: WorkerHandle,
        instance_id: impl Into<String>,
        backend_type: BackendType,
    ) -> Self {
        Self {
            handle,
            state: WorkerState::Provisioning,
            instance_id: instance_id.into(),
            address: None,
            peer_id: None,
            backend_type,
            resources: WorkerResources::default(),
            created_at: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_secs())
                .unwrap_or(0),
            labels: HashMap::new(),
        }
    }

    /// Check if the worker is in a terminal state.
    #[must_use]
    pub fn is_terminal(&self) -> bool {
        self.state.is_terminal()
    }

    /// Check if the worker is running.
    #[must_use]
    pub fn is_running(&self) -> bool {
        self.state.is_running()
    }

    /// Set the worker state.
    #[must_use]
    pub fn with_state(mut self, state: WorkerState) -> Self {
        self.state = state;
        self
    }

    /// Set the worker address.
    #[must_use]
    pub fn with_address(mut self, address: impl Into<String>) -> Self {
        self.address = Some(address.into());
        self
    }

    /// Set the peer ID.
    #[must_use]
    pub fn with_peer_id(mut self, peer_id: impl Into<String>) -> Self {
        self.peer_id = Some(peer_id.into());
        self
    }

    /// Set the resources.
    #[must_use]
    pub fn with_resources(mut self, resources: WorkerResources) -> Self {
        self.resources = resources;
        self
    }

    /// Add a label.
    #[must_use]
    pub fn with_label(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        self.labels.insert(key.into(), value.into());
        self
    }

    /// Get age of the worker in seconds.
    #[must_use]
    pub fn age_secs(&self) -> u64 {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        now.saturating_sub(self.created_at)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_worker_handle_display() {
        let handle = WorkerHandle(12345);
        assert_eq!(format!("{handle}"), "worker-00003039");
    }

    #[test]
    fn test_worker_handle_from_u64() {
        let handle: WorkerHandle = 42u64.into();
        assert_eq!(handle.id(), 42);
    }

    #[test]
    fn test_worker_state_display() {
        assert_eq!(format!("{}", WorkerState::Provisioning), "Provisioning");
        assert_eq!(format!("{}", WorkerState::Running), "Running");
        assert_eq!(
            format!(
                "{}",
                WorkerState::Failed {
                    message: "OOM".into()
                }
            ),
            "Failed: OOM"
        );
    }

    #[test]
    fn test_worker_state_is_terminal() {
        assert!(!WorkerState::Provisioning.is_terminal());
        assert!(!WorkerState::Running.is_terminal());
        assert!(!WorkerState::Terminating.is_terminal());
        assert!(WorkerState::Terminated.is_terminal());
        assert!(WorkerState::Failed {
            message: "test".into()
        }
        .is_terminal());
    }

    #[test]
    fn test_worker_state_failure_message() {
        assert_eq!(WorkerState::Running.failure_message(), None);
        assert_eq!(
            WorkerState::Failed {
                message: "error".into()
            }
            .failure_message(),
            Some("error")
        );
    }

    #[test]
    fn test_worker_resources_builder() {
        let resources = WorkerResources::new()
            .with_vcpus(8)
            .with_memory_mib(16384)
            .with_gpu(GpuAllocation::nvidia_v100(2));

        assert_eq!(resources.vcpus, 8);
        assert_eq!(resources.memory_mib, 16384);
        assert!(resources.has_gpu());
    }

    #[test]
    fn test_gpu_allocation() {
        let gpu = GpuAllocation::nvidia_v100(2);
        assert_eq!(gpu.device_type, "nvidia-tesla-v100");
        assert_eq!(gpu.count, 2);
        assert_eq!(gpu.memory_mib, 16384);

        let gpu = GpuAllocation::nvidia_a100(1);
        assert_eq!(gpu.device_type, "nvidia-a100");
        assert_eq!(gpu.memory_mib, 40960);
    }

    #[test]
    fn test_worker_image() {
        let fc = WorkerImage::firecracker("/kernel", "/rootfs");
        assert!(fc.is_firecracker());
        assert!(!fc.is_container());

        let container = WorkerImage::container("nginx", "latest");
        assert!(container.is_container());
        assert!(!container.is_firecracker());
    }

    #[test]
    fn test_provision_config_builder() {
        let config = ProvisionConfig::new()
            .with_backend(BackendType::Metal)
            .with_resources(WorkerResources {
                vcpus: 8,
                memory_mib: 16384,
                gpu: None,
            })
            .with_bootstrap_peer("192.168.1.100:9000")
            .with_env("RUST_LOG", "debug")
            .with_label("pool", "compute")
            .with_timeout(Duration::from_secs(60));

        assert_eq!(config.backend_type, BackendType::Metal);
        assert_eq!(config.resources.vcpus, 8);
        assert_eq!(config.bootstrap_peers.len(), 1);
        assert_eq!(config.env.get("RUST_LOG"), Some(&"debug".to_string()));
        assert_eq!(config.labels.get("pool"), Some(&"compute".to_string()));
        assert_eq!(config.timeout_secs, 60);
        assert_eq!(config.timeout(), Duration::from_secs(60));
    }

    #[test]
    fn test_worker_info_creation() {
        let info = WorkerInfo::new(WorkerHandle(1), "vm-001", BackendType::Cpu);

        assert_eq!(info.handle, WorkerHandle(1));
        assert_eq!(info.state, WorkerState::Provisioning);
        assert!(!info.is_terminal());
        assert!(!info.is_running());
    }

    #[test]
    fn test_worker_info_builder() {
        let info = WorkerInfo::new(WorkerHandle(1), "vm-001", BackendType::Cpu)
            .with_state(WorkerState::Running)
            .with_address("192.168.1.100:9000")
            .with_peer_id("peer-abc123")
            .with_label("role", "worker");

        assert!(info.is_running());
        assert_eq!(info.address, Some("192.168.1.100:9000".to_string()));
        assert_eq!(info.peer_id, Some("peer-abc123".to_string()));
        assert_eq!(info.labels.get("role"), Some(&"worker".to_string()));
    }

    #[test]
    fn test_worker_info_terminal_states() {
        let mut info = WorkerInfo::new(WorkerHandle(1), "vm-001", BackendType::Cpu);

        info.state = WorkerState::Running;
        assert!(!info.is_terminal());
        assert!(info.is_running());

        info.state = WorkerState::Terminated;
        assert!(info.is_terminal());
        assert!(!info.is_running());

        info.state = WorkerState::Failed {
            message: "error".into(),
        };
        assert!(info.is_terminal());
        assert!(!info.is_running());
    }

    #[test]
    fn test_worker_info_serialization() {
        let info = WorkerInfo::new(WorkerHandle(42), "test-vm", BackendType::Cpu)
            .with_state(WorkerState::Running)
            .with_address("127.0.0.1:8080");

        let json = serde_json::to_string(&info).unwrap();
        let parsed: WorkerInfo = serde_json::from_str(&json).unwrap();

        assert_eq!(parsed.handle, info.handle);
        assert_eq!(parsed.state, info.state);
        assert_eq!(parsed.address, info.address);
    }

    #[test]
    fn test_provision_config_serialization() {
        let config = ProvisionConfig::new()
            .with_backend(BackendType::Cpu)
            .with_env("KEY", "value");

        let json = serde_json::to_string(&config).unwrap();
        let parsed: ProvisionConfig = serde_json::from_str(&json).unwrap();

        assert_eq!(parsed.backend_type, config.backend_type);
        assert_eq!(parsed.env.get("KEY"), config.env.get("KEY"));
    }

    // ========================================================================
    // Additional edge case tests
    // ========================================================================

    #[test]
    fn test_worker_state_default() {
        let state = WorkerState::default();
        assert!(matches!(state, WorkerState::Provisioning));
        assert!(!state.is_terminal());
        assert!(!state.is_running());
        assert!(!state.is_failed());
    }

    #[test]
    fn test_worker_state_is_failed() {
        assert!(!WorkerState::Provisioning.is_failed());
        assert!(!WorkerState::Running.is_failed());
        assert!(!WorkerState::Terminated.is_failed());
        assert!(WorkerState::Failed {
            message: "error".into()
        }
        .is_failed());
    }

    #[test]
    fn test_worker_image_default() {
        let image = WorkerImage::default();
        assert!(image.is_container());

        if let WorkerImage::Container { image, tag } = image {
            assert!(image.contains("hologram-worker"));
            assert_eq!(tag, "latest");
        }
    }

    #[test]
    fn test_provision_config_with_bootstrap_peers() {
        let config = ProvisionConfig::new()
            .with_bootstrap_peers(vec!["peer1:9000".to_string(), "peer2:9000".to_string()]);

        assert_eq!(config.bootstrap_peers.len(), 2);
        assert!(config.bootstrap_peers.contains(&"peer1:9000".to_string()));
    }

    #[test]
    fn test_provision_config_with_image() {
        let config =
            ProvisionConfig::new().with_image(WorkerImage::firecracker("/kernel", "/rootfs"));

        assert!(config.image.is_firecracker());
    }

    #[test]
    fn test_worker_info_with_resources() {
        let resources = WorkerResources::new().with_vcpus(16).with_memory_mib(32768);
        let info =
            WorkerInfo::new(WorkerHandle(1), "vm-001", BackendType::Cuda).with_resources(resources);

        assert_eq!(info.resources.vcpus, 16);
        assert_eq!(info.resources.memory_mib, 32768);
    }

    #[test]
    fn test_worker_info_age() {
        let info = WorkerInfo::new(WorkerHandle(1), "vm-001", BackendType::Cpu);
        // Age should be very small since we just created it
        assert!(info.age_secs() < 5);
    }

    #[test]
    fn test_worker_resources_default() {
        let resources = WorkerResources::default();
        assert_eq!(resources.vcpus, 2);
        assert_eq!(resources.memory_mib, 4096);
        assert!(!resources.has_gpu());
    }

    #[test]
    fn test_gpu_allocation_custom() {
        let gpu = GpuAllocation::new("nvidia-h100", 8, 81920);
        assert_eq!(gpu.device_type, "nvidia-h100");
        assert_eq!(gpu.count, 8);
        assert_eq!(gpu.memory_mib, 81920);
    }

    #[test]
    fn test_worker_handle_equality() {
        let h1 = WorkerHandle::new(42);
        let h2 = WorkerHandle::new(42);
        let h3 = WorkerHandle::new(43);

        assert_eq!(h1, h2);
        assert_ne!(h1, h3);
    }

    #[test]
    fn test_worker_handle_hash() {
        use std::collections::HashSet;

        let mut set = HashSet::new();
        set.insert(WorkerHandle::new(1));
        set.insert(WorkerHandle::new(2));
        set.insert(WorkerHandle::new(1)); // Duplicate

        assert_eq!(set.len(), 2);
    }

    #[test]
    fn test_provision_config_default() {
        let config = ProvisionConfig::default();
        assert_eq!(config.backend_type, BackendType::Cpu);
        assert!(config.bootstrap_peers.is_empty());
        assert!(config.env.is_empty());
        assert_eq!(config.timeout_secs, 120);
    }
}
