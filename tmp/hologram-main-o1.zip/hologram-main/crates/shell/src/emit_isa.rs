//! ISA code generation from shell AST.
//!
//! Transforms a parsed [`Shell`] AST into Rust source code for:
//! - `IsaInstruction` enum with rkyv derives
//! - `InstructionDispatcher` trait
//! - `ExecuteOn<D>` match-based dispatch
//! - CPU `dispatcher_impl` delegation
//! - Builder structs for `@builder`-annotated ops

use proc_macro2::{Ident, Span, TokenStream};
use quote::quote;

use crate::ast::*;
use crate::naming;

// ============================================================================
// Resolved operation — flattened from groups and ops
// ============================================================================

/// A single ISA instruction, resolved from either a group member or a standalone op.
#[derive(Debug, Clone)]
pub struct FlatOp {
    /// PascalCase enum variant name.
    pub variant_name: String,
    /// `exec_snake_case` trait method name.
    pub method_name: String,
    /// Flattened parameters.
    pub params: Vec<FlatParam>,
    /// GPU kernel category from `@kernel("...")` annotation.
    pub kernel_category: Option<String>,
}

/// A resolved parameter.
#[derive(Debug, Clone)]
pub struct FlatParam {
    pub name: String,
    pub ty: FieldType,
}

/// Flatten all groups and ops into individual [`FlatOp`]s.
///
/// Compose definitions are **not** included — they are table metadata,
/// not ISA instructions. The runtime fusion cache handles compose chains.
pub fn resolve_ops(shell: &Shell) -> Vec<FlatOp> {
    let mut ops = Vec::new();
    for item in &shell.items {
        match item {
            ShellItem::Group(g) => {
                let kernel = kernel_from_annotations(&g.annotations);
                for member in &g.members {
                    ops.push(FlatOp {
                        variant_name: naming::variant_name(&member.name, &g.annotations),
                        method_name: naming::method_name(&member.name, &g.annotations),
                        params: g
                            .params
                            .iter()
                            .map(|p| FlatParam {
                                name: p.name.clone(),
                                ty: p.ty.clone(),
                            })
                            .collect(),
                        kernel_category: kernel.clone(),
                    });
                }
            }
            ShellItem::Op(o) => {
                ops.push(FlatOp {
                    variant_name: naming::variant_name(&o.name, &o.annotations),
                    method_name: naming::method_name(&o.name, &[]),
                    params: o
                        .all_params()
                        .into_iter()
                        .map(|p| FlatParam {
                            name: p.name.clone(),
                            ty: p.ty.clone(),
                        })
                        .collect(),
                    kernel_category: kernel_from_annotations(&o.annotations),
                });
            }
            _ => {} // Compose, Type, Enum, Transform — not ISA ops
        }
    }
    ops
}

/// Extract `@kernel("Category")` from annotations.
fn kernel_from_annotations(annotations: &[Annotation]) -> Option<String> {
    annotations.iter().find_map(|a| match a {
        Annotation::Kernel(cat) => Some(cat.clone()),
        _ => None,
    })
}

// ============================================================================
// Type conversion helpers
// ============================================================================

/// Convert a shell `FieldType` to the Rust type used in enum fields.
fn enum_type_tokens(ty: &FieldType) -> TokenStream {
    match ty {
        FieldType::U8 => quote!(u8),
        FieldType::U16 => quote!(u16),
        FieldType::U32 | FieldType::Buf => quote!(u32),
        FieldType::U64 => quote!(u64),
        FieldType::Usize => quote!(usize),
        FieldType::I32 => quote!(i32),
        FieldType::F32 => quote!(f32),
        FieldType::OptBuf => quote!(Option<u32>),
        FieldType::Array(inner, n) => {
            let inner_ts = enum_type_tokens(inner);
            quote!([#inner_ts; #n])
        }
        FieldType::Vec(inner) => {
            let inner_ts = enum_type_tokens(inner);
            quote!(Vec<#inner_ts>)
        }
        _ => quote!(u32), // fallback
    }
}

/// Convert a shell `FieldType` to the Rust type used in trait method parameters.
///
/// Large arrays and Vecs are passed by reference.
fn trait_type_tokens(ty: &FieldType) -> TokenStream {
    match ty {
        FieldType::Array(inner, n) if array_is_ref(inner, *n) => {
            let inner_ts = enum_type_tokens(inner);
            quote!(&[#inner_ts; #n])
        }
        FieldType::Vec(inner) => {
            let inner_ts = enum_type_tokens(inner);
            quote!(&[#inner_ts])
        }
        other => enum_type_tokens(other),
    }
}

/// Whether the given array type should be passed by reference in trait methods.
///
/// Arrays larger than 8 bytes are passed by reference.
fn array_is_ref(elem: &FieldType, count: usize) -> bool {
    let elem_bytes = match elem {
        FieldType::U8 => 1,
        FieldType::U16 => 2,
        FieldType::U32 | FieldType::I32 | FieldType::F32 | FieldType::Buf => 4,
        FieldType::U64 | FieldType::Usize => 8,
        _ => 8,
    };
    elem_bytes * count > 8
}

/// Whether a field needs `*` dereference in the match arm.
///
/// Scalars and small arrays are dereferenced (copied). Large arrays and Vecs
/// are passed by reference directly.
fn needs_deref(ty: &FieldType) -> bool {
    match ty {
        FieldType::Array(inner, n) => !array_is_ref(inner, *n),
        FieldType::Vec(_) => false,
        _ => true,
    }
}

fn ident(s: &str) -> Ident {
    Ident::new(s, Span::call_site())
}

// ============================================================================
// Enum generation
// ============================================================================

/// Generate the `IsaInstruction` enum.
///
/// ```text
/// #[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
/// #[archive(check_bytes)]
/// pub enum IsaInstruction {
///     Add { dst: u32, a: u32, b: u32, count: usize },
///     ...
/// }
/// ```
pub fn emit_instruction_enum(shell: &Shell) -> TokenStream {
    let ops = resolve_ops(shell);
    let variants: Vec<TokenStream> = ops
        .iter()
        .map(|op| {
            let var = ident(&op.variant_name);
            let fields: Vec<TokenStream> = op
                .params
                .iter()
                .map(|p| {
                    let name = ident(&p.name);
                    let ty = enum_type_tokens(&p.ty);
                    quote!(#name: #ty)
                })
                .collect();
            quote!(#var { #(#fields),* })
        })
        .collect();

    quote! {
        #[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
        #[archive(check_bytes)]
        #[allow(missing_docs)]
        pub enum IsaInstruction {
            #(#variants),*
        }
    }
}

// ============================================================================
// Trait generation
// ============================================================================

/// Generate the `InstructionDispatcher` trait.
///
/// ```text
/// pub trait InstructionDispatcher {
///     fn exec_add(&mut self, dst: u32, a: u32, b: u32, count: usize) -> Result<()>;
///     ...
/// }
/// ```
pub fn emit_dispatcher_trait(shell: &Shell) -> TokenStream {
    let ops = resolve_ops(shell);
    let methods: Vec<TokenStream> = ops
        .iter()
        .map(|op| {
            let method = ident(&op.method_name);
            let params: Vec<TokenStream> = op
                .params
                .iter()
                .map(|p| {
                    let name = ident(&p.name);
                    let ty = trait_type_tokens(&p.ty);
                    quote!(#name: #ty)
                })
                .collect();
            quote! {
                fn #method(&mut self, #(#params),*) -> Result<()>;
            }
        })
        .collect();

    quote! {
        #[allow(clippy::too_many_arguments)]
        #[allow(missing_docs)]
        pub trait InstructionDispatcher {
            #(#methods)*
        }
    }
}

// ============================================================================
// ExecuteOn match generation
// ============================================================================

/// Generate the `ExecuteOn<D>` impl with match dispatch.
///
/// ```text
/// impl<D: InstructionDispatcher> ExecuteOn<D> for IsaInstruction {
///     #[inline]
///     fn execute(&self, d: &mut D) -> Result<()> {
///         match self {
///             Self::Add { dst, a, b, count } => d.exec_add(*dst, *a, *b, *count),
///             ...
///         }
///     }
/// }
/// ```
pub fn emit_execute_on(shell: &Shell) -> TokenStream {
    let ops = resolve_ops(shell);
    let arms: Vec<TokenStream> = ops
        .iter()
        .map(|op| {
            let var = ident(&op.variant_name);
            let method = ident(&op.method_name);
            let bindings: Vec<Ident> = op.params.iter().map(|p| ident(&p.name)).collect();
            let args: Vec<TokenStream> = op
                .params
                .iter()
                .map(|p| {
                    let name = ident(&p.name);
                    if needs_deref(&p.ty) {
                        quote!(*#name)
                    } else {
                        quote!(#name)
                    }
                })
                .collect();
            quote! {
                Self::#var { #(#bindings),* } => d.#method(#(#args),*),
            }
        })
        .collect();

    quote! {
        impl<D: InstructionDispatcher> ExecuteOn<D> for IsaInstruction {
            #[inline]
            #[allow(clippy::too_many_lines)]
            fn execute(&self, d: &mut D) -> Result<()> {
                match self {
                    #(#arms)*
                }
            }
        }
    }
}

// ============================================================================
// CPU dispatcher impl generation
// ============================================================================

/// Generate the CPU dispatcher impl method bodies (pure delegation).
///
/// Returns only the method definitions, without an `impl` wrapper.
/// The caller provides the `impl ... for ... { }` block at the include site.
///
/// ```text
/// fn exec_add(&mut self, dst: u32, a: u32, b: u32, count: usize) -> Result<()> {
///     dispatch::exec_add(self, dst, a, b, count)
/// }
/// ```
pub fn emit_dispatcher_impl(shell: &Shell) -> TokenStream {
    let ops = resolve_ops(shell);
    let methods: Vec<TokenStream> = ops
        .iter()
        .map(|op| {
            let method = ident(&op.method_name);
            let params: Vec<TokenStream> = op
                .params
                .iter()
                .map(|p| {
                    let name = ident(&p.name);
                    let ty = trait_type_tokens(&p.ty);
                    quote!(#name: #ty)
                })
                .collect();
            let args: Vec<Ident> = op.params.iter().map(|p| ident(&p.name)).collect();
            quote! {
                fn #method(&mut self, #(#params),*) -> Result<()> {
                    dispatch::#method(self, #(#args),*)
                }
            }
        })
        .collect();

    quote! {
        #(#methods)*
    }
}

// ============================================================================
// Builder generation
// ============================================================================

/// Generate builder structs for all `@builder`-annotated ops.
pub fn emit_builder_structs(shell: &Shell) -> TokenStream {
    let mut builders = TokenStream::new();

    for item in &shell.items {
        if let ShellItem::Op(op) = item {
            if op.has_builder() {
                builders.extend(emit_single_builder(op));
            }
        }
    }

    // Factory methods on IsaInstruction
    let factories: Vec<TokenStream> = shell
        .items
        .iter()
        .filter_map(|item| {
            if let ShellItem::Op(op) = item {
                if op.has_builder() {
                    let method = ident(&op.name);
                    let builder = ident(&format!("{}Builder", naming::to_pascal_case(&op.name)));
                    let doc = format!(
                        "Create a `{}` instruction builder.",
                        naming::to_pascal_case(&op.name)
                    );
                    return Some(quote! {
                        #[doc = #doc]
                        #[must_use]
                        pub fn #method() -> #builder {
                            #builder::new()
                        }
                    });
                }
            }
            None
        })
        .collect();

    if !factories.is_empty() {
        builders.extend(quote! {
            impl IsaInstruction {
                #(#factories)*
            }
        });
    }

    builders
}

/// Generate a single builder struct + impl for one op.
fn emit_single_builder(op: &OpDef) -> TokenStream {
    let variant = ident(&naming::variant_name(&op.name, &op.annotations));
    let builder_name = ident(&format!("{}Builder", naming::to_pascal_case(&op.name)));

    // Collect builder fields and setters
    let mut field_defs = Vec::new();
    let mut field_defaults = Vec::new();
    let mut setters = Vec::new();
    let mut build_fields = Vec::new();

    for param in &op.params {
        match param {
            OpParam::Simple(p) => {
                emit_simple_builder_field(
                    p,
                    &mut field_defs,
                    &mut field_defaults,
                    &mut setters,
                    &mut build_fields,
                );
            }
            OpParam::Pair { group_name, params } => {
                emit_pair_builder_field(
                    group_name,
                    params,
                    &mut field_defs,
                    &mut field_defaults,
                    &mut setters,
                    &mut build_fields,
                );
            }
            OpParam::Group { group_name, params } => {
                emit_group_builder_field(
                    group_name,
                    params,
                    &mut field_defs,
                    &mut field_defaults,
                    &mut setters,
                    &mut build_fields,
                );
            }
        }
    }

    quote! {
        /// Builder for [`IsaInstruction`] variant.
        #[derive(Debug, Clone)]
        #[allow(missing_docs)]
        pub struct #builder_name {
            #(#field_defs),*
        }

        impl Default for #builder_name {
            fn default() -> Self { Self::new() }
        }

        #[allow(missing_docs)]
        impl #builder_name {
            /// Create a new builder with default parameters.
            #[must_use]
            pub fn new() -> Self {
                Self {
                    #(#field_defaults),*
                }
            }

            #(#setters)*

            /// Build the instruction from the configured parameters.
            pub fn build(self) -> Result<IsaInstruction, BuilderError> {
                Ok(IsaInstruction::#variant {
                    #(#build_fields),*
                })
            }
        }
    }
}

/// Emit builder field/setter/build for a simple parameter.
fn emit_simple_builder_field(
    p: &Param,
    field_defs: &mut Vec<TokenStream>,
    field_defaults: &mut Vec<TokenStream>,
    setters: &mut Vec<TokenStream>,
    build_fields: &mut Vec<TokenStream>,
) {
    let name = ident(&p.name);
    let field_name_str = &p.name;

    match (&p.ty, &p.default) {
        // Optional buffer — starts None, not required
        (FieldType::OptBuf, _) => {
            field_defs.push(quote!(#name: Option<u32>));
            field_defaults.push(quote!(#name: None));
            setters.push(quote! {
                #[must_use]
                pub fn #name(mut self, val: u32) -> Self {
                    self.#name = Some(val);
                    self
                }
            });
            build_fields.push(quote!(#name: self.#name));
        }
        // Has default — bare type with default value
        (ty, Some(def)) => {
            let rust_ty = enum_type_tokens(ty);
            let default_val = default_value_tokens(def, ty);
            field_defs.push(quote!(#name: #rust_ty));
            field_defaults.push(quote!(#name: #default_val));
            setters.push(quote! {
                #[must_use]
                pub fn #name(mut self, val: #rust_ty) -> Self {
                    self.#name = val;
                    self
                }
            });
            build_fields.push(quote!(#name: self.#name));
        }
        // No default, buf type — required
        (FieldType::Buf, None) => {
            field_defs.push(quote!(#name: Option<u32>));
            field_defaults.push(quote!(#name: None));
            setters.push(quote! {
                #[must_use]
                pub fn #name(mut self, val: u32) -> Self {
                    self.#name = Some(val);
                    self
                }
            });
            build_fields.push(quote! {
                #name: self.#name.ok_or(BuilderError::missing_field(#field_name_str))?
            });
        }
        // No default, other scalar — required
        (ty, None) => {
            let rust_ty = enum_type_tokens(ty);
            field_defs.push(quote!(#name: Option<#rust_ty>));
            field_defaults.push(quote!(#name: None));
            setters.push(quote! {
                #[must_use]
                pub fn #name(mut self, val: #rust_ty) -> Self {
                    self.#name = Some(val);
                    self
                }
            });
            build_fields.push(quote! {
                #name: self.#name.ok_or(BuilderError::missing_field(#field_name_str))?
            });
        }
    }
}

/// Emit builder field/setter/build for a `@pair` parameter group.
fn emit_pair_builder_field(
    group_name: &str,
    params: &[Param],
    field_defs: &mut Vec<TokenStream>,
    field_defaults: &mut Vec<TokenStream>,
    setters: &mut Vec<TokenStream>,
    build_fields: &mut Vec<TokenStream>,
) {
    let pair_name = ident(group_name);
    let pair_name_str = group_name;
    let all_have_defaults = params.iter().all(|p| p.default.is_some());

    // Get the types (pairs are typically homogeneous but we handle heterogeneous)
    let types: Vec<TokenStream> = params.iter().map(|p| enum_type_tokens(&p.ty)).collect();
    let param_names: Vec<Ident> = params.iter().map(|p| ident(&p.name)).collect();

    if all_have_defaults {
        // Pair with defaults — stored as tuple with default values
        let defaults: Vec<TokenStream> = params
            .iter()
            .map(|p| default_value_tokens(p.default.as_ref().unwrap(), &p.ty))
            .collect();

        let tuple_ty = quote!((#(#types),*));
        field_defs.push(quote!(#pair_name: #tuple_ty));
        field_defaults.push(quote!(#pair_name: (#(#defaults),*)));
        setters.push(quote! {
            #[must_use]
            pub fn #pair_name(mut self, #(#param_names: #types),*) -> Self {
                self.#pair_name = (#(#param_names),*);
                self
            }
        });
        // Split tuple into individual enum fields
        for (i, p) in params.iter().enumerate() {
            let field_name = ident(&p.name);
            let idx = proc_macro2::Literal::usize_unsuffixed(i);
            build_fields.push(quote!(#field_name: self.#pair_name.#idx));
        }
    } else {
        // Pair without all defaults — Option<tuple>, required
        let tuple_ty = quote!((#(#types),*));
        field_defs.push(quote!(#pair_name: Option<#tuple_ty>));
        field_defaults.push(quote!(#pair_name: None));
        setters.push(quote! {
            #[must_use]
            pub fn #pair_name(mut self, #(#param_names: #types),*) -> Self {
                self.#pair_name = Some((#(#param_names),*));
                self
            }
        });
        for (i, p) in params.iter().enumerate() {
            let field_name = ident(&p.name);
            let idx = proc_macro2::Literal::usize_unsuffixed(i);
            build_fields.push(quote! {
                #field_name: self.#pair_name
                    .ok_or(BuilderError::missing_field(#pair_name_str))?.#idx
            });
        }
    }
}

/// Emit builder field/setter/build for a `@group` parameter group.
fn emit_group_builder_field(
    group_name: &str,
    params: &[Param],
    field_defs: &mut Vec<TokenStream>,
    field_defaults: &mut Vec<TokenStream>,
    setters: &mut Vec<TokenStream>,
    build_fields: &mut Vec<TokenStream>,
) {
    let setter_name = ident(group_name);

    // Each group member gets its own field
    for p in params {
        emit_simple_builder_field(p, field_defs, field_defaults, &mut Vec::new(), build_fields);
    }

    // Add individual setters for group members
    for p in params {
        let name = ident(&p.name);
        let rust_ty = match (&p.ty, &p.default) {
            (FieldType::OptBuf, _) => quote!(u32),
            (ty, Some(_)) => enum_type_tokens(ty),
            (ty, None) => enum_type_tokens(ty),
        };
        let setter_body = if p.default.is_some() || matches!(p.ty, FieldType::OptBuf) {
            // Field stored as bare type or Option (optional)
            match (&p.ty, &p.default) {
                (FieldType::OptBuf, _) => quote!(self.#name = Some(val)),
                (_, Some(_)) => quote!(self.#name = val),
                _ => quote!(self.#name = Some(val)),
            }
        } else {
            quote!(self.#name = Some(val))
        };
        setters.push(quote! {
            #[must_use]
            pub fn #name(mut self, val: #rust_ty) -> Self {
                #setter_body;
                self
            }
        });
    }

    // Compound setter sets all at once
    let param_names: Vec<Ident> = params.iter().map(|p| ident(&p.name)).collect();
    let param_types: Vec<TokenStream> = params.iter().map(|p| enum_type_tokens(&p.ty)).collect();
    let assignments: Vec<TokenStream> = params
        .iter()
        .map(|p| {
            let name = ident(&p.name);
            if p.default.is_some() {
                quote!(self.#name = #name)
            } else {
                quote!(self.#name = Some(#name))
            }
        })
        .collect();

    setters.push(quote! {
        #[must_use]
        pub fn #setter_name(mut self, #(#param_names: #param_types),*) -> Self {
            #(#assignments;)*
            self
        }
    });
}

/// Convert a shell `DefaultValue` to a Rust literal token.
fn default_value_tokens(def: &DefaultValue, ty: &FieldType) -> TokenStream {
    match (def, ty) {
        (DefaultValue::None, _) => quote!(None),
        (DefaultValue::Int(n), FieldType::Usize) => {
            let v = *n as usize;
            quote!(#v)
        }
        (DefaultValue::Int(n), FieldType::U8) => {
            let v = *n as u8;
            quote!(#v)
        }
        (DefaultValue::Int(n), FieldType::U32 | FieldType::Buf) => {
            let v = *n as u32;
            quote!(#v)
        }
        (DefaultValue::Int(n), _) => quote!(#n),
        (DefaultValue::Float(f), _) => {
            let v = *f as f32;
            quote!(#v)
        }
        (DefaultValue::Ident(s), _) => {
            let id = ident(s);
            quote!(#id)
        }
    }
}

// ============================================================================
// Kernel classification generation
// ============================================================================

/// Generate the `classify_instruction` function for GPU kernel dispatch.
///
/// Maps each `IsaInstruction` variant to a `KernelCategory` based on
/// `@kernel("Category")` annotations in the shell definition.
///
/// ```text
/// pub fn classify_instruction(instr: &IsaInstruction) -> KernelCategory {
///     match instr {
///         IsaInstruction::Add { .. } => KernelCategory::ElementWise,
///         ...
///     }
/// }
/// ```
pub fn emit_kernel_classify(shell: &Shell) -> TokenStream {
    let ops = resolve_ops(shell);

    // Group variants by kernel category to emit merged `|` arms (avoids clippy::match_same_arms).
    let mut by_category: std::collections::BTreeMap<String, Vec<String>> =
        std::collections::BTreeMap::new();
    for op in &ops {
        if let Some(cat) = &op.kernel_category {
            by_category
                .entry(cat.clone())
                .or_default()
                .push(op.variant_name.clone());
        }
    }

    let arms: Vec<TokenStream> = by_category
        .iter()
        .map(|(cat_str, variants)| {
            let cat = ident(cat_str);
            let pats: Vec<TokenStream> = variants
                .iter()
                .map(|v| {
                    let var = ident(v);
                    quote! { IsaInstruction::#var { .. } }
                })
                .collect();
            quote! {
                #(#pats)|* => KernelCategory::#cat,
            }
        })
        .collect();

    quote! {
        /// Classification of ISA instruction into kernel category.
        ///
        /// Generated from `@kernel` annotations in `isa.shell`.
        #[must_use]
        pub fn classify_instruction(instr: &hologram_holo::IsaInstruction) -> KernelCategory {
            use hologram_holo::IsaInstruction;
            match instr {
                #(#arms)*
            }
        }
    }
}

/// Generate an `impl IsaInstruction { pub fn name(&self) -> &'static str }` method
/// that returns the variant name as a string.
pub fn emit_instruction_name(shell: &Shell) -> TokenStream {
    let ops = resolve_ops(shell);
    let arms: Vec<TokenStream> = ops
        .iter()
        .map(|op| {
            let var = ident(&op.variant_name);
            let name = &op.variant_name;
            quote! {
                Self::#var { .. } => #name,
            }
        })
        .collect();

    quote! {
        impl IsaInstruction {
            /// Returns the variant name of this instruction as a static string.
            #[must_use]
            pub fn name(&self) -> &'static str {
                match self {
                    #(#arms)*
                }
            }
        }
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parse::parse_shell;

    fn test_shell() -> Shell {
        parse_shell(r#"
            shell isa {
                group binary_arith(dst: buf, a: buf, b: buf, count: usize) {
                    add,
                    sub
                }
                group lut_activation(dst: buf, src: buf, count: usize) @suffix("LUT") {
                    sigmoid = SIGMOID_256,
                    tanh    = TANH_256
                }
                op matmul(c: buf, a: buf, b: buf, m: usize, k: usize, n: usize) @variant("MatMul")
                op softmax(dst: buf, src: buf, outer: usize, axis: usize, inner: usize)
                op transpose(dst: buf, src: buf, count: usize, ndim: u8, shape: [usize; 8], perm: [u8; 8])
                op call_layer(layer_id: u64, inputs: vec<buf>, outputs: vec<buf>)
                op conv2d(
                    dst: buf, input: buf, weight: buf, bias: buf? = none,
                    @pair kernel(kernel_h: usize = 3, kernel_w: usize = 3),
                    groups: usize = 1,
                    @group input_shape(batch: usize, in_channels: usize)
                ) @builder
            }
        "#).unwrap()
    }

    #[test]
    fn resolve_ops_count() {
        let shell = test_shell();
        let ops = resolve_ops(&shell);
        // 2 binary + 2 lut + matmul + softmax + transpose + call_layer + conv2d = 9
        assert_eq!(ops.len(), 9);
    }

    #[test]
    fn resolve_ops_naming() {
        let shell = test_shell();
        let ops = resolve_ops(&shell);
        assert_eq!(ops[0].variant_name, "Add");
        assert_eq!(ops[0].method_name, "exec_add");
        assert_eq!(ops[2].variant_name, "SigmoidLUT");
        assert_eq!(ops[2].method_name, "exec_sigmoid_lut");
        assert_eq!(ops[4].variant_name, "MatMul");
        assert_eq!(ops[4].method_name, "exec_matmul");
    }

    #[test]
    fn enum_generation_compiles() {
        let shell = test_shell();
        let tokens = emit_instruction_enum(&shell);
        let code = tokens.to_string();
        assert!(code.contains("Add"));
        assert!(code.contains("SigmoidLUT"));
        assert!(code.contains("MatMul"));
        assert!(code.contains("dst : u32"));
        assert!(code.contains("Option < u32 >"));
        assert!(code.contains("Vec < u32 >"));
        assert!(code.contains("[usize ; 8usize]"));
        assert!(code.contains("[u8 ; 8usize]"));
    }

    #[test]
    fn trait_generation_ref_types() {
        let shell = test_shell();
        let tokens = emit_dispatcher_trait(&shell);
        let code = tokens.to_string();
        // Large arrays should be passed by reference in trait
        assert!(code.contains("& [usize ; 8usize]"));
        // Small arrays by value
        assert!(code.contains("[u8 ; 8usize]"));
        // No & prefix on u8 array (it's small enough to copy)
        // Vec should be &[T]
        assert!(code.contains("& [u32]"));
    }

    #[test]
    fn execute_on_deref_patterns() {
        let shell = test_shell();
        let tokens = emit_execute_on(&shell);
        let code = tokens.to_string();
        // Scalars get dereferenced
        assert!(code.contains("* dst"));
        // Large arrays don't get dereferenced
        assert!(code.contains("shape ,")); // no * before shape
                                           // Vec passed by reference
        assert!(code.contains("inputs ,")); // no * before inputs
    }

    #[test]
    fn dispatcher_impl_delegation() {
        let shell = test_shell();
        let tokens = emit_dispatcher_impl(&shell);
        let code = tokens.to_string();
        assert!(code.contains("dispatch :: exec_add"));
        assert!(code.contains("dispatch :: exec_sigmoid_lut"));
        assert!(code.contains("dispatch :: exec_matmul"));
    }

    #[test]
    fn builder_struct_generated() {
        let shell = test_shell();
        let tokens = emit_builder_structs(&shell);
        let code = tokens.to_string();
        assert!(code.contains("Conv2dBuilder"));
        assert!(code.contains("pub fn new"));
        assert!(code.contains("pub fn build"));
        // Pair field
        assert!(code.contains("kernel :"));
        // Group compound setter
        assert!(code.contains("fn input_shape"));
        // Factory method
        assert!(code.contains("fn conv2d"));
    }

    #[test]
    fn compose_excluded_from_ops() {
        let shell = parse_shell(
            r#"
            shell test {
                group unary(dst: buf, src: buf, count: usize) {
                    sigmoid,
                    tanh,
                    relu
                }
                op sha256(dst: buf, src: buf, src_len: usize)
                compose standard_normalize = [sigmoid, tanh, relu]
                compose double_sha256 = [sha256, sha256]
            }
        "#,
        )
        .unwrap();

        let ops = resolve_ops(&shell);
        // 3 group members + 1 op = 4 (composes are metadata, not ISA ops)
        assert_eq!(ops.len(), 4);

        // Composes should NOT appear as ISA ops
        assert!(ops.iter().all(|o| o.variant_name != "StandardNormalize"));
        assert!(ops.iter().all(|o| o.variant_name != "DoubleSha256"));
    }

    #[test]
    fn full_isa_shell_resolves() {
        let input = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../descriptors/shells/isa.shell"
        ))
        .unwrap();
        let shell = parse_shell(&input).unwrap();
        let ops = resolve_ops(&shell);

        let names: Vec<&str> = ops.iter().map(|o| o.variant_name.as_str()).collect();

        // All 66 ISA variant names (composes excluded — they are table metadata)
        let expected = [
            // binary_arith group (7)
            "Add",
            "Sub",
            "Mul",
            "Div",
            "Pow",
            "ElemMin",
            "ElemMax",
            // unary_arith group (4)
            "Sqrt",
            "Log",
            "Exp",
            "Abs",
            // comparison group (4)
            "Greater",
            "Less",
            "LessOrEqual",
            "GreaterOrEqual",
            // where op (1)
            "Where",
            // float_activation group (3)
            "Sigmoid",
            "Tanh",
            "Relu",
            // lut_activation group (9)
            "SigmoidLUT",
            "TanhLUT",
            "ExpLUT",
            "LogLUT",
            "ReluLUT",
            "SqrtLUT",
            "AbsLUT",
            "GeluLUT",
            "SiluLUT",
            // softmax op (1)
            "Softmax",
            // linear algebra ops (3)
            "MatMul",
            "BatchMatMul",
            "MatMulLUT",
            // reduction group (3)
            "Sum",
            "Max",
            "Min",
            // reduce_mean op (1)
            "ReduceMean",
            // categorical group (2)
            "Lift",
            "OrbitClassify",
            // ring_ops group (2)
            "RingAdd",
            "RingMul",
            // memory ops (3)
            "Load",
            "Store",
            "Copy",
            // composition (1)
            "CallLayer",
            // codec ops (2)
            "Encode",
            "Decode",
            // shape ops (11)
            "Reshape",
            "Unsqueeze",
            "Squeeze",
            "Transpose",
            "Gather",
            "Concat",
            "Slice",
            "Pad",
            "Cast",
            "Tile",
            "Expand",
            // CNN ops (6)
            "Conv2d",
            "BatchNorm",
            "LayerNorm",
            "MaxPool2d",
            "AvgPool2d",
            "GlobalAvgPool",
            // hash ops (2)
            "Sha256",
            "DoubleSha256",
            // tokenization (1)
            "ViterbiTokenize",
            // fused ops (2)
            "MatMulRelu",
            "AddSigmoid",
        ];

        assert_eq!(
            ops.len(),
            expected.len(),
            "expected {} ops, got {}. Missing: {:?}",
            expected.len(),
            ops.len(),
            expected
                .iter()
                .filter(|e| !names.contains(e))
                .collect::<Vec<_>>()
        );

        for name in &expected {
            assert!(names.contains(name), "missing variant: {name}");
        }
    }

    #[test]
    fn full_isa_generates_all() {
        let input = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../descriptors/shells/isa.shell"
        ))
        .unwrap();
        let shell = parse_shell(&input).unwrap();

        let enum_code = emit_instruction_enum(&shell).to_string();
        let trait_code = emit_dispatcher_trait(&shell).to_string();
        let match_code = emit_execute_on(&shell).to_string();
        let impl_code = emit_dispatcher_impl(&shell).to_string();
        let builder_code = emit_builder_structs(&shell).to_string();

        // All should be non-empty
        assert!(!enum_code.is_empty());
        assert!(!trait_code.is_empty());
        assert!(!match_code.is_empty());
        assert!(!impl_code.is_empty());
        assert!(!builder_code.is_empty());

        // Builders should exist for annotated ops
        assert!(builder_code.contains("Conv2dBuilder"));
        assert!(builder_code.contains("BatchNormBuilder"));
        assert!(builder_code.contains("MaxPool2dBuilder"));
        assert!(builder_code.contains("AvgPool2dBuilder"));
    }

    #[test]
    fn kernel_category_propagated() {
        let shell = parse_shell(
            r#"
            shell test {
                group arith(dst: buf, a: buf, b: buf, count: usize) @kernel("ElementWise") {
                    add, sub
                }
                op matmul(c: buf, a: buf, b: buf, m: usize, k: usize, n: usize) @kernel("Matrix")
                op noop(dst: buf)
            }
        "#,
        )
        .unwrap();

        let ops = resolve_ops(&shell);
        assert_eq!(ops[0].kernel_category.as_deref(), Some("ElementWise"));
        assert_eq!(ops[1].kernel_category.as_deref(), Some("ElementWise"));
        assert_eq!(ops[2].kernel_category.as_deref(), Some("Matrix"));
        assert_eq!(ops[3].kernel_category, None);
    }

    #[test]
    fn kernel_classify_codegen() {
        let shell = parse_shell(
            r#"
            shell test {
                group arith(dst: buf, a: buf, b: buf, count: usize) @kernel("ElementWise") {
                    add, sub
                }
                op sha256(dst: buf, src: buf, src_len: usize) @kernel("ElementWise")
                group lut(dst: buf, src: buf, count: usize) @suffix("LUT") @kernel("Categorical") {
                    sigmoid = SIG_256
                }
            }
        "#,
        )
        .unwrap();

        let code = emit_kernel_classify(&shell).to_string();
        // Merged arms: Add | Sub | Sha256 => ElementWise
        assert!(code.contains("Add { .. }"));
        assert!(code.contains("Sub { .. }"));
        assert!(code.contains("Sha256 { .. }"));
        assert!(code.contains("KernelCategory :: ElementWise"));
        assert!(code.contains("SigmoidLUT { .. }"));
        assert!(code.contains("KernelCategory :: Categorical"));
    }

    #[test]
    fn full_isa_kernel_classify() {
        let input = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../descriptors/shells/isa.shell"
        ))
        .unwrap();
        let shell = parse_shell(&input).unwrap();

        let code = emit_kernel_classify(&shell).to_string();
        // All ops should have kernel categories
        let ops = resolve_ops(&shell);
        for op in &ops {
            assert!(
                op.kernel_category.is_some(),
                "op {} missing @kernel annotation",
                op.variant_name
            );
        }
        // Spot-check: all categories present, key variants present
        for cat in &[
            "ElementWise",
            "Matrix",
            "Reduction",
            "Categorical",
            "Memory",
            "Control",
        ] {
            assert!(
                code.contains(&format!("KernelCategory :: {cat}")),
                "missing category {cat}"
            );
        }
        for var in &[
            "Add",
            "MatMul",
            "Sum",
            "Lift",
            "Copy",
            "CallLayer",
            "Sha256",
        ] {
            assert!(
                code.contains(&format!("{var} {{ .. }}")),
                "missing variant {var}"
            );
        }
    }
}
