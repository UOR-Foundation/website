# Integration Guide: Identity + Your Space Modules
## For merging into UOR-Foundation/website

---

## Architecture Overview

This project contains two modules that need to be merged into the main Hologram OS repo:

| Module | Purpose | Target in main repo |
|--------|---------|-------------------|
| `identity` | Auth engine, ceremonies, crypto, UOR derivation, trust engine, sovereignty | `src/modules/identity/` (replace existing) |
| `your-space` | Dashboard, journey, trust graph viz, profile UI, myspace experience | `src/modules/your-space/` (replace existing) |

Additionally, shared infrastructure:
- `src/hooks/use-auth.tsx` → Reactive auth context (goes in `src/hooks/` or `src/modules/core/hooks/`)
- `src/modules/hologram-ui/components/MobileBottomNav.tsx` → Mobile PWA nav
- `src/modules/hologram-ui/components/DesktopOsSidebar.tsx` → Auth-aware sidebar
- `src/modules/hologram-ui/components/HologramOsLayout.tsx` → Layout with mobile nav
- `supabase/functions/sovereign-inference/` → Edge function

---

## Step-by-Step Integration

### 1. Copy Identity Module (Auth Engine)

Copy these **directly** into `src/modules/identity/` in the main repo:

```
src/modules/identity/
├── engine/                          # Pure functions — no side effects
│   ├── attestation-engine.ts
│   ├── boundary-violation-detector.ts
│   ├── ceremony-engine.ts
│   ├── disclosure-engine.ts
│   ├── index.ts
│   ├── path-integral-engine.ts
│   ├── pq-crypto.ts
│   ├── sovereignty-engine.ts
│   ├── three-axis-engine.ts
│   └── trust-engine.ts
├── types.ts                         # All type definitions
├── types/
│   ├── path-integral.ts
│   └── three-axis.ts
├── hooks/
│   ├── index.ts
│   ├── useIdentity.ts               # Main identity hook (Supabase-connected)
│   ├── useSovereignConversations.ts
│   ├── useTrustGraph.ts
│   ├── mock-data.ts
│   └── mock-graph-data.ts
├── components/
│   ├── IdentityCreationFlow.tsx      # Auth flow (magic link, OAuth, naming)
│   ├── ClaimIdentityDialog.tsx
│   ├── CeremonyHistory.tsx
│   ├── CommitmentHistory.tsx
│   ├── ConsentManager.tsx
│   ├── GlossaryTooltip.tsx
│   ├── IdentityProfileCard.tsx
│   ├── OnboardingWalkthrough.tsx
│   ├── PathIntegralPanel.tsx
│   ├── PermissionsPanel.tsx
│   ├── PrivacyPolicyViewer.tsx
│   ├── SelectiveDisclosurePanel.tsx
│   ├── SovereignInferencePanel.tsx
│   ├── SovereigntyMap.tsx
│   ├── StatCard.tsx
│   ├── ThreeAxisPanel.tsx
│   ├── TrustCeremonyDialog.tsx
│   ├── TrustMeter.tsx
│   ├── ViolationAlert.tsx
│   └── index.ts
├── index.ts
└── module.json
```

**Delete the `compat/` folder** — in the main repo, real Hologram OS hooks replace the stubs.

### 2. Copy Your-Space Module (Dashboard/UI)

Move these components into `src/modules/your-space/`:

```
src/modules/your-space/
├── components/
│   ├── TrustGraph.tsx               # Force-directed trust network (canvas)
│   ├── IdentityJourney.tsx          # 6-facet exploration journey
│   ├── CoverImage.tsx               # Profile cover image
│   ├── AvatarUpload.tsx             # Avatar upload component
│   ├── EditProfileDialog.tsx        # Profile editing dialog
│   └── ConversationSidebar.tsx      # AI conversation sidebar
├── pages/
│   ├── YourSpaceRouter.tsx          # Smart auth router (→ auth or → dashboard)
│   ├── YourSpaceDashboard.tsx       # Main dashboard (was IdentityDashboard)
│   └── TrustGraphPage.tsx           # Full-page trust network
├── index.ts
└── module.json
```

### 3. Shared Infrastructure

#### Auth Hook
Copy `src/hooks/use-auth.tsx` to `src/hooks/use-auth.tsx` (or `src/modules/core/hooks/use-auth.tsx`).

Wrap your app's root with `<AuthProvider>`:
```tsx
import { AuthProvider } from "@/hooks/use-auth";

// In App.tsx root:
<AuthProvider>
  <QueryClientProvider client={queryClient}>
    ...
  </QueryClientProvider>
</AuthProvider>
```

#### Sidebar Updates
Update `DesktopOsSidebar.tsx` to:
- Import `useAuth` for reactive auth state
- Show user avatar + name when logged in
- Add sign-out button
- Rename "Identity" nav item to "My Space"

#### Mobile Bottom Nav
Copy `MobileBottomNav.tsx` into `hologram-ui/components/` and update `HologramOsLayout.tsx` to include it.

### 4. Routes

Add to your router:
```tsx
<Route path="/myspace" element={<YourSpaceRouter />} />
<Route path="/myspace/explore" element={<YourSpaceDashboard />} />
<Route path="/myspace/graph" element={<TrustGraphPage />} />
```

### 5. Database Schema

These tables must exist (with RLS):

| Table | Purpose |
|-------|---------|
| `profiles` | User profile (display_name, handle, avatar_url, cover_image_url, uor_id, explored_facets) |
| `trust_nodes` | Graph nodes (name, type, trust_level, verified, description) |
| `trust_edges` | Graph edges (source_node_id, target_node_id, type, strength) |
| `trust_constellations` | Bookmarked nodes |
| `identity_ceremonies` | Ceremony records (ceremony_type, uor_id, metadata) |

Database function required:
```sql
CREATE OR REPLACE FUNCTION public.derive_uor_id(p_user_id uuid)
RETURNS text LANGUAGE sql IMMUTABLE
SET search_path TO 'public', 'extensions'
AS $$ SELECT 'uor:' || encode(extensions.digest(p_user_id::text || ':uor-identity-v1', 'sha256'), 'hex') $$;
```

Storage buckets: `avatars` (public), `cover-images` (public).

### 6. Dependencies

Ensure these are in `package.json`:
```
react-force-graph-2d    (trust graph visualization)
@lovable.dev/cloud-auth-js  (OAuth — Google, Apple)
```

### 7. Import Remapping (Compat → Real)

When merging, replace compat imports:
```
@/modules/identity/compat/hooks   →  @/modules/hologram-os/hooks
@/modules/identity/compat/palette →  @/modules/hologram-os/design-tokens
```

---

## Auth Flow Summary

```
Click "My Space" icon
  ├─ Not logged in → /myspace → redirect → IdentityCreationFlow (auth phase)
  │   ├─ Magic Link (email OTP)
  │   ├─ Google OAuth
  │   └─ Apple OAuth
  │   → After auth: naming phase → crystallization → dashboard
  │
  ├─ Logged in, no profile → /myspace → redirect → IdentityCreationFlow (naming phase)
  │   → naming → crystallization → dashboard
  │
  └─ Logged in, has profile → /myspace → redirect → /myspace/explore (dashboard)

Sign out → Home page. Same email always = same UOR ID (deterministic derivation).
```

---

## Edge Function

Copy `supabase/functions/sovereign-inference/` for the AI-powered inference panel.

---

## Namespace Registry

Add to `src/modules/namespace-registry.ts`:
```ts
"your-space": {
  prefix: "ys",
  routes: ["/myspace", "/myspace/explore", "/myspace/graph"],
  depends: ["identity", "hologram-ui"],
}
```
