# Hologram

O(1) compute acceleration via pre-computed lookup tables. Hologram maps computational operations onto a triadic cellular automaton that executes wavefront-parallel steps across a 4992-bit state, targeting constant-time evaluation through algebraic structure rather than brute-force optimization.

## Features

- **Full ML Operation Support**: MatMul, LayerNorm, Softmax, Conv2d, attention patterns
- **SIMD Acceleration**: AVX2, AVX-512, NEON optimized kernels
- **Multiple Backends**: CPU (optimized), WASM, CUDA/Metal (skeleton)
- **Compiler Pipeline**: 8-stage optimization with fusion passes
- **Content-Addressed Caching**: Hash-based model caching and distribution

## Quick Start

```rust
use hologram::prelude::*;

// Build a computation graph: output = relu(input_a + input_b)
let mut graph = OperationGraph::new();

// Define nodes
graph.add_node(OpNode::new(0, OpKind::Input, vec![4], DType::F32));
graph.add_node(OpNode::new(1, OpKind::Input, vec![4], DType::F32));
graph.add_node(OpNode::new(2, OpKind::Add, vec![4], DType::F32));
graph.add_node(OpNode::new(3, OpKind::Relu, vec![4], DType::F32));
graph.add_node(OpNode::new(4, OpKind::Output, vec![4], DType::F32));

// Connect: input_a -> add, input_b -> add, add -> relu -> output
graph.add_edge(0, 2);
graph.add_edge(1, 2);
graph.add_edge(2, 3);
graph.add_edge(3, 4);

// Register I/O
graph.add_input("a", 0);
graph.add_input("b", 1);
graph.add_output("result", 4);

// Compile and execute
let plan = compile(&graph, &CompilerConfig::default()).unwrap();
let backend = hologram::backend::cpu::CpuBackend::new();

let input_a: Vec<u8> = [1.0f32, -2.0, 3.0, -4.0].iter()
    .flat_map(|f| f.to_ne_bytes()).collect();
let input_b: Vec<u8> = [1.0f32, 2.0, 1.0, 2.0].iter()
    .flat_map(|f| f.to_ne_bytes()).collect();
let mut output = vec![0u8; 16];

backend.execute_plan(&plan, &[&input_a, &input_b], &mut [&mut output]).unwrap();
// Result: relu([2, 0, 4, -2]) = [2.0, 0.0, 4.0, 0.0]
```

## Transformer Operations

Hologram supports full transformer architectures including attention, layer normalization, and all required tensor operations.

### Self-Attention Pattern

```rust
use hologram::prelude::*;

let mut graph = OperationGraph::new();
let mut id = 0;

// Input: [seq_len=4, hidden_dim=64]
graph.add_node(OpNode::new(id, OpKind::Input, vec![4, 64], DType::F32));
graph.add_input("x", id);
let input = id; id += 1;

// LayerNorm (pre-norm architecture)
graph.add_node(OpNode::new(id, OpKind::Constant, vec![64], DType::F32));
graph.add_constant(ConstantData::F32(vec![1.0; 64])); // scale
let scale = id; id += 1;

graph.add_node(OpNode::new(id, OpKind::Constant, vec![64], DType::F32));
graph.add_constant(ConstantData::F32(vec![0.0; 64])); // bias
let bias = id; id += 1;

graph.add_node(OpNode::new(id, OpKind::LayerNorm {
    normalized_dims: 1,
    epsilon: 1e-5
}, vec![4, 64], DType::F32));
graph.add_edge(input, id);
graph.add_edge(scale, id);
graph.add_edge(bias, id);
let normed = id; id += 1;

// Q, K, V projections via MatMul
// W_q: [64, 64]
graph.add_node(OpNode::new(id, OpKind::Constant, vec![64, 64], DType::F32));
graph.add_constant(ConstantData::F32(vec![0.1; 64 * 64]));
let w_q = id; id += 1;

// Q = normed @ W_q: [4, 64] @ [64, 64] = [4, 64]
graph.add_node(OpNode::new(id, OpKind::MatMul { m: 4, k: 64, n: 64 }, vec![4, 64], DType::F32));
graph.add_edge(normed, id);
graph.add_edge(w_q, id);
let q = id; id += 1;

// ... K, V projections similarly ...

// Attention scores: Q @ K^T with Softmax
// scores = softmax(Q @ K^T / sqrt(d_k))
```

### Supported Operations

| Category | Operations |
|----------|------------|
| **Arithmetic** | Add, Sub, Mul, Div, Sqrt, Exp, Log, Pow, Abs |
| **Activations** | ReLU, Sigmoid, Tanh, GELU, SiLU, Softmax |
| **Matrix** | MatMul, BatchMatMul, Transpose |
| **Normalization** | LayerNorm, BatchNorm |
| **Pooling** | MaxPool, AvgPool, GlobalAveragePool |
| **Convolution** | Conv2d (with groups, dilation, padding) |
| **Shape** | Reshape, Squeeze, Unsqueeze, Flatten, Concat, Split, Slice, Pad |
| **Reduction** | Sum, Mean, Max, Min |
| **Comparison** | Greater, Less, GreaterOrEqual, LessOrEqual, Where |

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        User Code                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  hologram-compiler: OperationGraph → BackendPlan                │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐   │
│  │ Fusion  │→│ Layout  │→│Partition│→│Workspace│→│ Assemble│   │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  hologram-backend: Execute BackendPlan                          │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐               │
│  │   CPU   │ │  WASM   │ │  CUDA   │ │  Metal  │               │
│  │ (SIMD)  │ │(scalar) │ │(skeleton)│ │(skeleton)│              │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘               │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  uor: Core Mathematical Foundation                              │
│  Taxon, Domain, Ring, UorState, Wavefront, Microcode            │
└─────────────────────────────────────────────────────────────────┘
```

## Crate Structure

| Crate | Description |
|-------|-------------|
| `hologram` | Root crate with unified API and prelude |
| `hologram-compiler` | Graph IR, compilation pipeline, fusion passes |
| `hologram-backend` | Execution backends (CPU, WASM, GPU) |
| `hologram-holo` | Archive format (.holb, .holo) |
| `uor` | Core UOR implementation (zero dependencies) |
| `prism` | High-level state operations |
| `hologram-cli` | Command-line tools |

## Build

```bash
# Check, lint, and test
just ci

# Build
just build

# Run benchmarks (x86_64 with AVX2/SHA/AES)
RUSTFLAGS="-C target-feature=+avx2,+sha,+aes" just bench
```

## Performance

Hologram uses SIMD-optimized kernels for all core operations:

| Operation | Size | Throughput |
|-----------|------|------------|
| LayerNorm | 64×64 | ~150 Melem/s |
| Softmax | 64×64 | ~290 Melem/s |
| MatMul | 512×512 | ~2 GFLOPS |

*Benchmarks on AMD Zen 3 with AVX2. Run `cargo bench` for your hardware.*

## Documentation

- [`specs/project.md`](specs/project.md) -- Full conceptual definition and architecture
- [`specs/FUTURE_PLANS.md`](specs/FUTURE_PLANS.md) -- Development roadmap and constraints
- [`CLAUDE.md`](CLAUDE.md) -- Project rules for AI-assisted development
- [API Docs](https://docs.rs/hologram) -- Generated API documentation

## License

MIT OR Apache-2.0
