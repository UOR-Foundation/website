export { EditProfileDialog as default } from "@/modules/identity/components/EditProfileDialog";
