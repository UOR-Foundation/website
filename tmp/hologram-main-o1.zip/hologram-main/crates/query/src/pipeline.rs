//! Pipeline execution engine.
//!
//! Handles `mutation { pipeline(value: 42) { add(by: 10) { stratum }, sigmoid { value } } }`
//! by threading a value through sequential transform steps with per-step field resolution.

use serde_json::{json, Map, Value};

use crate::ast::*;
use crate::generated::{ActivationDto, ByteDto, FieldValue};
use crate::translate::{self, TranslateError};

/// Known transform operations and their domain classification.
fn classify_transform(op: &str) -> Option<&'static str> {
    match op {
        "add" | "sub" | "mul" => Some("byte"),
        "sigmoid" | "tanh" | "relu" | "exp" | "log" | "sqrt" | "abs" | "gelu" | "silu" => {
            Some("activation")
        }
        _ => None,
    }
}

/// Execute a pipeline mutation.
pub fn execute_pipeline(sel: &Selection) -> Result<Value, TranslateError> {
    let mut value = sel
        .arguments
        .iter()
        .find(|(n, _)| n == "value")
        .and_then(|(_, v)| v.as_int())
        .ok_or_else(|| TranslateError::MissingArg("value".into()))? as u8;

    let mut steps = Vec::new();

    for step in &sel.children {
        let op = &step.field;
        let domain = classify_transform(op).ok_or_else(|| TranslateError::UnknownOp(op.clone()))?;

        let by = step
            .arguments
            .iter()
            .find(|(n, _)| n == "by")
            .and_then(|(_, v)| v.as_int())
            .unwrap_or(0) as u8;

        let from_value = value;
        let new_value = translate::apply_transform(domain, value, op, by)?;

        let from_fields = resolve_step_fields(from_value, &step.children);
        let to_fields = resolve_step_fields(new_value, &step.children);

        steps.push(json!({
            "step": op,
            "from": { "value": from_value, "fields": from_fields },
            "to": { "value": new_value, "fields": to_fields },
        }));

        value = new_value;
    }

    Ok(json!({
        "initial": sel.arguments.iter()
            .find(|(n, _)| n == "value")
            .and_then(|(_, v)| v.as_int())
            .unwrap_or(0),
        "final": value,
        "steps": steps,
    }))
}

/// Resolve fields for a pipeline step value (always resolves as byte).
fn resolve_step_fields(value: u8, children: &[Selection]) -> Value {
    let mut obj = Map::new();
    for child in children {
        // Try byte fields first, then activation
        let fv = ByteDto::resolve_field(value, &child.field)
            .or_else(|| ActivationDto::resolve_field(value, &child.field));
        if let Some(fv) = fv {
            obj.insert(child.field.clone(), field_value_to_json(&fv));
        }
    }
    Value::Object(obj)
}

fn field_value_to_json(fv: &FieldValue) -> Value {
    match fv {
        FieldValue::U8(v) => json!(*v),
        FieldValue::U16(v) => json!(*v),
        FieldValue::U32(v) => json!(*v),
        FieldValue::U64(v) => json!(*v),
        FieldValue::Usize(v) => json!(*v),
        FieldValue::I32(v) => json!(*v),
        FieldValue::I64(v) => json!(*v),
        FieldValue::F32(v) => json!(*v),
        FieldValue::Str(v) => json!(v),
        FieldValue::Json(v) => v.clone(),
    }
}

/// Execute a chain mutation using pre-composed tables when available.
///
/// ```text
/// mutation { chain(value: 128, transforms: [sigmoid, tanh, relu]) { stratum } }
/// ```
pub fn execute_chain(sel: &Selection) -> Result<Value, TranslateError> {
    let value = sel
        .arguments
        .iter()
        .find(|(n, _)| n == "value")
        .and_then(|(_, v)| v.as_int())
        .ok_or_else(|| TranslateError::MissingArg("value".into()))? as u8;

    let transforms: Vec<&str> = sel
        .arguments
        .iter()
        .find(|(n, _)| n == "transforms")
        .and_then(|(_, v)| match v {
            QueryValue::List(items) => Some(
                items
                    .iter()
                    .filter_map(|item| item.as_str())
                    .collect::<Vec<_>>(),
            ),
            _ => None,
        })
        .unwrap_or_default();

    // Try pre-composed table first (O(1)), fall back to sequential
    let (result, composed) = match uor::lut::compose_chain(&transforms) {
        Some(table) => (table[value as usize], true),
        None => {
            let mut v = value;
            for op in &transforms {
                let domain = classify_transform(op)
                    .ok_or_else(|| TranslateError::UnknownOp((*op).to_string()))?;
                v = translate::apply_transform(domain, v, op, 0)?;
            }
            (v, false)
        }
    };

    let fields = resolve_step_fields(result, &sel.children);

    Ok(json!({
        "value": result,
        "composed": composed,
        "transforms": transforms,
        "fields": fields,
    }))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parse::parse;
    use crate::resolve::execute;

    #[test]
    fn pipeline_single_step() {
        let doc = parse("mutation { pipeline(value: 42) { add(by: 10) { stratum } } }").unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["initial"], json!(42));
        assert_eq!(result["final"], json!(52));
        let steps = result["steps"].as_array().unwrap();
        assert_eq!(steps.len(), 1);
        assert_eq!(steps[0]["step"], "add");
        assert_eq!(steps[0]["from"]["value"], json!(42));
        assert_eq!(steps[0]["to"]["value"], json!(52));
    }

    #[test]
    fn pipeline_multi_step() {
        let doc = parse(
            "mutation { pipeline(value: 10) { add(by: 5) { stratum }, mul(by: 2) { stratum } } }",
        )
        .unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["initial"], json!(10));
        // wrapping byte arithmetic: (10 + 5) then (15 * 2)
        assert_eq!(result["final"], json!(30));
        let steps = result["steps"].as_array().unwrap();
        assert_eq!(steps.len(), 2);
        assert_eq!(steps[0]["to"]["value"], json!(15));
        assert_eq!(steps[1]["to"]["value"], json!(30));
    }

    #[test]
    fn pipeline_mixed_transforms() {
        let doc = parse(
            "mutation { pipeline(value: 128) { sigmoid { stratum }, add(by: 10) { stratum } } }",
        )
        .unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["initial"], json!(128));
        let sigmoid_val = uor::lut::sigmoid_lut(128);
        let final_val = sigmoid_val.wrapping_add(10);
        assert_eq!(result["final"], json!(final_val));
    }

    #[test]
    fn pipeline_activation_chain() {
        let doc = parse("mutation { pipeline(value: 200) { relu { stratum }, tanh { stratum } } }")
            .unwrap();
        let result = execute(&doc).unwrap();
        let relu_val = uor::lut::relu_lut(200);
        let tanh_val = uor::lut::tanh_lut(relu_val);
        assert_eq!(result["final"], json!(tanh_val));
    }

    #[test]
    fn pipeline_field_resolution() {
        let doc = parse("mutation { pipeline(value: 42) { add(by: 0) { stratum, curvature } } }")
            .unwrap();
        let result = execute(&doc).unwrap();
        let steps = result["steps"].as_array().unwrap();
        assert!(steps[0]["from"]["fields"]["stratum"].is_number());
        assert!(steps[0]["from"]["fields"]["curvature"].is_number());
        assert!(steps[0]["to"]["fields"]["stratum"].is_number());
    }

    #[test]
    fn pipeline_unknown_op() {
        let doc =
            parse("mutation { pipeline(value: 42) { unknown_op(by: 1) { stratum } } }").unwrap();
        let result = execute(&doc);
        assert!(result.is_err());
    }

    #[test]
    fn pipeline_empty_steps() {
        // Pipeline with no steps
        let doc = parse("mutation { pipeline(value: 42) }").unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["initial"], json!(42));
        assert_eq!(result["final"], json!(42));
        assert_eq!(result["steps"].as_array().unwrap().len(), 0);
    }

    // Chain tests

    #[test]
    fn chain_composed_table() {
        let doc =
            parse("mutation { chain(value: 128, transforms: [sigmoid, tanh, relu]) { stratum } }")
                .unwrap();
        let result = execute(&doc).unwrap();
        assert!(result["composed"].as_bool().unwrap());
        // Verify correctness
        let s = uor::lut::sigmoid_lut(128);
        let t = uor::lut::tanh_lut(s);
        let r = uor::lut::relu_lut(t);
        assert_eq!(result["value"], json!(r));
    }

    #[test]
    fn chain_fallback_sequential() {
        // Single transform — no pre-composed table but still valid
        let doc =
            parse("mutation { chain(value: 42, transforms: [sigmoid]) { stratum } }").unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["value"], json!(uor::lut::sigmoid_lut(42)));
    }

    #[test]
    fn chain_all_256_composed() {
        let composed = uor::lut::compose_chain(&["sigmoid", "tanh", "relu"]).unwrap();
        for v in 0..=255u16 {
            let q = format!(
                "mutation {{ chain(value: {v}, transforms: [sigmoid, tanh, relu]) {{ stratum }} }}"
            );
            let doc = parse(&q).unwrap();
            let result = execute(&doc).unwrap();
            assert_eq!(
                result["value"],
                json!(composed[v as usize]),
                "mismatch at value {v}"
            );
        }
    }

    #[test]
    fn chain_with_fields() {
        let doc = parse(
            "mutation { chain(value: 100, transforms: [sigmoid, tanh]) { stratum, curvature } }",
        )
        .unwrap();
        let result = execute(&doc).unwrap();
        assert!(result["fields"]["stratum"].is_number());
        assert!(result["fields"]["curvature"].is_number());
    }

    #[test]
    fn pipeline_all_values() {
        // Verify pipeline works for all 256 byte values
        for v in 0..=255u16 {
            let q = format!("mutation {{ pipeline(value: {v}) {{ sigmoid {{ stratum }} }} }}");
            let doc = parse(&q).unwrap();
            let result = execute(&doc).unwrap();
            let expected = uor::lut::sigmoid_lut(v as u8);
            assert_eq!(result["final"], json!(expected), "failed at value {v}");
        }
    }
}
