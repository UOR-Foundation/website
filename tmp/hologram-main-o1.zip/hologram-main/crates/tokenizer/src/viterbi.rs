//! Viterbi algorithm for SentencePiece Unigram tokenization.
//!
//! Implements the dynamic programming algorithm to find the optimal
//! tokenization path through the vocabulary.

use smallvec::SmallVec;

use crate::PrefixTrie;

/// Result of Viterbi tokenization.
#[derive(Debug, Clone)]
pub struct ViterbiResult {
    /// Token IDs of the optimal tokenization.
    pub tokens: Vec<u32>,
    /// Total score (sum of log probabilities) of the path.
    pub score: f32,
}

/// Viterbi tokenizer using a prefix trie.
#[derive(Debug, Clone)]
pub struct ViterbiTokenizer {
    /// Prefix trie containing vocabulary.
    trie: PrefixTrie,
    /// Unknown token ID.
    unk_id: u32,
    /// Unknown token score.
    unk_score: f32,
}

/// Internal node for Viterbi DP.
#[derive(Debug, Clone, Copy)]
struct ViterbiNode {
    /// Best score reaching this position.
    score: f32,
    /// Token ID that ends at this position.
    token_id: u32,
    /// Start position of the token.
    start_pos: usize,
}

impl ViterbiTokenizer {
    /// Create a new Viterbi tokenizer with the given trie.
    ///
    /// # Arguments
    /// * `trie` - Prefix trie containing vocabulary tokens and scores
    /// * `unk_id` - Token ID to use for unknown characters
    /// * `unk_score` - Score (log probability) for unknown tokens
    pub fn new(trie: PrefixTrie, unk_id: u32, unk_score: f32) -> Self {
        Self {
            trie,
            unk_id,
            unk_score,
        }
    }

    /// Tokenize input codepoints using Viterbi algorithm.
    ///
    /// Finds the optimal tokenization path that maximizes the total score
    /// (sum of log probabilities).
    ///
    /// # Arguments
    /// * `codepoints` - Input text as Unicode codepoints
    ///
    /// # Returns
    /// The optimal tokenization with token IDs and total score.
    pub fn tokenize(&self, codepoints: &[u32]) -> ViterbiResult {
        if codepoints.is_empty() {
            return ViterbiResult {
                tokens: Vec::new(),
                score: 0.0,
            };
        }

        let n = codepoints.len();

        // Use stack allocation for typical inputs
        let mut best: SmallVec<[Option<ViterbiNode>; 256]> = SmallVec::new();
        best.resize(n + 1, None);

        // Initialize: empty prefix has score 0
        best[0] = Some(ViterbiNode {
            score: 0.0,
            token_id: 0,
            start_pos: 0,
        });

        // Forward pass: compute best scores
        for i in 0..n {
            let current_score = match &best[i] {
                Some(node) => node.score,
                None => continue, // Unreachable position
            };

            // Find all matching tokens starting at position i
            let matches = self.trie.find_matches(&codepoints[i..]);

            if matches.is_empty() {
                // No match: use unknown token for single character
                let end_pos = i + 1;
                let new_score = current_score + self.unk_score;

                if best[end_pos].is_none() || new_score > best[end_pos].as_ref().unwrap().score {
                    best[end_pos] = Some(ViterbiNode {
                        score: new_score,
                        token_id: self.unk_id,
                        start_pos: i,
                    });
                }
            } else {
                // Try each matching token
                for m in matches {
                    let end_pos = i + m.length;
                    if end_pos > n {
                        continue;
                    }

                    let new_score = current_score + m.score;

                    if best[end_pos].is_none() || new_score > best[end_pos].as_ref().unwrap().score
                    {
                        best[end_pos] = Some(ViterbiNode {
                            score: new_score,
                            token_id: m.token_id,
                            start_pos: i,
                        });
                    }
                }
            }
        }

        // Backtrack: reconstruct token sequence
        let final_node = match &best[n] {
            Some(node) => node,
            None => {
                // Shouldn't happen if UNK handling is correct
                return ViterbiResult {
                    tokens: vec![self.unk_id; n],
                    score: self.unk_score * n as f32,
                };
            }
        };

        let total_score = final_node.score;
        let mut tokens = Vec::new();
        let mut pos = n;

        while pos > 0 {
            let node = best[pos].as_ref().unwrap();
            tokens.push(node.token_id);
            pos = node.start_pos;
        }

        tokens.reverse();

        ViterbiResult {
            tokens,
            score: total_score,
        }
    }

    /// Tokenize a string (convenience method).
    pub fn tokenize_str(&self, text: &str) -> ViterbiResult {
        let codepoints: Vec<u32> = text.chars().map(|c| c as u32).collect();
        self.tokenize(&codepoints)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_tokenizer() -> ViterbiTokenizer {
        let mut trie = PrefixTrie::new();

        // Simple vocabulary
        trie.insert_str("a", 1, -0.1);
        trie.insert_str("b", 2, -0.2);
        trie.insert_str("ab", 3, -0.15); // "ab" has better score than "a" + "b"
        trie.insert_str("abc", 4, -0.1);
        trie.insert_str("c", 5, -0.3);

        ViterbiTokenizer::new(trie, 0, -10.0)
    }

    #[test]
    fn test_viterbi_empty_input() {
        let tokenizer = sample_tokenizer();
        let result = tokenizer.tokenize(&[]);

        assert!(result.tokens.is_empty());
        assert_eq!(result.score, 0.0);
    }

    #[test]
    fn test_viterbi_single_char() {
        let tokenizer = sample_tokenizer();
        let result = tokenizer.tokenize_str("a");

        assert_eq!(result.tokens, vec![1]); // "a" -> 1
    }

    #[test]
    fn test_viterbi_simple() {
        let tokenizer = sample_tokenizer();
        let result = tokenizer.tokenize_str("ab");

        // Should prefer "ab" (score -0.15) over "a" + "b" (score -0.1 + -0.2 = -0.3)
        assert_eq!(result.tokens, vec![3]); // "ab" -> 3
        assert_eq!(result.score, -0.15);
    }

    #[test]
    fn test_viterbi_prefers_longer() {
        let tokenizer = sample_tokenizer();
        let result = tokenizer.tokenize_str("abc");

        // "abc" (score -0.1) vs "ab" + "c" (-0.15 + -0.3 = -0.45)
        assert_eq!(result.tokens, vec![4]); // "abc" -> 4
    }

    #[test]
    fn test_viterbi_multiple_tokens() {
        let tokenizer = sample_tokenizer();
        let result = tokenizer.tokenize_str("abab");

        // "ab" + "ab" = -0.15 + -0.15 = -0.30
        // This is better than other combinations
        assert_eq!(result.tokens, vec![3, 3]); // "ab" + "ab"
        assert_eq!(result.score, -0.30);
    }

    #[test]
    fn test_viterbi_unknown() {
        let tokenizer = sample_tokenizer();
        let result = tokenizer.tokenize_str("x");

        // "x" is not in vocabulary, should use UNK
        assert_eq!(result.tokens, vec![0]); // UNK -> 0
        assert_eq!(result.score, -10.0); // UNK score
    }

    #[test]
    fn test_viterbi_mixed_known_unknown() {
        let tokenizer = sample_tokenizer();
        let result = tokenizer.tokenize_str("axb");

        // "a" + UNK("x") + "b"
        assert_eq!(result.tokens, vec![1, 0, 2]);
    }

    #[test]
    fn test_viterbi_long_sequence() {
        let tokenizer = sample_tokenizer();
        let input = "abcababc";
        let result = tokenizer.tokenize_str(input);

        // Should find optimal path
        // "abc" + "ab" + "abc" = -0.1 + -0.15 + -0.1 = -0.35
        assert_eq!(result.tokens, vec![4, 3, 4]); // "abc" + "ab" + "abc"
    }

    #[test]
    fn test_viterbi_unicode() {
        let mut trie = PrefixTrie::new();
        trie.insert_str("\u{2581}hello", 1, -1.0);
        trie.insert_str("\u{2581}", 2, -0.5);
        trie.insert_str("hello", 3, -2.0);

        let tokenizer = ViterbiTokenizer::new(trie, 0, -10.0);
        let result = tokenizer.tokenize_str("\u{2581}hello");

        // Should prefer "\u{2581}hello" (score -1.0) over "\u{2581}" + "hello" (-0.5 + -2.0 = -2.5)
        assert_eq!(result.tokens, vec![1]);
    }

    #[test]
    fn test_viterbi_backtrack_correctness() {
        let tokenizer = sample_tokenizer();
        let result = tokenizer.tokenize_str("abcab");

        // "abc" + "ab" = -0.1 + -0.15 = -0.25
        assert_eq!(result.tokens, vec![4, 3]); // "abc" + "ab"

        // Verify total score
        let expected_score = -0.1 + -0.15;
        assert!((result.score - expected_score).abs() < 1e-6);
    }

    #[test]
    fn test_viterbi_all_unknown() {
        let tokenizer = sample_tokenizer();
        let result = tokenizer.tokenize_str("xyz");

        // All characters unknown
        assert_eq!(result.tokens, vec![0, 0, 0]);
        assert_eq!(result.score, -30.0); // 3 * -10.0
    }

    #[test]
    fn test_viterbi_scores_match() {
        let mut trie = PrefixTrie::new();
        trie.insert_str("the", 1, -2.5);
        trie.insert_str("t", 2, -3.0);
        trie.insert_str("he", 3, -2.8);
        trie.insert_str("h", 4, -3.5);
        trie.insert_str("e", 5, -2.0);

        let tokenizer = ViterbiTokenizer::new(trie, 0, -10.0);
        let result = tokenizer.tokenize_str("the");

        // "the" (-2.5) vs "t" + "he" (-3.0 + -2.8 = -5.8) vs "t" + "h" + "e" (-3.0 + -3.5 + -2.0 = -8.5)
        assert_eq!(result.tokens, vec![1]); // "the"
        assert_eq!(result.score, -2.5);
    }
}
