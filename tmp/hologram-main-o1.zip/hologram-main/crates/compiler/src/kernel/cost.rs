//! Cost model for kernel selection.

use crate::graph::OpKind;
use hologram_backend::BackendCapabilities;

/// Estimated cost of executing a kernel.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct KernelCost {
    /// Estimated cycles.
    pub cycles: u64,
    /// Estimated cache pressure (bytes).
    pub cache_pressure: usize,
}

impl KernelCost {
    /// Create a new kernel cost.
    #[must_use]
    pub const fn new(cycles: u64, cache_pressure: usize) -> Self {
        Self {
            cycles,
            cache_pressure,
        }
    }

    /// Compute a combined score (lower is better).
    ///
    /// The score balances cycles and cache pressure relative to cache size.
    #[must_use]
    pub fn score(&self, l1_cache_size: usize) -> u64 {
        // Penalize cache pressure that exceeds L1 cache
        let cache_penalty = if self.cache_pressure > l1_cache_size {
            // Each cache miss costs ~100 cycles
            ((self.cache_pressure - l1_cache_size) / 64) as u64 * 100
        } else {
            0
        };
        self.cycles.saturating_add(cache_penalty)
    }
}

/// Estimate cost for an operation given backend capabilities.
#[must_use]
#[allow(clippy::too_many_lines)]
pub fn estimate_cost(op: &OpKind, shape: &[usize], caps: &BackendCapabilities) -> KernelCost {
    let element_count: usize = shape.iter().product();

    match op {
        // Element-wise binary operations: O(n) with SIMD speedup
        OpKind::Add
        | OpKind::Sub
        | OpKind::Mul
        | OpKind::Div
        | OpKind::Pow
        | OpKind::ElemMin
        | OpKind::ElemMax
        | OpKind::Greater
        | OpKind::GreaterOrEqual
        | OpKind::Less
        | OpKind::LessOrEqual => {
            let base_cycles = element_count as u64;
            let simd_speedup = caps.vector_width as u64;
            KernelCost::new(
                base_cycles / simd_speedup,
                element_count * 4 * 2, // 2 inputs, 4 bytes each for F32
            )
        }

        // Where (ternary conditional): O(n) with SIMD blendv
        OpKind::Where => {
            let base_cycles = element_count as u64;
            let simd_speedup = caps.vector_width as u64;
            KernelCost::new(
                base_cycles / simd_speedup,
                element_count * 4 * 3, // 3 inputs (cond, x, y)
            )
        }

        // Simple unary math: O(n) with native SIMD support
        OpKind::Sqrt | OpKind::Abs => {
            let base_cycles = element_count as u64;
            let simd_speedup = caps.vector_width as u64;
            KernelCost::new(base_cycles / simd_speedup, element_count * 4)
        }

        // Transcendental unary functions: O(n) with polynomial approximation
        OpKind::Log | OpKind::Exp => {
            // More expensive per element (~15 cycles for polynomial)
            let base_cycles = element_count as u64 * 15;
            let simd_speedup = caps.vector_width as u64;
            KernelCost::new(base_cycles / simd_speedup, element_count * 4)
        }

        // Unary activations: O(n) with lookup table or SIMD
        OpKind::Sigmoid | OpKind::Tanh | OpKind::Gelu | OpKind::Silu => {
            // These are more expensive per element (~10 cycles for lookup)
            let base_cycles = element_count as u64 * 10;
            let simd_speedup = caps.vector_width as u64;
            KernelCost::new(
                base_cycles / simd_speedup,
                element_count * 4, // 1 input
            )
        }

        OpKind::Relu => {
            // ReLU is very cheap (just a comparison)
            let base_cycles = element_count as u64;
            let simd_speedup = caps.vector_width as u64;
            KernelCost::new(base_cycles / simd_speedup, element_count * 4)
        }

        OpKind::Softmax { .. } => {
            // Softmax: exp for each element + sum + divide
            // O(n) but with higher constant factor
            let base_cycles = element_count as u64 * 20;
            let simd_speedup = caps.vector_width as u64;
            KernelCost::new(base_cycles / simd_speedup, element_count * 4)
        }

        // MatMul / MatMulRelu: O(m*k*n) with potential SIMD and blocking
        // (ReLU is near-free when fused into the writeback)
        OpKind::MatMul { m, k, n } | OpKind::MatMulRelu { m, k, n } => {
            let flops = (*m * *k * *n) as u64 * 2; // 2 ops per multiply-add
            let simd_speedup = caps.vector_width as u64;
            let fma_speedup = if caps.has_fma { 2 } else { 1 };
            KernelCost::new(
                flops / (simd_speedup * fma_speedup),
                (*m * *k + *k * *n + *m * *n) * 4, // A, B, C matrices
            )
        }

        // BatchMatMul: O(batch*m*k*n) - batched matrix multiplication
        OpKind::BatchMatMul { batch, m, k, n } => {
            let batch_size: usize = batch.iter().product();
            let flops = (batch_size * *m * *k * *n) as u64 * 2; // 2 ops per multiply-add
            let simd_speedup = caps.vector_width as u64;
            let fma_speedup = if caps.has_fma { 2 } else { 1 };
            KernelCost::new(
                flops / (simd_speedup * fma_speedup),
                batch_size * (*m * *k + *k * *n + *m * *n) * 4, // batched A, B, C matrices
            )
        }

        // Reductions: O(n) with tree reduction
        OpKind::Sum | OpKind::Max | OpKind::Min | OpKind::Mean => {
            let base_cycles = element_count as u64;
            let simd_speedup = caps.vector_width as u64;
            // Cache pressure is input (element_count * 4) + output (4 bytes scalar)
            KernelCost::new(base_cycles / simd_speedup, element_count * 4 + 4)
        }

        // Categorical operations: O(1) per element with precomputed LUT
        // These use uor::lut tables for:
        // - Lift: torus_page_q0 (256-byte LUT)
        // - OrbitClassify: orbit_class_q0 (256-byte LUT)
        // Cost is now dominated by memory access, not computation
        OpKind::Lift | OpKind::OrbitClassify => {
            // Single 256-byte LUT lookup per element
            let base_cycles = element_count as u64; // O(1) lookup
            KernelCost::new(base_cycles, element_count + 256) // input + LUT
        }

        // Hash operations: SHA-256 is ~45 ns per hash on HW SHA, output is 32 bytes
        OpKind::Sha256 { src_len } => {
            // SHA-256 compresses in 64-byte blocks; cost scales with input length
            let blocks = (*src_len).div_ceil(64) + 1; // +1 for padding block
            let base_cycles = blocks as u64 * 64; // ~64 cycles per block on HW SHA
            let sha_speedup = if caps.has_sha { 4 } else { 1 };
            KernelCost::new(base_cycles / sha_speedup, *src_len + 32)
        }
        OpKind::DoubleSha256 { src_len } => {
            // Double SHA-256: first hash + second hash (always 1 block for 32-byte intermediate)
            let blocks_first = (*src_len).div_ceil(64) + 1;
            let blocks_total = blocks_first + 1; // second hash is always 1 block
            let base_cycles = blocks_total as u64 * 64;
            let sha_speedup = if caps.has_sha { 4 } else { 1 };
            KernelCost::new(base_cycles / sha_speedup, *src_len + 32)
        }

        // Codec operations: O(n) with base conversion
        OpKind::Encode { .. } | OpKind::Decode { .. } => {
            // Base conversion involves bigint arithmetic, relatively expensive
            let base_cycles = element_count as u64 * 20;
            KernelCost::new(base_cycles, element_count * 2)
        }

        // Memory operations: dominated by memory bandwidth
        OpKind::Load | OpKind::Store | OpKind::Copy => {
            // Assume ~1 cycle per 8 bytes with good prefetching
            let bytes = element_count * 4;
            KernelCost::new((bytes / 8) as u64, bytes)
        }

        // Shape operations: mostly memory-bound copies
        OpKind::Reshape { .. } | OpKind::Unsqueeze { .. } | OpKind::Squeeze { .. } => {
            // Zero-copy for contiguous data, just metadata change
            let bytes = element_count * 4;
            KernelCost::new((bytes / 8) as u64, bytes)
        }

        OpKind::Transpose { .. } => {
            // Transpose requires non-contiguous memory access
            // More expensive due to cache misses
            let bytes = element_count * 4;
            KernelCost::new((bytes / 4) as u64, bytes * 2)
        }

        OpKind::Gather { .. } => {
            // Gather has random access patterns
            let bytes = element_count * 4;
            KernelCost::new((element_count * 5) as u64, bytes * 2)
        }

        OpKind::Concat { .. } => {
            // Concat is sequential copies
            let bytes = element_count * 4;
            KernelCost::new((bytes / 8) as u64, bytes * 2)
        }

        OpKind::Slice { .. } => {
            // Slice may be contiguous or strided
            let bytes = element_count * 4;
            KernelCost::new((bytes / 8) as u64, bytes)
        }

        OpKind::Split { .. } => {
            // Split is lowered to Slice, same cost model
            let bytes = element_count * 4;
            KernelCost::new((bytes / 8) as u64, bytes)
        }

        OpKind::Pad { .. } => {
            // Pad fills with constant and copies source data
            let bytes = element_count * 4;
            KernelCost::new((bytes / 4) as u64, bytes * 2)
        }

        OpKind::Cast { .. } => {
            // Cast requires per-element conversion
            let bytes = element_count * 4;
            KernelCost::new(element_count as u64, bytes * 2)
        }

        OpKind::Tile { .. } => {
            // Tile requires copying with index arithmetic
            let bytes = element_count * 4;
            KernelCost::new((element_count * 3) as u64, bytes * 2)
        }

        OpKind::Expand { .. } => {
            // Expand broadcasts with index arithmetic (similar to Tile)
            let bytes = element_count * 4;
            KernelCost::new((element_count * 3) as u64, bytes * 2)
        }

        // Control flow: depends on called layer (use placeholder)
        OpKind::CallLayer { .. } => KernelCost::new(1000, 0),

        // I/O and constants: minimal cost
        OpKind::Input | OpKind::Output | OpKind::Constant => KernelCost::new(1, 0),

        // Neural network operations: use placeholder costs until implemented
        OpKind::Conv2d { .. } => {
            // Conv2d is compute-heavy
            let bytes = element_count * 4;
            KernelCost::new((element_count * 100) as u64, bytes * 3)
        }
        OpKind::BatchNormalization { .. } => {
            // BatchNorm is O(n)
            let bytes = element_count * 4;
            KernelCost::new(element_count as u64 * 5, bytes)
        }
        OpKind::LayerNorm { .. } => {
            // LayerNorm is O(n) with mean/variance computation (Welford's algorithm)
            // Similar to BatchNorm but slightly more expensive due to per-instance stats
            let bytes = element_count * 4;
            KernelCost::new(element_count as u64 * 6, bytes)
        }
        OpKind::MaxPool { .. } => {
            // MaxPool is reduction-like
            let bytes = element_count * 4;
            KernelCost::new(element_count as u64 * 2, bytes)
        }
        OpKind::AvgPool { .. } => {
            // AvgPool is reduction-like (similar to MaxPool)
            let bytes = element_count * 4;
            KernelCost::new(element_count as u64 * 2, bytes)
        }
        OpKind::GlobalAveragePool => {
            // GlobalAveragePool is a reduction
            let bytes = element_count * 4;
            KernelCost::new(element_count as u64, bytes)
        }
        OpKind::Flatten { .. } => {
            // Flatten is a reshape (often zero-copy)
            let bytes = element_count * 4;
            KernelCost::new((bytes / 8) as u64, bytes)
        }

        // Fused Add+Sigmoid: same cost as Add (Sigmoid is cheap fused activation)
        OpKind::AddSigmoid => {
            let base_cycles = element_count as u64 * 10; // sigmoid dominates
            let simd_speedup = caps.vector_width as u64;
            KernelCost::new(
                base_cycles / simd_speedup,
                element_count * 4 * 2, // 2 inputs, 4 bytes each for F32
            )
        }

        // Tokenization: O(n²) Viterbi DP with trie lookup
        OpKind::ViterbiTokenize { max_tokens, .. } => {
            // Viterbi has O(n*k) where n is input length, k is avg token length
            // Plus trie lookup overhead per position
            // Use max_tokens as proxy for output size
            let input_len = element_count; // input bytes
            let estimated_cycles = (input_len * *max_tokens) as u64 * 10;
            let bytes = input_len + *max_tokens * 4; // input bytes + output token IDs
            KernelCost::new(estimated_cycles, bytes)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_backend::BackendType;

    fn test_caps() -> BackendCapabilities {
        BackendCapabilities {
            backend_type: BackendType::Cpu,
            vector_width: 8,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: true,
            has_sha: false,
            has_aes: false,
        }
    }

    #[test]
    fn test_kernel_cost_score() {
        let cost = KernelCost::new(100, 1024);
        let score = cost.score(32 * 1024);
        assert_eq!(score, 100); // No cache penalty

        let cost_large = KernelCost::new(100, 64 * 1024);
        let score_large = cost_large.score(32 * 1024);
        assert!(score_large > 100); // Cache penalty applied
    }

    #[test]
    fn test_estimate_add() {
        let caps = test_caps();
        let cost = estimate_cost(&OpKind::Add, &[1024], &caps);
        assert!(cost.cycles > 0);
        assert_eq!(cost.cache_pressure, 1024 * 4 * 2); // 2 inputs
    }

    #[test]
    fn test_estimate_relu_cheaper_than_sigmoid() {
        let caps = test_caps();
        let relu_cost = estimate_cost(&OpKind::Relu, &[1024], &caps);
        let sigmoid_cost = estimate_cost(&OpKind::Sigmoid, &[1024], &caps);
        assert!(relu_cost.cycles < sigmoid_cost.cycles);
    }

    #[test]
    fn test_estimate_matmul() {
        let caps = test_caps();
        let cost = estimate_cost(
            &OpKind::MatMul {
                m: 64,
                k: 64,
                n: 64,
            },
            &[64, 64],
            &caps,
        );
        // 64*64*64*2 = 524288 flops / (8 * 2) = 32768 cycles
        assert!(cost.cycles > 0);
        assert!(cost.cache_pressure > 0);
    }

    #[test]
    fn test_estimate_matmul_fma_speedup() {
        let mut caps = test_caps();
        caps.has_fma = true;
        let cost_with_fma = estimate_cost(
            &OpKind::MatMul {
                m: 64,
                k: 64,
                n: 64,
            },
            &[64, 64],
            &caps,
        );

        caps.has_fma = false;
        let cost_without_fma = estimate_cost(
            &OpKind::MatMul {
                m: 64,
                k: 64,
                n: 64,
            },
            &[64, 64],
            &caps,
        );

        assert!(cost_with_fma.cycles < cost_without_fma.cycles);
    }

    #[test]
    fn test_estimate_reduction() {
        let caps = test_caps();
        let cost = estimate_cost(&OpKind::Sum, &[1024], &caps);
        assert!(cost.cycles > 0);
        // Cache pressure: input (1024 * 4) + output (4 bytes scalar)
        assert_eq!(cost.cache_pressure, 1024 * 4 + 4);
    }

    #[test]
    fn test_estimate_io_minimal() {
        let caps = test_caps();
        let input_cost = estimate_cost(&OpKind::Input, &[1024], &caps);
        let output_cost = estimate_cost(&OpKind::Output, &[1024], &caps);
        assert_eq!(input_cost.cycles, 1);
        assert_eq!(output_cost.cycles, 1);
    }

    #[test]
    fn test_simd_width_affects_cost() {
        let mut caps = test_caps();
        caps.vector_width = 8;
        let cost_avx2 = estimate_cost(&OpKind::Add, &[1024], &caps);

        caps.vector_width = 16;
        let cost_avx512 = estimate_cost(&OpKind::Add, &[1024], &caps);

        assert!(cost_avx512.cycles < cost_avx2.cycles);
    }

    #[test]
    fn test_categorical_lut_cost() {
        let caps = test_caps();

        // Lift and OrbitClassify use 256-byte LUT
        let lift_cost = estimate_cost(&OpKind::Lift, &[1024], &caps);
        let orbit_cost = estimate_cost(&OpKind::OrbitClassify, &[1024], &caps);
        // O(1) per element, so cycles = element_count
        assert_eq!(lift_cost.cycles, 1024);
        assert_eq!(orbit_cost.cycles, 1024);
        // Cache pressure includes 256-byte LUT
        assert_eq!(lift_cost.cache_pressure, 1024 + 256);
    }

    #[test]
    fn test_categorical_faster_with_lut() {
        // Verify that LUT-based categorical ops are now faster than
        // compute-heavy operations like sigmoid
        let caps = test_caps();

        let lift_cost = estimate_cost(&OpKind::Lift, &[1024], &caps);
        let sigmoid_cost = estimate_cost(&OpKind::Sigmoid, &[1024], &caps);

        // Lift is O(1) per element, sigmoid is O(10) per element
        assert!(
            lift_cost.cycles < sigmoid_cost.cycles,
            "LUT-based Lift ({}) should be faster than Sigmoid ({})",
            lift_cost.cycles,
            sigmoid_cost.cycles
        );
    }
}
