import { useState, useEffect, useCallback } from 'react';

// WASM module types (matching categorical_ffi.d.ts)
export interface Cell {
  free(): void;
  distanceTo(other: Cell): number;
  next(): Cell;
  offset(delta: number): Cell;
  prev(): Cell;
  index: number;
}

export interface Res96 {
  free(): void;
  add(other: Res96): Res96;
  isUnit(): boolean;
  mul(other: Res96): Res96;
  neg(): Res96;
  sub(other: Res96): Res96;
  tryInverse(): Res96 | undefined;
  value: number;
}

export interface ToroidalBoundary {
  free(): void;
  applyBatch(json: string): void;
  applyMutation(json: string): void;
  clear(): void;
  get(cell: Cell): Res96;
  set(cell: Cell, value: Res96): void;
  signedBudget(): bigint;
  toUint8Array(): Uint8Array;
  totalBudget(): bigint;
}

export interface MutationFactory {
  add(cell: number, delta: number): string;
  bitwiseAnd(source: number, target: number): string;
  bitwiseNot(cell: number): string;
  bitwiseOr(source: number, target: number): string;
  bitwiseXor(source: number, target: number): string;
  fma(a: number, b: number, target: number): string;
  indexedCopy(index_cell: number, source: number): string;
  indexedWrite(index_cell: number, value: number): string;
  indirectMulFrom(base_cell: number, offset: number, target: number): string;
  indirectRead(base_cell: number, offset: number, target: number): string;
  mirror(cell: number): string;
  mul(cell: number, scalar: number): string;
  mulFrom(source: number, target: number): string;
  multiply(cell: number, scalar: number): string;
  set(cell: number, value: number): string;
  shiftLeft(cell: number, amount: number): string;
  shiftRight(cell: number, amount: number): string;
  swap(cell1: number, cell2: number): string;
}

export interface CodecRegistry {
  free(): void;
  listCodecs(): string[];
}

export interface FfiCodec {
  free(): void;
  decode(input: Uint8Array): Uint8Array;
  encode(input: Uint8Array): Uint8Array;
  readonly id: string;
  readonly isArbitrary: boolean;
  readonly name: string;
  readonly radix: number;
}

export interface WasmModule {
  Cell: new (index: number) => Cell;
  Res96: new (value: number) => Res96 & { zero: Res96; one: Res96 };
  ToroidalBoundary: {
    new (): ToroidalBoundary;
    newZero(): ToroidalBoundary;
    newOne(): ToroidalBoundary;
    newFill(value: Res96): ToroidalBoundary;
    fromUint8Array(data: Uint8Array): ToroidalBoundary;
  };
  MutationFactory: MutationFactory;
  CodecRegistry: new () => CodecRegistry;
  init(): void;
}

// Constants from the WASM module
export const BOUNDARY_SIZE = 12288;
export const R = 96;
export const T = 3;
export const O = 8;
export const C = 24;
export const B = 32;

interface WasmState {
  module: WasmModule | null;
  loading: boolean;
  error: string | null;
}

let wasmModuleCache: WasmModule | null = null;
let wasmLoadPromise: Promise<WasmModule> | null = null;

async function loadWasmModule(): Promise<WasmModule> {
  if (wasmModuleCache) {
    return wasmModuleCache;
  }

  if (wasmLoadPromise) {
    return wasmLoadPromise;
  }

  wasmLoadPromise = (async () => {
    // Dynamic import of the WASM module from src directory
    // @ts-expect-error - WASM module types
    const wasmModule = await import('../src/wasm/uor_ffi.js');

    // Load WASM binary from public folder using the base URL
    // In production, this respects the VITE_BASE_PATH (e.g., /hologram/)
    const basePath = import.meta.env.BASE_URL || '/';
    const wasmUrl = `${basePath}wasm/uor_ffi_bg.wasm`;

    // Initialize the WASM module
    await wasmModule.default(wasmUrl);

    wasmModuleCache = wasmModule as unknown as WasmModule;
    return wasmModuleCache;
  })();

  return wasmLoadPromise;
}

export function useWasm(): WasmState & { reload: () => void } {
  const [state, setState] = useState<WasmState>({
    module: wasmModuleCache,
    loading: !wasmModuleCache,
    error: null
  });

  const load = useCallback(async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const module = await loadWasmModule();
      setState({ module, loading: false, error: null });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load WASM module';
      setState({ module: null, loading: false, error: errorMessage });
      console.error('WASM loading error:', err);
    }
  }, []);

  const reload = useCallback(() => {
    wasmModuleCache = null;
    wasmLoadPromise = null;
    load();
  }, [load]);

  useEffect(() => {
    if (!wasmModuleCache) {
      load();
    }
  }, [load]);

  return { ...state, reload };
}

export default useWasm;
