//! Profiling integration for CPU and memory analysis.
//!
//! This module provides basic profiling utilities. For detailed profiling,
//! consider using external tools like `perf`, `flamegraph`, or `heaptrack`.

use std::time::{Duration, Instant};

/// A simple profiler for measuring code execution time.
///
/// # Example
///
/// ```rust
/// use hologram_telemetry::profiling::Profiler;
///
/// let mut profiler = Profiler::new("my_operation");
/// // ... do some work ...
/// let elapsed = profiler.elapsed();
/// println!("Operation took {:?}", elapsed);
/// ```
pub struct Profiler {
    name: &'static str,
    start: Instant,
    checkpoints: Vec<(&'static str, Duration)>,
}

impl Profiler {
    /// Create a new profiler with the given name.
    #[must_use]
    pub fn new(name: &'static str) -> Self {
        Self {
            name,
            start: Instant::now(),
            checkpoints: Vec::new(),
        }
    }

    /// Get the elapsed time since the profiler was created.
    #[must_use]
    pub fn elapsed(&self) -> Duration {
        self.start.elapsed()
    }

    /// Get the name of this profiler.
    #[must_use]
    pub const fn name(&self) -> &'static str {
        self.name
    }

    /// Add a checkpoint with the current elapsed time.
    ///
    /// # Example
    ///
    /// ```rust
    /// use hologram_telemetry::profiling::Profiler;
    ///
    /// let mut profiler = Profiler::new("complex_operation");
    /// // Phase 1
    /// profiler.checkpoint("phase_1");
    /// // Phase 2
    /// profiler.checkpoint("phase_2");
    /// ```
    pub fn checkpoint(&mut self, name: &'static str) {
        self.checkpoints.push((name, self.elapsed()));
    }

    /// Get all checkpoints.
    #[must_use]
    pub fn checkpoints(&self) -> &[(&'static str, Duration)] {
        &self.checkpoints
    }

    /// Reset the profiler, clearing all checkpoints and restarting the timer.
    pub fn reset(&mut self) {
        self.start = Instant::now();
        self.checkpoints.clear();
    }

    /// Get a report of all checkpoints as a formatted string.
    #[must_use]
    pub fn report(&self) -> String {
        let mut report = format!("Profiler '{}' report:\n", self.name);

        let mut last_time = Duration::ZERO;
        for (name, time) in &self.checkpoints {
            let delta = *time - last_time;
            report.push_str(&format!("  {} at {:?} (delta: {:?})\n", name, time, delta));
            last_time = *time;
        }

        report.push_str(&format!("  Total: {:?}\n", self.elapsed()));
        report
    }
}

/// A scope guard that records the duration of the enclosed scope.
///
/// # Example
///
/// ```rust
/// use hologram_telemetry::profiling::ScopeProfiler;
///
/// fn expensive_operation() {
///     let _guard = ScopeProfiler::new("expensive_operation", |duration| {
///         println!("Operation took {:?}", duration);
///     });
///     // ... do work ...
/// }
/// ```
pub struct ScopeProfiler<F: FnOnce(Duration)> {
    start: Instant,
    callback: Option<F>,
}

impl<F: FnOnce(Duration)> ScopeProfiler<F> {
    /// Create a new scope profiler with a callback.
    #[must_use]
    pub fn new(_name: &'static str, callback: F) -> Self {
        Self {
            start: Instant::now(),
            callback: Some(callback),
        }
    }
}

impl<F: FnOnce(Duration)> Drop for ScopeProfiler<F> {
    fn drop(&mut self) {
        if let Some(callback) = self.callback.take() {
            callback(self.start.elapsed());
        }
    }
}

/// Memory usage information (basic).
#[derive(Debug, Clone, Copy, Default)]
pub struct MemoryInfo {
    /// Allocated bytes (if available).
    pub allocated_bytes: Option<u64>,
}

impl MemoryInfo {
    /// Get current memory information.
    ///
    /// Note: This is a placeholder implementation. For accurate memory
    /// information, platform-specific code or external profiling tools
    /// should be used.
    #[must_use]
    pub fn current() -> Self {
        Self {
            allocated_bytes: None,
        }
    }
}

/// A guard for tracking memory usage in a scope.
pub struct MemoryProfiler {
    start_info: MemoryInfo,
}

impl MemoryProfiler {
    /// Create a new memory profiler.
    #[must_use]
    pub fn new() -> Self {
        Self {
            start_info: MemoryInfo::current(),
        }
    }

    /// Get the starting memory info.
    #[must_use]
    pub const fn start_info(&self) -> MemoryInfo {
        self.start_info
    }

    /// Get the current memory info.
    #[must_use]
    pub fn current_info(&self) -> MemoryInfo {
        MemoryInfo::current()
    }
}

impl Default for MemoryProfiler {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicBool, Ordering};
    use std::sync::Arc;

    #[test]
    fn test_profiler_new() {
        let profiler = Profiler::new("test");
        assert_eq!(profiler.name(), "test");
    }

    #[test]
    fn test_profiler_elapsed() {
        let profiler = Profiler::new("test");
        std::thread::sleep(Duration::from_millis(10));
        let elapsed = profiler.elapsed();
        assert!(elapsed >= Duration::from_millis(10));
    }

    #[test]
    fn test_profiler_checkpoint() {
        let mut profiler = Profiler::new("test");
        std::thread::sleep(Duration::from_millis(5));
        profiler.checkpoint("first");
        std::thread::sleep(Duration::from_millis(5));
        profiler.checkpoint("second");

        let checkpoints = profiler.checkpoints();
        assert_eq!(checkpoints.len(), 2);
        assert_eq!(checkpoints[0].0, "first");
        assert_eq!(checkpoints[1].0, "second");
        assert!(checkpoints[1].1 > checkpoints[0].1);
    }

    #[test]
    fn test_profiler_reset() {
        let mut profiler = Profiler::new("test");
        profiler.checkpoint("before_reset");
        assert_eq!(profiler.checkpoints().len(), 1);

        profiler.reset();
        assert_eq!(profiler.checkpoints().len(), 0);
    }

    #[test]
    fn test_profiler_report() {
        let mut profiler = Profiler::new("test_report");
        profiler.checkpoint("step1");
        profiler.checkpoint("step2");

        let report = profiler.report();
        assert!(report.contains("test_report"));
        assert!(report.contains("step1"));
        assert!(report.contains("step2"));
        assert!(report.contains("Total:"));
    }

    #[test]
    fn test_scope_profiler() {
        let called = Arc::new(AtomicBool::new(false));
        let called_clone = called.clone();

        {
            let _guard = ScopeProfiler::new("test_scope", move |duration| {
                called_clone.store(true, Ordering::SeqCst);
                assert!(duration >= Duration::from_millis(0));
            });
        }

        assert!(called.load(Ordering::SeqCst));
    }

    #[test]
    fn test_memory_info() {
        let info = MemoryInfo::current();
        // Just verify it doesn't panic
        let _ = info.allocated_bytes;
    }

    #[test]
    fn test_memory_profiler() {
        let profiler = MemoryProfiler::new();
        let _ = profiler.start_info();
        let _ = profiler.current_info();
    }

    #[test]
    fn test_memory_profiler_default() {
        let profiler = MemoryProfiler::default();
        let _ = profiler.start_info();
    }
}
