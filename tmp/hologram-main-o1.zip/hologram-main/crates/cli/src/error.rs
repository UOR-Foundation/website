//! CLI error types with colored diagnostics.

use owo_colors::OwoColorize;
use std::path::PathBuf;
use thiserror::Error;

/// Result type for CLI operations.
pub type CliResult<T> = Result<T, CliError>;

/// CLI-specific errors.
#[derive(Error, Debug)]
pub enum CliError {
    /// File not found.
    #[error("file not found: {0}")]
    FileNotFound(PathBuf),

    /// Unsupported file format.
    #[error("unsupported file format: {0}")]
    UnsupportedFormat(String),

    /// Invalid input data.
    #[error("invalid input: {0}")]
    InvalidInput(String),

    /// Compilation failed.
    #[error("compilation failed: {0}")]
    CompilationFailed(String),

    /// Execution failed.
    #[error("execution failed: {0}")]
    ExecutionFailed(String),

    /// IO error.
    #[error("IO error: {0}")]
    Io(String),

    /// IO error with context.
    #[error("{0}")]
    IoError(#[from] std::io::Error),

    /// JSON parsing error.
    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),

    /// Feature not yet implemented.
    #[error("{0} is not yet implemented")]
    NotImplemented(String),

    /// Registry error.
    #[error("registry error: {0}")]
    Registry(#[from] hologram_registry::RegistryError),

    /// Backend error with context.
    #[error("{context}: {source}")]
    Backend {
        /// Context describing where the error occurred
        context: String,
        /// Underlying backend error
        #[source]
        source: hologram_backend::BackendError,
    },

    /// Compiler error with context.
    #[error("{context}: {source}")]
    Compiler {
        /// Context describing where the error occurred
        context: String,
        /// Underlying compiler error
        #[source]
        source: hologram_compiler::CompileError,
    },

    /// Holo format error with context.
    #[error("{context}: {source}")]
    Holo {
        /// Context describing where the error occurred
        context: String,
        /// Underlying holo error
        #[source]
        source: hologram_holo::HoloError,
    },
}

impl CliError {
    /// Create a backend error with context.
    pub fn backend(context: impl Into<String>, source: hologram_backend::BackendError) -> Self {
        Self::Backend {
            context: context.into(),
            source,
        }
    }

    /// Create a compiler error with context.
    pub fn compiler(context: impl Into<String>, source: hologram_compiler::CompileError) -> Self {
        Self::Compiler {
            context: context.into(),
            source,
        }
    }

    /// Create a holo error with context.
    pub fn holo(context: impl Into<String>, source: hologram_holo::HoloError) -> Self {
        Self::Holo {
            context: context.into(),
            source,
        }
    }
}

/// Print a formatted error with colored output and context chain.
///
/// This displays errors in a human-readable format with:
/// - Red "error:" prefix
/// - Main error message
/// - Cause chain (if any)
/// - Hints for common issues
pub fn print_error(err: &CliError) {
    eprintln!("{}: {}", "error".red().bold(), err);

    // Print cause chain if available
    if let Some(source) = std::error::Error::source(err) {
        eprintln!();
        eprintln!("{}:", "Caused by".yellow().bold());
        let mut current = Some(source);
        let mut indent = 0;
        while let Some(cause) = current {
            eprintln!("  {}{}", "  ".repeat(indent), cause);
            current = cause.source();
            indent += 1;
        }
    }

    // Print hints for common errors
    print_hints(err);
}

/// Print hints for common error scenarios.
fn print_hints(err: &CliError) {
    match err {
        CliError::FileNotFound(path) => {
            eprintln!();
            eprintln!(
                "{}: Check that the file path is correct.",
                "hint".cyan().bold()
            );
            if let Some(ext) = path.extension() {
                if ext == "holb" {
                    eprintln!(
                        "{}: Use `hologram compile` to create .holb files from JSON graphs.",
                        "hint".cyan().bold()
                    );
                } else if ext == "holm" {
                    eprintln!(
                        "{}: .holm files are model bundles. Use `hologram info` to inspect them.",
                        "hint".cyan().bold()
                    );
                }
            }
        }
        CliError::UnsupportedFormat(fmt) => {
            eprintln!();
            eprintln!(
                "{}: Supported formats: .holb, .holm, .json",
                "hint".cyan().bold()
            );
            if fmt.contains("onnx") {
                eprintln!(
                    "{}: ONNX import is available via the hologram-ai repository.",
                    "hint".cyan().bold()
                );
            }
        }
        CliError::InvalidInput(msg) => {
            eprintln!();
            if msg.contains("shape") || msg.contains("dimension") {
                eprintln!(
                    "{}: Check that input tensor shapes match the model's expected input.",
                    "hint".cyan().bold()
                );
            } else if msg.contains("dtype") || msg.contains("type") {
                eprintln!(
                    "{}: Ensure data types match (e.g., f32 vs f64).",
                    "hint".cyan().bold()
                );
            }
        }
        CliError::CompilationFailed(msg) => {
            eprintln!();
            if msg.contains("graph") {
                eprintln!(
                    "{}: Use `hologram validate` to check your graph for errors.",
                    "hint".cyan().bold()
                );
            }
            eprintln!(
                "{}: Run with RUST_LOG=debug for detailed compilation traces.",
                "hint".cyan().bold()
            );
        }
        CliError::ExecutionFailed(msg) => {
            eprintln!();
            if msg.contains("memory") || msg.contains("allocation") {
                eprintln!(
                    "{}: The model may require more memory. Try reducing batch size.",
                    "hint".cyan().bold()
                );
            } else if msg.contains("buffer") {
                eprintln!(
                    "{}: Check that all input buffers are properly sized.",
                    "hint".cyan().bold()
                );
            }
        }
        CliError::Backend {
            source: hologram_backend::BackendError::InstructionError { operation, .. },
            ..
        } => {
            eprintln!();
            eprintln!(
                "{}: The {} operation failed. Check buffer sizes and input data.",
                "hint".cyan().bold(),
                operation.yellow()
            );
        }
        CliError::Backend {
            source: hologram_backend::BackendError::SizeMismatch { expected, actual },
            ..
        } => {
            eprintln!();
            eprintln!(
                "{}: Expected {} bytes but got {}. Resize your input buffer.",
                "hint".cyan().bold(),
                expected,
                actual
            );
        }
        CliError::Backend {
            source: hologram_backend::BackendError::LayerLoadError { layer_id, .. },
            ..
        } => {
            eprintln!();
            eprintln!(
                "{}: Layer {} could not be loaded. Check the registry or file path.",
                "hint".cyan().bold(),
                layer_id.yellow()
            );
        }
        CliError::Backend {
            source: hologram_backend::BackendError::CorruptedLayer { .. },
            ..
        } => {
            eprintln!();
            eprintln!(
                "{}: The layer file may be corrupted. Try re-downloading or re-compiling.",
                "hint".cyan().bold()
            );
        }
        CliError::Backend {
            source: hologram_backend::BackendError::NotImplemented { feature },
            ..
        } => {
            eprintln!();
            eprintln!(
                "{}: {} is not yet available. Check the project roadmap for updates.",
                "hint".cyan().bold(),
                feature.yellow()
            );
        }
        CliError::Compiler { .. } => {
            eprintln!();
            eprintln!(
                "{}: Use `hologram validate` to get detailed graph diagnostics.",
                "hint".cyan().bold()
            );
        }
        CliError::Registry(hologram_registry::RegistryError::NotFound(what)) => {
            eprintln!();
            eprintln!(
                "{}: {} was not found in the registry.",
                "hint".cyan().bold(),
                what
            );
            eprintln!(
                "{}: Use `hologram registry list` to see available entries.",
                "hint".cyan().bold()
            );
        }
        CliError::NotImplemented(feature) => {
            eprintln!();
            eprintln!(
                "{}: {} is planned but not yet implemented.",
                "hint".cyan().bold(),
                feature.yellow()
            );
        }
        _ => {}
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io;

    #[test]
    fn test_file_not_found_error() {
        let err = CliError::FileNotFound(PathBuf::from("/path/to/model.holb"));
        let msg = format!("{}", err);
        assert!(msg.contains("file not found"));
        assert!(msg.contains("/path/to/model.holb"));
    }

    #[test]
    fn test_unsupported_format_error() {
        let err = CliError::UnsupportedFormat(".xyz".to_string());
        let msg = format!("{}", err);
        assert!(msg.contains("unsupported file format"));
        assert!(msg.contains(".xyz"));
    }

    #[test]
    fn test_invalid_input_error() {
        let err = CliError::InvalidInput("shape mismatch: expected [1,3,224,224]".to_string());
        let msg = format!("{}", err);
        assert!(msg.contains("invalid input"));
        assert!(msg.contains("shape mismatch"));
    }

    #[test]
    fn test_compilation_failed_error() {
        let err = CliError::CompilationFailed("graph validation failed".to_string());
        let msg = format!("{}", err);
        assert!(msg.contains("compilation failed"));
        assert!(msg.contains("graph validation"));
    }

    #[test]
    fn test_execution_failed_error() {
        let err = CliError::ExecutionFailed("buffer overflow".to_string());
        let msg = format!("{}", err);
        assert!(msg.contains("execution failed"));
        assert!(msg.contains("buffer overflow"));
    }

    #[test]
    fn test_io_error() {
        let err = CliError::Io("permission denied".to_string());
        let msg = format!("{}", err);
        assert!(msg.contains("IO error"));
        assert!(msg.contains("permission denied"));
    }

    #[test]
    fn test_io_error_from_std() {
        let io_err = io::Error::new(io::ErrorKind::NotFound, "file missing");
        let err = CliError::from(io_err);
        assert!(matches!(err, CliError::IoError(_)));
    }

    #[test]
    fn test_not_implemented_error() {
        let err = CliError::NotImplemented("GPU acceleration".to_string());
        let msg = format!("{}", err);
        assert!(msg.contains("not yet implemented"));
        assert!(msg.contains("GPU acceleration"));
    }

    #[test]
    fn test_backend_error_constructor() {
        let backend_err = hologram_backend::BackendError::NotImplemented {
            feature: "CUDA".to_string(),
        };
        let err = CliError::backend("during execution", backend_err);
        let msg = format!("{}", err);
        assert!(msg.contains("during execution"));
    }

    #[test]
    fn test_compiler_error_constructor() {
        let compiler_err = hologram_compiler::CompileError::CycleDetected;
        let err = CliError::compiler("during compilation", compiler_err);
        let msg = format!("{}", err);
        assert!(msg.contains("during compilation"));
    }

    #[test]
    fn test_holo_error_constructor() {
        let holo_err = hologram_holo::HoloError::InvalidFormat {
            expected: "HOLB".to_string(),
            found: "JUNK".to_string(),
        };
        let err = CliError::holo("loading file", holo_err);
        let msg = format!("{}", err);
        assert!(msg.contains("loading file"));
    }

    #[test]
    fn test_print_error_file_not_found_holb() {
        // Just verify it doesn't panic
        let err = CliError::FileNotFound(PathBuf::from("model.holb"));
        print_error(&err);
    }

    #[test]
    fn test_print_error_file_not_found_holm() {
        let err = CliError::FileNotFound(PathBuf::from("model.holm"));
        print_error(&err);
    }

    #[test]
    fn test_print_error_unsupported_format_onnx() {
        let err = CliError::UnsupportedFormat(".onnx files".to_string());
        print_error(&err);
    }

    #[test]
    fn test_print_error_invalid_input_shape() {
        let err = CliError::InvalidInput("shape dimension mismatch".to_string());
        print_error(&err);
    }

    #[test]
    fn test_print_error_invalid_input_dtype() {
        let err = CliError::InvalidInput("dtype f16 not supported".to_string());
        print_error(&err);
    }

    #[test]
    fn test_print_error_compilation_graph() {
        let err = CliError::CompilationFailed("invalid graph structure".to_string());
        print_error(&err);
    }

    #[test]
    fn test_print_error_execution_memory() {
        let err = CliError::ExecutionFailed("memory allocation failed".to_string());
        print_error(&err);
    }

    #[test]
    fn test_print_error_execution_buffer() {
        let err = CliError::ExecutionFailed("buffer size mismatch".to_string());
        print_error(&err);
    }

    #[test]
    fn test_print_error_not_implemented() {
        let err = CliError::NotImplemented("profiling".to_string());
        print_error(&err);
    }

    #[test]
    fn test_print_error_backend_instruction() {
        let backend_err = hologram_backend::BackendError::InstructionError {
            index: 5,
            operation: "MatMul".to_string(),
            message: "dimension mismatch".to_string(),
        };
        let err = CliError::backend("executing plan", backend_err);
        print_error(&err);
    }

    #[test]
    fn test_print_error_backend_size_mismatch() {
        let backend_err = hologram_backend::BackendError::SizeMismatch {
            expected: 1024,
            actual: 512,
        };
        let err = CliError::backend("allocating buffer", backend_err);
        print_error(&err);
    }

    #[test]
    fn test_print_error_backend_layer_load() {
        let backend_err = hologram_backend::BackendError::LayerLoadError {
            layer_id: "layer_001".to_string(),
            reason: "file not found".to_string(),
        };
        let err = CliError::backend("loading model", backend_err);
        print_error(&err);
    }

    #[test]
    fn test_print_error_backend_corrupted_layer() {
        let backend_err = hologram_backend::BackendError::CorruptedLayer {
            layer_id: "layer_002".to_string(),
            expected: "abc123".to_string(),
            actual: "def456".to_string(),
        };
        let err = CliError::backend("verifying layer", backend_err);
        print_error(&err);
    }

    #[test]
    fn test_print_error_backend_not_implemented() {
        let backend_err = hologram_backend::BackendError::NotImplemented {
            feature: "WebGPU backend".to_string(),
        };
        let err = CliError::backend("selecting backend", backend_err);
        print_error(&err);
    }

    #[test]
    fn test_print_error_compiler() {
        let compiler_err = hologram_compiler::CompileError::CycleDetected;
        let err = CliError::compiler("validating graph", compiler_err);
        print_error(&err);
    }

    #[test]
    fn test_error_source_chain() {
        let io_err = io::Error::new(io::ErrorKind::PermissionDenied, "access denied");
        let err = CliError::from(io_err);

        // Verify source chain works
        let source = std::error::Error::source(&err);
        assert!(source.is_some());
    }

    #[test]
    fn test_cli_result_ok() {
        let result: CliResult<i32> = Ok(42);
        assert!(matches!(result, Ok(42)));
    }

    #[test]
    fn test_cli_result_err() {
        let result: CliResult<i32> = Err(CliError::Io("test error".to_string()));
        assert!(result.is_err());
    }
}
