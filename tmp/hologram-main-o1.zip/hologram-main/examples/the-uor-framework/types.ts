import { SimulationNodeDatum, SimulationLinkDatum } from 'd3';

export interface JsonLDNode {
  "@id": string;
  "@type"?: string | string[];
  "label"?: string;
  "comment"?: string;
  "formula"?: string;
  "yieldsValue"?: { "@value": number | string };
  "partOf"?: string;
  "contains"?: string[];
  [key: string]: any;
}

export interface OntologyGraph {
  "@context": any;
  "@graph": JsonLDNode[];
}

export interface D3Node extends SimulationNodeDatum {
  id: string;
  group: string;
  label: string;
  val: number;
}

export interface D3Link extends SimulationLinkDatum<D3Node> {
  source: string | D3Node;
  target: string | D3Node;
  relationship: string;
}

export enum CodecStatus {
  IDLE = 'IDLE',
  PROCESSING = 'PROCESSING',
  SUCCESS = 'SUCCESS',
  FAILURE = 'FAILURE'
}

export interface EncodedArtifact {
  original: string;
  bigIntRep: string;
  gaugeLevel: number;
  gaugeIndex: number; // The index within that gauge
  coordinates: {
    level: number;
    phase: number;
    remainder: string;
    modulus: string; // Added for reconstruction/verification
  }[];
  verification: boolean;
}