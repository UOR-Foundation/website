//! Kernel selection (Stage 3).
//!
//! This module provides:
//! - `KernelRegistry`: A registry of available kernel implementations
//! - `KernelCost`: Cost model for estimating kernel performance
//! - `select_kernels`: Assigns optimal kernels to graph nodes

mod cost;
mod registry;
mod select;

pub use cost::{estimate_cost, KernelCost};
pub use registry::{KernelId, KernelInfo, KernelRegistry, KernelRequirements};
pub use select::{
    select_kernels, select_kernels_with_cost, select_kernels_with_registry, total_graph_cost,
};
