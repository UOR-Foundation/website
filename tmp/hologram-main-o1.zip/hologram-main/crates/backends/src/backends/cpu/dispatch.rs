//! Instruction dispatch for CPU backend.
//!
//! Provides `exec_*` handler functions for each ISA instruction.
//! The unified dispatch system (`dispatch_unified.rs`) delegates to these
//! handlers via the `InstructionDispatcher` trait implementation in
//! `dispatcher_impl.rs`.
//!
//! # Instrumentation
//!
//! When the `instrumentation` feature is enabled, dispatch operations
//! emit tracing spans for observability. This adds ~5% overhead.
//! Disable the feature for production builds.

use std::collections::HashMap;

use hologram_holo::IsaInstruction;
use uor::lut::{
    abs_lut, byte_add, byte_mul, exp_lut, gelu_lut, log_lut, orbit_class_q0, relu_lut, sigmoid_lut,
    silu_lut, sqrt_lut, tanh_lut, torus_page_q0, ABS_256, EXP_256, GELU_256, LOG_256, RELU_256,
    SIGMOID_256, SILU_256, SQRT_256, TANH_256,
};

use super::context::ExecutionContext;
use crate::kernel_override;
use crate::types::{BackendError, Result};

// ============================================================================
// Arithmetic Operations (TASK-041) with SIMD optimization (TASK-046)
// ============================================================================

/// Commutative binary SIMD kernel: uses in-place path when dst aliases a or b,
/// avoiding scratch buffer allocation entirely (TASK-324).
macro_rules! binary_commutative_kernel {
    ($($fn_name:ident -> $simd_fn:ident / $inplace_fn:ident),+ $(,)?) => {
        $(
            pub(crate) fn $fn_name(
                ctx: &mut ExecutionContext<'_>,
                dst: u32,
                a: u32,
                b: u32,
                count: usize,
            ) -> Result<()> {
                // In-place path for commutative ops: modify dst directly.
                // Since add/mul are commutative, dst==a and dst==b are symmetric.
                if dst == a && dst != b {
                    let b_ptr = ctx.read_f32(b, count)?.as_ptr();
                    let dst_data = ctx.write_f32_mut(dst, count)?;
                    let b_slice = unsafe { std::slice::from_raw_parts(b_ptr, count) };
                    super::simd::$inplace_fn(dst_data, b_slice);
                    return Ok(());
                }
                if dst == b && dst != a {
                    let a_ptr = ctx.read_f32(a, count)?.as_ptr();
                    let dst_data = ctx.write_f32_mut(dst, count)?;
                    let a_slice = unsafe { std::slice::from_raw_parts(a_ptr, count) };
                    super::simd::$inplace_fn(dst_data, a_slice);
                    return Ok(());
                }
                // All-same (dst == a == b): scratch fallback (rare)
                if dst == a {
                    let data = ctx.read_f32(a, count)?;
                    let ptr = data.as_ptr();
                    let scratch = ctx.scratch_ptr(count);
                    let s = unsafe { std::slice::from_raw_parts(ptr, count) };
                    let out = unsafe { std::slice::from_raw_parts_mut(scratch, count) };
                    super::simd::$simd_fn(s, s, out);
                    let done = unsafe { std::slice::from_raw_parts(scratch, count) };
                    return ctx.write_f32(dst, done);
                }

                // Non-aliasing: zero-copy into dst
                let a_data = ctx.read_f32(a, count)?;
                let b_data = ctx.read_f32(b, count)?;
                let a_ptr = a_data.as_ptr();
                let b_ptr = b_data.as_ptr();
                let a_len = a_data.len();
                let b_len = b_data.len();

                let dst_data = ctx.write_f32_mut(dst, count)?;
                let a_slice = unsafe { std::slice::from_raw_parts(a_ptr, a_len) };
                let b_slice = unsafe { std::slice::from_raw_parts(b_ptr, b_len) };

                super::simd::$simd_fn(a_slice, b_slice, dst_data);
                Ok(())
            }
        )+
    };
}

/// Non-commutative binary SIMD kernel: scratch buffer for in-place operations.
macro_rules! binary_simd_kernel {
    ($($fn_name:ident -> $simd_fn:ident),+ $(,)?) => {
        $(
            pub(crate) fn $fn_name(
                ctx: &mut ExecutionContext<'_>,
                dst: u32,
                a: u32,
                b: u32,
                count: usize,
            ) -> Result<()> {
                if dst == a || dst == b {
                    let a_data = ctx.read_f32(a, count)?;
                    let b_data = ctx.read_f32(b, count)?;
                    let a_ptr = a_data.as_ptr();
                    let b_ptr = b_data.as_ptr();
                    let scratch = ctx.scratch_ptr(count);
                    let a_s = unsafe { std::slice::from_raw_parts(a_ptr, count) };
                    let b_s = unsafe { std::slice::from_raw_parts(b_ptr, count) };
                    let out = unsafe { std::slice::from_raw_parts_mut(scratch, count) };
                    super::simd::$simd_fn(a_s, b_s, out);
                    let done = unsafe { std::slice::from_raw_parts(scratch, count) };
                    return ctx.write_f32(dst, done);
                }

                let a_data = ctx.read_f32(a, count)?;
                let b_data = ctx.read_f32(b, count)?;
                let a_ptr = a_data.as_ptr();
                let b_ptr = b_data.as_ptr();
                let a_len = a_data.len();
                let b_len = b_data.len();

                let dst_data = ctx.write_f32_mut(dst, count)?;
                let a_slice = unsafe { std::slice::from_raw_parts(a_ptr, a_len) };
                let b_slice = unsafe { std::slice::from_raw_parts(b_ptr, b_len) };

                super::simd::$simd_fn(a_slice, b_slice, dst_data);
                Ok(())
            }
        )+
    };
}

binary_commutative_kernel!(
    exec_add -> add_simd / add_inplace_simd,
    exec_mul -> mul_simd / mul_inplace_simd,
    exec_elem_min -> elem_min_simd / elem_min_inplace_simd,
    exec_elem_max -> elem_max_simd / elem_max_inplace_simd,
);

binary_simd_kernel!(
    exec_sub -> sub_simd,
    exec_pow -> pow_simd,
    exec_greater -> greater_simd,
    exec_less -> less_simd,
);

/// Element-wise division: dst[i] = a[i] / b[i] (scalar, no SIMD).
pub(crate) fn exec_div(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    a: u32,
    b: u32,
    count: usize,
) -> Result<()> {
    let a_data = ctx.read_f32(a, count)?;
    let b_data = ctx.read_f32(b, count)?;
    let mut result = vec![0.0f32; count];
    for i in 0..count {
        result[i] = a_data[i] / b_data[i];
    }
    ctx.write_f32(dst, &result)
}

// ============================================================================
// Activation Functions (TASK-042)
// ============================================================================

/// Unary SIMD kernel: zero-copy when dst != src,
/// scratch buffer fallback for in-place operations.
macro_rules! unary_simd_kernel {
    ($($fn_name:ident -> $simd_fn:ident),+ $(,)?) => {
        $(
            pub(crate) fn $fn_name(
                ctx: &mut ExecutionContext<'_>,
                dst: u32,
                src: u32,
                count: usize,
            ) -> Result<()> {
                if dst == src {
                    let src_data = ctx.read_f32(src, count)?;
                    let src_ptr = src_data.as_ptr();
                    let scratch = ctx.scratch_ptr(count);
                    let s = unsafe { std::slice::from_raw_parts(src_ptr, count) };
                    let out = unsafe { std::slice::from_raw_parts_mut(scratch, count) };
                    super::simd::$simd_fn(s, out);
                    let done = unsafe { std::slice::from_raw_parts(scratch, count) };
                    return ctx.write_f32(dst, done);
                }

                let src_data = ctx.read_f32(src, count)?;
                let src_ptr = src_data.as_ptr();
                let src_len = src_data.len();

                let dst_data = ctx.write_f32_mut(dst, count)?;
                let src_slice = unsafe { std::slice::from_raw_parts(src_ptr, src_len) };

                super::simd::$simd_fn(src_slice, dst_data);
                Ok(())
            }
        )+
    };
}

unary_simd_kernel!(
    exec_sigmoid -> sigmoid_simd,
    exec_tanh -> tanh_simd,
    exec_relu -> relu_simd,
);

/// Softmax activation with axis support.
///
/// Applies softmax along the specified axis of the tensor.
/// The tensor is interpreted as [outer_size, axis_size, inner_size].
pub(crate) fn exec_softmax(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    outer_size: usize,
    axis_size: usize,
    inner_size: usize,
) -> Result<()> {
    let count = outer_size * axis_size * inner_size;
    let src_data = ctx.read_f32(src, count)?;
    let mut result = vec![0.0f32; count];

    // Try kernel override first (allows hologram-ai to inject optimized implementations)
    if let Some(provider) = kernel_override() {
        if let Some(override_result) =
            provider.softmax(src_data, &mut result, outer_size, axis_size, inner_size)
        {
            override_result?;
            return ctx.write_f32(dst, &result);
        }
    }

    // Default implementation
    super::simd::softmax_simd(src_data, &mut result, outer_size, axis_size, inner_size);
    ctx.write_f32(dst, &result)
}

// ============================================================================
// Transformer Operations (Sqrt, Log, Exp, Abs — via unary_simd_kernel!)
// Pow, ElemMin, ElemMax, Greater, Less — via binary_simd_kernel! above
// ============================================================================

unary_simd_kernel!(
    exec_sqrt -> sqrt_simd,
    exec_log -> log_simd,
    exec_exp -> exp_simd,
    exec_abs -> abs_simd,
);

/// Element-wise less-or-equal: dst[i] = (a[i] <= b[i]) ? 1.0 : 0.0
/// Uses AVX2/NEON SIMD when available with Rayon parallelization for large arrays.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip_all, fields(dst, a, b, count))
)]
pub(crate) fn exec_less_or_equal(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    a: u32,
    b: u32,
    count: usize,
) -> Result<()> {
    if dst == a || dst == b {
        let a_data = ctx.read_f32(a, count)?;
        let b_data = ctx.read_f32(b, count)?;
        let a_ptr = a_data.as_ptr();
        let b_ptr = b_data.as_ptr();
        let scratch = ctx.scratch_ptr(count);
        let a_s = unsafe { std::slice::from_raw_parts(a_ptr, count) };
        let b_s = unsafe { std::slice::from_raw_parts(b_ptr, count) };
        let out = unsafe { std::slice::from_raw_parts_mut(scratch, count) };

        #[cfg(not(target_arch = "wasm32"))]
        {
            super::simd::less_or_equal_parallel(a_s, b_s, out);
        }
        #[cfg(target_arch = "wasm32")]
        {
            super::simd::less_or_equal_simd(a_s, b_s, out);
        }

        let done = unsafe { std::slice::from_raw_parts(scratch, count) };
        return ctx.write_f32(dst, done);
    }

    // Non-aliased path: zero-copy writes
    let a_data = ctx.read_f32(a, count)?;
    let b_data = ctx.read_f32(b, count)?;
    let a_ptr = a_data.as_ptr();
    let b_ptr = b_data.as_ptr();
    let a_len = a_data.len();
    let b_len = b_data.len();

    let dst_data = ctx.write_f32_mut(dst, count)?;
    let a_slice = unsafe { std::slice::from_raw_parts(a_ptr, a_len) };
    let b_slice = unsafe { std::slice::from_raw_parts(b_ptr, b_len) };

    #[cfg(not(target_arch = "wasm32"))]
    {
        super::simd::less_or_equal_parallel(a_slice, b_slice, dst_data);
    }
    #[cfg(target_arch = "wasm32")]
    {
        super::simd::less_or_equal_simd(a_slice, b_slice, dst_data);
    }

    Ok(())
}

/// Element-wise greater-or-equal: dst[i] = (a[i] >= b[i]) ? 1.0 : 0.0
/// Uses AVX2/NEON SIMD when available with Rayon parallelization for large arrays.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip_all, fields(dst, a, b, count))
)]
pub(crate) fn exec_greater_or_equal(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    a: u32,
    b: u32,
    count: usize,
) -> Result<()> {
    if dst == a || dst == b {
        let a_data = ctx.read_f32(a, count)?;
        let b_data = ctx.read_f32(b, count)?;
        let a_ptr = a_data.as_ptr();
        let b_ptr = b_data.as_ptr();
        let scratch = ctx.scratch_ptr(count);
        let a_s = unsafe { std::slice::from_raw_parts(a_ptr, count) };
        let b_s = unsafe { std::slice::from_raw_parts(b_ptr, count) };
        let out = unsafe { std::slice::from_raw_parts_mut(scratch, count) };

        #[cfg(not(target_arch = "wasm32"))]
        {
            super::simd::greater_or_equal_parallel(a_s, b_s, out);
        }
        #[cfg(target_arch = "wasm32")]
        {
            super::simd::greater_or_equal_simd(a_s, b_s, out);
        }

        let done = unsafe { std::slice::from_raw_parts(scratch, count) };
        return ctx.write_f32(dst, done);
    }

    let a_data = ctx.read_f32(a, count)?;
    let b_data = ctx.read_f32(b, count)?;
    let a_ptr = a_data.as_ptr();
    let b_ptr = b_data.as_ptr();
    let a_len = a_data.len();
    let b_len = b_data.len();

    let dst_data = ctx.write_f32_mut(dst, count)?;
    let a_slice = unsafe { std::slice::from_raw_parts(a_ptr, a_len) };
    let b_slice = unsafe { std::slice::from_raw_parts(b_ptr, b_len) };

    #[cfg(not(target_arch = "wasm32"))]
    {
        super::simd::greater_or_equal_parallel(a_slice, b_slice, dst_data);
    }
    #[cfg(target_arch = "wasm32")]
    {
        super::simd::greater_or_equal_simd(a_slice, b_slice, dst_data);
    }

    Ok(())
}

/// Conditional select: dst[i] = cond[i] != 0 ? x[i] : y[i]
/// Uses AVX2/NEON SIMD when available.
pub(crate) fn exec_where(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    cond: u32,
    x: u32,
    y: u32,
    count: usize,
) -> Result<()> {
    // For where, we always use the temporary buffer approach since we have 3 sources
    let cond_data = ctx.read_f32(cond, count)?;
    let x_data = ctx.read_f32(x, count)?;
    let y_data = ctx.read_f32(y, count)?;

    let mut result = vec![0.0f32; count];
    super::simd::where_simd(cond_data, x_data, y_data, &mut result);

    ctx.write_f32(dst, &result)
}

// ============================================================================
// Linear Algebra (TASK-043) with tiled optimization (TASK-048)
// ============================================================================

/// Matrix multiplication: C = A @ B
/// A is m×k, B is k×n, C is m×n (row-major layout)
/// Uses BLIS-style A+B packing with SIMD micro-kernels for cache efficiency.
#[allow(clippy::many_single_char_names)] // Standard matrix variable names
pub(crate) fn exec_matmul(
    ctx: &mut ExecutionContext<'_>,
    c: u32,
    a: u32,
    b: u32,
    m: usize,
    k: usize,
    n: usize,
) -> Result<()> {
    // Read input matrices
    let a_data = ctx.read_f32(a, m * k)?;
    let b_data = ctx.read_f32(b, k * n)?;

    // Allocate result matrix
    let mut result = vec![0.0f32; m * n];

    // Try kernel override first (allows hologram-ai to inject cuBLAS, oneDNN, etc.)
    if let Some(provider) = kernel_override() {
        if let Some(override_result) = provider.matmul(a_data, b_data, &mut result, m, k, n) {
            override_result?;
            return ctx.write_f32(c, &result);
        }
    }

    // Use parallel matmul for large matrices (Rayon + BLIS packing),
    // falls back to unpacked tiled matmul for small matrices.
    // Benchmarks show single-threaded packing overhead exceeds cache benefit,
    // so we only pack when Rayon amortizes the cost across threads.
    super::simd::matmul_parallel(a_data, b_data, &mut result, m, k, n);

    ctx.write_f32(c, &result)
}

/// Batched matrix multiplication: C[b] = A[b] @ B[b] for each batch b.
/// Each matrix in the batch has dimensions: A[M×K], B[K×N], C[M×N].
#[allow(clippy::many_single_char_names)]
pub(crate) fn exec_batch_matmul(
    ctx: &mut ExecutionContext<'_>,
    c: u32,
    a: u32,
    b: u32,
    batch_count: usize,
    m: usize,
    k: usize,
    n: usize,
) -> Result<()> {
    let a_matrix_size = m * k;
    let b_matrix_size = k * n;
    let c_matrix_size = m * n;

    // Read all input data
    let a_data = ctx.read_f32(a, batch_count * a_matrix_size)?;
    let b_data = ctx.read_f32(b, batch_count * b_matrix_size)?;

    // Allocate result buffer
    let mut result = vec![0.0f32; batch_count * c_matrix_size];

    // Try kernel override first (allows hologram-ai to inject cuBLAS, oneDNN, etc.)
    if let Some(provider) = kernel_override() {
        if let Some(override_result) =
            provider.batch_matmul(a_data, b_data, &mut result, batch_count, m, k, n)
        {
            override_result?;
            return ctx.write_f32(c, &result);
        }
    }

    // Default: process each batch with parallel matmul (Rayon for large, tiled for small)
    for batch_idx in 0..batch_count {
        let a_offset = batch_idx * a_matrix_size;
        let b_offset = batch_idx * b_matrix_size;
        let c_offset = batch_idx * c_matrix_size;

        let a_slice = &a_data[a_offset..a_offset + a_matrix_size];
        let b_slice = &b_data[b_offset..b_offset + b_matrix_size];
        let c_slice = &mut result[c_offset..c_offset + c_matrix_size];

        super::simd::matmul_parallel(a_slice, b_slice, c_slice, m, k, n);
    }

    ctx.write_f32(c, &result)
}

// ============================================================================
// Fused Operations (TASK-327)
// Single dispatch, single memory pass — no intermediate buffer.
// ============================================================================

/// Fused MatMul + ReLU: C = max(0, A @ B).
///
/// Performs matmul then applies ReLU in-place on the result buffer,
/// saving one dispatch and one memory pass over separate MatMul + ReLU.
#[allow(clippy::many_single_char_names)]
pub(crate) fn exec_matmul_relu(
    ctx: &mut ExecutionContext<'_>,
    c: u32,
    a: u32,
    b: u32,
    m: usize,
    k: usize,
    n: usize,
) -> Result<()> {
    let a_data = ctx.read_f32(a, m * k)?;
    let b_data = ctx.read_f32(b, k * n)?;
    let mut result = vec![0.0f32; m * n];

    if let Some(provider) = kernel_override() {
        if let Some(override_result) = provider.matmul(a_data, b_data, &mut result, m, k, n) {
            override_result?;
            // Apply ReLU in-place
            for v in &mut result {
                *v = v.max(0.0);
            }
            return ctx.write_f32(c, &result);
        }
    }

    super::simd::matmul_parallel(a_data, b_data, &mut result, m, k, n);
    // Fused ReLU: apply in-place (no clone — just max(0, x) per element)
    for v in &mut result {
        *v = v.max(0.0);
    }
    ctx.write_f32(c, &result)
}

/// Fused Add + Sigmoid: dst[i] = sigmoid(a[i] + b[i]).
///
/// Performs element-wise add then sigmoid in a single dispatch, saving
/// one dispatch overhead and one memory pass.
pub(crate) fn exec_add_sigmoid(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    a: u32,
    b: u32,
    count: usize,
) -> Result<()> {
    let a_data = ctx.read_f32(a, count)?;
    let b_data = ctx.read_f32(b, count)?;
    let a_ptr = a_data.as_ptr();
    let b_ptr = b_data.as_ptr();
    let a_len = a_data.len();
    let b_len = b_data.len();

    // Add into scratch, then sigmoid into dst
    let mut temp = vec![0.0f32; count];
    let a_slice = unsafe { std::slice::from_raw_parts(a_ptr, a_len) };
    let b_slice = unsafe { std::slice::from_raw_parts(b_ptr, b_len) };
    super::simd::add_simd(a_slice, b_slice, &mut temp);

    let dst_data = ctx.write_f32_mut(dst, count)?;
    super::simd::sigmoid_simd(&temp, dst_data);
    Ok(())
}

/// LUT-based matrix multiplication with quantized weights.
///
/// Uses the Psumbook approach: for each output element, builds a partial sum
/// table indexed by quantization level, then accumulates via lookups.
/// 2-4x faster than tiled MatMul for small batch sizes.
#[allow(clippy::many_single_char_names)]
#[allow(clippy::too_many_arguments)]
pub(crate) fn exec_matmul_lut(
    ctx: &mut ExecutionContext<'_>,
    c: u32,
    a: u32,
    indices: u32,
    centroids: u32,
    m: usize,
    k: usize,
    n: usize,
    quant_bits: u8,
) -> Result<()> {
    // Read activations
    let a_data = ctx.read_f32(a, m * k)?;

    // Read centroids
    let num_centroids = match quant_bits {
        4 => 16,
        8 => 256,
        _ => {
            return Err(BackendError::UnsupportedInstruction(
                "MatMulLUT: quant_bits must be 4 or 8".to_string(),
            ))
        }
    };
    let centroids_data = ctx.read_f32(centroids, num_centroids)?;

    // Read packed indices
    let indices_size = match quant_bits {
        4 => k.div_ceil(2) * n, // 2 indices per byte for Q4
        8 => k * n,             // 1 index per byte for Q8
        _ => unreachable!(),
    };
    let indices_data = ctx.read_buffer(indices)?;
    if indices_data.len() < indices_size {
        return Err(BackendError::SizeMismatch {
            expected: indices_size,
            actual: indices_data.len(),
        });
    }

    // Allocate result
    let mut result = vec![0.0f32; m * n];

    // Execute LUT-based MatMul
    match quant_bits {
        4 => {
            // Reconstruct QuantizedWeights4 from buffer data
            let mut idx = vec![0u8; k.div_ceil(2) * n];
            idx[..indices_size].copy_from_slice(&indices_data[..indices_size]);
            let mut cents = [0.0f32; 16];
            cents.copy_from_slice(centroids_data);
            let qw = super::lut_matmul::QuantizedWeights4 {
                indices: idx,
                centroids: cents,
                rows: k,
                cols: n,
            };
            super::lut_matmul::matmul_lut_q4(a_data, &qw, &mut result, m, k, n);
        }
        8 => {
            // Reconstruct QuantizedWeights8 from buffer data
            let mut idx = vec![0u8; k * n];
            idx[..indices_size].copy_from_slice(&indices_data[..indices_size]);
            let mut cents = [0.0f32; 256];
            cents.copy_from_slice(centroids_data);
            let qw = super::lut_matmul::QuantizedWeights8 {
                indices: idx,
                centroids: cents,
                rows: k,
                cols: n,
            };
            super::lut_matmul::matmul_lut_q8(a_data, &qw, &mut result, m, k, n);
        }
        _ => unreachable!(),
    }

    ctx.write_f32(c, &result)
}

// ============================================================================
// Reduction Operations (TASK-044)
// ============================================================================

/// Sum reduction: dst = sum(src[0..count])
/// Uses AVX2/NEON SIMD horizontal reduction when available.
pub(crate) fn exec_sum(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_f32(src, count)?;

    // Use SIMD-optimized sum reduction
    let sum = super::simd::sum_simd(src_data);

    // Write single f32 result
    ctx.write_f32(dst, &[sum])
}

/// Max reduction: dst = max(src[0..count])
/// Uses AVX2/NEON SIMD horizontal reduction when available.
pub(crate) fn exec_max(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_f32(src, count)?;

    // Use SIMD-optimized max reduction
    let max = super::simd::max_simd(src_data);

    // Write single f32 result
    ctx.write_f32(dst, &[max])
}

/// Min reduction: dst = min(src[0..count])
/// Uses AVX2/NEON SIMD horizontal reduction when available.
pub(crate) fn exec_min(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_f32(src, count)?;

    // Use SIMD-optimized min reduction
    let min = super::simd::min_simd(src_data);

    // Write single f32 result
    ctx.write_f32(dst, &[min])
}

/// Axis-aware mean reduction for LayerNorm/RMSNorm.
///
/// Computes mean along a specific axis, producing one mean value for each
/// combination of outer and inner indices:
/// `dst[o*inner_size + i] = mean(src[o*axis_size*inner_size + j*inner_size + i] for j in 0..axis_size)`
///
/// For input shape `[outer_size, axis_size, inner_size]`:
/// - Output shape is `[outer_size, 1, inner_size]`
/// - Total output elements: `outer_size * inner_size`
#[allow(clippy::cast_precision_loss)]
pub(crate) fn exec_reduce_mean(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    outer_size: usize,
    axis_size: usize,
    inner_size: usize,
) -> Result<()> {
    let total_input = outer_size * axis_size * inner_size;
    let src_data = ctx.read_f32(src, total_input)?;

    let total_output = outer_size * inner_size;
    let mut output = vec![0.0f32; total_output];

    let axis_size_f32 = axis_size as f32;

    // For each output position (o, i), sum over axis dimension j
    for o in 0..outer_size {
        for i in 0..inner_size {
            let mut sum = 0.0f32;
            for j in 0..axis_size {
                let src_idx = o * axis_size * inner_size + j * inner_size + i;
                sum += src_data[src_idx];
            }
            let dst_idx = o * inner_size + i;
            output[dst_idx] = sum / axis_size_f32;
        }
    }

    ctx.write_f32(dst, &output)
}

// ============================================================================
// Categorical Operations (TASK-059, TASK-060)
// ============================================================================

/// Lift operation: Map bytes to torus coordinates.
///
/// For each input byte, computes torus cell coordinates using O(1) LUT:
/// - page = torus_page_q0(byte)  →  0..47 (48 pages)
/// - offset = byte  →  0..255
///
/// Output format: PackedCell as u16 where upper 8 bits = page, lower 8 bits = offset.
/// This matches the spec: "PackedCell: upper 8 bits = page, lower 8 bits = byte"
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_lift(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;
    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // Compute torus coordinates for each byte using O(1) LUT
    // Output is count * 2 bytes (u16 per input byte)
    let mut result = vec![0u8; count * 2];
    for (i, &byte) in src_data.iter().take(count).enumerate() {
        // O(1) page lookup from precomputed table
        let page = torus_page_q0(byte);

        // Pack as u16: page in upper byte, offset (original byte) in lower byte
        let packed = (u16::from(page) << 8) | u16::from(byte);
        result[i * 2] = (packed & 0xFF) as u8;
        result[i * 2 + 1] = (packed >> 8) as u8;
    }

    ctx.write_buffer(dst, &result)
}

/// OrbitClassify operation: Assign orbit class to each byte.
///
/// Orbit classes partition the 256 byte values into 32 groups (B = 32).
/// Each class contains 8 consecutive bytes: class k contains bytes [8k, 8k+7].
///
/// Output: orbit class index [0, 31] for each input byte.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_orbit_classify(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;
    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // O(1) orbit class lookup from precomputed table
    let result: Vec<u8> = src_data
        .iter()
        .take(count)
        .map(|&b| orbit_class_q0(b))
        .collect();

    ctx.write_buffer(dst, &result)
}

/// Ring addition (mod 96): dst[i] = (a[i] + b[i]) % 96
///
/// Operates on the resonance ring R = T × B = 3 × 32 = 96.
/// Input bytes are first reduced mod 96, then added mod 96.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_ring_add(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    a: u32,
    b: u32,
    count: usize,
) -> Result<()> {
    let a_data = ctx.read_buffer(a)?;
    let b_data = ctx.read_buffer(b)?;

    if a_data.len() < count || b_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: a_data.len().min(b_data.len()),
        });
    }

    // O(1) ring addition using precomputed 96x96 LUT
    // O(1) ring addition using precomputed LUT
    // ring_add_256 handles mod reduction + addition in pure table lookups
    let result: Vec<u8> = a_data
        .iter()
        .zip(b_data.iter())
        .take(count)
        .map(|(&a_val, &b_val)| byte_add(a_val, b_val))
        .collect();

    ctx.write_buffer(dst, &result)
}

/// Ring multiplication (mod 96): dst[i] = (a[i] * b[i]) % 96
///
/// Operates on the resonance ring R = T × B = 3 × 32 = 96.
/// Uses O(1) LUT lookups for both mod reduction and ring multiplication.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_ring_mul(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    a: u32,
    b: u32,
    count: usize,
) -> Result<()> {
    let a_data = ctx.read_buffer(a)?;
    let b_data = ctx.read_buffer(b)?;

    if a_data.len() < count || b_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: a_data.len().min(b_data.len()),
        });
    }

    // O(1) ring multiplication using precomputed LUT
    // ring_mul_256 handles mod reduction + multiplication in pure table lookups
    let result: Vec<u8> = a_data
        .iter()
        .zip(b_data.iter())
        .take(count)
        .map(|(&a_val, &b_val)| byte_mul(a_val, b_val))
        .collect();

    ctx.write_buffer(dst, &result)
}

/// O(1) LUT-based sigmoid activation for quantized u8 data.
///
/// Uses `SIGMOID_256` table for constant-time lookup.
/// Input bytes are treated as signed (-128 to 127 via two's complement).
/// Output is scaled 0-255 (128 = sigmoid(0) = 0.5).
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_sigmoid_lut(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;

    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // O(1) sigmoid using precomputed LUT - pure table lookup, no computation
    let result: Vec<u8> = src_data
        .iter()
        .take(count)
        .map(|&v| sigmoid_lut(v))
        .collect();

    ctx.write_buffer(dst, &result)
}

/// O(1) LUT-based tanh activation for quantized u8 data.
///
/// Uses `TANH_256` table for constant-time lookup.
/// Input bytes are treated as signed (-128 to 127 via two's complement).
/// Output is scaled 0-255 (128 = tanh(0) = 0).
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_tanh_lut(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;

    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // O(1) tanh using precomputed LUT - pure table lookup, no computation
    let result: Vec<u8> = src_data.iter().take(count).map(|&v| tanh_lut(v)).collect();

    ctx.write_buffer(dst, &result)
}

/// O(1) LUT-based exp activation for quantized u8 data.
///
/// Uses `EXP_256` table for constant-time lookup.
/// Input bytes are treated as signed (-128 to 127 via two's complement).
/// Output is scaled 0-255.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_exp_lut(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;

    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // O(1) exp using precomputed LUT - pure table lookup, no computation
    let result: Vec<u8> = src_data.iter().take(count).map(|&v| exp_lut(v)).collect();

    ctx.write_buffer(dst, &result)
}

/// O(1) LUT-based log activation for quantized u8 data.
///
/// Uses `LOG_256` table for constant-time lookup.
/// Input is unsigned 8-bit (0-255).
/// Output is scaled 0-255 (log(0) returns 0).
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_log_lut(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;

    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // O(1) log using precomputed LUT - pure table lookup, no computation
    let result: Vec<u8> = src_data.iter().take(count).map(|&v| log_lut(v)).collect();

    ctx.write_buffer(dst, &result)
}

/// O(1) LUT-based ReLU activation for quantized u8 data.
///
/// Uses `RELU_256` table for constant-time lookup.
/// Input bytes are treated as signed (-128 to 127 via two's complement).
/// Output: max(0, x) - positive values unchanged, negatives become 0.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_relu_lut(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;

    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // O(1) relu using precomputed LUT - pure table lookup, no computation
    let result: Vec<u8> = src_data.iter().take(count).map(|&v| relu_lut(v)).collect();

    ctx.write_buffer(dst, &result)
}

/// O(1) LUT-based sqrt for quantized u8 data.
///
/// Uses `SQRT_256` table for constant-time lookup.
/// Input is unsigned 8-bit (0-255).
/// Output is scaled 0-255.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_sqrt_lut(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;

    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // O(1) sqrt using precomputed LUT - pure table lookup, no computation
    let result: Vec<u8> = src_data.iter().take(count).map(|&v| sqrt_lut(v)).collect();

    ctx.write_buffer(dst, &result)
}

/// O(1) LUT-based abs for quantized u8 data.
///
/// Uses `ABS_256` table for constant-time lookup.
/// Input bytes are treated as signed (-128 to 127 via two's complement).
/// Output: |x|, where |-128| = 128.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_abs_lut(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;

    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // O(1) abs using precomputed LUT - pure table lookup, no computation
    let result: Vec<u8> = src_data.iter().take(count).map(|&v| abs_lut(v)).collect();

    ctx.write_buffer(dst, &result)
}

/// Execute GELU LUT instruction.
///
/// Applies O(1) GELU activation using precomputed lookup table.
/// GELU is the primary activation in transformers (BERT, GPT, ViT).
pub(crate) fn exec_gelu_lut(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;

    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // O(1) GELU using precomputed LUT - pure table lookup, no computation
    let result: Vec<u8> = src_data.iter().take(count).map(|&v| gelu_lut(v)).collect();

    ctx.write_buffer(dst, &result)
}

/// Execute SiLU (Swish) LUT instruction.
///
/// Applies O(1) SiLU activation using precomputed lookup table.
/// SiLU is used in EfficientNet, ConvNeXt, and modern architectures.
pub(crate) fn exec_silu_lut(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;

    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // O(1) SiLU using precomputed LUT - pure table lookup, no computation
    let result: Vec<u8> = src_data.iter().take(count).map(|&v| silu_lut(v)).collect();

    ctx.write_buffer(dst, &result)
}

// ============================================================================
// Memory Operations (TASK-045)
// ============================================================================

/// Load data from one buffer to another (buffer-to-buffer copy)
pub(crate) fn exec_load(
    _ctx: &mut ExecutionContext<'_>,
    _buffer: u32,
    _offset: usize,
    _size: usize,
) -> Result<()> {
    // In the unified buffer model, Load typically copies between buffers.
    // For now, this is a no-op since data is already in the buffer space.
    Ok(())
}

/// Store data (no-op in unified buffer model)
pub(crate) fn exec_store(
    _ctx: &mut ExecutionContext<'_>,
    _buffer: u32,
    _offset: usize,
    _size: usize,
) -> Result<()> {
    // In the unified buffer model, Store is a no-op since data is already
    // in the buffer space and will be extracted at the end.
    Ok(())
}

/// Copy data from source buffer to destination buffer
pub(crate) fn exec_copy(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    size: usize,
) -> Result<()> {
    // Read source data
    let src_data = ctx.read_buffer(src)?;
    if src_data.len() < size {
        return Err(BackendError::SizeMismatch {
            expected: size,
            actual: src_data.len(),
        });
    }

    // Copy data
    let data_copy: Vec<u8> = src_data[..size].to_vec();

    // Write to destination
    ctx.write_buffer(dst, &data_copy)
}

// ============================================================================
// Shape Operations
// ============================================================================

/// Tile tensor by repeating along dimensions.
///
/// Takes input tensor and repeats it according to the multiples for each dimension.
/// Uses parallelization for large outputs (>= 16384 * num_threads).
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip_all, fields(dst, src, ndim, count))
)]
pub(crate) fn exec_tile(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    ndim: u8,
    input_shape: &[usize; 8],
    multiples: &[usize; 8],
    count: usize,
) -> Result<()> {
    let in_count: usize = input_shape[..ndim as usize].iter().product();
    let src_data = ctx.read_f32(src, in_count)?;
    let mut result = vec![0.0f32; count];

    let in_shape = &input_shape[..ndim as usize];
    let mult = &multiples[..ndim as usize];

    #[cfg(not(target_arch = "wasm32"))]
    {
        super::simd::tile_parallel(src_data, &mut result, in_shape, mult);
    }
    #[cfg(target_arch = "wasm32")]
    {
        super::simd::tile_scalar(src_data, &mut result, in_shape, mult);
    }

    ctx.write_f32(dst, &result)
}

/// Expand tensor to target shape via broadcasting.
///
/// Uses NumPy broadcasting rules: dimensions are right-aligned, size-1 dimensions
/// are repeated to match the target shape.
/// Uses parallelization for large outputs (>= 16384 * num_threads).
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip_all, fields(dst, src, ndim, count))
)]
pub(crate) fn exec_expand(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    ndim: u8,
    input_shape: &[usize; 8],
    target_shape: &[usize; 8],
    count: usize,
) -> Result<()> {
    let in_count: usize = input_shape[..ndim as usize].iter().product();
    let src_data = ctx.read_f32(src, in_count)?;
    let mut result = vec![0.0f32; count];

    let in_shape = &input_shape[..ndim as usize];
    let tgt_shape = &target_shape[..ndim as usize];

    #[cfg(not(target_arch = "wasm32"))]
    {
        super::simd::expand_parallel(src_data, &mut result, in_shape, tgt_shape);
    }
    #[cfg(target_arch = "wasm32")]
    {
        super::simd::expand_scalar(src_data, &mut result, in_shape, tgt_shape);
    }

    ctx.write_f32(dst, &result)
}

// ============================================================================
// Composition
// ============================================================================

/// Execute a sub-layer via CallLayer instruction.
///
/// Extracts input data from current buffers, executes the sub-layer,
/// and copies outputs back to the destination buffers.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_call_layer(
    ctx: &mut ExecutionContext<'_>,
    layer_id: u64,
    input_indices: &[u32],
    output_indices: &[u32],
) -> Result<()> {
    // Gather input data from buffers
    let inputs: Vec<Vec<u8>> = input_indices
        .iter()
        .map(|&idx| ctx.read_buffer(idx).map(<[u8]>::to_vec))
        .collect::<Result<Vec<_>>>()?;
    let input_refs: Vec<&[u8]> = inputs.iter().map(Vec::as_slice).collect();

    // Prepare output buffers (sized based on what we can read from metadata)
    // For now, use the destination buffer sizes
    let output_sizes: Vec<usize> = output_indices
        .iter()
        .map(|&idx| ctx.read_buffer(idx).map(<[u8]>::len).unwrap_or(0))
        .collect();

    let mut outputs: Vec<Vec<u8>> = output_sizes.iter().map(|&sz| vec![0u8; sz]).collect();
    let mut output_refs: Vec<&mut [u8]> = outputs.iter_mut().map(Vec::as_mut_slice).collect();

    // Execute the sub-layer
    ctx.execute_sublayer(layer_id, &input_refs, &mut output_refs)?;

    // Copy outputs back to destination buffers
    for (&idx, output) in output_indices.iter().zip(outputs.iter()) {
        ctx.write_buffer(idx, output)?;
    }

    Ok(())
}

// ============================================================================
// Codec Operations (TASK-089)
// ============================================================================

/// Encode bytes using a codec.
///
/// Transforms input bytes through the specified codec's representation.
/// Codecs: 0=binary, 1=decimal, 2=hexadecimal, 3=mod96crt, 4=continuedFraction.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_encode(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    codec_id: u32,
    count: usize,
) -> Result<()> {
    let codec = crate::codec::get_codec(codec_id).ok_or_else(|| {
        BackendError::UnsupportedInstruction(format!("unknown codec ID: {codec_id}"))
    })?;

    let src_data = ctx.read_buffer(src)?;
    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    let encoded = codec
        .encode(&src_data[..count])
        .map_err(|e| BackendError::ExecutionError(format!("codec encode failed: {e}")))?;

    ctx.write_buffer(dst, &encoded)
}

/// Decode bytes from a codec's representation.
///
/// Transforms encoded data back to original bytes.
/// Codecs: 0=binary, 1=decimal, 2=hexadecimal, 3=mod96crt, 4=continuedFraction.
#[cfg_attr(
    feature = "instrumentation",
    tracing::instrument(skip(ctx), level = "debug")
)]
pub(crate) fn exec_decode(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    codec_id: u32,
    count: usize,
) -> Result<()> {
    let codec = crate::codec::get_codec(codec_id).ok_or_else(|| {
        BackendError::UnsupportedInstruction(format!("unknown codec ID: {codec_id}"))
    })?;

    let src_data = ctx.read_buffer(src)?;
    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    let decoded = codec
        .decode(&src_data[..count])
        .map_err(|e| BackendError::ExecutionError(format!("codec decode failed: {e}")))?;

    ctx.write_buffer(dst, &decoded)
}

// ============================================================================
// Shape Operations
// ============================================================================

/// Reshape buffer (zero-copy for contiguous data).
pub(crate) fn exec_reshape(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;
    let size = count * 4; // Assuming f32
    if src_data.len() < size {
        return Err(BackendError::SizeMismatch {
            expected: size,
            actual: src_data.len(),
        });
    }
    let data_copy = src_data[..size].to_vec();
    ctx.write_buffer(dst, &data_copy)
}

/// Transpose/permute dimensions.
#[allow(clippy::too_many_arguments)]
pub(crate) fn exec_transpose(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
    ndim: u8,
    shape: &[usize; 8],
    perm: [u8; 8],
) -> Result<()> {
    let src_data = ctx.read_f32(src, count)?;
    let mut result = vec![0.0f32; count];

    let ndim = ndim as usize;
    let shape = &shape[..ndim];
    let perm: Vec<usize> = perm[..ndim].iter().map(|&p| p as usize).collect();

    // Compute strides for source and destination
    let mut src_strides = vec![1usize; ndim];
    for i in (0..ndim.saturating_sub(1)).rev() {
        src_strides[i] = src_strides[i + 1] * shape[i + 1];
    }

    // Compute transposed shape and strides
    let transposed_shape: Vec<usize> = perm.iter().map(|&p| shape[p]).collect();
    let mut dst_strides = vec![1usize; ndim];
    for i in (0..ndim.saturating_sub(1)).rev() {
        dst_strides[i] = dst_strides[i + 1] * transposed_shape[i + 1];
    }

    // Perform transpose
    for (dst_idx, dest) in result.iter_mut().enumerate().take(count) {
        // Convert flat dst index to multi-dimensional coordinates
        let mut coords = vec![0usize; ndim];
        let mut remaining = dst_idx;
        for i in 0..ndim {
            coords[i] = remaining / dst_strides[i];
            remaining %= dst_strides[i];
        }

        // Apply inverse permutation to get source coordinates
        let mut src_coords = vec![0usize; ndim];
        for (i, &p) in perm.iter().enumerate() {
            src_coords[p] = coords[i];
        }

        // Convert source coordinates to flat index
        let src_idx: usize = src_coords
            .iter()
            .zip(src_strides.iter())
            .map(|(&c, &s)| c * s)
            .sum();

        *dest = src_data[src_idx];
    }

    ctx.write_f32(dst, &result)
}

/// Gather elements by indices (embedding lookup).
///
/// Supports both integer indices (I32/I64) and float indices (F32).
/// Float indices are converted to integers by truncation (e.g., 1.0 -> 1).
#[allow(clippy::too_many_arguments)]
pub(crate) fn exec_gather(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    data: u32,
    indices: u32,
    _axis: u8,
    num_indices: usize,
    slice_size: usize,
    data_size: usize,
) -> Result<()> {
    let data_buf = ctx.read_f32(data, data_size)?;
    let indices_buf = ctx.read_buffer(indices)?;

    let mut result = Vec::with_capacity(num_indices * slice_size);

    // Determine if indices are F32 or integer based on buffer content
    // Check multiple values: if any non-zero value looks like F32 (in typical F32 range), use F32 mode.
    // F32 values for small integers (1.0-1000.0) have exponent in range 0x3F8-0x449 (bytes 0x3F-0x44).
    let (indices_are_f32, first_as_u32) = {
        let mut f32_count = 0;
        let mut int_count = 0;
        let mut first_val = 0u32;
        for (i, chunk) in indices_buf.chunks(4).take(20).enumerate() {
            if chunk.len() < 4 {
                break;
            }
            let val = u32::from_le_bytes(chunk.try_into().unwrap());
            if i == 0 {
                first_val = val;
            }
            if val == 0 {
                // Zero is ambiguous - could be 0 as int or 0.0 as f32
                continue;
            }
            // Check if val looks like an F32 representation of a small positive number
            // F32 for 0.5-2000 has bits 0x3F000000-0x4500_0000 (approximately)
            if (0x3F00_0000..0x5000_0000).contains(&val) {
                f32_count += 1;
            } else if val < 100_000 {
                // Small integers (valid embedding indices)
                int_count += 1;
            }
        }
        (f32_count > int_count, first_val)
    };

    // Debug output
    if std::env::var("HOLOGRAM_DEBUG_GATHER").is_ok() {
        eprintln!(
            "[Gather] indices_buf.len()={}, first_as_u32=0x{:08x}, indices_are_f32={}, data_size={}, slice_size={}",
            indices_buf.len(),
            first_as_u32,
            indices_are_f32,
            data_size,
            slice_size
        );
        if indices_buf.len() >= 20 {
            let first_5: Vec<(u32, f32)> = (0..5)
                .map(|i| {
                    let bytes: [u8; 4] = indices_buf[i * 4..(i + 1) * 4].try_into().unwrap();
                    (u32::from_le_bytes(bytes), f32::from_le_bytes(bytes))
                })
                .collect();
            eprintln!("[Gather] First 5 indices: {first_5:?}");
        }
        // Debug: show first few values from embedding table
        let emb_sample: Vec<f32> = data_buf.iter().take(10).copied().collect();
        eprintln!("[Gather] Embedding table first 10 values: {emb_sample:?}");
    }

    let debug_gather = std::env::var("HOLOGRAM_DEBUG_GATHER").is_ok();
    let mut debug_results: Vec<(usize, Vec<f32>)> = Vec::new();

    for (idx_num, idx_bytes) in indices_buf.chunks(4).take(num_indices).enumerate() {
        if idx_bytes.len() < 4 {
            break;
        }
        #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)]
        let i = if indices_are_f32 {
            // Interpret as F32 and convert to integer index
            let f = f32::from_le_bytes(idx_bytes.try_into().unwrap());
            f as usize
        } else {
            // Interpret as U32 index
            u32::from_le_bytes(idx_bytes.try_into().unwrap()) as usize
        };
        let start = i * slice_size;
        let end = start + slice_size;
        if end <= data_buf.len() {
            let slice = &data_buf[start..end];
            if debug_gather && idx_num < 5 {
                debug_results.push((i, slice[..5.min(slice_size)].to_vec()));
            }
            result.extend_from_slice(slice);
        } else {
            // Pad with zeros if index is out of bounds
            result.extend(std::iter::repeat_n(0.0f32, slice_size));
            if debug_gather && idx_num < 5 {
                debug_results.push((i, vec![0.0; 5.min(slice_size)]));
            }
        }
    }

    if debug_gather && !debug_results.is_empty() {
        eprintln!("[Gather] First 5 lookups (idx, first5vals): {debug_results:?}");
    }

    ctx.write_f32(dst, &result)
}

/// Concatenate buffers.
pub(crate) fn exec_concat(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    srcs: &[u32; 8],
    num_srcs: u8,
    sizes: &[usize; 8],
) -> Result<()> {
    let mut result = Vec::new();

    for i in 0..num_srcs as usize {
        let src_data = ctx.read_buffer(srcs[i])?;
        let size = sizes[i];
        if src_data.len() >= size {
            result.extend_from_slice(&src_data[..size]);
        }
    }

    ctx.write_buffer(dst, &result)
}

/// Insert size-1 dimension (copy operation).
pub(crate) fn exec_unsqueeze(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    size: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;
    if src_data.len() < size {
        return Err(BackendError::SizeMismatch {
            expected: size,
            actual: src_data.len(),
        });
    }
    let data_copy = src_data[..size].to_vec();
    ctx.write_buffer(dst, &data_copy)
}

/// Remove size-1 dimension (copy operation).
pub(crate) fn exec_squeeze(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    size: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;
    if src_data.len() < size {
        return Err(BackendError::SizeMismatch {
            expected: size,
            actual: src_data.len(),
        });
    }
    let data_copy = src_data[..size].to_vec();
    ctx.write_buffer(dst, &data_copy)
}

/// Slice/extract tensor portion with strided access.
///
/// Supports arbitrary strides per dimension, including negative strides for reverse.
#[allow(clippy::too_many_arguments, clippy::cast_sign_loss)]
pub(crate) fn exec_slice(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    ndim: u8,
    src_shape: &[u32; 4],
    dst_shape: &[u32; 4],
    starts: &[u32; 4],
    steps: &[i32; 4],
    elem_size: u8,
) -> Result<()> {
    let ndim = ndim as usize;
    let elem_size = elem_size as usize;

    // Compute destination element count from dst_shape
    let dst_count: usize = dst_shape[..ndim].iter().map(|&d| d as usize).product();

    let src_data = ctx.read_buffer(src)?;
    let mut result = vec![0u8; dst_count * elem_size];

    if ndim == 0 || dst_count == 0 {
        // Scalar case or empty: just return
        if ndim == 0 && elem_size <= src_data.len() && elem_size <= result.len() {
            result[..elem_size].copy_from_slice(&src_data[..elem_size]);
        }
        return ctx.write_buffer(dst, &result);
    }

    // Compute source strides (row-major order)
    let mut src_strides = [0usize; 4];
    let mut stride = 1usize;
    for i in (0..ndim).rev() {
        src_strides[i] = stride;
        stride *= src_shape[i] as usize;
    }

    // Compute destination strides (row-major order)
    let mut dst_strides = [0usize; 4];
    let mut dst_stride = 1usize;
    for i in (0..ndim).rev() {
        dst_strides[i] = dst_stride;
        dst_stride *= dst_shape[i] as usize;
    }

    // Copy elements one by one
    for dst_idx in 0..dst_count {
        // Decompose dst_idx into output coordinates
        let mut out_coords = [0usize; 4];
        let mut idx = dst_idx;
        for i in 0..ndim {
            out_coords[i] = idx / dst_strides[i];
            idx %= dst_strides[i];
        }

        // Map output coords to source coords using starts and steps
        let mut src_linear = 0;
        for i in 0..ndim {
            let step = steps[i];
            let src_coord = if step >= 0 {
                starts[i] as usize + out_coords[i] * (step as usize)
            } else {
                (starts[i] as usize).wrapping_sub(out_coords[i] * ((-step) as usize))
            };
            src_linear += src_coord * src_strides[i];
        }

        // Copy element
        let src_start = src_linear * elem_size;
        let dst_start = dst_idx * elem_size;
        if src_start + elem_size <= src_data.len() && dst_start + elem_size <= result.len() {
            result[dst_start..dst_start + elem_size]
                .copy_from_slice(&src_data[src_start..src_start + elem_size]);
        }
    }

    ctx.write_buffer(dst, &result)
}

/// Pad tensor with constant values.
#[allow(clippy::too_many_arguments)]
pub(crate) fn exec_pad(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    ndim: u8,
    src_shape: &[u32; 4],
    pad_before: &[u32; 4],
    pad_after: &[u32; 4],
    constant_value: f32,
    elem_size: u8,
) -> Result<()> {
    let ndim = ndim as usize;
    let elem_size = elem_size as usize;

    // Compute destination shape
    let mut dst_shape = [0usize; 4];
    for i in 0..ndim {
        dst_shape[i] = src_shape[i] as usize + pad_before[i] as usize + pad_after[i] as usize;
    }

    // Compute destination element count
    let dst_count: usize = dst_shape[..ndim].iter().product();

    let src_data = ctx.read_buffer(src)?;
    let mut result = vec![0u8; dst_count * elem_size];

    // Fill with constant value
    let const_bytes = constant_value.to_ne_bytes();
    let copy_len = elem_size.min(4);
    for i in 0..dst_count {
        let start = i * elem_size;
        result[start..(start + copy_len)].copy_from_slice(&const_bytes[..copy_len]);
    }

    if ndim == 0 || dst_count == 0 {
        return ctx.write_buffer(dst, &result);
    }

    // Compute source strides (row-major order)
    let mut src_strides = [0usize; 4];
    let mut stride = 1usize;
    for i in (0..ndim).rev() {
        src_strides[i] = stride;
        stride *= src_shape[i] as usize;
    }

    // Compute destination strides (row-major order)
    let mut dst_strides = [0usize; 4];
    let mut dst_stride = 1usize;
    for i in (0..ndim).rev() {
        dst_strides[i] = dst_stride;
        dst_stride *= dst_shape[i];
    }

    // Copy source data into padded region
    let src_count: usize = (0..ndim).map(|i| src_shape[i] as usize).product();
    for src_idx in 0..src_count {
        // Decompose src_idx into source coordinates
        let mut src_coords = [0usize; 4];
        let mut idx = src_idx;
        for i in 0..ndim {
            src_coords[i] = idx / src_strides[i];
            idx %= src_strides[i];
        }

        // Map to destination coordinates (add padding offset)
        let mut dst_linear = 0;
        for i in 0..ndim {
            let dst_coord = src_coords[i] + pad_before[i] as usize;
            dst_linear += dst_coord * dst_strides[i];
        }

        // Copy element from source to destination
        let src_start = src_idx * elem_size;
        let dst_start = dst_linear * elem_size;
        if src_start + elem_size <= src_data.len() && dst_start + elem_size <= result.len() {
            result[dst_start..dst_start + elem_size]
                .copy_from_slice(&src_data[src_start..src_start + elem_size]);
        }
    }

    ctx.write_buffer(dst, &result)
}

/// Type cast elements.
pub(crate) fn exec_cast(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
    src_dtype: u8,
    dst_dtype: u8,
) -> Result<()> {
    // DType encoding: 0=F32, 1=F64, 2=I8, 3=I16, 4=I32, 5=I64, 6=U8, 7=U16, 8=U32, 9=U64, 10=Bool

    match (src_dtype, dst_dtype) {
        // F32 -> other types
        (0, 0) => {
            // F32 -> F32 (identity)
            let data = ctx.read_f32(src, count)?.to_vec();
            ctx.write_f32(dst, &data)
        }
        (0, 4) => {
            // F32 -> I32
            let data = ctx.read_f32(src, count)?;
            #[allow(clippy::cast_possible_truncation)]
            let result: Vec<i32> = data.iter().map(|&f| f as i32).collect();
            let bytes: Vec<u8> = result.iter().flat_map(|&i| i.to_ne_bytes()).collect();
            ctx.write_buffer(dst, &bytes)
        }
        (4, 0) => {
            // I32 -> F32
            let src_data = ctx.read_buffer(src)?;
            #[allow(clippy::cast_precision_loss)]
            let result: Vec<f32> = src_data
                .chunks_exact(4)
                .take(count)
                .map(|chunk| {
                    let i = i32::from_ne_bytes(chunk.try_into().unwrap());
                    i as f32
                })
                .collect();
            ctx.write_f32(dst, &result)
        }
        (0, 1) => {
            // F32 -> F64
            let data = ctx.read_f32(src, count)?;
            let result: Vec<f64> = data.iter().map(|&f| f64::from(f)).collect();
            let bytes: Vec<u8> = result.iter().flat_map(|&f| f.to_ne_bytes()).collect();
            ctx.write_buffer(dst, &bytes)
        }
        (1, 0) => {
            // F64 -> F32
            let src_data = ctx.read_buffer(src)?;
            #[allow(clippy::cast_possible_truncation)]
            let result: Vec<f32> = src_data
                .chunks_exact(8)
                .take(count)
                .map(|chunk| {
                    let f = f64::from_ne_bytes(chunk.try_into().unwrap());
                    f as f32
                })
                .collect();
            ctx.write_f32(dst, &result)
        }
        _ => {
            // For unsupported type combinations, just copy the bytes
            let src_data = ctx.read_buffer(src)?;
            let data_copy = src_data.to_vec();
            ctx.write_buffer(dst, &data_copy)
        }
    }
}

// ============================================================================
// CNN Operations
// ============================================================================

/// 2D Convolution: output = conv2d(input, weight) + bias
///
/// Uses direct convolution loop. NCHW format.
#[allow(clippy::too_many_arguments)]
pub(crate) fn exec_conv2d(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    input: u32,
    weight: u32,
    bias: Option<u32>,
    kernel_h: usize,
    kernel_w: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
    dilation_h: usize,
    dilation_w: usize,
    groups: usize,
    batch: usize,
    in_channels: usize,
    in_h: usize,
    in_w: usize,
    out_channels: usize,
    out_h: usize,
    out_w: usize,
) -> Result<()> {
    let input_data = ctx.read_f32(input, batch * in_channels * in_h * in_w)?;
    let weight_data = ctx.read_f32(
        weight,
        out_channels * (in_channels / groups) * kernel_h * kernel_w,
    )?;
    let bias_data = if let Some(bias_idx) = bias {
        Some(ctx.read_f32(bias_idx, out_channels)?.to_vec())
    } else {
        None
    };

    let mut output = vec![0.0f32; batch * out_channels * out_h * out_w];

    super::simd::conv2d_nchw(
        &mut output,
        input_data,
        weight_data,
        bias_data.as_deref(),
        batch,
        in_channels,
        out_channels,
        in_h,
        in_w,
        out_h,
        out_w,
        kernel_h,
        kernel_w,
        stride_h,
        stride_w,
        pad_h,
        pad_w,
        dilation_h,
        dilation_w,
        groups,
    );

    ctx.write_f32(dst, &output)
}

/// Batch Normalization (inference mode).
///
/// Applies: output = (input - mean) / sqrt(var + epsilon) * scale + bias
#[allow(clippy::too_many_arguments)]
pub(crate) fn exec_batch_norm(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    input: u32,
    scale: u32,
    bias: u32,
    mean: u32,
    var: u32,
    epsilon: f32,
    batch: usize,
    channels: usize,
    spatial: usize,
) -> Result<()> {
    let input_data = ctx.read_f32(input, batch * channels * spatial)?;
    let scale_data = ctx.read_f32(scale, channels)?;
    let bias_data = ctx.read_f32(bias, channels)?;
    let mean_data = ctx.read_f32(mean, channels)?;
    let var_data = ctx.read_f32(var, channels)?;

    let mut output = vec![0.0f32; batch * channels * spatial];

    super::simd::batch_norm_inference(
        &mut output,
        input_data,
        scale_data,
        bias_data,
        mean_data,
        var_data,
        epsilon,
        batch,
        channels,
        spatial,
    );

    ctx.write_f32(dst, &output)
}

/// Layer Normalization (transformer-style).
///
/// Normalizes over the last `normalized_count` elements per instance using
/// Welford's algorithm for numerical stability.
#[allow(clippy::too_many_arguments)]
pub(crate) fn exec_layer_norm(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    input: u32,
    scale: u32,
    bias: u32,
    epsilon: f32,
    num_instances: usize,
    normalized_count: usize,
) -> Result<()> {
    let total_count = num_instances * normalized_count;
    let input_data = ctx.read_f32(input, total_count)?;
    let scale_data = ctx.read_f32(scale, normalized_count)?;
    let bias_data = ctx.read_f32(bias, normalized_count)?;

    let mut output = vec![0.0f32; total_count];

    // Try kernel override first (allows hologram-ai to inject optimized implementations)
    if let Some(provider) = kernel_override() {
        if let Some(override_result) = provider.layer_norm(
            input_data,
            scale_data,
            bias_data,
            &mut output,
            num_instances,
            normalized_count,
            epsilon,
        ) {
            override_result?;
            return ctx.write_f32(dst, &output);
        }
    }

    // Default implementation
    super::simd::layer_norm_simd(
        input_data,
        scale_data,
        bias_data,
        &mut output,
        num_instances,
        normalized_count,
        epsilon,
    );

    ctx.write_f32(dst, &output)
}

/// 2D Max Pooling.
#[allow(clippy::too_many_arguments)]
pub(crate) fn exec_max_pool2d(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    kernel_h: usize,
    kernel_w: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
    batch: usize,
    channels: usize,
    in_h: usize,
    in_w: usize,
    out_h: usize,
    out_w: usize,
) -> Result<()> {
    let input_data = ctx.read_f32(src, batch * channels * in_h * in_w)?;
    let mut output = vec![0.0f32; batch * channels * out_h * out_w];

    super::simd::max_pool2d(
        &mut output,
        input_data,
        batch,
        channels,
        in_h,
        in_w,
        out_h,
        out_w,
        kernel_h,
        kernel_w,
        stride_h,
        stride_w,
        pad_h,
        pad_w,
    );

    ctx.write_f32(dst, &output)
}

/// 2D Average Pooling.
#[allow(clippy::too_many_arguments)]
pub(crate) fn exec_avg_pool2d(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    kernel_h: usize,
    kernel_w: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
    batch: usize,
    channels: usize,
    in_h: usize,
    in_w: usize,
    out_h: usize,
    out_w: usize,
) -> Result<()> {
    let input_data = ctx.read_f32(src, batch * channels * in_h * in_w)?;
    let mut output = vec![0.0f32; batch * channels * out_h * out_w];

    super::simd::avg_pool2d(
        &mut output,
        input_data,
        batch,
        channels,
        in_h,
        in_w,
        out_h,
        out_w,
        kernel_h,
        kernel_w,
        stride_h,
        stride_w,
        pad_h,
        pad_w,
    );

    ctx.write_f32(dst, &output)
}

/// Global Average Pooling.
///
/// Reduces spatial dimensions to 1x1 by averaging.
pub(crate) fn exec_global_avg_pool(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    batch: usize,
    channels: usize,
    spatial: usize,
) -> Result<()> {
    let input_data = ctx.read_f32(src, batch * channels * spatial)?;
    let mut output = vec![0.0f32; batch * channels];

    super::simd::global_avg_pool(&mut output, input_data, batch, channels, spatial);

    ctx.write_f32(dst, &output)
}

// ============================================================================
// Hash Operations
// ============================================================================

/// SHA-256 hash of input buffer.
///
/// Reads `src_len` bytes from `src`, computes SHA-256, writes 32-byte digest to `dst`.
pub(crate) fn exec_sha256(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    src_len: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;
    if src_data.len() < src_len {
        return Err(BackendError::SizeMismatch {
            expected: src_len,
            actual: src_data.len(),
        });
    }
    let hash = hologram_sha256::sha256(&src_data[..src_len]);
    ctx.write_buffer(dst, hash.as_ref())
}

/// Double SHA-256: `SHA256(SHA256(data))`.
///
/// Used in Bitcoin block hashing. Reads `src_len` bytes, computes double hash,
/// writes 32-byte digest to `dst`.
pub(crate) fn exec_double_sha256(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    src_len: usize,
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;
    if src_data.len() < src_len {
        return Err(BackendError::SizeMismatch {
            expected: src_len,
            actual: src_data.len(),
        });
    }
    let hash = hologram_sha256::double_sha256(&src_data[..src_len]);
    ctx.write_buffer(dst, hash.as_ref())
}

// ============================================================================
// Tokenization Operations (TASK-245)
// ============================================================================

/// Fused Viterbi tokenization for SentencePiece Unigram models.
///
/// Performs complete tokenization in a single operation:
/// 1. Read UTF-8 bytes from input buffer
/// 2. Apply normalization (based on normalize_flags)
/// 3. Match tokens using prefix trie from vocabulary data
/// 4. Run Viterbi dynamic programming for optimal tokenization
/// 5. Write token IDs to output buffer
///
/// When the `tokenization` feature is disabled, returns an error.
#[allow(clippy::too_many_arguments)]
pub(crate) fn exec_viterbi_tokenize(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    dst_len: u32,
    src: u32,
    src_len: usize,
    vocab_data: u32,
    vocab_size: usize,
    max_tokens: usize,
    normalize_flags: u32,
    unk_token_id: u32,
    unk_score: f32,
) -> Result<()> {
    #[cfg(feature = "tokenization")]
    {
        use hologram_tokenizer::{deserialize_tokenizer, Normalizer, ViterbiTokenizer};

        // Read input UTF-8 bytes
        let input_bytes = ctx.read_buffer(src)?;
        let input_slice = &input_bytes[..src_len.min(input_bytes.len())];

        // Read vocabulary data (serialized trie + scores)
        let vocab_bytes = ctx.read_buffer(vocab_data)?;
        let vocab_slice = &vocab_bytes[..vocab_size.min(vocab_bytes.len())];

        // Deserialize vocabulary
        let (_vocab, trie, normalizer_config) = deserialize_tokenizer(vocab_slice)
            .map_err(|e| BackendError::ExecutionError(format!("Tokenizer deserialization: {e}")))?;

        // Build normalizer from flags (override serialized config if flags are set)
        let normalizer = if normalize_flags != 0 {
            build_normalizer_from_flags(normalize_flags)
        } else {
            Normalizer::new(normalizer_config)
        };

        // Convert input bytes to string
        let input_str = std::str::from_utf8(input_slice)
            .map_err(|e| BackendError::ExecutionError(format!("Invalid UTF-8 input: {e}")))?;

        // Normalize input
        let codepoints = normalizer
            .normalize(input_str)
            .map_err(|e| BackendError::ExecutionError(format!("Normalization failed: {e}")))?;

        // Run Viterbi tokenization
        let tokenizer = ViterbiTokenizer::new(trie, unk_token_id, unk_score);
        let result = tokenizer.tokenize(&codepoints);

        // Truncate to max_tokens
        let tokens: Vec<u32> = result.tokens.into_iter().take(max_tokens).collect();
        // Safety: max_tokens is typically < 32K, so token_count fits in u32
        #[allow(clippy::cast_possible_truncation)]
        let token_count = tokens.len() as u32;

        // Write output tokens
        let token_bytes: Vec<u8> = tokens.iter().flat_map(|&t| t.to_le_bytes()).collect();
        ctx.write_buffer(dst, &token_bytes)?;

        // Write token count
        ctx.write_buffer(dst_len, &token_count.to_le_bytes())?;

        Ok(())
    }

    #[cfg(not(feature = "tokenization"))]
    {
        // Suppress unused variable warnings
        let _ = (
            ctx,
            dst,
            dst_len,
            src,
            src_len,
            vocab_data,
            vocab_size,
            max_tokens,
            normalize_flags,
            unk_token_id,
            unk_score,
        );
        Err(BackendError::UnsupportedInstruction(
            "ViterbiTokenize requires the 'tokenization' feature".to_string(),
        ))
    }
}

/// Build a normalizer from normalization flags bitfield.
#[cfg(feature = "tokenization")]
fn build_normalizer_from_flags(flags: u32) -> hologram_tokenizer::Normalizer {
    use hologram_tokenizer::{NormalizerConfig, NormalizerStep};

    let mut steps = Vec::new();

    // Order matches the standard normalization pipeline
    if flags & (1 << 1) != 0 {
        steps.push(NormalizerStep::Nfkc);
    }
    if flags & (1 << 2) != 0 {
        steps.push(NormalizerStep::Nfc);
    }
    if flags & (1 << 0) != 0 {
        steps.push(NormalizerStep::Lowercase);
    }
    if flags & (1 << 5) != 0 {
        steps.push(NormalizerStep::StripAccents);
    }
    if flags & (1 << 3) != 0 {
        steps.push(NormalizerStep::ReplaceWhitespace);
    }
    if flags & (1 << 4) != 0 {
        steps.push(NormalizerStep::CollapseWhitespace);
    }
    if flags & (1 << 6) != 0 {
        steps.push(NormalizerStep::SpaceToUnderscore);
    }
    if flags & (1 << 7) != 0 {
        steps.push(NormalizerStep::PrependUnderscore);
    }

    hologram_tokenizer::Normalizer::new(NormalizerConfig { steps })
}

// ============================================================================
// LUT Activation Fusion (TASK-286)
// ============================================================================

/// Numeric ID for each LUT activation type, used as cache keys.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[repr(u8)]
pub(crate) enum LutId {
    Sigmoid = 0,
    Tanh = 1,
    Exp = 2,
    Log = 3,
    Relu = 4,
    Sqrt = 5,
    Abs = 6,
    Gelu = 7,
    Silu = 8,
}

/// Get the static 256-byte table for a LUT activation type.
#[inline]
fn lut_table(id: LutId) -> &'static [u8; 256] {
    match id {
        LutId::Sigmoid => &SIGMOID_256,
        LutId::Tanh => &TANH_256,
        LutId::Exp => &EXP_256,
        LutId::Log => &LOG_256,
        LutId::Relu => &RELU_256,
        LutId::Sqrt => &SQRT_256,
        LutId::Abs => &ABS_256,
        LutId::Gelu => &GELU_256,
        LutId::Silu => &SILU_256,
    }
}

/// Extract LUT information from an ISA instruction, if it is a LUT activation.
/// Returns `(lut_id, dst_buffer, src_buffer, element_count)`.
#[inline]
pub(crate) fn extract_lut(instr: &IsaInstruction) -> Option<(LutId, u32, u32, usize)> {
    match *instr {
        IsaInstruction::SigmoidLUT { dst, src, count } => Some((LutId::Sigmoid, dst, src, count)),
        IsaInstruction::TanhLUT { dst, src, count } => Some((LutId::Tanh, dst, src, count)),
        IsaInstruction::ExpLUT { dst, src, count } => Some((LutId::Exp, dst, src, count)),
        IsaInstruction::LogLUT { dst, src, count } => Some((LutId::Log, dst, src, count)),
        IsaInstruction::ReluLUT { dst, src, count } => Some((LutId::Relu, dst, src, count)),
        IsaInstruction::SqrtLUT { dst, src, count } => Some((LutId::Sqrt, dst, src, count)),
        IsaInstruction::AbsLUT { dst, src, count } => Some((LutId::Abs, dst, src, count)),
        IsaInstruction::GeluLUT { dst, src, count } => Some((LutId::Gelu, dst, src, count)),
        IsaInstruction::SiluLUT { dst, src, count } => Some((LutId::Silu, dst, src, count)),
        _ => None,
    }
}

/// Compose two 256-byte LUT tables: `result[x] = b[a[x]]`.
#[inline]
fn compose_luts(a: &[u8; 256], b: &[u8; 256]) -> [u8; 256] {
    let mut result = [0u8; 256];
    let mut i = 0;
    while i < 256 {
        result[i] = b[a[i] as usize];
        i += 1;
    }
    result
}

/// Cache for fused (composed) LUT tables.
///
/// When consecutive LUT activations chain (output of one feeds into the next),
/// their tables can be pre-composed into a single 256-byte table. This collapses
/// N memory passes to 1, giving 2-3x speedup for activation-heavy sequences.
///
/// Keys are sorted vectors of `LutId`s representing the chain. Tables are
/// composed once and cached for subsequent invocations.
pub(crate) struct LutFusionCache {
    /// Cache: (chain signature) → composed 256-byte table
    cache: HashMap<Vec<LutId>, [u8; 256]>,
}

impl LutFusionCache {
    pub(crate) fn new() -> Self {
        Self {
            cache: HashMap::new(),
        }
    }

    /// Get or create a composed table for a chain of LUT activations.
    pub(crate) fn get_or_compose(&mut self, chain: &[LutId]) -> &[u8; 256] {
        if !self.cache.contains_key(chain) {
            let composed = Self::compose_chain(chain);
            self.cache.insert(chain.to_vec(), composed);
        }
        &self.cache[chain]
    }

    /// Compose a chain of LUT tables into a single table.
    fn compose_chain(chain: &[LutId]) -> [u8; 256] {
        debug_assert!(!chain.is_empty());
        let mut result = *lut_table(chain[0]);
        for &id in &chain[1..] {
            result = compose_luts(&result, lut_table(id));
        }
        result
    }
}

/// Execute a fused LUT chain: apply a pre-composed table in a single pass.
pub(crate) fn exec_fused_lut_chain(
    ctx: &mut ExecutionContext<'_>,
    dst: u32,
    src: u32,
    count: usize,
    table: &[u8; 256],
) -> Result<()> {
    let src_data = ctx.read_buffer(src)?;

    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    // Single pass: apply composed table to all elements
    let result: Vec<u8> = src_data
        .iter()
        .take(count)
        .map(|&v| table[v as usize])
        .collect();

    ctx.write_buffer(dst, &result)
}

/// Scan instructions starting at `start` for a fusable LUT chain.
///
/// A chain is a sequence of consecutive LUT instructions where:
/// 1. Each instruction's `src` equals the previous instruction's `dst`
/// 2. All instructions have the same `count`
///
/// Returns `(chain_lut_ids, final_dst, original_src, count, instructions_consumed)`.
/// If no chain is found (single LUT or no LUT), returns `None`.
pub(crate) fn scan_lut_chain(
    instructions: &[IsaInstruction],
    start: usize,
) -> Option<(Vec<LutId>, u32, u32, usize, usize)> {
    let first = instructions.get(start)?;
    let (first_id, first_dst, first_src, first_count) = extract_lut(first)?;

    let mut chain = vec![first_id];
    let mut current_dst = first_dst;
    let mut consumed = 1;

    // Scan ahead for chained LUT instructions
    for instr in &instructions[start + 1..] {
        if let Some((id, dst, src, count)) = extract_lut(instr) {
            // Chain condition: src matches previous dst, same count
            if src == current_dst && count == first_count {
                chain.push(id);
                current_dst = dst;
                consumed += 1;
            } else {
                break;
            }
        } else {
            break;
        }
    }

    // Only return if we found a chain (2+ instructions)
    if consumed >= 2 {
        Some((chain, current_dst, first_src, first_count, consumed))
    } else {
        None
    }
}

// ============================================================================
// Hash Operations
// ============================================================================

#[cfg(test)]
#[allow(clippy::cast_precision_loss, clippy::uninlined_format_args)]
mod tests {
    use super::super::buffer::BufferManager;
    use super::*;
    use crate::backends::dispatch_unified::ExecuteOn;
    use hologram_holo::types::{BufferMetadata, BufferType};
    use hologram_holo::IsaInstruction;

    /// Helper to convert f32 slice to aligned byte buffer
    fn f32_to_bytes(data: &[f32]) -> Vec<u8> {
        data.iter().flat_map(|f| f.to_ne_bytes()).collect()
    }

    /// Helper to read f32 values from a byte slice
    fn bytes_to_f32(bytes: &[u8], count: usize) -> Vec<f32> {
        bytes
            .chunks_exact(4)
            .take(count)
            .map(|chunk| f32::from_ne_bytes(chunk.try_into().unwrap()))
            .collect()
    }

    fn make_metadata(types: &[BufferType], sizes: &[usize]) -> Vec<BufferMetadata> {
        types
            .iter()
            .zip(sizes.iter())
            .map(|(&bt, &sz)| BufferMetadata::new(sz, bt))
            .collect()
    }

    /// Helper to create node_buffer_map for tests (simple 1:1 mapping)
    fn make_node_map(count: usize) -> Vec<Option<u32>> {
        #[allow(clippy::cast_possible_truncation)]
        (0..count).map(|i| Some(i as u32)).collect()
    }

    // ========================================================================
    // Arithmetic Operations Tests (TASK-041)
    // ========================================================================

    #[test]
    fn test_add_basic() {
        // Set up buffers: 2 inputs, 1 workspace for result
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[16, 16, 16],
        );
        let a_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
        let b_bytes = f32_to_bytes(&[5.0, 6.0, 7.0, 8.0]);
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Add {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        };

        let result = instr.execute(&mut ctx);
        assert!(result.is_ok());

        // Verify: [1+5, 2+6, 3+7, 4+8] = [6.0, 8.0, 10.0, 12.0]
        let output_data = ctx.read_buffer(2).unwrap();
        let output = bytes_to_f32(output_data, 4);
        assert_eq!(output, vec![6.0, 8.0, 10.0, 12.0]);
    }

    #[test]
    fn test_add_zeros() {
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[12, 12, 12],
        );
        let a_bytes = f32_to_bytes(&[1.0, 2.0, 3.0]);
        let b_bytes = f32_to_bytes(&[0.0, 0.0, 0.0]);
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Add {
            dst: 2,
            a: 0,
            b: 1,
            count: 3,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(2).unwrap();
        let output = bytes_to_f32(output_data, 3);
        assert_eq!(output, vec![1.0, 2.0, 3.0]);
    }

    #[test]
    fn test_add_negative() {
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[12, 12, 12],
        );
        let a_bytes = f32_to_bytes(&[5.0, -3.0, 0.0]);
        let b_bytes = f32_to_bytes(&[-2.0, 3.0, -1.0]);
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Add {
            dst: 2,
            a: 0,
            b: 1,
            count: 3,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(2).unwrap();
        let output = bytes_to_f32(output_data, 3);
        assert_eq!(output, vec![3.0, 0.0, -1.0]);
    }

    #[test]
    fn test_sub_basic() {
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[16, 16, 16],
        );
        let a_bytes = f32_to_bytes(&[10.0, 20.0, 30.0, 40.0]);
        let b_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Sub {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(2).unwrap();
        let output = bytes_to_f32(output_data, 4);
        assert_eq!(output, vec![9.0, 18.0, 27.0, 36.0]);
    }

    #[test]
    fn test_mul_basic() {
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[16, 16, 16],
        );
        let a_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
        let b_bytes = f32_to_bytes(&[2.0, 3.0, 4.0, 5.0]);
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Mul {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(2).unwrap();
        let output = bytes_to_f32(output_data, 4);
        assert_eq!(output, vec![2.0, 6.0, 12.0, 20.0]);
    }

    #[test]
    fn test_add_invalid_buffer() {
        let metadata = make_metadata(&[BufferType::Input], &[16]);
        let a_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]); // Must match 16 bytes (4 f32s)
        let inputs: &[&[u8]] = &[&a_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(1);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Add {
            dst: 0,
            a: 0,
            b: 1, // Buffer 1 doesn't exist
            count: 2,
        };

        let result = instr.execute(&mut ctx);
        assert!(result.is_err());
    }

    // ========================================================================
    // Activation Functions Tests (TASK-042)
    // ========================================================================

    #[test]
    fn test_sigmoid_basic() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[16, 16]);
        let src_bytes = f32_to_bytes(&[0.0, 1.0, -1.0, 2.0]);
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Sigmoid {
            dst: 1,
            src: 0,
            count: 4,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();
        let output = bytes_to_f32(output_data, 4);

        // sigmoid(0) = 0.5 exactly
        assert!((output[0] - 0.5).abs() < 1e-6);
        // sigmoid(1) ≈ 0.7311
        assert!((output[1] - 0.7311).abs() < 1e-3);
        // sigmoid(-1) ≈ 0.2689
        assert!((output[2] - 0.2689).abs() < 1e-3);
    }

    #[test]
    fn test_tanh_basic() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[16, 16]);
        let src_bytes = f32_to_bytes(&[0.0, 1.0, -1.0, 0.5]);
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Tanh {
            dst: 1,
            src: 0,
            count: 4,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();
        let output = bytes_to_f32(output_data, 4);

        // tanh(0) = 0 exactly
        assert!(output[0].abs() < 1e-6);
        // tanh(1) ≈ 0.7616
        assert!((output[1] - 0.7616).abs() < 1e-3);
    }

    #[test]
    fn test_relu_basic() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[16, 16]);
        let src_bytes = f32_to_bytes(&[1.0, -1.0, 0.0, 5.0]);
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Relu {
            dst: 1,
            src: 0,
            count: 4,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();
        let output = bytes_to_f32(output_data, 4);

        assert!((output[0] - 1.0).abs() < 1e-6);
        assert!(output[1].abs() < 1e-6);
        assert!(output[2].abs() < 1e-6);
        assert!((output[3] - 5.0).abs() < 1e-6);
    }

    // ========================================================================
    // MatMul Tests (TASK-043)
    // ========================================================================

    #[test]
    fn test_matmul_2x2_basic() {
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[16, 16, 16],
        );
        // A = [[1,2],[3,4]], B = [[5,6],[7,8]]
        // C = [[19,22],[43,50]]
        let a_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
        let b_bytes = f32_to_bytes(&[5.0, 6.0, 7.0, 8.0]);
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::MatMul {
            c: 2,
            a: 0,
            b: 1,
            m: 2,
            k: 2,
            n: 2,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(2).unwrap();
        let output = bytes_to_f32(output_data, 4);

        let expected = [19.0, 22.0, 43.0, 50.0];
        for (a, b) in output.iter().zip(expected.iter()) {
            assert!((a - b).abs() < 1e-6);
        }
    }

    // ========================================================================
    // Reduction Operations Tests (TASK-044)
    // ========================================================================

    #[test]
    fn test_sum_basic() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[16, 4]);
        let src_bytes = f32_to_bytes(&[1.0, 2.0, 3.0, 4.0]);
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Sum {
            dst: 1,
            src: 0,
            count: 4,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();
        let output = bytes_to_f32(output_data, 1);

        assert!((output[0] - 10.0).abs() < 1e-6);
    }

    #[test]
    fn test_max_basic() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[16, 4]);
        let src_bytes = f32_to_bytes(&[1.0, 5.0, 3.0, 2.0]);
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Max {
            dst: 1,
            src: 0,
            count: 4,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();
        let output = bytes_to_f32(output_data, 1);

        assert!((output[0] - 5.0).abs() < 1e-6);
    }

    #[test]
    fn test_min_basic() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[16, 4]);
        let src_bytes = f32_to_bytes(&[1.0, 5.0, 3.0, 2.0]);
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Min {
            dst: 1,
            src: 0,
            count: 4,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();
        let output = bytes_to_f32(output_data, 1);

        assert!((output[0] - 1.0).abs() < 1e-6);
    }

    // ========================================================================
    // Memory Operations Tests (TASK-045)
    // ========================================================================

    #[test]
    fn test_copy_basic() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[8, 8]);
        let src_bytes = vec![1u8, 2, 3, 4, 5, 6, 7, 8];
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Copy {
            dst: 1,
            src: 0,
            size: 8,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();
        assert_eq!(output_data, &[1, 2, 3, 4, 5, 6, 7, 8]);
    }

    // ========================================================================
    // Remaining instruction tests (still unimplemented)
    // ========================================================================

    #[test]
    fn test_dispatch_call_layer_without_executor() {
        let metadata = vec![
            BufferMetadata::new(16, BufferType::Input),
            BufferMetadata::new(16, BufferType::Input),
            BufferMetadata::new(16, BufferType::Output),
        ];
        let buf_a = vec![0u8; 16];
        let buf_b = vec![0u8; 16];
        let input_slices: &[&[u8]] = &[&buf_a, &buf_b];
        let mut manager = BufferManager::new(&metadata, input_slices, &[]).unwrap();
        let node_map: Vec<Option<u32>> = vec![Some(0), Some(1), Some(2)];
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::CallLayer {
            layer_id: 12345,
            inputs: vec![0, 1],
            outputs: vec![2],
        };

        // Without a layer executor, CallLayer returns UnsupportedInstruction
        let result = instr.execute(&mut ctx);
        assert!(matches!(
            result,
            Err(BackendError::UnsupportedInstruction(_))
        ));
    }

    #[test]
    fn test_dispatch_call_layer_with_executor() {
        let metadata = vec![
            BufferMetadata::new(4, BufferType::Input),
            BufferMetadata::new(4, BufferType::Output),
        ];
        let input = vec![1u8, 2, 3, 4];
        let inputs: &[&[u8]] = &[&input];
        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map: Vec<Option<u32>> = vec![Some(0), Some(1)];

        // Create a simple layer executor that doubles all input bytes
        let mut executor =
            |_layer_id: u64, inputs: &[&[u8]], outputs: &mut [&mut [u8]]| -> Result<()> {
                if !inputs.is_empty() && !outputs.is_empty() {
                    for (i, &b) in inputs[0].iter().enumerate() {
                        if i < outputs[0].len() {
                            outputs[0][i] = b.wrapping_mul(2);
                        }
                    }
                }
                Ok(())
            };

        let mut ctx = ExecutionContext::with_layer_executor(&mut manager, &node_map, &mut executor);

        let instr = IsaInstruction::CallLayer {
            layer_id: 12345,
            inputs: vec![0],
            outputs: vec![1],
        };

        instr.execute(&mut ctx).unwrap();

        // Verify output was written (input bytes doubled)
        let output = ctx.read_buffer(1).unwrap();
        assert_eq!(&output[..4], &[2, 4, 6, 8]);
    }

    // ========================================================================
    // Categorical Operations Tests (TASK-059, TASK-060)
    // ========================================================================

    #[test]
    fn test_lift_basic() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[4, 8]);
        let src_bytes: Vec<u8> = vec![0, 1, 96, 255];
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Lift {
            dst: 1,
            src: 0,
            count: 4,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();

        // Verify torus coordinates (packed as little-endian u16)
        // byte 0: page = 0 / 8 = 0
        assert_eq!(output_data[0], 0); // offset = 0
        assert_eq!(output_data[1], 0); // page = 0

        // byte 1: page = 1 / 8 = 0
        assert_eq!(output_data[2], 1); // offset = 1
        assert_eq!(output_data[3], 0); // page = 0

        // byte 96: page = 96 / 8 = 12
        assert_eq!(output_data[4], 96); // offset = 96
        assert_eq!(output_data[5], 12); // page = 12

        // byte 255: page = 255 / 8 = 31
        assert_eq!(output_data[6], 255); // offset = 255
        assert_eq!(output_data[7], 31); // page = 31
    }

    #[test]
    fn test_lift_page_range() {
        // Verify all 32 pages are achievable
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[256, 512]);
        let src_bytes: Vec<u8> = (0..=255).collect();
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Lift {
            dst: 1,
            src: 0,
            count: 256,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();

        // Verify pages cover 0..31 (8 bytes per page)
        let mut pages_seen = [false; 32];
        for i in 0..256 {
            let page = output_data[i * 2 + 1];
            pages_seen[page as usize] = true;
        }

        for (i, &seen) in pages_seen.iter().enumerate() {
            assert!(seen, "Page {i} not seen");
        }
    }

    #[test]
    fn test_orbit_classify_basic() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[8, 8]);
        let src_bytes: Vec<u8> = vec![0, 7, 8, 15, 16, 31, 248, 255];
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::OrbitClassify {
            dst: 1,
            src: 0,
            count: 8,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();

        // Verify orbit classes: byte / 8
        assert_eq!(output_data[0], 0); // 0 / 8 = 0
        assert_eq!(output_data[1], 0); // 7 / 8 = 0
        assert_eq!(output_data[2], 1); // 8 / 8 = 1
        assert_eq!(output_data[3], 1); // 15 / 8 = 1
        assert_eq!(output_data[4], 2); // 16 / 8 = 2
        assert_eq!(output_data[5], 3); // 31 / 8 = 3
        assert_eq!(output_data[6], 31); // 248 / 8 = 31
        assert_eq!(output_data[7], 31); // 255 / 8 = 31
    }

    #[test]
    fn test_orbit_classify_partitions() {
        // Verify orbit classes partition bytes into 32 groups of 8
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[256, 256]);
        let src_bytes: Vec<u8> = (0..=255).collect();
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::OrbitClassify {
            dst: 1,
            src: 0,
            count: 256,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();

        // Count bytes in each orbit class
        let mut class_counts = [0usize; 32];
        for &class in output_data.iter().take(256) {
            assert!(class < 32, "Orbit class {class} out of range");
            class_counts[class as usize] += 1;
        }

        // Each class should have exactly 8 members
        for (i, &count) in class_counts.iter().enumerate() {
            assert_eq!(count, 8, "Orbit class {i} has {count} members, expected 8");
        }
    }

    #[test]
    fn test_lift_preserves_bijection() {
        // Each byte should map to a unique torus cell
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[256, 512]);
        let src_bytes: Vec<u8> = (0..=255).collect();
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Lift {
            dst: 1,
            src: 0,
            count: 256,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();

        // Collect all (page, offset) pairs
        let mut cells = std::collections::HashSet::new();
        for i in 0..256 {
            let offset = output_data[i * 2];
            let page = output_data[i * 2 + 1];
            let cell = (page, offset);
            assert!(cells.insert(cell), "Duplicate cell ({page}, {offset})");
        }

        // Should have 256 unique cells
        assert_eq!(cells.len(), 256);
    }

    // ========================================================================
    // Ring Operations Tests (TASK-061)
    // ========================================================================

    #[test]
    fn test_ring_add_basic() {
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[4, 4, 4],
        );
        let a_bytes: Vec<u8> = vec![10, 50, 95, 0];
        let b_bytes: Vec<u8> = vec![5, 50, 5, 96];
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::RingAdd {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(2).unwrap();

        // wrapping byte add
        assert_eq!(output_data[0], 15);
        assert_eq!(output_data[1], 100);
        assert_eq!(output_data[2], 100);
        assert_eq!(output_data[3], 96);
    }

    #[test]
    fn test_ring_mul_basic() {
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[4, 4, 4],
        );
        let a_bytes: Vec<u8> = vec![10, 12, 48, 1];
        let b_bytes: Vec<u8> = vec![5, 8, 2, 95];
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::RingMul {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(2).unwrap();

        // wrapping byte mul
        assert_eq!(output_data[0], 50);
        assert_eq!(output_data[1], 96);
        assert_eq!(output_data[2], 96);
        assert_eq!(output_data[3], 95);
    }

    #[test]
    fn test_ring_add_closure() {
        // Verify ring closure: result is always in [0, 95]
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[256, 256, 256],
        );
        let a_bytes: Vec<u8> = (0..=255).collect();
        let b_bytes: Vec<u8> = (0..=255).rev().collect();
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::RingAdd {
            dst: 2,
            a: 0,
            b: 1,
            count: 256,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(2).unwrap();

        // Wrapping byte add always remains in u8 range.
        for (i, &val) in output_data.iter().take(256).enumerate() {
            assert_eq!(val, a_bytes[i].wrapping_add(b_bytes[i]));
        }
    }

    #[test]
    fn test_ring_mul_closure() {
        // Verify ring closure: result is always in [0, 95]
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[256, 256, 256],
        );
        let a_bytes: Vec<u8> = (0..=255).collect();
        let b_bytes: Vec<u8> = (0..=255).rev().collect();
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::RingMul {
            dst: 2,
            a: 0,
            b: 1,
            count: 256,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(2).unwrap();

        // Wrapping byte mul always remains in u8 range.
        for (i, &val) in output_data.iter().take(256).enumerate() {
            assert_eq!(val, a_bytes[i].wrapping_mul(b_bytes[i]));
        }
    }

    #[test]
    #[allow(clippy::cast_possible_truncation)]
    fn test_ring_add_identity() {
        // Adding 0 should be identity
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[96, 96, 96],
        );
        let a_bytes: Vec<u8> = (0..96).collect();
        let b_bytes: Vec<u8> = vec![0; 96];
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::RingAdd {
            dst: 2,
            a: 0,
            b: 1,
            count: 96,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(2).unwrap();

        // a + 0 = a (mod 96)
        for (i, &val) in output_data.iter().enumerate().take(96) {
            assert_eq!(val, i as u8, "a + 0 != a at index {i}");
        }
    }

    #[test]
    #[allow(clippy::cast_possible_truncation)]
    fn test_ring_mul_identity() {
        // Multiplying by 1 should be identity
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Input, BufferType::Workspace],
            &[96, 96, 96],
        );
        let a_bytes: Vec<u8> = (0..96).collect();
        let b_bytes: Vec<u8> = vec![1; 96];
        let inputs: &[&[u8]] = &[&a_bytes, &b_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::RingMul {
            dst: 2,
            a: 0,
            b: 1,
            count: 96,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(2).unwrap();

        // a * 1 = a (mod 96)
        for (i, &val) in output_data.iter().enumerate().take(96) {
            assert_eq!(val, i as u8, "a * 1 != a at index {i}");
        }
    }

    // ========================================================================
    // Codec Operations Tests (TASK-089)
    // ========================================================================

    #[test]
    fn test_encode_binary_identity() {
        // Binary codec is identity transform
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[8, 8]);
        let src_bytes: Vec<u8> = vec![1, 2, 3, 4, 5, 6, 7, 8];
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Encode {
            dst: 1,
            src: 0,
            codec_id: 0, // binary
            count: 8,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();
        assert_eq!(&output_data[..8], &src_bytes);
    }

    #[test]
    fn test_decode_binary_identity() {
        // Binary codec decode is also identity
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[8, 8]);
        let src_bytes: Vec<u8> = vec![1, 2, 3, 4, 5, 6, 7, 8];
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Decode {
            dst: 1,
            src: 0,
            codec_id: 0, // binary
            count: 8,
        };

        instr.execute(&mut ctx).unwrap();
        let output_data = ctx.read_buffer(1).unwrap();
        assert_eq!(&output_data[..8], &src_bytes);
    }

    #[test]
    fn test_encode_decode_decimal_roundtrip() {
        // Encode then decode should return original data
        let src_bytes: Vec<u8> = vec![1, 2, 3, 4]; // No leading zeros

        // Get actual encoded length by calling codec directly
        let codec = crate::codec::get_codec(1).unwrap(); // decimal
        let expected_encoded = codec.encode(&src_bytes).unwrap();
        let encoded_len = expected_encoded.len();

        let metadata = make_metadata(
            &[
                BufferType::Input,
                BufferType::Workspace,
                BufferType::Workspace,
            ],
            &[4, 16, 4], // workspace needs more space for decimal digits
        );
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        // Encode
        let encode_instr = IsaInstruction::Encode {
            dst: 1,
            src: 0,
            codec_id: 1, // decimal
            count: 4,
        };
        encode_instr.execute(&mut ctx).unwrap();

        // Decode using actual encoded length
        let decode_instr = IsaInstruction::Decode {
            dst: 2,
            src: 1,
            codec_id: 1, // decimal
            count: encoded_len,
        };
        decode_instr.execute(&mut ctx).unwrap();

        let decoded = ctx.read_buffer(2).unwrap();
        assert_eq!(&decoded[..4], &src_bytes);
    }

    #[test]
    fn test_encode_invalid_codec_id() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[4, 16]);
        let src_bytes: Vec<u8> = vec![1, 2, 3, 4];
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Encode {
            dst: 1,
            src: 0,
            codec_id: 100, // Invalid
            count: 4,
        };

        let result = instr.execute(&mut ctx);
        assert!(result.is_err());
        assert!(matches!(
            result,
            Err(BackendError::UnsupportedInstruction(_))
        ));
    }

    #[test]
    fn test_decode_invalid_codec_id() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[4, 16]);
        let src_bytes: Vec<u8> = vec![1, 2, 3, 4];
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Decode {
            dst: 1,
            src: 0,
            codec_id: 255, // Invalid
            count: 4,
        };

        let result = instr.execute(&mut ctx);
        assert!(result.is_err());
    }

    #[test]
    fn test_encode_insufficient_source_buffer() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Workspace], &[4, 16]);
        let src_bytes: Vec<u8> = vec![1, 2, 3, 4];
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let instr = IsaInstruction::Encode {
            dst: 1,
            src: 0,
            codec_id: 1,
            count: 100, // More than buffer has
        };

        let result = instr.execute(&mut ctx);
        assert!(result.is_err());
        assert!(matches!(result, Err(BackendError::SizeMismatch { .. })));
    }

    #[test]
    fn test_encode_decode_hexadecimal_roundtrip() {
        let src_bytes: Vec<u8> = vec![0xDE, 0xAD, 0xBE, 0xEF];

        // Get actual encoded length by calling codec directly
        let codec = crate::codec::get_codec(2).unwrap(); // hexadecimal
        let expected_encoded = codec.encode(&src_bytes).unwrap();
        let encoded_len = expected_encoded.len();

        let metadata = make_metadata(
            &[
                BufferType::Input,
                BufferType::Workspace,
                BufferType::Workspace,
            ],
            &[4, 16, 4],
        );
        let inputs: &[&[u8]] = &[&src_bytes];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        // Encode to hex
        let encode_instr = IsaInstruction::Encode {
            dst: 1,
            src: 0,
            codec_id: 2, // hexadecimal
            count: 4,
        };
        encode_instr.execute(&mut ctx).unwrap();

        // Decode from hex using actual encoded length
        let decode_instr = IsaInstruction::Decode {
            dst: 2,
            src: 1,
            codec_id: 2,
            count: encoded_len,
        };
        decode_instr.execute(&mut ctx).unwrap();

        let decoded = ctx.read_buffer(2).unwrap();
        assert_eq!(&decoded[..4], &src_bytes);
    }

    #[test]
    fn test_all_codecs_roundtrip() {
        // Test all 5 codecs with roundtrip.
        // We call the codec directly to get the actual encoded length, since
        // the buffer system doesn't track written length (just capacity).
        let src_bytes: Vec<u8> = vec![1, 2, 3, 4]; // No leading zeros

        for codec_id in 0..5u32 {
            // Get actual encoded length by calling codec directly
            let codec = crate::codec::get_codec(codec_id).unwrap();
            let expected_encoded = codec.encode(&src_bytes).unwrap();
            let encoded_len = expected_encoded.len();

            let metadata = make_metadata(
                &[
                    BufferType::Input,
                    BufferType::Workspace,
                    BufferType::Workspace,
                ],
                &[4, 64, 4], // Large workspace for various encodings
            );
            let inputs: &[&[u8]] = &[&src_bytes];

            let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
            let node_map = make_node_map(3);
            let mut ctx = ExecutionContext::new(&mut manager, &node_map);

            // Encode
            let encode_instr = IsaInstruction::Encode {
                dst: 1,
                src: 0,
                codec_id,
                count: 4,
            };
            encode_instr
                .execute(&mut ctx)
                .unwrap_or_else(|e| panic!("Encode failed for codec {codec_id}: {e}"));

            // Verify encoded data matches expected
            let encoded_buf = ctx.read_buffer(1).unwrap();
            assert_eq!(
                &encoded_buf[..encoded_len],
                &expected_encoded,
                "Encoded data mismatch for codec {codec_id}"
            );

            // Decode using actual encoded length
            let decode_instr = IsaInstruction::Decode {
                dst: 2,
                src: 1,
                codec_id,
                count: encoded_len,
            };
            decode_instr
                .execute(&mut ctx)
                .unwrap_or_else(|e| panic!("Decode failed for codec {codec_id}: {e}"));

            let decoded = ctx.read_buffer(2).unwrap();
            assert_eq!(
                &decoded[..4],
                &src_bytes,
                "Roundtrip failed for codec {codec_id}"
            );
        }
    }

    // ========================================================================
    // CNN Operations Tests (Bug Fix Validation)
    // ========================================================================

    #[test]
    fn test_conv2d_produces_nonzero_output() {
        // Input: 1x1x4x4 (16 elements), all 1.0
        // Weight: 1x1x3x3 (9 elements), all 1.0
        // Output: 1x1x2x2 (4 elements)
        // Expected: each output = sum of 9 ones = 9.0

        let input_data: Vec<f32> = vec![1.0; 16];
        let weight_data: Vec<f32> = vec![1.0; 9];

        let input_bytes = f32_to_bytes(&input_data);
        let weight_bytes = f32_to_bytes(&weight_data);

        let metadata = make_metadata(
            &[
                BufferType::Input,
                BufferType::Constant,
                BufferType::Workspace,
            ],
            &[64, 36, 16], // 16*4, 9*4, 4*4 bytes
        );

        let inputs: &[&[u8]] = &[&input_bytes];
        let mut manager = BufferManager::new(&metadata, inputs, &weight_bytes).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let result = IsaInstruction::Conv2d {
            dst: 2,
            input: 0,
            weight: 1,
            bias: None,
            kernel_h: 3,
            kernel_w: 3,
            stride_h: 1,
            stride_w: 1,
            pad_h: 0,
            pad_w: 0,
            dilation_h: 1,
            dilation_w: 1,
            groups: 1,
            batch: 1,
            in_channels: 1,
            out_channels: 1,
            in_h: 4,
            in_w: 4,
            out_h: 2,
            out_w: 2,
        }
        .execute(&mut ctx);
        assert!(result.is_ok(), "Conv2d should succeed: {result:?}");

        let output = bytes_to_f32(ctx.read_buffer(2).unwrap(), 4);

        // Each output should be 9.0 (sum of 3x3 window of 1.0s)
        for (i, &val) in output.iter().enumerate() {
            assert!(
                (val - 9.0).abs() < 1e-5,
                "output[{i}] = {val}, expected 9.0"
            );
        }
    }

    #[test]
    fn test_conv2d_with_specific_values() {
        // Test with specific input values to verify correct convolution
        // Input: 4x4 with values 1..16
        // Weight: 3x3 all ones
        // Output positions calculated manually

        let input_data: Vec<f32> = (1..=16).map(|i| i as f32).collect();
        let weight_data: Vec<f32> = vec![1.0; 9];

        let input_bytes = f32_to_bytes(&input_data);
        let weight_bytes = f32_to_bytes(&weight_data);

        let metadata = make_metadata(
            &[
                BufferType::Input,
                BufferType::Constant,
                BufferType::Workspace,
            ],
            &[64, 36, 16],
        );

        let inputs: &[&[u8]] = &[&input_bytes];
        let mut manager = BufferManager::new(&metadata, inputs, &weight_bytes).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        IsaInstruction::Conv2d {
            dst: 2,
            input: 0,
            weight: 1,
            bias: None,
            kernel_h: 3,
            kernel_w: 3,
            stride_h: 1,
            stride_w: 1,
            pad_h: 0,
            pad_w: 0,
            dilation_h: 1,
            dilation_w: 1,
            groups: 1,
            batch: 1,
            in_channels: 1,
            out_channels: 1,
            in_h: 4,
            in_w: 4,
            out_h: 2,
            out_w: 2,
        }
        .execute(&mut ctx)
        .unwrap();

        let output = bytes_to_f32(ctx.read_buffer(2).unwrap(), 4);

        // Input layout (4x4):
        //  1  2  3  4
        //  5  6  7  8
        //  9 10 11 12
        // 13 14 15 16
        //
        // Output[0,0] = sum of 3x3 at (0,0) = 1+2+3+5+6+7+9+10+11 = 54
        // Output[0,1] = sum of 3x3 at (0,1) = 2+3+4+6+7+8+10+11+12 = 63
        // Output[1,0] = sum of 3x3 at (1,0) = 5+6+7+9+10+11+13+14+15 = 90
        // Output[1,1] = sum of 3x3 at (1,1) = 6+7+8+10+11+12+14+15+16 = 99

        assert!((output[0] - 54.0).abs() < 1e-5, "output[0] = {}", output[0]);
        assert!((output[1] - 63.0).abs() < 1e-5, "output[1] = {}", output[1]);
        assert!((output[2] - 90.0).abs() < 1e-5, "output[2] = {}", output[2]);
        assert!((output[3] - 99.0).abs() < 1e-5, "output[3] = {}", output[3]);
    }

    #[test]
    fn test_batch_norm_produces_nonzero_output() {
        // BatchNorm test: verify non-zero output with constant scale=1, bias=0, mean=0, var=1
        // This simplifies to: output = input (identity transform)

        let input_data: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0];
        let scale_data: Vec<f32> = vec![1.0]; // scale for 1 channel
        let bias_data: Vec<f32> = vec![0.0]; // bias for 1 channel
        let mean_data: Vec<f32> = vec![0.0]; // mean for 1 channel
        let var_data: Vec<f32> = vec![1.0]; // var for 1 channel

        let input_bytes = f32_to_bytes(&input_data);
        let scale_bytes = f32_to_bytes(&scale_data);
        let bias_bytes = f32_to_bytes(&bias_data);
        let mean_bytes = f32_to_bytes(&mean_data);
        let var_bytes = f32_to_bytes(&var_data);

        // Constants: scale, bias, mean, var (each 4 bytes = 1 f32)
        let mut constants = scale_bytes.clone();
        constants.extend_from_slice(&bias_bytes);
        constants.extend_from_slice(&mean_bytes);
        constants.extend_from_slice(&var_bytes);

        let metadata = make_metadata(
            &[
                BufferType::Input,     // input: 4 f32 = 16 bytes
                BufferType::Constant,  // scale: 1 f32 = 4 bytes
                BufferType::Constant,  // bias: 1 f32 = 4 bytes
                BufferType::Constant,  // mean: 1 f32 = 4 bytes
                BufferType::Constant,  // var: 1 f32 = 4 bytes
                BufferType::Workspace, // output: 4 f32 = 16 bytes
            ],
            &[16, 4, 4, 4, 4, 16],
        );

        let inputs: &[&[u8]] = &[&input_bytes];
        let mut manager = BufferManager::new(&metadata, inputs, &constants).unwrap();
        let node_map = make_node_map(6);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let result = IsaInstruction::BatchNorm {
            dst: 5,
            input: 0,
            scale: 1,
            bias: 2,
            mean: 3,
            var: 4,
            epsilon: 1e-5,
            batch: 1,
            channels: 1,
            spatial: 4,
        }
        .execute(&mut ctx);
        assert!(result.is_ok(), "BatchNorm should succeed: {:?}", result);

        let output = bytes_to_f32(ctx.read_buffer(5).unwrap(), 4);

        // With scale=1, bias=0, mean=0, var=1, epsilon small:
        // output = (input - 0) / sqrt(1 + 1e-5) * 1 + 0 ≈ input
        for (i, (&out, &inp)) in output.iter().zip(input_data.iter()).enumerate() {
            assert!(
                (out - inp).abs() < 0.01,
                "output[{}] = {}, expected ~{}",
                i,
                out,
                inp
            );
        }
    }

    #[test]
    fn test_max_pool2d_produces_nonzero_output() {
        // MaxPool test: 4x4 input, 2x2 pool, stride 2 -> 2x2 output

        let input_data: Vec<f32> = (1..=16).map(|i| i as f32).collect();
        let input_bytes = f32_to_bytes(&input_data);

        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Workspace],
            &[64, 16], // 16 f32 input, 4 f32 output
        );

        let inputs: &[&[u8]] = &[&input_bytes];
        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let result = IsaInstruction::MaxPool2d {
            dst: 1,
            src: 0,
            kernel_h: 2,
            kernel_w: 2,
            stride_h: 2,
            stride_w: 2,
            pad_h: 0,
            pad_w: 0,
            batch: 1,
            channels: 1,
            in_h: 4,
            in_w: 4,
            out_h: 2,
            out_w: 2,
        }
        .execute(&mut ctx);
        assert!(result.is_ok(), "MaxPool2d should succeed: {:?}", result);

        let output = bytes_to_f32(ctx.read_buffer(1).unwrap(), 4);

        // Input layout (4x4):
        //  1  2  3  4
        //  5  6  7  8
        //  9 10 11 12
        // 13 14 15 16
        //
        // Output[0,0] = max(1,2,5,6) = 6
        // Output[0,1] = max(3,4,7,8) = 8
        // Output[1,0] = max(9,10,13,14) = 14
        // Output[1,1] = max(11,12,15,16) = 16

        assert!((output[0] - 6.0).abs() < 1e-5, "output[0] = {}", output[0]);
        assert!((output[1] - 8.0).abs() < 1e-5, "output[1] = {}", output[1]);
        assert!((output[2] - 14.0).abs() < 1e-5, "output[2] = {}", output[2]);
        assert!((output[3] - 16.0).abs() < 1e-5, "output[3] = {}", output[3]);
    }

    #[test]
    fn test_global_avg_pool_produces_nonzero_output() {
        // GlobalAvgPool test: average all spatial elements per channel

        let input_data: Vec<f32> = (1..=16).map(|i| i as f32).collect();
        let input_bytes = f32_to_bytes(&input_data);

        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Workspace],
            &[64, 4], // 16 f32 input, 1 f32 output
        );

        let inputs: &[&[u8]] = &[&input_bytes];
        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let result = IsaInstruction::GlobalAvgPool {
            dst: 1,
            src: 0,
            batch: 1,
            channels: 1,
            spatial: 16,
        }
        .execute(&mut ctx);
        assert!(result.is_ok(), "GlobalAvgPool should succeed: {:?}", result);

        let output = bytes_to_f32(ctx.read_buffer(1).unwrap(), 1);

        // Average of 1..16 = (1+2+...+16)/16 = 136/16 = 8.5
        assert!(
            (output[0] - 8.5).abs() < 1e-5,
            "output[0] = {}, expected 8.5",
            output[0]
        );
    }

    #[test]
    fn test_avg_pool2d_produces_correct_output() {
        // AvgPool2d test: 2x2 kernel, stride 2 on 4x4 input
        // Input: [1, 1, 4, 4] -> Output: [1, 1, 2, 2]

        let input_data: Vec<f32> = (1..=16).map(|i| i as f32).collect();
        let input_bytes = f32_to_bytes(&input_data);

        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Workspace],
            &[64, 16], // 16 f32 input, 4 f32 output
        );

        let inputs: &[&[u8]] = &[&input_bytes];
        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map = make_node_map(2);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let result = IsaInstruction::AvgPool2d {
            dst: 1,
            src: 0,
            kernel_h: 2,
            kernel_w: 2,
            stride_h: 2,
            stride_w: 2,
            pad_h: 0,
            pad_w: 0,
            batch: 1,
            channels: 1,
            in_h: 4,
            in_w: 4,
            out_h: 2,
            out_w: 2,
        }
        .execute(&mut ctx);
        assert!(result.is_ok(), "AvgPool2d should succeed: {:?}", result);

        let output = bytes_to_f32(ctx.read_buffer(1).unwrap(), 4);

        // Input layout (4x4):
        //  1  2  3  4
        //  5  6  7  8
        //  9 10 11 12
        // 13 14 15 16
        //
        // AvgPool 2x2 with stride 2:
        // output[0,0] = mean(1,2,5,6) = 3.5
        // output[0,1] = mean(3,4,7,8) = 5.5
        // output[1,0] = mean(9,10,13,14) = 11.5
        // output[1,1] = mean(11,12,15,16) = 13.5

        assert!((output[0] - 3.5).abs() < 1e-5, "output[0] = {}", output[0]);
        assert!((output[1] - 5.5).abs() < 1e-5, "output[1] = {}", output[1]);
        assert!((output[2] - 11.5).abs() < 1e-5, "output[2] = {}", output[2]);
        assert!((output[3] - 13.5).abs() < 1e-5, "output[3] = {}", output[3]);
    }

    // ========================================================================
    // Bug Report Test Cases - All Constant Buffers
    // Tests from hologram-ai-onnx team bug report (2026-02-02)
    // ========================================================================

    #[test]
    fn test_add_with_constants_baseline() {
        // Baseline test: proves constants work with basic ops
        let a: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0];
        let b: Vec<f32> = vec![0.1, 0.2, 0.3, 0.4];

        let a_bytes: Vec<u8> = a.iter().flat_map(|f| f.to_ne_bytes()).collect();
        let b_bytes: Vec<u8> = b.iter().flat_map(|f| f.to_ne_bytes()).collect();

        let mut constants = a_bytes;
        constants.extend_from_slice(&b_bytes);

        let metadata = make_metadata(
            &[
                BufferType::Constant,  // buffer 0 - a
                BufferType::Constant,  // buffer 1 - b
                BufferType::Workspace, // buffer 2 - output
            ],
            &[16, 16, 16], // 4*4 bytes each
        );

        let inputs: &[&[u8]] = &[];
        let mut manager = BufferManager::new(&metadata, inputs, &constants).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let result = IsaInstruction::Add {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        }
        .execute(&mut ctx);
        assert!(result.is_ok());

        let output = bytes_to_f32(ctx.read_buffer(2).unwrap(), 4);

        // Should be [1.1, 2.2, 3.3, 4.4]
        assert!(
            (output[0] - 1.1).abs() < 0.01,
            "Add baseline output[0] = {}, expected 1.1",
            output[0]
        );
        assert!(
            (output[1] - 2.2).abs() < 0.01,
            "Add baseline output[1] = {}, expected 2.2",
            output[1]
        );
    }

    #[test]
    fn test_conv2d_all_constants_produces_nonzero_output() {
        // Bug report test: Conv2d with all-constant buffers
        // Simple 1-channel conv: [1,1,4,4] input * [1,1,3,3] weight -> [1,1,2,2] output
        // Input: 1..16, Weight: all 1.0
        // Expected output: sums of 3x3 regions = [54, 63, 90, 99]

        let input_data: Vec<f32> = (1..=16).map(|i| i as f32).collect();
        let weight_data: Vec<f32> = vec![1.0; 9];

        let input_bytes: Vec<u8> = input_data.iter().flat_map(|f| f.to_ne_bytes()).collect();
        let weight_bytes: Vec<u8> = weight_data.iter().flat_map(|f| f.to_ne_bytes()).collect();

        let mut constants = input_bytes;
        constants.extend_from_slice(&weight_bytes);

        // Buffer 0: Input [1,1,4,4] (constant) - 16 * 4 = 64 bytes
        // Buffer 1: Weight [1,1,3,3] (constant) - 9 * 4 = 36 bytes
        // Buffer 2: Output [1,1,2,2] (workspace) - 4 * 4 = 16 bytes
        let metadata = make_metadata(
            &[
                BufferType::Constant,  // buffer 0 - input
                BufferType::Constant,  // buffer 1 - weight
                BufferType::Workspace, // buffer 2 - output
            ],
            &[64, 36, 16],
        );

        let inputs: &[&[u8]] = &[];
        let mut manager = BufferManager::new(&metadata, inputs, &constants).unwrap();
        let node_map = make_node_map(3);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let result = IsaInstruction::Conv2d {
            dst: 2,
            input: 0,
            weight: 1,
            bias: None,
            kernel_h: 3,
            kernel_w: 3,
            stride_h: 1,
            stride_w: 1,
            pad_h: 0,
            pad_w: 0,
            dilation_h: 1,
            dilation_w: 1,
            groups: 1,
            batch: 1,
            in_channels: 1,
            out_channels: 1,
            in_h: 4,
            in_w: 4,
            out_h: 2,
            out_w: 2,
        }
        .execute(&mut ctx);
        assert!(result.is_ok(), "Conv2d dispatch failed: {:?}", result);

        let output = bytes_to_f32(ctx.read_buffer(2).unwrap(), 4);

        // With all-ones 3x3 kernel and no padding:
        // output[0,0] = sum of input[0:3, 0:3] = 1+2+3+5+6+7+9+10+11 = 54
        // output[0,1] = sum of input[0:3, 1:4] = 2+3+4+6+7+8+10+11+12 = 63
        // output[1,0] = sum of input[1:4, 0:3] = 5+6+7+9+10+11+13+14+15 = 90
        // output[1,1] = sum of input[1:4, 1:4] = 6+7+8+10+11+12+14+15+16 = 99

        assert!(
            output[0] != 0.0,
            "Conv2d output[0] should be non-zero, got {}",
            output[0]
        );
        assert!(
            (output[0] - 54.0).abs() < 1e-5,
            "Conv2d output[0] = {}, expected 54.0",
            output[0]
        );
        assert!(
            (output[1] - 63.0).abs() < 1e-5,
            "Conv2d output[1] = {}, expected 63.0",
            output[1]
        );
        assert!(
            (output[2] - 90.0).abs() < 1e-5,
            "Conv2d output[2] = {}, expected 90.0",
            output[2]
        );
        assert!(
            (output[3] - 99.0).abs() < 1e-5,
            "Conv2d output[3] = {}, expected 99.0",
            output[3]
        );
    }

    #[test]
    fn test_batch_norm_all_constants_produces_nonzero_output() {
        // Bug report test: BatchNorm with all-constant buffers
        // BatchNorm: output = (input - mean) / sqrt(var + eps) * scale + bias
        // With mean=0, var=1, scale=1, bias=0: output = input (identity)

        let input: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0]; // [1, 1, 2, 2] = 4 elements
        let scale: Vec<f32> = vec![1.0]; // [1] channel
        let bias: Vec<f32> = vec![0.0];
        let mean: Vec<f32> = vec![0.0];
        let var: Vec<f32> = vec![1.0];

        let mut constants = Vec::new();
        constants.extend(input.iter().flat_map(|f| f.to_ne_bytes()));
        constants.extend(scale.iter().flat_map(|f| f.to_ne_bytes()));
        constants.extend(bias.iter().flat_map(|f| f.to_ne_bytes()));
        constants.extend(mean.iter().flat_map(|f| f.to_ne_bytes()));
        constants.extend(var.iter().flat_map(|f| f.to_ne_bytes()));

        // Buffers: input, scale, bias, mean, var, output
        let metadata = make_metadata(
            &[
                BufferType::Constant,  // 0: input [1,1,2,2]
                BufferType::Constant,  // 1: scale [1]
                BufferType::Constant,  // 2: bias [1]
                BufferType::Constant,  // 3: mean [1]
                BufferType::Constant,  // 4: var [1]
                BufferType::Workspace, // 5: output [1,1,2,2]
            ],
            &[16, 4, 4, 4, 4, 16],
        );

        let inputs: &[&[u8]] = &[];
        let mut manager = BufferManager::new(&metadata, inputs, &constants).unwrap();
        let node_map = make_node_map(6);
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        let result = IsaInstruction::BatchNorm {
            dst: 5,
            input: 0,
            scale: 1,
            bias: 2,
            mean: 3,
            var: 4,
            epsilon: 1e-5,
            batch: 1,
            channels: 1,
            spatial: 4,
        }
        .execute(&mut ctx);
        assert!(result.is_ok(), "BatchNorm dispatch failed: {:?}", result);

        let output = bytes_to_f32(ctx.read_buffer(5).unwrap(), 4);

        // With identity params, output should equal input
        assert!(
            (output[0] - 1.0).abs() < 0.01,
            "BatchNorm output[0] = {}, expected ~1.0",
            output[0]
        );
        assert!(
            (output[1] - 2.0).abs() < 0.01,
            "BatchNorm output[1] = {}, expected ~2.0",
            output[1]
        );
        assert!(
            (output[2] - 3.0).abs() < 0.01,
            "BatchNorm output[2] = {}, expected ~3.0",
            output[2]
        );
        assert!(
            (output[3] - 4.0).abs() < 0.01,
            "BatchNorm output[3] = {}, expected ~4.0",
            output[3]
        );
    }

    // ========================================================================
    // LUT Fusion Tests (TASK-286)
    // ========================================================================

    #[test]
    fn test_compose_luts_identity() {
        // Composing relu(sigmoid(x)) should match manual computation
        let composed = compose_luts(&SIGMOID_256, &RELU_256);
        for i in 0u8..=255 {
            let expected = relu_lut(sigmoid_lut(i));
            assert_eq!(composed[i as usize], expected, "mismatch at i={i}");
        }
    }

    #[test]
    fn test_compose_three_luts() {
        // relu(tanh(sigmoid(x)))
        let step1 = compose_luts(&SIGMOID_256, &TANH_256);
        let step2 = compose_luts(&step1, &RELU_256);
        for i in 0u8..=255 {
            let expected = relu_lut(tanh_lut(sigmoid_lut(i)));
            assert_eq!(step2[i as usize], expected, "mismatch at i={i}");
        }
    }

    #[test]
    fn test_fusion_cache_compose_chain() {
        let mut cache = LutFusionCache::new();
        let chain = vec![LutId::Sigmoid, LutId::Tanh, LutId::Relu];
        let table = cache.get_or_compose(&chain);
        for i in 0u8..=255 {
            let expected = relu_lut(tanh_lut(sigmoid_lut(i)));
            assert_eq!(table[i as usize], expected, "mismatch at i={i}");
        }
    }

    #[test]
    fn test_fusion_cache_caches_result() {
        let mut cache = LutFusionCache::new();
        let chain = vec![LutId::Sigmoid, LutId::Tanh];
        let t1 = *cache.get_or_compose(&chain);
        let t2 = *cache.get_or_compose(&chain);
        assert_eq!(t1, t2, "cached table should be identical");
    }

    #[test]
    fn test_extract_lut_sigmoid() {
        let instr = IsaInstruction::SigmoidLUT {
            dst: 1,
            src: 0,
            count: 256,
        };
        let result = extract_lut(&instr);
        assert_eq!(result, Some((LutId::Sigmoid, 1, 0, 256)));
    }

    #[test]
    fn test_extract_lut_non_lut() {
        let instr = IsaInstruction::Add {
            dst: 1,
            a: 0,
            b: 2,
            count: 4,
        };
        assert!(extract_lut(&instr).is_none());
    }

    #[test]
    fn test_scan_lut_chain_two() {
        let instructions = vec![
            IsaInstruction::SigmoidLUT {
                dst: 1,
                src: 0,
                count: 64,
            },
            IsaInstruction::TanhLUT {
                dst: 1,
                src: 1,
                count: 64,
            },
        ];
        let result = scan_lut_chain(&instructions, 0);
        let (chain, dst, src, count, consumed) = result.unwrap();
        assert_eq!(chain, vec![LutId::Sigmoid, LutId::Tanh]);
        assert_eq!(dst, 1);
        assert_eq!(src, 0);
        assert_eq!(count, 64);
        assert_eq!(consumed, 2);
    }

    #[test]
    fn test_scan_lut_chain_three() {
        let instructions = vec![
            IsaInstruction::SigmoidLUT {
                dst: 1,
                src: 0,
                count: 128,
            },
            IsaInstruction::TanhLUT {
                dst: 1,
                src: 1,
                count: 128,
            },
            IsaInstruction::ReluLUT {
                dst: 2,
                src: 1,
                count: 128,
            },
        ];
        let result = scan_lut_chain(&instructions, 0);
        let (chain, dst, src, count, consumed) = result.unwrap();
        assert_eq!(chain, vec![LutId::Sigmoid, LutId::Tanh, LutId::Relu]);
        assert_eq!(dst, 2);
        assert_eq!(src, 0);
        assert_eq!(count, 128);
        assert_eq!(consumed, 3);
    }

    #[test]
    fn test_scan_lut_chain_broken_by_non_lut() {
        let instructions = vec![
            IsaInstruction::SigmoidLUT {
                dst: 1,
                src: 0,
                count: 64,
            },
            IsaInstruction::Add {
                dst: 1,
                a: 0,
                b: 2,
                count: 4,
            },
            IsaInstruction::TanhLUT {
                dst: 1,
                src: 1,
                count: 64,
            },
        ];
        // Should not fuse across the Add
        assert!(scan_lut_chain(&instructions, 0).is_none());
    }

    #[test]
    fn test_scan_lut_chain_broken_by_count_mismatch() {
        let instructions = vec![
            IsaInstruction::SigmoidLUT {
                dst: 1,
                src: 0,
                count: 64,
            },
            IsaInstruction::TanhLUT {
                dst: 1,
                src: 1,
                count: 32, // Different count!
            },
        ];
        assert!(scan_lut_chain(&instructions, 0).is_none());
    }

    #[test]
    fn test_scan_lut_chain_single_lut() {
        let instructions = vec![IsaInstruction::SigmoidLUT {
            dst: 1,
            src: 0,
            count: 64,
        }];
        // Single LUT instruction — no chain to fuse
        assert!(scan_lut_chain(&instructions, 0).is_none());
    }

    #[test]
    fn test_exec_fused_lut_chain_end_to_end() {
        // Set up: buffer 0 = input (u8 data), buffer 1 = output
        let metadata = vec![
            BufferMetadata::new(8, BufferType::Input),
            BufferMetadata::new(8, BufferType::Workspace),
        ];
        let input_data: Vec<u8> = vec![0, 32, 64, 128, 192, 224, 255, 100];
        let inputs: &[&[u8]] = &[&input_data];
        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();
        let node_map: Vec<Option<u32>> = vec![Some(0), Some(1)];
        let mut ctx = ExecutionContext::new(&mut manager, &node_map);

        // Compose sigmoid → tanh table
        let table = compose_luts(&SIGMOID_256, &TANH_256);
        exec_fused_lut_chain(&mut ctx, 1, 0, 8, &table).unwrap();

        // Verify: each output byte = tanh(sigmoid(input))
        let output = ctx.read_buffer(1).unwrap();
        for i in 0..8 {
            let expected = tanh_lut(sigmoid_lut(input_data[i]));
            assert_eq!(output[i], expected, "mismatch at i={i}");
        }
    }
}
