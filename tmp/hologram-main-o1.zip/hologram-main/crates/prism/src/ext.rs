//! Extension framework for user-defined operations.
//!
//! Provides the [`define_op!`] and [`define_binary_op!`] macros for
//! creating custom operations with mandatory conformance targets.
//!
//! # Example
//!
//! ```
//! use prism::state::State;
//! use prism::ops::{ConformanceTargets, Operation};
//! use prism::define_op;
//!
//! define_op!(DoubleNot, min = 5, opt = 3, theo = 1, |state: State| -> State {
//!     let mut s = state;
//!     for b in s.as_bytes_mut() {
//!         *b = !*b;
//!     }
//!     for b in s.as_bytes_mut() {
//!         *b = !*b;
//!     }
//!     s
//! });
//!
//! let op = DoubleNot;
//! let s = State::zeros();
//! assert_eq!(op.apply(s), s);
//! ```

/// Define a unary [`Operation`](crate::ops::Operation) struct with conformance targets.
///
/// # Syntax
///
/// ```ignore
/// define_op!(Name, min = MIN, opt = OPT, theo = THEO, |state: State| -> State { body });
/// ```
///
/// Generates a zero-sized struct `Name` implementing `Operation` with the
/// given targets and closure body.
///
/// # Example
///
/// ```
/// use prism::state::State;
/// use prism::ops::Operation;
/// use prism::define_op;
///
/// define_op!(Identity, min = 5, opt = 3, theo = 1, |state: State| -> State {
///     state
/// });
///
/// let result = Identity.apply(State::zeros());
/// assert_eq!(result, State::zeros());
/// ```
#[macro_export]
macro_rules! define_op {
    ($name:ident, min = $min:expr, opt = $opt:expr, theo = $theo:expr,
     |$param:ident : State| -> State $body:block) => {
        /// User-defined operation.
        pub struct $name;

        impl $crate::ops::Operation for $name {
            const NAME: &'static str = stringify!($name);
            const TARGETS: $crate::ops::ConformanceTargets = $crate::ops::ConformanceTargets {
                minimum: $min,
                optimal: $opt,
                theoretical: $theo,
            };

            fn apply(&self, $param: $crate::state::State) -> $crate::state::State {
                $body
            }
        }
    };
}

/// Define a binary [`BinaryOperation`](crate::ops::BinaryOperation) struct with conformance targets.
///
/// # Syntax
///
/// ```ignore
/// define_binary_op!(Name, min = MIN, opt = OPT, theo = THEO,
///     |a: State, b: State| -> State { body });
/// ```
///
/// # Example
///
/// ```
/// use prism::state::State;
/// use prism::ops::BinaryOperation;
/// use prism::define_binary_op;
///
/// define_binary_op!(SelectA, min = 3, opt = 2, theo = 1,
///     |a: State, _b: State| -> State { a });
///
/// let result = SelectA.apply(State::ones(), State::zeros());
/// assert_eq!(result, State::ones());
/// ```
#[macro_export]
macro_rules! define_binary_op {
    ($name:ident, min = $min:expr, opt = $opt:expr, theo = $theo:expr,
     |$a:ident : State, $b:ident : State| -> State $body:block) => {
        /// User-defined binary operation.
        pub struct $name;

        impl $crate::ops::BinaryOperation for $name {
            const NAME: &'static str = stringify!($name);
            const TARGETS: $crate::ops::ConformanceTargets = $crate::ops::ConformanceTargets {
                minimum: $min,
                optimal: $opt,
                theoretical: $theo,
            };

            fn apply(
                &self,
                $a: $crate::state::State,
                $b: $crate::state::State,
            ) -> $crate::state::State {
                $body
            }
        }
    };
}

#[cfg(test)]
mod tests {
    use crate::ops::{BinaryOperation, Operation};
    use crate::state::State;

    define_op!(
        TestIdentity,
        min = 5,
        opt = 3,
        theo = 1,
        |state: State| -> State { state }
    );

    define_binary_op!(TestXor, min = 3, opt = 2, theo = 1, |a: State,
                                                            b: State|
     -> State {
        crate::ops::elementwise::xor(a, b)
    });

    #[test]
    fn test_define_op_identity() {
        let s = State::from_bytes(&[42; 624]);
        assert_eq!(TestIdentity.apply(s), s);
        assert_eq!(TestIdentity::NAME, "TestIdentity");
    }

    #[test]
    fn test_define_op_targets() {
        assert_eq!(TestIdentity::TARGETS.minimum, 5);
        assert_eq!(TestIdentity::TARGETS.optimal, 3);
        assert_eq!(TestIdentity::TARGETS.theoretical, 1);
    }

    #[test]
    fn test_define_binary_op() {
        let a = State::ones();
        let b = State::ones();
        assert_eq!(TestXor.apply(a, b), State::zeros());
        assert_eq!(TestXor::NAME, "TestXor");
    }

    #[test]
    fn test_define_binary_op_targets() {
        assert_eq!(TestXor::TARGETS.minimum, 3);
        assert_eq!(TestXor::TARGETS.optimal, 2);
        assert_eq!(TestXor::TARGETS.theoretical, 1);
    }
}
