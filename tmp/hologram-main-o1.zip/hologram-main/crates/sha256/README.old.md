# hologram-sha256

SHA-256 hashing using hologram's kernel override system, suitable for Bitcoin mining.

## Quick Start

```rust
use hologram_sha256::{sha256, double_sha256, Sha256};

// One-shot hashing
let hash = sha256(b"hello world");
assert_eq!(hash.len(), 32);

// Incremental hashing
let mut hasher = Sha256::new();
hasher.update(b"hello ");
hasher.update(b"world");
let hash = hasher.finalize();

// Bitcoin double SHA-256
let block_header = [0u8; 80];
let hash = double_sha256(&block_header);
```

## Bitcoin Mining

```rust
use hologram_sha256::mine_check;

let mut header = [0u8; 80];
let target = [0xFF; 32]; // Easy target for testing
if let Some(hash) = mine_check(&header, &target) {
    println!("Found valid hash: {}", hash);
}
```

## Kernel Override Integration

This crate implements hologram's `KernelOverride` trait to provide optimized SHA-256 operations to the backend system. Register the kernels at application startup:

```rust
use hologram_sha256::register_sha256_kernels;

fn main() {
    // Register SHA-256 kernel overrides at startup
    register_sha256_kernels().expect("failed to register SHA-256 kernels");

    // Now hologram backends will use optimized SHA-256 when available
}
```

### Kernel Override Methods

The following kernel methods are provided:

| Method | Description |
|--------|-------------|
| `sha256` | Compute SHA-256 hash of arbitrary data |
| `double_sha256` | Compute SHA256(SHA256(data)) for Bitcoin |
| `sha256_compress` | Core compression function (64-byte block) |

## Architecture

This crate provides:

1. **Standalone API**: `sha256()`, `double_sha256()`, `mine_check()`, `Sha256` hasher
2. **Kernel Overrides**: `Sha256Kernels` implementing `KernelOverride`
3. **Low-level Access**: `compress()`, `H0`, `K` constants

### Implementation

The current implementation uses a correct pure-Rust compression function that:
- Passes all FIPS 180-4 test vectors
- Matches the `sha2` crate output exactly
- Provides consistent behavior across all platforms

Future versions may add hardware acceleration (SHA-NI) as an optimization.

## API Reference

### Functions

- `sha256(data: &[u8]) -> Sha256Digest` - One-shot hash
- `double_sha256(data: &[u8]) -> Sha256Digest` - Bitcoin hash (SHA256(SHA256(x)))
- `mine_check(header: &[u8; 80], target: &[u8; 32]) -> Option<Sha256Digest>` - Mining check
- `compress(state: &mut [u32; 8], block: &[u8; 64])` - Low-level compression
- `register_sha256_kernels() -> Result<(), &'static str>` - Register kernel overrides

### Types

- `Sha256` - Incremental hasher with `new()`, `update()`, `finalize()`
- `Sha256Digest` - 32-byte hash result with `as_bytes()`, `to_hex()`
- `Sha256Kernels` - `KernelOverride` implementation

### Constants

- `H0: [u32; 8]` - Initial hash values
- `K: [u32; 64]` - Round constants
- `SHA256_H0: [u32; 8]` - Alias for H0 (kernel module)

## Extraction to Standalone Repository

This crate is designed for extraction to its own repository at:
https://github.com/UOR-Foundation/hologram-sha256

When extracting:
1. Change `hologram = { path = "../.." }` to `hologram = "0.1"`
2. Update repository URL in `Cargo.toml`
3. No other changes needed - the API is self-contained

## Features

- `bitcoin` - Enable Bitcoin-specific optimizations (double SHA-256, block header parsing)

## License

MIT OR Apache-2.0
