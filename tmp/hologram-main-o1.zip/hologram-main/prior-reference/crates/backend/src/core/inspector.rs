//! Runtime inspection hooks for debugging and visualization.
//!
//! This module provides types for inspecting data flow during execution.
//! All inspection code is feature-gated behind `inspector` to ensure
//! zero overhead in production builds.
//!
//! # Usage
//!
//! Enable inspection by compiling with the `inspector` feature:
//!
//! ```bash
//! cargo build --features inspector
//! ```
//!
//! # Performance Notes
//!
//! - Inspection callbacks execute synchronously during kernel dispatch
//! - Snapshot capture (`capture_snapshots = true`) allocates heap memory
//! - For production, use provenance tracking instead (compile-time overhead only)

#[cfg(feature = "inspector")]
use crate::plan::BufferRef;
use crate::BufferHandle;

/// Phase of inspection relative to operation execution.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InspectionPhase {
    /// Before the operation executes.
    BeforeOp,
    /// After the operation completes.
    AfterOp,
}

/// A snapshot of buffer data at an inspection point.
///
/// WARNING: This allocates heap memory! Only use when debugging.
#[cfg(feature = "inspector")]
#[derive(Debug, Clone)]
pub struct BufferSnapshot {
    /// The buffer reference this snapshot is for.
    pub buffer_ref: BufferRef,
    /// Copy of the buffer data at the inspection point.
    pub data: Vec<u8>,
    /// The operation index where the snapshot was taken.
    pub op_index: usize,
    /// The phase (before or after operation).
    pub phase: InspectionPhase,
}

/// Information available at an inspection point.
///
/// This is passed to inspection callbacks and provides metadata
/// about the current execution state.
#[derive(Debug, Clone)]
pub struct InspectionPoint {
    /// Index of the operation being inspected.
    pub op_index: usize,
    /// Phase of inspection (before or after operation).
    pub phase: InspectionPhase,
    /// Buffer handle being inspected (if applicable).
    pub buffer: Option<BufferHandle>,
    /// Raw pointer to the buffer data.
    ///
    /// # Safety
    ///
    /// This pointer is only valid during the callback invocation.
    /// Do not store or dereference after the callback returns.
    pub data_ptr: *const u8,
    /// Size of the buffer in bytes.
    pub size: usize,
    /// Shape of the tensor (if known).
    pub shape: Option<Vec<usize>>,
    /// Kernel ID being executed.
    pub kernel_id: u32,
}

impl InspectionPoint {
    /// Read the buffer data as a slice.
    ///
    /// # Safety
    ///
    /// The returned slice is only valid during the inspection callback.
    /// Do not store references to this data.
    pub unsafe fn as_slice(&self) -> &[u8] {
        if self.data_ptr.is_null() || self.size == 0 {
            &[]
        } else {
            std::slice::from_raw_parts(self.data_ptr, self.size)
        }
    }

    /// Read the buffer data as f32 values.
    ///
    /// # Safety
    ///
    /// Assumes the buffer contains valid f32 data. The returned slice
    /// is only valid during the inspection callback.
    pub unsafe fn as_f32_slice(&self) -> &[f32] {
        if self.data_ptr.is_null() || self.size < 4 {
            &[]
        } else {
            let count = self.size / 4;
            std::slice::from_raw_parts(self.data_ptr as *const f32, count)
        }
    }

    /// Get the number of elements (assuming f32).
    pub fn num_elements(&self) -> usize {
        self.size / 4
    }

    /// Check if this is a pre-operation inspection.
    pub fn is_before(&self) -> bool {
        self.phase == InspectionPhase::BeforeOp
    }

    /// Check if this is a post-operation inspection.
    pub fn is_after(&self) -> bool {
        self.phase == InspectionPhase::AfterOp
    }
}

/// Type alias for inspection callback functions.
///
/// The callback receives an `InspectionPoint` and returns `true` to continue
/// execution or `false` to abort.
pub type InspectorCallback = Box<dyn Fn(&InspectionPoint) -> bool + Send + Sync>;

/// Configuration for data flow inspection during execution.
///
/// The inspector can selectively observe operations and capture buffer
/// snapshots for debugging purposes.
#[cfg(feature = "inspector")]
pub struct DataFlowInspector {
    /// Filter to specific operation indices (None = all ops).
    pub op_filter: Option<Vec<usize>>,
    /// Callback invoked at each inspection point.
    pub callback: Option<InspectorCallback>,
    /// Whether to capture buffer snapshots (WARNING: allocates!).
    pub capture_snapshots: bool,
    /// Captured snapshots (only populated if capture_snapshots is true).
    pub snapshots: Vec<BufferSnapshot>,
    /// Whether to inspect before operations.
    pub inspect_before: bool,
    /// Whether to inspect after operations.
    pub inspect_after: bool,
}

#[cfg(feature = "inspector")]
impl DataFlowInspector {
    /// Create a new inspector with default settings.
    pub fn new() -> Self {
        Self {
            op_filter: None,
            callback: None,
            capture_snapshots: false,
            snapshots: Vec::new(),
            inspect_before: false,
            inspect_after: true,
        }
    }

    /// Filter inspection to specific operation indices.
    pub fn with_op_filter(mut self, ops: Vec<usize>) -> Self {
        self.op_filter = Some(ops);
        self
    }

    /// Set the inspection callback.
    pub fn with_callback<F>(mut self, callback: F) -> Self
    where
        F: Fn(&InspectionPoint) -> bool + Send + Sync + 'static,
    {
        self.callback = Some(Box::new(callback));
        self
    }

    /// Enable snapshot capture (WARNING: allocates heap memory!).
    pub fn with_snapshots(mut self) -> Self {
        self.capture_snapshots = true;
        self
    }

    /// Enable pre-operation inspection.
    pub fn inspect_before_ops(mut self) -> Self {
        self.inspect_before = true;
        self
    }

    /// Enable post-operation inspection (default).
    pub fn inspect_after_ops(mut self) -> Self {
        self.inspect_after = true;
        self
    }

    /// Check if a specific operation should be inspected.
    pub fn should_inspect(&self, op_index: usize) -> bool {
        match &self.op_filter {
            Some(filter) => filter.contains(&op_index),
            None => true,
        }
    }

    /// Invoke the callback for an inspection point.
    ///
    /// Returns `true` if execution should continue, `false` to abort.
    pub fn inspect(&mut self, point: &InspectionPoint) -> bool {
        // Check phase
        match point.phase {
            InspectionPhase::BeforeOp if !self.inspect_before => return true,
            InspectionPhase::AfterOp if !self.inspect_after => return true,
            _ => {}
        }

        // Check filter
        if !self.should_inspect(point.op_index) {
            return true;
        }

        // Capture snapshot if enabled
        if self.capture_snapshots && !point.data_ptr.is_null() && point.size > 0 {
            let data = unsafe { std::slice::from_raw_parts(point.data_ptr, point.size) };
            self.snapshots.push(BufferSnapshot {
                buffer_ref: BufferRef::Workspace(0), // TODO: get actual ref
                data: data.to_vec(),
                op_index: point.op_index,
                phase: point.phase,
            });
        }

        // Invoke callback
        if let Some(ref callback) = self.callback {
            callback(point)
        } else {
            true
        }
    }

    /// Get all captured snapshots.
    pub fn get_snapshots(&self) -> &[BufferSnapshot] {
        &self.snapshots
    }

    /// Clear captured snapshots.
    pub fn clear_snapshots(&mut self) {
        self.snapshots.clear();
    }

    /// Get the number of captured snapshots.
    pub fn snapshot_count(&self) -> usize {
        self.snapshots.len()
    }
}

#[cfg(feature = "inspector")]
impl Default for DataFlowInspector {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(feature = "inspector")]
impl std::fmt::Debug for DataFlowInspector {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("DataFlowInspector")
            .field("op_filter", &self.op_filter)
            .field("has_callback", &self.callback.is_some())
            .field("capture_snapshots", &self.capture_snapshots)
            .field("snapshot_count", &self.snapshots.len())
            .field("inspect_before", &self.inspect_before)
            .field("inspect_after", &self.inspect_after)
            .finish()
    }
}

// ============================================================================
// Stub implementations when feature is disabled
// ============================================================================

/// Stub inspector when feature is disabled.
#[cfg(not(feature = "inspector"))]
#[derive(Debug, Clone, Copy, Default)]
pub struct DataFlowInspector;

#[cfg(not(feature = "inspector"))]
impl DataFlowInspector {
    /// Create a new stub inspector (no-op).
    #[inline(always)]
    pub const fn new() -> Self {
        Self
    }
}

// ============================================================================
// DOT Format Export
// ============================================================================

/// Export a plan as a DOT graph for visualization.
///
/// This generates a Graphviz DOT format string that can be rendered
/// using tools like `dot -Tpng graph.dot -o graph.png`.
pub fn export_execution_graph(plan: &crate::plan::BackendPlan) -> String {
    let mut dot = String::new();
    dot.push_str("digraph ExecutionGraph {\n");
    dot.push_str("    rankdir=TB;\n");
    dot.push_str("    node [shape=box, style=filled, fillcolor=lightblue];\n\n");

    // Add nodes for each operation
    for (i, op) in plan.ops.iter().enumerate() {
        let kernel_name = format!("0x{:04x}", op.kernel_id.0);
        dot.push_str(&format!(
            "    op{} [label=\"Op {}\\n{}\"];\n",
            i, i, kernel_name
        ));
    }

    dot.push('\n');

    // Add edges based on buffer dependencies
    // This is a simplified view - real dependencies would come from buffer refs
    for i in 1..plan.ops.len() {
        dot.push_str(&format!("    op{} -> op{};\n", i - 1, i));
    }

    dot.push_str("}\n");
    dot
}

/// Export plan statistics as a summary string.
pub fn plan_summary(plan: &crate::plan::BackendPlan) -> String {
    let mut summary = String::new();
    summary.push_str("=== Plan Summary ===\n");
    summary.push_str(&format!("Operations: {}\n", plan.ops.len()));
    summary.push_str(&format!(
        "Workspace size: {} bytes\n",
        plan.workspace_layout.total_size
    ));
    summary.push_str(&format!(
        "Constant data: {} bytes\n",
        plan.constant_data.len()
    ));
    summary.push_str(&format!(
        "Workspace regions: {}\n",
        plan.workspace_layout.regions.len()
    ));

    // Count kernel categories
    let mut category_counts = std::collections::HashMap::new();
    for op in &plan.ops {
        let category = op.kernel_id.category();
        *category_counts.entry(category).or_insert(0) += 1;
    }

    summary.push_str("\nKernel categories:\n");
    for (category, count) in category_counts {
        let name = match category {
            0x00 => "NOOP",
            0x01 => "GEMM",
            0x02 => "CONV",
            0x03 => "ELEMENTWISE",
            0x04 => "ACTIVATION",
            0x05 => "TRANSCENDENTAL",
            0x06 => "REDUCE",
            0x07 => "TENSOR_OPS",
            0x08 => "NORMALIZATION",
            _ => "OTHER",
        };
        summary.push_str(&format!("  {}: {}\n", name, count));
    }

    summary
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_inspection_phase() {
        assert_eq!(InspectionPhase::BeforeOp, InspectionPhase::BeforeOp);
        assert_ne!(InspectionPhase::BeforeOp, InspectionPhase::AfterOp);
    }

    #[test]
    fn test_inspection_point_helpers() {
        let point = InspectionPoint {
            op_index: 5,
            phase: InspectionPhase::BeforeOp,
            buffer: None,
            data_ptr: std::ptr::null(),
            size: 0,
            shape: None,
            kernel_id: 0x0100,
        };

        assert!(point.is_before());
        assert!(!point.is_after());
        assert_eq!(point.num_elements(), 0);
    }

    #[test]
    #[cfg(feature = "inspector")]
    fn test_inspector_new() {
        let inspector = DataFlowInspector::new();
        assert!(inspector.op_filter.is_none());
        assert!(inspector.callback.is_none());
        assert!(!inspector.capture_snapshots);
        assert!(!inspector.inspect_before);
        assert!(inspector.inspect_after);
    }

    #[test]
    #[cfg(feature = "inspector")]
    fn test_inspector_builder() {
        let inspector = DataFlowInspector::new()
            .with_op_filter(vec![0, 1, 5])
            .with_snapshots()
            .inspect_before_ops();

        assert_eq!(inspector.op_filter, Some(vec![0, 1, 5]));
        assert!(inspector.capture_snapshots);
        assert!(inspector.inspect_before);
    }

    #[test]
    #[cfg(feature = "inspector")]
    fn test_inspector_should_inspect() {
        let inspector = DataFlowInspector::new().with_op_filter(vec![0, 2, 4]);

        assert!(inspector.should_inspect(0));
        assert!(!inspector.should_inspect(1));
        assert!(inspector.should_inspect(2));
        assert!(!inspector.should_inspect(3));
        assert!(inspector.should_inspect(4));
    }

    #[test]
    #[cfg(feature = "inspector")]
    fn test_inspector_callback() {
        let call_count = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let counter = call_count.clone();

        let mut inspector = DataFlowInspector::new().with_callback(move |_point| {
            counter.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            true
        });

        let point = InspectionPoint {
            op_index: 0,
            phase: InspectionPhase::AfterOp,
            buffer: None,
            data_ptr: std::ptr::null(),
            size: 0,
            shape: None,
            kernel_id: 0,
        };

        assert!(inspector.inspect(&point));
        assert_eq!(call_count.load(std::sync::atomic::Ordering::SeqCst), 1);
    }
}
