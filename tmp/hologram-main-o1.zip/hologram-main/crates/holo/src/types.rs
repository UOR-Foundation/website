//! Supporting types for backend plans and buffers.
//!
//! This module defines the metadata types used to describe buffers in
//! compiled plans, including size, alignment, and classification.
//!
//! Also includes observable metadata for categorical operation verification.

use rkyv::{Archive, Deserialize, Serialize};

/// Buffer metadata describing size, alignment, and type.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct BufferMetadata {
    /// Size in bytes
    pub size: usize,

    /// Alignment requirement in bytes (32 for AVX2, 64 for AVX-512)
    pub alignment: usize,

    /// Buffer type classification
    pub buffer_type: BufferType,

    /// Compiler hint: the first instruction targeting this buffer writes every
    /// byte, so the runtime can skip pre-zeroing.  Set by the compiler for
    /// Output/Workspace buffers whose first write is a full overwrite (matmul,
    /// element-wise ops, etc.).
    pub fully_written: bool,
}

/// Classification of buffer usage.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub enum BufferType {
    /// Input buffer (caller-provided)
    Input,

    /// Output buffer (caller-provided)
    Output,

    /// Workspace buffer (backend-managed temporary)
    Workspace,

    /// Constant buffer (embedded in plan, zero-copy)
    Constant,
}

impl BufferMetadata {
    /// Create a new buffer metadata with default alignment.
    #[must_use]
    pub const fn new(size: usize, buffer_type: BufferType) -> Self {
        Self {
            size,
            alignment: 32, // Default to AVX2 alignment
            buffer_type,
            fully_written: false,
        }
    }

    /// Create a new buffer metadata with custom alignment.
    #[must_use]
    pub const fn with_alignment(size: usize, alignment: usize, buffer_type: BufferType) -> Self {
        Self {
            size,
            alignment,
            buffer_type,
            fully_written: false,
        }
    }

    /// Mark this buffer as fully written by its first instruction.
    ///
    /// When set, the runtime skips pre-zeroing this buffer since the first
    /// instruction will overwrite every byte.
    #[must_use]
    pub const fn with_fully_written(mut self) -> Self {
        self.fully_written = true;
        self
    }
}

/// Observable metadata for categorical operation chains.
///
/// This captures monodromy signature information computed during fusion
/// and enables runtime verification of fused operations.
#[derive(Debug, Clone, Default, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct ObservableMetadata {
    /// Fused categorical chains with their observable annotations.
    pub chains: Vec<FusedChain>,

    /// Whether runtime verification is enabled.
    pub verify_enabled: bool,
}

/// A fused categorical operation chain with its observable annotation.
#[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct FusedChain {
    /// Index of the fused instruction in the plan.
    pub instruction_idx: u32,

    /// Operation types in the chain (for verification).
    pub op_types: Vec<CategoricalOpType>,

    /// Expected stratum change (Hamming weight delta).
    pub stratum_delta: i32,

    /// Maximum curvature (cascade length) in the chain.
    pub max_curvature: u8,

    /// Whether the chain is pure (no side effects).
    pub is_pure: bool,
}

/// Classification of categorical operations for observable tracking.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub enum CategoricalOpType {
    /// Lift to torus coordinates.
    Lift,

    /// Orbit classification.
    OrbitClassify,
}

impl ObservableMetadata {
    /// Create new observable metadata with no chains.
    #[must_use]
    pub const fn new() -> Self {
        Self {
            chains: Vec::new(),
            verify_enabled: false,
        }
    }

    /// Enable runtime verification.
    #[must_use]
    pub const fn with_verification(mut self) -> Self {
        self.verify_enabled = true;
        self
    }

    /// Add a fused chain.
    #[must_use]
    pub fn with_chain(mut self, chain: FusedChain) -> Self {
        self.chains.push(chain);
        self
    }

    /// Check if any fused chains exist.
    #[must_use]
    pub fn has_chains(&self) -> bool {
        !self.chains.is_empty()
    }
}

impl FusedChain {
    /// Create a new fused chain annotation.
    #[must_use]
    pub const fn new(instruction_idx: u32) -> Self {
        Self {
            instruction_idx,
            op_types: Vec::new(),
            stratum_delta: 0,
            max_curvature: 0,
            is_pure: true,
        }
    }

    /// Estimate variation cost using LUT metrics.
    ///
    /// Lower variation means more cache-friendly execution.
    #[must_use]
    pub fn variation_cost(&self) -> u64 {
        let mut cost = 0u64;
        for op in &self.op_types {
            cost += match op {
                CategoricalOpType::Lift | CategoricalOpType::OrbitClassify => 1,
            };
        }
        cost
    }
}

// ============================================================================
// LUT Section: Embedded Lookup Tables for O(1) Operations
// ============================================================================

/// Embedded LUT section for O(1) categorical operations.
///
/// All categorical operations (`Lift`, `OrbitClassify`)
/// use precomputed lookup tables for constant-time execution. This section
/// embeds the LUT data directly in the plan for zero-copy memory mapping.
///
/// # Table Sizes
///
/// | Table | Size | Purpose |
/// |-------|------|---------|
/// | `torus_page` | 256 bytes | Map byte to torus page |
/// | `orbit_class` | 256 bytes | Map byte to orbit class |
///
/// Total: 512 bytes (fits in L1 cache)
#[derive(Debug, Clone, Default, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct LutSection {
    /// Torus page table: maps byte to page coordinate (256 bytes).
    pub torus_page: Vec<u8>,

    /// Orbit class table: maps byte to orbit class 0-31 (256 bytes).
    pub orbit_class: Vec<u8>,

    /// Whether LUT data is embedded (false = use `uor::lut` static tables).
    pub embedded: bool,
}

/// Size constants for LUT tables.
pub mod lut_sizes {
    /// Torus page table size (256 entries).
    pub const TORUS_PAGE_SIZE: usize = 256;

    /// Orbit class table size (256 entries).
    pub const ORBIT_CLASS_SIZE: usize = 256;

    /// Total LUT section size when embedded.
    pub const TOTAL_SIZE: usize = TORUS_PAGE_SIZE + ORBIT_CLASS_SIZE;
}

impl LutSection {
    /// Create an empty LUT section (uses static tables from `uor::lut`).
    #[must_use]
    pub const fn new() -> Self {
        Self {
            torus_page: Vec::new(),
            orbit_class: Vec::new(),
            embedded: false,
        }
    }

    /// Create a LUT section with embedded data from `uor::lut` static tables.
    ///
    /// This copies the static LUT data into the plan for portable execution
    /// without requiring the `uor` crate at runtime.
    #[must_use]
    pub fn with_embedded_luts() -> Self {
        Self {
            torus_page: uor::lut::TORUS_PAGE_Q0.to_vec(),
            orbit_class: uor::lut::ORBIT_CLASS_Q0.to_vec(),
            embedded: true,
        }
    }

    /// Check if this section has embedded LUT data.
    #[must_use]
    pub const fn is_embedded(&self) -> bool {
        self.embedded
    }

    /// Total size of embedded LUT data in bytes.
    #[must_use]
    pub fn embedded_size(&self) -> usize {
        if self.embedded {
            self.torus_page.len() + self.orbit_class.len()
        } else {
            0
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_buffer_metadata_new() {
        let meta = BufferMetadata::new(1024, BufferType::Input);
        assert_eq!(meta.size, 1024);
        assert_eq!(meta.alignment, 32);
        assert_eq!(meta.buffer_type, BufferType::Input);
        assert!(!meta.fully_written);
    }

    #[test]
    fn test_buffer_metadata_with_alignment() {
        let meta = BufferMetadata::with_alignment(2048, 64, BufferType::Workspace);
        assert_eq!(meta.size, 2048);
        assert_eq!(meta.alignment, 64);
        assert_eq!(meta.buffer_type, BufferType::Workspace);
        assert!(!meta.fully_written);
    }

    #[test]
    fn test_buffer_metadata_with_fully_written() {
        let meta = BufferMetadata::new(512, BufferType::Output).with_fully_written();
        assert_eq!(meta.size, 512);
        assert!(meta.fully_written);
    }

    #[test]
    fn test_observable_metadata_default() {
        let meta = ObservableMetadata::default();
        assert!(!meta.verify_enabled);
        assert!(meta.chains.is_empty());
    }

    #[test]
    fn test_observable_metadata_with_verification() {
        let meta = ObservableMetadata::new().with_verification();
        assert!(meta.verify_enabled);
    }

    #[test]
    fn test_fused_chain_new() {
        let chain = FusedChain::new(5);
        assert_eq!(chain.instruction_idx, 5);
        assert!(chain.op_types.is_empty());
        assert!(chain.is_pure);
    }

    #[test]
    fn test_fused_chain_variation_cost() {
        let mut chain = FusedChain::new(0);
        chain.op_types = vec![CategoricalOpType::Lift, CategoricalOpType::OrbitClassify];
        assert_eq!(chain.variation_cost(), 2);
    }

    #[test]
    fn test_observable_metadata_has_chains() {
        let empty = ObservableMetadata::new();
        assert!(!empty.has_chains());

        let with_chain = ObservableMetadata::new().with_chain(FusedChain::new(0));
        assert!(with_chain.has_chains());
    }

    #[test]
    fn test_lut_section_new() {
        let lut = LutSection::new();
        assert!(!lut.is_embedded());
        assert_eq!(lut.embedded_size(), 0);
    }

    #[test]
    fn test_lut_section_with_embedded() {
        let lut = LutSection::with_embedded_luts();
        assert!(lut.is_embedded());
        assert_eq!(lut.embedded_size(), lut_sizes::TOTAL_SIZE);
        assert_eq!(lut.torus_page.len(), lut_sizes::TORUS_PAGE_SIZE);
        assert_eq!(lut.orbit_class.len(), lut_sizes::ORBIT_CLASS_SIZE);
    }

    #[test]
    fn test_lut_sizes_constants() {
        assert_eq!(lut_sizes::TORUS_PAGE_SIZE, 256);
        assert_eq!(lut_sizes::ORBIT_CLASS_SIZE, 256);
        assert_eq!(lut_sizes::TOTAL_SIZE, 512);
    }
}
