#!/usr/bin/env python3
"""
Integration tests for UOR Python bindings.

Build bindings first:
    just ffi-python

Run tests:
    just ffi-test-python
    # or directly:
    pytest examples/python/test_bindings.py -v
"""

import sys
import os

import pytest

# Add bindings to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../bindings/python'))

from uor import (
    byte_to_braille,
    byte_to_codepoint,
    byte_to_domain,
    byte_rank,
    byte_succ,
    byte_pred,
    byte_not,
    FfiView,
    FfiError,
    braille_base,
    braille_max,
    triadic_constant,
    octave_constant,
    state_taxons,
    state_bits,
)


class TestConstants:
    """Test constant values match expected mathematical definitions."""

    def test_braille_base(self):
        assert braille_base() == 0x2800

    def test_braille_max(self):
        assert braille_max() == 0x28FF

    def test_triadic_constant(self):
        assert triadic_constant() == 3

    def test_octave_constant(self):
        assert octave_constant() == 8

    def test_state_taxons(self):
        assert state_taxons() == 624

    def test_state_bits(self):
        assert state_bits() == 4992


class TestByteToCodepoint:
    """Test byte to Unicode codepoint conversion."""

    def test_zero(self):
        assert byte_to_codepoint(0) == 0x2800

    def test_one(self):
        assert byte_to_codepoint(1) == 0x2801

    def test_max(self):
        assert byte_to_codepoint(255) == 0x28FF

    def test_arbitrary(self):
        assert byte_to_codepoint(42) == 0x2800 + 42

    def test_bijection(self):
        """Every byte maps to a unique codepoint."""
        codepoints = [byte_to_codepoint(i) for i in range(256)]
        assert len(set(codepoints)) == 256


class TestByteToBraille:
    """Test byte to Braille character conversion."""

    def test_zero(self):
        assert byte_to_braille(0) == "⠀"

    def test_one(self):
        assert byte_to_braille(1) == "⠁"

    def test_max(self):
        assert byte_to_braille(255) == "⣿"

    def test_codepoint_consistency(self):
        """Braille char codepoint matches byte_to_codepoint."""
        for i in range(256):
            braille = byte_to_braille(i)
            assert ord(braille) == byte_to_codepoint(i)


class TestByteToDomain:
    """Test byte to triadic domain classification.

    Note: byte_to_domain returns u8 (0=Theta, 1=Psi, 2=Delta), not FfiDomain enum.
    """

    def test_zero_is_theta(self):
        domain = byte_to_domain(0)
        assert domain == 0  # Theta

    def test_one_is_psi(self):
        domain = byte_to_domain(1)
        assert domain == 1  # Psi

    def test_two_is_delta(self):
        domain = byte_to_domain(2)
        assert domain == 2  # Delta

    def test_all_bytes_have_domain(self):
        """Every byte maps to one of three domains (0, 1, 2)."""
        for i in range(256):
            domain = byte_to_domain(i)
            assert domain in (0, 1, 2)


class TestByteRank:
    """Test rank within domain."""

    def test_zero_rank(self):
        rank = byte_rank(0)
        assert isinstance(rank, int)
        assert 0 <= rank < 256

    def test_all_bytes_have_rank(self):
        """Every byte has a rank."""
        for i in range(256):
            rank = byte_rank(i)
            assert isinstance(rank, int)
            assert 0 <= rank < 256


class TestRingOperations:
    """Test ring arithmetic operations."""

    def test_succ_pred_inverse(self):
        """Successor and predecessor are inverses."""
        for value in [0, 1, 42, 127, 254, 255]:
            assert byte_pred(byte_succ(value)) == value

    def test_pred_succ_inverse(self):
        """Predecessor and successor are inverses."""
        for value in [0, 1, 42, 127, 254, 255]:
            assert byte_succ(byte_pred(value)) == value

    def test_not_involution(self):
        """NOT applied twice returns original."""
        for value in [0, 1, 42, 127, 254, 255]:
            assert byte_not(byte_not(value)) == value

    def test_succ_wraps(self):
        """Successor wraps around at 255."""
        result = byte_succ(255)
        assert 0 <= result <= 255

    def test_pred_wraps(self):
        """Predecessor wraps around at 0."""
        result = byte_pred(0)
        assert 0 <= result <= 255


class TestFfiViewIdentity:
    """Test identity view operations."""

    def test_create_identity(self):
        view = FfiView.identity()
        assert view is not None

    def test_identity_preserves_zero(self):
        view = FfiView.identity()
        assert view.apply(0) == 0

    def test_identity_preserves_arbitrary(self):
        view = FfiView.identity()
        assert view.apply(42) == 42

    def test_identity_preserves_max(self):
        view = FfiView.identity()
        assert view.apply(255) == 255

    def test_identity_preserves_all(self):
        """Identity view preserves all 256 values."""
        view = FfiView.identity()
        for i in range(256):
            assert view.apply(i) == i

    def test_identity_is_bijective(self):
        view = FfiView.identity()
        assert view.is_bijective() is True

    def test_identity_inverse(self):
        """Identity inverse is also identity."""
        view = FfiView.identity()
        inv = view.inverse()
        assert inv.apply(42) == 42


class TestFfiViewConstant:
    """Test constant view operations."""

    def test_create_constant(self):
        view = FfiView.constant(17)
        assert view is not None

    def test_constant_maps_all_to_value(self):
        view = FfiView.constant(99)
        assert view.apply(0) == 99
        assert view.apply(42) == 99
        assert view.apply(255) == 99

    def test_constant_is_not_bijective(self):
        view = FfiView.constant(0)
        assert view.is_bijective() is False

    def test_constant_inverse_fails(self):
        """Constant view has no inverse (not bijective)."""
        view = FfiView.constant(0)
        with pytest.raises(FfiError):
            view.inverse()


class TestFfiViewComposition:
    """Test view composition."""

    def test_identity_then_identity(self):
        """Composing identity with identity yields identity."""
        a = FfiView.identity()
        b = FfiView.identity()
        composed = a.then(b)
        assert composed.apply(42) == 42

    def test_identity_then_constant(self):
        """Identity then constant yields constant."""
        a = FfiView.identity()
        b = FfiView.constant(17)
        composed = a.then(b)
        assert composed.apply(42) == 17

    def test_constant_then_identity(self):
        """Constant then identity yields constant."""
        a = FfiView.constant(17)
        b = FfiView.identity()
        composed = a.then(b)
        assert composed.apply(42) == 17


class TestFfiViewApplySlice:
    """Test batch operations on byte arrays."""

    def test_identity_preserves_array(self):
        view = FfiView.identity()
        input_data = bytes([0, 1, 2, 3, 4, 5, 6, 7])
        output = view.apply_slice(input_data)
        assert list(output) == list(input_data)

    def test_constant_transforms_array(self):
        view = FfiView.constant(42)
        input_data = bytes([0, 1, 2, 3])
        output = view.apply_slice(input_data)
        assert list(output) == [42, 42, 42, 42]

    def test_empty_array(self):
        view = FfiView.identity()
        output = view.apply_slice(bytes())
        assert list(output) == []

    def test_large_array(self):
        """Test with 1KB of data."""
        view = FfiView.identity()
        input_data = bytes(range(256)) * 4  # 1024 bytes
        output = view.apply_slice(input_data)
        assert output == input_data


class TestFfiViewTable:
    """Test view lookup table access."""

    def test_identity_table(self):
        view = FfiView.identity()
        table = view.table()
        assert len(table) == 256
        for i in range(256):
            assert table[i] == i

    def test_constant_table(self):
        view = FfiView.constant(42)
        table = view.table()
        assert len(table) == 256
        for i in range(256):
            assert table[i] == 42


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
