//! Equivalence test: verify generated dispatch code matches hand-written code.
//!
//! Compares generated dispatcher trait methods and match block structure
//! against the hand-written InstructionDispatcher trait.

/// Verify generated trait has the same method count as hand-written.
#[test]
fn generated_trait_method_count() {
    let input = include_str!("../../../descriptors/shells/isa.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ops = hologram_shell::emit_isa::resolve_ops(&shell);
    let trait_code = hologram_shell::emit_isa::emit_dispatcher_trait(&shell).to_string();

    // Count method declarations in generated trait
    let method_count = trait_code.matches("fn exec_").count();
    assert_eq!(
        method_count,
        ops.len(),
        "generated trait has {method_count} methods, expected {}",
        ops.len()
    );
}

/// Verify generated match block has one arm per variant.
#[test]
fn generated_match_arm_count() {
    let input = include_str!("../../../descriptors/shells/isa.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ops = hologram_shell::emit_isa::resolve_ops(&shell);
    let match_code = hologram_shell::emit_isa::emit_execute_on(&shell).to_string();

    // Count match arms (Self:: patterns)
    let arm_count = match_code.matches("Self ::").count();
    assert_eq!(
        arm_count,
        ops.len(),
        "generated match has {arm_count} arms, expected {}",
        ops.len()
    );
}

/// Verify generated dispatcher impl has one delegation per method.
#[test]
fn generated_impl_delegation_count() {
    let input = include_str!("../../../descriptors/shells/isa.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ops = hologram_shell::emit_isa::resolve_ops(&shell);
    let impl_code = hologram_shell::emit_isa::emit_dispatcher_impl(&shell).to_string();

    // Count dispatch delegations
    let delegation_count = impl_code.matches("dispatch ::").count();
    assert_eq!(
        delegation_count,
        ops.len(),
        "generated impl has {delegation_count} delegations, expected {}",
        ops.len()
    );
}

/// Verify trait parameter types for complex ops match expectations.
#[test]
fn generated_trait_complex_param_types() {
    let input = include_str!("../../../descriptors/shells/isa.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let trait_code = hologram_shell::emit_isa::emit_dispatcher_trait(&shell).to_string();

    // Conv2d should have Option<u32> for bias
    assert!(trait_code.contains("Option < u32 >"));

    // Transpose should have &[usize; 8] for shape (by ref, large array)
    assert!(trait_code.contains("& [usize ; 8usize]"));

    // Transpose should have [u8; 8] for perm (by value, small array)
    assert!(trait_code.contains("[u8 ; 8usize]"));

    // CallLayer should have &[u32] for inputs/outputs (Vec → slice ref)
    assert!(trait_code.contains("& [u32]"));

    // BatchNorm should have f32 for epsilon
    assert!(trait_code.contains("f32"));
}

/// Verify match deref patterns are correct.
#[test]
fn generated_match_deref_patterns() {
    let input = include_str!("../../../descriptors/shells/isa.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let match_code = hologram_shell::emit_isa::emit_execute_on(&shell).to_string();

    // Scalar fields should be dereferenced
    assert!(match_code.contains("* dst"));

    // The generated code should contain exec_ method calls
    assert!(match_code.contains("exec_add"));
    assert!(match_code.contains("exec_matmul"));
    assert!(match_code.contains("exec_conv2d"));
    assert!(match_code.contains("exec_sigmoid_lut"));
}
