# UOR FFI - Multi-Language Bindings

Foreign function interface bindings for UOR (Universal Object Reference), providing access to core UOR functionality from Python, TypeScript, Swift, Kotlin, Ruby, and C.

## Features

- **Zero-copy operations**: < 1 ns overhead for most operations
- **Multi-language support**: Python, TypeScript/JS, Swift, Kotlin, Ruby, C/C++
- **Type-safe**: Generated bindings maintain type safety across language boundaries
- **Minimal overhead**: Benchmarked at 0.4-6.5 ns per FFI call

## Supported Languages

| Language      | Binding Strategy        | Status      |
| ------------- | ----------------------- | ----------- |
| Python        | UniFFI (auto-generated) | ✅ Ready    |
| TypeScript/JS | WASM (wasm-bindgen)     | ✅ Ready    |
| Swift         | UniFFI                  | ✅ Ready    |
| Kotlin        | UniFFI                  | ✅ Ready    |
| Ruby          | UniFFI                  | ✅ Ready    |
| C             | cbindgen                | ✅ Ready    |
| C++           | cbindgen + wrapper      | ✅ Ready    |

## Building

### UniFFI Bindings (Python, Swift, Kotlin, Ruby)

```bash
# Build the library
cargo build -p uor-ffi --release

# Generate Python bindings
cargo run -p uor-ffi --features uniffi-cli --bin uniffi-bindgen -- \
    generate --library target/release/libuor_ffi.so \
    --language python --out-dir bindings/python

# Generate Swift bindings
cargo run -p uor-ffi --features uniffi-cli --bin uniffi-bindgen -- \
    generate --library target/release/libuor_ffi.dylib \
    --language swift --out-dir bindings/swift

# Generate Kotlin bindings
cargo run -p uor-ffi --features uniffi-cli --bin uniffi-bindgen -- \
    generate --library target/release/libuor_ffi.so \
    --language kotlin --out-dir bindings/kotlin

# Generate Ruby bindings
cargo run -p uor-ffi --features uniffi-cli --bin uniffi-bindgen -- \
    generate --library target/release/libuor_ffi.so \
    --language ruby --out-dir bindings/ruby
```

### WASM Bindings (TypeScript/JavaScript)

```bash
# Install wasm-pack
cargo install wasm-pack

# Build for web
wasm-pack build --target web --features wasm crates/ffi --out-dir bindings/typescript/pkg

# Build for Node.js
wasm-pack build --target nodejs --features wasm crates/ffi --out-dir bindings/nodejs/pkg
```

## Usage Examples

### Python

```python
import uor

# Taxon operations (bijective byte ↔ Braille mapping)
braille = uor.byte_to_braille(42)  # '⠪'
codepoint = uor.byte_to_codepoint(42)  # 0x282A
domain = uor.byte_to_domain(42)  # 0 (Theta)
rank = uor.byte_rank(42)  # 14

# Ring operations
successor = uor.byte_succ(42)  # 43
predecessor = uor.byte_pred(42)  # 41
inverted = uor.byte_not(42)  # 213

# ElementWiseView - O(1) function composition via lookup tables
identity = uor.FfiView()  # Identity view
constant = uor.FfiView.constant(17)  # All inputs → 17

# Apply views
result = identity.apply(42)  # 42
result = constant.apply(42)  # 17

# Compose views (creates new lookup table)
composed = identity.then(constant)
result = composed.apply(100)  # 17

# Bulk operations (SIMD-accelerated)
data = bytes([1, 2, 3, 4, 5])
transformed = identity.apply_slice(data)

# Check bijectivity
is_bijective = identity.is_bijective()  # True
is_bijective = constant.is_bijective()  # False

# Inverse (only for bijective views)
inverse = identity.inverse()  # Ok
# constant.inverse()  # Raises FfiError.NotBijective

# Constants
T = uor.triadic_constant()  # 3
O = uor.octave_constant()  # 8
state_size = uor.state_taxons()  # 624
```

### TypeScript (WASM)

```typescript
import init, * as uor from './pkg/uor_ffi.js';

await init();

// Taxon operations
const braille = uor.wasm_byte_to_braille(42);  // '⠪'
const codepoint = uor.wasm_byte_to_codepoint(42);  // 0x282A
const domain = uor.wasm_byte_to_domain(42);  // 0

// Ring operations
const successor = uor.wasm_byte_succ(42);  // 43
const predecessor = uor.wasm_byte_pred(42);  // 41

// Views
const identity = new uor.WasmView();
const result = identity.apply(42);  // 42

// Bulk operations
const data = new Uint8Array([1, 2, 3, 4, 5]);
const transformed = identity.applySlice(data);

// Composition
const constant = uor.WasmView.constant(17);
const composed = identity.then(constant);

// Constants
const T = uor.triadic_constant();  // 3
const O = uor.octave_constant();  // 8
```

### Swift

```swift
import uor

// Taxon operations
let braille = byteTobraille(value: 42)  // "⠪"
let codepoint = byteToCcodepoint(value: 42)  // 0x282A
let domain = byteToDomain(value: 42)  // 0

// Ring operations
let successor = byteSucc(value: 42)  // 43
let predecessor = bytePred(value: 42)  // 41

// Views
let identity = try FfiView()
let result = identity.apply(byteValue: 42)  // 42

// Composition
let constant = try FfiView.constant(value: 17)
let composed = identity.then(other: constant)

// Bulk operations
let data = Data([1, 2, 3, 4, 5])
let transformed = identity.applySlice(input: data)
```

### Kotlin

```kotlin
import uor.*

fun main() {
    // Taxon operations
    val braille = byteTobraille(42u)  // "⠪"
    val codepoint = byteToCcodepoint(42u)  // 0x282A
    val domain = byteToDomain(42u)  // 0

    // Ring operations
    val successor = byteSucc(42u)  // 43
    val predecessor = bytePred(42u)  // 41
    val inverted = byteNot(42u)  // 213

    // Views
    val identity = FfiView()
    val result = identity.apply(42u)  // 42

    // Composition
    val constant = FfiView.constant(17u)
    val composed = identity.then(constant)

    // Bulk operations
    val data = listOf<UByte>(1u, 2u, 3u, 4u, 5u)
    val transformed = identity.applySlice(data)

    // Bijectivity
    println("Identity is bijective: ${identity.isBijective()}")  // true
    println("Constant is bijective: ${constant.isBijective()}")  // false
}
```

### Ruby

```ruby
require 'uor'

# Taxon operations
braille = Uor.byte_to_braille(42)  # "⠪"
codepoint = Uor.byte_to_codepoint(42)  # 0x282A
domain = Uor.byte_to_domain(42)  # 0 (:theta)
rank = Uor.byte_rank(42)  # 42

# Ring operations
successor = Uor.byte_succ(42)  # 43
predecessor = Uor.byte_pred(42)  # 41
inverted = Uor.byte_not(42)  # 213

# Views
identity = Uor::FfiView.new
result = identity.apply(42)  # 42

# Composition
constant = Uor::FfiView.constant(17)
composed = identity.then(constant)

# Bulk operations
data = [1, 2, 3, 4, 5].pack('C*')
transformed = identity.apply_slice(data)

# Bijectivity
puts "Identity bijective: #{identity.is_bijective?}"  # true
puts "Constant bijective: #{constant.is_bijective?}"  # false
```

### C

```c
#include "uor.h"

int main(void) {
    // Taxon operations
    char* braille = uor_byte_to_braille(42);  // "⠪"
    printf("Braille: %s\n", braille);
    uor_string_free(braille);  // Must free strings!

    uint32_t codepoint = uor_byte_to_codepoint(42);  // 0x282A
    uint8_t domain = uor_byte_to_domain(42);  // 0
    uint8_t rank = uor_byte_rank(42);  // 42

    // Ring operations
    uint8_t succ = uor_byte_succ(42);  // 43
    uint8_t pred = uor_byte_pred(42);  // 41
    uint8_t inv = uor_byte_not(42);   // 213

    // Views
    struct UorView* identity = uor_view_identity();
    uint8_t result = uor_view_apply(identity, 42);  // 42

    struct UorView* constant = uor_view_constant(17);
    bool is_bij = uor_view_is_bijective(constant);  // false

    // Composition
    struct UorView* composed = uor_view_compose(identity, constant);
    uint8_t comp_result = uor_view_apply(composed, 100);  // 17

    // Bulk operations
    uint8_t input[] = {1, 2, 3, 4, 5};
    uint8_t output[5];
    uor_view_apply_slice(identity, input, output, 5);

    // Cleanup - must free views!
    uor_view_free(identity);
    uor_view_free(constant);
    uor_view_free(composed);

    return 0;
}
```

**Building C programs:**

```bash
# Build the C bindings
just ffi-c

# Compile with gcc/clang
gcc -o myprogram myprogram.c \
    -I bindings/c \
    -L target/release \
    -luor_ffi \
    -Wl,-rpath,target/release

# Run
./myprogram
```

**Memory Management:**
- Strings returned from `uor_byte_to_braille()` must be freed with `uor_string_free()`
- Views created with `uor_view_*()` must be freed with `uor_view_free()`
- Scalar values (uint8_t, uint32_t, bool) do not require cleanup

### C++

```cpp
#include "uor.h"
#include <iostream>
#include <memory>

// RAII wrapper for UorView
struct ViewDeleter {
    void operator()(UorView* v) { uor_view_free(v); }
};
using UniqueView = std::unique_ptr<UorView, ViewDeleter>;

// RAII wrapper for strings
struct StringDeleter {
    void operator()(char* s) { uor_string_free(s); }
};
using UniqueString = std::unique_ptr<char, StringDeleter>;

int main() {
    // Taxon operations with RAII
    UniqueString braille(uor_byte_to_braille(42));
    std::cout << "Braille: " << braille.get() << std::endl;

    // Views with RAII - automatic cleanup
    UniqueView identity(uor_view_identity());
    UniqueView constant(uor_view_constant(17));

    uint8_t result = uor_view_apply(identity.get(), 42);
    std::cout << "Identity(42) = " << static_cast<int>(result) << std::endl;

    // Composition
    UniqueView composed(uor_view_compose(identity.get(), constant.get()));
    uint8_t comp = uor_view_apply(composed.get(), 100);
    std::cout << "Composed(100) = " << static_cast<int>(comp) << std::endl;

    return 0;
}
```

## API Overview

### Core Functions

- `byte_to_braille(value: u8) -> string` - Get Braille character (bijective mapping)
- `byte_to_codepoint(value: u8) -> u32` - Get Unicode codepoint
- `byte_to_domain(value: u8) -> u8` - Get triadic domain (Theta=0, Psi=1, Delta=2)
- `byte_rank(value: u8) -> u8` - Get rank within domain
- `byte_succ(value: u8) -> u8` - Successor in ring
- `byte_pred(value: u8) -> u8` - Predecessor in ring
- `byte_not(value: u8) -> u8` - Bitwise NOT

### FfiView (ElementWiseView)

256-byte lookup table for O(1) function composition.

**Constructors:**
- `FfiView()` - Identity view
- `FfiView.constant(value: u8)` - Constant view

**Methods:**
- `apply(byte_value: u8) -> u8` - Apply to single byte
- `apply_slice(input: bytes) -> bytes` - Apply to byte array (SIMD-accelerated)
- `then(other: FfiView) -> FfiView` - Compose views
- `is_bijective() -> bool` - Check if 1-to-1 mapping
- `inverse() -> Result<FfiView>` - Get inverse (if bijective)
- `table() -> bytes` - Get underlying 256-byte table

### Constants

- `braille_base() -> u32` - U+2800
- `braille_max() -> u32` - U+28FF
- `triadic_constant() -> u8` - T = 3
- `octave_constant() -> u8` - O = 8
- `state_taxons() -> u16` - 624
- `state_bits() -> u16` - 4992

## Performance

Benchmarked on Apple M3 (aarch64):

| Operation           | Time        | Overhead  |
| ------------------- | ----------- | --------- |
| `byte_to_codepoint` | 420 ps      | < 1 ns    |
| `byte_rank`         | 333 ps      | < 1 ns    |
| `byte_succ`         | 430 ps      | < 1 ns    |
| `byte_not`          | 431 ps      | < 1 ns    |
| `view_apply`        | 768 ps      | < 1 ns    |
| `byte_to_braille`   | 6.5 ns      | < 10 ns   |
| `apply_slice` (1KB) | 0.22 ns/byte| < 1 ns    |

**All operations meet the < 10 ns overhead requirement.**

## Testing

```bash
# Run Rust unit tests
cargo test -p uor-ffi

# Run benchmarks
cargo bench -p uor-ffi

# Test Python bindings (after generating)
cd bindings/python
python3 -c "import uor; print(uor.byte_to_braille(42))"

# Test WASM bindings (after building)
cd bindings/typescript
node test.js
```

## License

MIT OR Apache-2.0
