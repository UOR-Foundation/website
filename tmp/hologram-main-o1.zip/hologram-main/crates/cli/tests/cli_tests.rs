//! CLI integration tests.

#![allow(deprecated)] // cargo_bin is deprecated but works for our use case

use assert_cmd::Command;
use predicates::prelude::*;
use tempfile::TempDir;

/// Test that the CLI displays help.
#[test]
fn test_help() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.arg("--help")
        .assert()
        .success()
        .stdout(predicate::str::contains("Hologram"))
        .stdout(predicate::str::contains("compile"))
        .stdout(predicate::str::contains("run"))
        .stdout(predicate::str::contains("holo"))
        .stdout(predicate::str::contains("model"))
        .stdout(predicate::str::contains("registry"))
        .stdout(predicate::str::contains("metrics"));
}

/// Test that the CLI displays version.
#[test]
fn test_version() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.arg("--version")
        .assert()
        .success()
        .stdout(predicate::str::contains("hologram"));
}

/// Test compile command help.
#[test]
fn test_compile_help() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["compile", "--help"])
        .assert()
        .success()
        .stdout(predicate::str::contains("INPUT"))
        .stdout(predicate::str::contains("--output"));
}

/// Test run command help.
#[test]
fn test_run_help() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["run", "--help"])
        .assert()
        .success()
        .stdout(predicate::str::contains("MODEL"))
        .stdout(predicate::str::contains("--input"));
}

/// Test holo command help.
#[test]
fn test_holo_help() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["holo", "--help"])
        .assert()
        .success()
        .stdout(predicate::str::contains("pack"))
        .stdout(predicate::str::contains("unpack"))
        .stdout(predicate::str::contains("inspect"));
}

/// Test model command help.
#[test]
fn test_model_help() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["model", "--help"])
        .assert()
        .success()
        .stdout(predicate::str::contains("info"))
        .stdout(predicate::str::contains("validate"))
        .stdout(predicate::str::contains("benchmark"));
}

/// Test registry command help.
#[test]
fn test_registry_help() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["registry", "--help"])
        .assert()
        .success()
        .stdout(predicate::str::contains("publish"))
        .stdout(predicate::str::contains("fetch"))
        .stdout(predicate::str::contains("search"));
}

/// Test metrics command help.
#[test]
fn test_metrics_help() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["metrics", "--help"])
        .assert()
        .success()
        .stdout(predicate::str::contains("profile"))
        .stdout(predicate::str::contains("memory"))
        .stdout(predicate::str::contains("compare"));
}

/// Test compile with missing file.
#[test]
fn test_compile_missing_file() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["compile", "nonexistent.onnx"])
        .assert()
        .failure()
        .stderr(predicate::str::contains("file not found"));
}

/// Test holo inspect with missing file.
#[test]
fn test_holo_inspect_missing_file() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["holo", "inspect", "nonexistent.holo"])
        .assert()
        .failure()
        .stderr(predicate::str::contains("file not found"));
}

// ============================================================================
// End-to-End Model Tests (TASK-110)
// ============================================================================

/// JSON representation of a simple ReLU model.
///
/// Graph: Input(4) -> ReLU -> Output(4)
const SIMPLE_RELU_JSON: &str = r#"{
    "nodes": [
        {"id": 0, "op": "Input", "shape": [4], "dtype": "F32"},
        {"id": 1, "op": "Relu", "shape": [4], "dtype": "F32"},
        {"id": 2, "op": "Output", "shape": [4], "dtype": "F32"}
    ],
    "edges": [[0, 1], [1, 2]],
    "inputs": [["x", 0]],
    "outputs": [["y", 2]],
    "constants": []
}"#;

/// JSON representation of an Add model.
///
/// Graph: Input_a(4) + Input_b(4) -> Output(4)
const SIMPLE_ADD_JSON: &str = r#"{
    "nodes": [
        {"id": 0, "op": "Input", "shape": [4], "dtype": "F32"},
        {"id": 1, "op": "Input", "shape": [4], "dtype": "F32"},
        {"id": 2, "op": "Add", "shape": [4], "dtype": "F32"},
        {"id": 3, "op": "Output", "shape": [4], "dtype": "F32"}
    ],
    "edges": [[0, 2], [1, 2], [2, 3]],
    "inputs": [["a", 0], ["b", 1]],
    "outputs": [["y", 3]],
    "constants": []
}"#;

/// End-to-end test: compile a ReLU model from JSON.
#[test]
fn test_e2e_compile_relu_model() {
    let temp = TempDir::new().unwrap();
    let json_path = temp.path().join("relu.json");
    let holb_path = temp.path().join("relu.holb");

    // Write the JSON graph
    std::fs::write(&json_path, SIMPLE_RELU_JSON).unwrap();

    // Compile it
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args([
        "compile",
        json_path.to_str().unwrap(),
        "-o",
        holb_path.to_str().unwrap(),
    ])
    .assert()
    .success()
    .stdout(predicate::str::contains("Compiled"));

    // Verify the .holb file was created
    assert!(holb_path.exists());

    // Verify it has HOLB magic
    let bytes = std::fs::read(&holb_path).unwrap();
    assert_eq!(&bytes[0..4], b"HOLB");
}

/// End-to-end test: compile and inspect a model.
#[test]
fn test_e2e_compile_and_inspect() {
    let temp = TempDir::new().unwrap();
    let json_path = temp.path().join("model.json");
    let holb_path = temp.path().join("model.holb");

    // Write and compile
    std::fs::write(&json_path, SIMPLE_RELU_JSON).unwrap();

    Command::cargo_bin("hologram")
        .unwrap()
        .args([
            "compile",
            json_path.to_str().unwrap(),
            "-o",
            holb_path.to_str().unwrap(),
        ])
        .assert()
        .success();

    // Inspect the compiled model
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["holo", "inspect", holb_path.to_str().unwrap()])
        .assert()
        .success()
        .stdout(predicate::str::contains("HOLB"))
        .stdout(predicate::str::contains("Graph"));
}

/// End-to-end test: compile and validate a model.
#[test]
fn test_e2e_compile_and_validate() {
    let temp = TempDir::new().unwrap();
    let json_path = temp.path().join("model.json");
    let holb_path = temp.path().join("model.holb");

    // Write and compile
    std::fs::write(&json_path, SIMPLE_RELU_JSON).unwrap();

    Command::cargo_bin("hologram")
        .unwrap()
        .args([
            "compile",
            json_path.to_str().unwrap(),
            "-o",
            holb_path.to_str().unwrap(),
        ])
        .assert()
        .success();

    // Validate the model
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["model", "validate", holb_path.to_str().unwrap()])
        .assert()
        .success()
        .stdout(predicate::str::contains("valid"));
}

/// End-to-end test: compile, run and verify output of a model.
#[test]
fn test_e2e_compile_run_verify() {
    let temp = TempDir::new().unwrap();
    let json_path = temp.path().join("relu.json");
    let holb_path = temp.path().join("relu.holb");
    let input_path = temp.path().join("input.json");
    let output_path = temp.path().join("output.json");

    // Write the JSON graph
    std::fs::write(&json_path, SIMPLE_RELU_JSON).unwrap();

    // Compile it
    Command::cargo_bin("hologram")
        .unwrap()
        .args([
            "compile",
            json_path.to_str().unwrap(),
            "-o",
            holb_path.to_str().unwrap(),
        ])
        .assert()
        .success();

    // Create input data: [-1.0, 0.0, 1.0, 2.0]
    // After ReLU: [0.0, 0.0, 1.0, 2.0]
    std::fs::write(&input_path, "[-1.0, 0.0, 1.0, 2.0]").unwrap();

    // Run the model
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args([
        "run",
        holb_path.to_str().unwrap(),
        "--input",
        input_path.to_str().unwrap(),
        "--output",
        output_path.to_str().unwrap(),
    ])
    .assert()
    .success();

    // Verify output file exists
    assert!(output_path.exists());

    // Read and verify output
    let output = std::fs::read_to_string(&output_path).unwrap();
    let values: Vec<f32> = serde_json::from_str(&output).unwrap();

    // After ReLU: negative values become 0, positive values stay the same
    assert_eq!(values.len(), 4);
    assert!(values[0] >= 0.0); // -1.0 -> 0.0
    assert!((values[1] - 0.0).abs() < 0.01); // 0.0 -> 0.0
    assert!((values[2] - 1.0).abs() < 0.01); // 1.0 -> 1.0
    assert!((values[3] - 2.0).abs() < 0.01); // 2.0 -> 2.0
}

/// End-to-end test: pack multiple models into a HOLM archive.
#[test]
fn test_e2e_pack_unpack_models() {
    let temp = TempDir::new().unwrap();
    let json1 = temp.path().join("model1.json");
    let json2 = temp.path().join("model2.json");
    let holb1 = temp.path().join("model1.holb");
    let holb2 = temp.path().join("model2.holb");
    let holm = temp.path().join("pipeline.holm");
    let unpack_dir = temp.path().join("unpacked");

    // Create two models
    std::fs::write(&json1, SIMPLE_RELU_JSON).unwrap();
    std::fs::write(&json2, SIMPLE_ADD_JSON).unwrap();

    // Compile both
    for (json, holb) in [(&json1, &holb1), (&json2, &holb2)] {
        Command::cargo_bin("hologram")
            .unwrap()
            .args([
                "compile",
                json.to_str().unwrap(),
                "-o",
                holb.to_str().unwrap(),
            ])
            .assert()
            .success();
    }

    // Pack into HOLM
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args([
        "holo",
        "pack",
        holb1.to_str().unwrap(),
        holb2.to_str().unwrap(),
        "-o",
        holm.to_str().unwrap(),
    ])
    .assert()
    .success();

    // Verify HOLM was created
    assert!(holm.exists());
    let bytes = std::fs::read(&holm).unwrap();
    assert_eq!(&bytes[0..4], b"HOLM");

    // Unpack
    std::fs::create_dir(&unpack_dir).unwrap();
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args([
        "holo",
        "unpack",
        holm.to_str().unwrap(),
        "-o",
        unpack_dir.to_str().unwrap(),
    ])
    .assert()
    .success();

    // Verify unpacked models
    let unpacked_files: Vec<_> = std::fs::read_dir(&unpack_dir)
        .unwrap()
        .filter_map(|e| e.ok())
        .collect();
    assert_eq!(unpacked_files.len(), 2, "Expected 2 unpacked models");
}

/// End-to-end test: model info command.
#[test]
fn test_e2e_model_info() {
    let temp = TempDir::new().unwrap();
    let json_path = temp.path().join("model.json");
    let holb_path = temp.path().join("model.holb");

    std::fs::write(&json_path, SIMPLE_RELU_JSON).unwrap();

    Command::cargo_bin("hologram")
        .unwrap()
        .args([
            "compile",
            json_path.to_str().unwrap(),
            "-o",
            holb_path.to_str().unwrap(),
            "--name",
            "test-relu",
        ])
        .assert()
        .success();

    // Get model info
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["model", "info", holb_path.to_str().unwrap()])
        .assert()
        .success()
        .stdout(predicate::str::contains("test-relu"))
        .stdout(predicate::str::contains("Instructions"))
        .stdout(predicate::str::contains("Buffers"));
}

// ============================================================================
// Tokenizer Integration Tests (TASK-248)
// ============================================================================

/// Sample tokenizer.json in HuggingFace format.
const SAMPLE_TOKENIZER_JSON: &str = r#"{
    "model": {
        "vocab": [
            ["<pad>", 0.0],
            ["</s>", 0.0],
            ["<unk>", 0.0],
            ["\u2581", -0.5],
            ["\u2581hello", -1.0],
            ["\u2581world", -1.5],
            ["h", -2.0],
            ["e", -2.0],
            ["l", -2.0],
            ["o", -2.0],
            ["w", -2.0],
            ["r", -2.0],
            ["d", -2.0]
        ]
    },
    "added_tokens": [
        {"id": 0, "content": "<pad>", "special": true},
        {"id": 1, "content": "</s>", "special": true},
        {"id": 2, "content": "<unk>", "special": true}
    ]
}"#;

/// Test tokenizer command help.
#[test]
fn test_tokenizer_help() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["tokenizer", "--help"])
        .assert()
        .success()
        .stdout(predicate::str::contains("compile"))
        .stdout(predicate::str::contains("info"));
}

/// Test tokenizer compile help.
#[test]
fn test_tokenizer_compile_help() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["tokenizer", "compile", "--help"])
        .assert()
        .success()
        .stdout(predicate::str::contains("INPUT"))
        .stdout(predicate::str::contains("--output"));
}

/// End-to-end test: compile a tokenizer.json to .holo format.
#[test]
fn test_e2e_tokenizer_compile() {
    let temp = TempDir::new().unwrap();
    let json_path = temp.path().join("tokenizer.json");
    let holo_path = temp.path().join("tokenizer.holo");

    // Write the tokenizer JSON
    std::fs::write(&json_path, SAMPLE_TOKENIZER_JSON).unwrap();

    // Compile it
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args([
        "tokenizer",
        "compile",
        json_path.to_str().unwrap(),
        "-o",
        holo_path.to_str().unwrap(),
    ])
    .assert()
    .success()
    .stdout(predicate::str::contains("Compiled"));

    // Verify the .holo file was created
    assert!(holo_path.exists());

    // Verify it has TOKE magic (tokenizer format magic 0x544F4B45 = "TOKE" in little-endian)
    let bytes = std::fs::read(&holo_path).unwrap();
    let magic = u32::from_le_bytes(bytes[0..4].try_into().unwrap());
    assert_eq!(magic, 0x544F4B45, "Expected TOKE magic");
}

/// End-to-end test: compile tokenizer with default output path.
#[test]
fn test_e2e_tokenizer_compile_default_output() {
    let temp = TempDir::new().unwrap();
    let json_path = temp.path().join("my_tokenizer.json");

    // Write the tokenizer JSON
    std::fs::write(&json_path, SAMPLE_TOKENIZER_JSON).unwrap();

    // Compile without explicit output (should create my_tokenizer.holo)
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["tokenizer", "compile", json_path.to_str().unwrap()])
        .assert()
        .success();

    // Verify default output path
    let expected_output = temp.path().join("my_tokenizer.holo");
    assert!(
        expected_output.exists(),
        "Expected output at {:?}",
        expected_output
    );
}

/// End-to-end test: compile tokenizer and get info.
#[test]
fn test_e2e_tokenizer_compile_and_info() {
    let temp = TempDir::new().unwrap();
    let json_path = temp.path().join("tokenizer.json");
    let holo_path = temp.path().join("tokenizer.holo");

    // Write and compile
    std::fs::write(&json_path, SAMPLE_TOKENIZER_JSON).unwrap();

    Command::cargo_bin("hologram")
        .unwrap()
        .args([
            "tokenizer",
            "compile",
            json_path.to_str().unwrap(),
            "-o",
            holo_path.to_str().unwrap(),
        ])
        .assert()
        .success();

    // Get tokenizer info (output has ANSI color codes, so use regex)
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["tokenizer", "info", holo_path.to_str().unwrap()])
        .assert()
        .success()
        .stdout(predicate::str::contains("Vocab size"))
        // Check the content appears (color codes in between)
        .stdout(predicate::str::is_match(r"pad=.*0").unwrap())
        .stdout(predicate::str::is_match(r"eos=.*1").unwrap())
        .stdout(predicate::str::is_match(r"unk=.*2").unwrap());
}

/// End-to-end test: compile tokenizer and get verbose info.
#[test]
fn test_e2e_tokenizer_info_verbose() {
    let temp = TempDir::new().unwrap();
    let json_path = temp.path().join("tokenizer.json");
    let holo_path = temp.path().join("tokenizer.holo");

    std::fs::write(&json_path, SAMPLE_TOKENIZER_JSON).unwrap();

    Command::cargo_bin("hologram")
        .unwrap()
        .args([
            "tokenizer",
            "compile",
            json_path.to_str().unwrap(),
            "-o",
            holo_path.to_str().unwrap(),
        ])
        .assert()
        .success();

    // Get verbose tokenizer info
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["-v", "tokenizer", "info", holo_path.to_str().unwrap()])
        .assert()
        .success()
        .stdout(predicate::str::contains("Tokenizer Info"))
        .stdout(predicate::str::contains("Normalizer steps"));
}

/// Test tokenizer compile with missing input file.
#[test]
fn test_tokenizer_compile_missing_file() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["tokenizer", "compile", "/nonexistent/tokenizer.json"])
        .assert()
        .failure()
        .stderr(predicate::str::contains("not found"));
}

/// Test tokenizer info with missing file.
#[test]
fn test_tokenizer_info_missing_file() {
    let mut cmd = Command::cargo_bin("hologram").unwrap();
    cmd.args(["tokenizer", "info", "/nonexistent/tokenizer.holo"])
        .assert()
        .failure()
        .stderr(predicate::str::contains("not found"));
}
