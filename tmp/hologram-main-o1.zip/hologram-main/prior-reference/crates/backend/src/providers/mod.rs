//! Additional constant providers for specialized sources.
//!
//! This module groups higher-level `ConstProvider` implementations for
//! networking, orchestration-aware fetch, encryption, and shared mmap reuse.

pub mod const_provider;

#[cfg(feature = "const-provider-http")]
mod http;
#[cfg(feature = "const-provider-http")]
pub use http::HttpConstProvider;

#[cfg(feature = "const-provider-peer")]
mod peer;
#[cfg(feature = "const-provider-peer")]
pub use peer::PeerHttpConstProvider;

mod shared;
pub use shared::{SharedMmapProvider, SharedMmapRegistry};

mod encrypted;
pub use encrypted::XorEncryptedConstProvider;

// Re-export core providers for convenience so callers can use a single module.
pub use const_provider::{
    ChunkedFileConstProvider as CoreChunkedFileConstProvider, ConstChunk, ConstProvider,
    MmapConstProvider as CoreMmapConstProvider,
    StreamingConstProvider as CoreStreamingConstProvider,
};
