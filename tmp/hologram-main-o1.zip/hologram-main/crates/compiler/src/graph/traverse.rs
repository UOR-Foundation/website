//! Internal compiler graph using hologram-graph.

use std::collections::HashMap;

use hologram_graph::{toposort, ComputeGraph, CycleError, InputSource, NodeId};

use super::node::{ConstantData, DType, OpKind, OpNode, OperationGraph};
use crate::error::CompileError;

/// Epilogue chain fused into a kernel's writeback phase.
///
/// This allows a single kernel to apply bias, activation, and scaling
/// in one memory pass instead of requiring separate operations.
#[derive(Debug, Clone, Default)]
pub struct EpilogueChain {
    /// Fused bias addition (node ID of the Add op with Constant input).
    pub bias_add: Option<u32>,
    /// Fused activation function (node ID of the activation op).
    pub activation: Option<u32>,
    /// Fused scaling (node ID of the Mul op with Constant input).
    pub scale: Option<u32>,
}

impl EpilogueChain {
    /// Check if any epilogue operations are fused.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.bias_add.is_none() && self.activation.is_none() && self.scale.is_none()
    }
}

/// Compiler operation with metadata assigned during compilation stages.
#[derive(Debug, Clone)]
pub struct CompileOp {
    /// Operation kind.
    pub op: OpKind,
    /// Output shape.
    pub shape: Vec<usize>,
    /// Data type.
    pub dtype: DType,
    /// Optional debug name.
    pub name: Option<String>,
    /// Assigned kernel (after Stage 3).
    pub kernel: Option<u32>,
    /// Assigned layout (after Stage 4).
    pub layout: Option<u32>,
    /// Workspace slot (after Stage 5).
    pub workspace_slot: Option<u32>,
    /// Thread assignment (after Stage 6).
    pub thread_id: Option<u32>,
    /// Fused epilogue chain (after Stage 7).
    pub epilogue: EpilogueChain,
    /// Compiler annotations (e.g., "decomposed:4x4", "batch:1024").
    pub annotations: Vec<String>,
}

impl CompileOp {
    /// Create a new compile operation from an `OpNode`.
    #[must_use]
    pub fn from_op_node(node: &OpNode) -> Self {
        Self {
            op: node.op.clone(),
            shape: node.shape.clone(),
            dtype: node.dtype,
            name: node.name.clone(),
            kernel: None,
            layout: None,
            workspace_slot: None,
            thread_id: None,
            epilogue: EpilogueChain::default(),
            annotations: Vec::new(),
        }
    }
}

/// Internal compiler DAG using hologram-graph.
#[derive(Debug, Clone)]
pub struct CompileGraph {
    /// The underlying compute graph.
    graph: ComputeGraph<CompileOp>,
    /// Cached topological order as `NodeId`s.
    topo_order: Vec<NodeId>,
    /// Map from original u32 IDs to `NodeId`s.
    id_map: Vec<Option<NodeId>>,
    /// Named inputs.
    inputs: Vec<(String, u32)>,
    /// Named outputs.
    outputs: Vec<(String, u32)>,
    /// Constant node IDs in insertion order.
    /// This preserves the order constants were added via `add_constant()`.
    constant_nodes_order: Vec<u32>,
    /// Folded constant data from constant folding pass.
    /// Maps node IDs of nodes that were folded to their computed `ConstantData`.
    folded_constants: HashMap<u32, ConstantData>,
}

impl Default for CompileGraph {
    fn default() -> Self {
        Self {
            graph: ComputeGraph::new(),
            topo_order: Vec::new(),
            id_map: Vec::new(),
            inputs: Vec::new(),
            outputs: Vec::new(),
            constant_nodes_order: Vec::new(),
            folded_constants: HashMap::new(),
        }
    }
}

impl CompileGraph {
    /// Convert from `OperationGraph`.
    ///
    /// # Errors
    ///
    /// Returns `CompileError::CycleDetected` if the graph contains cycles.
    pub fn from_operation_graph(op_graph: &OperationGraph) -> Result<Self, CompileError> {
        let mut graph = ComputeGraph::with_capacity(op_graph.nodes.len());
        let mut id_map: Vec<Option<NodeId>> = vec![None; op_graph.nodes.len() + 1];

        // Add nodes
        for node in &op_graph.nodes {
            let compile_op = CompileOp::from_op_node(node);
            let node_id = graph.add_node(compile_op);

            // Ensure id_map is large enough
            while id_map.len() <= node.id as usize {
                id_map.push(None);
            }
            id_map[node.id as usize] = Some(node_id);
        }

        // Determine constant node order:
        // - Use explicit constant_node_ids if populated (preferred, order-independent)
        // - Fall back to iteration-based collection for legacy graphs
        let constant_nodes_order = if op_graph.constant_node_ids.is_empty() {
            // Legacy fallback: collect constant nodes in iteration order
            // This assumes add_node() and add_constant() were called in matching order
            op_graph
                .nodes
                .iter()
                .filter(|n| matches!(n.op, OpKind::Constant))
                .map(|n| n.id)
                .collect()
        } else {
            // Explicit mapping: use directly (this is the correct order)
            op_graph.constant_node_ids.clone()
        };

        // Add edges
        for &(src, dst) in &op_graph.edges {
            if let (Some(src_id), Some(dst_id)) = (
                id_map.get(src as usize).and_then(|x| *x),
                id_map.get(dst as usize).and_then(|x| *x),
            ) {
                graph.add_edge(src_id, dst_id);
            }
        }

        // Compute topological order
        let topo_order = toposort(&graph).map_err(|_: CycleError| CompileError::CycleDetected)?;

        Ok(Self {
            graph,
            topo_order,
            id_map,
            inputs: op_graph.inputs.clone(),
            outputs: op_graph.outputs.clone(),
            constant_nodes_order,
            folded_constants: HashMap::new(),
        })
    }

    /// Get a node by original u32 id.
    #[must_use]
    pub fn get_node(&self, id: u32) -> Option<&CompileOp> {
        let node_id = self.id_map.get(id as usize)?.as_ref()?;
        self.graph.get(*node_id).map(|n| &n.op)
    }

    /// Get a mutable node by original u32 id.
    pub fn get_node_mut(&mut self, id: u32) -> Option<&mut CompileOp> {
        let node_id = self.id_map.get(id as usize)?.as_ref()?;
        self.graph.get_mut(*node_id).map(|n| &mut n.op)
    }

    /// Get the `NodeId` for an original u32 id.
    #[must_use]
    pub fn get_node_id(&self, id: u32) -> Option<NodeId> {
        self.id_map.get(id as usize).and_then(|x| *x)
    }

    /// Remove a node by original u32 id.
    pub fn remove_node(&mut self, id: u32) {
        if let Some(Some(node_id)) = self.id_map.get(id as usize) {
            self.graph.remove_node(*node_id);
            self.id_map[id as usize] = None;
        }
    }

    /// Return the topological order as original u32 IDs.
    #[must_use]
    pub fn topo_order(&self) -> Vec<u32> {
        self.topo_order
            .iter()
            .filter_map(|&node_id| self.node_id_to_u32(node_id))
            .collect()
    }

    /// Return predecessors of a node by original u32 id.
    #[must_use]
    pub fn predecessors(&self, id: u32) -> Vec<u32> {
        let Some(node_id) = self.get_node_id(id) else {
            return Vec::new();
        };
        self.graph
            .predecessors(node_id)
            .into_iter()
            .filter_map(|pred| self.node_id_to_u32(pred))
            .collect()
    }

    /// Return successors of a node by original u32 id.
    #[must_use]
    pub fn successors(&self, id: u32) -> Vec<u32> {
        let Some(node_id) = self.get_node_id(id) else {
            return Vec::new();
        };
        self.graph
            .successors(node_id)
            .iter()
            .filter_map(|&succ| self.node_id_to_u32(succ))
            .collect()
    }

    /// Iterate over active nodes with their original u32 IDs.
    pub fn nodes(&self) -> impl Iterator<Item = (u32, &CompileOp)> {
        self.id_map.iter().enumerate().filter_map(|(idx, opt_id)| {
            let node_id = (*opt_id)?;
            let node = self.graph.get(node_id)?;
            #[allow(clippy::cast_possible_truncation)]
            Some((idx as u32, &node.op))
        })
    }

    /// Iterate over active nodes mutably with their original u32 IDs.
    pub fn nodes_mut(&mut self) -> impl Iterator<Item = &mut CompileOp> {
        self.graph.nodes_mut().map(|n| &mut n.op)
    }

    /// Return the number of active nodes.
    #[must_use]
    pub fn node_count(&self) -> usize {
        self.graph.node_count()
    }

    /// Return all edges as (source, target) pairs of original u32 IDs.
    #[must_use]
    pub fn edges(&self) -> Vec<(u32, u32)> {
        self.graph
            .edges()
            .iter()
            .filter_map(|&(src, dst)| {
                let src_u32 = self.node_id_to_u32(src)?;
                let dst_u32 = self.node_id_to_u32(dst)?;
                Some((src_u32, dst_u32))
            })
            .collect()
    }

    /// Return named inputs.
    #[must_use]
    pub fn inputs(&self) -> &[(String, u32)] {
        &self.inputs
    }

    /// Return named outputs.
    #[must_use]
    pub fn outputs(&self) -> &[(String, u32)] {
        &self.outputs
    }

    /// Return constant node IDs in the order they were added.
    ///
    /// This preserves the insertion order from `OperationGraph`, which matches
    /// the order of `graph.constants[]`. Critical for correct constant mapping.
    #[must_use]
    pub fn constant_nodes_in_order(&self) -> &[u32] {
        &self.constant_nodes_order
    }

    /// Add a folded constant from constant folding pass.
    ///
    /// This stores the computed `ConstantData` for a node that was converted
    /// to `OpKind::Constant` by the constant folding pass.
    pub fn add_folded_constant(&mut self, node_id: u32, data: ConstantData) {
        self.folded_constants.insert(node_id, data);
    }

    /// Get a folded constant by node ID.
    ///
    /// Returns the computed `ConstantData` if this node was folded to a constant,
    /// or `None` if it was an original constant or not a constant at all.
    #[must_use]
    pub fn get_folded_constant(&self, node_id: u32) -> Option<&ConstantData> {
        self.folded_constants.get(&node_id)
    }

    /// Add an annotation to a node.
    ///
    /// Annotations are string tags used by compiler passes to mark nodes for
    /// special handling during later stages (e.g., `lut_gemm:4` for LUT-based `MatMul`).
    pub fn add_annotation(&mut self, node_id: u32, annotation: String) {
        if let Some(node) = self.get_node_mut(node_id) {
            node.annotations.push(annotation);
        }
    }

    /// Get annotations for a node.
    #[must_use]
    pub fn get_annotations(&self, node_id: u32) -> Option<&[String]> {
        self.get_node(node_id).map(|n| n.annotations.as_slice())
    }

    /// Check if a node has a specific annotation prefix.
    #[must_use]
    pub fn has_annotation_prefix(&self, node_id: u32, prefix: &str) -> bool {
        self.get_annotations(node_id)
            .is_some_and(|anns| anns.iter().any(|a| a.starts_with(prefix)))
    }

    /// Get all folded constants.
    ///
    /// Returns a reference to the map of node IDs to their computed constant data.
    #[must_use]
    pub fn folded_constants(&self) -> &HashMap<u32, ConstantData> {
        &self.folded_constants
    }

    /// Get the maximum node ID in the graph.
    ///
    /// Used for generating unique IDs for new constant nodes.
    #[must_use]
    #[allow(clippy::cast_possible_truncation)] // Node IDs fit in u32
    pub fn max_node_id(&self) -> u32 {
        // Check both the id_map size and folded_constants keys
        let map_max = self.id_map.len() as u32;
        let folded_max = self.folded_constants.keys().copied().max().unwrap_or(0);
        map_max.max(folded_max)
    }

    /// Replace a node's operation kind.
    ///
    /// Useful for constant folding where we convert operations to constants.
    pub fn replace_op(&mut self, id: u32, new_op: OpKind) -> bool {
        if let Some(node) = self.get_node_mut(id) {
            node.op = new_op;
            true
        } else {
            false
        }
    }

    /// Rewire all successors of `old_id` to instead depend on `new_id`.
    ///
    /// Used by CSE to merge duplicate nodes.
    pub fn rewire_successors(&mut self, old_id: u32, new_id: u32) {
        let Some(old_node_id) = self.get_node_id(old_id) else {
            return;
        };
        let Some(new_node_id) = self.get_node_id(new_id) else {
            return;
        };

        // Find all nodes that have old_node_id as a predecessor
        for node in self.graph.nodes_mut() {
            for input in &mut node.inputs {
                if input.source == InputSource::Node(old_node_id) {
                    input.source = InputSource::Node(new_node_id);
                }
            }
        }
    }

    /// Replace a specific predecessor of a node with a new predecessor.
    ///
    /// Used by activation fusion to rewire chain inputs.
    pub fn replace_predecessor(&mut self, node_id: u32, old_pred: u32, new_pred: u32) {
        let Some(target) = self.get_node_id(node_id) else {
            return;
        };
        let Some(old_pred_id) = self.get_node_id(old_pred) else {
            return;
        };
        let Some(new_pred_id) = self.get_node_id(new_pred) else {
            return;
        };

        if let Some(node) = self.graph.get_mut(target) {
            for input in &mut node.inputs {
                if input.source == InputSource::Node(old_pred_id) {
                    input.source = InputSource::Node(new_pred_id);
                }
            }
        }
    }

    /// Check if a node has the given operation kind.
    #[must_use]
    pub fn is_op_kind(&self, id: u32, kind: &OpKind) -> bool {
        self.get_node(id)
            .is_some_and(|n| std::mem::discriminant(&n.op) == std::mem::discriminant(kind))
    }

    /// Check if a node is a constant.
    #[must_use]
    pub fn is_constant(&self, id: u32) -> bool {
        self.get_node(id)
            .is_some_and(|n| matches!(n.op, OpKind::Constant))
    }

    /// Check if all predecessors of a node are constants.
    #[must_use]
    pub fn all_predecessors_constant(&self, id: u32) -> bool {
        let preds = self.predecessors(id);
        !preds.is_empty() && preds.iter().all(|&p| self.is_constant(p))
    }

    /// Convert a `NodeId` back to the original u32 ID.
    fn node_id_to_u32(&self, node_id: NodeId) -> Option<u32> {
        #[allow(clippy::cast_possible_truncation)]
        self.id_map
            .iter()
            .enumerate()
            .find(|(_, opt)| opt.map(|id| id == node_id).unwrap_or(false))
            .map(|(idx, _)| idx as u32)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn simple_graph() -> OperationGraph {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 2], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 2], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![1, 2], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph
    }

    #[test]
    fn test_from_operation_graph() {
        let graph = simple_graph();
        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        assert_eq!(compile_graph.node_count(), 3);
    }

    #[test]
    fn test_topo_order() {
        let graph = simple_graph();
        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        let order = compile_graph.topo_order();
        // Node 0 must come before 1, node 1 before 2
        let pos_0 = order.iter().position(|&x| x == 0).unwrap();
        let pos_1 = order.iter().position(|&x| x == 1).unwrap();
        let pos_2 = order.iter().position(|&x| x == 2).unwrap();
        assert!(pos_0 < pos_1);
        assert!(pos_1 < pos_2);
    }

    #[test]
    fn test_predecessors_successors() {
        let graph = simple_graph();
        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        assert_eq!(compile_graph.predecessors(1), vec![0]);
        assert_eq!(compile_graph.successors(1), vec![2]);
    }

    #[test]
    fn test_cycle_detection() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Add, vec![1], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Add, vec![1], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 0); // Cycle!
        let result = CompileGraph::from_operation_graph(&graph);
        assert!(matches!(result, Err(CompileError::CycleDetected)));
    }

    #[test]
    fn test_remove_node() {
        let graph = simple_graph();
        let mut compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        compile_graph.remove_node(1);
        assert_eq!(compile_graph.node_count(), 2);
        assert!(compile_graph.get_node(1).is_none());
    }

    #[test]
    fn test_get_node() {
        let graph = simple_graph();
        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();

        let node = compile_graph.get_node(0).unwrap();
        assert!(matches!(node.op, OpKind::Input));

        let node = compile_graph.get_node(1).unwrap();
        assert!(matches!(node.op, OpKind::Relu));
    }

    #[test]
    fn test_get_node_mut() {
        let graph = simple_graph();
        let mut compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();

        // Modify kernel assignment
        if let Some(node) = compile_graph.get_node_mut(1) {
            node.kernel = Some(42);
        }

        assert_eq!(compile_graph.get_node(1).unwrap().kernel, Some(42));
    }

    #[test]
    fn test_nodes_iteration() {
        let graph = simple_graph();
        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();

        let count = compile_graph.nodes().count();
        assert_eq!(count, 3);
    }

    #[test]
    fn test_edges() {
        let graph = simple_graph();
        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();

        let edges = compile_graph.edges();
        assert_eq!(edges.len(), 2);
        assert!(edges.contains(&(0, 1)));
        assert!(edges.contains(&(1, 2)));
    }
}
