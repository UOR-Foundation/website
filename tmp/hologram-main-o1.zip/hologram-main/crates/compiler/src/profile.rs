//! Compilation profiling data structures and utilities.
//!
//! When the `instrumentation` feature is enabled, timing data for each
//! compilation stage is recorded to the global metrics registry.
//! This module provides utilities to extract and format that data.

use std::collections::BTreeMap;
use std::fmt::Write;
use std::time::Duration;

/// Profiling data from a compilation run.
#[derive(Debug, Clone, Default)]
pub struct CompileProfile {
    /// Per-stage timing data (stage name → duration).
    pub stages: BTreeMap<String, Duration>,
    /// Total compilation time.
    pub total: Duration,
}

impl CompileProfile {
    /// Create an empty profile.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Record a stage timing.
    pub fn record(&mut self, stage: &str, duration: Duration) {
        self.stages.insert(stage.to_string(), duration);
    }

    /// Get total compilation time.
    #[must_use]
    pub fn total_time(&self) -> Duration {
        self.total
    }

    /// Format as a human-readable report.
    #[must_use]
    pub fn format_report(&self) -> String {
        let mut report = String::new();
        report.push_str("Compilation Profile:\n");
        report.push_str("─────────────────────────────────────\n");

        let mut sorted: Vec<_> = self.stages.iter().collect();
        sorted.sort_by_key(|(k, _)| *k);

        for (stage, duration) in sorted {
            let name = stage.replace("compile_", "").replace('_', " ");
            let _ = writeln!(
                report,
                "  {:30} {:>10.3}ms",
                name,
                duration.as_secs_f64() * 1000.0
            );
        }

        report.push_str("─────────────────────────────────────\n");
        let _ = writeln!(
            report,
            "  {:30} {:>10.3}ms",
            "TOTAL",
            self.total.as_secs_f64() * 1000.0
        );
        report
    }

    /// Export as JSON.
    #[must_use]
    pub fn to_json(&self) -> String {
        let mut json = String::from("{\n");
        json.push_str("  \"stages\": {\n");

        let entries: Vec<_> = self.stages.iter().collect();
        for (i, (stage, duration)) in entries.iter().enumerate() {
            let comma = if i < entries.len() - 1 { "," } else { "" };
            let _ = writeln!(
                json,
                "    \"{}\": {:.6}{}",
                stage,
                duration.as_secs_f64() * 1000.0,
                comma
            );
        }

        json.push_str("  },\n");
        let _ = writeln!(
            json,
            "  \"total_ms\": {:.6}",
            self.total.as_secs_f64() * 1000.0
        );
        json.push_str("}\n");
        json
    }
}

/// Capture profiling data from the global metrics registry.
///
/// This function extracts timing histograms for compilation stages
/// from the telemetry registry. Only available when `instrumentation`
/// feature is enabled.
#[cfg(feature = "instrumentation")]
#[must_use]
pub fn capture_profile() -> CompileProfile {
    use hologram_telemetry::MetricsRegistry;

    let registry = MetricsRegistry::global();
    let histograms = registry.histograms();

    let mut profile = CompileProfile::new();
    let mut total = Duration::ZERO;

    for (name, summary) in histograms {
        if name.starts_with("compile_stage") && !summary.is_empty() {
            let duration = Duration::from_secs_f64(summary.mean);
            profile.record(name, duration);
            total += duration;
        }
    }

    profile.total = total;
    profile
}

/// Capture profiling data (no-op when instrumentation is disabled).
#[cfg(not(feature = "instrumentation"))]
#[must_use]
pub fn capture_profile() -> CompileProfile {
    CompileProfile::new()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_profile_creation() {
        let profile = CompileProfile::new();
        assert!(profile.stages.is_empty());
        assert_eq!(profile.total, Duration::ZERO);
    }

    #[test]
    fn test_profile_record() {
        let mut profile = CompileProfile::new();
        profile.record("stage1", Duration::from_millis(10));
        profile.record("stage2", Duration::from_millis(20));

        assert_eq!(profile.stages.len(), 2);
        assert_eq!(profile.stages["stage1"], Duration::from_millis(10));
    }

    #[test]
    fn test_profile_format_report() {
        let mut profile = CompileProfile::new();
        profile.record("compile_stage1_ir", Duration::from_millis(5));
        profile.record("compile_stage2_fusion", Duration::from_millis(15));
        profile.total = Duration::from_millis(20);

        let report = profile.format_report();
        assert!(report.contains("stage1 ir"));
        assert!(report.contains("stage2 fusion"));
        assert!(report.contains("TOTAL"));
    }

    #[test]
    fn test_profile_to_json() {
        let mut profile = CompileProfile::new();
        profile.record("stage1", Duration::from_millis(10));
        profile.total = Duration::from_millis(10);

        let json = profile.to_json();
        assert!(json.contains("\"stage1\""));
        assert!(json.contains("\"total_ms\""));
    }

    #[test]
    fn test_capture_profile_without_instrumentation() {
        // Should return empty profile when instrumentation is disabled
        let profile = capture_profile();
        // With instrumentation disabled, we get an empty profile
        // (or with instrumentation enabled, we get whatever was recorded)
        let _ = profile; // Just verify it compiles
    }
}
