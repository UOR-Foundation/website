//! FFI integration tests — exercises the full API surface from an external crate perspective.
//!
//! These tests verify that the public API works correctly when called as a library consumer,
//! catching re-export issues, type mismatches, and boundary conditions.

use uor_ffi::{
    abs_lut,
    braille_base,
    braille_max,
    // Core
    byte_not,
    byte_pred,
    byte_rank,
    byte_succ,
    byte_to_braille,
    byte_to_codepoint,
    byte_to_domain,
    curvature_q0,
    curvature_q1,
    domain_q0,
    octave_constant,
    orbit_class_q0,
    rank_q0,
    relu_lut,
    // LUT activations
    sigmoid_lut,
    state_bits,
    state_taxons,
    // LUT Q0
    stratum_q0,
    // LUT Q1
    stratum_q1,
    torus_offset_q0,
    torus_page_q0,
    triadic_constant,
    // Datum types
    FfiDatum16,
    FfiDatum16Proof,
    FfiState,
    FfiView,
    // Word types
    FfiWord2,
    FfiWord4,
    FfiWord8,
};

// ============================================================================
// Core API integration
// ============================================================================

#[test]
fn integration_constants() {
    assert_eq!(braille_base(), 0x2800);
    assert_eq!(braille_max(), 0x28FF);
    assert_eq!(triadic_constant(), 3);
    assert_eq!(octave_constant(), 8);
    assert_eq!(state_taxons(), 624);
    assert_eq!(state_bits(), 4992);
}

#[test]
fn integration_byte_braille_bijection() {
    let mut seen = std::collections::HashSet::new();
    for i in 0..=255u8 {
        let braille = byte_to_braille(i);
        assert!(!braille.is_empty());
        assert!(seen.insert(braille), "Duplicate braille for byte {}", i);
    }
    assert_eq!(seen.len(), 256);
}

#[test]
fn integration_byte_codepoint_range() {
    for i in 0..=255u8 {
        let cp = byte_to_codepoint(i);
        assert!(
            (0x2800..=0x28FF).contains(&cp),
            "Codepoint {} out of Braille range",
            cp
        );
    }
}

#[test]
fn integration_domain_triadic() {
    for i in 0..=255u8 {
        let d = byte_to_domain(i);
        assert!(d < 3, "Domain {} not in [0,2]", d);
    }
}

#[test]
fn integration_ring_successor_cycle() {
    let mut val = 0u8;
    for _ in 0..256 {
        val = byte_succ(val);
    }
    assert_eq!(val, 0, "Successor should cycle back to 0 after 256 steps");
}

#[test]
fn integration_ring_predecessor_inverse() {
    for i in 0..=255u8 {
        assert_eq!(byte_pred(byte_succ(i)), i);
        assert_eq!(byte_succ(byte_pred(i)), i);
    }
}

#[test]
fn integration_byte_not_involution() {
    for i in 0..=255u8 {
        assert_eq!(byte_not(byte_not(i)), i);
    }
}

#[test]
fn integration_state_zero() {
    let state = FfiState::new();
    assert!(state.is_zero());
    assert_eq!(state.as_bytes().len(), 624);
}

#[test]
fn integration_state_roundtrip() {
    let mut data = vec![0u8; 624];
    data[0] = 42;
    data[623] = 99;
    let state = FfiState::from_bytes(data.clone()).unwrap();
    assert_eq!(state.get_taxon(0).unwrap(), 42);
    assert_eq!(state.get_taxon(623).unwrap(), 99);
    assert_eq!(state.as_bytes(), data);
}

#[test]
fn integration_view_identity_preserves() {
    let view = FfiView::identity();
    for i in 0..=255u8 {
        assert_eq!(view.apply(i), i);
    }
}

#[test]
fn integration_view_composition_associative() {
    let id = std::sync::Arc::new(FfiView::identity());
    let not = id.inverse().unwrap();
    let composed = id.clone().then(not.clone());
    let double = not.clone().then(not.clone());

    for i in 0..=255u8 {
        assert_eq!(composed.apply(i), not.apply(i));
        assert_eq!(double.apply(i), i); // NOT(NOT(x)) = x
    }
}

// ============================================================================
// LUT Q0 integration
// ============================================================================

#[test]
fn integration_q0_exhaustive_stratum() {
    for i in 0..=255u8 {
        assert_eq!(stratum_q0(i), i.count_ones() as u8);
    }
}

#[test]
fn integration_q0_domain_matches_core() {
    for i in 0..=255u8 {
        assert_eq!(domain_q0(i), byte_to_domain(i));
    }
}

#[test]
fn integration_q0_rank_matches_core() {
    for i in 0..=255u8 {
        assert_eq!(rank_q0(i), byte_rank(i));
    }
}

#[test]
fn integration_q0_orbit_class_range() {
    for i in 0..=255u8 {
        assert!(orbit_class_q0(i) < 32);
    }
}

#[test]
fn integration_q0_torus_page_range() {
    for i in 0..=255u8 {
        assert!(torus_page_q0(i) < 32);
    }
}

#[test]
fn integration_q0_torus_offset_binary() {
    for i in 0..=255u8 {
        assert!(torus_offset_q0(i) < 8);
    }
}

#[test]
fn integration_q0_curvature_range() {
    for i in 0..=255u8 {
        let c = curvature_q0(i);
        assert!(
            (1..=8).contains(&c),
            "Curvature {} out of [1,8] for byte {}",
            c,
            i
        );
    }
}

// ============================================================================
// Activation functions integration
// ============================================================================

#[test]
fn integration_activation_sigmoid_monotone() {
    // For signed interpretation: values 0..127 (positive) should have sigmoid >= 128
    for i in 0..64u8 {
        assert!(
            sigmoid_lut(i) >= 128,
            "sigmoid({}) = {} < 128",
            i,
            sigmoid_lut(i)
        );
    }
}

#[test]
fn integration_activation_relu_nonnegative() {
    for i in 0..=255u8 {
        let r = relu_lut(i);
        // ReLU: unsigned values 0-127 preserved, 128-255 (negative signed) -> 0
        if i < 128 {
            assert_eq!(r, i);
        } else {
            assert_eq!(r, 0);
        }
    }
}

#[test]
fn integration_activation_abs_nonnegative() {
    for i in 0..=127u8 {
        assert_eq!(abs_lut(i), i);
    }
}

// ============================================================================
// Q1 integration
// ============================================================================

#[test]
fn integration_q1_stratum_popcount() {
    for v in [0u16, 1, 0xFF, 0x100, 0x1234, 0xFFFF] {
        assert_eq!(stratum_q1(v), v.count_ones() as u8);
    }
}

#[test]
fn integration_q1_curvature_boundary() {
    assert_eq!(curvature_q1(0), 1);
    assert_eq!(curvature_q1(0xFFFF), 16);
}

// ============================================================================
// Word type integration
// ============================================================================

#[test]
fn integration_word2_roundtrip() {
    for v in [0u16, 1, 0x1234, 0xFFFF] {
        let w = FfiWord2::new(v);
        assert_eq!(w.value(), v);
        let w2 = FfiWord2::from_bytes(w.to_bytes()).unwrap();
        assert_eq!(w2.value(), v);
    }
}

#[test]
fn integration_word4_roundtrip() {
    for v in [0u32, 1, 0xDEADBEEF, u32::MAX] {
        let w = FfiWord4::new(v);
        assert_eq!(w.value(), v);
        let w2 = FfiWord4::from_bytes(w.to_bytes()).unwrap();
        assert_eq!(w2.value(), v);
    }
}

#[test]
fn integration_word8_roundtrip() {
    for v in [0u64, 1, 0xDEADBEEFCAFEBABE, u64::MAX] {
        let w = FfiWord8::new(v);
        assert_eq!(w.value(), v);
        let w2 = FfiWord8::from_bytes(w.to_bytes()).unwrap();
        assert_eq!(w2.value(), v);
    }
}

#[test]
fn integration_word2_taxons() {
    let w = FfiWord2::new(0xABCD);
    assert_eq!(w.taxon(0).unwrap(), 0xAB);
    assert_eq!(w.taxon(1).unwrap(), 0xCD);
    assert!(w.taxon(2).is_err());
}

#[test]
fn integration_word4_taxons() {
    let w = FfiWord4::new(0x12345678);
    assert_eq!(w.taxon(0).unwrap(), 0x12);
    assert_eq!(w.taxon(1).unwrap(), 0x34);
    assert_eq!(w.taxon(2).unwrap(), 0x56);
    assert_eq!(w.taxon(3).unwrap(), 0x78);
    assert!(w.taxon(4).is_err());
}

#[test]
fn integration_word8_taxons() {
    let w = FfiWord8::new(0x0102030405060708);
    for i in 0..8 {
        assert_eq!(w.taxon(i).unwrap(), (i + 1) as u8);
    }
    assert!(w.taxon(8).is_err());
}

#[test]
fn integration_word_is_zero() {
    assert!(FfiWord2::new(0).is_zero());
    assert!(!FfiWord2::new(1).is_zero());
    assert!(FfiWord4::new(0).is_zero());
    assert!(!FfiWord4::new(1).is_zero());
    assert!(FfiWord8::new(0).is_zero());
    assert!(!FfiWord8::new(1).is_zero());
}

// ============================================================================
// Datum16 integration
// ============================================================================

#[test]
fn integration_datum16_observables() {
    let d = FfiDatum16::new(0x00FF);
    assert_eq!(d.value(), 0x00FF);
    assert_eq!(d.stratum(), 8);
    assert_eq!(d.high_byte(), 0x00);
    assert_eq!(d.low_byte(), 0xFF);
    assert_eq!(d.spectrum().len(), 8);
}

#[test]
fn integration_datum16_glyph_two_chars() {
    for v in [0u16, 1, 0x1234, 0xFFFF] {
        let d = FfiDatum16::new(v);
        assert_eq!(d.glyph().chars().count(), 2);
    }
}

#[test]
fn integration_datum16_json() {
    let d = FfiDatum16::new(42);
    let json = d.to_json();
    assert!(!json.is_empty());
}

#[test]
fn integration_datum16_stratum_matches_q1() {
    for v in [0u16, 1, 0xFF, 0x100, 0x1234, 0xFFFF] {
        assert_eq!(FfiDatum16::new(v).stratum(), stratum_q1(v));
    }
}

#[test]
fn integration_datum16_curvature_matches_q1() {
    for v in [0u16, 1, 0xFF, 0x100, 0x1234, 0xFFFF] {
        assert_eq!(FfiDatum16::new(v).curvature(), curvature_q1(v));
    }
}

// ============================================================================
// Datum16Proof integration
// ============================================================================

#[test]
fn integration_proof_valid() {
    for v in [0u16, 1, 255, 256, 0x1234, 0xFFFF] {
        let p = FfiDatum16Proof::from_datum(v);
        assert!(p.is_valid(), "Proof invalid for value {}", v);
        assert_eq!(p.value(), v);
    }
}

#[test]
fn integration_proof_observables_match_datum() {
    for v in [0u16, 42, 0x00FF, 0x1234, 0xFFFF] {
        let d = FfiDatum16::new(v);
        let p = FfiDatum16Proof::from_datum(v);
        assert_eq!(d.stratum(), p.stratum());
        assert_eq!(d.curvature(), p.curvature());
        assert_eq!(d.glyph(), p.glyph());
        assert_eq!(d.spectrum(), p.spectrum());
    }
}

#[test]
fn integration_proof_json() {
    let p = FfiDatum16Proof::from_datum(0x1234);
    let json = p.to_json().unwrap();
    assert!(json.contains("DatumProof"));
}
