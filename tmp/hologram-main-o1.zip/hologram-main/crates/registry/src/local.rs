//! Local filesystem-backed registry for content-addressed layer storage.

use std::fs::{self, File};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};

use crate::error::{RegistryError, Result};

/// Content-addressed local registry backed by filesystem.
///
/// Layers are stored by their BLAKE3 hash in a sharded directory structure:
/// ```text
/// ~/.hologram/registry/
/// └── blobs/
///     ├── ab/
///     │   └── ab1234...5678  (full hash as filename)
///     └── cd/
///         └── cd9876...4321
/// ```
///
/// # Example
///
/// ```no_run
/// use hologram_registry::LocalRegistry;
///
/// let registry = LocalRegistry::default_location().unwrap();
///
/// // Store data
/// let data = b"layer content";
/// let hash = registry.store(data).unwrap();
///
/// // Fetch it back
/// let fetched = registry.fetch(&hash).unwrap();
/// assert_eq!(data.as_slice(), fetched.as_slice());
/// ```
#[derive(Debug, Clone)]
pub struct LocalRegistry {
    /// Root directory for the registry.
    root: PathBuf,
}

impl LocalRegistry {
    /// Default registry location: `~/.hologram/registry/`.
    const DEFAULT_SUBDIR: &'static str = ".hologram/registry";

    /// Create a registry at the default location.
    ///
    /// The default location is `~/.hologram/registry/`.
    ///
    /// # Errors
    ///
    /// Returns an error if the home directory cannot be determined or
    /// if the registry directories cannot be created.
    pub fn default_location() -> Result<Self> {
        let home = home_dir()?;
        let root = home.join(Self::DEFAULT_SUBDIR);
        Self::new(root)
    }

    /// Create a registry at a custom location.
    ///
    /// Creates the directory structure if it doesn't exist.
    ///
    /// # Errors
    ///
    /// Returns an error if the directories cannot be created.
    pub fn new(root: impl Into<PathBuf>) -> Result<Self> {
        let root = root.into();
        let blobs_dir = root.join("blobs");
        let index_dir = root.join("index");

        fs::create_dir_all(&blobs_dir).map_err(|e| RegistryError::io(&blobs_dir, e))?;
        fs::create_dir_all(&index_dir).map_err(|e| RegistryError::io(&index_dir, e))?;

        Ok(Self { root })
    }

    /// Get the root directory of the registry.
    #[must_use]
    pub fn root(&self) -> &Path {
        &self.root
    }

    /// Get the blobs directory.
    #[must_use]
    pub fn blobs_dir(&self) -> PathBuf {
        self.root.join("blobs")
    }

    /// Get the index directory.
    #[must_use]
    pub fn index_dir(&self) -> PathBuf {
        self.root.join("index")
    }

    /// Get the path to the name index file.
    #[must_use]
    pub fn index_path(&self) -> PathBuf {
        self.root.join("index").join("names.json")
    }

    /// Store layer data and return its content hash.
    ///
    /// If data with the same hash already exists, this is a no-op.
    ///
    /// # Errors
    ///
    /// Returns an error if the data cannot be written.
    pub fn store(&self, data: &[u8]) -> Result<[u8; 32]> {
        let hash = crate::hash_data(data);
        let path = self.blob_path(&hash);

        // Idempotent: if already exists, just return hash
        if path.exists() {
            return Ok(hash);
        }

        // Create shard directory
        let shard_dir = path.parent().expect("blob path has parent");
        fs::create_dir_all(shard_dir).map_err(|e| RegistryError::io(shard_dir, e))?;

        // Write to temp file, then rename (atomic)
        let temp_path = path.with_extension("tmp");
        let mut file = File::create(&temp_path).map_err(|e| RegistryError::io(&temp_path, e))?;
        file.write_all(data)
            .map_err(|e| RegistryError::io(&temp_path, e))?;
        file.sync_all()
            .map_err(|e| RegistryError::io(&temp_path, e))?;

        fs::rename(&temp_path, &path).map_err(|e| RegistryError::io(&path, e))?;

        Ok(hash)
    }

    /// Fetch layer data by hash.
    ///
    /// Verifies the content hash after reading.
    ///
    /// # Errors
    ///
    /// Returns [`RegistryError::NotFound`] if the layer doesn't exist.
    /// Returns [`RegistryError::HashMismatch`] if data is corrupted.
    pub fn fetch(&self, hash: &[u8; 32]) -> Result<Vec<u8>> {
        let path = self.blob_path(hash);

        if !path.exists() {
            return Err(RegistryError::NotFound(hex::encode(hash)));
        }

        let mut file = File::open(&path).map_err(|e| RegistryError::io(&path, e))?;
        let mut data = Vec::new();
        file.read_to_end(&mut data)
            .map_err(|e| RegistryError::io(&path, e))?;

        // Verify hash
        let computed = crate::hash_data(&data);
        if &computed != hash {
            return Err(RegistryError::HashMismatch {
                expected: hex::encode(hash),
                actual: hex::encode(computed),
            });
        }

        Ok(data)
    }

    /// Check if a layer exists in the registry.
    #[must_use]
    pub fn exists(&self, hash: &[u8; 32]) -> bool {
        self.blob_path(hash).exists()
    }

    /// List all stored layer hashes.
    ///
    /// # Errors
    ///
    /// Returns an error if the blobs directory cannot be read.
    pub fn list(&self) -> Result<Vec<[u8; 32]>> {
        let blobs_dir = self.blobs_dir();
        let mut hashes = Vec::new();

        // Iterate over shard directories
        let entries = fs::read_dir(&blobs_dir).map_err(|e| RegistryError::io(&blobs_dir, e))?;

        for entry in entries {
            let entry = entry.map_err(|e| RegistryError::io(&blobs_dir, e))?;
            let shard_path = entry.path();

            if !shard_path.is_dir() {
                continue;
            }

            // Iterate over blobs in shard
            let shard_entries =
                fs::read_dir(&shard_path).map_err(|e| RegistryError::io(&shard_path, e))?;

            for blob_entry in shard_entries {
                let blob_entry = blob_entry.map_err(|e| RegistryError::io(&shard_path, e))?;
                let blob_path = blob_entry.path();

                // Skip temp files
                if blob_path.extension().is_some() {
                    continue;
                }

                if let Some(hash) = parse_hash_from_filename(&blob_path) {
                    hashes.push(hash);
                }
            }
        }

        // Sort for deterministic ordering
        hashes.sort();
        Ok(hashes)
    }

    /// Remove a layer from the registry.
    ///
    /// Returns `true` if the layer was removed, `false` if it didn't exist.
    ///
    /// # Errors
    ///
    /// Returns an error if the file cannot be deleted.
    pub fn remove(&self, hash: &[u8; 32]) -> Result<bool> {
        let path = self.blob_path(hash);

        if !path.exists() {
            return Ok(false);
        }

        fs::remove_file(&path).map_err(|e| RegistryError::io(&path, e))?;
        Ok(true)
    }

    /// Get the file path for a blob by hash.
    fn blob_path(&self, hash: &[u8; 32]) -> PathBuf {
        let hex = hex::encode(hash);
        let shard = &hex[0..2];
        self.blobs_dir().join(shard).join(&hex)
    }
}

/// Get the user's home directory.
fn home_dir() -> Result<PathBuf> {
    std::env::var("HOME")
        .map(PathBuf::from)
        .map_err(|_| RegistryError::InvalidRef("HOME environment variable not set".to_string()))
}

/// Parse a hash from a filename.
fn parse_hash_from_filename(path: &Path) -> Option<[u8; 32]> {
    let filename = path.file_name()?.to_str()?;

    if filename.len() != 64 {
        return None;
    }

    let bytes = hex::decode(filename).ok()?;
    let hash: [u8; 32] = bytes.try_into().ok()?;
    Some(hash)
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    fn temp_registry() -> (TempDir, LocalRegistry) {
        let temp = TempDir::new().unwrap();
        let registry = LocalRegistry::new(temp.path()).unwrap();
        (temp, registry)
    }

    #[test]
    fn test_new_creates_directories() {
        let temp = TempDir::new().unwrap();
        let root = temp.path().join("registry");
        let registry = LocalRegistry::new(&root).unwrap();

        assert!(registry.blobs_dir().exists());
        assert!(registry.index_dir().exists());
    }

    #[test]
    fn test_store_and_fetch() {
        let (_temp, registry) = temp_registry();
        let data = b"hello world";

        let hash = registry.store(data).unwrap();
        let fetched = registry.fetch(&hash).unwrap();

        assert_eq!(data.as_slice(), fetched.as_slice());
    }

    #[test]
    fn test_store_idempotent() {
        let (_temp, registry) = temp_registry();
        let data = b"same data";

        let hash1 = registry.store(data).unwrap();
        let hash2 = registry.store(data).unwrap();

        assert_eq!(hash1, hash2);
    }

    #[test]
    fn test_store_different_data() {
        let (_temp, registry) = temp_registry();

        let hash1 = registry.store(b"data one").unwrap();
        let hash2 = registry.store(b"data two").unwrap();

        assert_ne!(hash1, hash2);
    }

    #[test]
    fn test_exists() {
        let (_temp, registry) = temp_registry();
        let data = b"test";
        let hash = registry.store(data).unwrap();

        assert!(registry.exists(&hash));
        assert!(!registry.exists(&[0u8; 32]));
    }

    #[test]
    fn test_fetch_not_found() {
        let (_temp, registry) = temp_registry();
        let result = registry.fetch(&[0u8; 32]);

        assert!(result.is_err());
        assert!(matches!(result, Err(RegistryError::NotFound(_))));
    }

    #[test]
    fn test_list_empty() {
        let (_temp, registry) = temp_registry();
        let list = registry.list().unwrap();

        assert!(list.is_empty());
    }

    #[test]
    fn test_list_with_blobs() {
        let (_temp, registry) = temp_registry();

        let hash1 = registry.store(b"one").unwrap();
        let hash2 = registry.store(b"two").unwrap();
        let hash3 = registry.store(b"three").unwrap();

        let mut list = registry.list().unwrap();
        list.sort();

        let mut expected = vec![hash1, hash2, hash3];
        expected.sort();

        assert_eq!(list, expected);
    }

    #[test]
    fn test_remove() {
        let (_temp, registry) = temp_registry();
        let hash = registry.store(b"to remove").unwrap();

        assert!(registry.exists(&hash));

        let removed = registry.remove(&hash).unwrap();
        assert!(removed);
        assert!(!registry.exists(&hash));

        // Remove again should return false
        let removed_again = registry.remove(&hash).unwrap();
        assert!(!removed_again);
    }

    #[test]
    fn test_blob_path_sharding() {
        let (_temp, registry) = temp_registry();
        let hash = [0xab; 32];
        let path = registry.blob_path(&hash);

        // Should be sharded by first 2 hex chars
        let path_str = path.to_string_lossy();
        let expected_shard = format!("ab{}", std::path::MAIN_SEPARATOR);
        assert!(path_str.contains(&expected_shard));
        assert!(path_str.contains("abab"));
    }

    #[test]
    fn test_hash_verification() {
        let (_temp, registry) = temp_registry();
        let data = b"original data";
        let hash = registry.store(data).unwrap();

        // Corrupt the file
        let path = registry.blob_path(&hash);
        fs::write(&path, b"corrupted").unwrap();

        // Fetch should fail with hash mismatch
        let result = registry.fetch(&hash);
        assert!(matches!(result, Err(RegistryError::HashMismatch { .. })));
    }

    #[test]
    fn test_root_accessor() {
        let temp = TempDir::new().unwrap();
        let registry = LocalRegistry::new(temp.path()).unwrap();

        assert_eq!(registry.root(), temp.path());
    }

    #[test]
    fn test_index_path() {
        let (_temp, registry) = temp_registry();
        let index_path = registry.index_path();

        assert!(index_path.ends_with("index/names.json"));
    }

    #[test]
    fn test_large_data() {
        let (_temp, registry) = temp_registry();
        let data: Vec<u8> = (0..100_000).map(|i| (i % 256) as u8).collect();

        let hash = registry.store(&data).unwrap();
        let fetched = registry.fetch(&hash).unwrap();

        assert_eq!(data, fetched);
    }
}
