//! Partition types for distributed execution.
//!
//! This module provides types for partitioning `BackendPlan`s into smaller
//! units that can be executed independently across distributed workers.
//!
//! # Partitioning Model
//!
//! A `BackendPlan` can be split into multiple `PlanPartition`s based on:
//! - Compute cost boundaries (load balancing)
//! - Memory boundaries (fitting in device memory)
//! - Data dependencies (minimizing cross-partition communication)
//!
//! Partitions form a DAG where edges represent data dependencies.
//! The `PartitionedPlan` tracks this dependency graph.
//!
//! # Example
//!
//! ```
//! use hologram_holo::{PlanPartition, PartitionedPlan};
//!
//! // Create partitions
//! let p1 = PlanPartition::new("encoder", [1; 32], vec![1, 2, 3])
//!     .with_cost(1000)
//!     .with_memory(1024 * 1024);
//!
//! let p2 = PlanPartition::new("decoder", [2; 32], vec![4, 5, 6])
//!     .with_cost(2000)
//!     .with_memory(2 * 1024 * 1024);
//!
//! // Create partitioned plan with dependencies
//! let mut plan = PartitionedPlan::new();
//! plan.add_partition(p1, vec![]); // p1 has no dependencies
//! plan.add_partition(p2, vec!["encoder".to_string()]); // p2 depends on p1
//! ```

use rkyv::{Archive, Deserialize, Serialize};

/// A partition of a compiled plan.
///
/// Represents a segment of a `BackendPlan` that can be executed independently
/// once its dependencies are satisfied. Partitions contain serialized IR that
/// can be compiled to a `BackendPlan` on the target worker.
#[derive(Debug, Clone, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct PlanPartition {
    /// Unique name for this partition.
    pub name: String,

    /// Content hash (SHA-256) for integrity verification.
    pub content_hash: [u8; 32],

    /// Serialized IR bytes (portable representation).
    ///
    /// This contains the subset of operations for this partition,
    /// serialized in a format that can be deserialized and compiled
    /// on any worker.
    pub ir_bytes: Vec<u8>,

    /// Estimated compute cost (arbitrary units for scheduling).
    pub estimated_cost: u64,

    /// Estimated memory requirement in bytes.
    pub estimated_memory: usize,

    /// Input buffer indices (from the original plan).
    pub input_indices: Vec<u32>,

    /// Output buffer indices (from the original plan).
    pub output_indices: Vec<u32>,

    /// Optional metadata (JSON-encoded for flexibility).
    pub metadata: Option<String>,
}

impl PlanPartition {
    /// Create a new partition.
    #[must_use]
    pub fn new(name: impl Into<String>, content_hash: [u8; 32], ir_bytes: Vec<u8>) -> Self {
        Self {
            name: name.into(),
            content_hash,
            ir_bytes,
            estimated_cost: 0,
            estimated_memory: 0,
            input_indices: Vec::new(),
            output_indices: Vec::new(),
            metadata: None,
        }
    }

    /// Set the estimated compute cost.
    #[must_use]
    pub fn with_cost(mut self, cost: u64) -> Self {
        self.estimated_cost = cost;
        self
    }

    /// Set the estimated memory requirement.
    #[must_use]
    pub fn with_memory(mut self, memory: usize) -> Self {
        self.estimated_memory = memory;
        self
    }

    /// Set the input buffer indices.
    #[must_use]
    pub fn with_inputs(mut self, inputs: Vec<u32>) -> Self {
        self.input_indices = inputs;
        self
    }

    /// Set the output buffer indices.
    #[must_use]
    pub fn with_outputs(mut self, outputs: Vec<u32>) -> Self {
        self.output_indices = outputs;
        self
    }

    /// Set optional metadata.
    #[must_use]
    pub fn with_metadata(mut self, metadata: impl Into<String>) -> Self {
        self.metadata = Some(metadata.into());
        self
    }

    /// Get the partition name.
    #[must_use]
    pub fn name(&self) -> &str {
        &self.name
    }

    /// Get the content hash.
    #[must_use]
    pub fn content_hash(&self) -> &[u8; 32] {
        &self.content_hash
    }

    /// Get the IR bytes.
    #[must_use]
    pub fn ir_bytes(&self) -> &[u8] {
        &self.ir_bytes
    }

    /// Check if this partition has any inputs.
    #[must_use]
    pub fn has_inputs(&self) -> bool {
        !self.input_indices.is_empty()
    }

    /// Check if this partition has any outputs.
    #[must_use]
    pub fn has_outputs(&self) -> bool {
        !self.output_indices.is_empty()
    }

    /// Compute the content hash from the IR bytes.
    #[must_use]
    pub fn compute_hash(&self) -> [u8; 32] {
        use hologram_sha256::Sha256;
        let mut hasher = Sha256::new();
        hasher.update(&self.ir_bytes);
        hasher.finalize().into()
    }

    /// Verify the content hash matches the IR bytes.
    #[must_use]
    pub fn verify_hash(&self) -> bool {
        self.content_hash == self.compute_hash()
    }
}

/// A partitioned execution plan.
///
/// Contains multiple `PlanPartition`s along with their dependency relationships,
/// enabling distributed execution across multiple workers.
#[derive(Debug, Clone, Default, PartialEq, Archive, Serialize, Deserialize)]
#[archive(check_bytes)]
pub struct PartitionedPlan {
    /// All partitions in this plan.
    pub partitions: Vec<PlanPartition>,

    /// Dependency map: partition name -> list of partition names it depends on.
    ///
    /// A partition can only execute after all its dependencies have completed.
    pub dependencies: Vec<(String, Vec<String>)>,

    /// External inputs to the plan (from caller).
    pub external_inputs: Vec<String>,

    /// External outputs from the plan (to caller).
    pub external_outputs: Vec<String>,

    /// Plan metadata.
    pub name: String,

    /// Plan version.
    pub version: String,
}

impl PartitionedPlan {
    /// Create a new empty partitioned plan.
    #[must_use]
    pub fn new() -> Self {
        Self {
            partitions: Vec::new(),
            dependencies: Vec::new(),
            external_inputs: Vec::new(),
            external_outputs: Vec::new(),
            name: String::new(),
            version: String::from("0.1.0"),
        }
    }

    /// Set the plan name.
    #[must_use]
    pub fn with_name(mut self, name: impl Into<String>) -> Self {
        self.name = name.into();
        self
    }

    /// Set the plan version.
    #[must_use]
    pub fn with_version(mut self, version: impl Into<String>) -> Self {
        self.version = version.into();
        self
    }

    /// Add a partition with its dependencies.
    pub fn add_partition(&mut self, partition: PlanPartition, deps: Vec<String>) {
        let name = partition.name.clone();
        self.partitions.push(partition);
        self.dependencies.push((name, deps));
    }

    /// Get a partition by name.
    #[must_use]
    pub fn partition(&self, name: &str) -> Option<&PlanPartition> {
        self.partitions.iter().find(|p| p.name == name)
    }

    /// Get the dependencies for a partition.
    #[must_use]
    pub fn partition_deps(&self, name: &str) -> Option<&[String]> {
        self.dependencies
            .iter()
            .find(|(n, _)| n == name)
            .map(|(_, deps)| deps.as_slice())
    }

    /// Get all partition names.
    #[must_use]
    pub fn partition_names(&self) -> Vec<&str> {
        self.partitions.iter().map(|p| p.name.as_str()).collect()
    }

    /// Get the number of partitions.
    #[must_use]
    pub fn num_partitions(&self) -> usize {
        self.partitions.len()
    }

    /// Check if the plan is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.partitions.is_empty()
    }

    /// Get the total estimated cost across all partitions.
    #[must_use]
    pub fn total_cost(&self) -> u64 {
        self.partitions.iter().map(|p| p.estimated_cost).sum()
    }

    /// Get the total estimated memory across all partitions.
    #[must_use]
    pub fn total_memory(&self) -> usize {
        self.partitions.iter().map(|p| p.estimated_memory).sum()
    }

    /// Get partitions that have no dependencies (can be executed immediately).
    #[must_use]
    pub fn root_partitions(&self) -> Vec<&str> {
        self.dependencies
            .iter()
            .filter(|(_, deps)| deps.is_empty())
            .map(|(name, _)| name.as_str())
            .collect()
    }

    /// Get partitions that depend on a given partition.
    #[must_use]
    pub fn dependents(&self, name: &str) -> Vec<&str> {
        self.dependencies
            .iter()
            .filter(|(_, deps)| deps.iter().any(|d| d == name))
            .map(|(n, _)| n.as_str())
            .collect()
    }

    /// Validate the plan structure.
    ///
    /// Checks:
    /// - All dependencies reference existing partitions
    /// - No circular dependencies
    /// - All partitions have entries in the dependency map
    pub fn validate(&self) -> Result<(), PartitionValidationError> {
        let names: std::collections::HashSet<_> =
            self.partitions.iter().map(|p| p.name.as_str()).collect();

        // Check all dependencies reference existing partitions
        for (partition_name, deps) in &self.dependencies {
            if !names.contains(partition_name.as_str()) {
                return Err(PartitionValidationError::MissingPartition(
                    partition_name.clone(),
                ));
            }
            for dep in deps {
                if !names.contains(dep.as_str()) {
                    return Err(PartitionValidationError::MissingDependency {
                        partition: partition_name.clone(),
                        dependency: dep.clone(),
                    });
                }
            }
        }

        // Check all partitions have dependency entries
        for partition in &self.partitions {
            if !self.dependencies.iter().any(|(n, _)| n == &partition.name) {
                return Err(PartitionValidationError::MissingDependencyEntry(
                    partition.name.clone(),
                ));
            }
        }

        // Check for cycles using DFS
        self.check_cycles()?;

        Ok(())
    }

    /// Check for dependency cycles using DFS.
    fn check_cycles(&self) -> Result<(), PartitionValidationError> {
        #[derive(Clone, Copy, PartialEq, Eq)]
        enum Color {
            White,
            Gray,
            Black,
        }

        fn dfs<'a>(
            node: &'a str,
            colors: &mut std::collections::HashMap<&'a str, Color>,
            deps: &'a [(String, Vec<String>)],
            path: &mut Vec<String>,
        ) -> Result<(), PartitionValidationError> {
            colors.insert(node, Color::Gray);
            path.push(node.to_string());

            if let Some((_, node_deps)) = deps.iter().find(|(n, _)| n == node) {
                for dep in node_deps {
                    match colors.get(dep.as_str()) {
                        Some(Color::Gray) => {
                            path.push(dep.clone());
                            return Err(PartitionValidationError::CycleDetected(path.clone()));
                        }
                        Some(Color::White) | None => {
                            dfs(dep, colors, deps, path)?;
                        }
                        Some(Color::Black) => {}
                    }
                }
            }

            colors.insert(node, Color::Black);
            path.pop();
            Ok(())
        }

        let mut colors: std::collections::HashMap<&str, Color> = self
            .partitions
            .iter()
            .map(|p| (p.name.as_str(), Color::White))
            .collect();

        for partition in &self.partitions {
            if colors.get(partition.name.as_str()) == Some(&Color::White) {
                let mut path = Vec::new();
                dfs(&partition.name, &mut colors, &self.dependencies, &mut path)?;
            }
        }

        Ok(())
    }

    /// Compute a topological order for execution.
    ///
    /// Returns partition names in an order where all dependencies
    /// are satisfied before a partition is executed.
    pub fn topological_order(&self) -> Result<Vec<&str>, PartitionValidationError> {
        self.validate()?;

        let mut in_degree: std::collections::HashMap<&str, usize> = self
            .partitions
            .iter()
            .map(|p| (p.name.as_str(), 0usize))
            .collect();

        // Calculate in-degrees (number of dependencies each partition has)
        for partition in &self.partitions {
            if let Some((_, deps)) = self.dependencies.iter().find(|(n, _)| n == &partition.name) {
                *in_degree.get_mut(partition.name.as_str()).unwrap() = deps.len();
            }
        }

        // Kahn's algorithm
        let mut queue: std::collections::VecDeque<&str> = in_degree
            .iter()
            .filter(|(_, &deg)| deg == 0)
            .map(|(&name, _)| name)
            .collect();

        let mut result = Vec::new();

        while let Some(node) = queue.pop_front() {
            result.push(node);

            // Find partitions that depend on this node
            for (name, deps) in &self.dependencies {
                if deps.iter().any(|d| d == node) {
                    if let Some(count) = in_degree.get_mut(name.as_str()) {
                        *count = count.saturating_sub(1);
                        if *count == 0 {
                            queue.push_back(name);
                        }
                    }
                }
            }
        }

        if result.len() != self.partitions.len() {
            return Err(PartitionValidationError::CycleDetected(
                result.into_iter().map(String::from).collect(),
            ));
        }

        Ok(result)
    }

    /// Group partitions into parallel execution levels.
    ///
    /// Returns a Vec of Vec where each inner Vec contains partitions
    /// that can be executed in parallel (all dependencies satisfied).
    pub fn parallel_levels(&self) -> Result<Vec<Vec<&str>>, PartitionValidationError> {
        self.validate()?;

        let mut levels: Vec<Vec<&str>> = Vec::new();
        let mut completed: std::collections::HashSet<&str> = std::collections::HashSet::new();
        let mut remaining: std::collections::HashSet<&str> =
            self.partitions.iter().map(|p| p.name.as_str()).collect();

        while !remaining.is_empty() {
            let mut level = Vec::new();

            for &name in &remaining {
                let deps = self.partition_deps(name).unwrap_or(&[]);
                let all_deps_completed = deps.iter().all(|d| completed.contains(d.as_str()));

                if all_deps_completed {
                    level.push(name);
                }
            }

            if level.is_empty() {
                return Err(PartitionValidationError::CycleDetected(
                    remaining.into_iter().map(String::from).collect(),
                ));
            }

            for name in &level {
                remaining.remove(name);
                completed.insert(name);
            }

            levels.push(level);
        }

        Ok(levels)
    }
}

/// Errors that can occur during partition validation.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum PartitionValidationError {
    /// A partition referenced in dependencies doesn't exist.
    #[error("Missing partition: {0}")]
    MissingPartition(String),

    /// A dependency references a non-existent partition.
    #[error("Partition '{partition}' depends on missing partition '{dependency}'")]
    MissingDependency {
        /// The partition with the invalid dependency.
        partition: String,
        /// The missing dependency.
        dependency: String,
    },

    /// A partition has no entry in the dependency map.
    #[error("Partition '{0}' has no dependency entry")]
    MissingDependencyEntry(String),

    /// A dependency cycle was detected.
    #[error("Dependency cycle detected: {0:?}")]
    CycleDetected(Vec<String>),
}

#[cfg(test)]
mod tests {
    use super::*;

    fn test_partition(name: &str) -> PlanPartition {
        PlanPartition::new(name, [0u8; 32], vec![1, 2, 3])
            .with_cost(100)
            .with_memory(1024)
    }

    #[test]
    fn test_partition_creation() {
        let p = PlanPartition::new("test", [1u8; 32], vec![1, 2, 3])
            .with_cost(500)
            .with_memory(2048)
            .with_inputs(vec![0, 1])
            .with_outputs(vec![2])
            .with_metadata(r#"{"key": "value"}"#);

        assert_eq!(p.name(), "test");
        assert_eq!(p.content_hash(), &[1u8; 32]);
        assert_eq!(p.ir_bytes(), &[1, 2, 3]);
        assert_eq!(p.estimated_cost, 500);
        assert_eq!(p.estimated_memory, 2048);
        assert!(p.has_inputs());
        assert!(p.has_outputs());
        assert!(p.metadata.is_some());
    }

    #[test]
    fn test_partition_hash_verification() {
        let data = vec![1, 2, 3, 4, 5];
        let mut p = PlanPartition::new("test", [0u8; 32], data);

        // Set the correct hash
        p.content_hash = p.compute_hash();
        assert!(p.verify_hash());

        // Corrupt the hash
        p.content_hash[0] ^= 0xFF;
        assert!(!p.verify_hash());
    }

    #[test]
    fn test_partitioned_plan_creation() {
        let mut plan = PartitionedPlan::new()
            .with_name("test_model")
            .with_version("1.0.0");

        let p1 = test_partition("p1");
        let p2 = test_partition("p2");
        let p3 = test_partition("p3");

        plan.add_partition(p1, vec![]);
        plan.add_partition(p2, vec!["p1".to_string()]);
        plan.add_partition(p3, vec!["p1".to_string(), "p2".to_string()]);

        assert_eq!(plan.name, "test_model");
        assert_eq!(plan.version, "1.0.0");
        assert_eq!(plan.num_partitions(), 3);
        assert!(!plan.is_empty());
    }

    #[test]
    fn test_partition_lookup() {
        let mut plan = PartitionedPlan::new();
        plan.add_partition(test_partition("p1"), vec![]);
        plan.add_partition(test_partition("p2"), vec!["p1".to_string()]);

        assert!(plan.partition("p1").is_some());
        assert!(plan.partition("p2").is_some());
        assert!(plan.partition("p3").is_none());

        let deps = plan.partition_deps("p2").unwrap();
        assert_eq!(deps, &["p1"]);
    }

    #[test]
    fn test_root_partitions() {
        let mut plan = PartitionedPlan::new();
        plan.add_partition(test_partition("p1"), vec![]);
        plan.add_partition(test_partition("p2"), vec![]);
        plan.add_partition(test_partition("p3"), vec!["p1".to_string()]);

        let roots = plan.root_partitions();
        assert_eq!(roots.len(), 2);
        assert!(roots.contains(&"p1"));
        assert!(roots.contains(&"p2"));
    }

    #[test]
    fn test_dependents() {
        let mut plan = PartitionedPlan::new();
        plan.add_partition(test_partition("p1"), vec![]);
        plan.add_partition(test_partition("p2"), vec!["p1".to_string()]);
        plan.add_partition(test_partition("p3"), vec!["p1".to_string()]);

        let deps = plan.dependents("p1");
        assert_eq!(deps.len(), 2);
        assert!(deps.contains(&"p2"));
        assert!(deps.contains(&"p3"));
    }

    #[test]
    fn test_total_cost_and_memory() {
        let mut plan = PartitionedPlan::new();
        plan.add_partition(
            PlanPartition::new("p1", [0; 32], vec![])
                .with_cost(100)
                .with_memory(1000),
            vec![],
        );
        plan.add_partition(
            PlanPartition::new("p2", [0; 32], vec![])
                .with_cost(200)
                .with_memory(2000),
            vec![],
        );

        assert_eq!(plan.total_cost(), 300);
        assert_eq!(plan.total_memory(), 3000);
    }

    #[test]
    fn test_validation_success() {
        let mut plan = PartitionedPlan::new();
        plan.add_partition(test_partition("p1"), vec![]);
        plan.add_partition(test_partition("p2"), vec!["p1".to_string()]);

        assert!(plan.validate().is_ok());
    }

    #[test]
    fn test_validation_missing_dependency() {
        let mut plan = PartitionedPlan::new();
        plan.add_partition(test_partition("p1"), vec!["missing".to_string()]);

        let result = plan.validate();
        assert!(matches!(
            result,
            Err(PartitionValidationError::MissingDependency { .. })
        ));
    }

    #[test]
    fn test_validation_cycle() {
        let mut plan = PartitionedPlan::new();
        plan.add_partition(test_partition("p1"), vec!["p2".to_string()]);
        plan.add_partition(test_partition("p2"), vec!["p1".to_string()]);

        let result = plan.validate();
        assert!(matches!(
            result,
            Err(PartitionValidationError::CycleDetected(_))
        ));
    }

    #[test]
    fn test_topological_order() {
        let mut plan = PartitionedPlan::new();
        plan.add_partition(test_partition("p1"), vec![]);
        plan.add_partition(test_partition("p2"), vec!["p1".to_string()]);
        plan.add_partition(test_partition("p3"), vec!["p2".to_string()]);

        let order = plan.topological_order().unwrap();
        assert_eq!(order, vec!["p1", "p2", "p3"]);
    }

    #[test]
    fn test_parallel_levels() {
        let mut plan = PartitionedPlan::new();
        // Level 0: p1, p2 (no deps)
        plan.add_partition(test_partition("p1"), vec![]);
        plan.add_partition(test_partition("p2"), vec![]);
        // Level 1: p3, p4 (depend on p1 or p2)
        plan.add_partition(test_partition("p3"), vec!["p1".to_string()]);
        plan.add_partition(test_partition("p4"), vec!["p2".to_string()]);
        // Level 2: p5 (depends on p3 and p4)
        plan.add_partition(
            test_partition("p5"),
            vec!["p3".to_string(), "p4".to_string()],
        );

        let levels = plan.parallel_levels().unwrap();
        assert_eq!(levels.len(), 3);

        // Level 0 should have p1 and p2
        assert_eq!(levels[0].len(), 2);
        assert!(levels[0].contains(&"p1"));
        assert!(levels[0].contains(&"p2"));

        // Level 1 should have p3 and p4
        assert_eq!(levels[1].len(), 2);
        assert!(levels[1].contains(&"p3"));
        assert!(levels[1].contains(&"p4"));

        // Level 2 should have p5
        assert_eq!(levels[2], vec!["p5"]);
    }

    #[test]
    fn test_partition_names() {
        let mut plan = PartitionedPlan::new();
        plan.add_partition(test_partition("alpha"), vec![]);
        plan.add_partition(test_partition("beta"), vec![]);

        let names = plan.partition_names();
        assert_eq!(names.len(), 2);
        assert!(names.contains(&"alpha"));
        assert!(names.contains(&"beta"));
    }

    #[test]
    fn test_empty_plan() {
        let plan = PartitionedPlan::new();
        assert!(plan.is_empty());
        assert_eq!(plan.num_partitions(), 0);
        assert_eq!(plan.total_cost(), 0);
        assert_eq!(plan.total_memory(), 0);
        assert!(plan.root_partitions().is_empty());
    }

    #[test]
    fn test_diamond_dependency() {
        // Diamond: p1 -> p2, p3 -> p4
        //          p1 ─┬─> p2 ─┬─> p4
        //              └─> p3 ─┘
        let mut plan = PartitionedPlan::new();
        plan.add_partition(test_partition("p1"), vec![]);
        plan.add_partition(test_partition("p2"), vec!["p1".to_string()]);
        plan.add_partition(test_partition("p3"), vec!["p1".to_string()]);
        plan.add_partition(
            test_partition("p4"),
            vec!["p2".to_string(), "p3".to_string()],
        );

        assert!(plan.validate().is_ok());

        let levels = plan.parallel_levels().unwrap();
        assert_eq!(levels.len(), 3);
        assert_eq!(levels[0], vec!["p1"]);
        assert_eq!(levels[1].len(), 2); // p2 and p3 in parallel
        assert_eq!(levels[2], vec!["p4"]);
    }
}
