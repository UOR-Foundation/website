
/**
 * TrustGraphPage — Visual exploration of your trust network.
 *
 * Features:
 * - Search, filter, click to explore
 * - Constellation: bookmark nodes into a personal collection
 * - Waypoint: set a start node and follow connections step by step
 * - Connect: create new edges between any two nodes
 */

import { useState, useMemo, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft, Search, Sun, Moon, Network, X,
  Star, MapPin, Link2, Plus, Sparkles, ChevronRight, Trash2,
  Loader2
} from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import TrustGraph, {
  NODE_TYPE_LABELS,
  EDGE_TYPE_LABELS,
  NODE_TYPE_ICONS,
  NODE_COLORS,
  EDGE_COLORS,
  type GraphNode,
  type NodeType,
  type EdgeType,
} from "../components/TrustGraph";
import { useTrustGraph } from "../hooks/useTrustGraph";

const ALL_NODE_TYPES: NodeType[] = ["self", "person", "agent", "experience", "object"];
const ALL_EDGE_TYPES: EdgeType[] = ["trusts", "verified", "interacted", "witnessed", "created"];

type Mode = "explore" | "constellation" | "connect";

export default function TrustGraphPage() {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  // Data hook
  const { 
    graphData, 
    loading, 
    constellation, 
    addLink, 
    toggleConstellation,
    isReadOnly 
  } = useTrustGraph();

  const [searchQuery, setSearchQuery] = useState("");
  const [activeNodeTypes, setActiveNodeTypes] = useState<Set<NodeType>>(new Set(ALL_NODE_TYPES));
  const [activeEdgeTypes, setActiveEdgeTypes] = useState<Set<EdgeType>>(new Set(ALL_EDGE_TYPES));
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(window.innerWidth >= 640);

  // ── Mode state ──
  const [mode, setMode] = useState<Mode>("explore");

  // ── Waypoint ──
  const [waypoint, setWaypoint] = useState<GraphNode | null>(null);
  const [waypointPath, setWaypointPath] = useState<GraphNode[]>([]);

  // ── Connect ──
  const [connectSource, setConnectSource] = useState<GraphNode | null>(null);
  const [connectTarget, setConnectTarget] = useState<GraphNode | null>(null);
  const [connectEdgeType, setConnectEdgeType] = useState<EdgeType>("trusts");

  const toggleNodeType = useCallback((type: NodeType) => {
    setActiveNodeTypes((prev) => {
      const next = new Set(prev);
      if (next.has(type)) { if (next.size > 1) next.delete(type); }
      else next.add(type);
      return next;
    });
  }, []);

  const toggleEdgeType = useCallback((type: EdgeType) => {
    setActiveEdgeTypes((prev) => {
      const next = new Set(prev);
      if (next.has(type)) { if (next.size > 1) next.delete(type); }
      else next.add(type);
      return next;
    });
  }, []);

  const stats = useMemo(() => ({
    nodes: graphData.nodes.length,
    edges: graphData.links.length,
    verified: graphData.nodes.filter((n) => n.verified).length,
  }), [graphData]);

  // Connections for selected node
  const nodeConnections = useMemo(() => {
    if (!selectedNode) return [];
    return graphData.links
      .filter((l) => {
        const src = typeof l.source === "object" ? (l.source as any).id : l.source;
        const tgt = typeof l.target === "object" ? (l.target as any).id : l.target;
        return src === selectedNode.id || tgt === selectedNode.id;
      })
      .map((l) => {
        const src = typeof l.source === "object" ? (l.source as any).id : l.source;
        const tgt = typeof l.target === "object" ? (l.target as any).id : l.target;
        const otherId = src === selectedNode.id ? tgt : src;
        const other = graphData.nodes.find((n) => n.id === otherId);
        return { link: l, other };
      })
      .filter((c) => c.other);
  }, [selectedNode, graphData]);

  // Constellation nodes
  const constellationNodes = useMemo(
    () => graphData.nodes.filter((n) => constellation.has(n.id)),
    [constellation, graphData]
  );

  // ── Actions ──
  const setAsWaypoint = useCallback((node: GraphNode) => {
    setWaypoint(node);
    setWaypointPath([node]);
    setMode("explore");
  }, []);

  const followConnection = useCallback((node: GraphNode) => {
    setSelectedNode(node);
    setWaypointPath((prev) => [...prev, node]);
  }, []);

  const startConnect = useCallback((node: GraphNode) => {
    setConnectSource(node);
    setConnectTarget(null);
    setMode("connect");
  }, []);

  const completeConnect = useCallback(() => {
    if (!connectSource || !connectTarget) return;
    
    addLink(connectSource.id, connectTarget.id, connectEdgeType);
    
    setConnectSource(null);
    setConnectTarget(null);
    setMode("explore");
  }, [connectSource, connectTarget, connectEdgeType, addLink]);

  const handleNodeClick = useCallback((node: GraphNode) => {
    if (mode === "connect" && connectSource && !connectTarget) {
      if (node.id !== connectSource.id) {
        setConnectTarget(node);
      }
      return;
    }
    setSelectedNode(node);
  }, [mode, connectSource, connectTarget]);

  if (loading) {
    return (
      <div className="h-full w-full bg-background flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="h-full w-full bg-background flex overflow-hidden" style={{ minHeight: "100vh" }}>
      {/* ── Left sidebar ── */}
      {sidebarOpen && (
        <aside className="w-full sm:w-72 flex-shrink-0 border-r border-border/20 bg-card/50 backdrop-blur-sm flex flex-col overflow-hidden absolute sm:relative inset-0 z-20 sm:z-auto">
          {/* Header */}
          <div className="px-5 pt-5 pb-4 border-b border-border/15">
            <div className="flex items-center gap-3 mb-4">
              <button onClick={() => navigate("/identity/explore")} className="text-foreground/50 hover:text-foreground transition-colors">
                <ArrowLeft className="h-4 w-4" />
              </button>
              <div className="flex-1">
                <h1 className="text-xl font-display font-medium text-foreground">Trust Network</h1>
              </div>
              <button onClick={toggleTheme} className="p-1.5 text-foreground/40 hover:text-foreground transition-colors">
                {isDark ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
              </button>
              <button onClick={() => setSidebarOpen(false)} className="sm:hidden p-1.5 text-foreground/40 hover:text-foreground transition-colors">
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="flex gap-3 text-sm text-muted-foreground/60 font-mono">
              <span>{stats.nodes} nodes</span>
              <span>·</span>
              <span>{stats.edges} edges</span>
              <span>·</span>
              <span>{stats.verified} verified</span>
            </div>
          </div>

          {/* Mode tabs */}
          <div className="px-5 pt-3 pb-1 flex gap-1">
            {([
              { id: "explore" as Mode, icon: Search, label: "Explore" },
              { id: "constellation" as Mode, icon: Sparkles, label: "Constellation" },
              { id: "connect" as Mode, icon: Link2, label: "Connect" },
            ]).map(({ id, icon: Icon, label }) => (
              <button
                key={id}
                onClick={() => setMode(id)}
                className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-300 ${
                  mode === id
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground/40 hover:text-muted-foreground/60"
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                {label}
              </button>
            ))}
          </div>

          {/* ── Explore mode ── */}
          {mode === "explore" && (
            <>
              {/* Search */}
              <div className="px-5 py-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground/40" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search connections…"
                    className="w-full pl-9 pr-3 py-2 text-sm bg-muted/30 border border-border/20 rounded-lg text-foreground placeholder:text-muted-foreground/30 focus:outline-none focus:ring-1 focus:ring-primary/30 transition-all"
                  />
                </div>
              </div>

              {/* Waypoint indicator */}
              {waypoint && (
                <div className="mx-5 mb-3 px-3 py-2.5 rounded-lg bg-primary/5 border border-primary/15">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] tracking-[0.15em] uppercase text-primary/60 font-medium flex items-center gap-1">
                      <MapPin className="h-3 w-3" /> Waypoint
                    </span>
                    <button onClick={() => { setWaypoint(null); setWaypointPath([]); }} className="text-muted-foreground/30 hover:text-foreground/50 transition-colors">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {waypointPath.map((node, i) => (
                      <span key={`${node.id}-${i}`} className="flex items-center gap-1">
                        {i > 0 && <ChevronRight className="h-3 w-3 text-muted-foreground/20" />}
                        <button
                          onClick={() => setSelectedNode(node)}
                          className="text-xs text-foreground/70 hover:text-foreground transition-colors"
                        >
                          {node.name}
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Filters */}
              <div className="flex-1 overflow-y-auto px-5 pb-5 space-y-5">
                <div>
                  <p className="text-xs tracking-[0.2em] uppercase text-muted-foreground/40 mb-2.5 font-medium">Node Types</p>
                  <div className="space-y-1">
                    {ALL_NODE_TYPES.filter((t) => t !== "self").map((type) => {
                      const active = activeNodeTypes.has(type);
                      const count = graphData.nodes.filter((n) => n.type === type).length;
                      const colors = NODE_COLORS[type];
                      const color = isDark ? colors.dark : colors.light;
                      return (
                        <button key={type} onClick={() => toggleNodeType(type)}
                          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-all duration-300 ${active ? "bg-muted/40 text-foreground" : "text-muted-foreground/40 hover:text-muted-foreground/60"}`}>
                          <span className="w-3 h-3 rounded-full flex-shrink-0 transition-opacity" style={{ backgroundColor: color, opacity: active ? 1 : 0.3 }} />
                          <span className="flex-1 text-left">{NODE_TYPE_LABELS[type]}</span>
                          <span className="text-xs text-muted-foreground/30 font-mono">{count}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
                <div>
                  <p className="text-[11px] tracking-[0.2em] uppercase text-muted-foreground/40 mb-2.5 font-medium">Relationships</p>
                  <div className="space-y-1">
                    {ALL_EDGE_TYPES.map((type) => {
                      const active = activeEdgeTypes.has(type);
                      const count = graphData.links.filter((l) => l.type === type).length;
                      const colors = EDGE_COLORS[type];
                      const color = isDark ? colors.dark : colors.light;
                      return (
                        <button key={type} onClick={() => toggleEdgeType(type)}
                          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-all duration-300 ${active ? "bg-muted/40 text-foreground" : "text-muted-foreground/40 hover:text-muted-foreground/60"}`}>
                          <span className="w-4 h-0.5 rounded-full flex-shrink-0 transition-opacity" style={{ backgroundColor: color.replace(/[\d.]+\)$/, "1)"), opacity: active ? 1 : 0.3 }} />
                          <span className="flex-1 text-left">{EDGE_TYPE_LABELS[type]}</span>
                          <span className="text-xs text-muted-foreground/30 font-mono">{count}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </>
          )}

          {/* ── Constellation mode ── */}
          {mode === "constellation" && (
            <div className="flex-1 overflow-y-auto px-5 py-3 space-y-4">
              <p className="text-sm text-muted-foreground/50 leading-relaxed">
                Your constellation is a personal collection of nodes that matter to you. Star any node to add it here.
              </p>

              {constellationNodes.length === 0 ? (
                <div className="text-center py-10">
                  <Sparkles className="h-8 w-8 text-muted-foreground/15 mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground/30">No stars yet</p>
                  <p className="text-xs text-muted-foreground/20 mt-1">Click a node, then tap ★ to add it</p>
                </div>
              ) : (
                <div className="space-y-1">
                  {constellationNodes.map((node) => (
                    <div key={node.id} className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-muted/20 hover:bg-muted/30 transition-colors group">
                      <span className="text-sm">{NODE_TYPE_ICONS[node.type]}</span>
                      <button onClick={() => setSelectedNode(node)} className="flex-1 text-left">
                        <span className="text-sm text-foreground/80">{node.name}</span>
                        <span className="text-[10px] text-muted-foreground/40 ml-2 capitalize">{NODE_TYPE_LABELS[node.type]}</span>
                      </button>
                      <button onClick={() => toggleConstellation(node.id)} className="text-primary/40 hover:text-primary transition-colors opacity-0 group-hover:opacity-100">
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {constellationNodes.length > 0 && (
                <div className="pt-3 border-t border-border/10 space-y-2">
                  <p className="text-[10px] tracking-[0.15em] uppercase text-muted-foreground/30">
                    {constellationNodes.length} stars in your constellation
                  </p>
                </div>
              )}
            </div>
          )}

          {/* ── Connect mode (in sidebar) ── */}
          {mode === "connect" && (
            <div className="flex-1 overflow-y-auto px-5 py-3 space-y-4">
              <p className="text-sm text-muted-foreground/50 leading-relaxed">
                Create a new connection between two nodes. Select the source, then click a target node on the graph.
              </p>

              {/* Source */}
              <div>
                <p className="text-[10px] tracking-[0.15em] uppercase text-muted-foreground/40 mb-2">Source</p>
                {connectSource ? (
                  <div className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-primary/5 border border-primary/15">
                    <span className="text-sm">{NODE_TYPE_ICONS[connectSource.type]}</span>
                    <span className="text-sm text-foreground/80 flex-1">{connectSource.name}</span>
                    <button onClick={() => { setConnectSource(null); setConnectTarget(null); }} className="text-muted-foreground/30 hover:text-foreground/50">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground/30 px-3 py-2.5 rounded-lg border border-dashed border-border/20">
                    Select a node, then tap "Connect from here"
                  </p>
                )}
              </div>

              {/* Edge type */}
              <div>
                <p className="text-[10px] tracking-[0.15em] uppercase text-muted-foreground/40 mb-2">Relationship</p>
                <div className="space-y-1">
                  {ALL_EDGE_TYPES.map((type) => (
                    <button key={type} onClick={() => setConnectEdgeType(type)}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-all ${connectEdgeType === type ? "bg-primary/10 text-primary" : "text-muted-foreground/40 hover:text-muted-foreground/60"}`}>
                      <span className="flex-1 text-left capitalize">{EDGE_TYPE_LABELS[type]}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Target */}
              <div>
                <p className="text-[10px] tracking-[0.15em] uppercase text-muted-foreground/40 mb-2">Target</p>
                {connectTarget ? (
                  <div className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-primary/5 border border-primary/15">
                    <span className="text-sm">{NODE_TYPE_ICONS[connectTarget.type]}</span>
                    <span className="text-sm text-foreground/80 flex-1">{connectTarget.name}</span>
                    <button onClick={() => setConnectTarget(null)} className="text-muted-foreground/30 hover:text-foreground/50">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground/30 px-3 py-2.5 rounded-lg border border-dashed border-border/20">
                    {connectSource ? "Now click a target node on the graph" : "Select source first"}
                  </p>
                )}
              </div>

              {/* Complete */}
              {connectSource && connectTarget && (
                <button
                  onClick={completeConnect}
                  disabled={isReadOnly}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Plus className="h-4 w-4" />
                  Create connection
                </button>
              )}

              {isReadOnly && connectSource && connectTarget && (
                 <p className="text-[10px] text-red-500/60 text-center">Login to save connections</p>
              )}

              {(connectSource || connectTarget) && (
                <button
                  onClick={() => { setConnectSource(null); setConnectTarget(null); setMode("explore"); }}
                  className="w-full text-center text-xs text-muted-foreground/40 hover:text-muted-foreground/60 transition-colors py-2"
                >
                  Cancel
                </button>
              )}
            </div>
          )}

          {/* Footer */}
          <div className="px-5 py-3 border-t border-border/10">
            <p className="text-[10px] tracking-[0.2em] uppercase text-muted-foreground/20 text-center">
              Your trust universe
            </p>
          </div>
        </aside>
      )}

      {/* ── Graph area ── */}
      <main className="flex-1 relative">
        {!sidebarOpen && (
          <button onClick={() => setSidebarOpen(true)} className="absolute top-4 left-4 z-20 p-2.5 bg-card/80 backdrop-blur-sm border border-border/20 rounded-xl text-foreground/50 hover:text-foreground transition-all">
            <Network className="h-4 w-4" />
          </button>
        )}
        {sidebarOpen && (
          <button onClick={() => setSidebarOpen(false)} className="absolute top-4 left-4 z-20 p-2 text-foreground/30 hover:text-foreground/60 transition-colors" title="Hide sidebar">
            <X className="h-3.5 w-3.5" />
          </button>
        )}

        {/* Connect mode banner */}
        {mode === "connect" && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 px-5 py-2.5 bg-card/90 backdrop-blur-sm border border-primary/20 rounded-xl text-sm text-foreground/70 flex items-center gap-2">
            <Link2 className="h-4 w-4 text-primary" />
            {!connectSource ? "Click a source node" : !connectTarget ? "Now click a target node" : "Ready to connect"}
          </div>
        )}

        <TrustGraph
          data={graphData}
          activeNodeTypes={activeNodeTypes}
          activeEdgeTypes={activeEdgeTypes}
          searchQuery={searchQuery}
          onNodeClick={handleNodeClick}
          onRequestConnect={() => { setSidebarOpen(true); setMode("connect"); }}
        />

        {/* ── Selected node detail panel ── */}
        {selectedNode && mode !== "connect" && (
          <div className="absolute top-4 right-4 w-80 bg-card/90 backdrop-blur-sm border border-border/25 rounded-2xl overflow-hidden animate-fade-in z-20">
            <div className="px-5 pt-5 pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{NODE_TYPE_ICONS[selectedNode.type]}</span>
                  <div>
                    <h3 className="text-base font-display font-medium text-foreground">{selectedNode.name}</h3>
                    <p className="text-xs text-muted-foreground/50 capitalize">{NODE_TYPE_LABELS[selectedNode.type]}</p>
                  </div>
                </div>
                <button onClick={() => setSelectedNode(null)} className="p-1 text-foreground/30 hover:text-foreground/60 transition-colors">
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
              {selectedNode.description && (
                <p className="text-sm text-muted-foreground/60 mt-2 leading-relaxed">{selectedNode.description}</p>
              )}
              {selectedNode.trustLevel !== undefined && (
                <div className="mt-3 flex items-center gap-3">
                  <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                    <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${selectedNode.trustLevel * 100}%` }} />
                  </div>
                  <span className="text-xs font-mono text-muted-foreground/50">{Math.round(selectedNode.trustLevel * 100)}%</span>
                </div>
              )}
              {selectedNode.verified && (
                <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-500/10 text-green-600 dark:text-green-400 text-xs">
                  ✓ Verified
                </div>
              )}

              {/* ── Action buttons ── */}
              <div className="flex gap-2 mt-4">
                <button
                  onClick={() => toggleConstellation(selectedNode.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    constellation.has(selectedNode.id)
                      ? "bg-primary/15 text-primary"
                      : "bg-muted/30 text-muted-foreground/50 hover:text-foreground/70"
                  }`}
                >
                  <Star className={`h-3 w-3 ${constellation.has(selectedNode.id) ? "fill-primary" : ""}`} />
                  {constellation.has(selectedNode.id) ? "Starred" : "Star"}
                </button>
                <button
                  onClick={() => setAsWaypoint(selectedNode)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    waypoint?.id === selectedNode.id
                      ? "bg-primary/15 text-primary"
                      : "bg-muted/30 text-muted-foreground/50 hover:text-foreground/70"
                  }`}
                >
                  <MapPin className="h-3 w-3" />
                  Waypoint
                </button>
                <button
                  onClick={() => startConnect(selectedNode)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-muted/30 text-muted-foreground/50 hover:text-foreground/70 transition-all"
                >
                  <Link2 className="h-3 w-3" />
                  Connect
                </button>
              </div>
            </div>

            {/* Connections */}
            {nodeConnections.length > 0 && (
              <div className="border-t border-border/15 px-5 py-3">
                <p className="text-[10px] tracking-[0.15em] uppercase text-muted-foreground/40 mb-2">
                  {nodeConnections.length} connections
                </p>
                <div className="space-y-1 max-h-48 overflow-y-auto">
                  {nodeConnections.map(({ link, other }, i) => (
                    <button
                      key={`${other!.id}-${link.type}-${i}`}
                      onClick={() => waypoint ? followConnection(other as GraphNode) : setSelectedNode(other as GraphNode)}
                      className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-sm hover:bg-muted/30 transition-colors text-left"
                    >
                      <span className="text-xs opacity-60">{NODE_TYPE_ICONS[other!.type]}</span>
                      <span className="flex-1 text-foreground/80 truncate">{other!.name}</span>
                      <span className="text-[10px] text-muted-foreground/40 capitalize">{link.type}</span>
                      {waypoint && <ChevronRight className="h-3 w-3 text-muted-foreground/20" />}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
