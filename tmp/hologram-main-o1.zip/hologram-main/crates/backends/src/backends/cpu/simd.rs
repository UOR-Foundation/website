//! SIMD-optimized operations for CPU backend.
//!
//! Provides AVX2-accelerated implementations for arithmetic and activation
//! functions on x86_64, and NEON-accelerated implementations on aarch64.
//! Falls back to scalar operations on unsupported platforms.
//!
//! # Performance Optimizations
//!
//! - **Cached feature detection**: AVX2/NEON detection is cached using `OnceLock`
//!   to avoid repeated CPUID checks (~1-2ns overhead per call otherwise).
//! - **Loop unrolling**: Hot loops process 2x chunks per iteration for better ILP.
//! - **Inline wrappers**: Safe wrappers are marked `#[inline]` for zero overhead.

// Allow wildcard imports for SIMD intrinsics - explicit imports would be very verbose
#![allow(clippy::wildcard_imports)]
// Allow excessive precision for mathematical constants
#![allow(clippy::excessive_precision)]
// Allow approximate constants for Taylor series coefficients
#![allow(clippy::approx_constant)]

/// Cached AVX2 feature detection result.
/// Avoids calling `is_x86_feature_detected!` on every function call.
#[cfg(target_arch = "x86_64")]
static AVX2_SUPPORTED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();

/// Returns true if AVX2 is supported, caching the result.
#[cfg(target_arch = "x86_64")]
#[inline]
fn has_avx2_cached() -> bool {
    *AVX2_SUPPORTED.get_or_init(|| is_x86_feature_detected!("avx2"))
}

/// Process 8 f32 values per AVX2 iteration
#[cfg(target_arch = "x86_64")]
const AVX2_F32_LANES: usize = 8;

/// Process 4 f32 values per NEON iteration
#[cfg(target_arch = "aarch64")]
const NEON_F32_LANES: usize = 4;

/// Process 16 f32 values per AVX-512 iteration
#[cfg(target_arch = "x86_64")]
const AVX512_F32_LANES: usize = 16;

/// Prefetch distance in f32 elements (4 cache lines = 256 bytes = 64 f32s).
/// Software prefetch 2-4 cache lines ahead reduces L2→L1 transfer stalls
/// for streaming element-wise operations on buffers > 64 KB (TASK-325).
///
/// **Benchmark finding:** On aarch64 (Apple Silicon), hardware prefetch for
/// sequential access is excellent. Software prefetch adds per-instruction
/// overhead without measurable benefit on NEON loops. Prefetch is therefore
/// only active on x86_64 where hardware prefetch varies across
/// Intel/AMD microarchitectures.
#[cfg(target_arch = "x86_64")]
const PREFETCH_DISTANCE: usize = 64;

/// x86_64 software prefetch: hint to load `addr` into L1 cache.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
#[inline(always)]
unsafe fn prefetch_read_x86(addr: *const f32) {
    use std::arch::x86_64::*;
    _mm_prefetch(addr.cast::<i8>(), _MM_HINT_T0);
}

// ============================================================================
// AVX2 Arithmetic Operations (TASK-046)
// ============================================================================

/// AVX2-optimized element-wise addition
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn add_avx2(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    // Process 8 elements at a time
    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        // Software prefetch 4 cache lines ahead (TASK-325)
        prefetch_read_x86(a.as_ptr().add(offset + PREFETCH_DISTANCE));
        prefetch_read_x86(b.as_ptr().add(offset + PREFETCH_DISTANCE));
        let va = _mm256_loadu_ps(a.as_ptr().add(offset));
        let vb = _mm256_loadu_ps(b.as_ptr().add(offset));
        let vr = _mm256_add_ps(va, vb);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    // Handle remainder with scalar operations
    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i] + b[base + i];
    }
}

/// AVX2-optimized element-wise subtraction
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn sub_avx2(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        prefetch_read_x86(a.as_ptr().add(offset + PREFETCH_DISTANCE));
        prefetch_read_x86(b.as_ptr().add(offset + PREFETCH_DISTANCE));
        let va = _mm256_loadu_ps(a.as_ptr().add(offset));
        let vb = _mm256_loadu_ps(b.as_ptr().add(offset));
        let vr = _mm256_sub_ps(va, vb);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i] - b[base + i];
    }
}

/// AVX2-optimized element-wise multiplication
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn mul_avx2(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        prefetch_read_x86(a.as_ptr().add(offset + PREFETCH_DISTANCE));
        prefetch_read_x86(b.as_ptr().add(offset + PREFETCH_DISTANCE));
        let va = _mm256_loadu_ps(a.as_ptr().add(offset));
        let vb = _mm256_loadu_ps(b.as_ptr().add(offset));
        let vr = _mm256_mul_ps(va, vb);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i] * b[base + i];
    }
}

// ============================================================================
// AVX2 Activation Functions (TASK-047)
// ============================================================================

/// AVX2-optimized ReLU: max(0, x)
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn relu_avx2(src: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = src.len().min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    let zeros = _mm256_setzero_ps();

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        prefetch_read_x86(src.as_ptr().add(offset + PREFETCH_DISTANCE));
        let v = _mm256_loadu_ps(src.as_ptr().add(offset));
        // max(0, x) using _mm256_max_ps
        let vr = _mm256_max_ps(zeros, v);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].max(0.0);
    }
}

/// AVX2-optimized fast exponential approximation using polynomial.
/// Uses a degree-6 polynomial approximation accurate to ~1e-5 for x in [-88, 88].
/// exp(x) ≈ 2^(x * log2(e)) using integer/fractional split.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
#[inline]
unsafe fn exp_avx2(x: std::arch::x86_64::__m256) -> std::arch::x86_64::__m256 {
    use std::arch::x86_64::*;

    // Constants for exp approximation
    let log2e = _mm256_set1_ps(1.442_695_04); // log2(e)

    // Polynomial coefficients for 2^f where f in [-0.5, 0.5]
    let c0 = _mm256_set1_ps(1.0);
    let c1 = _mm256_set1_ps(0.693_147_18); // ln(2)
    let c2 = _mm256_set1_ps(0.240_226_51); // ln(2)^2 / 2!
    let c3 = _mm256_set1_ps(0.055_504_109); // ln(2)^3 / 3!
    let c4 = _mm256_set1_ps(0.009_618_129); // ln(2)^4 / 4!
    let c5 = _mm256_set1_ps(0.001_333_356); // ln(2)^5 / 5!

    // Clamp input to avoid overflow/underflow
    let min_val = _mm256_set1_ps(-88.0);
    let max_val = _mm256_set1_ps(88.0);
    let x = _mm256_max_ps(_mm256_min_ps(x, max_val), min_val);

    // Convert to base-2: t = x * log2(e)
    let t = _mm256_mul_ps(x, log2e);

    // Split into integer and fractional parts: t = n + f
    let n = _mm256_round_ps(t, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);

    // Fractional part: f = t - n (in [-0.5, 0.5])
    let f = _mm256_sub_ps(t, n);

    // Evaluate polynomial: 2^f ≈ c0 + c1*f + c2*f^2 + c3*f^3 + c4*f^4 + c5*f^5
    // Using Horner's method: ((((c5*f + c4)*f + c3)*f + c2)*f + c1)*f + c0
    let mut poly = c5;
    poly = _mm256_add_ps(_mm256_mul_ps(poly, f), c4);
    poly = _mm256_add_ps(_mm256_mul_ps(poly, f), c3);
    poly = _mm256_add_ps(_mm256_mul_ps(poly, f), c2);
    poly = _mm256_add_ps(_mm256_mul_ps(poly, f), c1);
    poly = _mm256_add_ps(_mm256_mul_ps(poly, f), c0);

    // Compute 2^n by adding n to the exponent bits
    // IEEE 754: exponent is bits 23-30, bias is 127
    let n_i32 = _mm256_cvtps_epi32(n);
    let shift = _mm256_slli_epi32(n_i32, 23);
    let pow2n = _mm256_castsi256_ps(_mm256_add_epi32(shift, _mm256_set1_epi32(0x3f80_0000)));

    // Result: 2^n * 2^f = exp(x)
    _mm256_mul_ps(pow2n, poly)
}

/// AVX2-optimized Sigmoid: 1 / (1 + exp(-x))
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn sigmoid_avx2(src: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = src.len().min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    let ones = _mm256_set1_ps(1.0);

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let x = _mm256_loadu_ps(src.as_ptr().add(offset));

        // sigmoid(x) = 1 / (1 + exp(-x))
        let neg_x = _mm256_sub_ps(_mm256_setzero_ps(), x);
        let exp_neg_x = exp_avx2(neg_x);
        let denom = _mm256_add_ps(ones, exp_neg_x);
        let vr = _mm256_div_ps(ones, denom);

        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        let x = src[base + i];
        result[base + i] = 1.0 / (1.0 + (-x).exp());
    }
}

/// AVX2-optimized Tanh: (exp(2x) - 1) / (exp(2x) + 1) = 2*sigmoid(2x) - 1
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn tanh_avx2(src: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = src.len().min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    let ones = _mm256_set1_ps(1.0);
    let twos = _mm256_set1_ps(2.0);

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let x = _mm256_loadu_ps(src.as_ptr().add(offset));

        // tanh(x) = 2*sigmoid(2x) - 1
        let two_x = _mm256_mul_ps(twos, x);
        let neg_two_x = _mm256_sub_ps(_mm256_setzero_ps(), two_x);
        let exp_neg = exp_avx2(neg_two_x);
        let denom = _mm256_add_ps(ones, exp_neg);
        let sigmoid_2x = _mm256_div_ps(ones, denom);
        let vr = _mm256_sub_ps(_mm256_mul_ps(twos, sigmoid_2x), ones);

        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].tanh();
    }
}

// ============================================================================
// AVX-512 Arithmetic Operations (when available)
// ============================================================================

/// AVX-512 element-wise addition
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx512f")]
pub unsafe fn add_avx512(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / AVX512_F32_LANES;
    let remainder = len % AVX512_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX512_F32_LANES;
        let va = _mm512_loadu_ps(a.as_ptr().add(offset));
        let vb = _mm512_loadu_ps(b.as_ptr().add(offset));
        let vr = _mm512_add_ps(va, vb);
        _mm512_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    // Handle remainder with AVX2 or scalar
    let base = chunks * AVX512_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i] + b[base + i];
    }
}

/// AVX-512 element-wise subtraction
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx512f")]
pub unsafe fn sub_avx512(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / AVX512_F32_LANES;
    let remainder = len % AVX512_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX512_F32_LANES;
        let va = _mm512_loadu_ps(a.as_ptr().add(offset));
        let vb = _mm512_loadu_ps(b.as_ptr().add(offset));
        let vr = _mm512_sub_ps(va, vb);
        _mm512_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX512_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i] - b[base + i];
    }
}

/// AVX-512 element-wise multiplication
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx512f")]
pub unsafe fn mul_avx512(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / AVX512_F32_LANES;
    let remainder = len % AVX512_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX512_F32_LANES;
        let va = _mm512_loadu_ps(a.as_ptr().add(offset));
        let vb = _mm512_loadu_ps(b.as_ptr().add(offset));
        let vr = _mm512_mul_ps(va, vb);
        _mm512_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX512_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i] * b[base + i];
    }
}

/// AVX-512 ReLU: max(0, x)
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx512f")]
pub unsafe fn relu_avx512(src: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = src.len().min(result.len());
    let chunks = len / AVX512_F32_LANES;
    let remainder = len % AVX512_F32_LANES;

    let zeros = _mm512_setzero_ps();

    for i in 0..chunks {
        let offset = i * AVX512_F32_LANES;
        let v = _mm512_loadu_ps(src.as_ptr().add(offset));
        let vr = _mm512_max_ps(zeros, v);
        _mm512_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX512_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].max(0.0);
    }
}

/// AVX-512 fast exponential approximation using polynomial.
/// Uses a degree-6 polynomial approximation accurate to ~1e-5 for x in [-88, 88].
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx512f")]
#[inline]
unsafe fn exp_avx512(x: std::arch::x86_64::__m512) -> std::arch::x86_64::__m512 {
    use std::arch::x86_64::*;

    let log2e = _mm512_set1_ps(1.442_695_04);

    // Polynomial coefficients for 2^f where f in [-0.5, 0.5]
    let c0 = _mm512_set1_ps(1.0);
    let c1 = _mm512_set1_ps(0.693_147_18);
    let c2 = _mm512_set1_ps(0.240_226_51);
    let c3 = _mm512_set1_ps(0.055_504_109);
    let c4 = _mm512_set1_ps(0.009_618_129);
    let c5 = _mm512_set1_ps(0.001_333_356);

    // Clamp input to avoid overflow/underflow
    let min_val = _mm512_set1_ps(-88.0);
    let max_val = _mm512_set1_ps(88.0);
    let x = _mm512_max_ps(_mm512_min_ps(x, max_val), min_val);

    // Convert to base-2: t = x * log2(e)
    let t = _mm512_mul_ps(x, log2e);

    // Split into integer and fractional parts
    let n = _mm512_roundscale_ps(t, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
    let f = _mm512_sub_ps(t, n);

    // Evaluate polynomial using Horner's method
    let mut poly = c5;
    poly = _mm512_add_ps(_mm512_mul_ps(poly, f), c4);
    poly = _mm512_add_ps(_mm512_mul_ps(poly, f), c3);
    poly = _mm512_add_ps(_mm512_mul_ps(poly, f), c2);
    poly = _mm512_add_ps(_mm512_mul_ps(poly, f), c1);
    poly = _mm512_add_ps(_mm512_mul_ps(poly, f), c0);

    // Compute 2^n by manipulating IEEE 754 exponent bits
    let n_i32 = _mm512_cvtps_epi32(n);
    let shift = _mm512_slli_epi32(n_i32, 23);
    let bias = _mm512_set1_epi32(0x3f80_0000);
    let pow2n = _mm512_castsi512_ps(_mm512_add_epi32(shift, bias));

    _mm512_mul_ps(pow2n, poly)
}

/// AVX-512 Sigmoid: 1 / (1 + exp(-x))
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx512f")]
pub unsafe fn sigmoid_avx512(src: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = src.len().min(result.len());
    let chunks = len / AVX512_F32_LANES;
    let remainder = len % AVX512_F32_LANES;

    let ones = _mm512_set1_ps(1.0);

    for i in 0..chunks {
        let offset = i * AVX512_F32_LANES;
        let x = _mm512_loadu_ps(src.as_ptr().add(offset));

        let neg_x = _mm512_sub_ps(_mm512_setzero_ps(), x);
        let exp_neg_x = exp_avx512(neg_x);
        let denom = _mm512_add_ps(ones, exp_neg_x);
        let vr = _mm512_div_ps(ones, denom);

        _mm512_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX512_F32_LANES;
    for i in 0..remainder {
        let x = src[base + i];
        result[base + i] = 1.0 / (1.0 + (-x).exp());
    }
}

/// AVX-512 Tanh: 2*sigmoid(2x) - 1
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx512f")]
pub unsafe fn tanh_avx512(src: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = src.len().min(result.len());
    let chunks = len / AVX512_F32_LANES;
    let remainder = len % AVX512_F32_LANES;

    let ones = _mm512_set1_ps(1.0);
    let twos = _mm512_set1_ps(2.0);

    for i in 0..chunks {
        let offset = i * AVX512_F32_LANES;
        let x = _mm512_loadu_ps(src.as_ptr().add(offset));

        let two_x = _mm512_mul_ps(twos, x);
        let neg_two_x = _mm512_sub_ps(_mm512_setzero_ps(), two_x);
        let exp_neg = exp_avx512(neg_two_x);
        let denom = _mm512_add_ps(ones, exp_neg);
        let sigmoid_2x = _mm512_div_ps(ones, denom);
        let vr = _mm512_sub_ps(_mm512_mul_ps(twos, sigmoid_2x), ones);

        _mm512_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX512_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].tanh();
    }
}

// ============================================================================
// ARM NEON Arithmetic Operations
// ============================================================================

/// NEON-optimized element-wise addition
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn add_neon(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let va = vld1q_f32(a.as_ptr().add(offset));
        let vb = vld1q_f32(b.as_ptr().add(offset));
        let vr = vaddq_f32(va, vb);
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i] + b[base + i];
    }
}

/// NEON-optimized element-wise subtraction
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn sub_neon(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let va = vld1q_f32(a.as_ptr().add(offset));
        let vb = vld1q_f32(b.as_ptr().add(offset));
        let vr = vsubq_f32(va, vb);
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i] - b[base + i];
    }
}

/// NEON-optimized element-wise multiplication
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn mul_neon(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let va = vld1q_f32(a.as_ptr().add(offset));
        let vb = vld1q_f32(b.as_ptr().add(offset));
        let vr = vmulq_f32(va, vb);
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i] * b[base + i];
    }
}

// ============================================================================
// ARM NEON Activation Functions
// ============================================================================

/// NEON-optimized ReLU: max(0, x)
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn relu_neon(src: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = src.len().min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    let zeros = vdupq_n_f32(0.0);

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let v = vld1q_f32(src.as_ptr().add(offset));
        let vr = vmaxq_f32(zeros, v);
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].max(0.0);
    }
}

/// NEON-optimized fast exponential approximation using polynomial.
/// Uses range reduction to base-2 and polynomial approximation for 2^f.
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
#[inline]
unsafe fn exp_neon(x: std::arch::aarch64::float32x4_t) -> std::arch::aarch64::float32x4_t {
    use std::arch::aarch64::*;

    let log2e = vdupq_n_f32(1.442_695_04);

    // Polynomial coefficients for 2^f where f in [-0.5, 0.5]
    let c0 = vdupq_n_f32(1.0);
    let c1 = vdupq_n_f32(0.693_147_18); // ln(2)
    let c2 = vdupq_n_f32(0.240_226_51); // ln(2)^2 / 2!
    let c3 = vdupq_n_f32(0.055_504_109); // ln(2)^3 / 3!
    let c4 = vdupq_n_f32(0.009_618_129); // ln(2)^4 / 4!
    let c5 = vdupq_n_f32(0.001_333_356); // ln(2)^5 / 5!

    let min_val = vdupq_n_f32(-88.0);
    let max_val = vdupq_n_f32(88.0);
    let x = vmaxq_f32(vminq_f32(x, max_val), min_val);

    // Convert to base-2: t = x * log2(e)
    let t = vmulq_f32(x, log2e);

    // Split into integer and fractional parts: t = n + f
    let n = vrndnq_f32(t);
    let f = vsubq_f32(t, n); // f is in [-0.5, 0.5]

    // Evaluate 2^f using polynomial (Horner's method)
    // 2^f ≈ c0 + c1*f + c2*f^2 + c3*f^3 + c4*f^4 + c5*f^5
    let mut poly = c5;
    poly = vaddq_f32(vmulq_f32(poly, f), c4);
    poly = vaddq_f32(vmulq_f32(poly, f), c3);
    poly = vaddq_f32(vmulq_f32(poly, f), c2);
    poly = vaddq_f32(vmulq_f32(poly, f), c1);
    poly = vaddq_f32(vmulq_f32(poly, f), c0);

    // Compute 2^n by manipulating IEEE 754 exponent bits
    let n_i32 = vcvtq_s32_f32(n);
    let shift = vshlq_n_s32(n_i32, 23);
    let bias = vdupq_n_s32(0x3f80_0000);
    let pow2n = vreinterpretq_f32_s32(vaddq_s32(shift, bias));

    // Result: 2^n * 2^f = 2^(n+f) = 2^t = e^x
    vmulq_f32(pow2n, poly)
}

/// NEON-optimized Sigmoid: 1 / (1 + exp(-x))
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn sigmoid_neon(src: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::{vaddq_f32, vdivq_f32, vdupq_n_f32, vld1q_f32, vst1q_f32, vsubq_f32};

    let len = src.len().min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    let ones = vdupq_n_f32(1.0);
    let zeros = vdupq_n_f32(0.0);

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let x = vld1q_f32(src.as_ptr().add(offset));

        let neg_x = vsubq_f32(zeros, x);
        let exp_neg_x = exp_neon(neg_x);
        let denom = vaddq_f32(ones, exp_neg_x);
        let vr = vdivq_f32(ones, denom);

        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        let x = src[base + i];
        result[base + i] = 1.0 / (1.0 + (-x).exp());
    }
}

/// NEON-optimized Tanh: 2*sigmoid(2x) - 1
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn tanh_neon(src: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::{
        vaddq_f32, vdivq_f32, vdupq_n_f32, vld1q_f32, vmulq_f32, vst1q_f32, vsubq_f32,
    };

    let len = src.len().min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    let ones = vdupq_n_f32(1.0);
    let twos = vdupq_n_f32(2.0);
    let zeros = vdupq_n_f32(0.0);

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let x = vld1q_f32(src.as_ptr().add(offset));

        let two_x = vmulq_f32(twos, x);
        let neg_two_x = vsubq_f32(zeros, two_x);
        let exp_neg = exp_neon(neg_two_x);
        let denom = vaddq_f32(ones, exp_neg);
        let sigmoid_2x = vdivq_f32(ones, denom);
        let vr = vsubq_f32(vmulq_f32(twos, sigmoid_2x), ones);

        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].tanh();
    }
}

// ============================================================================
// Runtime Feature Detection
// ============================================================================

/// Check if AVX2 is available at runtime
#[cfg(target_arch = "x86_64")]
#[inline]
fn has_avx2() -> bool {
    has_avx2_cached()
}

/// NEON is always available on aarch64
#[cfg(target_arch = "aarch64")]
#[inline]
fn has_neon() -> bool {
    true
}

/// Check if AVX-512F is available at runtime
#[cfg(target_arch = "x86_64")]
#[inline]
fn has_avx512f() -> bool {
    is_x86_feature_detected!("avx512f")
}

// ============================================================================
// Safe Wrapper Functions
// ============================================================================

/// Safe wrapper for SIMD add with runtime detection (AVX-512/AVX2 on x86_64, NEON on aarch64)
pub fn add_simd(a: &[f32], b: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    {
        // Try AVX-512 first (2x wider than AVX2)
        if has_avx512f() {
            unsafe {
                add_avx512(a, b, result);
            }
            return;
        }
        if has_avx2() {
            // Safety: We've verified AVX2 is available
            unsafe {
                add_avx2(a, b, result);
            }
            return;
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_neon() {
            // Safety: NEON is always available on aarch64
            unsafe {
                add_neon(a, b, result);
            }
            return;
        }
    }
    // Scalar fallback
    add_scalar(a, b, result);
}

/// Safe wrapper for SIMD sub with runtime detection (AVX-512/AVX2 on x86_64, NEON on aarch64)
pub fn sub_simd(a: &[f32], b: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    {
        if has_avx512f() {
            unsafe {
                sub_avx512(a, b, result);
            }
            return;
        }
        if has_avx2() {
            unsafe {
                sub_avx2(a, b, result);
            }
            return;
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_neon() {
            unsafe {
                sub_neon(a, b, result);
            }
            return;
        }
    }
    sub_scalar(a, b, result);
}

/// Safe wrapper for SIMD mul with runtime detection (AVX-512/AVX2 on x86_64, NEON on aarch64)
pub fn mul_simd(a: &[f32], b: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    {
        if has_avx512f() {
            unsafe {
                mul_avx512(a, b, result);
            }
            return;
        }
        if has_avx2() {
            unsafe {
                mul_avx2(a, b, result);
            }
            return;
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_neon() {
            unsafe {
                mul_neon(a, b, result);
            }
            return;
        }
    }
    mul_scalar(a, b, result);
}

/// Safe wrapper for SIMD relu with runtime detection (AVX-512/AVX2 on x86_64, NEON on aarch64)
pub fn relu_simd(src: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    {
        if has_avx512f() {
            unsafe {
                relu_avx512(src, result);
            }
            return;
        }
        if has_avx2() {
            unsafe {
                relu_avx2(src, result);
            }
            return;
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_neon() {
            unsafe {
                relu_neon(src, result);
            }
            return;
        }
    }
    relu_scalar(src, result);
}

/// Safe wrapper for SIMD sigmoid with runtime detection (AVX-512/AVX2 on x86_64, NEON on aarch64)
pub fn sigmoid_simd(src: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    {
        if has_avx512f() {
            unsafe {
                sigmoid_avx512(src, result);
            }
            return;
        }
        if has_avx2() {
            unsafe {
                sigmoid_avx2(src, result);
            }
            return;
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_neon() {
            unsafe {
                sigmoid_neon(src, result);
            }
            return;
        }
    }
    sigmoid_scalar(src, result);
}

/// Safe wrapper for SIMD tanh with runtime detection (AVX-512/AVX2 on x86_64, NEON on aarch64)
pub fn tanh_simd(src: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    {
        if has_avx512f() {
            unsafe {
                tanh_avx512(src, result);
            }
            return;
        }
        if has_avx2() {
            unsafe {
                tanh_avx2(src, result);
            }
            return;
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_neon() {
            unsafe {
                tanh_neon(src, result);
            }
            return;
        }
    }
    tanh_scalar(src, result);
}

// ============================================================================
// SIMD Reduction Operations
// ============================================================================

/// AVX2-optimized horizontal sum reduction
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn sum_avx2(src: &[f32]) -> f32 {
    use std::arch::x86_64::*;

    let len = src.len();
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    // Accumulate in vector
    let mut acc = _mm256_setzero_ps();
    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let v = _mm256_loadu_ps(src.as_ptr().add(offset));
        acc = _mm256_add_ps(acc, v);
    }

    // Horizontal reduction: 8 -> 4 -> 2 -> 1
    let hi = _mm256_extractf128_ps(acc, 1);
    let lo = _mm256_castps256_ps128(acc);
    let sum128 = _mm_add_ps(lo, hi);
    let sum64 = _mm_add_ps(sum128, _mm_movehl_ps(sum128, sum128));
    let sum32 = _mm_add_ss(sum64, _mm_shuffle_ps(sum64, sum64, 1));

    let mut result = _mm_cvtss_f32(sum32);

    // Add remainder
    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result += src[base + i];
    }

    result
}

/// AVX2-optimized horizontal max reduction
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn max_avx2(src: &[f32]) -> f32 {
    use std::arch::x86_64::*;

    if src.is_empty() {
        return f32::NEG_INFINITY;
    }

    let len = src.len();
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    // Start with negative infinity
    let mut acc = _mm256_set1_ps(f32::NEG_INFINITY);
    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let v = _mm256_loadu_ps(src.as_ptr().add(offset));
        acc = _mm256_max_ps(acc, v);
    }

    // Horizontal max: 8 -> 4 -> 2 -> 1
    let hi = _mm256_extractf128_ps(acc, 1);
    let lo = _mm256_castps256_ps128(acc);
    let max128 = _mm_max_ps(lo, hi);
    let max64 = _mm_max_ps(max128, _mm_movehl_ps(max128, max128));
    let max32 = _mm_max_ss(max64, _mm_shuffle_ps(max64, max64, 1));

    let mut result = _mm_cvtss_f32(max32);

    // Check remainder
    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result = result.max(src[base + i]);
    }

    result
}

/// AVX2-optimized horizontal min reduction
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn min_avx2(src: &[f32]) -> f32 {
    use std::arch::x86_64::*;

    if src.is_empty() {
        return f32::INFINITY;
    }

    let len = src.len();
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    // Start with positive infinity
    let mut acc = _mm256_set1_ps(f32::INFINITY);
    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let v = _mm256_loadu_ps(src.as_ptr().add(offset));
        acc = _mm256_min_ps(acc, v);
    }

    // Horizontal min: 8 -> 4 -> 2 -> 1
    let hi = _mm256_extractf128_ps(acc, 1);
    let lo = _mm256_castps256_ps128(acc);
    let min128 = _mm_min_ps(lo, hi);
    let min64 = _mm_min_ps(min128, _mm_movehl_ps(min128, min128));
    let min32 = _mm_min_ss(min64, _mm_shuffle_ps(min64, min64, 1));

    let mut result = _mm_cvtss_f32(min32);

    // Check remainder
    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result = result.min(src[base + i]);
    }

    result
}

/// NEON-optimized horizontal sum reduction
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn sum_neon(src: &[f32]) -> f32 {
    use std::arch::aarch64::*;

    let len = src.len();
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    // Accumulate in vector
    let mut acc = vdupq_n_f32(0.0);
    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let v = vld1q_f32(src.as_ptr().add(offset));
        acc = vaddq_f32(acc, v);
    }

    // Horizontal sum using pairwise addition
    let sum = vaddvq_f32(acc);

    // Add remainder
    let mut result = sum;
    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result += src[base + i];
    }

    result
}

/// NEON-optimized horizontal max reduction
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn max_neon(src: &[f32]) -> f32 {
    use std::arch::aarch64::*;

    if src.is_empty() {
        return f32::NEG_INFINITY;
    }

    let len = src.len();
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    let mut acc = vdupq_n_f32(f32::NEG_INFINITY);
    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let v = vld1q_f32(src.as_ptr().add(offset));
        acc = vmaxq_f32(acc, v);
    }

    let max = vmaxvq_f32(acc);

    let mut result = max;
    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result = result.max(src[base + i]);
    }

    result
}

/// NEON-optimized horizontal min reduction
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn min_neon(src: &[f32]) -> f32 {
    use std::arch::aarch64::*;

    if src.is_empty() {
        return f32::INFINITY;
    }

    let len = src.len();
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    let mut acc = vdupq_n_f32(f32::INFINITY);
    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let v = vld1q_f32(src.as_ptr().add(offset));
        acc = vminq_f32(acc, v);
    }

    let min = vminvq_f32(acc);

    let mut result = min;
    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result = result.min(src[base + i]);
    }

    result
}

/// Safe wrapper for SIMD sum with runtime detection
#[must_use]
pub fn sum_simd(src: &[f32]) -> f32 {
    #[cfg(target_arch = "x86_64")]
    {
        if has_avx2() {
            return unsafe { sum_avx2(src) };
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_neon() {
            return unsafe { sum_neon(src) };
        }
    }
    sum_scalar(src)
}

/// Safe wrapper for SIMD max with runtime detection
#[must_use]
pub fn max_simd(src: &[f32]) -> f32 {
    #[cfg(target_arch = "x86_64")]
    {
        if has_avx2() {
            return unsafe { max_avx2(src) };
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_neon() {
            return unsafe { max_neon(src) };
        }
    }
    max_scalar(src)
}

/// Safe wrapper for SIMD min with runtime detection
#[must_use]
pub fn min_simd(src: &[f32]) -> f32 {
    #[cfg(target_arch = "x86_64")]
    {
        if has_avx2() {
            return unsafe { min_avx2(src) };
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_neon() {
            return unsafe { min_neon(src) };
        }
    }
    min_scalar(src)
}

/// Scalar sum reduction
#[must_use]
pub fn sum_scalar(src: &[f32]) -> f32 {
    src.iter().sum()
}

/// Scalar max reduction
pub fn max_scalar(src: &[f32]) -> f32 {
    src.iter().copied().fold(f32::NEG_INFINITY, f32::max)
}

/// Scalar min reduction
pub fn min_scalar(src: &[f32]) -> f32 {
    src.iter().copied().fold(f32::INFINITY, f32::min)
}

// ============================================================================
// Scalar Fallback Implementations
// ============================================================================

/// Scalar element-wise addition
pub fn add_scalar(a: &[f32], b: &[f32], result: &mut [f32]) {
    let len = a.len().min(b.len()).min(result.len());
    for i in 0..len {
        result[i] = a[i] + b[i];
    }
}

/// Scalar element-wise subtraction
pub fn sub_scalar(a: &[f32], b: &[f32], result: &mut [f32]) {
    let len = a.len().min(b.len()).min(result.len());
    for i in 0..len {
        result[i] = a[i] - b[i];
    }
}

/// Scalar element-wise multiplication
pub fn mul_scalar(a: &[f32], b: &[f32], result: &mut [f32]) {
    let len = a.len().min(b.len()).min(result.len());
    for i in 0..len {
        result[i] = a[i] * b[i];
    }
}

/// Scalar ReLU
pub fn relu_scalar(src: &[f32], result: &mut [f32]) {
    let len = src.len().min(result.len());
    for i in 0..len {
        result[i] = src[i].max(0.0);
    }
}

/// Scalar Sigmoid: 1 / (1 + exp(-x))
pub fn sigmoid_scalar(src: &[f32], result: &mut [f32]) {
    let len = src.len().min(result.len());
    for i in 0..len {
        result[i] = 1.0 / (1.0 + (-src[i]).exp());
    }
}

/// Scalar Tanh
pub fn tanh_scalar(src: &[f32], result: &mut [f32]) {
    let len = src.len().min(result.len());
    for i in 0..len {
        result[i] = src[i].tanh();
    }
}

// ============================================================================
// In-Place SIMD Operations (TASK-324)
//
// For commutative operations (add, mul) where dst aliases a, we can
// modify the buffer directly without a scratch copy. These functions
// take `dst_a: &mut [f32]` (both source and destination) and `b: &[f32]`.
// ============================================================================

/// AVX2 in-place addition: dst_a[i] += b[i]
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
unsafe fn add_inplace_avx2(dst_a: &mut [f32], b: &[f32]) {
    use std::arch::x86_64::*;

    let len = dst_a.len().min(b.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let va = _mm256_loadu_ps(dst_a.as_ptr().add(offset));
        let vb = _mm256_loadu_ps(b.as_ptr().add(offset));
        _mm256_storeu_ps(dst_a.as_mut_ptr().add(offset), _mm256_add_ps(va, vb));
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        dst_a[base + i] += b[base + i];
    }
}

/// AVX2 in-place multiplication: dst_a[i] *= b[i]
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
unsafe fn add_inplace_mul_avx2(dst_a: &mut [f32], b: &[f32]) {
    use std::arch::x86_64::*;

    let len = dst_a.len().min(b.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let va = _mm256_loadu_ps(dst_a.as_ptr().add(offset));
        let vb = _mm256_loadu_ps(b.as_ptr().add(offset));
        _mm256_storeu_ps(dst_a.as_mut_ptr().add(offset), _mm256_mul_ps(va, vb));
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        dst_a[base + i] *= b[base + i];
    }
}

/// AVX-512 in-place addition: dst_a[i] += b[i]
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx512f")]
unsafe fn add_inplace_avx512(dst_a: &mut [f32], b: &[f32]) {
    use std::arch::x86_64::*;

    let len = dst_a.len().min(b.len());
    let chunks = len / AVX512_F32_LANES;
    let remainder = len % AVX512_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX512_F32_LANES;
        let va = _mm512_loadu_ps(dst_a.as_ptr().add(offset));
        let vb = _mm512_loadu_ps(b.as_ptr().add(offset));
        _mm512_storeu_ps(dst_a.as_mut_ptr().add(offset), _mm512_add_ps(va, vb));
    }

    let base = chunks * AVX512_F32_LANES;
    for i in 0..remainder {
        dst_a[base + i] += b[base + i];
    }
}

/// AVX-512 in-place multiplication: dst_a[i] *= b[i]
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx512f")]
unsafe fn mul_inplace_avx512(dst_a: &mut [f32], b: &[f32]) {
    use std::arch::x86_64::*;

    let len = dst_a.len().min(b.len());
    let chunks = len / AVX512_F32_LANES;
    let remainder = len % AVX512_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX512_F32_LANES;
        let va = _mm512_loadu_ps(dst_a.as_ptr().add(offset));
        let vb = _mm512_loadu_ps(b.as_ptr().add(offset));
        _mm512_storeu_ps(dst_a.as_mut_ptr().add(offset), _mm512_mul_ps(va, vb));
    }

    let base = chunks * AVX512_F32_LANES;
    for i in 0..remainder {
        dst_a[base + i] *= b[base + i];
    }
}

/// NEON in-place addition: dst_a[i] += b[i]
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn add_inplace_neon(dst_a: &mut [f32], b: &[f32]) {
    use std::arch::aarch64::*;

    let len = dst_a.len().min(b.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let va = vld1q_f32(dst_a.as_ptr().add(offset));
        let vb = vld1q_f32(b.as_ptr().add(offset));
        vst1q_f32(dst_a.as_mut_ptr().add(offset), vaddq_f32(va, vb));
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        dst_a[base + i] += b[base + i];
    }
}

/// NEON in-place multiplication: dst_a[i] *= b[i]
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn mul_inplace_neon(dst_a: &mut [f32], b: &[f32]) {
    use std::arch::aarch64::*;

    let len = dst_a.len().min(b.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let va = vld1q_f32(dst_a.as_ptr().add(offset));
        let vb = vld1q_f32(b.as_ptr().add(offset));
        vst1q_f32(dst_a.as_mut_ptr().add(offset), vmulq_f32(va, vb));
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        dst_a[base + i] *= b[base + i];
    }
}

/// Scalar in-place addition: dst_a[i] += b[i]
#[inline]
fn add_inplace_scalar(dst_a: &mut [f32], b: &[f32]) {
    let len = dst_a.len().min(b.len());
    for i in 0..len {
        dst_a[i] += b[i];
    }
}

/// Scalar in-place multiplication: dst_a[i] *= b[i]
#[inline]
fn mul_inplace_scalar(dst_a: &mut [f32], b: &[f32]) {
    let len = dst_a.len().min(b.len());
    for i in 0..len {
        dst_a[i] *= b[i];
    }
}

/// Safe in-place addition with runtime SIMD detection.
///
/// Modifies `dst_a` in place: `dst_a[i] += b[i]`.
/// Avoids scratch buffer allocation for commutative in-place operations.
#[inline]
pub fn add_inplace_simd(dst_a: &mut [f32], b: &[f32]) {
    #[cfg(target_arch = "x86_64")]
    {
        if has_avx512f() {
            unsafe { add_inplace_avx512(dst_a, b) };
            return;
        }
        if has_avx2() {
            unsafe { add_inplace_avx2(dst_a, b) };
            return;
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_neon() {
            unsafe { add_inplace_neon(dst_a, b) };
            return;
        }
    }
    add_inplace_scalar(dst_a, b);
}

/// Safe in-place multiplication with runtime SIMD detection.
///
/// Modifies `dst_a` in place: `dst_a[i] *= b[i]`.
/// Avoids scratch buffer allocation for commutative in-place operations.
#[inline]
pub fn mul_inplace_simd(dst_a: &mut [f32], b: &[f32]) {
    #[cfg(target_arch = "x86_64")]
    {
        if has_avx512f() {
            unsafe { mul_inplace_avx512(dst_a, b) };
            return;
        }
        if has_avx2() {
            unsafe { add_inplace_mul_avx2(dst_a, b) };
            return;
        }
    }
    #[cfg(target_arch = "aarch64")]
    {
        if has_neon() {
            unsafe { mul_inplace_neon(dst_a, b) };
            return;
        }
    }
    mul_inplace_scalar(dst_a, b);
}

/// Safe in-place element-wise minimum with runtime SIMD detection.
///
/// Modifies `dst_a` in place: `dst_a[i] = min(dst_a[i], b[i])`.
#[inline]
pub fn elem_min_inplace_simd(dst_a: &mut [f32], b: &[f32]) {
    let len = dst_a.len().min(b.len());
    for i in 0..len {
        dst_a[i] = dst_a[i].min(b[i]);
    }
}

/// Safe in-place element-wise maximum with runtime SIMD detection.
///
/// Modifies `dst_a` in place: `dst_a[i] = max(dst_a[i], b[i])`.
#[inline]
pub fn elem_max_inplace_simd(dst_a: &mut [f32], b: &[f32]) {
    let len = dst_a.len().min(b.len());
    for i in 0..len {
        dst_a[i] = dst_a[i].max(b[i]);
    }
}

// ============================================================================
// Parallel Execution (Rayon)
// ============================================================================

/// Base threshold for parallel execution (elements).
/// Scaled by number of threads: actual_threshold = BASE * (1 + log2(threads))
/// - 1 thread: 4096 elements (16 KB for f32)
/// - 8 threads: 16384 elements (64 KB for f32)
/// - 16 threads: 20480 elements (80 KB for f32)
const PARALLEL_BASE_THRESHOLD: usize = 4096;

/// Get the effective parallel threshold, scaled by available threads.
/// Uses a logarithmic scaling to avoid excessive thresholds on many-core systems.
#[inline]
#[allow(
    clippy::cast_precision_loss,
    clippy::cast_sign_loss,
    clippy::cast_possible_truncation
)]
fn parallel_threshold() -> usize {
    use std::sync::OnceLock;
    static THRESHOLD: OnceLock<usize> = OnceLock::new();

    *THRESHOLD.get_or_init(|| {
        let threads = rayon::current_num_threads();
        // Logarithmic scaling: threshold = base * (1 + log2(threads))
        // This gives reasonable scaling without exploding on 64+ core systems
        // Note: Thread counts are small (<1000), so precision loss is not an issue
        let scale = 1 + (threads as f64).log2().ceil() as usize;
        PARALLEL_BASE_THRESHOLD * scale
    })
}

/// Parallel element-wise addition for large arrays.
pub fn add_parallel(a: &[f32], b: &[f32], result: &mut [f32]) {
    use rayon::prelude::*;

    let len = a.len().min(b.len()).min(result.len());
    if len < parallel_threshold() {
        add_simd(a, b, result);
        return;
    }

    // Parallel execution with Rayon
    result[..len]
        .par_iter_mut()
        .zip(a[..len].par_iter())
        .zip(b[..len].par_iter())
        .for_each(|((r, &a_val), &b_val)| {
            *r = a_val + b_val;
        });
}

/// Parallel element-wise subtraction for large arrays.
pub fn sub_parallel(a: &[f32], b: &[f32], result: &mut [f32]) {
    use rayon::prelude::*;

    let len = a.len().min(b.len()).min(result.len());
    if len < parallel_threshold() {
        sub_simd(a, b, result);
        return;
    }

    result[..len]
        .par_iter_mut()
        .zip(a[..len].par_iter())
        .zip(b[..len].par_iter())
        .for_each(|((r, &a_val), &b_val)| {
            *r = a_val - b_val;
        });
}

/// Parallel element-wise multiplication for large arrays.
pub fn mul_parallel(a: &[f32], b: &[f32], result: &mut [f32]) {
    use rayon::prelude::*;

    let len = a.len().min(b.len()).min(result.len());
    if len < parallel_threshold() {
        mul_simd(a, b, result);
        return;
    }

    result[..len]
        .par_iter_mut()
        .zip(a[..len].par_iter())
        .zip(b[..len].par_iter())
        .for_each(|((r, &a_val), &b_val)| {
            *r = a_val * b_val;
        });
}

/// Parallel ReLU for large arrays.
pub fn relu_parallel(src: &[f32], result: &mut [f32]) {
    use rayon::prelude::*;

    let len = src.len().min(result.len());
    if len < parallel_threshold() {
        relu_simd(src, result);
        return;
    }

    result[..len]
        .par_iter_mut()
        .zip(src[..len].par_iter())
        .for_each(|(r, &s)| {
            *r = s.max(0.0);
        });
}

/// Parallel Sigmoid for large arrays.
pub fn sigmoid_parallel(src: &[f32], result: &mut [f32]) {
    use rayon::prelude::*;

    let len = src.len().min(result.len());
    if len < parallel_threshold() {
        sigmoid_simd(src, result);
        return;
    }

    result[..len]
        .par_iter_mut()
        .zip(src[..len].par_iter())
        .for_each(|(r, &s)| {
            *r = 1.0 / (1.0 + (-s).exp());
        });
}

/// Parallel Tanh for large arrays.
pub fn tanh_parallel(src: &[f32], result: &mut [f32]) {
    use rayon::prelude::*;

    let len = src.len().min(result.len());
    if len < parallel_threshold() {
        tanh_simd(src, result);
        return;
    }

    result[..len]
        .par_iter_mut()
        .zip(src[..len].par_iter())
        .for_each(|(r, &s)| {
            *r = s.tanh();
        });
}

/// Parallel less-or-equal comparison for large arrays.
pub fn less_or_equal_parallel(a: &[f32], b: &[f32], result: &mut [f32]) {
    use rayon::prelude::*;

    let len = a.len().min(b.len()).min(result.len());
    if len < parallel_threshold() {
        less_or_equal_simd(a, b, result);
        return;
    }

    result[..len]
        .par_iter_mut()
        .zip(a[..len].par_iter())
        .zip(b[..len].par_iter())
        .for_each(|((r, &a_val), &b_val)| {
            *r = if a_val <= b_val { 1.0 } else { 0.0 };
        });
}

/// Parallel greater-or-equal comparison for large arrays.
pub fn greater_or_equal_parallel(a: &[f32], b: &[f32], result: &mut [f32]) {
    use rayon::prelude::*;

    let len = a.len().min(b.len()).min(result.len());
    if len < parallel_threshold() {
        greater_or_equal_simd(a, b, result);
        return;
    }

    result[..len]
        .par_iter_mut()
        .zip(a[..len].par_iter())
        .zip(b[..len].par_iter())
        .for_each(|((r, &a_val), &b_val)| {
            *r = if a_val >= b_val { 1.0 } else { 0.0 };
        });
}

// ============================================================================
// Transformer Operations (Sqrt, Log, Exp, Abs, Pow, ElemMin, ElemMax, Greater, Less, Where)
// ============================================================================

/// AVX2-optimized element-wise square root
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn sqrt_avx2(src: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = src.len().min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let v = _mm256_loadu_ps(src.as_ptr().add(offset));
        let vr = _mm256_sqrt_ps(v);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].sqrt();
    }
}

/// AVX2-optimized natural logarithm using polynomial approximation.
/// Uses range reduction: ln(x) = n*ln(2) + ln(f) where x = 2^n * f, f in [1, 2)
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
#[inline]
unsafe fn ln_avx2(x: std::arch::x86_64::__m256) -> std::arch::x86_64::__m256 {
    use std::arch::x86_64::*;

    // Constants
    let one = _mm256_set1_ps(1.0);
    let ln2 = _mm256_set1_ps(0.693_147_18);
    let mantissa_mask = _mm256_set1_epi32(0x007f_ffff);
    let exponent_bias = _mm256_set1_epi32(127);

    // Polynomial coefficients for ln(1+f) where f in [0, 1)
    // Using minimax polynomial approximation
    let c0 = _mm256_set1_ps(0.0);
    let c1 = _mm256_set1_ps(0.999_998_50);
    let c2 = _mm256_set1_ps(-0.499_879_40);
    let c3 = _mm256_set1_ps(0.333_154_30);
    let c4 = _mm256_set1_ps(-0.241_628_70);

    // Extract exponent: n = floor(log2(x))
    let xi = _mm256_castps_si256(x);
    let exp_bits = _mm256_srli_epi32(xi, 23);
    let n = _mm256_sub_epi32(exp_bits, exponent_bias);
    let n_f = _mm256_cvtepi32_ps(n);

    // Extract mantissa and set exponent to 0 (giving f in [1, 2))
    let mantissa = _mm256_and_si256(xi, mantissa_mask);
    let normalized = _mm256_or_si256(mantissa, _mm256_set1_epi32(0x3f80_0000));
    let f = _mm256_castsi256_ps(normalized);

    // f - 1 to get f in [0, 1)
    let f_minus_1 = _mm256_sub_ps(f, one);

    // Evaluate polynomial: ln(1+f) ≈ c1*f + c2*f^2 + c3*f^3 + c4*f^4
    // Using Horner's method: (((c4*f + c3)*f + c2)*f + c1)*f + c0
    let mut poly = c4;
    poly = _mm256_add_ps(_mm256_mul_ps(poly, f_minus_1), c3);
    poly = _mm256_add_ps(_mm256_mul_ps(poly, f_minus_1), c2);
    poly = _mm256_add_ps(_mm256_mul_ps(poly, f_minus_1), c1);
    poly = _mm256_add_ps(_mm256_mul_ps(poly, f_minus_1), c0);

    // Result: n * ln(2) + ln(f)
    _mm256_add_ps(_mm256_mul_ps(n_f, ln2), poly)
}

/// AVX2-optimized element-wise natural logarithm
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn log_avx2(src: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = src.len().min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let v = _mm256_loadu_ps(src.as_ptr().add(offset));
        let vr = ln_avx2(v);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].ln();
    }
}

/// AVX2-optimized element-wise exponential (public wrapper around internal exp_avx2)
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn exp_public_avx2(src: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = src.len().min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let v = _mm256_loadu_ps(src.as_ptr().add(offset));
        let vr = exp_avx2(v);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].exp();
    }
}

/// AVX2-optimized element-wise absolute value
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn abs_avx2(src: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = src.len().min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    // Mask to clear sign bit (all bits except sign bit set)
    let sign_mask = _mm256_set1_ps(-0.0);

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let v = _mm256_loadu_ps(src.as_ptr().add(offset));
        // Clear sign bit using andnot: result = ~sign_mask & v
        let vr = _mm256_andnot_ps(sign_mask, v);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].abs();
    }
}

/// AVX2-optimized element-wise power: result[i] = a[i]^b[i]
/// Uses exp(b * ln(|a|)) formula with sign handling for negative bases.
///
/// AVX2-optimized element-wise power
///
/// Special-cases common exponents (2.0, 0.5) for perfect accuracy.
/// For exponent=2, uses a*a instead of exp(2*ln(a)) to avoid precision loss.
/// For negative bases with even integer exponents (like x^2), result is positive.
/// For negative bases with odd integer exponents (like x^3), result is negative.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn pow_avx2(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    if len == 0 {
        return;
    }

    // Check if all exponents are 2.0 (squaring) - common in RMSNorm
    // This is the fast path that avoids exp/ln precision issues
    #[allow(clippy::float_cmp)]
    let all_two = b.iter().take(len).all(|&x| x == 2.0);
    if all_two {
        let chunks = len / AVX2_F32_LANES;
        let remainder = len % AVX2_F32_LANES;

        for i in 0..chunks {
            let offset = i * AVX2_F32_LANES;
            let va = _mm256_loadu_ps(a.as_ptr().add(offset));
            let vr = _mm256_mul_ps(va, va); // a * a is exact
            _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
        }

        let base = chunks * AVX2_F32_LANES;
        for i in 0..remainder {
            result[base + i] = a[base + i] * a[base + i];
        }
        return;
    }

    // Check if all exponents are 0.5 (sqrt) - common in normalization
    #[allow(clippy::float_cmp)]
    let all_half = b.iter().take(len).all(|&x| x == 0.5);
    if all_half {
        sqrt_avx2(a, result);
        return;
    }

    // General case: use exp(b * ln(|a|)) with proper sign handling
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    // Sign bit mask for extracting/applying sign
    let sign_mask = _mm256_set1_ps(-0.0f32); // 0x80000000
    let two = _mm256_set1_ps(2.0);

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let va = _mm256_loadu_ps(a.as_ptr().add(offset));
        let vb = _mm256_loadu_ps(b.as_ptr().add(offset));

        // Take absolute value of a for ln computation
        let abs_a = _mm256_andnot_ps(sign_mask, va);

        // Compute |a|^b = exp(b * ln(|a|))
        let ln_abs_a = ln_avx2(abs_a);
        let b_ln_a = _mm256_mul_ps(vb, ln_abs_a);
        let pow_result = exp_avx2(b_ln_a);

        // Handle sign: negative base with odd integer exponent should give negative result
        // Check if a is negative: sign_a is all 1s for negative, 0 for positive
        let is_negative = _mm256_cmp_ps(va, _mm256_setzero_ps(), _CMP_LT_OQ);

        // Check if b is an odd integer: floor(b) == b AND floor(b/2)*2 != b
        let floor_b = _mm256_floor_ps(vb);
        let is_integer = _mm256_cmp_ps(floor_b, vb, _CMP_EQ_OQ);
        let half_b = _mm256_mul_ps(floor_b, _mm256_set1_ps(0.5));
        let floor_half_b = _mm256_floor_ps(half_b);
        let is_even = _mm256_cmp_ps(_mm256_mul_ps(floor_half_b, two), floor_b, _CMP_EQ_OQ);
        let is_odd_integer = _mm256_andnot_ps(is_even, is_integer);

        // Apply negative sign only when: base is negative AND exponent is odd integer
        let apply_sign = _mm256_and_ps(is_negative, is_odd_integer);
        let sign_to_apply = _mm256_and_ps(apply_sign, sign_mask);
        let vr = _mm256_xor_ps(pow_result, sign_to_apply);

        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i].powf(b[base + i]);
    }
}

/// AVX2-optimized element-wise minimum
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn elem_min_avx2(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let va = _mm256_loadu_ps(a.as_ptr().add(offset));
        let vb = _mm256_loadu_ps(b.as_ptr().add(offset));
        let vr = _mm256_min_ps(va, vb);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i].min(b[base + i]);
    }
}

/// AVX2-optimized element-wise maximum
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn elem_max_avx2(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / AVX2_F32_LANES;
    let remainder = len % AVX2_F32_LANES;

    for i in 0..chunks {
        let offset = i * AVX2_F32_LANES;
        let va = _mm256_loadu_ps(a.as_ptr().add(offset));
        let vb = _mm256_loadu_ps(b.as_ptr().add(offset));
        let vr = _mm256_max_ps(va, vb);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * AVX2_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i].max(b[base + i]);
    }
}

/// AVX2-optimized element-wise greater than comparison
/// Result is stored as f32 where 1.0 = true, 0.0 = false
/// Uses 2x loop unrolling for better instruction-level parallelism
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn greater_avx2(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let ones = _mm256_set1_ps(1.0);

    // 2x unrolled loop: process 16 elements per iteration
    let unrolled_chunks = len / (AVX2_F32_LANES * 2);
    let mut i = 0;

    while i < unrolled_chunks {
        let offset0 = i * AVX2_F32_LANES * 2;
        let offset1 = offset0 + AVX2_F32_LANES;

        // Load both chunks
        let va0 = _mm256_loadu_ps(a.as_ptr().add(offset0));
        let va1 = _mm256_loadu_ps(a.as_ptr().add(offset1));
        let vb0 = _mm256_loadu_ps(b.as_ptr().add(offset0));
        let vb1 = _mm256_loadu_ps(b.as_ptr().add(offset1));

        // Compare and convert to 1.0/0.0
        let mask0 = _mm256_cmp_ps(va0, vb0, _CMP_GT_OQ);
        let mask1 = _mm256_cmp_ps(va1, vb1, _CMP_GT_OQ);
        let vr0 = _mm256_and_ps(mask0, ones);
        let vr1 = _mm256_and_ps(mask1, ones);

        // Store results
        _mm256_storeu_ps(result.as_mut_ptr().add(offset0), vr0);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset1), vr1);

        i += 1;
    }

    // Handle remaining full chunks (0 or 1 chunk)
    let base = unrolled_chunks * AVX2_F32_LANES * 2;
    if len >= base + AVX2_F32_LANES {
        let va = _mm256_loadu_ps(a.as_ptr().add(base));
        let vb = _mm256_loadu_ps(b.as_ptr().add(base));
        let mask = _mm256_cmp_ps(va, vb, _CMP_GT_OQ);
        let vr = _mm256_and_ps(mask, ones);
        _mm256_storeu_ps(result.as_mut_ptr().add(base), vr);
    }

    // Handle scalar remainder
    let scalar_base = (len / AVX2_F32_LANES) * AVX2_F32_LANES;
    for j in scalar_base..len {
        result[j] = if a[j] > b[j] { 1.0 } else { 0.0 };
    }
}

/// AVX2-optimized element-wise less than comparison
/// Result is stored as f32 where 1.0 = true, 0.0 = false
/// Uses 2x loop unrolling for better instruction-level parallelism
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn less_avx2(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let ones = _mm256_set1_ps(1.0);

    // 2x unrolled loop: process 16 elements per iteration
    let unrolled_chunks = len / (AVX2_F32_LANES * 2);
    let mut i = 0;

    while i < unrolled_chunks {
        let offset0 = i * AVX2_F32_LANES * 2;
        let offset1 = offset0 + AVX2_F32_LANES;

        // Load both chunks
        let va0 = _mm256_loadu_ps(a.as_ptr().add(offset0));
        let va1 = _mm256_loadu_ps(a.as_ptr().add(offset1));
        let vb0 = _mm256_loadu_ps(b.as_ptr().add(offset0));
        let vb1 = _mm256_loadu_ps(b.as_ptr().add(offset1));

        // Compare and convert to 1.0/0.0
        let mask0 = _mm256_cmp_ps(va0, vb0, _CMP_LT_OQ);
        let mask1 = _mm256_cmp_ps(va1, vb1, _CMP_LT_OQ);
        let vr0 = _mm256_and_ps(mask0, ones);
        let vr1 = _mm256_and_ps(mask1, ones);

        // Store results
        _mm256_storeu_ps(result.as_mut_ptr().add(offset0), vr0);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset1), vr1);

        i += 1;
    }

    // Handle remaining full chunks (0 or 1 chunk)
    let base = unrolled_chunks * AVX2_F32_LANES * 2;
    if len >= base + AVX2_F32_LANES {
        let va = _mm256_loadu_ps(a.as_ptr().add(base));
        let vb = _mm256_loadu_ps(b.as_ptr().add(base));
        let mask = _mm256_cmp_ps(va, vb, _CMP_LT_OQ);
        let vr = _mm256_and_ps(mask, ones);
        _mm256_storeu_ps(result.as_mut_ptr().add(base), vr);
    }

    // Handle scalar remainder
    let scalar_base = (len / AVX2_F32_LANES) * AVX2_F32_LANES;
    for j in scalar_base..len {
        result[j] = if a[j] < b[j] { 1.0 } else { 0.0 };
    }
}

/// AVX2-optimized element-wise less than or equal comparison
/// Result is stored as f32 where 1.0 = true, 0.0 = false
/// Uses 2x loop unrolling for better instruction-level parallelism
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn less_or_equal_avx2(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let ones = _mm256_set1_ps(1.0);

    // 2x unrolled loop: process 16 elements per iteration
    let unrolled_chunks = len / (AVX2_F32_LANES * 2);
    let mut i = 0;

    while i < unrolled_chunks {
        let offset0 = i * AVX2_F32_LANES * 2;
        let offset1 = offset0 + AVX2_F32_LANES;

        // Load both chunks
        let va0 = _mm256_loadu_ps(a.as_ptr().add(offset0));
        let va1 = _mm256_loadu_ps(a.as_ptr().add(offset1));
        let vb0 = _mm256_loadu_ps(b.as_ptr().add(offset0));
        let vb1 = _mm256_loadu_ps(b.as_ptr().add(offset1));

        // Compare: a <= b using _CMP_LE_OQ (ordered, quiet)
        let mask0 = _mm256_cmp_ps(va0, vb0, _CMP_LE_OQ);
        let mask1 = _mm256_cmp_ps(va1, vb1, _CMP_LE_OQ);
        let vr0 = _mm256_and_ps(mask0, ones);
        let vr1 = _mm256_and_ps(mask1, ones);

        // Store results
        _mm256_storeu_ps(result.as_mut_ptr().add(offset0), vr0);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset1), vr1);

        i += 1;
    }

    // Handle remaining full chunks (0 or 1 chunk)
    let base = unrolled_chunks * AVX2_F32_LANES * 2;
    if len >= base + AVX2_F32_LANES {
        let va = _mm256_loadu_ps(a.as_ptr().add(base));
        let vb = _mm256_loadu_ps(b.as_ptr().add(base));
        let mask = _mm256_cmp_ps(va, vb, _CMP_LE_OQ);
        let vr = _mm256_and_ps(mask, ones);
        _mm256_storeu_ps(result.as_mut_ptr().add(base), vr);
    }

    // Handle scalar remainder
    let scalar_base = (len / AVX2_F32_LANES) * AVX2_F32_LANES;
    for j in scalar_base..len {
        result[j] = if a[j] <= b[j] { 1.0 } else { 0.0 };
    }
}

/// AVX2-optimized element-wise greater than or equal comparison
/// Result is stored as f32 where 1.0 = true, 0.0 = false
/// Uses 2x loop unrolling for better instruction-level parallelism
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn greater_or_equal_avx2(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = a.len().min(b.len()).min(result.len());
    let ones = _mm256_set1_ps(1.0);

    // 2x unrolled loop: process 16 elements per iteration
    let unrolled_chunks = len / (AVX2_F32_LANES * 2);
    let mut i = 0;

    while i < unrolled_chunks {
        let offset0 = i * AVX2_F32_LANES * 2;
        let offset1 = offset0 + AVX2_F32_LANES;

        // Load both chunks
        let va0 = _mm256_loadu_ps(a.as_ptr().add(offset0));
        let va1 = _mm256_loadu_ps(a.as_ptr().add(offset1));
        let vb0 = _mm256_loadu_ps(b.as_ptr().add(offset0));
        let vb1 = _mm256_loadu_ps(b.as_ptr().add(offset1));

        // Compare: a >= b using _CMP_GE_OQ (ordered, quiet)
        let mask0 = _mm256_cmp_ps(va0, vb0, _CMP_GE_OQ);
        let mask1 = _mm256_cmp_ps(va1, vb1, _CMP_GE_OQ);
        let vr0 = _mm256_and_ps(mask0, ones);
        let vr1 = _mm256_and_ps(mask1, ones);

        // Store results
        _mm256_storeu_ps(result.as_mut_ptr().add(offset0), vr0);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset1), vr1);

        i += 1;
    }

    // Handle remaining full chunks (0 or 1 chunk)
    let base = unrolled_chunks * AVX2_F32_LANES * 2;
    if len >= base + AVX2_F32_LANES {
        let va = _mm256_loadu_ps(a.as_ptr().add(base));
        let vb = _mm256_loadu_ps(b.as_ptr().add(base));
        let mask = _mm256_cmp_ps(va, vb, _CMP_GE_OQ);
        let vr = _mm256_and_ps(mask, ones);
        _mm256_storeu_ps(result.as_mut_ptr().add(base), vr);
    }

    // Handle scalar remainder
    let scalar_base = (len / AVX2_F32_LANES) * AVX2_F32_LANES;
    for j in scalar_base..len {
        result[j] = if a[j] >= b[j] { 1.0 } else { 0.0 };
    }
}

/// AVX2-optimized conditional select: where(cond, x, y) = cond ? x : y
/// cond is expected as f32 where non-zero = true (typically 1.0)
/// Uses 2x loop unrolling for better instruction-level parallelism
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn where_avx2(cond: &[f32], x: &[f32], y: &[f32], result: &mut [f32]) {
    use std::arch::x86_64::*;

    let len = cond.len().min(x.len()).min(y.len()).min(result.len());
    let zeros = _mm256_setzero_ps();

    // 2x unrolled loop: process 16 elements per iteration
    let unrolled_chunks = len / (AVX2_F32_LANES * 2);
    let mut i = 0;

    while i < unrolled_chunks {
        let offset0 = i * AVX2_F32_LANES * 2;
        let offset1 = offset0 + AVX2_F32_LANES;

        // Load all inputs for both chunks
        let vc0 = _mm256_loadu_ps(cond.as_ptr().add(offset0));
        let vc1 = _mm256_loadu_ps(cond.as_ptr().add(offset1));
        let vx0 = _mm256_loadu_ps(x.as_ptr().add(offset0));
        let vx1 = _mm256_loadu_ps(x.as_ptr().add(offset1));
        let vy0 = _mm256_loadu_ps(y.as_ptr().add(offset0));
        let vy1 = _mm256_loadu_ps(y.as_ptr().add(offset1));

        // Create masks and blend
        let mask0 = _mm256_cmp_ps(vc0, zeros, _CMP_NEQ_OQ);
        let mask1 = _mm256_cmp_ps(vc1, zeros, _CMP_NEQ_OQ);
        let vr0 = _mm256_blendv_ps(vy0, vx0, mask0);
        let vr1 = _mm256_blendv_ps(vy1, vx1, mask1);

        // Store results
        _mm256_storeu_ps(result.as_mut_ptr().add(offset0), vr0);
        _mm256_storeu_ps(result.as_mut_ptr().add(offset1), vr1);

        i += 1;
    }

    // Handle remaining full chunks (0 or 1 chunk)
    let base = unrolled_chunks * AVX2_F32_LANES * 2;
    if len >= base + AVX2_F32_LANES {
        let vc = _mm256_loadu_ps(cond.as_ptr().add(base));
        let vx = _mm256_loadu_ps(x.as_ptr().add(base));
        let vy = _mm256_loadu_ps(y.as_ptr().add(base));
        let mask = _mm256_cmp_ps(vc, zeros, _CMP_NEQ_OQ);
        let vr = _mm256_blendv_ps(vy, vx, mask);
        _mm256_storeu_ps(result.as_mut_ptr().add(base), vr);
    }

    // Handle scalar remainder
    let scalar_base = (len / AVX2_F32_LANES) * AVX2_F32_LANES;
    for j in scalar_base..len {
        result[j] = if cond[j] == 0.0 { y[j] } else { x[j] };
    }
}

// ============================================================================
// NEON Transformer Operations (aarch64)
// ============================================================================

/// NEON-optimized element-wise square root
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn sqrt_neon(src: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = src.len().min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let v = vld1q_f32(src.as_ptr().add(offset));
        let vr = vsqrtq_f32(v);
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].sqrt();
    }
}

/// NEON natural logarithm helper using polynomial approximation
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
#[inline]
unsafe fn ln_neon(x: std::arch::aarch64::float32x4_t) -> std::arch::aarch64::float32x4_t {
    use std::arch::aarch64::*;

    let one = vdupq_n_f32(1.0);
    let ln2 = vdupq_n_f32(0.693_147_18);

    // Polynomial coefficients
    let c0 = vdupq_n_f32(0.0);
    let c1 = vdupq_n_f32(0.999_998_50);
    let c2 = vdupq_n_f32(-0.499_879_40);
    let c3 = vdupq_n_f32(0.333_154_30);
    let c4 = vdupq_n_f32(-0.241_628_70);

    // Extract exponent
    let xi = vreinterpretq_s32_f32(x);
    let exp_bits = vshrq_n_s32(xi, 23);
    let n = vsubq_s32(exp_bits, vdupq_n_s32(127));
    let n_f = vcvtq_f32_s32(n);

    // Extract mantissa
    let mantissa = vandq_s32(xi, vdupq_n_s32(0x007f_ffff));
    let normalized = vorrq_s32(mantissa, vdupq_n_s32(0x3f80_0000));
    let f = vreinterpretq_f32_s32(normalized);
    let f_minus_1 = vsubq_f32(f, one);

    // Polynomial evaluation (Horner's method)
    let mut poly = c4;
    poly = vaddq_f32(vmulq_f32(poly, f_minus_1), c3);
    poly = vaddq_f32(vmulq_f32(poly, f_minus_1), c2);
    poly = vaddq_f32(vmulq_f32(poly, f_minus_1), c1);
    poly = vaddq_f32(vmulq_f32(poly, f_minus_1), c0);

    vaddq_f32(vmulq_f32(n_f, ln2), poly)
}

/// NEON-optimized element-wise natural logarithm
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn log_neon(src: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = src.len().min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let v = vld1q_f32(src.as_ptr().add(offset));
        let vr = ln_neon(v);
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].ln();
    }
}

/// NEON-optimized element-wise exponential
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn exp_public_neon(src: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = src.len().min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let v = vld1q_f32(src.as_ptr().add(offset));
        let vr = exp_neon(v);
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].exp();
    }
}

/// NEON-optimized element-wise absolute value
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn abs_neon(src: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = src.len().min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let v = vld1q_f32(src.as_ptr().add(offset));
        let vr = vabsq_f32(v);
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = src[base + i].abs();
    }
}

/// NEON-optimized element-wise power
///
/// Special-cases common exponents (2.0, 0.5) for perfect accuracy.
/// For exponent=2, uses a*a instead of exp(2*ln(a)) to avoid precision loss.
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn pow_neon(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = a.len().min(b.len()).min(result.len());
    if len == 0 {
        return;
    }

    // Check if all exponents are 2.0 (squaring) - common in RMSNorm
    // This is the fast path that avoids exp/ln precision issues
    #[allow(clippy::float_cmp)]
    let all_two = b.iter().take(len).all(|&x| x == 2.0);
    if all_two {
        let chunks = len / NEON_F32_LANES;
        let remainder = len % NEON_F32_LANES;

        for i in 0..chunks {
            let offset = i * NEON_F32_LANES;
            let va = vld1q_f32(a.as_ptr().add(offset));
            let vr = vmulq_f32(va, va); // a * a is exact
            vst1q_f32(result.as_mut_ptr().add(offset), vr);
        }

        let base = chunks * NEON_F32_LANES;
        for i in 0..remainder {
            result[base + i] = a[base + i] * a[base + i];
        }
        return;
    }

    // Check if all exponents are 0.5 (sqrt) - common in normalization
    #[allow(clippy::float_cmp)]
    let all_half = b.iter().take(len).all(|&x| x == 0.5);
    if all_half {
        sqrt_neon(a, result);
        return;
    }

    // General case: use exp(b * ln(|a|)) with proper sign handling
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    let zero = vdupq_n_f32(0.0);
    let two = vdupq_n_f32(2.0);
    let half = vdupq_n_f32(0.5);

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let va = vld1q_f32(a.as_ptr().add(offset));
        let vb = vld1q_f32(b.as_ptr().add(offset));

        // Take absolute value of a for ln computation
        let abs_a = vabsq_f32(va);

        // Compute |a|^b = exp(b * ln(|a|))
        let ln_abs_a = ln_neon(abs_a);
        let b_ln_a = vmulq_f32(vb, ln_abs_a);
        let pow_result = exp_neon(b_ln_a);

        // Handle sign: negative base with odd integer exponent gives negative result
        // Check if a is negative
        let is_negative = vcltq_f32(va, zero);

        // Check if b is an odd integer: floor(b) == b AND floor(b/2)*2 != b
        let floor_b = vrndmq_f32(vb); // floor
        let is_integer = vceqq_f32(floor_b, vb);
        let half_b = vmulq_f32(floor_b, half);
        let floor_half_b = vrndmq_f32(half_b);
        let doubled = vmulq_f32(floor_half_b, two);
        let is_even = vceqq_f32(doubled, floor_b);
        let is_odd_integer = vbicq_u32(is_integer, is_even);

        // Apply negative sign only when: base is negative AND exponent is odd integer
        let apply_sign = vandq_u32(is_negative, is_odd_integer);
        let vr = vbslq_f32(apply_sign, vnegq_f32(pow_result), pow_result);

        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i].powf(b[base + i]);
    }
}

/// NEON-optimized element-wise minimum
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn elem_min_neon(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let va = vld1q_f32(a.as_ptr().add(offset));
        let vb = vld1q_f32(b.as_ptr().add(offset));
        let vr = vminq_f32(va, vb);
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i].min(b[base + i]);
    }
}

/// NEON-optimized element-wise maximum
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn elem_max_neon(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let va = vld1q_f32(a.as_ptr().add(offset));
        let vb = vld1q_f32(b.as_ptr().add(offset));
        let vr = vmaxq_f32(va, vb);
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = a[base + i].max(b[base + i]);
    }
}

/// NEON-optimized element-wise greater than comparison
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn greater_neon(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    let ones = vdupq_n_f32(1.0);

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let va = vld1q_f32(a.as_ptr().add(offset));
        let vb = vld1q_f32(b.as_ptr().add(offset));
        let mask = vcgtq_f32(va, vb);
        let vr = vbslq_f32(mask, ones, vdupq_n_f32(0.0));
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = if a[base + i] > b[base + i] { 1.0 } else { 0.0 };
    }
}

/// NEON-optimized element-wise less than comparison
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn less_neon(a: &[f32], b: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = a.len().min(b.len()).min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    let ones = vdupq_n_f32(1.0);

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let va = vld1q_f32(a.as_ptr().add(offset));
        let vb = vld1q_f32(b.as_ptr().add(offset));
        let mask = vcltq_f32(va, vb);
        let vr = vbslq_f32(mask, ones, vdupq_n_f32(0.0));
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = if a[base + i] < b[base + i] { 1.0 } else { 0.0 };
    }
}

/// NEON-optimized conditional select
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
pub unsafe fn where_neon(cond: &[f32], x: &[f32], y: &[f32], result: &mut [f32]) {
    use std::arch::aarch64::*;

    let len = cond.len().min(x.len()).min(y.len()).min(result.len());
    let chunks = len / NEON_F32_LANES;
    let remainder = len % NEON_F32_LANES;

    let zeros = vdupq_n_f32(0.0);

    for i in 0..chunks {
        let offset = i * NEON_F32_LANES;
        let vc = vld1q_f32(cond.as_ptr().add(offset));
        let vx = vld1q_f32(x.as_ptr().add(offset));
        let vy = vld1q_f32(y.as_ptr().add(offset));
        // Create mask from condition (non-zero = select x)
        // vcgtq_f32 returns uint32x4_t directly
        let mask = vcgtq_f32(vabsq_f32(vc), zeros);
        let vr = vbslq_f32(mask, vx, vy);
        vst1q_f32(result.as_mut_ptr().add(offset), vr);
    }

    let base = chunks * NEON_F32_LANES;
    for i in 0..remainder {
        result[base + i] = if cond[base + i] == 0.0 {
            y[base + i]
        } else {
            x[base + i]
        };
    }
}

// ============================================================================
// Scalar Transformer Operations Fallbacks
// ============================================================================

/// Scalar element-wise square root
pub fn sqrt_scalar(src: &[f32], result: &mut [f32]) {
    let len = src.len().min(result.len());
    for i in 0..len {
        result[i] = src[i].sqrt();
    }
}

/// Scalar element-wise natural logarithm
pub fn log_scalar(src: &[f32], result: &mut [f32]) {
    let len = src.len().min(result.len());
    for i in 0..len {
        result[i] = src[i].ln();
    }
}

/// Scalar element-wise exponential
pub fn exp_scalar(src: &[f32], result: &mut [f32]) {
    let len = src.len().min(result.len());
    for i in 0..len {
        result[i] = src[i].exp();
    }
}

/// Scalar element-wise absolute value
pub fn abs_scalar(src: &[f32], result: &mut [f32]) {
    let len = src.len().min(result.len());
    for i in 0..len {
        result[i] = src[i].abs();
    }
}

/// Scalar element-wise power
pub fn pow_scalar(a: &[f32], b: &[f32], result: &mut [f32]) {
    let len = a.len().min(b.len()).min(result.len());
    for i in 0..len {
        result[i] = a[i].powf(b[i]);
    }
}

/// Scalar element-wise minimum
pub fn elem_min_scalar(a: &[f32], b: &[f32], result: &mut [f32]) {
    let len = a.len().min(b.len()).min(result.len());
    for i in 0..len {
        result[i] = a[i].min(b[i]);
    }
}

/// Scalar element-wise maximum
pub fn elem_max_scalar(a: &[f32], b: &[f32], result: &mut [f32]) {
    let len = a.len().min(b.len()).min(result.len());
    for i in 0..len {
        result[i] = a[i].max(b[i]);
    }
}

/// Scalar element-wise greater than comparison
pub fn greater_scalar(a: &[f32], b: &[f32], result: &mut [f32]) {
    let len = a.len().min(b.len()).min(result.len());
    for i in 0..len {
        result[i] = if a[i] > b[i] { 1.0 } else { 0.0 };
    }
}

/// Scalar element-wise less than comparison
pub fn less_scalar(a: &[f32], b: &[f32], result: &mut [f32]) {
    let len = a.len().min(b.len()).min(result.len());
    for i in 0..len {
        result[i] = if a[i] < b[i] { 1.0 } else { 0.0 };
    }
}

/// Scalar element-wise less than or equal comparison
pub fn less_or_equal_scalar(a: &[f32], b: &[f32], result: &mut [f32]) {
    let len = a.len().min(b.len()).min(result.len());
    for i in 0..len {
        result[i] = if a[i] <= b[i] { 1.0 } else { 0.0 };
    }
}

/// Scalar element-wise greater than or equal comparison
pub fn greater_or_equal_scalar(a: &[f32], b: &[f32], result: &mut [f32]) {
    let len = a.len().min(b.len()).min(result.len());
    for i in 0..len {
        result[i] = if a[i] >= b[i] { 1.0 } else { 0.0 };
    }
}

// ============================================================================
// Tile Operation
// ============================================================================

/// Tile tensor by repeating along dimensions (scalar).
///
/// Complexity: O(output_size) with index arithmetic overhead.
/// Each output element maps to one input element via modulo coordinates.
pub fn tile_scalar(src: &[f32], result: &mut [f32], input_shape: &[usize], multiples: &[usize]) {
    let ndim = input_shape.len();
    if ndim == 0 || src.is_empty() {
        return;
    }

    // Compute output shape and input strides
    let out_shape: Vec<usize> = input_shape
        .iter()
        .zip(multiples)
        .map(|(d, m)| d * m)
        .collect();
    let mut in_strides = vec![1; ndim];
    for i in (0..ndim.saturating_sub(1)).rev() {
        in_strides[i] = in_strides[i + 1] * input_shape[i + 1];
    }

    let total: usize = out_shape.iter().product();
    let total = total.min(result.len());

    for (out_idx, out_elem) in result.iter_mut().enumerate().take(total) {
        // Convert linear index to multi-dimensional coordinates
        let mut out_coords = vec![0; ndim];
        let mut remainder = out_idx;
        for i in 0..ndim {
            let stride: usize = out_shape[(i + 1)..].iter().product();
            out_coords[i] = remainder / stride;
            remainder %= stride;
        }

        // Map to input coordinates (modulo input shape)
        let mut in_idx = 0;
        for i in 0..ndim {
            let in_coord = out_coords[i] % input_shape[i];
            in_idx += in_coord * in_strides[i];
        }

        if in_idx < src.len() {
            *out_elem = src[in_idx];
        }
    }
}

/// Parallel tile using Rayon for large outputs.
#[cfg(not(target_arch = "wasm32"))]
pub fn tile_parallel(src: &[f32], result: &mut [f32], input_shape: &[usize], multiples: &[usize]) {
    use rayon::prelude::*;

    let threads = rayon::current_num_threads();
    let threshold = 16384 * threads; // Higher threshold (index arithmetic is expensive)

    let total: usize = input_shape
        .iter()
        .zip(multiples)
        .map(|(d, m)| d * m)
        .product();
    if total < threshold {
        return tile_scalar(src, result, input_shape, multiples);
    }

    let ndim = input_shape.len();
    let out_shape: Vec<usize> = input_shape
        .iter()
        .zip(multiples)
        .map(|(d, m)| d * m)
        .collect();
    let mut in_strides = vec![1; ndim];
    for i in (0..ndim.saturating_sub(1)).rev() {
        in_strides[i] = in_strides[i + 1] * input_shape[i + 1];
    }

    let result_len = result.len();
    result[..total.min(result_len)]
        .par_iter_mut()
        .enumerate()
        .for_each(|(out_idx, r)| {
            let mut out_coords = vec![0; ndim];
            let mut remainder = out_idx;
            for i in 0..ndim {
                let stride: usize = out_shape[(i + 1)..].iter().product();
                out_coords[i] = remainder / stride;
                remainder %= stride;
            }

            let mut in_idx = 0;
            for i in 0..ndim {
                let in_coord = out_coords[i] % input_shape[i];
                in_idx += in_coord * in_strides[i];
            }

            if in_idx < src.len() {
                *r = src[in_idx];
            }
        });
}

// ============================================================================
// Expand Operation
// ============================================================================

/// Expand tensor to target shape via broadcasting (scalar).
pub fn expand_scalar(
    src: &[f32],
    result: &mut [f32],
    input_shape: &[usize],
    target_shape: &[usize],
) {
    let out_ndim = target_shape.len();
    let in_ndim = input_shape.len();

    if out_ndim == 0 || src.is_empty() {
        return;
    }

    let dim_offset = out_ndim.saturating_sub(in_ndim);

    let mut in_strides = vec![1; in_ndim];
    for i in (0..in_ndim.saturating_sub(1)).rev() {
        in_strides[i] = in_strides[i + 1] * input_shape[i + 1];
    }

    let total: usize = target_shape.iter().product();
    let total = total.min(result.len());

    for (out_idx, out_elem) in result.iter_mut().enumerate().take(total) {
        let mut out_coords = vec![0; out_ndim];
        let mut remainder = out_idx;
        for i in 0..out_ndim {
            let stride: usize = target_shape[(i + 1)..].iter().product();
            out_coords[i] = remainder / stride;
            remainder %= stride;
        }

        let mut in_idx = 0;
        for i in 0..in_ndim {
            let out_i = dim_offset + i;
            let coord = if input_shape[i] == 1 {
                0
            } else {
                out_coords[out_i]
            };
            in_idx += coord * in_strides[i];
        }

        if in_idx < src.len() {
            *out_elem = src[in_idx];
        }
    }
}

/// Parallel expand using Rayon for large outputs.
#[cfg(not(target_arch = "wasm32"))]
pub fn expand_parallel(
    src: &[f32],
    result: &mut [f32],
    input_shape: &[usize],
    target_shape: &[usize],
) {
    use rayon::prelude::*;

    let threads = rayon::current_num_threads();
    let threshold = 16384 * threads;

    let total: usize = target_shape.iter().product();
    if total < threshold {
        return expand_scalar(src, result, input_shape, target_shape);
    }

    let out_ndim = target_shape.len();
    let in_ndim = input_shape.len();
    let dim_offset = out_ndim.saturating_sub(in_ndim);

    let mut in_strides = vec![1; in_ndim];
    for i in (0..in_ndim.saturating_sub(1)).rev() {
        in_strides[i] = in_strides[i + 1] * input_shape[i + 1];
    }

    let result_len = result.len();
    result[..total.min(result_len)]
        .par_iter_mut()
        .enumerate()
        .for_each(|(out_idx, r)| {
            let mut out_coords = vec![0; out_ndim];
            let mut remainder = out_idx;
            for i in 0..out_ndim {
                let stride: usize = target_shape[(i + 1)..].iter().product();
                out_coords[i] = remainder / stride;
                remainder %= stride;
            }

            let mut in_idx = 0;
            for i in 0..in_ndim {
                let out_i = dim_offset + i;
                let coord = if input_shape[i] == 1 {
                    0
                } else {
                    out_coords[out_i]
                };
                in_idx += coord * in_strides[i];
            }

            if in_idx < src.len() {
                *r = src[in_idx];
            }
        });
}

/// Scalar conditional select
pub fn where_scalar(cond: &[f32], x: &[f32], y: &[f32], result: &mut [f32]) {
    let len = cond.len().min(x.len()).min(y.len()).min(result.len());
    for i in 0..len {
        result[i] = if cond[i] == 0.0 { y[i] } else { x[i] };
    }
}

// ============================================================================
// Safe Wrappers for Transformer Operations
// ============================================================================

/// Safe wrapper for SIMD sqrt with runtime detection
#[inline]
pub fn sqrt_simd(src: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            sqrt_avx2(src, result);
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if has_neon() {
        unsafe {
            sqrt_neon(src, result);
        }
        return;
    }
    sqrt_scalar(src, result);
}

/// Safe wrapper for SIMD log with runtime detection
#[inline]
pub fn log_simd(src: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            log_avx2(src, result);
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if has_neon() {
        unsafe {
            log_neon(src, result);
        }
        return;
    }
    log_scalar(src, result);
}

/// Safe wrapper for SIMD exp with runtime detection
#[inline]
pub fn exp_simd(src: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            exp_public_avx2(src, result);
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if has_neon() {
        unsafe {
            exp_public_neon(src, result);
        }
        return;
    }
    exp_scalar(src, result);
}

/// Safe wrapper for SIMD abs with runtime detection
#[inline]
pub fn abs_simd(src: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            abs_avx2(src, result);
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if has_neon() {
        unsafe {
            abs_neon(src, result);
        }
        return;
    }
    abs_scalar(src, result);
}

/// Safe wrapper for SIMD pow with runtime detection
#[inline]
pub fn pow_simd(a: &[f32], b: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            pow_avx2(a, b, result);
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if has_neon() {
        unsafe {
            pow_neon(a, b, result);
        }
        return;
    }
    pow_scalar(a, b, result);
}

/// Safe wrapper for SIMD elem_min with runtime detection
#[inline]
pub fn elem_min_simd(a: &[f32], b: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            elem_min_avx2(a, b, result);
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if has_neon() {
        unsafe {
            elem_min_neon(a, b, result);
        }
        return;
    }
    elem_min_scalar(a, b, result);
}

/// Safe wrapper for SIMD elem_max with runtime detection
#[inline]
pub fn elem_max_simd(a: &[f32], b: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            elem_max_avx2(a, b, result);
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if has_neon() {
        unsafe {
            elem_max_neon(a, b, result);
        }
        return;
    }
    elem_max_scalar(a, b, result);
}

/// Safe wrapper for SIMD greater with runtime detection
#[inline]
pub fn greater_simd(a: &[f32], b: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            greater_avx2(a, b, result);
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if has_neon() {
        unsafe {
            greater_neon(a, b, result);
        }
        return;
    }
    greater_scalar(a, b, result);
}

/// Safe wrapper for SIMD less with runtime detection
#[inline]
pub fn less_simd(a: &[f32], b: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            less_avx2(a, b, result);
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if has_neon() {
        unsafe {
            less_neon(a, b, result);
        }
        return;
    }
    less_scalar(a, b, result);
}

/// Safe wrapper for SIMD less-or-equal with runtime detection
#[inline]
pub fn less_or_equal_simd(a: &[f32], b: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            less_or_equal_avx2(a, b, result);
        }
        return;
    }
    // aarch64 uses scalar fallback (no NEON comparison intrinsics needed)
    less_or_equal_scalar(a, b, result);
}

/// Safe wrapper for SIMD greater-or-equal with runtime detection
#[inline]
pub fn greater_or_equal_simd(a: &[f32], b: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            greater_or_equal_avx2(a, b, result);
        }
        return;
    }
    // aarch64 uses scalar fallback (no NEON comparison intrinsics needed)
    greater_or_equal_scalar(a, b, result);
}

/// Safe wrapper for SIMD where with runtime detection
#[inline]
pub fn where_simd(cond: &[f32], x: &[f32], y: &[f32], result: &mut [f32]) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() {
        unsafe {
            where_avx2(cond, x, y, result);
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if has_neon() {
        unsafe {
            where_neon(cond, x, y, result);
        }
        return;
    }
    where_scalar(cond, x, y, result);
}

// ============================================================================
// Tiled MatMul (TASK-048, TASK-096)
// ============================================================================

/// Macro to generate AVX2 micro-kernels of arbitrary MR x NR dimensions.
/// MR = number of rows of C (each row needs MR broadcasts of A values)
/// NR_VECS = number of AVX2 vectors for columns (NR = NR_VECS * 8 columns)
///
/// The macro generates:
/// - MR * NR_VECS accumulator registers
/// - Loads MR A values per k iteration (broadcast)
/// - Loads NR_VECS B vectors per k iteration
/// - MR * NR_VECS FMA operations per k iteration
#[cfg(target_arch = "x86_64")]
macro_rules! define_micro_kernel {
    (
        $fn_name:ident,
        mr = $mr:expr,
        nr_vecs = $nr_vecs:expr
    ) => {
        #[cfg(target_arch = "x86_64")]
        #[target_feature(enable = "avx2", enable = "fma")]
        #[inline]
        #[allow(clippy::many_single_char_names)]
        unsafe fn $fn_name(
            a: &[f32],
            b: &[f32],
            c: &mut [f32],
            k: usize,
            n: usize,
            i: usize,
            j: usize,
            pc: usize,
            kc: usize,
        ) {
            use std::arch::x86_64::*;

            // Create accumulator array: MR rows × NR_VECS vectors
            let mut acc: [[__m256; $nr_vecs]; $mr] = [[_mm256_setzero_ps(); $nr_vecs]; $mr];

            // Load current C values into accumulators
            for row in 0..$mr {
                let c_ptr = c.as_ptr().add((i + row) * n + j);
                for v in 0..$nr_vecs {
                    acc[row][v] = _mm256_loadu_ps(c_ptr.add(v * 8));
                }
            }

            // Stream through K dimension
            for p in 0..kc {
                let kp = pc + p;

                // Load B vectors
                let b_ptr = b.as_ptr().add(kp * n + j);
                let mut b_vecs: [__m256; $nr_vecs] = [_mm256_setzero_ps(); $nr_vecs];
                for v in 0..$nr_vecs {
                    b_vecs[v] = _mm256_loadu_ps(b_ptr.add(v * 8));
                }

                // Load A values and accumulate
                for row in 0..$mr {
                    let a_val = *a.as_ptr().add((i + row) * k + kp);
                    let a_broadcast = _mm256_set1_ps(a_val);
                    for v in 0..$nr_vecs {
                        acc[row][v] = _mm256_fmadd_ps(a_broadcast, b_vecs[v], acc[row][v]);
                    }
                }
            }

            // Store results back to C
            for row in 0..$mr {
                let c_ptr = c.as_mut_ptr().add((i + row) * n + j);
                for v in 0..$nr_vecs {
                    _mm256_storeu_ps(c_ptr.add(v * 8), acc[row][v]);
                }
            }
        }
    };
}

// Generate micro-kernels for different sizes
// 6x16: 6 rows × 2 vectors = 12 registers (good for AVX2, leaves headroom)
#[cfg(target_arch = "x86_64")]
define_micro_kernel!(micro_kernel_6x16, mr = 6, nr_vecs = 2);

// Alternative kernel sizes (commented out, not currently used):
// 4x24: 4 rows × 3 vectors = 12 registers (wider, shallower)
// 8x8:  8 rows × 1 vector  = 8 registers  (tall and narrow)
// #[cfg(target_arch = "x86_64")]
// define_micro_kernel!(micro_kernel_4x24, mr = 4, nr_vecs = 3);
// #[cfg(target_arch = "x86_64")]
// define_micro_kernel!(micro_kernel_8x8, mr = 8, nr_vecs = 1);

/// Macro to generate NEON micro-kernels for ARM aarch64.
/// MR = number of rows of C
/// NR_VECS = number of NEON vectors for columns (NR = NR_VECS * 4 columns)
#[cfg(target_arch = "aarch64")]
macro_rules! define_neon_micro_kernel {
    (
        $fn_name:ident,
        mr = $mr:expr,
        nr_vecs = $nr_vecs:expr
    ) => {
        #[cfg(target_arch = "aarch64")]
        #[target_feature(enable = "neon")]
        #[inline]
        #[allow(clippy::many_single_char_names)]
        unsafe fn $fn_name(
            a: &[f32],
            b: &[f32],
            c: &mut [f32],
            k: usize,
            n: usize,
            i: usize,
            j: usize,
            pc: usize,
            kc: usize,
        ) {
            use std::arch::aarch64::*;

            // Create accumulator array: MR rows × NR_VECS vectors
            let mut acc: [[float32x4_t; $nr_vecs]; $mr] = [[vdupq_n_f32(0.0); $nr_vecs]; $mr];

            // Load current C values into accumulators
            for row in 0..$mr {
                let c_ptr = c.as_ptr().add((i + row) * n + j);
                for v in 0..$nr_vecs {
                    acc[row][v] = vld1q_f32(c_ptr.add(v * 4));
                }
            }

            // Stream through K dimension
            for p in 0..kc {
                let kp = pc + p;

                // Load B vectors (NR_VECS vectors of 4 f32 each)
                let b_ptr = b.as_ptr().add(kp * n + j);
                let mut b_vecs: [float32x4_t; $nr_vecs] = [vdupq_n_f32(0.0); $nr_vecs];
                for v in 0..$nr_vecs {
                    b_vecs[v] = vld1q_f32(b_ptr.add(v * 4));
                }

                // Load A values and accumulate using FMA
                for row in 0..$mr {
                    let a_val = *a.as_ptr().add((i + row) * k + kp);
                    for v in 0..$nr_vecs {
                        // acc = acc + b * a_val (FMA with scalar broadcast)
                        acc[row][v] = vfmaq_n_f32(acc[row][v], b_vecs[v], a_val);
                    }
                }
            }

            // Store results back to C
            for row in 0..$mr {
                let c_ptr = c.as_mut_ptr().add((i + row) * n + j);
                for v in 0..$nr_vecs {
                    vst1q_f32(c_ptr.add(v * 4), acc[row][v]);
                }
            }
        }
    };
}

// Generate NEON micro-kernel: 4x8 (4 rows × 2 vectors × 4 lanes = 8 columns)
#[cfg(target_arch = "aarch64")]
define_neon_micro_kernel!(neon_micro_kernel_4x8, mr = 4, nr_vecs = 2);

/// Micro-kernel dimensions for default AVX2 configuration
#[cfg(target_arch = "x86_64")]
const MR: usize = 6;
#[cfg(target_arch = "x86_64")]
const NR: usize = 16;

/// Macro-tile sizes for L2 cache efficiency
/// MC x KC panel of A, KC x NC panel of B
#[cfg(target_arch = "x86_64")]
const MC: usize = 96; // Multiple of MR
#[cfg(target_arch = "x86_64")]
const KC: usize = 256; // K-dimension blocking
#[cfg(target_arch = "x86_64")]
const NC: usize = 256; // Multiple of NR

// NEON micro-kernel dimensions (4 rows × 2 vectors × 4 lanes = 4x8)
#[cfg(target_arch = "aarch64")]
const MR_NEON: usize = 4;
#[cfg(target_arch = "aarch64")]
const NR_NEON: usize = 8;

// NEON macro-tile sizes for L2 cache efficiency
#[cfg(target_arch = "aarch64")]
const MC_NEON: usize = 48; // Multiple of MR_NEON
#[cfg(target_arch = "aarch64")]
const KC_NEON: usize = 256; // K-dimension blocking
#[cfg(target_arch = "aarch64")]
const NC_NEON: usize = 128; // Multiple of NR_NEON

/// Cache-friendly tiled matrix multiplication
/// C = A @ B where A is m×k, B is k×n, C is m×n (row-major)
#[allow(clippy::many_single_char_names)] // Standard matrix variable names
pub fn matmul_tiled(a: &[f32], b: &[f32], c: &mut [f32], m: usize, k: usize, n: usize) {
    // Zero output matrix
    for x in c.iter_mut() {
        *x = 0.0;
    }

    #[cfg(target_arch = "x86_64")]
    if has_avx2() && n >= NR && m >= MR {
        // Use AVX2 micro-kernel path
        unsafe {
            matmul_avx2(a, b, c, m, k, n);
        }
        return;
    }

    #[cfg(target_arch = "aarch64")]
    if has_neon() && n >= NR_NEON && m >= MR_NEON {
        // Use NEON micro-kernel path
        unsafe {
            matmul_neon(a, b, c, m, k, n);
        }
        return;
    }

    // Scalar fallback
    matmul_scalar(a, b, c, m, k, n);
}

/// Cache-friendly tiled matrix multiplication with B matrix pre-packing.
///
/// Packs the B matrix into NR-wide micro-panels before computation,
/// converting strided B accesses (stride=n) into sequential accesses
/// (stride=NR). This improves L1/L2 cache hit rates by 10-20%.
///
/// C = A @ B where A is m×k, B is k×n, C is m×n (row-major).
#[allow(clippy::many_single_char_names)]
pub fn matmul_tiled_packed(a: &[f32], b: &[f32], c: &mut [f32], m: usize, k: usize, n: usize) {
    for x in c.iter_mut() {
        *x = 0.0;
    }

    #[cfg(target_arch = "x86_64")]
    if has_avx2() && n >= NR && m >= MR {
        unsafe {
            matmul_avx2_packed(a, b, c, m, k, n);
        }
        return;
    }

    #[cfg(target_arch = "aarch64")]
    if has_neon() && n >= NR_NEON && m >= MR_NEON {
        unsafe {
            matmul_neon_packed(a, b, c, m, k, n);
        }
        return;
    }

    // Scalar fallback (no packing benefit for scalar)
    matmul_scalar(a, b, c, m, k, n);
}

/// Pack a KC×NC panel of B into NR-wide contiguous micro-panels.
///
/// Input B layout (row-major): `b[kp * n + j]` (stride = n)
/// Output packed layout: `panel[p * nr + col]` (stride = NR, sequential)
///
/// For each NR-wide column group, the K rows are stored contiguously:
/// `packed[jr_panel][p * NR + col]` where `jr_panel = jr / NR`.
#[cfg(target_arch = "aarch64")]
#[inline]
fn pack_b_panel_neon(
    b: &[f32],
    packed: &mut [f32],
    n: usize,
    jc: usize,
    nc: usize,
    pc: usize,
    kc: usize,
) {
    let n_panels = nc.div_ceil(NR_NEON);
    for panel_idx in 0..n_panels {
        let jr = panel_idx * NR_NEON;
        let j = jc + jr;
        let nr = NR_NEON.min(nc - jr);
        let panel_base = panel_idx * kc * NR_NEON;

        for p in 0..kc {
            let dst_offset = panel_base + p * NR_NEON;
            let src_row = pc + p;
            for col in 0..nr {
                packed[dst_offset + col] = b[src_row * n + j + col];
            }
            // Zero-pad if nr < NR_NEON (edge panel)
            for col in nr..NR_NEON {
                packed[dst_offset + col] = 0.0;
            }
        }
    }
}

/// Pack an MC×KC panel of A into MR-tall contiguous micro-panels (NEON).
///
/// Input A layout (row-major): `a[(ic + row) * k + (pc + p)]` (stride = k)
/// Output packed layout: `packed[panel * kc * MR_NEON + p * MR_NEON + row]` (sequential)
#[cfg(target_arch = "aarch64")]
#[inline]
fn pack_a_panel_neon(
    a: &[f32],
    packed: &mut [f32],
    k: usize,
    ic: usize,
    mc: usize,
    pc: usize,
    kc: usize,
) {
    let n_panels = mc.div_ceil(MR_NEON);
    for panel_idx in 0..n_panels {
        let ir = panel_idx * MR_NEON;
        let i = ic + ir;
        let mr = MR_NEON.min(mc - ir);
        let panel_base = panel_idx * kc * MR_NEON;

        for p in 0..kc {
            let dst_offset = panel_base + p * MR_NEON;
            let src_col = pc + p;
            for row in 0..mr {
                packed[dst_offset + row] = a[(i + row) * k + src_col];
            }
            for row in mr..MR_NEON {
                packed[dst_offset + row] = 0.0;
            }
        }
    }
}

/// NEON micro-kernel for fully packed A+B: 4 rows × 8 columns.
///
/// Both A and B are accessed sequentially from packed buffers.
/// A: `packed_a[a_panel_offset + p * MR_NEON + row]` (stride = MR_NEON)
/// B: `packed_b[b_panel_offset + p * NR_NEON + col]` (stride = NR_NEON)
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
#[inline]
#[allow(clippy::many_single_char_names, clippy::needless_range_loop)]
unsafe fn neon_micro_kernel_4x8_fully_packed(
    packed_a: &[f32],
    packed_b: &[f32],
    c: &mut [f32],
    n: usize,
    i: usize,
    j: usize,
    kc: usize,
    a_panel_offset: usize,
    b_panel_offset: usize,
) {
    use std::arch::aarch64::*;

    let mut acc: [[float32x4_t; 2]; 4] = [[vdupq_n_f32(0.0); 2]; 4];

    // Load current C values
    for row in 0..4 {
        let c_ptr = c.as_ptr().add((i + row) * n + j);
        for v in 0..2 {
            acc[row][v] = vld1q_f32(c_ptr.add(v * 4));
        }
    }

    // Stream through K — both A and B are sequential
    for p in 0..kc {
        let b_ptr = packed_b.as_ptr().add(b_panel_offset + p * NR_NEON);
        let b0 = vld1q_f32(b_ptr);
        let b1 = vld1q_f32(b_ptr.add(4));

        let a_ptr = packed_a.as_ptr().add(a_panel_offset + p * MR_NEON);
        for row in 0..4 {
            let a_val = *a_ptr.add(row);
            acc[row][0] = vfmaq_n_f32(acc[row][0], b0, a_val);
            acc[row][1] = vfmaq_n_f32(acc[row][1], b1, a_val);
        }
    }

    // Store results back to C
    for row in 0..4 {
        let c_ptr = c.as_mut_ptr().add((i + row) * n + j);
        for v in 0..2 {
            vst1q_f32(c_ptr.add(v * 4), acc[row][v]);
        }
    }
}

/// NEON tiled MatMul with fully packed A+B matrices.
#[cfg(target_arch = "aarch64")]
#[allow(clippy::many_single_char_names, clippy::similar_names)]
unsafe fn matmul_neon_packed(a: &[f32], b: &[f32], c: &mut [f32], m: usize, k: usize, n: usize) {
    let max_b_panels = NC_NEON.div_ceil(NR_NEON);
    let max_a_panels = MC_NEON.div_ceil(MR_NEON);
    let mut packed_b = vec![0.0f32; max_b_panels * KC_NEON * NR_NEON];
    let mut packed_a = vec![0.0f32; max_a_panels * KC_NEON * MR_NEON];

    for jc in (0..n).step_by(NC_NEON) {
        let nc = NC_NEON.min(n - jc);

        for pc in (0..k).step_by(KC_NEON) {
            let kc = KC_NEON.min(k - pc);

            // Pack B once for this (jc, pc) block
            pack_b_panel_neon(b, &mut packed_b, n, jc, nc, pc, kc);

            for ic in (0..m).step_by(MC_NEON) {
                let mc = MC_NEON.min(m - ic);

                // Pack A once for this (ic, pc) block
                pack_a_panel_neon(a, &mut packed_a, k, ic, mc, pc, kc);

                for ir in (0..mc).step_by(MR_NEON) {
                    let mr = MR_NEON.min(mc - ir);
                    let i = ic + ir;
                    let a_panel_idx = ir / MR_NEON;
                    let a_panel_offset = a_panel_idx * kc * MR_NEON;

                    for jr in (0..nc).step_by(NR_NEON) {
                        let nr = NR_NEON.min(nc - jr);
                        let j = jc + jr;
                        let b_panel_idx = jr / NR_NEON;
                        let b_panel_offset = b_panel_idx * kc * NR_NEON;

                        if mr == MR_NEON && nr == NR_NEON {
                            neon_micro_kernel_4x8_fully_packed(
                                &packed_a,
                                &packed_b,
                                c,
                                n,
                                i,
                                j,
                                kc,
                                a_panel_offset,
                                b_panel_offset,
                            );
                        } else {
                            // Edge case: scalar fallback from packed buffers
                            for ii in 0..mr {
                                for p in 0..kc {
                                    let a_val = packed_a[a_panel_offset + p * MR_NEON + ii];
                                    for jj in 0..nr {
                                        c[(i + ii) * n + (j + jj)] +=
                                            a_val * packed_b[b_panel_offset + p * NR_NEON + jj];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// Parallel matrix multiplication for large matrices.
///
/// Uses JC-panel parallelism: each thread gets an NC-wide column slice of C
/// and packs its own B panel independently. This avoids B contention and
/// gives each thread cache-local packed data.
#[allow(clippy::many_single_char_names)]
pub fn matmul_parallel(a: &[f32], b: &[f32], c: &mut [f32], m: usize, k: usize, n: usize) {
    use rayon::prelude::*;

    let total_elements = m * n;
    if total_elements < parallel_threshold() {
        // Single-threaded: use unpacked tiled matmul (packing overhead exceeds
        // cache benefit without Rayon to amortize it across threads)
        matmul_tiled(a, b, c, m, k, n);
        return;
    }

    // Zero output matrix
    for x in c.iter_mut() {
        *x = 0.0;
    }

    // Determine tile size for parallelism (use platform-specific NC)
    #[cfg(target_arch = "x86_64")]
    let nc_tile = NC;
    #[cfg(target_arch = "aarch64")]
    let nc_tile = NC_NEON;
    #[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
    let nc_tile = 64;

    // Collect JC panel ranges
    let jc_panels: Vec<usize> = (0..n).step_by(nc_tile).collect();

    // Each thread processes one NC-wide column slice with its own packed buffers.
    // SAFETY: each thread writes to disjoint column ranges [jc..jc+nc] within
    // each row. No two threads overlap in their output writes.
    // We cast the pointer to usize for Send+Sync across threads.
    let c_addr = c.as_mut_ptr() as usize;
    let c_len = c.len();

    jc_panels.into_par_iter().for_each(move |jc| {
        let nc = nc_tile.min(n - jc);
        // SAFETY: disjoint column ranges — threads never overlap.
        // usize→*mut f32 roundtrip is safe; pointer was valid for c_len elements.
        let c_local = unsafe { std::slice::from_raw_parts_mut(c_addr as *mut f32, c_len) };

        matmul_parallel_panel(a, b, c_local, m, k, n, jc, nc);
    });
}

/// Compute one NC-wide panel of C = A @ B using packed matmul.
///
/// Processes columns `jc..jc+nc` for all rows, packing B once per KC block.
#[allow(clippy::many_single_char_names)]
fn matmul_parallel_panel(
    a: &[f32],
    b: &[f32],
    c: &mut [f32],
    m: usize,
    k: usize,
    n: usize,
    jc: usize,
    nc: usize,
) {
    #[cfg(target_arch = "x86_64")]
    if has_avx2() && nc >= NR && m >= MR {
        unsafe { matmul_panel_avx2(a, b, c, m, k, n, jc, nc) };
        return;
    }

    #[cfg(target_arch = "aarch64")]
    if has_neon() && nc >= NR_NEON && m >= MR_NEON {
        unsafe { matmul_panel_neon(a, b, c, m, k, n, jc, nc) };
        return;
    }

    // Scalar fallback for one panel
    for pc in (0..k).step_by(64) {
        let kc = 64_usize.min(k - pc);
        for i in 0..m {
            for p in 0..kc {
                let a_val = a[i * k + (pc + p)];
                for j in 0..nc {
                    c[i * n + (jc + j)] += a_val * b[(pc + p) * n + (jc + j)];
                }
            }
        }
    }
}

/// AVX2 single-panel matmul: computes columns `jc..jc+nc` for all rows.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2", enable = "fma")]
#[allow(clippy::many_single_char_names)]
unsafe fn matmul_panel_avx2(
    a: &[f32],
    b: &[f32],
    c: &mut [f32],
    m: usize,
    k: usize,
    n: usize,
    jc: usize,
    nc: usize,
) {
    let max_b_panels = nc.div_ceil(NR);
    let max_a_panels = MC.div_ceil(MR);
    let mut packed_b = vec![0.0f32; max_b_panels * KC * NR];
    let mut packed_a = vec![0.0f32; max_a_panels * KC * MR];

    for pc in (0..k).step_by(KC) {
        let kc = KC.min(k - pc);

        pack_b_panel_avx2(b, &mut packed_b, n, jc, nc, pc, kc);

        for ic in (0..m).step_by(MC) {
            let mc = MC.min(m - ic);

            pack_a_panel_avx2(a, &mut packed_a, k, ic, mc, pc, kc);

            for ir in (0..mc).step_by(MR) {
                let mr = MR.min(mc - ir);
                let i = ic + ir;
                let a_panel_offset = (ir / MR) * kc * MR;

                for jr in (0..nc).step_by(NR) {
                    let nr = NR.min(nc - jr);
                    let j = jc + jr;
                    let b_panel_offset = (jr / NR) * kc * NR;

                    if mr == MR && nr == NR {
                        micro_kernel_6x16_packed(
                            &packed_a,
                            &packed_b,
                            c,
                            n,
                            i,
                            j,
                            kc,
                            a_panel_offset,
                            b_panel_offset,
                        );
                    } else {
                        for ii in 0..mr {
                            for p in 0..kc {
                                let a_val = packed_a[a_panel_offset + p * MR + ii];
                                for jj in 0..nr {
                                    c[(i + ii) * n + (j + jj)] +=
                                        a_val * packed_b[b_panel_offset + p * NR + jj];
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// NEON single-panel matmul: computes columns `jc..jc+nc` for all rows.
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
#[allow(clippy::many_single_char_names, clippy::similar_names)]
unsafe fn matmul_panel_neon(
    a: &[f32],
    b: &[f32],
    c: &mut [f32],
    m: usize,
    k: usize,
    n: usize,
    jc: usize,
    nc: usize,
) {
    let max_b_panels = nc.div_ceil(NR_NEON);
    let max_a_panels = MC_NEON.div_ceil(MR_NEON);
    let mut packed_b = vec![0.0f32; max_b_panels * KC_NEON * NR_NEON];
    let mut packed_a = vec![0.0f32; max_a_panels * KC_NEON * MR_NEON];

    for pc in (0..k).step_by(KC_NEON) {
        let kc = KC_NEON.min(k - pc);

        pack_b_panel_neon(b, &mut packed_b, n, jc, nc, pc, kc);

        for ic in (0..m).step_by(MC_NEON) {
            let mc = MC_NEON.min(m - ic);

            pack_a_panel_neon(a, &mut packed_a, k, ic, mc, pc, kc);

            for ir in (0..mc).step_by(MR_NEON) {
                let mr = MR_NEON.min(mc - ir);
                let i = ic + ir;
                let a_panel_offset = (ir / MR_NEON) * kc * MR_NEON;

                for jr in (0..nc).step_by(NR_NEON) {
                    let nr = NR_NEON.min(nc - jr);
                    let j = jc + jr;
                    let b_panel_offset = (jr / NR_NEON) * kc * NR_NEON;

                    if mr == MR_NEON && nr == NR_NEON {
                        neon_micro_kernel_4x8_fully_packed(
                            &packed_a,
                            &packed_b,
                            c,
                            n,
                            i,
                            j,
                            kc,
                            a_panel_offset,
                            b_panel_offset,
                        );
                    } else {
                        for ii in 0..mr {
                            for p in 0..kc {
                                let a_val = packed_a[a_panel_offset + p * MR_NEON + ii];
                                for jj in 0..nr {
                                    c[(i + ii) * n + (j + jj)] +=
                                        a_val * packed_b[b_panel_offset + p * NR_NEON + jj];
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// Scalar matrix multiplication with cache-aware tiling
#[allow(clippy::many_single_char_names)]
fn matmul_scalar(a: &[f32], b: &[f32], c: &mut [f32], m: usize, k: usize, n: usize) {
    const TILE: usize = 64;

    for i0 in (0..m).step_by(TILE) {
        let i_end = (i0 + TILE).min(m);

        for j0 in (0..n).step_by(TILE) {
            let j_end = (j0 + TILE).min(n);

            for l0 in (0..k).step_by(TILE) {
                let l_end = (l0 + TILE).min(k);

                for i in i0..i_end {
                    for l in l0..l_end {
                        let a_val = a[i * k + l];
                        for j in j0..j_end {
                            c[i * n + j] += a_val * b[l * n + j];
                        }
                    }
                }
            }
        }
    }
}

/// Pack a KC×NC panel of B into NR-wide contiguous micro-panels (AVX2).
///
/// Input B layout (row-major): `b[kp * n + j]` (stride = n)
/// Output packed layout: `packed[panel * kc * NR + p * NR + col]` (sequential)
#[cfg(target_arch = "x86_64")]
#[inline]
fn pack_b_panel_avx2(
    b: &[f32],
    packed: &mut [f32],
    n: usize,
    jc: usize,
    nc: usize,
    pc: usize,
    kc: usize,
) {
    let n_panels = nc.div_ceil(NR);
    for panel_idx in 0..n_panels {
        let jr = panel_idx * NR;
        let j = jc + jr;
        let nr = NR.min(nc - jr);
        let panel_base = panel_idx * kc * NR;

        for p in 0..kc {
            let dst_offset = panel_base + p * NR;
            let src_row = pc + p;
            for col in 0..nr {
                packed[dst_offset + col] = b[src_row * n + j + col];
            }
            // Zero-pad if nr < NR (edge panel)
            for col in nr..NR {
                packed[dst_offset + col] = 0.0;
            }
        }
    }
}

/// Pack an MC×KC panel of A into MR-tall contiguous micro-panels (AVX2).
///
/// Input A layout (row-major): `a[(ic + row) * k + (pc + p)]` (stride = k)
/// Output packed layout: `packed[panel * kc * MR + p * MR + row]` (sequential)
#[cfg(target_arch = "x86_64")]
#[inline]
fn pack_a_panel_avx2(
    a: &[f32],
    packed: &mut [f32],
    k: usize,
    ic: usize,
    mc: usize,
    pc: usize,
    kc: usize,
) {
    let n_panels = mc.div_ceil(MR);
    for panel_idx in 0..n_panels {
        let ir = panel_idx * MR;
        let i = ic + ir;
        let mr = MR.min(mc - ir);
        let panel_base = panel_idx * kc * MR;

        for p in 0..kc {
            let dst_offset = panel_base + p * MR;
            let src_col = pc + p;
            for row in 0..mr {
                packed[dst_offset + row] = a[(i + row) * k + src_col];
            }
            // Zero-pad if mr < MR (edge panel)
            for row in mr..MR {
                packed[dst_offset + row] = 0.0;
            }
        }
    }
}

/// AVX2 micro-kernel for fully packed A+B: 6 rows × 16 columns.
///
/// Both A and B are accessed sequentially from packed buffers.
/// A: `packed_a[panel_offset + p * MR + row]` (stride = MR)
/// B: `packed_b[panel_offset + p * NR + col]` (stride = NR)
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2", enable = "fma")]
#[inline]
#[allow(clippy::many_single_char_names)]
unsafe fn micro_kernel_6x16_packed(
    packed_a: &[f32],
    packed_b: &[f32],
    c: &mut [f32],
    n: usize,
    i: usize,
    j: usize,
    kc: usize,
    a_panel_offset: usize,
    b_panel_offset: usize,
) {
    use std::arch::x86_64::*;

    let mut acc: [[__m256; 2]; MR] = [[_mm256_setzero_ps(); 2]; MR];

    // Load current C values
    for row in 0..MR {
        let c_ptr = c.as_ptr().add((i + row) * n + j);
        for v in 0..2 {
            acc[row][v] = _mm256_loadu_ps(c_ptr.add(v * 8));
        }
    }

    // Stream through K — both A and B are sequential
    for p in 0..kc {
        let b_ptr = packed_b.as_ptr().add(b_panel_offset + p * NR);
        let b0 = _mm256_loadu_ps(b_ptr);
        let b1 = _mm256_loadu_ps(b_ptr.add(8));

        let a_ptr = packed_a.as_ptr().add(a_panel_offset + p * MR);
        for row in 0..MR {
            let a_broadcast = _mm256_set1_ps(*a_ptr.add(row));
            acc[row][0] = _mm256_fmadd_ps(a_broadcast, b0, acc[row][0]);
            acc[row][1] = _mm256_fmadd_ps(a_broadcast, b1, acc[row][1]);
        }
    }

    // Store results back to C
    for row in 0..MR {
        let c_ptr = c.as_mut_ptr().add((i + row) * n + j);
        _mm256_storeu_ps(c_ptr, acc[row][0]);
        _mm256_storeu_ps(c_ptr.add(8), acc[row][1]);
    }
}

/// AVX2-accelerated matrix multiplication with A+B packing.
///
/// BLIS-style loop order: JC → PC → (pack B) → IC → (pack A) → JR → IR.
/// B is packed once per (JC, PC) block (stays in L3).
/// A is packed once per (IC, PC) block (stays in L2).
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2", enable = "fma")]
#[allow(clippy::many_single_char_names)]
unsafe fn matmul_avx2_packed(a: &[f32], b: &[f32], c: &mut [f32], m: usize, k: usize, n: usize) {
    let max_b_panels = NC.div_ceil(NR);
    let max_a_panels = MC.div_ceil(MR);
    let mut packed_b = vec![0.0f32; max_b_panels * KC * NR];
    let mut packed_a = vec![0.0f32; max_a_panels * KC * MR];

    for jc in (0..n).step_by(NC) {
        let nc = NC.min(n - jc);

        for pc in (0..k).step_by(KC) {
            let kc = KC.min(k - pc);

            // Pack B once for this (jc, pc) block
            pack_b_panel_avx2(b, &mut packed_b, n, jc, nc, pc, kc);

            for ic in (0..m).step_by(MC) {
                let mc = MC.min(m - ic);

                // Pack A once for this (ic, pc) block
                pack_a_panel_avx2(a, &mut packed_a, k, ic, mc, pc, kc);

                for ir in (0..mc).step_by(MR) {
                    let mr = MR.min(mc - ir);
                    let i = ic + ir;
                    let a_panel_idx = ir / MR;
                    let a_panel_offset = a_panel_idx * kc * MR;

                    for jr in (0..nc).step_by(NR) {
                        let nr = NR.min(nc - jr);
                        let j = jc + jr;
                        let b_panel_idx = jr / NR;
                        let b_panel_offset = b_panel_idx * kc * NR;

                        if mr == MR && nr == NR {
                            micro_kernel_6x16_packed(
                                &packed_a,
                                &packed_b,
                                c,
                                n,
                                i,
                                j,
                                kc,
                                a_panel_offset,
                                b_panel_offset,
                            );
                        } else {
                            // Edge case: scalar fallback from packed buffers
                            for ii in 0..mr {
                                for p in 0..kc {
                                    let a_val = packed_a[a_panel_offset + p * MR + ii];
                                    for jj in 0..nr {
                                        c[(i + ii) * n + (j + jj)] +=
                                            a_val * packed_b[b_panel_offset + p * NR + jj];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// AVX2-accelerated matrix multiplication with register blocking
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2", enable = "fma")]
#[allow(clippy::many_single_char_names)]
unsafe fn matmul_avx2(a: &[f32], b: &[f32], c: &mut [f32], m: usize, k: usize, n: usize) {
    // Loop over NC-wide panels of B and MC-tall panels of A
    for jc in (0..n).step_by(NC) {
        let nc = NC.min(n - jc);

        for pc in (0..k).step_by(KC) {
            let kc = KC.min(k - pc);

            for ic in (0..m).step_by(MC) {
                let mc = MC.min(m - ic);

                // Process MR x NR micro-tiles
                for ir in (0..mc).step_by(MR) {
                    let mr = MR.min(mc - ir);
                    let i = ic + ir;

                    for jr in (0..nc).step_by(NR) {
                        let nr = NR.min(nc - jr);
                        let j = jc + jr;

                        if mr == MR && nr == NR {
                            // Full 6x16 micro-kernel
                            micro_kernel_6x16(a, b, c, k, n, i, j, pc, kc);
                        } else {
                            // Edge case: partial micro-kernel
                            for ii in 0..mr {
                                for p in 0..kc {
                                    let a_val = a[(i + ii) * k + (pc + p)];
                                    for jj in 0..nr {
                                        c[(i + ii) * n + (j + jj)] +=
                                            a_val * b[(pc + p) * n + (j + jj)];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// NEON-accelerated matrix multiplication with register blocking
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
#[allow(clippy::many_single_char_names)]
unsafe fn matmul_neon(a: &[f32], b: &[f32], c: &mut [f32], m: usize, k: usize, n: usize) {
    // Loop over NC-wide panels of B and MC-tall panels of A
    for jc in (0..n).step_by(NC_NEON) {
        let nc = NC_NEON.min(n - jc);

        for pc in (0..k).step_by(KC_NEON) {
            let kc = KC_NEON.min(k - pc);

            for ic in (0..m).step_by(MC_NEON) {
                let mc = MC_NEON.min(m - ic);

                // Process MR x NR micro-tiles
                for ir in (0..mc).step_by(MR_NEON) {
                    let mr = MR_NEON.min(mc - ir);
                    let i = ic + ir;

                    for jr in (0..nc).step_by(NR_NEON) {
                        let nr = NR_NEON.min(nc - jr);
                        let j = jc + jr;

                        if mr == MR_NEON && nr == NR_NEON {
                            // Full 4x8 NEON micro-kernel
                            neon_micro_kernel_4x8(a, b, c, k, n, i, j, pc, kc);
                        } else {
                            // Edge case: partial micro-kernel (scalar fallback)
                            for ii in 0..mr {
                                for p in 0..kc {
                                    let a_val = a[(i + ii) * k + (pc + p)];
                                    for jj in 0..nr {
                                        c[(i + ii) * n + (j + jj)] +=
                                            a_val * b[(pc + p) * n + (j + jj)];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// CNN Configuration Types
// ============================================================================

/// Configuration for 2D convolution operations.
///
/// Encapsulates all parameters needed for conv2d except buffer references.
#[derive(Debug, Clone, Copy)]
pub struct Conv2dConfig {
    /// Batch size
    pub batch: usize,
    /// Number of input channels
    pub in_channels: usize,
    /// Number of output channels
    pub out_channels: usize,
    /// Input height
    pub in_h: usize,
    /// Input width
    pub in_w: usize,
    /// Output height
    pub out_h: usize,
    /// Output width
    pub out_w: usize,
    /// Kernel height
    pub kernel_h: usize,
    /// Kernel width
    pub kernel_w: usize,
    /// Stride height
    pub stride_h: usize,
    /// Stride width
    pub stride_w: usize,
    /// Padding height
    pub pad_h: usize,
    /// Padding width
    pub pad_w: usize,
    /// Dilation height
    pub dilation_h: usize,
    /// Dilation width
    pub dilation_w: usize,
    /// Number of groups for grouped convolution
    pub groups: usize,
}

impl Conv2dConfig {
    /// Create config from ISA instruction parameters.
    #[must_use]
    #[allow(clippy::too_many_arguments)]
    pub fn from_isa(
        batch: usize,
        in_channels: usize,
        out_channels: usize,
        in_h: usize,
        in_w: usize,
        out_h: usize,
        out_w: usize,
        kernel_h: usize,
        kernel_w: usize,
        stride_h: usize,
        stride_w: usize,
        pad_h: usize,
        pad_w: usize,
        dilation_h: usize,
        dilation_w: usize,
        groups: usize,
    ) -> Self {
        Self {
            batch,
            in_channels,
            out_channels,
            in_h,
            in_w,
            out_h,
            out_w,
            kernel_h,
            kernel_w,
            stride_h,
            stride_w,
            pad_h,
            pad_w,
            dilation_h,
            dilation_w,
            groups,
        }
    }
}

/// Configuration for 2D pooling operations (max/avg pool).
///
/// Encapsulates all parameters needed for pooling except buffer references.
#[derive(Debug, Clone, Copy)]
pub struct Pool2dConfig {
    /// Batch size
    pub batch: usize,
    /// Number of channels
    pub channels: usize,
    /// Input height
    pub in_h: usize,
    /// Input width
    pub in_w: usize,
    /// Output height
    pub out_h: usize,
    /// Output width
    pub out_w: usize,
    /// Kernel height
    pub kernel_h: usize,
    /// Kernel width
    pub kernel_w: usize,
    /// Stride height
    pub stride_h: usize,
    /// Stride width
    pub stride_w: usize,
    /// Padding height
    pub pad_h: usize,
    /// Padding width
    pub pad_w: usize,
}

impl Pool2dConfig {
    /// Create config from ISA instruction parameters.
    #[must_use]
    #[allow(clippy::too_many_arguments)]
    pub fn from_isa(
        batch: usize,
        channels: usize,
        in_h: usize,
        in_w: usize,
        out_h: usize,
        out_w: usize,
        kernel_h: usize,
        kernel_w: usize,
        stride_h: usize,
        stride_w: usize,
        pad_h: usize,
        pad_w: usize,
    ) -> Self {
        Self {
            batch,
            channels,
            in_h,
            in_w,
            out_h,
            out_w,
            kernel_h,
            kernel_w,
            stride_h,
            stride_w,
            pad_h,
            pad_w,
        }
    }
}

/// Configuration for batch normalization.
///
/// Encapsulates parameters for batch norm inference.
#[derive(Debug, Clone, Copy)]
pub struct BatchNormConfig {
    /// Batch size
    pub batch: usize,
    /// Number of channels
    pub channels: usize,
    /// Spatial size (height * width)
    pub spatial: usize,
    /// Epsilon for numerical stability
    pub epsilon: f32,
}

impl BatchNormConfig {
    /// Create config from ISA instruction parameters.
    #[must_use]
    pub fn from_isa(batch: usize, channels: usize, spatial: usize, epsilon: f32) -> Self {
        Self {
            batch,
            channels,
            spatial,
            epsilon,
        }
    }
}

/// Configuration for layer normalization.
///
/// Encapsulates parameters for layer norm (transformer-style).
#[derive(Debug, Clone, Copy)]
pub struct LayerNormConfig {
    /// Number of instances (batch * sequence_length)
    pub num_instances: usize,
    /// Size of normalized dimension (hidden_size)
    pub normalized_count: usize,
    /// Epsilon for numerical stability
    pub epsilon: f32,
}

impl LayerNormConfig {
    /// Create config from ISA instruction parameters.
    #[must_use]
    pub fn from_isa(num_instances: usize, normalized_count: usize, epsilon: f32) -> Self {
        Self {
            num_instances,
            normalized_count,
            epsilon,
        }
    }
}

// ============================================================================
// CNN Operations
// ============================================================================

/// 2D Convolution (NCHW format) with direct loop implementation.
///
/// Input: [batch, in_channels, in_h, in_w]
/// Weight: [out_channels, in_channels/groups, kernel_h, kernel_w]
/// Output: [batch, out_channels, out_h, out_w]
#[allow(clippy::too_many_arguments)]
pub fn conv2d_nchw(
    output: &mut [f32],
    input: &[f32],
    weight: &[f32],
    bias: Option<&[f32]>,
    batch: usize,
    in_channels: usize,
    out_channels: usize,
    in_h: usize,
    in_w: usize,
    out_h: usize,
    out_w: usize,
    kernel_h: usize,
    kernel_w: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
    dilation_h: usize,
    dilation_w: usize,
    groups: usize,
) {
    let in_channels_per_group = in_channels / groups;
    let out_channels_per_group = out_channels / groups;

    for n in 0..batch {
        for g in 0..groups {
            let oc_start = g * out_channels_per_group;
            let oc_end = oc_start + out_channels_per_group;
            let ic_start = g * in_channels_per_group;

            for oc in oc_start..oc_end {
                for oh in 0..out_h {
                    for ow in 0..out_w {
                        let mut sum = bias.map_or(0.0, |b| b[oc]);

                        for ic_offset in 0..in_channels_per_group {
                            let ic = ic_start + ic_offset;

                            for kh in 0..kernel_h {
                                for kw in 0..kernel_w {
                                    let src_row =
                                        (oh * stride_h + kh * dilation_h).wrapping_sub(pad_h);
                                    let src_col =
                                        (ow * stride_w + kw * dilation_w).wrapping_sub(pad_w);

                                    // Check bounds (wrapping subtraction makes out-of-bounds very large)
                                    if src_row < in_h && src_col < in_w {
                                        let in_idx = n * in_channels * in_h * in_w
                                            + ic * in_h * in_w
                                            + src_row * in_w
                                            + src_col;
                                        let w_idx =
                                            oc * in_channels_per_group * kernel_h * kernel_w
                                                + ic_offset * kernel_h * kernel_w
                                                + kh * kernel_w
                                                + kw;

                                        sum += input[in_idx] * weight[w_idx];
                                    }
                                }
                            }
                        }

                        let out_idx =
                            n * out_channels * out_h * out_w + oc * out_h * out_w + oh * out_w + ow;
                        output[out_idx] = sum;
                    }
                }
            }
        }
    }
}

/// Batch Normalization (inference mode).
///
/// Applies: output = (input - mean) / sqrt(var + epsilon) * scale + bias
#[allow(clippy::too_many_arguments)]
pub fn batch_norm_inference(
    output: &mut [f32],
    input: &[f32],
    scale: &[f32],
    bias: &[f32],
    mean: &[f32],
    var: &[f32],
    epsilon: f32,
    batch: usize,
    channels: usize,
    spatial: usize,
) {
    // Precompute: a[c] = scale[c] / sqrt(var[c] + epsilon)
    //             b[c] = bias[c] - mean[c] * a[c]
    let mut a = vec![0.0f32; channels];
    let mut b = vec![0.0f32; channels];

    for c in 0..channels {
        let inv_std = 1.0 / (var[c] + epsilon).sqrt();
        a[c] = scale[c] * inv_std;
        b[c] = bias[c] - mean[c] * a[c];
    }

    // Apply: output[n,c,h,w] = input[n,c,h,w] * a[c] + b[c]
    for n in 0..batch {
        for c in 0..channels {
            let offset = (n * channels + c) * spatial;
            let a_c = a[c];
            let b_c = b[c];

            for i in 0..spatial {
                output[offset + i] = input[offset + i] * a_c + b_c;
            }
        }
    }
}

/// Layer Normalization (transformer-style).
///
/// Normalizes over the last `normalized_count` elements per instance using
/// Welford's algorithm for numerical stability.
///
/// # Arguments
/// * `input` - Input tensor of shape `[num_instances, normalized_count]`
/// * `scale` - Scale (gamma) parameters of shape `[normalized_count]`
/// * `bias` - Bias (beta) parameters of shape `[normalized_count]`
/// * `output` - Output tensor (same shape as input)
/// * `num_instances` - Number of instances (batch * sequence_length for transformers)
/// * `normalized_count` - Size of normalized dimension (hidden_size for transformers)
/// * `epsilon` - Numerical stability constant (typically 1e-5)
#[allow(
    clippy::too_many_arguments,
    clippy::cast_precision_loss,
    clippy::cast_possible_truncation
)]
pub fn layer_norm_simd(
    input: &[f32],
    scale: &[f32],
    bias: &[f32],
    output: &mut [f32],
    num_instances: usize,
    normalized_count: usize,
    epsilon: f32,
) {
    // Process each instance independently
    for i in 0..num_instances {
        let offset = i * normalized_count;
        let slice = &input[offset..offset + normalized_count];
        let out_slice = &mut output[offset..offset + normalized_count];

        // Welford's algorithm for numerically stable mean and variance
        // Using f64 for intermediate precision
        let mut mean = 0.0f64;
        let mut m2 = 0.0f64;

        for (n, &x) in slice.iter().enumerate() {
            let x = f64::from(x);
            let delta = x - mean;
            mean += delta / (n + 1) as f64;
            let delta2 = x - mean;
            m2 += delta * delta2;
        }

        let var = m2 / normalized_count as f64;
        let inv_std = 1.0 / (var + f64::from(epsilon)).sqrt();

        // Normalize and apply scale/bias
        for j in 0..normalized_count {
            let normalized = (f64::from(slice[j]) - mean) * inv_std;
            out_slice[j] = (normalized * f64::from(scale[j]) + f64::from(bias[j])) as f32;
        }
    }
}

/// 2D Max Pooling.
///
/// Input: [batch, channels, in_h, in_w]
/// Output: [batch, channels, out_h, out_w]
#[allow(clippy::too_many_arguments)]
pub fn max_pool2d(
    output: &mut [f32],
    input: &[f32],
    batch: usize,
    channels: usize,
    in_h: usize,
    in_w: usize,
    out_h: usize,
    out_w: usize,
    kernel_h: usize,
    kernel_w: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
) {
    for n in 0..batch {
        for c in 0..channels {
            for oh in 0..out_h {
                for ow in 0..out_w {
                    let mut max_val = f32::NEG_INFINITY;

                    for kh in 0..kernel_h {
                        for kw in 0..kernel_w {
                            let src_row = (oh * stride_h + kh).wrapping_sub(pad_h);
                            let src_col = (ow * stride_w + kw).wrapping_sub(pad_w);

                            // Check bounds (wrapping subtraction makes out-of-bounds very large)
                            if src_row < in_h && src_col < in_w {
                                let idx = n * channels * in_h * in_w
                                    + c * in_h * in_w
                                    + src_row * in_w
                                    + src_col;
                                max_val = max_val.max(input[idx]);
                            }
                        }
                    }

                    // Handle case where all positions are padded (use 0 as fallback)
                    if max_val == f32::NEG_INFINITY {
                        max_val = 0.0;
                    }

                    let out_idx =
                        n * channels * out_h * out_w + c * out_h * out_w + oh * out_w + ow;
                    output[out_idx] = max_val;
                }
            }
        }
    }
}

/// 2D Average Pooling.
///
/// Input: [batch, channels, in_h, in_w]
/// Output: [batch, channels, out_h, out_w]
#[allow(clippy::too_many_arguments, clippy::cast_precision_loss)]
pub fn avg_pool2d(
    output: &mut [f32],
    input: &[f32],
    batch: usize,
    channels: usize,
    in_h: usize,
    in_w: usize,
    out_h: usize,
    out_w: usize,
    kernel_h: usize,
    kernel_w: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
) {
    for n in 0..batch {
        for c in 0..channels {
            for oh in 0..out_h {
                for ow in 0..out_w {
                    let mut sum = 0.0f32;
                    let mut count = 0usize;

                    for kh in 0..kernel_h {
                        for kw in 0..kernel_w {
                            let src_row = (oh * stride_h + kh).wrapping_sub(pad_h);
                            let src_col = (ow * stride_w + kw).wrapping_sub(pad_w);

                            // Check bounds (wrapping subtraction makes out-of-bounds very large)
                            if src_row < in_h && src_col < in_w {
                                let idx = n * channels * in_h * in_w
                                    + c * in_h * in_w
                                    + src_row * in_w
                                    + src_col;
                                sum += input[idx];
                                count += 1;
                            }
                        }
                    }

                    // Compute average (handle edge case where count is 0)
                    let avg = if count > 0 { sum / count as f32 } else { 0.0 };

                    let out_idx =
                        n * channels * out_h * out_w + c * out_h * out_w + oh * out_w + ow;
                    output[out_idx] = avg;
                }
            }
        }
    }
}

/// Global Average Pooling.
///
/// Reduces spatial dimensions to 1x1 by averaging.
/// Input: [batch, channels, H, W], Output: [batch, channels]
#[allow(clippy::cast_precision_loss)]
pub fn global_avg_pool(
    output: &mut [f32],
    input: &[f32],
    batch: usize,
    channels: usize,
    spatial: usize,
) {
    let inv_spatial = 1.0 / spatial as f32;

    for n in 0..batch {
        for c in 0..channels {
            let in_offset = (n * channels + c) * spatial;
            let sum: f32 = input[in_offset..in_offset + spatial].iter().sum();
            output[n * channels + c] = sum * inv_spatial;
        }
    }
}

/// Softmax with axis support.
///
/// Computes numerically stable softmax along a specified axis.
/// The tensor is interpreted as [outer_size, axis_size, inner_size].
///
/// For each outer position and inner position, softmax is computed over axis_size elements.
///
/// Formula: softmax(x) = exp(x - max(x)) / sum(exp(x - max(x)))
#[allow(clippy::cast_precision_loss)]
pub fn softmax_simd(
    input: &[f32],
    output: &mut [f32],
    outer_size: usize,
    axis_size: usize,
    inner_size: usize,
) {
    // Process each outer x inner combination
    for outer in 0..outer_size {
        for inner in 0..inner_size {
            // Compute stride: elements are at outer * (axis_size * inner_size) + axis * inner_size + inner
            let base_offset = outer * axis_size * inner_size + inner;
            let stride = inner_size;

            // Step 1: Find max for numerical stability
            let mut max_val = f32::NEG_INFINITY;
            for axis in 0..axis_size {
                let idx = base_offset + axis * stride;
                max_val = max_val.max(input[idx]);
            }

            // Step 2: Compute exp(x - max) and sum
            let mut sum = 0.0f32;
            for axis in 0..axis_size {
                let idx = base_offset + axis * stride;
                let exp_val = (input[idx] - max_val).exp();
                output[idx] = exp_val;
                sum += exp_val;
            }

            // Step 3: Normalize by sum
            let inv_sum = 1.0 / sum;
            for axis in 0..axis_size {
                let idx = base_offset + axis * stride;
                output[idx] *= inv_sum;
            }
        }
    }
}

/// Scalar fallback for softmax.
#[allow(clippy::cast_precision_loss)]
pub fn softmax_scalar(
    input: &[f32],
    output: &mut [f32],
    outer_size: usize,
    axis_size: usize,
    inner_size: usize,
) {
    softmax_simd(input, output, outer_size, axis_size, inner_size);
}

#[cfg(test)]
mod tests {
    use super::*;

    // ========================================================================
    // SIMD Arithmetic Tests
    // ========================================================================

    #[test]
    fn test_add_simd_basic() {
        let a = vec![1.0f32, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
        let b = vec![8.0f32, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0];
        let mut result = vec![0.0f32; 8];

        add_simd(&a, &b, &mut result);

        // All should sum to 9.0
        for &r in &result {
            assert!((r - 9.0).abs() < 1e-6);
        }
    }

    #[test]
    fn test_add_simd_remainder() {
        // Test with non-multiple of 8
        let a = vec![1.0f32, 2.0, 3.0, 4.0, 5.0];
        let b = vec![1.0f32, 1.0, 1.0, 1.0, 1.0];
        let mut result = vec![0.0f32; 5];

        add_simd(&a, &b, &mut result);

        let expected = [2.0, 3.0, 4.0, 5.0, 6.0];
        for (r, e) in result.iter().zip(expected.iter()) {
            assert!((r - e).abs() < 1e-6);
        }
    }

    #[test]
    fn test_sub_simd_basic() {
        let a = vec![10.0f32; 8];
        let b = vec![3.0f32; 8];
        let mut result = vec![0.0f32; 8];

        sub_simd(&a, &b, &mut result);

        for &r in &result {
            assert!((r - 7.0).abs() < 1e-6);
        }
    }

    #[test]
    fn test_mul_simd_basic() {
        let a = vec![2.0f32; 8];
        let b = vec![3.0f32; 8];
        let mut result = vec![0.0f32; 8];

        mul_simd(&a, &b, &mut result);

        for &r in &result {
            assert!((r - 6.0).abs() < 1e-6);
        }
    }

    #[test]
    fn test_mul_simd_large() {
        // Test with larger array to exercise SIMD path
        let a = vec![2.0f32; 100];
        let b = vec![3.0f32; 100];
        let mut result = vec![0.0f32; 100];

        mul_simd(&a, &b, &mut result);

        for &r in &result {
            assert!((r - 6.0).abs() < 1e-6);
        }
    }

    // ========================================================================
    // SIMD Activation Tests
    // ========================================================================

    #[test]
    fn test_relu_simd_basic() {
        let src = vec![1.0f32, -1.0, 2.0, -2.0, 3.0, -3.0, 4.0, -4.0];
        let mut result = vec![0.0f32; 8];

        relu_simd(&src, &mut result);

        let expected = [1.0, 0.0, 2.0, 0.0, 3.0, 0.0, 4.0, 0.0];
        for (r, e) in result.iter().zip(expected.iter()) {
            assert!((r - e).abs() < 1e-6);
        }
    }

    #[test]
    fn test_relu_simd_all_positive() {
        let src = vec![1.0f32, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
        let mut result = vec![0.0f32; 8];

        relu_simd(&src, &mut result);

        for (r, s) in result.iter().zip(src.iter()) {
            assert!((r - s).abs() < 1e-6);
        }
    }

    #[test]
    fn test_relu_simd_all_negative() {
        let src = vec![-1.0f32, -2.0, -3.0, -4.0, -5.0, -6.0, -7.0, -8.0];
        let mut result = vec![0.0f32; 8];

        relu_simd(&src, &mut result);

        for &r in &result {
            assert!(r.abs() < 1e-6);
        }
    }

    #[test]
    fn test_sigmoid_simd_basic() {
        let src = vec![0.0f32, 1.0, -1.0, 2.0, -2.0, 5.0, -5.0, 10.0];
        let mut result = vec![0.0f32; 8];

        sigmoid_simd(&src, &mut result);

        // sigmoid(0) = 0.5
        assert!((result[0] - 0.5).abs() < 1e-4);
        // sigmoid(x) > 0.5 for x > 0
        assert!(result[1] > 0.5);
        // sigmoid(-x) < 0.5 for x > 0
        assert!(result[2] < 0.5);
        // sigmoid(x) + sigmoid(-x) ≈ 1
        assert!((result[1] + result[2] - 1.0).abs() < 1e-4);
        assert!((result[3] + result[4] - 1.0).abs() < 1e-4);
        // Large positive -> ~1
        assert!(result[7] > 0.999);
    }

    #[test]
    #[allow(clippy::cast_precision_loss)] // Test uses small integers where precision is exact
    fn test_sigmoid_simd_accuracy() {
        // Test accuracy against standard library
        // Note: Polynomial approximation has ~1e-3 error margin
        let src: Vec<f32> = (-10..=10).map(|x| x as f32 * 0.5).collect();
        let mut result = vec![0.0f32; src.len()];

        sigmoid_simd(&src, &mut result);

        for (i, &x) in src.iter().enumerate() {
            let expected = 1.0 / (1.0 + (-x).exp());
            assert!(
                (result[i] - expected).abs() < 1e-3,
                "sigmoid({x}) = {} expected {expected}",
                result[i]
            );
        }
    }

    #[test]
    fn test_sigmoid_simd_large() {
        // Test with larger array to exercise SIMD path
        let src = vec![0.5f32; 100];
        let mut result = vec![0.0f32; 100];

        sigmoid_simd(&src, &mut result);

        let expected = 1.0 / (1.0 + (-0.5f32).exp());
        for &r in &result {
            assert!((r - expected).abs() < 1e-3);
        }
    }

    #[test]
    fn test_tanh_simd_basic() {
        let src = vec![0.0f32, 1.0, -1.0, 2.0, -2.0, 5.0, -5.0, 10.0];
        let mut result = vec![0.0f32; 8];

        tanh_simd(&src, &mut result);

        // tanh(0) = 0 (polynomial approximation has some error)
        assert!(result[0].abs() < 1e-3);
        // tanh is odd: tanh(-x) = -tanh(x)
        assert!((result[1] + result[2]).abs() < 1e-3);
        assert!((result[3] + result[4]).abs() < 1e-3);
        // Large positive -> ~1, large negative -> ~-1
        assert!(result[5] > 0.99);
        assert!(result[6] < -0.99);
    }

    #[test]
    #[allow(clippy::cast_precision_loss)] // Test uses small integers where precision is exact
    fn test_tanh_simd_accuracy() {
        // Test accuracy against standard library
        // Note: Polynomial approximation has ~1e-3 error margin
        let src: Vec<f32> = (-10..=10).map(|x| x as f32 * 0.5).collect();
        let mut result = vec![0.0f32; src.len()];

        tanh_simd(&src, &mut result);

        for (i, &x) in src.iter().enumerate() {
            let expected = x.tanh();
            assert!(
                (result[i] - expected).abs() < 1e-3,
                "tanh({x}) = {} expected {expected}",
                result[i]
            );
        }
    }

    #[test]
    fn test_tanh_simd_large() {
        // Test with larger array to exercise SIMD path
        let src = vec![0.5f32; 100];
        let mut result = vec![0.0f32; 100];

        tanh_simd(&src, &mut result);

        let expected = 0.5f32.tanh();
        for &r in &result {
            assert!((r - expected).abs() < 1e-3);
        }
    }

    // ========================================================================
    // Tiled MatMul Tests
    // ========================================================================

    #[test]
    fn test_matmul_tiled_2x2() {
        // A = [[1,2],[3,4]], B = [[5,6],[7,8]]
        // C = [[1*5+2*7, 1*6+2*8], [3*5+4*7, 3*6+4*8]] = [[19,22],[43,50]]
        let a = vec![1.0f32, 2.0, 3.0, 4.0];
        let b = vec![5.0f32, 6.0, 7.0, 8.0];
        let mut c = vec![0.0f32; 4];

        matmul_tiled(&a, &b, &mut c, 2, 2, 2);

        let expected = [19.0, 22.0, 43.0, 50.0];
        for (r, e) in c.iter().zip(expected.iter()) {
            assert!((r - e).abs() < 1e-5);
        }
    }

    #[test]
    fn test_matmul_tiled_identity() {
        // A = I (identity), B = some matrix
        // C = I @ B = B
        let a = vec![1.0f32, 0.0, 0.0, 1.0];
        let b = vec![5.0f32, 6.0, 7.0, 8.0];
        let mut c = vec![0.0f32; 4];

        matmul_tiled(&a, &b, &mut c, 2, 2, 2);

        for (r, e) in c.iter().zip(b.iter()) {
            assert!((r - e).abs() < 1e-6);
        }
    }

    #[test]
    #[allow(clippy::cast_precision_loss)]
    fn test_matmul_tiled_large() {
        // Test with matrix larger than tile size
        let size = 100;
        let a = vec![1.0f32; size * size];
        let b = vec![1.0f32; size * size];
        let mut c = vec![0.0f32; size * size];

        matmul_tiled(&a, &b, &mut c, size, size, size);

        // Each element should be sum of 'size' ones = size
        for &r in &c {
            assert!((r - size as f32).abs() < 1e-3);
        }
    }

    #[test]
    fn test_matmul_tiled_non_square() {
        // A = 2x3, B = 3x2, C = 2x2
        let a = vec![1.0f32, 2.0, 3.0, 4.0, 5.0, 6.0];
        let b = vec![7.0f32, 8.0, 9.0, 10.0, 11.0, 12.0];
        let mut c = vec![0.0f32; 4];

        matmul_tiled(&a, &b, &mut c, 2, 3, 2);

        // C[0,0] = 1*7 + 2*9 + 3*11 = 7 + 18 + 33 = 58
        // C[0,1] = 1*8 + 2*10 + 3*12 = 8 + 20 + 36 = 64
        // C[1,0] = 4*7 + 5*9 + 6*11 = 28 + 45 + 66 = 139
        // C[1,1] = 4*8 + 5*10 + 6*12 = 32 + 50 + 72 = 154
        let expected = [58.0, 64.0, 139.0, 154.0];
        for (r, e) in c.iter().zip(expected.iter()) {
            assert!((r - e).abs() < 1e-5);
        }
    }

    // ========================================================================
    // Feature Detection Test
    // ========================================================================

    #[test]
    fn test_simd_functions_work_regardless_of_avx2() {
        // Verify SIMD functions work correctly (using scalar fallback if no AVX2)
        let a = vec![1.0f32, 2.0];
        let b = vec![3.0f32, 4.0];
        let mut result = vec![0.0f32; 2];

        add_simd(&a, &b, &mut result);
        assert!((result[0] - 4.0).abs() < 1e-6);
        assert!((result[1] - 6.0).abs() < 1e-6);
    }

    // ========================================================================
    // Parallel Execution Tests
    // ========================================================================

    #[test]
    fn test_add_parallel_small() {
        // Below threshold, should use SIMD path
        let a = vec![1.0f32; 100];
        let b = vec![2.0f32; 100];
        let mut result = vec![0.0f32; 100];

        add_parallel(&a, &b, &mut result);

        for &r in &result {
            assert!((r - 3.0).abs() < 1e-6);
        }
    }

    #[test]
    fn test_add_parallel_large() {
        // Above threshold, should use parallel path
        let a = vec![1.0f32; 10000];
        let b = vec![2.0f32; 10000];
        let mut result = vec![0.0f32; 10000];

        add_parallel(&a, &b, &mut result);

        for &r in &result {
            assert!((r - 3.0).abs() < 1e-6);
        }
    }

    #[test]
    fn test_sub_parallel_large() {
        let a = vec![5.0f32; 10000];
        let b = vec![2.0f32; 10000];
        let mut result = vec![0.0f32; 10000];

        sub_parallel(&a, &b, &mut result);

        for &r in &result {
            assert!((r - 3.0).abs() < 1e-6);
        }
    }

    #[test]
    fn test_mul_parallel_large() {
        let a = vec![2.0f32; 10000];
        let b = vec![3.0f32; 10000];
        let mut result = vec![0.0f32; 10000];

        mul_parallel(&a, &b, &mut result);

        for &r in &result {
            assert!((r - 6.0).abs() < 1e-6);
        }
    }

    #[test]
    #[allow(clippy::cast_precision_loss)] // Test uses small integers where precision is sufficient
    fn test_relu_parallel_large() {
        let src: Vec<f32> = (-5000..5000).map(|x| x as f32).collect();
        let mut result = vec![0.0f32; 10000];

        relu_parallel(&src, &mut result);

        for (i, &r) in result.iter().enumerate() {
            let expected = src[i].max(0.0);
            assert!((r - expected).abs() < 1e-6);
        }
    }

    #[test]
    fn test_matmul_parallel_small() {
        // Below threshold, should use tiled path
        let a = vec![1.0f32, 2.0, 3.0, 4.0];
        let b = vec![5.0f32, 6.0, 7.0, 8.0];
        let mut c = vec![0.0f32; 4];

        matmul_parallel(&a, &b, &mut c, 2, 2, 2);

        let expected = [19.0, 22.0, 43.0, 50.0];
        for (r, e) in c.iter().zip(expected.iter()) {
            assert!((r - e).abs() < 1e-5);
        }
    }

    #[test]
    #[allow(clippy::cast_precision_loss)]
    fn test_matmul_parallel_large() {
        // Above threshold, should use parallel path
        let size = 100;
        let a = vec![1.0f32; size * size];
        let b = vec![1.0f32; size * size];
        let mut c = vec![0.0f32; size * size];

        matmul_parallel(&a, &b, &mut c, size, size, size);

        // Each element should be sum of 'size' ones = size
        for &r in &c {
            assert!((r - size as f32).abs() < 1e-3);
        }
    }

    // ========================================================================
    // SIMD Reduction Tests
    // ========================================================================

    #[test]
    fn test_sum_simd_basic() {
        let src = vec![1.0f32, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
        let result = sum_simd(&src);
        let expected: f32 = src.iter().sum();
        assert!((result - expected).abs() < 1e-5);
    }

    #[test]
    #[allow(clippy::cast_precision_loss)]
    fn test_sum_simd_large() {
        // Large array to exercise SIMD path
        let src: Vec<f32> = (1..=1000).map(|x| x as f32).collect();
        let result = sum_simd(&src);
        let expected: f32 = (1..=1000).sum::<i32>() as f32;
        assert!(
            (result - expected).abs() < 1e-2,
            "sum_simd result {result} expected {expected}"
        );
    }

    #[test]
    fn test_sum_simd_empty() {
        let src: Vec<f32> = vec![];
        let result = sum_simd(&src);
        assert!((result - 0.0).abs() < 1e-10);
    }

    #[test]
    fn test_max_simd_basic() {
        let src = vec![1.0f32, 5.0, 3.0, 8.0, 2.0, 7.0, 4.0, 6.0];
        let result = max_simd(&src);
        assert!((result - 8.0).abs() < 1e-6);
    }

    #[test]
    fn test_max_simd_negative() {
        let src = vec![-5.0f32, -2.0, -8.0, -1.0, -3.0, -7.0, -4.0, -6.0];
        let result = max_simd(&src);
        assert!((result - (-1.0)).abs() < 1e-6);
    }

    #[test]
    #[allow(clippy::cast_precision_loss)]
    fn test_max_simd_large() {
        // Large array to exercise SIMD path
        let mut src: Vec<f32> = (1..=1000).map(|x| x as f32).collect();
        src[500] = 5000.0; // Insert max in middle
        let result = max_simd(&src);
        assert!((result - 5000.0).abs() < 1e-5);
    }

    #[test]
    fn test_max_simd_empty() {
        let src: Vec<f32> = vec![];
        let result = max_simd(&src);
        assert!(result == f32::NEG_INFINITY);
    }

    #[test]
    fn test_min_simd_basic() {
        let src = vec![5.0f32, 1.0, 3.0, 8.0, 2.0, 7.0, 4.0, 6.0];
        let result = min_simd(&src);
        assert!((result - 1.0).abs() < 1e-6);
    }

    #[test]
    fn test_min_simd_negative() {
        let src = vec![-5.0f32, -2.0, -8.0, -1.0, -3.0, -7.0, -4.0, -6.0];
        let result = min_simd(&src);
        assert!((result - (-8.0)).abs() < 1e-6);
    }

    #[test]
    #[allow(clippy::cast_precision_loss)]
    fn test_min_simd_large() {
        // Large array to exercise SIMD path
        let mut src: Vec<f32> = (1..=1000).map(|x| x as f32).collect();
        src[500] = -5000.0; // Insert min in middle
        let result = min_simd(&src);
        assert!((result - (-5000.0)).abs() < 1e-5);
    }

    #[test]
    fn test_min_simd_empty() {
        let src: Vec<f32> = vec![];
        let result = min_simd(&src);
        assert!(result == f32::INFINITY);
    }

    // ========================================================================
    // NEON MatMul Tests (aarch64 specific, but tests use matmul_tiled which
    // dispatches to NEON on ARM or AVX2/scalar on other platforms)
    // ========================================================================

    #[test]
    #[allow(clippy::many_single_char_names, clippy::cast_precision_loss)]
    fn test_matmul_neon_4x8_basic() {
        // Test minimum NEON micro-kernel size (4 rows x 8 columns)
        let m = 4;
        let k = 4;
        let n = 8;

        let a: Vec<f32> = (0..m * k).map(|i| (i + 1) as f32).collect();
        let b: Vec<f32> = (0..k * n).map(|i| ((i % 8) + 1) as f32).collect();
        let mut c = vec![0.0f32; m * n];

        matmul_tiled(&a, &b, &mut c, m, k, n);

        // Compute reference using scalar
        let mut expected = vec![0.0f32; m * n];
        for i in 0..m {
            for j in 0..n {
                for l in 0..k {
                    expected[i * n + j] += a[i * k + l] * b[l * n + j];
                }
            }
        }

        for (i, (r, e)) in c.iter().zip(expected.iter()).enumerate() {
            assert!(
                (r - e).abs() < 1e-4,
                "mismatch at {i}: got {r}, expected {e}"
            );
        }
    }

    #[test]
    #[allow(clippy::many_single_char_names, clippy::cast_precision_loss)]
    fn test_matmul_neon_exact_tile() {
        // Test exact tile multiple (48x128 matches MC_NEON x NC_NEON)
        let m = 48;
        let k = 32;
        let n = 128;

        let a = vec![1.0f32; m * k];
        let b = vec![1.0f32; k * n];
        let mut c = vec![0.0f32; m * n];

        matmul_tiled(&a, &b, &mut c, m, k, n);

        // Each element should equal k (sum of k ones)
        for &r in &c {
            assert!((r - k as f32).abs() < 1e-3);
        }
    }

    #[test]
    #[allow(clippy::many_single_char_names, clippy::cast_precision_loss)]
    fn test_matmul_neon_larger_than_tile() {
        // Test with matrix larger than all tile sizes (full blocking)
        let m = 128;
        let k = 256;
        let n = 256;

        let a = vec![0.5f32; m * k];
        let b = vec![0.5f32; k * n];
        let mut c = vec![0.0f32; m * n];

        matmul_tiled(&a, &b, &mut c, m, k, n);

        // Each element should be k * 0.5 * 0.5 = k * 0.25
        let expected = k as f32 * 0.25;
        for &r in &c {
            assert!((r - expected).abs() < 0.1);
        }
    }

    #[test]
    #[allow(clippy::many_single_char_names, clippy::cast_precision_loss)]
    fn test_matmul_neon_edge_cases() {
        // Test non-aligned dimensions (17x33) that don't match tile multiples
        let m = 17;
        let k = 33;
        let n = 29;

        let a: Vec<f32> = (0..m * k).map(|i| ((i % 5) as f32) / 5.0).collect();
        let b: Vec<f32> = (0..k * n).map(|i| ((i % 7) as f32) / 7.0).collect();
        let mut c = vec![0.0f32; m * n];

        matmul_tiled(&a, &b, &mut c, m, k, n);

        // Compute reference
        let mut expected = vec![0.0f32; m * n];
        for i in 0..m {
            for j in 0..n {
                for l in 0..k {
                    expected[i * n + j] += a[i * k + l] * b[l * n + j];
                }
            }
        }

        for (i, (r, e)) in c.iter().zip(expected.iter()).enumerate() {
            assert!(
                (r - e).abs() < 1e-3,
                "mismatch at {i}: got {r}, expected {e}"
            );
        }
    }

    #[test]
    #[allow(clippy::many_single_char_names)]
    fn test_matmul_neon_small_fallback() {
        // Test matrices below NEON threshold (should use scalar)
        let m = 2;
        let k = 2;
        let n = 3;

        let a = vec![1.0f32, 2.0, 3.0, 4.0];
        let b = vec![1.0f32, 2.0, 3.0, 4.0, 5.0, 6.0];
        let mut c = vec![0.0f32; m * n];

        matmul_tiled(&a, &b, &mut c, m, k, n);

        // C[0,0] = 1*1 + 2*4 = 9
        // C[0,1] = 1*2 + 2*5 = 12
        // C[0,2] = 1*3 + 2*6 = 15
        // C[1,0] = 3*1 + 4*4 = 19
        // C[1,1] = 3*2 + 4*5 = 26
        // C[1,2] = 3*3 + 4*6 = 33
        let expected = [9.0, 12.0, 15.0, 19.0, 26.0, 33.0];
        for (r, e) in c.iter().zip(expected.iter()) {
            assert!((r - e).abs() < 1e-5);
        }
    }

    #[test]
    #[allow(clippy::many_single_char_names, clippy::cast_precision_loss)]
    fn test_matmul_neon_single_row() {
        // Edge case: m = 1 (single row)
        let m = 1;
        let k = 16;
        let n = 32;

        let a = vec![1.0f32; m * k];
        let b = vec![1.0f32; k * n];
        let mut c = vec![0.0f32; m * n];

        matmul_tiled(&a, &b, &mut c, m, k, n);

        // Each element should equal k
        for &r in &c {
            assert!((r - k as f32).abs() < 1e-4);
        }
    }

    #[test]
    #[allow(clippy::many_single_char_names, clippy::cast_precision_loss)]
    fn test_matmul_neon_single_col() {
        // Edge case: n = 1 (single column)
        let m = 32;
        let k = 16;
        let n = 1;

        let a = vec![1.0f32; m * k];
        let b = vec![1.0f32; k * n];
        let mut c = vec![0.0f32; m * n];

        matmul_tiled(&a, &b, &mut c, m, k, n);

        // Each element should equal k
        for &r in &c {
            assert!((r - k as f32).abs() < 1e-4);
        }
    }

    #[test]
    #[allow(clippy::many_single_char_names, clippy::cast_precision_loss)]
    fn test_matmul_neon_vs_scalar_consistency() {
        // Cross-verify NEON/AVX2 results match scalar implementation
        let m = 64;
        let k = 64;
        let n = 64;

        let a: Vec<f32> = (0..m * k).map(|i| (i % 10) as f32 / 10.0).collect();
        let b: Vec<f32> = (0..k * n).map(|i| (i % 7) as f32 / 7.0).collect();

        // Use matmul_tiled (may use SIMD)
        let mut c_simd = vec![0.0f32; m * n];
        matmul_tiled(&a, &b, &mut c_simd, m, k, n);

        // Compute scalar reference
        let mut c_scalar = vec![0.0f32; m * n];
        for i in 0..m {
            for j in 0..n {
                for l in 0..k {
                    c_scalar[i * n + j] += a[i * k + l] * b[l * n + j];
                }
            }
        }

        // Allow small floating-point tolerance
        for (i, (simd, scalar)) in c_simd.iter().zip(c_scalar.iter()).enumerate() {
            assert!(
                (simd - scalar).abs() < 1e-3,
                "mismatch at {i}: SIMD {simd}, scalar {scalar}"
            );
        }
    }

    #[test]
    fn test_matmul_packed_small() {
        // A = 2x3, B = 3x2, C = 2x2
        let a = vec![1.0f32, 2.0, 3.0, 4.0, 5.0, 6.0];
        let b = vec![7.0f32, 8.0, 9.0, 10.0, 11.0, 12.0];
        let mut c = vec![0.0f32; 4];

        matmul_tiled_packed(&a, &b, &mut c, 2, 3, 2);

        let expected = [58.0, 64.0, 139.0, 154.0];
        for (r, e) in c.iter().zip(expected.iter()) {
            assert!((r - e).abs() < 1e-5, "expected {e}, got {r}");
        }
    }

    #[test]
    #[allow(clippy::cast_precision_loss, clippy::many_single_char_names)]
    fn test_matmul_packed_vs_unpacked_consistency() {
        // Cross-verify packed and unpacked produce identical results
        let m = 100;
        let k = 100;
        let n = 100;

        let a: Vec<f32> = (0..m * k).map(|i| (i % 10) as f32 / 10.0).collect();
        let b: Vec<f32> = (0..k * n).map(|i| (i % 7) as f32 / 7.0).collect();

        let mut c_unpacked = vec![0.0f32; m * n];
        matmul_tiled(&a, &b, &mut c_unpacked, m, k, n);

        let mut c_packed = vec![0.0f32; m * n];
        matmul_tiled_packed(&a, &b, &mut c_packed, m, k, n);

        for (i, (packed, unpacked)) in c_packed.iter().zip(c_unpacked.iter()).enumerate() {
            assert!(
                (packed - unpacked).abs() < 1e-3,
                "mismatch at {i}: packed {packed}, unpacked {unpacked}"
            );
        }
    }

    #[test]
    #[allow(clippy::cast_precision_loss, clippy::many_single_char_names)]
    fn test_matmul_packed_large() {
        // Test with matrix larger than all tile sizes (MC=96, KC=256, NC=256)
        let m = 128;
        let k = 300;
        let n = 300;

        let a: Vec<f32> = (0..m * k)
            .map(|i| ((i * 7 + 3) % 100) as f32 / 100.0)
            .collect();
        let b: Vec<f32> = (0..k * n)
            .map(|i| ((i * 11 + 5) % 100) as f32 / 100.0)
            .collect();

        let mut c_packed = vec![0.0f32; m * n];
        matmul_tiled_packed(&a, &b, &mut c_packed, m, k, n);

        // Scalar reference
        let mut c_ref = vec![0.0f32; m * n];
        for i in 0..m {
            for j in 0..n {
                for l in 0..k {
                    c_ref[i * n + j] += a[i * k + l] * b[l * n + j];
                }
            }
        }

        for (i, (packed, reference)) in c_packed.iter().zip(c_ref.iter()).enumerate() {
            assert!(
                (packed - reference).abs() < 1e-1,
                "mismatch at {i}: packed {packed}, reference {reference}"
            );
        }
    }
}
