use criterion::{black_box, criterion_group, criterion_main, Criterion, Throughput};

const ISA_SHELL: &str = r#"
shell isa {
    group lut_activation(dst: buf, src: buf, count: usize) @suffix("LUT") {
        sigmoid = SIGMOID_256,
        tanh    = TANH_256,
        relu    = RELU_256,
        gelu    = GELU_256,
        silu    = SILU_256,
        swish   = SWISH_256
    }

    group binary_elementwise(dst: buf, a: buf, b: buf, count: usize) {
        add, sub, mul
    }

    op matmul(c: buf, a: buf, b: buf, m: usize, k: usize, n: usize)

    op conv2d(
        dst: buf, input: buf, weight: buf, bias: buf? = none,
        @pair kernel(kernel_h: usize = 3, kernel_w: usize = 3),
        @pair stride(stride_h: usize = 1, stride_w: usize = 1),
        @pair padding(pad_h: usize = 0, pad_w: usize = 0),
        @pair dilation(dilation_h: usize = 1, dilation_w: usize = 1),
        groups: usize = 1,
        @group input_shape(batch: usize, in_channels: usize, in_h: usize, in_w: usize),
        @group output_shape(out_channels: usize, out_h: usize, out_w: usize)
    ) @builder

    op softmax(dst: buf, src: buf, outer_size: usize, axis_size: usize, inner_size: usize)

    op transpose(dst: buf, src: buf, count: usize, ndim: u8, shape: [usize; 8], perm: [u8; 8])

    compose standard_normalize = [sigmoid, tanh, relu]
}
"#;

const DATUM_SHAPES_TTL: &str = include_str!("../../../descriptors/shacl/datum-shapes.ttl");

// Real shell files
const REAL_ISA: &str = include_str!("../../../descriptors/shells/isa.shell");
const REAL_DATUM: &str = include_str!("../../../descriptors/shells/datum.shell");
const REAL_RING: &str = include_str!("../../../descriptors/shells/ring.shell");
const REAL_ACTIVATION: &str = include_str!("../../../descriptors/shells/activation.shell");
const REAL_OBSERVABLE: &str = include_str!("../../../descriptors/shells/observable.shell");

// ============================================================================
// Parse benchmarks: inline snippet
// ============================================================================

fn bench_parse_inline(c: &mut Criterion) {
    let mut group = c.benchmark_group("parse");
    group.throughput(Throughput::Bytes(ISA_SHELL.len() as u64));

    group.bench_function("isa_shell", |b| {
        b.iter(|| {
            black_box(hologram_shell::parse_shell(black_box(ISA_SHELL)).unwrap());
        });
    });

    group.finish();
}

fn bench_parse_shacl(c: &mut Criterion) {
    let mut group = c.benchmark_group("parse_shacl");
    group.throughput(Throughput::Bytes(DATUM_SHAPES_TTL.len() as u64));

    group.bench_function("datum_shapes", |b| {
        b.iter(|| {
            black_box(
                hologram_shell::parse_shacl::parse_shacl_file(black_box(DATUM_SHAPES_TTL)).unwrap(),
            );
        });
    });

    group.finish();
}

// ============================================================================
// Parse benchmarks: real shell files
// ============================================================================

fn bench_parse_real(c: &mut Criterion) {
    let mut group = c.benchmark_group("parse_real");

    let files: &[(&str, &str)] = &[
        ("isa_shell", REAL_ISA),
        ("datum_shell", REAL_DATUM),
        ("ring_shell", REAL_RING),
        ("activation_shell", REAL_ACTIVATION),
        ("observable_shell", REAL_OBSERVABLE),
    ];

    for (name, source) in files {
        group.throughput(Throughput::Bytes(source.len() as u64));
        group.bench_function(*name, |b| {
            b.iter(|| {
                black_box(hologram_shell::parse_shell(black_box(source)).unwrap());
            });
        });
    }

    group.finish();
}

// ============================================================================
// Emit ISA benchmarks
// ============================================================================

fn bench_emit_isa(c: &mut Criterion) {
    let mut group = c.benchmark_group("emit_isa");
    let shell = hologram_shell::parse_shell(REAL_ISA).unwrap();

    group.throughput(Throughput::Elements(1));

    group.bench_function("instruction_enum", |b| {
        b.iter(|| {
            black_box(hologram_shell::emit_isa::emit_instruction_enum(black_box(
                &shell,
            )));
        });
    });

    group.bench_function("dispatcher_trait", |b| {
        b.iter(|| {
            black_box(hologram_shell::emit_isa::emit_dispatcher_trait(black_box(
                &shell,
            )));
        });
    });

    group.bench_function("execute_on", |b| {
        b.iter(|| {
            black_box(hologram_shell::emit_isa::emit_execute_on(black_box(&shell)));
        });
    });

    group.finish();
}

// ============================================================================
// Emit query benchmarks
// ============================================================================

fn bench_emit_query(c: &mut Criterion) {
    let mut group = c.benchmark_group("emit_query");

    let shells: &[(&str, &str)] = &[
        ("datum_all", REAL_DATUM),
        ("ring_all", REAL_RING),
        ("activation_all", REAL_ACTIVATION),
        ("observable_all", REAL_OBSERVABLE),
    ];

    group.throughput(Throughput::Elements(1));

    for (name, source) in shells {
        let shell = hologram_shell::parse_shell(source).unwrap();
        group.bench_function(*name, |b| {
            b.iter(|| {
                black_box(hologram_shell::emit_query::emit_all(black_box(&shell)));
            });
        });
    }

    group.finish();
}

criterion_group!(
    benches,
    bench_parse_inline,
    bench_parse_shacl,
    bench_parse_real,
    bench_emit_isa,
    bench_emit_query,
);
criterion_main!(benches);
