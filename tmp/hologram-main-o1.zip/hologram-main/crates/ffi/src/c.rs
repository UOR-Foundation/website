//! C bindings via cbindgen.
//!
//! This module provides a C-compatible FFI interface for UOR.
//! All functions are `extern "C"` with `#[no_mangle]` for C linkage.
//!
//! # Memory Management
//!
//! - Strings returned by `uor_*` functions must be freed with `uor_string_free()`
//! - Views created with `uor_view_*` must be freed with `uor_view_free()`
//! - Byte arrays allocated by the library must be freed appropriately
//!
//! # Safety
//!
//! All functions are marked `unsafe` because they cross the FFI boundary.
//! Callers must ensure:
//! - Pointers are valid and properly aligned
//! - Memory is not freed multiple times
//! - Concurrent access is properly synchronized

use std::ffi::CString;
use std::os::raw::{c_char, c_uchar};
use std::ptr;

use crate::core::{
    byte_not, byte_pred, byte_rank, byte_succ, byte_to_braille, byte_to_codepoint, byte_to_domain,
    FfiState, FfiView,
};

// ============================================================================
// OPAQUE TYPES
// ============================================================================

/// Opaque handle to a UOR view (256-byte lookup table)
#[repr(C)]
pub struct UorView {
    _private: [u8; 0],
}

/// Opaque handle to a UOR state (624 taxons = 4992 bits)
#[repr(C)]
pub struct UorState {
    _private: [u8; 0],
}

// ============================================================================
// TAXON OPERATIONS
// ============================================================================

/// Get Braille character for a byte value (bijective mapping).
///
/// Returns a NUL-terminated UTF-8 string that must be freed with `uor_string_free()`.
///
/// # Safety
///
/// The returned pointer must be freed exactly once with `uor_string_free()`.
#[no_mangle]
pub unsafe extern "C" fn uor_byte_to_braille(value: c_uchar) -> *mut c_char {
    let braille = byte_to_braille(value);
    match CString::new(braille) {
        Ok(s) => s.into_raw(),
        Err(_) => ptr::null_mut(),
    }
}

/// Get Unicode codepoint for a byte value.
#[no_mangle]
pub extern "C" fn uor_byte_to_codepoint(value: c_uchar) -> u32 {
    byte_to_codepoint(value)
}

/// Get triadic domain for a byte value (0=Theta, 1=Psi, 2=Delta).
#[no_mangle]
pub extern "C" fn uor_byte_to_domain(value: c_uchar) -> c_uchar {
    byte_to_domain(value)
}

/// Get rank within domain for a byte value.
#[no_mangle]
pub extern "C" fn uor_byte_rank(value: c_uchar) -> c_uchar {
    byte_rank(value)
}

// ============================================================================
// RING OPERATIONS
// ============================================================================

/// Get successor in ring.
#[no_mangle]
pub extern "C" fn uor_byte_succ(value: c_uchar) -> c_uchar {
    byte_succ(value)
}

/// Get predecessor in ring.
#[no_mangle]
pub extern "C" fn uor_byte_pred(value: c_uchar) -> c_uchar {
    byte_pred(value)
}

/// Bitwise NOT.
#[no_mangle]
pub extern "C" fn uor_byte_not(value: c_uchar) -> c_uchar {
    byte_not(value)
}

// ============================================================================
// VIEW OPERATIONS
// ============================================================================

/// Create an identity view.
///
/// Must be freed with `uor_view_free()`.
///
/// # Safety
///
/// The returned pointer must be freed exactly once with `uor_view_free()`.
#[no_mangle]
pub unsafe extern "C" fn uor_view_identity() -> *mut UorView {
    let view = Box::new(FfiView::identity());
    Box::into_raw(view) as *mut UorView
}

/// Create a constant view (all inputs map to the same output).
///
/// Returns NULL if the value is invalid.
/// Must be freed with `uor_view_free()`.
///
/// # Safety
///
/// The returned pointer must be freed exactly once with `uor_view_free()`.
#[no_mangle]
pub unsafe extern "C" fn uor_view_constant(value: c_uchar) -> *mut UorView {
    match FfiView::constant(value) {
        Ok(view) => {
            let boxed = Box::new(view);
            Box::into_raw(boxed) as *mut UorView
        }
        Err(_) => ptr::null_mut(),
    }
}

/// Apply a view to a single byte.
///
/// # Safety
///
/// `view` must be a valid pointer returned by `uor_view_*` functions.
#[no_mangle]
pub unsafe extern "C" fn uor_view_apply(view: *const UorView, byte_value: c_uchar) -> c_uchar {
    if view.is_null() {
        return 0;
    }
    let view = &*(view as *const FfiView);
    view.apply(byte_value)
}

/// Apply a view to a byte array.
///
/// # Safety
///
/// - `view` must be a valid pointer
/// - `input` must point to at least `input_len` valid bytes
/// - `output` must point to at least `input_len` bytes of writable memory
#[no_mangle]
pub unsafe extern "C" fn uor_view_apply_slice(
    view: *const UorView,
    input: *const c_uchar,
    input_len: usize,
    output: *mut c_uchar,
) {
    if view.is_null() || input.is_null() || output.is_null() {
        return;
    }

    let view = &*(view as *const FfiView);
    let input_slice = std::slice::from_raw_parts(input, input_len);
    let result = view.apply_slice(input_slice.to_vec());

    let output_slice = std::slice::from_raw_parts_mut(output, input_len);
    output_slice.copy_from_slice(&result);
}

/// Check if a view is bijective (1-to-1 mapping).
///
/// # Safety
///
/// `view` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_view_is_bijective(view: *const UorView) -> bool {
    if view.is_null() {
        return false;
    }
    let view = &*(view as *const FfiView);
    view.is_bijective()
}

/// Get the inverse of a bijective view.
///
/// Returns NULL if the view is not bijective.
/// Must be freed with `uor_view_free()`.
///
/// # Safety
///
/// - `view` must be a valid pointer
/// - The returned pointer must be freed exactly once with `uor_view_free()`.
#[no_mangle]
pub unsafe extern "C" fn uor_view_inverse(view: *const UorView) -> *mut UorView {
    if view.is_null() {
        return ptr::null_mut();
    }

    let view = &*(view as *const FfiView);
    match view.inverse() {
        Ok(inv) => {
            let inv = (*inv).clone();
            let boxed = Box::new(inv);
            Box::into_raw(boxed) as *mut UorView
        }
        Err(_) => ptr::null_mut(),
    }
}

/// Compose two views: result[x] = other[self[x]].
///
/// Must be freed with `uor_view_free()`.
///
/// # Safety
///
/// - Both `self_view` and `other_view` must be valid pointers
/// - The returned pointer must be freed exactly once with `uor_view_free()`.
#[no_mangle]
pub unsafe extern "C" fn uor_view_then(
    self_view: *const UorView,
    other_view: *const UorView,
) -> *mut UorView {
    if self_view.is_null() || other_view.is_null() {
        return ptr::null_mut();
    }

    let self_view = &*(self_view as *const FfiView);
    let other_view = &*(other_view as *const FfiView);

    let composed =
        std::sync::Arc::new(self_view.clone()).then(std::sync::Arc::new(other_view.clone()));
    let boxed = Box::new((*composed).clone());
    Box::into_raw(boxed) as *mut UorView
}

/// Free a view created by `uor_view_*` functions.
///
/// # Safety
///
/// - `view` must be a valid pointer returned by a `uor_view_*` function
/// - `view` must not be used after this call
/// - `view` must not be freed more than once
#[no_mangle]
pub unsafe extern "C" fn uor_view_free(view: *mut UorView) {
    if !view.is_null() {
        let _ = Box::from_raw(view as *mut FfiView);
    }
}

// ============================================================================
// STATE OPERATIONS
// ============================================================================

/// Create a zero-initialized state (624 taxons).
///
/// Must be freed with `uor_state_free()`.
///
/// # Safety
///
/// The returned pointer must be freed exactly once with `uor_state_free()`.
#[no_mangle]
pub unsafe extern "C" fn uor_state_new() -> *mut UorState {
    let state = Box::new(FfiState::new());
    Box::into_raw(state) as *mut UorState
}

/// Create a state from a byte array.
///
/// Returns NULL if `data_len` is not 624.
/// Must be freed with `uor_state_free()`.
///
/// # Safety
///
/// - `data` must point to at least `data_len` valid bytes
/// - The returned pointer must be freed exactly once with `uor_state_free()`.
#[no_mangle]
pub unsafe extern "C" fn uor_state_from_bytes(
    data: *const c_uchar,
    data_len: usize,
) -> *mut UorState {
    if data.is_null() || data_len != 624 {
        return ptr::null_mut();
    }

    let data_slice = std::slice::from_raw_parts(data, data_len);
    match FfiState::from_bytes(data_slice.to_vec()) {
        Ok(state) => {
            let boxed = Box::new(state);
            Box::into_raw(boxed) as *mut UorState
        }
        Err(_) => ptr::null_mut(),
    }
}

/// Copy state bytes to output buffer.
///
/// # Safety
///
/// - `state` must be a valid pointer
/// - `output` must point to at least 624 bytes of writable memory
#[no_mangle]
pub unsafe extern "C" fn uor_state_to_bytes(state: *const UorState, output: *mut c_uchar) {
    if state.is_null() || output.is_null() {
        return;
    }

    let state = &*(state as *const FfiState);
    let bytes = state.as_bytes();
    let output_slice = std::slice::from_raw_parts_mut(output, 624);
    output_slice.copy_from_slice(&bytes);
}

/// Get a taxon value at index.
///
/// Returns 0 if state is NULL or index is out of bounds.
///
/// # Safety
///
/// `state` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_state_get_taxon(state: *const UorState, index: usize) -> c_uchar {
    if state.is_null() || index >= 624 {
        return 0;
    }
    let state = &*(state as *const FfiState);
    state.get_taxon(index).unwrap_or(0)
}

/// Set a taxon value at index.
///
/// Does nothing if state is NULL or index is out of bounds.
///
/// # Safety
///
/// `state` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_state_set_taxon(state: *mut UorState, index: usize, value: c_uchar) {
    if state.is_null() || index >= 624 {
        return;
    }
    let state = &mut *(state as *mut FfiState);
    let _ = state.set_taxon(index, value);
}

/// Check if state is all zeros.
///
/// # Safety
///
/// `state` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_state_is_zero(state: *const UorState) -> bool {
    if state.is_null() {
        return false;
    }
    let state = &*(state as *const FfiState);
    state.is_zero()
}

/// Free a state created by `uor_state_*` functions.
///
/// # Safety
///
/// - `state` must be a valid pointer returned by a `uor_state_*` function
/// - `state` must not be used after this call
/// - `state` must not be freed more than once
#[no_mangle]
pub unsafe extern "C" fn uor_state_free(state: *mut UorState) {
    if !state.is_null() {
        let _ = Box::from_raw(state as *mut FfiState);
    }
}

// ============================================================================
// CONSTANTS
// ============================================================================

/// Get Braille base codepoint (U+2800).
#[no_mangle]
pub extern "C" fn uor_braille_base() -> u32 {
    crate::core::braille_base()
}

/// Get Braille max codepoint (U+28FF).
#[no_mangle]
pub extern "C" fn uor_braille_max() -> u32 {
    crate::core::braille_max()
}

/// Get triadic constant (T = 3).
#[no_mangle]
pub extern "C" fn uor_triadic_constant() -> c_uchar {
    crate::core::triadic_constant()
}

/// Get octave constant (O = 8).
#[no_mangle]
pub extern "C" fn uor_octave_constant() -> c_uchar {
    crate::core::octave_constant()
}

/// Get state taxon count (624).
#[no_mangle]
pub extern "C" fn uor_state_taxons() -> u16 {
    crate::core::state_taxons()
}

/// Get state bit count (4992).
#[no_mangle]
pub extern "C" fn uor_state_bits() -> u16 {
    crate::core::state_bits()
}

// ============================================================================
// LUT Q0 OBSERVABLE FUNCTIONS
// ============================================================================

/// O(1) stratum (Hamming weight) for a byte value.
#[no_mangle]
pub extern "C" fn uor_stratum_q0(value: c_uchar) -> c_uchar {
    crate::lut::stratum_q0(value)
}

/// O(1) curvature (cascade length) for a byte value.
#[no_mangle]
pub extern "C" fn uor_curvature_q0(value: c_uchar) -> c_uchar {
    crate::lut::curvature_q0(value)
}

/// O(1) domain (mod 3) for a byte value.
#[no_mangle]
pub extern "C" fn uor_domain_q0(value: c_uchar) -> c_uchar {
    crate::lut::domain_q0(value)
}

/// O(1) rank (div 3) for a byte value.
#[no_mangle]
pub extern "C" fn uor_rank_q0(value: c_uchar) -> c_uchar {
    crate::lut::rank_q0(value)
}

/// O(1) orbit class (div 8) for a byte value.
#[no_mangle]
pub extern "C" fn uor_orbit_class_q0(value: c_uchar) -> c_uchar {
    crate::lut::orbit_class_q0(value)
}

/// O(1) torus page index for a byte value.
#[no_mangle]
pub extern "C" fn uor_torus_page_q0(value: c_uchar) -> c_uchar {
    crate::lut::torus_page_q0(value)
}

/// O(1) torus offset within page pair.
#[no_mangle]
pub extern "C" fn uor_torus_offset_q0(value: c_uchar) -> c_uchar {
    crate::lut::torus_offset_q0(value)
}

// ============================================================================
// LUT ACTIVATION FUNCTIONS
// ============================================================================

/// O(1) sigmoid lookup.
#[no_mangle]
pub extern "C" fn uor_sigmoid_lut(value: c_uchar) -> c_uchar {
    crate::lut::sigmoid_lut(value)
}

/// O(1) tanh lookup.
#[no_mangle]
pub extern "C" fn uor_tanh_lut(value: c_uchar) -> c_uchar {
    crate::lut::tanh_lut(value)
}

/// O(1) ReLU lookup.
#[no_mangle]
pub extern "C" fn uor_relu_lut(value: c_uchar) -> c_uchar {
    crate::lut::relu_lut(value)
}

/// O(1) exp lookup.
#[no_mangle]
pub extern "C" fn uor_exp_lut(value: c_uchar) -> c_uchar {
    crate::lut::exp_lut(value)
}

/// O(1) log lookup.
#[no_mangle]
pub extern "C" fn uor_log_lut(value: c_uchar) -> c_uchar {
    crate::lut::log_lut(value)
}

/// O(1) sqrt lookup.
#[no_mangle]
pub extern "C" fn uor_sqrt_lut(value: c_uchar) -> c_uchar {
    crate::lut::sqrt_lut(value)
}

/// O(1) abs lookup.
#[no_mangle]
pub extern "C" fn uor_abs_lut(value: c_uchar) -> c_uchar {
    crate::lut::abs_lut(value)
}

/// O(1) GELU lookup.
#[no_mangle]
pub extern "C" fn uor_gelu_lut(value: c_uchar) -> c_uchar {
    crate::lut::gelu_lut(value)
}

/// O(1) SiLU (Swish) lookup.
#[no_mangle]
pub extern "C" fn uor_silu_lut(value: c_uchar) -> c_uchar {
    crate::lut::silu_lut(value)
}

// ============================================================================
// LUT Q1 FUNCTIONS
// ============================================================================

/// O(1) stratum for Q1 (16-bit).
#[no_mangle]
pub extern "C" fn uor_stratum_q1(value: u16) -> c_uchar {
    crate::lut::stratum_q1(value)
}

/// O(1) curvature for Q1 (16-bit).
#[no_mangle]
pub extern "C" fn uor_curvature_q1(value: u16) -> c_uchar {
    crate::lut::curvature_q1(value)
}

// ============================================================================
// WORD OPERATIONS
// ============================================================================

/// Create a Word2 from a u16 value.
///
/// Must be freed with `uor_word2_free()`.
///
/// # Safety
///
/// The returned pointer must be freed exactly once.
#[no_mangle]
pub unsafe extern "C" fn uor_word2_new(value: u16) -> *mut crate::word::FfiWord2 {
    Box::into_raw(Box::new(crate::word::FfiWord2::new(value)))
}

/// Get the u16 value of a Word2.
///
/// # Safety
///
/// `word` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_word2_value(word: *const crate::word::FfiWord2) -> u16 {
    if word.is_null() {
        return 0;
    }
    (*word).value()
}

/// Get a taxon byte from a Word2.
///
/// Returns 0 if word is NULL or index is out of bounds.
///
/// # Safety
///
/// `word` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_word2_taxon(
    word: *const crate::word::FfiWord2,
    index: usize,
) -> c_uchar {
    if word.is_null() {
        return 0;
    }
    (*word).taxon(index as u32).unwrap_or(0)
}

/// Check if a Word2 is zero.
///
/// # Safety
///
/// `word` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_word2_is_zero(word: *const crate::word::FfiWord2) -> bool {
    if word.is_null() {
        return false;
    }
    (*word).is_zero()
}

/// Free a Word2.
///
/// # Safety
///
/// `word` must have been created by `uor_word2_new()`.
#[no_mangle]
pub unsafe extern "C" fn uor_word2_free(word: *mut crate::word::FfiWord2) {
    if !word.is_null() {
        let _ = Box::from_raw(word);
    }
}

/// Create a Word4 from a u32 value.
///
/// Must be freed with `uor_word4_free()`.
///
/// # Safety
///
/// The returned pointer must be freed exactly once.
#[no_mangle]
pub unsafe extern "C" fn uor_word4_new(value: u32) -> *mut crate::word::FfiWord4 {
    Box::into_raw(Box::new(crate::word::FfiWord4::new(value)))
}

/// Get the u32 value of a Word4.
///
/// # Safety
///
/// `word` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_word4_value(word: *const crate::word::FfiWord4) -> u32 {
    if word.is_null() {
        return 0;
    }
    (*word).value()
}

/// Get a taxon byte from a Word4.
///
/// # Safety
///
/// `word` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_word4_taxon(
    word: *const crate::word::FfiWord4,
    index: usize,
) -> c_uchar {
    if word.is_null() {
        return 0;
    }
    (*word).taxon(index as u32).unwrap_or(0)
}

/// Check if a Word4 is zero.
///
/// # Safety
///
/// `word` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_word4_is_zero(word: *const crate::word::FfiWord4) -> bool {
    if word.is_null() {
        return false;
    }
    (*word).is_zero()
}

/// Free a Word4.
///
/// # Safety
///
/// `word` must have been created by `uor_word4_new()`.
#[no_mangle]
pub unsafe extern "C" fn uor_word4_free(word: *mut crate::word::FfiWord4) {
    if !word.is_null() {
        let _ = Box::from_raw(word);
    }
}

/// Create a Word8 from a u64 value.
///
/// Must be freed with `uor_word8_free()`.
///
/// # Safety
///
/// The returned pointer must be freed exactly once.
#[no_mangle]
pub unsafe extern "C" fn uor_word8_new(value: u64) -> *mut crate::word::FfiWord8 {
    Box::into_raw(Box::new(crate::word::FfiWord8::new(value)))
}

/// Get the u64 value of a Word8.
///
/// # Safety
///
/// `word` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_word8_value(word: *const crate::word::FfiWord8) -> u64 {
    if word.is_null() {
        return 0;
    }
    (*word).value()
}

/// Get a taxon byte from a Word8.
///
/// # Safety
///
/// `word` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_word8_taxon(
    word: *const crate::word::FfiWord8,
    index: usize,
) -> c_uchar {
    if word.is_null() {
        return 0;
    }
    (*word).taxon(index as u32).unwrap_or(0)
}

/// Check if a Word8 is zero.
///
/// # Safety
///
/// `word` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_word8_is_zero(word: *const crate::word::FfiWord8) -> bool {
    if word.is_null() {
        return false;
    }
    (*word).is_zero()
}

/// Free a Word8.
///
/// # Safety
///
/// `word` must have been created by `uor_word8_new()`.
#[no_mangle]
pub unsafe extern "C" fn uor_word8_free(word: *mut crate::word::FfiWord8) {
    if !word.is_null() {
        let _ = Box::from_raw(word);
    }
}

// ============================================================================
// DATUM16 OPERATIONS
// ============================================================================

/// Create a Datum16 from a u16 value.
///
/// Must be freed with `uor_datum16_free()`.
///
/// # Safety
///
/// The returned pointer must be freed exactly once.
#[no_mangle]
pub unsafe extern "C" fn uor_datum16_new(value: u16) -> *mut crate::datum::FfiDatum16 {
    Box::into_raw(Box::new(crate::datum::FfiDatum16::new(value)))
}

/// Get the u16 value of a Datum16.
///
/// # Safety
///
/// `datum` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_datum16_value(datum: *const crate::datum::FfiDatum16) -> u16 {
    if datum.is_null() {
        return 0;
    }
    (*datum).value()
}

/// Get the stratum (Hamming weight) of a Datum16.
///
/// # Safety
///
/// `datum` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_datum16_stratum(datum: *const crate::datum::FfiDatum16) -> c_uchar {
    if datum.is_null() {
        return 0;
    }
    (*datum).stratum()
}

/// Get the curvature of a Datum16.
///
/// # Safety
///
/// `datum` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_datum16_curvature(datum: *const crate::datum::FfiDatum16) -> c_uchar {
    if datum.is_null() {
        return 0;
    }
    (*datum).curvature()
}

/// Free a Datum16.
///
/// # Safety
///
/// `datum` must have been created by `uor_datum16_new()`.
#[no_mangle]
pub unsafe extern "C" fn uor_datum16_free(datum: *mut crate::datum::FfiDatum16) {
    if !datum.is_null() {
        let _ = Box::from_raw(datum);
    }
}

/// Create a Datum16Proof from a u16 value.
///
/// Must be freed with `uor_datum16_proof_free()`.
///
/// # Safety
///
/// The returned pointer must be freed exactly once.
#[no_mangle]
pub unsafe extern "C" fn uor_datum16_proof_new(value: u16) -> *mut crate::datum::FfiDatum16Proof {
    Box::into_raw(Box::new(crate::datum::FfiDatum16Proof::from_datum(value)))
}

/// Check if a Datum16Proof is valid (all observables verified).
///
/// # Safety
///
/// `proof` must be a valid pointer.
#[no_mangle]
pub unsafe extern "C" fn uor_datum16_proof_is_valid(
    proof: *const crate::datum::FfiDatum16Proof,
) -> bool {
    if proof.is_null() {
        return false;
    }
    (*proof).is_valid()
}

/// Free a Datum16Proof.
///
/// # Safety
///
/// `proof` must have been created by `uor_datum16_proof_new()`.
#[no_mangle]
pub unsafe extern "C" fn uor_datum16_proof_free(proof: *mut crate::datum::FfiDatum16Proof) {
    if !proof.is_null() {
        let _ = Box::from_raw(proof);
    }
}

// ============================================================================
// MEMORY MANAGEMENT
// ============================================================================

/// Free a string returned by `uor_byte_to_braille()`.
///
/// # Safety
///
/// - `s` must be a valid pointer returned by a UOR function
/// - `s` must not be used after this call
/// - `s` must not be freed more than once
#[no_mangle]
pub unsafe extern "C" fn uor_string_free(s: *mut c_char) {
    if !s.is_null() {
        let _ = CString::from_raw(s);
    }
}
