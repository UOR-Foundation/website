//! Integration tests for the schema server API.

use hologram_schema_server::schema::{load_schemas, SchemaStore};
use hologram_schema_server::Config;
use std::path::PathBuf;

fn test_config() -> Config {
    // Use workspace root from environment or assume we're in workspace
    let workspace_root = std::env::var("CARGO_MANIFEST_DIR")
        .map(PathBuf::from)
        .map(|p| p.parent().unwrap().parent().unwrap().to_path_buf())
        .unwrap_or_else(|_| PathBuf::from("."));

    Config::new(3001, workspace_root)
}

fn test_store() -> SchemaStore {
    let config = test_config();
    let loaded = load_schemas(&config).expect("Failed to load schemas");
    SchemaStore::new(loaded)
}

#[test]
fn test_list_schemas() {
    let store = test_store();
    let schemas = store.list_schemas();
    assert_eq!(schemas.len(), 4);
    assert!(schemas.iter().any(|s| s.id == "uor"));
    assert!(schemas.iter().any(|s| s.id == "catalog"));
    assert!(schemas.iter().any(|s| s.id == "hologram"));
}

#[test]
fn test_get_schema() {
    let store = test_store();
    assert!(store.get_schema("uor").is_ok());
    assert!(store.get_schema("hologram").is_ok());
    assert!(store.get_schema("nonexistent").is_err());
}

#[test]
fn test_list_taxons() {
    let store = test_store();
    let response = store.list_taxons(0, 50);
    assert_eq!(response.total, 256);
    assert_eq!(response.items.len(), 50);
    assert_eq!(response.offset, 0);
    assert_eq!(response.limit, 50);
}

#[test]
fn test_get_taxon() {
    let store = test_store();

    // First taxon
    let t0 = store.get_taxon(0).expect("Taxon 0 should exist");
    assert_eq!(t0.value, 0);
    assert_eq!(t0.codepoint, 10240); // U+2800
    assert_eq!(t0.domain, "Theta");

    // Last taxon
    let t255 = store.get_taxon(255).expect("Taxon 255 should exist");
    assert_eq!(t255.value, 255);
    assert_eq!(t255.codepoint, 10495); // U+28FF

    // Invalid taxon (actually all 0-255 are valid, but check error handling)
    // All values 0-255 should exist
}

#[test]
fn test_get_taxons_by_domain() {
    let store = test_store();

    let theta = store
        .get_taxons_by_domain("Theta")
        .expect("Theta domain should exist");
    assert!(!theta.is_empty());
    assert!(theta.iter().all(|t| t.domain == "Theta"));

    let psi = store
        .get_taxons_by_domain("Psi")
        .expect("Psi domain should exist");
    assert!(!psi.is_empty());
    assert!(psi.iter().all(|t| t.domain == "Psi"));

    let delta = store
        .get_taxons_by_domain("Delta")
        .expect("Delta domain should exist");
    assert!(!delta.is_empty());
    assert!(delta.iter().all(|t| t.domain == "Delta"));

    // Total should be 256
    assert_eq!(theta.len() + psi.len() + delta.len(), 256);
}

#[test]
fn test_list_domains() {
    let store = test_store();
    let domains = store.list_domains();
    assert_eq!(domains.len(), 3);

    let names: Vec<_> = domains.iter().map(|d| d.name.as_str()).collect();
    assert!(names.contains(&"Theta"));
    assert!(names.contains(&"Psi"));
    assert!(names.contains(&"Delta"));
}

#[test]
fn test_list_constants() {
    let store = test_store();
    let constants = store.list_constants();

    // Should have at least the core constants
    let names: Vec<_> = constants.iter().map(|c| c.name.as_str()).collect();
    assert!(names.contains(&"U"));
    assert!(names.contains(&"D"));
    assert!(names.contains(&"T"));
    assert!(names.contains(&"O"));
    assert!(names.contains(&"B"));
    assert!(names.contains(&"R"));
}

#[test]
fn test_get_constant() {
    let store = test_store();

    let t = store.get_constant("T").expect("T should exist");
    assert_eq!(t.value, 3);
    assert!(!t.derived_from.is_empty() || t.formula.is_some());

    let o = store.get_constant("O").expect("O should exist");
    assert_eq!(o.value, 8);

    let u = store.get_constant("U").expect("U should exist");
    assert_eq!(u.value, 1);
    assert!(!u.is_mutable); // U is immutable
}

#[test]
fn test_constant_mutability() {
    let store = test_store();

    // U and D are immutable
    let u = store.get_constant("U").unwrap();
    assert!(!u.is_mutable);

    let d = store.get_constant("D").unwrap();
    assert!(!d.is_mutable);

    // T, O, B, R are mutable
    let t = store.get_constant("T").unwrap();
    assert!(t.is_mutable);
}

#[test]
fn test_gauge_tower() {
    let store = test_store();
    let tower = store.get_gauge_tower();

    assert!(!tower.levels.is_empty());
    assert!(tower.levels.len() >= 6);

    // Check base level
    let base = &tower.levels[0];
    assert_eq!(base.index, 0);
    assert_eq!(base.modulus, 96); // T * B = 3 * 32
    assert_eq!(base.boundary, 12_288);
}

#[test]
fn test_get_gauge_level() {
    let store = test_store();

    let level0 = store.get_gauge_level(0).expect("Level 0 should exist");
    assert_eq!(level0.modulus, 96);

    let level1 = store.get_gauge_level(1).expect("Level 1 should exist");
    assert_eq!(level1.modulus, 480);

    // Out of bounds
    assert!(store.get_gauge_level(100).is_err());
}

#[test]
fn test_preview_mutation() {
    let store = test_store();

    // Preview changing T (should show cascade effects)
    let preview = store.preview_mutation("T", 4).expect("Preview should work");
    assert_eq!(preview.target, "T");
    assert_eq!(preview.old_value, 3);
    assert_eq!(preview.new_value, 4);
    // Cascade should affect B and R
    assert!(!preview.cascade.is_empty());
}

#[test]
fn test_update_constant() {
    let store = test_store();

    // Update T
    let preview = store.update_constant("T", 4).expect("Update should work");
    assert_eq!(preview.new_value, 4);

    // Verify the change persisted
    let t = store.get_constant("T").unwrap();
    assert_eq!(t.value, 4);

    // Reset and verify
    store.reset_constants();
    let t = store.get_constant("T").unwrap();
    assert_eq!(t.value, 3);
}

#[test]
fn test_immutable_constant_update() {
    let store = test_store();

    // Trying to update U should fail
    let result = store.update_constant("U", 2);
    assert!(result.is_err());
}

#[test]
fn test_validation() {
    use hologram_schema_server::schema::validation::validate_constant_mutation;

    // U and D are immutable
    assert!(validate_constant_mutation("U", 2).is_err());
    assert!(validate_constant_mutation("D", 3).is_err());

    // T must be 1-10
    assert!(validate_constant_mutation("T", 3).is_ok());
    assert!(validate_constant_mutation("T", 0).is_err());
    assert!(validate_constant_mutation("T", 11).is_err());

    // B must be power of 2
    assert!(validate_constant_mutation("B", 32).is_ok());
    assert!(validate_constant_mutation("B", 64).is_ok());
    assert!(validate_constant_mutation("B", 3).is_err());
}

// ============================================================================
// Query-layer (generated resolver) tests
// ============================================================================

#[test]
fn test_byte_dto_resolve() {
    use hologram_schema_server::generated::ByteDto;

    let dto = ByteDto::resolve(42);
    assert_eq!(dto.value, 42);
    assert_eq!(dto.stratum, uor::lut::stratum_q0(42));
    assert_eq!(dto.curvature, uor::lut::curvature_q0(42));
    assert_eq!(dto.domain, uor::lut::domain_q0(42));
    assert_eq!(dto.rank, uor::lut::rank_q0(42));
    assert_eq!(dto.orbit_class, uor::lut::orbit_class_q0(42));
    assert_eq!(dto.torus.page, uor::lut::torus_page_q0(42));
    assert_eq!(dto.torus.offset, uor::lut::torus_offset_q0(42));
}

#[test]
fn test_byte_dto_boundaries() {
    use hologram_schema_server::generated::ByteDto;

    // Min
    let d0 = ByteDto::resolve(0);
    assert_eq!(d0.value, 0);
    assert_eq!(d0.stratum, uor::lut::stratum_q0(0));

    // Max
    let d255 = ByteDto::resolve(255);
    assert_eq!(d255.value, 255);
    assert_eq!(d255.stratum, uor::lut::stratum_q0(255));
}

#[test]
fn test_element_dto_resolve() {
    use hologram_schema_server::generated::ElementDto;

    let dto = ElementDto::resolve(50);
    assert_eq!(dto.value, 50);
}

#[test]
fn test_element_resolver_operations() {
    use hologram_schema_server::generated::{ElementResolver, LutElementResolver};

    let r = LutElementResolver;
    assert_eq!(r.add(10, 20), uor::lut::byte_add(10, 20));
    assert_eq!(r.sub(50, 30), uor::lut::byte_sub(50, 30));
    assert_eq!(r.mul(6, 7), uor::lut::byte_mul(6, 7));
}

#[test]
fn test_element_resolver_mod_wrapping() {
    use hologram_schema_server::generated::{ElementResolver, LutElementResolver};

    let r = LutElementResolver;
    assert_eq!(r.add(100, 200), uor::lut::byte_add(100, 200));
    assert_eq!(r.sub(150, 100), uor::lut::byte_sub(150, 100));
    assert_eq!(r.mul(200, 200), uor::lut::byte_mul(200, 200));
}

#[test]
fn test_activation_dto_resolve() {
    use hologram_schema_server::generated::ActivationDto;

    let dto = ActivationDto::resolve(128);
    assert_eq!(dto.value, 128);
    assert_eq!(dto.sigmoid, uor::lut::sigmoid_lut(128));
    assert_eq!(dto.tanh, uor::lut::tanh_lut(128));
    assert_eq!(dto.relu, uor::lut::relu_lut(128));
    assert_eq!(dto.exp, uor::lut::exp_lut(128));
    assert_eq!(dto.log, uor::lut::log_lut(128));
    assert_eq!(dto.sqrt, uor::lut::sqrt_lut(128));
    assert_eq!(dto.abs, uor::lut::abs_lut(128));
    assert_eq!(dto.gelu, uor::lut::gelu_lut(128));
    assert_eq!(dto.silu, uor::lut::silu_lut(128));
}

#[test]
fn test_activation_dto_all_values() {
    use hologram_schema_server::generated::ActivationDto;

    // Verify all 256 values resolve without panic
    for v in 0..=255u8 {
        let dto = ActivationDto::resolve(v);
        assert_eq!(dto.value, v);
    }
}

#[test]
fn test_translate_resolver() {
    use hologram_schema_server::generated::{LutTranslateResolver, TranslateResolver};

    let r = LutTranslateResolver;
    assert_eq!(r.add(10, 5), uor::lut::byte_add(10, 5));
    assert_eq!(r.sub(10, 5), uor::lut::byte_sub(10, 5));
}

#[test]
fn test_domain_enum() {
    use hologram_schema_server::generated::Domain;

    assert_eq!(Domain::Theta as u8, 0);
    assert_eq!(Domain::Psi as u8, 1);
    assert_eq!(Domain::Delta as u8, 2);
}

// ============================================================================
// Observable (generated PathDto resolver) tests
// ============================================================================

#[test]
fn test_path_dto_fields_constant() {
    use hologram_schema_server::generated::PathDto;

    let fields = PathDto::FIELDS;
    assert_eq!(fields.len(), 3);
    assert!(fields.contains(&"winding"));
    assert!(fields.contains(&"total_variation"));
    assert!(fields.contains(&"cascade_spectrum"));
}

#[test]
fn test_path_dto_resolve_field_winding() {
    use hologram_schema_server::generated::PathDto;

    let path = &[0u64, 10, 20, 30, 40];
    let quantum = 8u32;
    let result = PathDto::resolve_field(path, quantum, "winding");
    assert!(result.is_some());
    let expected = uor::observable::winding_number(path, quantum);
    match result.unwrap() {
        hologram_schema_server::generated::FieldValue::I64(v) => assert_eq!(v, expected),
        other => panic!("expected I64, got {other:?}"),
    }
}

#[test]
fn test_path_dto_resolve_field_total_variation() {
    use hologram_schema_server::generated::PathDto;

    let path = &[0u64, 10, 20, 30, 40];
    let quantum = 8u32;
    let result = PathDto::resolve_field(path, quantum, "total_variation");
    assert!(result.is_some());
    let expected = uor::observable::total_variation(path, quantum);
    match result.unwrap() {
        hologram_schema_server::generated::FieldValue::U64(v) => assert_eq!(v, expected),
        other => panic!("expected U64, got {other:?}"),
    }
}

#[test]
fn test_path_dto_resolve_field_cascade_spectrum() {
    use hologram_schema_server::generated::PathDto;

    let path = &[0u64, 10, 20, 30, 40];
    let quantum = 8u32;
    let result = PathDto::resolve_field(path, quantum, "cascade_spectrum");
    assert!(result.is_some());
    match result.unwrap() {
        hologram_schema_server::generated::FieldValue::Json(v) => assert!(v.is_array()),
        other => panic!("expected Json, got {other:?}"),
    }
}
