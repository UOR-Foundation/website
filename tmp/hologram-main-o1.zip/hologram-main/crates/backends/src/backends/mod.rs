//! Backend implementations for ISA execution.

pub mod cpu;
pub mod cuda;
pub mod dispatch_unified;
pub mod gpu;
pub mod kernel;
pub mod kernel_abi;
pub mod kernels;
pub mod loader;
pub mod metal;
pub mod wasm;
pub mod webgpu;

pub use dispatch_unified::{ExecuteOn, InstructionDispatcher};

use hologram_holo::BackendPlan;

use crate::types::{BackendCapabilities, BackendType, Result};

/// Type alias for layer execution callback.
///
/// The layer executor is called when a plan contains `CallLayer` instructions.
/// It receives:
/// - `layer_id`: Unique identifier for the sub-layer to execute (u64 hash prefix)
/// - `inputs`: Input buffers for the sub-layer
/// - `outputs`: Output buffers to write results
///
/// The executor should load the sub-layer plan and execute it, writing results
/// to the output buffers.
pub type LayerExecutorFn<'a> = &'a mut dyn FnMut(u64, &[&[u8]], &mut [&mut [u8]]) -> Result<()>;

/// Core backend trait for ISA plan execution.
///
/// Backends execute compiled `BackendPlan` instances, which contain
/// optimized instruction sequences and embedded constant data.
pub trait Backend: Send + Sync {
    /// Get backend type.
    fn backend_type(&self) -> BackendType;

    /// Execute a compiled plan.
    ///
    /// # Arguments
    /// * `plan` - The compiled backend plan (potentially memory-mapped)
    /// * `inputs` - Caller-provided input buffers
    /// * `outputs` - Caller-provided output buffers
    ///
    /// # Zero-copy contract
    /// - `plan` may be an archived reference into a memory-mapped .holo file
    /// - `plan.constants` provides zero-copy access to embedded weights
    /// - Workspace is stack-allocated or pre-allocated arena (no heap allocation)
    ///
    /// # Errors
    /// Returns error if:
    /// - Buffer count mismatch
    /// - Unsupported instruction
    /// - Execution fails
    /// - Plan contains `CallLayer` instructions (use `execute_plan_with_layers` instead)
    fn execute_plan(
        &self,
        plan: &BackendPlan,
        inputs: &[&[u8]],
        outputs: &mut [&mut [u8]],
    ) -> Result<()>;

    /// Execute a compiled plan with layer executor support.
    ///
    /// This method enables execution of plans containing `CallLayer` instructions,
    /// which invoke sub-layers by ID. The layer executor callback is responsible
    /// for loading and executing the referenced sub-layers.
    ///
    /// # Arguments
    /// * `plan` - The compiled backend plan
    /// * `inputs` - Caller-provided input buffers
    /// * `outputs` - Caller-provided output buffers
    /// * `layer_executor` - Closure that executes sub-layers by ID
    ///
    /// # Layer Executor
    ///
    /// The layer executor receives:
    /// - `layer_id`: The u64 identifier (first 8 bytes of SHA-256 content hash)
    /// - `inputs`: Input buffers prepared by the CallLayer instruction
    /// - `outputs`: Output buffers to write results
    ///
    /// The executor should:
    /// 1. Load the sub-layer plan (from cache, disk, registry, or embedded)
    /// 2. Execute it using a backend
    /// 3. Write results to the output buffers
    ///
    /// # Example
    ///
    /// ```rust,ignore
    /// use hologram_backend::{Backend, backends::cpu::CpuBackend};
    /// use std::collections::HashMap;
    ///
    /// let backend = CpuBackend::new();
    /// let mut layer_cache: HashMap<u64, BackendPlan> = load_layers();
    ///
    /// // Define layer executor
    /// let mut executor = |layer_id: u64, inputs: &[&[u8]], outputs: &mut [&mut [u8]]| {
    ///     let sublayer = layer_cache.get(&layer_id)
    ///         .ok_or_else(|| BackendError::LayerLoadError {
    ///             layer_id: format!("{layer_id:016x}"),
    ///             reason: "not found".into(),
    ///         })?;
    ///     backend.execute_plan(sublayer, inputs, outputs)
    /// };
    ///
    /// // Execute main plan with layer support
    /// backend.execute_plan_with_layers(&plan, &inputs, &mut outputs, &mut executor)?;
    /// ```
    ///
    /// # Errors
    ///
    /// Returns error if execution fails or layer executor returns an error.
    fn execute_plan_with_layers(
        &self,
        plan: &BackendPlan,
        inputs: &[&[u8]],
        outputs: &mut [&mut [u8]],
        layer_executor: LayerExecutorFn<'_>,
    ) -> Result<()>;

    /// Get backend capabilities (for compile-time planning).
    fn capabilities(&self) -> &BackendCapabilities;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_backend_trait_object_safety() {
        // Verify Backend is object-safe (can be used as &dyn Backend)
        fn _assert_object_safe(_: &dyn Backend) {}
    }
}
