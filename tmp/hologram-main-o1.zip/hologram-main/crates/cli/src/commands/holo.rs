//! Holo command: archive management for .holo files.

use std::io::Write;
use std::path::{Path, PathBuf};

use clap::{Args, Subcommand};
use hologram_holo::{HolbHeader, HolmHeader, HOLB_MAGIC};

use crate::error::{CliError, CliResult};
use crate::reader::read_holb;

/// Arguments for the holo command.
#[derive(Args, Debug)]
pub struct HoloArgs {
    #[command(subcommand)]
    pub command: HoloCommand,
}

/// Holo subcommands.
#[derive(Subcommand, Debug)]
pub enum HoloCommand {
    /// Pack layers into a .holo archive
    Pack {
        /// .holb files to pack
        #[arg(value_name = "FILES", required = true)]
        inputs: Vec<PathBuf>,

        /// Output .holo archive path
        #[arg(short, long, value_name = "OUTPUT")]
        output: PathBuf,
    },

    /// Unpack a .holo archive to a directory
    Unpack {
        /// Input .holo archive
        #[arg(value_name = "ARCHIVE")]
        input: PathBuf,

        /// Output directory
        #[arg(short, long, value_name = "DIR")]
        output: Option<PathBuf>,
    },

    /// Inspect a .holb/.holo file's metadata
    Inspect {
        /// Input .holb/.holo file
        #[arg(value_name = "FILE")]
        input: PathBuf,

        /// Show detailed layer information
        #[arg(short, long)]
        detailed: bool,
    },
}

/// Execute the holo command.
pub fn execute(args: HoloArgs, verbose: bool) -> CliResult<()> {
    match args.command {
        HoloCommand::Pack { inputs, output } => pack(&inputs, &output, verbose),
        HoloCommand::Unpack { input, output } => unpack(&input, output.as_deref(), verbose),
        HoloCommand::Inspect { input, detailed } => inspect(&input, detailed, verbose),
    }
}

/// Pack layers into a .holo archive.
fn pack(inputs: &[PathBuf], output: &Path, verbose: bool) -> CliResult<()> {
    // Verify all input files exist
    for input in inputs {
        if !input.exists() {
            return Err(CliError::FileNotFound(input.clone()));
        }
    }

    if inputs.is_empty() {
        return Err(CliError::InvalidInput(
            "no input files provided".to_string(),
        ));
    }

    if verbose {
        println!("Packing {} files -> {}", inputs.len(), output.display());
        for input in inputs {
            println!("  {}", input.display());
        }
    }

    // Read all input .holb files
    let mut models: Vec<(String, Vec<u8>)> = Vec::new();
    for input in inputs {
        let name = input
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap_or("model")
            .to_string();
        let data = std::fs::read(input)?;

        // Verify it's a valid HOLB file
        if data.len() < 4 || &data[0..4] != HOLB_MAGIC {
            return Err(CliError::InvalidInput(format!(
                "{} is not a valid .holb file",
                input.display()
            )));
        }

        models.push((name, data));
    }

    // Build HOLM archive
    let header_size = std::mem::size_of::<HolmHeader>();
    let index_offset = header_size;

    // Calculate index size (simplified: name length + offset + size per entry)
    // Using a simple binary format: u32 name_len, name bytes, u64 offset, u64 size, u32 checksum
    let mut index_data = Vec::new();
    let mut model_offsets: Vec<(u64, u64)> = Vec::new();

    // First pass: calculate sizes
    let mut current_offset = header_size;

    // Reserve space for index (estimate)
    let estimated_index_size: usize = models
        .iter()
        .map(|(name, _)| 4 + name.len() + 8 + 8 + 4)
        .sum();
    current_offset += estimated_index_size;

    // Align to 4KB boundary for first model
    current_offset = current_offset.next_multiple_of(4096);

    // Calculate offsets for each model
    for (_, data) in &models {
        model_offsets.push((current_offset as u64, data.len() as u64));
        current_offset += data.len();
        // Align each model to 4KB boundary
        current_offset = current_offset.next_multiple_of(4096);
    }

    // Build index
    for ((name, data), (offset, size)) in models.iter().zip(&model_offsets) {
        let checksum = crc32fast::hash(data);

        // Write name length and name
        index_data.extend_from_slice(&(name.len() as u32).to_le_bytes());
        index_data.extend_from_slice(name.as_bytes());

        // Write offset, size, checksum
        index_data.extend_from_slice(&offset.to_le_bytes());
        index_data.extend_from_slice(&size.to_le_bytes());
        index_data.extend_from_slice(&checksum.to_le_bytes());
    }

    // Build header
    let mut header = HolmHeader::new();
    header.model_count = models.len() as u32;
    header.index_offset = index_offset as u64;

    // Write to file
    let mut file = std::fs::File::create(output)?;

    // Write header
    let header_bytes: &[u8] = unsafe {
        std::slice::from_raw_parts(
            std::ptr::from_ref::<HolmHeader>(&header).cast::<u8>(),
            std::mem::size_of::<HolmHeader>(),
        )
    };
    file.write_all(header_bytes)?;

    // Write index
    file.write_all(&index_data)?;

    // Pad to first model offset
    let current_pos = header_size + index_data.len();
    let first_model_offset = model_offsets[0].0 as usize;
    if current_pos < first_model_offset {
        file.write_all(&vec![0u8; first_model_offset - current_pos])?;
    }

    // Write models with padding
    for (i, (_, data)) in models.iter().enumerate() {
        file.write_all(data)?;

        // Pad if not the last model
        if i < models.len() - 1 {
            let next_offset = model_offsets[i + 1].0 as usize;
            let current_end = model_offsets[i].0 as usize + data.len();
            if current_end < next_offset {
                file.write_all(&vec![0u8; next_offset - current_end])?;
            }
        }
    }

    file.flush()?;

    let file_size = std::fs::metadata(output)?.len();
    println!(
        "Packed {} models into {} ({} bytes)",
        models.len(),
        output.display(),
        file_size
    );

    Ok(())
}

/// Unpack a .holo archive.
fn unpack(input: &Path, output: Option<&Path>, verbose: bool) -> CliResult<()> {
    if !input.exists() {
        return Err(CliError::FileNotFound(input.to_path_buf()));
    }

    let output_dir = output
        .map(Path::to_path_buf)
        .unwrap_or_else(|| input.with_extension(""));

    if verbose {
        println!("Unpacking {} -> {}", input.display(), output_dir.display());
    }

    // Read archive
    let bytes = std::fs::read(input)?;

    // Check magic
    if bytes.len() < 4 {
        return Err(CliError::InvalidInput("file too small".to_string()));
    }

    let magic = &bytes[0..4];
    match magic {
        b"HOLB" => unpack_holb(&bytes, input, &output_dir),
        b"HOLM" => unpack_holm(&bytes, &output_dir, verbose),
        _ => Err(CliError::InvalidInput(format!(
            "unknown file format (magic: {:?})",
            magic
        ))),
    }
}

/// Unpack a single HOLB file (just copy it).
fn unpack_holb(bytes: &[u8], input: &Path, output_dir: &Path) -> CliResult<()> {
    std::fs::create_dir_all(output_dir)?;

    let filename = input
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or("model.holb");
    let output_path = output_dir.join(filename);

    std::fs::write(&output_path, bytes)?;
    println!("Unpacked: {}", output_path.display());

    Ok(())
}

/// Unpack a HOLM archive.
fn unpack_holm(bytes: &[u8], output_dir: &Path, verbose: bool) -> CliResult<()> {
    let header_size = std::mem::size_of::<HolmHeader>();
    if bytes.len() < header_size {
        return Err(CliError::InvalidInput(
            "file too small for HOLM header".to_string(),
        ));
    }

    #[allow(clippy::cast_ptr_alignment)]
    let header = unsafe { &*(bytes.as_ptr().cast::<HolmHeader>()) };

    if !header.is_valid() {
        return Err(CliError::InvalidInput("invalid HOLM magic".to_string()));
    }

    if verbose {
        println!("  Models: {}", header.model_count);
    }

    // Create output directory
    std::fs::create_dir_all(output_dir)?;

    // Parse index and extract models
    let mut index_pos = header.index_offset as usize;

    for i in 0..header.model_count {
        // Read name length
        if index_pos + 4 > bytes.len() {
            return Err(CliError::InvalidInput("truncated index".to_string()));
        }
        let name_len = u32::from_le_bytes([
            bytes[index_pos],
            bytes[index_pos + 1],
            bytes[index_pos + 2],
            bytes[index_pos + 3],
        ]) as usize;
        index_pos += 4;

        // Read name
        if index_pos + name_len > bytes.len() {
            return Err(CliError::InvalidInput("truncated name".to_string()));
        }
        let name = String::from_utf8_lossy(&bytes[index_pos..index_pos + name_len]).to_string();
        index_pos += name_len;

        // Read offset, size, checksum
        if index_pos + 20 > bytes.len() {
            return Err(CliError::InvalidInput("truncated index entry".to_string()));
        }
        let offset = u64::from_le_bytes([
            bytes[index_pos],
            bytes[index_pos + 1],
            bytes[index_pos + 2],
            bytes[index_pos + 3],
            bytes[index_pos + 4],
            bytes[index_pos + 5],
            bytes[index_pos + 6],
            bytes[index_pos + 7],
        ]) as usize;
        index_pos += 8;

        let size = u64::from_le_bytes([
            bytes[index_pos],
            bytes[index_pos + 1],
            bytes[index_pos + 2],
            bytes[index_pos + 3],
            bytes[index_pos + 4],
            bytes[index_pos + 5],
            bytes[index_pos + 6],
            bytes[index_pos + 7],
        ]) as usize;
        index_pos += 8;

        let expected_checksum = u32::from_le_bytes([
            bytes[index_pos],
            bytes[index_pos + 1],
            bytes[index_pos + 2],
            bytes[index_pos + 3],
        ]);
        index_pos += 4;

        // Extract model data
        if offset + size > bytes.len() {
            return Err(CliError::InvalidInput(format!(
                "model {} extends beyond file",
                i
            )));
        }
        let model_data = &bytes[offset..offset + size];

        // Verify checksum
        let computed_checksum = crc32fast::hash(model_data);
        if computed_checksum != expected_checksum {
            return Err(CliError::InvalidInput(format!(
                "checksum mismatch for model {}: expected {:#x}, got {:#x}",
                name, expected_checksum, computed_checksum
            )));
        }

        // Write model to file
        let output_path = output_dir.join(format!("{name}.holb"));
        std::fs::write(&output_path, model_data)?;

        if verbose {
            println!("  Extracted: {} ({} bytes)", output_path.display(), size);
        }
    }

    println!(
        "Unpacked {} models to {}",
        header.model_count,
        output_dir.display()
    );

    Ok(())
}

/// Inspect a .holb/.holo file's metadata.
fn inspect(input: &Path, detailed: bool, verbose: bool) -> CliResult<()> {
    if !input.exists() {
        return Err(CliError::FileNotFound(input.to_path_buf()));
    }

    if verbose {
        println!("Inspecting {}", input.display());
    }

    let bytes = std::fs::read(input)?;

    if bytes.len() < 4 {
        return Err(CliError::InvalidInput("file too small".to_string()));
    }

    let magic = &bytes[0..4];
    match magic {
        b"HOLB" => inspect_holb(&bytes, input, detailed),
        b"HOLM" => inspect_holm(&bytes, input, detailed),
        _ => {
            println!("File: {}", input.display());
            println!("Size: {} bytes", bytes.len());
            println!("Format: Unknown (magic: {:?})", magic);
            Ok(())
        }
    }
}

/// Inspect a HOLB file.
fn inspect_holb(bytes: &[u8], path: &Path, detailed: bool) -> CliResult<()> {
    let header_size = std::mem::size_of::<HolbHeader>();
    if bytes.len() < header_size {
        return Err(CliError::InvalidInput(
            "file too small for HOLB header".to_string(),
        ));
    }

    #[allow(clippy::cast_ptr_alignment)]
    let header = unsafe { &*(bytes.as_ptr().cast::<HolbHeader>()) };

    println!("File: {}", path.display());
    println!("Format: HOLB (Unified Bundle)");
    println!("Version: {}", header.version);
    println!("Size: {} bytes", bytes.len());
    println!();
    println!("Graph:");
    println!("  Offset: {} bytes", header.graph_offset);
    println!("  Size: {} bytes", header.graph_size);
    println!("  Checksum: {:#010x}", header.graph_checksum);
    println!();
    println!("Weights:");
    println!("  Offset: {} bytes", header.weights_offset);
    println!("  Size: {} bytes", header.weights_size);
    println!("  Checksum: {:#010x}", header.weights_checksum);

    // Verify checksums
    let graph_start = header.graph_offset as usize;
    let graph_end = graph_start + header.graph_size as usize;
    if graph_end <= bytes.len() {
        let computed = crc32fast::hash(&bytes[graph_start..graph_end]);
        let status = if computed == header.graph_checksum {
            "OK"
        } else {
            "MISMATCH"
        };
        println!("  Graph integrity: {status}");
    }

    if header.weights_size > 0 {
        let weights_start = header.weights_offset as usize;
        let weights_end = weights_start + header.weights_size as usize;
        if weights_end <= bytes.len() {
            let computed = crc32fast::hash(&bytes[weights_start..weights_end]);
            let status = if computed == header.weights_checksum {
                "OK"
            } else {
                "MISMATCH"
            };
            println!("  Weights integrity: {status}");
        }
    }

    if detailed {
        // Load and show plan details
        let plan = read_holb(path)?;
        println!();
        println!("Plan Details:");
        println!("  Name: {}", plan.metadata.name);
        println!("  Version: {}", plan.metadata.version);
        if let Some(author) = &plan.metadata.author {
            println!("  Author: {author}");
        }
        if let Some(desc) = &plan.metadata.description {
            println!("  Description: {desc}");
        }
        println!("  Instructions: {}", plan.instructions.len());
        println!("  Buffers: {}", plan.buffers.len());
        println!("  Workspace: {} bytes", plan.workspace_size);
        println!("  Dependencies: {}", plan.dependencies.len());
    }

    Ok(())
}

/// Inspect a HOLM file.
fn inspect_holm(bytes: &[u8], path: &Path, detailed: bool) -> CliResult<()> {
    let header_size = std::mem::size_of::<HolmHeader>();
    if bytes.len() < header_size {
        return Err(CliError::InvalidInput(
            "file too small for HOLM header".to_string(),
        ));
    }

    #[allow(clippy::cast_ptr_alignment)]
    let header = unsafe { &*(bytes.as_ptr().cast::<HolmHeader>()) };

    println!("File: {}", path.display());
    println!("Format: HOLM (Pipeline Bundle)");
    println!("Version: {}", header.version);
    println!("Size: {} bytes", bytes.len());
    println!("Models: {}", header.model_count);
    println!("Index Offset: {} bytes", header.index_offset);

    if detailed {
        // Parse and show index entries
        let mut index_pos = header.index_offset as usize;

        println!();
        println!("Model Index:");

        for i in 0..header.model_count {
            // Read name length
            if index_pos + 4 > bytes.len() {
                println!("  [truncated]");
                break;
            }
            let name_len = u32::from_le_bytes([
                bytes[index_pos],
                bytes[index_pos + 1],
                bytes[index_pos + 2],
                bytes[index_pos + 3],
            ]) as usize;
            index_pos += 4;

            // Read name
            if index_pos + name_len > bytes.len() {
                println!("  [truncated]");
                break;
            }
            let name = String::from_utf8_lossy(&bytes[index_pos..index_pos + name_len]).to_string();
            index_pos += name_len;

            // Read offset, size, checksum
            if index_pos + 20 > bytes.len() {
                println!("  [truncated]");
                break;
            }
            let offset = u64::from_le_bytes([
                bytes[index_pos],
                bytes[index_pos + 1],
                bytes[index_pos + 2],
                bytes[index_pos + 3],
                bytes[index_pos + 4],
                bytes[index_pos + 5],
                bytes[index_pos + 6],
                bytes[index_pos + 7],
            ]);
            index_pos += 8;

            let size = u64::from_le_bytes([
                bytes[index_pos],
                bytes[index_pos + 1],
                bytes[index_pos + 2],
                bytes[index_pos + 3],
                bytes[index_pos + 4],
                bytes[index_pos + 5],
                bytes[index_pos + 6],
                bytes[index_pos + 7],
            ]);
            index_pos += 8;

            let checksum = u32::from_le_bytes([
                bytes[index_pos],
                bytes[index_pos + 1],
                bytes[index_pos + 2],
                bytes[index_pos + 3],
            ]);
            index_pos += 4;

            println!();
            println!("  [{i}] {name}");
            println!("      Offset: {offset} bytes");
            println!("      Size: {size} bytes");
            println!("      Checksum: {checksum:#010x}");

            // Verify checksum
            let model_start = offset as usize;
            let model_end = model_start + size as usize;
            if model_end <= bytes.len() {
                let computed = crc32fast::hash(&bytes[model_start..model_end]);
                let status = if computed == checksum {
                    "OK"
                } else {
                    "MISMATCH"
                };
                println!("      Integrity: {status}");
            }
        }
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_holo::{BackendPlan, PlanMetadata};
    use tempfile::tempdir;

    use crate::writer::write_holb;

    fn create_test_holb(dir: &Path, name: &str) -> PathBuf {
        let path = dir.join(format!("{name}.holb"));
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![1, 2, 3, 4],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata {
                name: name.to_string(),
                version: "1.0.0".to_string(),
                author: None,
                description: None,
            },
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };
        write_holb(&plan, &path).unwrap();
        path
    }

    #[test]
    fn test_inspect_holb() {
        let dir = tempdir().unwrap();
        let path = create_test_holb(dir.path(), "test-model");

        let result = inspect(&path, false, false);
        assert!(result.is_ok());
    }

    #[test]
    fn test_inspect_holb_detailed() {
        let dir = tempdir().unwrap();
        let path = create_test_holb(dir.path(), "detailed-model");

        let result = inspect(&path, true, false);
        assert!(result.is_ok());
    }

    #[test]
    fn test_pack_and_unpack() {
        let dir = tempdir().unwrap();

        // Create test .holb files
        let model1 = create_test_holb(dir.path(), "model1");
        let model2 = create_test_holb(dir.path(), "model2");

        // Pack into .holo
        let holo_path = dir.path().join("bundle.holo");
        let result = pack(&[model1, model2], &holo_path, false);
        assert!(result.is_ok(), "pack failed: {result:?}");
        assert!(holo_path.exists());

        // Inspect the archive
        let result = inspect(&holo_path, true, false);
        assert!(result.is_ok(), "inspect failed: {result:?}");

        // Unpack
        let unpack_dir = dir.path().join("unpacked");
        let result = unpack(&holo_path, Some(&unpack_dir), false);
        assert!(result.is_ok(), "unpack failed: {result:?}");

        // Verify unpacked files
        assert!(unpack_dir.join("model1.holb").exists());
        assert!(unpack_dir.join("model2.holb").exists());
    }

    #[test]
    fn test_unpack_single_holb() {
        let dir = tempdir().unwrap();
        let path = create_test_holb(dir.path(), "single");

        let unpack_dir = dir.path().join("unpacked_single");
        let result = unpack(&path, Some(&unpack_dir), false);
        assert!(result.is_ok());
        assert!(unpack_dir.join("single.holb").exists());
    }
}
