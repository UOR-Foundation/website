//! Benchmarks for CPU kernel operations and hot path allocation testing.
//!
//! # Overview
//!
//! These benchmarks measure the performance of core kernel operations
//! (matmul, vector_add, vector_mul) to verify zero-allocation in hot paths.
//!
//! # Benchmark Groups
//!
//! ## `vector_add`
//! Measures vector addition performance at various sizes.
//! Should show allocation overhead at small sizes (before optimization).
//!
//! ## `vector_mul`
//! Measures vector multiplication performance at various sizes.
//!
//! ## `matmul`
//! Measures matrix multiplication at various dimensions.
//! This is the WORST offender with 4 allocations per call before optimization.
//!
//! ## `gemm_kernel_direct`
//! Benchmarks the GEMM kernel directly without backend overhead
//! to establish the theoretical maximum performance.
//!
//! # Expected Results (Before Optimization)
//!
//! - Small matrices: Dominated by allocation overhead
//! - Large matrices: Compute-bound, allocation overhead less visible
//!
//! # Expected Results (After Optimization)
//!
//! - 10-50% improvement for small matrices (allocation-bound)
//! - 5-10% improvement for large matrices (compute-bound)
//! - Zero allocations in steady-state execution

use std::time::Duration;

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use hologram_backend::cpu::{CpuBackend, SimdDispatcher};
use hologram_backend::{ComputeBackend, MatMulParams, ProgramBackend};
use hologram_isa::Type;

// Stabilize measurements so baseline comparisons are less sensitive to short
// turbo bursts or background load on developer machines.
fn benchmark_config() -> Criterion {
    Criterion::default()
        .configure_from_args()
        .warm_up_time(Duration::from_secs(2))
        .measurement_time(Duration::from_secs(7))
        .sample_size(30)
        .noise_threshold(0.02)
        .significance_level(0.02)
}

// ============================================================================
// VECTOR ADD BENCHMARKS
// ============================================================================

fn bench_vector_add(c: &mut Criterion) {
    let mut group = c.benchmark_group("vector_add");

    for size in [256, 1024, 4096, 16384, 65536, 262144] {
        group.throughput(Throughput::Elements(size as u64));
        group.bench_with_input(BenchmarkId::from_parameter(size), &size, |b, &size| {
            let backend = CpuBackend::new();

            // Allocate buffers (one-time setup)
            let buf_a = backend.allocate_buffer(size).unwrap();
            let buf_b = backend.allocate_buffer(size).unwrap();
            let buf_c = backend.allocate_buffer(size).unwrap();

            // Fill with test data
            let data_a: Vec<u8> = (0..size).map(|i| (i % 256) as u8).collect();
            let data_b: Vec<u8> = (0..size).map(|i| ((i * 7) % 256) as u8).collect();
            backend.copy_to_buffer(buf_a, &data_a).unwrap();
            backend.copy_to_buffer(buf_b, &data_b).unwrap();

            b.iter(|| {
                backend
                    .vector_add(black_box(buf_c), black_box(buf_a), black_box(buf_b), size)
                    .unwrap()
            });
        });
    }

    group.finish();
}

// ============================================================================
// VECTOR MUL BENCHMARKS
// ============================================================================

fn bench_vector_mul(c: &mut Criterion) {
    let mut group = c.benchmark_group("vector_mul");

    for size in [256, 1024, 4096, 16384, 65536, 262144] {
        group.throughput(Throughput::Elements(size as u64));
        group.bench_with_input(BenchmarkId::from_parameter(size), &size, |b, &size| {
            let backend = CpuBackend::new();

            // Allocate buffers (one-time setup)
            let buf_a = backend.allocate_buffer(size).unwrap();
            let buf_b = backend.allocate_buffer(size).unwrap();
            let buf_c = backend.allocate_buffer(size).unwrap();

            // Fill with test data
            let data_a: Vec<u8> = (0..size).map(|i| (i % 256) as u8).collect();
            let data_b: Vec<u8> = (0..size).map(|i| ((i * 7) % 256) as u8).collect();
            backend.copy_to_buffer(buf_a, &data_a).unwrap();
            backend.copy_to_buffer(buf_b, &data_b).unwrap();

            b.iter(|| {
                backend
                    .vector_mul(black_box(buf_c), black_box(buf_a), black_box(buf_b), size)
                    .unwrap()
            });
        });
    }

    group.finish();
}

// ============================================================================
// MATMUL BENCHMARKS
// ============================================================================

fn bench_matmul(c: &mut Criterion) {
    let mut group = c.benchmark_group("matmul");

    // Test various matrix sizes
    let sizes = [
        (32, 32, 32),       // Very small - allocation dominated
        (64, 64, 64),       // Small
        (128, 128, 128),    // Medium-small
        (256, 256, 256),    // Medium
        (512, 512, 512),    // Large
        (1024, 1024, 1024), // Very large - compute dominated
    ];

    for (m, k, n) in sizes {
        let flops = 2 * m * k * n; // FMA = 2 ops
        group.throughput(Throughput::Elements(flops as u64));

        group.bench_with_input(
            BenchmarkId::new("square", format!("{}x{}", m, n)),
            &(m, k, n),
            |b, &(m, k, n)| {
                let backend = CpuBackend::new();

                // Allocate buffers for A[m,k], B[k,n], C[m,n]
                let size_a = m * k * 4; // f32
                let size_b = k * n * 4;
                let size_c = m * n * 4;

                let buf_a = backend.allocate_buffer(size_a).unwrap();
                let buf_b = backend.allocate_buffer(size_b).unwrap();
                let buf_c = backend.allocate_buffer(size_c).unwrap();

                // Fill with test data (simple pattern for reproducibility)
                let data_a: Vec<u8> = (0..m * k)
                    .flat_map(|i| ((i % 100) as f32 * 0.01).to_le_bytes())
                    .collect();
                let data_b: Vec<u8> = (0..k * n)
                    .flat_map(|i| ((i % 100) as f32 * 0.01).to_le_bytes())
                    .collect();
                backend.copy_to_buffer(buf_a, &data_a).unwrap();
                backend.copy_to_buffer(buf_b, &data_b).unwrap();

                let params = MatMulParams {
                    m: m as u32,
                    k: k as u32,
                    n: n as u32,
                    alpha: 1.0,
                    beta: 0.0,
                    trans_a: false,
                    trans_b: false,
                    dtype: Type::F32,
                };

                b.iter(|| {
                    backend
                        .matmul(
                            black_box(buf_c),
                            black_box(buf_a),
                            black_box(buf_b),
                            black_box(&params),
                        )
                        .unwrap()
                });
            },
        );
    }

    // Non-square matrices (common in ML)
    let nonsquare_sizes = [
        (1, 768, 768),    // Vector-matrix (batch=1)
        (32, 768, 768),   // Small batch
        (128, 768, 3072), // Typical transformer MLP
        (128, 3072, 768), // Transformer MLP second half
    ];

    for (m, k, n) in nonsquare_sizes {
        let flops = 2 * m * k * n;
        group.throughput(Throughput::Elements(flops as u64));

        group.bench_with_input(
            BenchmarkId::new("nonsquare", format!("{}x{}x{}", m, k, n)),
            &(m, k, n),
            |b, &(m, k, n)| {
                let backend = CpuBackend::new();

                let size_a = m * k * 4;
                let size_b = k * n * 4;
                let size_c = m * n * 4;

                let buf_a = backend.allocate_buffer(size_a).unwrap();
                let buf_b = backend.allocate_buffer(size_b).unwrap();
                let buf_c = backend.allocate_buffer(size_c).unwrap();

                let data_a: Vec<u8> = (0..m * k)
                    .flat_map(|i| ((i % 100) as f32 * 0.01).to_le_bytes())
                    .collect();
                let data_b: Vec<u8> = (0..k * n)
                    .flat_map(|i| ((i % 100) as f32 * 0.01).to_le_bytes())
                    .collect();
                backend.copy_to_buffer(buf_a, &data_a).unwrap();
                backend.copy_to_buffer(buf_b, &data_b).unwrap();

                let params = MatMulParams {
                    m: m as u32,
                    k: k as u32,
                    n: n as u32,
                    alpha: 1.0,
                    beta: 0.0,
                    trans_a: false,
                    trans_b: false,
                    dtype: Type::F32,
                };

                b.iter(|| {
                    backend
                        .matmul(
                            black_box(buf_c),
                            black_box(buf_a),
                            black_box(buf_b),
                            black_box(&params),
                        )
                        .unwrap()
                });
            },
        );
    }

    group.finish();
}

// ============================================================================
// DIRECT GEMM KERNEL BENCHMARK (No backend overhead)
// ============================================================================

fn bench_gemm_kernel_direct(c: &mut Criterion) {
    let mut group = c.benchmark_group("gemm_kernel_direct");

    let sizes = [(64, 64, 64), (256, 256, 256), (512, 512, 512)];

    for (m, k, n) in sizes {
        let flops = 2 * m * k * n;
        group.throughput(Throughput::Elements(flops as u64));

        group.bench_with_input(
            BenchmarkId::new("simd_dispatch", format!("{}x{}", m, n)),
            &(m, k, n),
            |b, &(m, k, n)| {
                // Allocate aligned buffers directly
                let mut a: Vec<f32> = vec![0.0; m * k];
                let mut b_mat: Vec<f32> = vec![0.0; k * n];
                let mut c: Vec<f32> = vec![0.0; m * n];

                // Initialize with test pattern
                for (i, val) in a.iter_mut().enumerate() {
                    *val = (i % 100) as f32 * 0.01;
                }
                for (i, val) in b_mat.iter_mut().enumerate() {
                    *val = (i % 100) as f32 * 0.01;
                }

                let dispatcher = SimdDispatcher::new();

                b.iter(|| {
                    dispatcher
                        .matmul_f32(
                            black_box(&mut c),
                            black_box(&a),
                            black_box(&b_mat),
                            m,
                            k,
                            n,
                            1.0,
                            0.0,
                        )
                        .unwrap()
                });
            },
        );
    }

    group.finish();
}

// ============================================================================
// ALLOCATION OVERHEAD COMPARISON
// ============================================================================

fn bench_allocation_overhead(c: &mut Criterion) {
    let mut group = c.benchmark_group("allocation_overhead");

    // Baseline: measure Vec allocation cost at various sizes
    for size in [1024, 4096, 16384, 65536] {
        group.bench_with_input(
            BenchmarkId::new("vec_alloc_bytes", size),
            &size,
            |b, &size| {
                b.iter(|| {
                    let v: Vec<u8> = vec![0u8; size];
                    black_box(v.as_ptr())
                });
            },
        );
    }

    // Vec<f32> allocation (what get_buffer_f32 does)
    for count in [256, 1024, 4096, 16384] {
        group.bench_with_input(
            BenchmarkId::new("vec_alloc_f32", count),
            &count,
            |b, &count| {
                b.iter(|| {
                    let v: Vec<f32> = vec![0.0f32; count];
                    black_box(v.as_ptr())
                });
            },
        );
    }

    // Clone operation (what vector_add/mul currently does)
    for size in [1024, 4096, 16384, 65536] {
        let source: Vec<u8> = vec![42u8; size];
        group.bench_with_input(
            BenchmarkId::new("vec_clone_bytes", size),
            &source,
            |b, source| {
                b.iter(|| {
                    let cloned = source.clone();
                    black_box(cloned.as_ptr())
                });
            },
        );
    }

    group.finish();
}

criterion_group! {
    name = benches;
    config = benchmark_config();
    targets =
        bench_vector_add,
        bench_vector_mul,
        bench_matmul,
        bench_gemm_kernel_direct,
        bench_allocation_overhead,
}

criterion_main!(benches);
