//! Layer metadata types.
//!
//! This module provides types for layer metadata and search results,
//! used by both local and remote registries.

use std::collections::HashMap;

use serde::{Deserialize, Serialize};

/// Metadata about a layer in the registry.
///
/// This struct contains information about a layer's size, digest,
/// timestamps, and optional descriptive metadata.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerMetadata {
    /// Layer reference string.
    pub layer_ref: String,
    /// Size in bytes.
    pub size: u64,
    /// Content digest (usually BLAKE3 or SHA256).
    pub digest: String,
    /// Creation timestamp (ISO 8601).
    pub created_at: Option<String>,
    /// Last modified timestamp (ISO 8601).
    pub updated_at: Option<String>,
    /// Human-readable description.
    pub description: Option<String>,
    /// Available version tags.
    pub tags: Vec<String>,
    /// Author/maintainer.
    pub author: Option<String>,
    /// License identifier.
    pub license: Option<String>,
    /// Custom labels/annotations.
    #[serde(default)]
    pub labels: HashMap<String, String>,
}

impl LayerMetadata {
    /// Create new metadata with required fields.
    ///
    /// # Example
    ///
    /// ```
    /// use hologram_registry::LayerMetadata;
    ///
    /// let meta = LayerMetadata::new("model:v1.0", 1024, "blake3:abc123");
    /// assert_eq!(meta.size, 1024);
    /// ```
    #[must_use]
    pub fn new(layer_ref: impl Into<String>, size: u64, digest: impl Into<String>) -> Self {
        Self {
            layer_ref: layer_ref.into(),
            size,
            digest: digest.into(),
            created_at: None,
            updated_at: None,
            description: None,
            tags: vec![],
            author: None,
            license: None,
            labels: HashMap::new(),
        }
    }

    /// Set the description.
    #[must_use]
    pub fn with_description(mut self, description: impl Into<String>) -> Self {
        self.description = Some(description.into());
        self
    }

    /// Set the author.
    #[must_use]
    pub fn with_author(mut self, author: impl Into<String>) -> Self {
        self.author = Some(author.into());
        self
    }

    /// Set the license.
    #[must_use]
    pub fn with_license(mut self, license: impl Into<String>) -> Self {
        self.license = Some(license.into());
        self
    }

    /// Add a tag.
    #[must_use]
    pub fn with_tag(mut self, tag: impl Into<String>) -> Self {
        self.tags.push(tag.into());
        self
    }

    /// Add a label.
    #[must_use]
    pub fn with_label(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        self.labels.insert(key.into(), value.into());
        self
    }

    /// Set the creation timestamp.
    #[must_use]
    pub fn with_created_at(mut self, timestamp: impl Into<String>) -> Self {
        self.created_at = Some(timestamp.into());
        self
    }

    /// Set the update timestamp.
    #[must_use]
    pub fn with_updated_at(mut self, timestamp: impl Into<String>) -> Self {
        self.updated_at = Some(timestamp.into());
        self
    }

    /// Get a human-readable size string.
    ///
    /// # Example
    ///
    /// ```
    /// use hologram_registry::LayerMetadata;
    ///
    /// let meta = LayerMetadata::new("m", 5 * 1024 * 1024, "d");
    /// assert_eq!(meta.size_string(), "5.00 MB");
    /// ```
    #[must_use]
    pub fn size_string(&self) -> String {
        const KB: u64 = 1024;
        const MB: u64 = KB * 1024;
        const GB: u64 = MB * 1024;

        if self.size >= GB {
            format!("{:.2} GB", self.size as f64 / GB as f64)
        } else if self.size >= MB {
            format!("{:.2} MB", self.size as f64 / MB as f64)
        } else if self.size >= KB {
            format!("{:.2} KB", self.size as f64 / KB as f64)
        } else {
            format!("{} bytes", self.size)
        }
    }
}

/// Result of a search operation.
///
/// Contains summary information about a layer matching a search query.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SearchResult {
    /// Layer reference string.
    pub layer_ref: String,
    /// Human-readable description.
    pub description: Option<String>,
    /// Download count.
    pub downloads: u64,
    /// Available tags.
    pub tags: Vec<String>,
    /// Star count / popularity score.
    pub stars: u64,
    /// Last updated timestamp.
    pub updated_at: Option<String>,
}

impl SearchResult {
    /// Create a new search result with just a layer reference.
    ///
    /// # Example
    ///
    /// ```
    /// use hologram_registry::SearchResult;
    ///
    /// let result = SearchResult::new("bert/embeddings:v1.0");
    /// assert_eq!(result.downloads, 0);
    /// ```
    #[must_use]
    pub fn new(layer_ref: impl Into<String>) -> Self {
        Self {
            layer_ref: layer_ref.into(),
            description: None,
            downloads: 0,
            tags: vec![],
            stars: 0,
            updated_at: None,
        }
    }

    /// Set the description.
    #[must_use]
    pub fn with_description(mut self, description: impl Into<String>) -> Self {
        self.description = Some(description.into());
        self
    }

    /// Set the download count.
    #[must_use]
    pub fn with_downloads(mut self, downloads: u64) -> Self {
        self.downloads = downloads;
        self
    }

    /// Set the star count.
    #[must_use]
    pub fn with_stars(mut self, stars: u64) -> Self {
        self.stars = stars;
        self
    }

    /// Add a tag.
    #[must_use]
    pub fn with_tag(mut self, tag: impl Into<String>) -> Self {
        self.tags.push(tag.into());
        self
    }

    /// Set the update timestamp.
    #[must_use]
    pub fn with_updated_at(mut self, timestamp: impl Into<String>) -> Self {
        self.updated_at = Some(timestamp.into());
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_metadata_new() {
        let meta = LayerMetadata::new("bert/embeddings:v1.0", 1024 * 1024, "sha256:abc123");
        assert_eq!(meta.layer_ref, "bert/embeddings:v1.0");
        assert_eq!(meta.size, 1024 * 1024);
        assert_eq!(meta.digest, "sha256:abc123");
        assert!(meta.description.is_none());
        assert!(meta.tags.is_empty());
    }

    #[test]
    fn test_metadata_builder() {
        let meta = LayerMetadata::new("bert/embeddings:v1.0", 1024, "sha256:abc")
            .with_description("BERT embeddings layer")
            .with_author("Anthropic")
            .with_license("MIT")
            .with_tag("v1.0")
            .with_tag("latest")
            .with_label("model.type", "embedding")
            .with_created_at("2024-01-01T00:00:00Z")
            .with_updated_at("2024-01-02T00:00:00Z");

        assert_eq!(meta.description, Some("BERT embeddings layer".to_string()));
        assert_eq!(meta.author, Some("Anthropic".to_string()));
        assert_eq!(meta.license, Some("MIT".to_string()));
        assert_eq!(meta.tags, vec!["v1.0", "latest"]);
        assert_eq!(
            meta.labels.get("model.type"),
            Some(&"embedding".to_string())
        );
        assert_eq!(meta.created_at, Some("2024-01-01T00:00:00Z".to_string()));
        assert_eq!(meta.updated_at, Some("2024-01-02T00:00:00Z".to_string()));
    }

    #[test]
    fn test_size_string_bytes() {
        let meta = LayerMetadata::new("t", 500, "d");
        assert_eq!(meta.size_string(), "500 bytes");
    }

    #[test]
    fn test_size_string_kb() {
        let meta = LayerMetadata::new("t", 2048, "d");
        assert_eq!(meta.size_string(), "2.00 KB");
    }

    #[test]
    fn test_size_string_mb() {
        let meta = LayerMetadata::new("t", 5 * 1024 * 1024, "d");
        assert_eq!(meta.size_string(), "5.00 MB");
    }

    #[test]
    fn test_size_string_gb() {
        let meta = LayerMetadata::new("t", 2 * 1024 * 1024 * 1024, "d");
        assert_eq!(meta.size_string(), "2.00 GB");
    }

    #[test]
    fn test_search_result_new() {
        let result = SearchResult::new("model:v1.0");
        assert_eq!(result.layer_ref, "model:v1.0");
        assert_eq!(result.downloads, 0);
        assert_eq!(result.stars, 0);
        assert!(result.description.is_none());
    }

    #[test]
    fn test_search_result_builder() {
        let result = SearchResult::new("model:v1.0")
            .with_description("A test model")
            .with_downloads(100)
            .with_stars(50)
            .with_tag("latest")
            .with_tag("stable")
            .with_updated_at("2024-01-01T00:00:00Z");

        assert_eq!(result.description, Some("A test model".to_string()));
        assert_eq!(result.downloads, 100);
        assert_eq!(result.stars, 50);
        assert_eq!(result.tags, vec!["latest", "stable"]);
        assert_eq!(result.updated_at, Some("2024-01-01T00:00:00Z".to_string()));
    }

    #[test]
    fn test_metadata_serde_roundtrip() {
        let meta = LayerMetadata::new("model:v1", 1024, "sha256:abc")
            .with_description("Test")
            .with_label("key", "value");

        let json = serde_json::to_string(&meta).unwrap();
        let restored: LayerMetadata = serde_json::from_str(&json).unwrap();

        assert_eq!(meta.layer_ref, restored.layer_ref);
        assert_eq!(meta.size, restored.size);
        assert_eq!(meta.description, restored.description);
        assert_eq!(meta.labels.get("key"), restored.labels.get("key"));
    }

    #[test]
    fn test_search_result_serde_roundtrip() {
        let result = SearchResult::new("model:v1")
            .with_description("Test")
            .with_downloads(42);

        let json = serde_json::to_string(&result).unwrap();
        let restored: SearchResult = serde_json::from_str(&json).unwrap();

        assert_eq!(result.layer_ref, restored.layer_ref);
        assert_eq!(result.downloads, restored.downloads);
    }

    #[test]
    fn test_size_string_boundary_cases() {
        // Exactly 1 KB
        let meta = LayerMetadata::new("t", 1024, "d");
        assert_eq!(meta.size_string(), "1.00 KB");

        // Exactly 1 MB
        let meta = LayerMetadata::new("t", 1024 * 1024, "d");
        assert_eq!(meta.size_string(), "1.00 MB");

        // Exactly 1 GB
        let meta = LayerMetadata::new("t", 1024 * 1024 * 1024, "d");
        assert_eq!(meta.size_string(), "1.00 GB");

        // Zero bytes
        let meta = LayerMetadata::new("t", 0, "d");
        assert_eq!(meta.size_string(), "0 bytes");
    }
}
