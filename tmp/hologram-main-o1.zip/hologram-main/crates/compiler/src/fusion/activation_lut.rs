//! Activation LUT fusion pass.
//!
//! Detects activation functions operating on quantized (U8/I8) data and marks
//! them for O(1) LUT-based execution instead of runtime arithmetic.
//!
//! # Supported Activations
//!
//! - `Sigmoid` → `SigmoidLUT` (256-byte lookup table)
//! - `Tanh` → `TanhLUT` (256-byte lookup table)
//! - `Exp` → `ExpLUT` (256-byte lookup table)
//! - `Log` → `LogLUT` (256-byte lookup table)
//! - `Relu` → `ReluLUT` (256-byte lookup table)
//! - `Sqrt` → `SqrtLUT` (256-byte lookup table)
//! - `Abs` → `AbsLUT` (256-byte lookup table)
//! - `Gelu` → `GeluLUT` (256-byte lookup table, transformers)
//! - `Silu` → `SiluLUT` (256-byte lookup table, modern CNNs)
//!
//! # Detection Criteria
//!
//! An activation is marked for LUT execution when:
//! 1. The input dtype is U8 or I8 (quantized data)
//! 2. The activation has a LUT variant in the ISA
//!
//! # Annotation Format
//!
//! Nodes marked for LUT execution receive an annotation:
//! - `activation_lut:sigmoid` for Sigmoid → `SigmoidLUT`
//! - `activation_lut:tanh` for Tanh → `TanhLUT`
//! - `activation_lut:exp` for Exp → `ExpLUT`
//! - `activation_lut:log` for Log → `LogLUT`
//! - `activation_lut:relu` for Relu → `ReluLUT`
//! - `activation_lut:sqrt` for Sqrt → `SqrtLUT`
//! - `activation_lut:abs` for Abs → `AbsLUT`
//! - `activation_lut:gelu` for Gelu → `GeluLUT`
//! - `activation_lut:silu` for Silu → `SiluLUT`

use crate::graph::{CompileGraph, DType, OpKind};

/// Configuration for activation LUT fusion.
#[allow(clippy::struct_excessive_bools)] // Each bool enables a distinct LUT activation type
#[derive(Debug, Clone, Copy, Default)]
pub struct ActivationLutConfig {
    /// Enable LUT-based Sigmoid for quantized inputs.
    pub enable_sigmoid: bool,
    /// Enable LUT-based Tanh for quantized inputs.
    pub enable_tanh: bool,
    /// Enable LUT-based Exp for quantized inputs.
    pub enable_exp: bool,
    /// Enable LUT-based Log for quantized inputs.
    pub enable_log: bool,
    /// Enable LUT-based `ReLU` for quantized inputs.
    pub enable_relu: bool,
    /// Enable LUT-based Sqrt for quantized inputs.
    pub enable_sqrt: bool,
    /// Enable LUT-based Abs for quantized inputs.
    pub enable_abs: bool,
    /// Enable LUT-based GELU for quantized inputs (transformers).
    pub enable_gelu: bool,
    /// Enable LUT-based `SiLU` (Swish) for quantized inputs.
    pub enable_silu: bool,
}

impl ActivationLutConfig {
    /// Create a config with all LUT activations enabled.
    #[must_use]
    pub fn enabled() -> Self {
        Self {
            enable_sigmoid: true,
            enable_tanh: true,
            enable_exp: true,
            enable_log: true,
            enable_relu: true,
            enable_sqrt: true,
            enable_abs: true,
            enable_gelu: true,
            enable_silu: true,
        }
    }

    /// Create a config with only Sigmoid LUT enabled.
    #[must_use]
    pub fn sigmoid_only() -> Self {
        Self {
            enable_sigmoid: true,
            ..Self::default()
        }
    }

    /// Create a config with only Tanh LUT enabled.
    #[must_use]
    pub fn tanh_only() -> Self {
        Self {
            enable_tanh: true,
            ..Self::default()
        }
    }

    /// Create a config with classic activations enabled (sigmoid, tanh, relu).
    #[must_use]
    pub fn activations_only() -> Self {
        Self {
            enable_sigmoid: true,
            enable_tanh: true,
            enable_relu: true,
            ..Self::default()
        }
    }

    /// Create a config with math functions enabled (exp, log, sqrt, abs).
    #[must_use]
    pub fn math_only() -> Self {
        Self {
            enable_exp: true,
            enable_log: true,
            enable_sqrt: true,
            enable_abs: true,
            ..Self::default()
        }
    }

    /// Create a config with transformer activations enabled (gelu, silu).
    #[must_use]
    pub fn transformer_only() -> Self {
        Self {
            enable_gelu: true,
            enable_silu: true,
            ..Self::default()
        }
    }

    /// Check if any LUT activation is enabled.
    #[must_use]
    pub fn is_active(&self) -> bool {
        self.enable_sigmoid
            || self.enable_tanh
            || self.enable_exp
            || self.enable_log
            || self.enable_relu
            || self.enable_sqrt
            || self.enable_abs
            || self.enable_gelu
            || self.enable_silu
    }
}

/// Check if a dtype is quantized (suitable for LUT-based operations).
fn is_quantized_dtype(dtype: DType) -> bool {
    matches!(dtype, DType::U8 | DType::I8)
}

/// Run the activation LUT fusion pass.
///
/// Scans the graph for activation functions with quantized inputs and marks
/// them for LUT-based execution.
///
/// # Arguments
///
/// * `graph` - The compilation graph to transform
/// * `config` - Activation LUT configuration
///
/// # Returns
///
/// Number of activation nodes marked for LUT execution.
pub fn activation_lut_fusion(graph: &mut CompileGraph, config: &ActivationLutConfig) -> usize {
    // Early exit if no LUT activations are enabled
    if !config.is_active() {
        return 0;
    }

    let mut marked_count = 0;

    // Collect candidate nodes (we can't modify while iterating)
    let candidates: Vec<(u32, String)> = graph
        .nodes()
        .filter_map(|(id, node)| {
            // Check if this is an activation we can convert
            let activation_type = match &node.op {
                OpKind::Sigmoid if config.enable_sigmoid => "sigmoid",
                OpKind::Tanh if config.enable_tanh => "tanh",
                OpKind::Exp if config.enable_exp => "exp",
                OpKind::Log if config.enable_log => "log",
                OpKind::Relu if config.enable_relu => "relu",
                OpKind::Sqrt if config.enable_sqrt => "sqrt",
                OpKind::Abs if config.enable_abs => "abs",
                OpKind::Gelu if config.enable_gelu => "gelu",
                OpKind::Silu if config.enable_silu => "silu",
                _ => return None,
            };

            // Check if input is quantized
            let preds = graph.predecessors(id);
            if preds.is_empty() {
                return None;
            }

            let input_node = graph.get_node(preds[0])?;
            if !is_quantized_dtype(input_node.dtype) {
                return None;
            }

            // This activation can use LUT
            Some((id, format!("activation_lut:{activation_type}")))
        })
        .collect();

    // Apply annotations
    for (node_id, annotation) in candidates {
        graph.add_annotation(node_id, annotation);
        marked_count += 1;
    }

    marked_count
}

/// Parse an activation LUT annotation and return the activation type.
///
/// Returns `Some("sigmoid")`, `Some("tanh")`, `Some("exp")`, `Some("log")`,
/// `Some("relu")`, `Some("sqrt")`, `Some("abs")`, `Some("gelu")`, or `Some("silu")`
/// if the annotation matches, `None` otherwise.
#[must_use]
pub fn parse_activation_lut_annotation(annotation: &str) -> Option<&str> {
    annotation.strip_prefix("activation_lut:").filter(|s| {
        matches!(
            *s,
            "sigmoid" | "tanh" | "exp" | "log" | "relu" | "sqrt" | "abs" | "gelu" | "silu"
        )
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{OpNode, OperationGraph};

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    #[test]
    fn test_config_default() {
        let config = ActivationLutConfig::default();
        assert!(!config.enable_sigmoid);
        assert!(!config.enable_tanh);
        assert!(!config.enable_exp);
        assert!(!config.enable_log);
        assert!(!config.enable_relu);
        assert!(!config.enable_sqrt);
        assert!(!config.enable_abs);
        assert!(!config.is_active());
    }

    #[test]
    fn test_config_enabled() {
        let config = ActivationLutConfig::enabled();
        assert!(config.enable_sigmoid);
        assert!(config.enable_tanh);
        assert!(config.enable_exp);
        assert!(config.enable_log);
        assert!(config.enable_relu);
        assert!(config.enable_sqrt);
        assert!(config.enable_abs);
        assert!(config.is_active());
    }

    #[test]
    fn test_config_sigmoid_only() {
        let config = ActivationLutConfig::sigmoid_only();
        assert!(config.enable_sigmoid);
        assert!(!config.enable_tanh);
        assert!(config.is_active());
    }

    #[test]
    fn test_config_tanh_only() {
        let config = ActivationLutConfig::tanh_only();
        assert!(!config.enable_sigmoid);
        assert!(config.enable_tanh);
        assert!(config.is_active());
    }

    #[test]
    fn test_disabled_config_no_changes() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Sigmoid, vec![256], DType::U8),
                OpNode::new(2, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let config = ActivationLutConfig::default();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 0);
    }

    #[test]
    fn test_f32_sigmoid_not_marked() {
        // F32 data should not trigger LUT activation
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::F32),
                OpNode::new(1, OpKind::Sigmoid, vec![256], DType::F32),
                OpNode::new(2, OpKind::Output, vec![256], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 0);
    }

    #[test]
    fn test_u8_sigmoid_marked() {
        // U8 Sigmoid should be marked for LUT
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Sigmoid, vec![256], DType::U8),
                OpNode::new(2, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 1);

        // Check annotation
        let annotations = graph.get_annotations(1).unwrap();
        assert!(annotations.iter().any(|a| a == "activation_lut:sigmoid"));
    }

    #[test]
    fn test_i8_tanh_marked() {
        // I8 Tanh should be marked for LUT
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::I8),
                OpNode::new(1, OpKind::Tanh, vec![256], DType::I8),
                OpNode::new(2, OpKind::Output, vec![256], DType::I8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 1);

        // Check annotation
        let annotations = graph.get_annotations(1).unwrap();
        assert!(annotations.iter().any(|a| a == "activation_lut:tanh"));
    }

    #[test]
    fn test_multiple_activations_marked() {
        // Multiple quantized activations
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Sigmoid, vec![256], DType::U8),
                OpNode::new(2, OpKind::Tanh, vec![256], DType::U8),
                OpNode::new(3, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2), (2, 3)],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 2);
    }

    #[test]
    fn test_u8_relu_marked() {
        // U8 ReLU should be marked for LUT
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Relu, vec![256], DType::U8),
                OpNode::new(2, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 1);

        let annotations = graph.get_annotations(1).unwrap();
        assert!(annotations.iter().any(|a| a == "activation_lut:relu"));
    }

    #[test]
    fn test_u8_exp_marked() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Exp, vec![256], DType::U8),
                OpNode::new(2, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 1);

        let annotations = graph.get_annotations(1).unwrap();
        assert!(annotations.iter().any(|a| a == "activation_lut:exp"));
    }

    #[test]
    fn test_u8_log_marked() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Log, vec![256], DType::U8),
                OpNode::new(2, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 1);

        let annotations = graph.get_annotations(1).unwrap();
        assert!(annotations.iter().any(|a| a == "activation_lut:log"));
    }

    #[test]
    fn test_u8_sqrt_marked() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Sqrt, vec![256], DType::U8),
                OpNode::new(2, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 1);

        let annotations = graph.get_annotations(1).unwrap();
        assert!(annotations.iter().any(|a| a == "activation_lut:sqrt"));
    }

    #[test]
    fn test_u8_abs_marked() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Abs, vec![256], DType::U8),
                OpNode::new(2, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 1);

        let annotations = graph.get_annotations(1).unwrap();
        assert!(annotations.iter().any(|a| a == "activation_lut:abs"));
    }

    #[test]
    fn test_all_lut_activations_marked() {
        // Test a chain of all LUT-able activations
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Sigmoid, vec![256], DType::U8),
                OpNode::new(2, OpKind::Tanh, vec![256], DType::U8),
                OpNode::new(3, OpKind::Exp, vec![256], DType::U8),
                OpNode::new(4, OpKind::Log, vec![256], DType::U8),
                OpNode::new(5, OpKind::Relu, vec![256], DType::U8),
                OpNode::new(6, OpKind::Sqrt, vec![256], DType::U8),
                OpNode::new(7, OpKind::Abs, vec![256], DType::U8),
                OpNode::new(8, OpKind::Output, vec![256], DType::U8),
            ],
            vec![
                (0, 1),
                (1, 2),
                (2, 3),
                (3, 4),
                (4, 5),
                (5, 6),
                (6, 7),
                (7, 8),
            ],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 7); // All 7 activations marked
    }

    #[test]
    fn test_parse_activation_lut_annotation() {
        assert_eq!(
            parse_activation_lut_annotation("activation_lut:sigmoid"),
            Some("sigmoid")
        );
        assert_eq!(
            parse_activation_lut_annotation("activation_lut:tanh"),
            Some("tanh")
        );
        assert_eq!(
            parse_activation_lut_annotation("activation_lut:exp"),
            Some("exp")
        );
        assert_eq!(
            parse_activation_lut_annotation("activation_lut:log"),
            Some("log")
        );
        assert_eq!(
            parse_activation_lut_annotation("activation_lut:relu"),
            Some("relu")
        );
        assert_eq!(
            parse_activation_lut_annotation("activation_lut:sqrt"),
            Some("sqrt")
        );
        assert_eq!(
            parse_activation_lut_annotation("activation_lut:abs"),
            Some("abs")
        );
        assert_eq!(
            parse_activation_lut_annotation("activation_lut:gelu"),
            Some("gelu")
        );
        assert_eq!(
            parse_activation_lut_annotation("activation_lut:silu"),
            Some("silu")
        );
        assert_eq!(
            parse_activation_lut_annotation("activation_lut:unknown"),
            None
        );
        assert_eq!(parse_activation_lut_annotation("lut_gemm:4:5:6"), None);
        assert_eq!(parse_activation_lut_annotation("other"), None);
    }

    #[test]
    fn test_activations_only_config() {
        let config = ActivationLutConfig::activations_only();
        assert!(config.enable_sigmoid);
        assert!(config.enable_tanh);
        assert!(config.enable_relu);
        assert!(!config.enable_exp);
        assert!(!config.enable_log);
        assert!(!config.enable_sqrt);
        assert!(!config.enable_abs);
        assert!(config.is_active());
    }

    #[test]
    fn test_math_only_config() {
        let config = ActivationLutConfig::math_only();
        assert!(!config.enable_sigmoid);
        assert!(!config.enable_tanh);
        assert!(!config.enable_relu);
        assert!(config.enable_exp);
        assert!(config.enable_log);
        assert!(config.enable_sqrt);
        assert!(config.enable_abs);
        assert!(config.is_active());
    }

    #[test]
    fn test_sigmoid_only_config() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Sigmoid, vec![256], DType::U8),
                OpNode::new(2, OpKind::Tanh, vec![256], DType::U8),
                OpNode::new(3, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2), (2, 3)],
        );

        let config = ActivationLutConfig::sigmoid_only();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 1); // Only Sigmoid marked

        assert!(graph
            .get_annotations(1)
            .unwrap()
            .iter()
            .any(|a| a == "activation_lut:sigmoid"));
        assert!(graph.get_annotations(2).unwrap().is_empty());
    }

    #[test]
    fn test_transformer_only_config() {
        let config = ActivationLutConfig::transformer_only();
        assert!(!config.enable_sigmoid);
        assert!(!config.enable_tanh);
        assert!(!config.enable_relu);
        assert!(!config.enable_exp);
        assert!(!config.enable_log);
        assert!(!config.enable_sqrt);
        assert!(!config.enable_abs);
        assert!(config.enable_gelu);
        assert!(config.enable_silu);
        assert!(config.is_active());
    }

    #[test]
    fn test_u8_gelu_marked() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Gelu, vec![256], DType::U8),
                OpNode::new(2, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 1);

        let annotations = graph.get_annotations(1).unwrap();
        assert!(annotations.iter().any(|a| a == "activation_lut:gelu"));
    }

    #[test]
    fn test_u8_silu_marked() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Silu, vec![256], DType::U8),
                OpNode::new(2, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 1);

        let annotations = graph.get_annotations(1).unwrap();
        assert!(annotations.iter().any(|a| a == "activation_lut:silu"));
    }

    #[test]
    fn test_all_lut_activations_including_transformer() {
        // Test with all 9 LUT activations including gelu/silu
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Sigmoid, vec![256], DType::U8),
                OpNode::new(2, OpKind::Tanh, vec![256], DType::U8),
                OpNode::new(3, OpKind::Exp, vec![256], DType::U8),
                OpNode::new(4, OpKind::Log, vec![256], DType::U8),
                OpNode::new(5, OpKind::Relu, vec![256], DType::U8),
                OpNode::new(6, OpKind::Sqrt, vec![256], DType::U8),
                OpNode::new(7, OpKind::Abs, vec![256], DType::U8),
                OpNode::new(8, OpKind::Gelu, vec![256], DType::U8),
                OpNode::new(9, OpKind::Silu, vec![256], DType::U8),
                OpNode::new(10, OpKind::Output, vec![256], DType::U8),
            ],
            vec![
                (0, 1),
                (1, 2),
                (2, 3),
                (3, 4),
                (4, 5),
                (5, 6),
                (6, 7),
                (7, 8),
                (8, 9),
                (9, 10),
            ],
        );

        let config = ActivationLutConfig::enabled();
        let count = activation_lut_fusion(&mut graph, &config);
        assert_eq!(count, 9); // All 9 activations marked
    }
}
