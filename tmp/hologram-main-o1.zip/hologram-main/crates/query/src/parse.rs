//! nom parser for the query language.
//!
//! Supports a strict GraphQL subset:
//! ```text
//! query { byte(value: 42) { stratum, curvature, torus { page, offset } } }
//! query { ring(value: 50) { add(other: 10), sub(other: 5) } }
//! mutation { translate(domain: byte, value: 42, op: add, by: 10) { value, stratum } }
//! ```

use nom::{
    branch::alt,
    bytes::complete::{tag, take_while, take_while1},
    character::complete::{char, multispace0},
    combinator::{map, opt, recognize},
    multi::separated_list0,
    sequence::{delimited, pair, preceded, tuple},
    IResult,
};

use crate::ast::*;

// ============================================================================
// Whitespace
// ============================================================================

fn ws(input: &str) -> IResult<&str, ()> {
    let (input, _) = multispace0(input)?;
    let mut rest = input;
    loop {
        let (r, _) = multispace0(rest)?;
        if r.starts_with('#') {
            let nl = r.find('\n').unwrap_or(r.len());
            rest = &r[nl..];
        } else {
            return Ok((r, ()));
        }
    }
}

fn wsp<'a, O, F>(f: F) -> impl FnMut(&'a str) -> IResult<&'a str, O>
where
    F: FnMut(&'a str) -> IResult<&'a str, O>,
{
    preceded(ws, f)
}

// ============================================================================
// Identifiers and literals
// ============================================================================

fn ident(input: &str) -> IResult<&str, &str> {
    recognize(pair(
        take_while1(|c: char| c.is_ascii_alphabetic() || c == '_'),
        take_while(|c: char| c.is_ascii_alphanumeric() || c == '_'),
    ))(input)
}

fn integer(input: &str) -> IResult<&str, i64> {
    let (rest, neg) = opt(char('-'))(input)?;
    let (rest, digits) = take_while1(|c: char| c.is_ascii_digit())(rest)?;
    let val: i64 = digits.parse().map_err(|_| {
        nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Digit))
    })?;
    Ok((rest, if neg.is_some() { -val } else { val }))
}

fn quoted_string(input: &str) -> IResult<&str, String> {
    let (rest, _) = char('"')(input)?;
    let (rest, s) = take_while(|c: char| c != '"')(rest)?;
    let (rest, _) = char('"')(rest)?;
    Ok((rest, s.to_string()))
}

// ============================================================================
// Values
// ============================================================================

fn query_value(input: &str) -> IResult<&str, QueryValue> {
    let (input, _) = ws(input)?;
    alt((
        map(integer, QueryValue::Int),
        map(quoted_string, QueryValue::Str),
        map(list_value, QueryValue::List),
        map(ident, |s: &str| QueryValue::Ident(s.to_string())),
    ))(input)
}

fn list_value(input: &str) -> IResult<&str, Vec<QueryValue>> {
    delimited(
        char('['),
        separated_list0(wsp(char(',')), query_value),
        wsp(char(']')),
    )(input)
}

// ============================================================================
// Arguments
// ============================================================================

fn argument(input: &str) -> IResult<&str, (String, QueryValue)> {
    let (rest, (name, _, _, _, val)) = tuple((wsp(ident), ws, char(':'), ws, query_value))(input)?;
    Ok((rest, (name.to_string(), val)))
}

fn arguments(input: &str) -> IResult<&str, Vec<(String, QueryValue)>> {
    delimited(
        char('('),
        separated_list0(wsp(char(',')), argument),
        wsp(char(')')),
    )(input)
}

// ============================================================================
// Selections
// ============================================================================

fn selection(input: &str) -> IResult<&str, Selection> {
    let (rest, name) = wsp(ident)(input)?;
    let (rest, args) = opt(arguments)(rest)?;
    let (rest, children) = opt(selection_set)(rest)?;
    Ok((
        rest,
        Selection {
            field: name.to_string(),
            arguments: args.unwrap_or_default(),
            children: children.unwrap_or_default(),
        },
    ))
}

fn selection_set(input: &str) -> IResult<&str, Vec<Selection>> {
    delimited(
        wsp(char('{')),
        separated_list0(wsp(char(',')), selection),
        wsp(char('}')),
    )(input)
}

// ============================================================================
// Document
// ============================================================================

fn op_type(input: &str) -> IResult<&str, OpType> {
    alt((
        map(tag("query"), |_| OpType::Query),
        map(tag("mutation"), |_| OpType::Mutation),
    ))(input)
}

fn document(input: &str) -> IResult<&str, Document> {
    let (rest, op) = wsp(op_type)(input)?;
    let (rest, selections) = selection_set(rest)?;
    let (rest, _) = ws(rest)?;
    Ok((rest, Document { op, selections }))
}

/// Parse a query string into a [`Document`].
pub fn parse(input: &str) -> Result<Document, String> {
    match document(input) {
        Ok(("", doc)) => Ok(doc),
        Ok((rest, _)) => Err(format!("unexpected trailing input: {rest:?}")),
        Err(e) => Err(format!("parse error: {e}")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_simple_query() {
        let doc = parse("query { byte(value: 42) { stratum, curvature } }").unwrap();
        assert_eq!(doc.op, OpType::Query);
        assert_eq!(doc.selections.len(), 1);
        assert_eq!(doc.selections[0].field, "byte");
        assert_eq!(doc.selections[0].children.len(), 2);
        assert_eq!(doc.selections[0].children[0].field, "stratum");
        assert_eq!(doc.selections[0].children[1].field, "curvature");
    }

    #[test]
    fn parse_nested_selection() {
        let doc = parse("query { byte(value: 0) { stratum, torus { page, offset } } }").unwrap();
        let byte = &doc.selections[0];
        assert_eq!(byte.children.len(), 2);
        let torus = &byte.children[1];
        assert_eq!(torus.field, "torus");
        assert_eq!(torus.children.len(), 2);
        assert_eq!(torus.children[0].field, "page");
    }

    #[test]
    fn parse_parameterized_field() {
        let doc = parse("query { ring(value: 50) { add(other: 10) } }").unwrap();
        let ring = &doc.selections[0];
        let add = &ring.children[0];
        assert_eq!(add.field, "add");
        assert_eq!(add.arguments.len(), 1);
        assert_eq!(add.arguments[0].0, "other");
        assert_eq!(add.arguments[0].1, QueryValue::Int(10));
    }

    #[test]
    fn parse_mutation() {
        let doc = parse(
            "mutation { translate(domain: byte, value: 42, op: add, by: 10) { value, stratum } }",
        )
        .unwrap();
        assert_eq!(doc.op, OpType::Mutation);
        let t = &doc.selections[0];
        assert_eq!(t.field, "translate");
        assert_eq!(t.arguments.len(), 4);
    }

    #[test]
    fn parse_multiple_root_selections() {
        let doc =
            parse("query { byte(value: 1) { stratum }, byte(value: 2) { curvature } }").unwrap();
        assert_eq!(doc.selections.len(), 2);
    }

    #[test]
    fn parse_string_arg() {
        let doc = parse("query { byte(value: 42) { domain } }").unwrap();
        let byte = &doc.selections[0];
        assert_eq!(byte.arguments[0].1, QueryValue::Int(42));
    }

    #[test]
    fn parse_negative_int() {
        let doc = parse("query { byte(value: -1) { stratum } }").unwrap();
        assert_eq!(doc.selections[0].arguments[0].1, QueryValue::Int(-1));
    }

    #[test]
    fn parse_ident_arg() {
        let doc =
            parse("mutation { translate(domain: byte, value: 10, op: add, by: 5) { value } }")
                .unwrap();
        let t = &doc.selections[0];
        assert_eq!(t.arguments[0].1, QueryValue::Ident("byte".into()));
        assert_eq!(t.arguments[2].1, QueryValue::Ident("add".into()));
    }

    #[test]
    fn parse_error_no_op() {
        assert!(parse("{ byte(value: 1) { stratum } }").is_err());
    }

    #[test]
    fn parse_error_trailing() {
        assert!(parse("query { byte(value: 1) { stratum } } extra").is_err());
    }

    #[test]
    fn parse_comments_ignored() {
        let doc = parse("# fetch a byte\nquery {\n  # the byte\n  byte(value: 42) { stratum }\n}")
            .unwrap();
        assert_eq!(doc.selections[0].field, "byte");
    }

    #[test]
    fn parse_no_args_leaf() {
        let doc = parse("query { byte(value: 0) { stratum } }").unwrap();
        assert!(doc.selections[0].children[0].arguments.is_empty());
    }

    #[test]
    fn parse_all_byte_fields() {
        let doc = parse(
            "query { byte(value: 100) { stratum, curvature, domain, orbit_class, torus { page, offset } } }",
        )
        .unwrap();
        let byte = &doc.selections[0];
        assert_eq!(byte.children.len(), 5);
    }

    #[test]
    fn parse_list_value() {
        let doc = parse("query { byte(value: 42, extra: [1, 2, 3]) { stratum } }").unwrap();
        let args = &doc.selections[0].arguments;
        assert_eq!(args[1].0, "extra");
        assert_eq!(
            args[1].1,
            QueryValue::List(vec![
                QueryValue::Int(1),
                QueryValue::Int(2),
                QueryValue::Int(3),
            ])
        );
    }

    #[test]
    fn parse_quoted_string() {
        let doc = parse("query { byte(name: \"hello\") { stratum } }").unwrap();
        assert_eq!(
            doc.selections[0].arguments[0].1,
            QueryValue::Str("hello".into())
        );
    }
}
