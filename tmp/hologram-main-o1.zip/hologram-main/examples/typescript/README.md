# UOR TypeScript WASM Bindings Examples

TypeScript examples demonstrating UOR WASM bindings with full type safety.

## Prerequisites

- Node.js 18+
- TypeScript 5.3+
- Modern web browser (for web example)

## WASM Targets

UOR provides three WASM build targets:

| Target | Package | Use Case |
|--------|---------|----------|
| **bundler** | `uor` | Webpack, Vite, Rollup, etc. |
| **web** | `uor-web` | Direct browser usage (no bundler) |
| **nodejs** | `uor-node` | Node.js/TypeScript applications |

## Building

Build all WASM targets:

```bash
just ffi-wasm
```

Or build individually:

```bash
just ffi-wasm-bundler  # For bundlers (webpack, vite)
just ffi-wasm-web      # For browsers (no bundler)
just ffi-wasm-node     # For Node.js/TypeScript
```

## Setup

Install TypeScript dependencies:

```bash
cd examples/typescript
npm install
```

## Running Examples

### TypeScript Example

```bash
just ffi-wasm-node
cd examples/typescript
npm run example
```

### TypeScript Benchmark

```bash
just ffi-wasm-node
cd examples/typescript
npm run bench
```

### Web Browser

```bash
just ffi-wasm-web
cd /workspace
python3 -m http.server 8000
# Open http://localhost:8000/examples/typescript/example-web.html
```

## TypeScript API

All WASM bindings include TypeScript definitions (`.d.ts` files) for full type safety.

### Node.js TypeScript

See [example-node.ts](example-node.ts) and [bench-node.ts](bench-node.ts).

```typescript
import * as uor from '../../bindings/wasm/nodejs/uor_ffi.js';

// Full type safety with TypeScript
const braille: string = uor.wasm_byte_to_braille(42);
const codepoint: number = uor.wasm_byte_to_codepoint(42);
const domain: number = uor.wasm_byte_to_domain(42);
const rank: number = uor.wasm_byte_rank(42);

// Typed classes
const view: uor.WasmView = new uor.WasmView();
const result: number = view.apply(42);
view.free();
```

### Compilation

```bash
# Install dependencies (once)
npm install

# Compile TypeScript to JavaScript
npm run build

# Run compiled code
node dist/example-node.js

# Or use the npm scripts
npm run example  # Builds and runs example
npm run bench    # Builds and runs benchmark
```

## Memory Management

**Important**: WASM requires manual memory management for objects.

```typescript
const view: uor.WasmView = new uor.WasmView();
try {
    const result: number = view.apply(42);
    console.log(result);
} finally {
    // Always free WASM objects!
    view.free();
}
```

Scalar values (numbers, strings) are automatically managed.

## API Functions

All functions are fully typed:

### Constants

```typescript
uor.braille_base(): number       // 0x2800
uor.braille_max(): number        // 0x28FF
uor.triadic_constant(): number   // 3
uor.octave_constant(): number    // 8
uor.state_taxons(): number       // 624
uor.state_bits(): number         // 4992
```

### Taxon Operations

```typescript
uor.wasm_byte_to_braille(value: number): string
uor.wasm_byte_to_codepoint(value: number): number
uor.wasm_byte_to_domain(value: number): number
uor.wasm_byte_rank(value: number): number
```

### Ring Operations

```typescript
uor.wasm_byte_succ(value: number): number
uor.wasm_byte_pred(value: number): number
uor.wasm_byte_not(value: number): number
```

### View Operations

```typescript
class WasmView {
    constructor();                              // Identity view
    static constant(value: number): WasmView;   // Constant view

    apply(byte_value: number): number;
    applySlice(input: Uint8Array): Uint8Array;
    then(other: WasmView): WasmView;
    inverse(): WasmView;
    isBijective(): boolean;
    table(): Uint8Array;

    free(): void;  // MUST call when done!
}
```

## Features Demonstrated

All examples demonstrate:

- ✅ **Type Safety**: Full TypeScript types for all APIs
- ✅ **Constants**: Braille codepoints, triadic/octave constants
- ✅ **Taxon Operations**: Byte transformations with type checking
- ✅ **Ring Operations**: Algebraic operations
- ✅ **View Operations**: Functional composition with types
- ✅ **Array Operations**: Batch processing with `Uint8Array`
- ✅ **Memory Management**: Proper `free()` calls

## Benchmarks

TypeScript benchmarks measure FFI call overhead:

```bash
npm run bench
```

Expected performance:
- Simple operations: ~5ns per call (200M calls/sec)
- String operations: ~90ns per call (11M calls/sec)
- Batch operations: >1GB/sec throughput

Results on your machine may vary based on CPU and Node.js version.

## Example Output

```
=== UOR WASM (Node.js) Bindings Example ===

Constants:
  Braille Base: U+2800
  Braille Max:  U+28FF
  Triadic (T):  3
  Octave (O):   8
  State Taxons: 624
  State Bits:   4992

Taxon Operations:
  Byte 42 -> Braille: ⠪
  Byte 42 -> Codepoint: U+282A
  Byte 42 -> Domain: 0
  Byte 42 -> Rank: 14

Ring Operations:
  Byte 42 -> Successor: 43
  Byte 42 -> Predecessor: 41
  Byte 42 -> NOT: 213

View Operations:
  Created identity view
  Identity(42) = 42
  Constant(42) = 99
  Constant view is bijective: false
  Identity.then(Identity)(42) = 42

  Applying identity view to array...
  Input:  [0, 1, 2, 3, 4, 5, 6, 7]
  Output: [0, 1, 2, 3, 4, 5, 6, 7]

=== All tests completed successfully! ===
```

## Publishing

WASM packages are ready for npm:

```bash
# Publish bundler version
just publish-wasm-bundler

# Publish web version
just publish-wasm-web

# Publish Node.js version
just publish-wasm-node

# Or publish all
just publish-wasm
```

## Type Definitions

TypeScript definitions are automatically included in all WASM packages:

- `bindings/wasm/nodejs/uor_ffi.d.ts` - Node.js types
- `bindings/wasm/web/uor_ffi.d.ts` - Web types
- `bindings/wasm/bundler/uor_ffi.d.ts` - Bundler types

Your editor (VS Code, etc.) will provide full autocomplete and type checking.
