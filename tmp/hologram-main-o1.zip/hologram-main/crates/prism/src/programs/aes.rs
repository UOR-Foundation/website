//! AES encryption operations.
//!
//! Delegates to UOR wavefront AES programs via the appropriate
//! executor for the current architecture.
//!
//! ```
//! use prism::state::State;
//! use prism::programs::aes::aes128_encrypt;
//!
//! let mut s = State::zeros();
//! aes128_encrypt(&mut s);
//! ```

use crate::state::State;
use uor::UorStep;

/// Execute AES-128 encryption (10 rounds).
///
/// ```
/// use prism::state::State;
/// use prism::programs::aes::aes128_encrypt;
///
/// let mut s = State::from_bytes(&[0x42; 624]);
/// aes128_encrypt(&mut s);
/// ```
pub fn aes128_encrypt(state: &mut State) {
    let program = uor::wavefront::aes128_encrypt_program();
    run_program(state, &program);
}

/// Execute AES-256 encryption (14 rounds).
///
/// ```
/// use prism::state::State;
/// use prism::programs::aes::aes256_encrypt;
///
/// let mut s = State::from_bytes(&[0x42; 624]);
/// aes256_encrypt(&mut s);
/// ```
pub fn aes256_encrypt(state: &mut State) {
    let program = uor::wavefront::aes256_encrypt_program();
    run_program(state, &program);
}

#[cfg(target_arch = "x86_64")]
fn run_program(state: &mut State, program: &[uor::Wavefront]) {
    if let Some(executor) = try_zen3() {
        unsafe { executor.run(state.inner_mut(), program) };
    } else {
        let executor = uor::ScalarExecutor::new();
        unsafe { executor.run(state.inner_mut(), program) };
    }
}

#[cfg(not(target_arch = "x86_64"))]
fn run_program(state: &mut State, program: &[uor::Wavefront]) {
    let executor = uor::ScalarExecutor::new();
    unsafe { executor.run(state.inner_mut(), program) };
}

#[cfg(target_arch = "x86_64")]
fn try_zen3() -> Option<uor::Zen3Executor> {
    if std::is_x86_feature_detected!("avx2")
        && std::is_x86_feature_detected!("sha")
        && std::is_x86_feature_detected!("aes")
    {
        Some(uor::Zen3Executor::new())
    } else {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_aes128_encrypt_runs() {
        let mut s = State::zeros();
        aes128_encrypt(&mut s);
    }

    #[test]
    fn test_aes256_encrypt_runs() {
        let mut s = State::zeros();
        aes256_encrypt(&mut s);
    }

    #[test]
    fn test_aes128_from_data() {
        let mut s = State::from_bytes(&[0xAB; 624]);
        aes128_encrypt(&mut s);
    }

    #[test]
    fn test_aes256_from_data() {
        let mut s = State::from_bytes(&[0xCD; 624]);
        aes256_encrypt(&mut s);
    }
}
