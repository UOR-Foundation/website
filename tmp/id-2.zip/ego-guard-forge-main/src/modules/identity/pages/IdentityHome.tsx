/**
 * IdentityHome — Smart router for the identity flow.
 *
 * - Not authenticated → redirect to /identity/create (auth screen)
 * - Authenticated + no profile → redirect to /identity/create (naming)
 * - Authenticated + profile → redirect to /identity/explore (dashboard)
 */

import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/use-auth";

export default function IdentityHome() {
  const navigate = useNavigate();
  const { session, profile, loading } = useAuth();

  useEffect(() => {
    if (loading) return;

    if (!session) {
      // Not logged in → show auth flow
      navigate("/identity/create", { replace: true });
    } else if (!profile) {
      // Logged in but no profile → show naming
      navigate("/identity/create", { replace: true });
    } else {
      // Logged in with profile → go to myspace
      navigate("/identity/explore", { replace: true });
    }
  }, [loading, session, profile, navigate]);

  // Brief loading state while checking auth
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );
}
