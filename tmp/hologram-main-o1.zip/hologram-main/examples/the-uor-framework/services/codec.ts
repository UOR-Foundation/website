import { BASE_96_CHARS } from '../constants';
import { EncodedArtifact } from '../types';

/**
 * Categorical X Codec Implementation
 * 
 * Implements a bijective Mixed Radix System (MRS) encoding/decoding.
 * Base: 96 (Printable ASCII).
 * Hierarchy: Defined by sequential prime scalings (Gauge Levels).
 * 
 * This ensures that any arbitrary length string can be:
 * 1. Mapped to a unique integer (BigInt).
 * 2. Decomposed into a unique set of hierarchical coordinates (residues).
 * 3. Reconstructed perfectly (Bijective).
 */

// --- MATH UTILITIES ---

export const gcd = (a: bigint, b: bigint): bigint => {
  while (b > 0n) {
    let t = b;
    b = a % b;
    a = t;
  }
  return a;
};

export const abs = (n: bigint): bigint => (n < 0n ? -n : n);

/**
 * Generates a cryptographically strong random BigInt of a specified bit length.
 * Removes dependency on Math.random() (53-bit limit) for arbitrary scale operations.
 */
export const randomBigInt = (bits: number): bigint => {
    // Calculate required bytes
    const byteCount = Math.ceil(bits / 8);
    const buffer = new Uint8Array(byteCount);
    // Use Web Crypto API for uniform distribution
    crypto.getRandomValues(buffer);
    
    let result = 0n;
    for (let i = 0; i < byteCount; i++) {
        result = (result << 8n) | BigInt(buffer[i]);
    }
    
    // Mask to ensure exact bit length fit
    const mask = (1n << BigInt(bits)) - 1n;
    return result & mask;
};

/**
 * Real factorization implementation using Pollard's Rho algorithm.
 * Solves N = P * Q for the demo.
 */
export const factorizeSemiprime = (n: bigint): { p: bigint, q: bigint } | null => {
    // 1. Handle small cases / even numbers
    if (n <= 3n) return null;
    if (n % 2n === 0n) return { p: 2n, q: n / 2n };
    
    // 2. Trial Division for small factors (speed optimization for demo)
    // Helps if the random generator picked a small prime
    const limit = 1000n;
    for(let i=3n; i < limit && i * i <= n; i+=2n) {
        if (n % i === 0n) return { p: i, q: n/i };
    }

    // 3. Pollard's Rho Algorithm
    // A probabilistic algorithm that is very effective for finding small non-trivial factors
    let x = 2n;
    let y = 2n;
    let d = 1n;
    let c = 1n;
    
    const f = (val: bigint) => (val * val + c) % n;

    // We limit iterations to prevent browser freeze on very large primes in the main thread
    // For 64-bit semiprimes this is usually instantaneous.
    let iterations = 0;
    const maxIterations = 50000; 

    while (d === 1n && iterations < maxIterations) {
        x = f(x);
        y = f(f(y));
        d = gcd(abs(x - y), n);
        iterations++;
        
        // If we cycle or fail, try a different constant 'c'
        if (d === n) { 
             d = 1n;
             c += 1n;
             x = 2n;
             y = 2n;
             // Safety break if we try too many polynomials
             if (c > 7n) break;
        }
    }

    if (d !== 1n && d !== n) {
        const q = n / d;
        return { p: d < q ? d : q, q: d < q ? q : d };
    }
    
    return null; // Could not factorize within the interactive time budget
};

/**
 * Arbitrary Precision Z-Order Curve (Morton Code).
 * Interleaves bits of two BigInts to create a single hierarchical index.
 * Supports coordinates far exceeding 32-bit limits.
 */
export const interleaveBigIntBits = (x: bigint, y: bigint): bigint => {
    let z = 0n;
    let shift = 0n;
    let tempX = x;
    let tempY = y;
    
    // Iterate until both numbers are consumed
    while (tempX > 0n || tempY > 0n) {
        const xBit = tempX & 1n;
        const yBit = tempY & 1n;
        
        z |= (xBit << shift);
        z |= (yBit << (shift + 1n));
        
        tempX >>= 1n;
        tempY >>= 1n;
        shift += 2n;
    }
    return z;
};

// --- CODEC IMPLEMENTATION ---

// Helper: Prime Generator
function* primeGenerator() {
  yield 5; // Level 1 scale
  yield 7; // Level 2 scale
  yield 11;
  yield 13;
  yield 17;
  yield 19;
  yield 23;
  yield 29;
  yield 31;
  yield 37;
  yield 41;
  yield 43;
  yield 47;
  yield 53;
  // Dynamic continuation
  let n = 55;
  while (true) {
    let isPrime = true;
    for (let i = 2; i * i <= n; i++) {
      if (n % i === 0) {
        isPrime = false;
        break;
      }
    }
    if (isPrime) yield n;
    n += 2;
  }
}

export const getModulusAtLevel = (level: number): bigint => {
    if (level === 0) return 96n;
    const gen = primeGenerator();
    let p = 0;
    for(let i=1; i<=level; i++) {
        p = gen.next().value as number;
    }
    return BigInt(p);
};

export const getGaugeModuli = (count: number): bigint[] => {
    const moduli = [96n];
    const gen = primeGenerator();
    for(let i=1; i<count; i++) {
        moduli.push(BigInt(gen.next().value as number));
    }
    return moduli;
};

// Helper: String to BigInt (Base 96)
const stringToBigInt = (input: string): bigint => {
  let val = 0n;
  const base = 96n;
  for (let i = 0; i < input.length; i++) {
    const charCode = BigInt(BASE_96_CHARS.indexOf(input[i]));
    if (charCode === -1n) {
      val = val * base + BigInt(BASE_96_CHARS.indexOf('?'));
    } else {
      val = val * base + charCode;
    }
  }
  return val;
};

// Helper: BigInt to String (Base 96)
const bigIntToString = (val: bigint): string => {
  if (val === 0n) return ""; 
  let result = "";
  let current = val;
  const base = 96n;
  while (current > 0n) {
    const remainder = Number(current % base);
    result = BASE_96_CHARS[remainder] + result;
    current = current / base;
  }
  return result;
};

/**
 * Encodes a string into a Hierarchical Categorical X Artifact.
 * Performs a Mixed Radix Decomposition.
 */
export const encodeCategoricalX = (input: string): EncodedArtifact => {
  const bigIntRep = stringToBigInt(input);
  return encodeBigIntToCategoricalX(bigIntRep, input);
};

/**
 * Core encoding logic that works directly on BigInt.
 * This enables the framework to be used for pure numeric tasks (Factorization etc).
 */
export const encodeBigIntToCategoricalX = (val: bigint, originalLabel: string = "Numeric"): EncodedArtifact => {
  const coordinates: { level: number; phase: number; remainder: string; modulus: string }[] = [];
  
  // Level 0: Base 96
  let currentVal = val;
  const baseModulus = 96n;
  
  const r0 = currentVal % baseModulus;
  coordinates.push({
    level: 0,
    phase: 0, 
    remainder: r0.toString(), 
    modulus: "96"
  });
  
  currentVal = (currentVal - r0) / baseModulus;

  // Higher Levels: Prime factors
  const primes = primeGenerator();
  let level = 1;

  while (currentVal > 0n) {
    const p = BigInt(primes.next().value as number);
    const r = currentVal % p;
    
    coordinates.push({
      level: level,
      phase: Number(r), 
      remainder: r.toString(),
      modulus: p.toString()
    });

    currentVal = (currentVal - r) / p;
    level++;
  }

  // Verification
  const reconstructedBigInt = reconstructFromCoordinates(coordinates);
  const isBijective = reconstructedBigInt === val;

  return {
    original: originalLabel,
    bigIntRep: val.toString(),
    gaugeLevel: level - 1,
    gaugeIndex: 0,
    coordinates,
    verification: isBijective
  };
};

/**
 * Reconstructs the BigInt from the Mixed Radix coordinates.
 */
const reconstructFromCoordinates = (coords: { remainder: string; modulus: string }[]): bigint => {
  let value = 0n;
  let multiplier = 1n;

  for (let i = 0; i < coords.length; i++) {
    const digit = BigInt(coords[i].remainder);
    value += digit * multiplier;
    const mod = BigInt(coords[i].modulus);
    multiplier *= mod;
  }

  return value;
};

/**
 * Decodes a Categorical X BigInt representation back to string.
 */
export const decodeCategoricalX = (bigIntStr: string): string => {
  try {
    const val = BigInt(bigIntStr);
    return bigIntToString(val);
  } catch (e) {
    return "Error: Invalid Categorical Representation";
  }
};

/**
 * Runs a randomized test suite to mathematically prove bijectivity.
 */
export const runBijectivityTestSuite = (iterations: number = 100): { total: number, passed: number, failures: string[] } => {
    let passed = 0;
    const failures: string[] = [];
    
    const chars = BASE_96_CHARS;
    
    for(let i=0; i<iterations; i++) {
        // Generate random string of random length (1 to 50 chars)
        const len = Math.floor(Math.random() * 50) + 1;
        let testStr = "";
        for(let j=0; j<len; j++) {
            testStr += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        
        const artifact = encodeCategoricalX(testStr);
        const decoded = decodeCategoricalX(artifact.bigIntRep);
        
        if (decoded === testStr && artifact.verification) {
            passed++;
        } else {
            failures.push(testStr);
        }
    }
    
    return { total: iterations, passed, failures };
};
