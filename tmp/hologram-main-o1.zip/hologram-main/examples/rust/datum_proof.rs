//! Example: Q1 Datum Observable Proofs
//!
//! This example demonstrates the integration of generated `Datum16` types
//! with the derivation chain system to create certified proofs.
//!
//! Run with: `cargo run --example datum_proof`

use hologram::prelude::*;
use hologram::{datum_derivation_chain, emit_datum_proof, Datum16, Datum16Proof, CARDINALITY};

fn main() {
    println!("=== Q1 Datum Observable Proofs ===\n");

    // 1. Create a datum and compute its observables
    datum_observables();

    // 2. Generate a derivation proof
    derivation_proof();

    // 3. Batch processing
    batch_processing();

    // 4. Statistical analysis
    statistics();
}

/// Demonstrate datum observable computation.
fn datum_observables() {
    println!("1. Datum Observables");
    println!("--------------------");

    let values = [0x0000u16, 0x1234, 0xFFFF, 0xAAAA, 0x5555];

    for &value in &values {
        let datum = Datum16::from_value(value);
        println!(
            "  0x{:04X}: stratum={:2}, curvature={:2}, glyph='{}'",
            value,
            datum.stratum(),
            datum.curvature(),
            datum.glyph()
        );
    }
    println!();
}

/// Demonstrate derivation proof generation.
fn derivation_proof() {
    println!("2. Derivation Proof");
    println!("-------------------");

    let datum = Datum16::from_value(0x1234);
    let proof = Datum16Proof::new(datum);

    println!("  Value:     0x{:04X}", proof.value);
    println!("  Stratum:   {} (Hamming weight)", proof.stratum);
    println!("  Spectrum:  {:?} (bit positions)", proof.spectrum);
    println!("  Glyph:     '{}'", proof.glyph);
    println!("  Curvature: {} (distance to successor)", proof.curvature);
    println!("  Verified:  {}", proof.verify());

    // Generate full derivation chain
    let chain = datum_derivation_chain(datum, "2026-02-06T00:00:00Z");
    println!("  Steps:     {}", chain.steps.len());
    println!();
}

/// Demonstrate batch processing of datums.
fn batch_processing() {
    println!("3. Batch Processing");
    println!("-------------------");

    // Process all datums in stratum 8 (exactly 8 bits set)
    let stratum_8: Vec<u16> = (0..=65535u16)
        .filter(|&v| v.count_ones() == 8)
        .take(5) // Just first 5 for demo
        .collect();

    println!("  First 5 datums with stratum = 8:");
    for value in stratum_8 {
        let datum = Datum16::from_value(value);
        println!("    0x{:04X}: spectrum={:?}", value, datum.spectrum());
    }

    // Count datums by stratum (binomial distribution)
    let mut stratum_counts = [0u32; 17];
    for datum in all_q1_datums() {
        stratum_counts[datum.stratum() as usize] += 1;
    }

    println!("\n  Stratum distribution (binomial C(16,k)):");
    for (k, &count) in stratum_counts.iter().enumerate() {
        if count > 0 {
            println!("    Stratum {:2}: {:5} datums", k, count);
        }
    }
    println!();
}

/// Demonstrate statistical analysis.
fn statistics() {
    println!("4. Statistics");
    println!("-------------");

    // Compute mean curvature
    let total_curvature: u64 = all_q1_datums().map(|d| d.curvature() as u64).sum();
    let mean_curvature = total_curvature as f64 / CARDINALITY as f64;

    println!("  Total datums: {}", CARDINALITY);
    println!("  Mean curvature: {:.6}", mean_curvature);
    println!("  Expected: ~2.0 (theoretical)");

    // Find datums with maximum curvature
    let max_curvature = all_q1_datums().map(|d| d.curvature()).max().unwrap();

    let max_curvature_datums: Vec<u16> = all_q1_datums()
        .filter(|d| d.curvature() == max_curvature)
        .take(3)
        .map(|d| d.value)
        .collect();

    println!("  Max curvature: {}", max_curvature);
    println!(
        "  Examples: {:?}",
        max_curvature_datums
            .iter()
            .map(|v| format!("0x{:04X}", v))
            .collect::<Vec<_>>()
    );
    println!();

    // Emit a sample proof as JSON-LD
    println!("5. JSON-LD Output (sample)");
    println!("--------------------------");
    let datum = Datum16::from_value(0x1234);
    let json = emit_datum_proof(datum, "2026-02-06T00:00:00Z");
    let pretty = serde_json::to_string_pretty(&json).unwrap();

    // Show just the first 20 lines
    for (i, line) in pretty.lines().take(20).enumerate() {
        println!("  {}", line);
        if i == 19 {
            println!("  ... (truncated)");
        }
    }
}
