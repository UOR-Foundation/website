//! Shell DSL abstract syntax tree.
//!
//! A shell file declares typed domains — queryable namespaces with fields
//! bound to resolver functions. The same shell declarations generate both
//! query-layer resolvers and ISA-layer dispatch infrastructure.

/// A complete shell file: `shell name { items... }`.
#[derive(Debug, Clone, PartialEq)]
pub struct Shell {
    /// Shell namespace name (e.g., "datum", "ring", "isa").
    pub name: String,
    /// Module path for resolver functions (e.g., "uor::observable").
    /// Defaults to "uor::lut" if not specified via `@module("...")`.
    pub module_path: Option<String>,
    /// Top-level items within the shell.
    pub items: Vec<ShellItem>,
}

/// A top-level item within a shell.
#[derive(Debug, Clone, PartialEq)]
pub enum ShellItem {
    /// Queryable type: `type Byte(value: u8) { fields... }`
    Type(TypeDef),
    /// Value enum: `enum Domain { Theta = 0, Psi = 1, Delta = 2 }`
    Enum(EnumDef),
    /// Mutation spec: `transform Translate(by: u8 mod 96) -> u8 { ... }`
    Transform(TransformDef),
    /// Uniform-signature instruction group: `group lut_activation(sig) { ops }`
    Group(GroupDef),
    /// Custom-signature instruction: `op matmul(c: buf, a: buf, ...)`
    Op(OpDef),
    /// Compile-time table composition: `compose name = [a, b, c]`
    Compose(ComposeDef),
}

// ============================================================================
// Query-layer constructs (datum.shell, ring.shell, activation.shell)
// ============================================================================

/// A queryable type parameterized by a root value.
///
/// ```text
/// type Byte(value: u8) {
///     stratum: u8 = stratum_q0(value)
///     curvature: u8 = curvature_q0(value)
/// }
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct TypeDef {
    pub name: String,
    /// Root parameters (one for single-param types, multiple for observables).
    pub params: Vec<Param>,
    pub fields: Vec<FieldDef>,
}

/// A field with resolver binding.
///
/// ```text
/// stratum: u8 = stratum_q0(value)
/// add(other: u8 mod 96): u8 = ring_add_96(value, other)
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct FieldDef {
    pub name: String,
    /// Arguments for parameterized fields (empty for plain fields).
    pub args: Vec<Param>,
    pub return_type: FieldType,
    pub resolver: ResolverExpr,
    /// Nested sub-object fields (e.g., `torus { page, offset }`).
    pub children: Vec<FieldDef>,
}

/// A resolver expression: function call with arguments.
///
/// ```text
/// stratum_q0(value)
/// ring_add_96(value, other)
/// byte(value >> 8)
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct ResolverExpr {
    pub function: String,
    pub args: Vec<ExprArg>,
}

/// An argument to a resolver expression.
#[derive(Debug, Clone, PartialEq)]
pub enum ExprArg {
    /// References a type param or field arg by name.
    Param(String),
    /// A computed expression.
    Expr(Box<Expr>),
}

/// An expression within a resolver binding.
#[derive(Debug, Clone, PartialEq)]
pub enum Expr {
    Param(String),
    Literal(u64),
    BinOp(Box<Expr>, BinOp, Box<Expr>),
    Call(String, Vec<Expr>),
}

/// Binary operators in resolver expressions.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BinOp {
    Shr,
    Shl,
    BitAnd,
    BitOr,
    Add,
    Sub,
    Mul,
    Mod,
}

/// A value enum within a shell.
///
/// ```text
/// enum Domain { Theta = 0, Psi = 1, Delta = 2 }
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct EnumDef {
    pub name: String,
    pub variants: Vec<EnumVariant>,
}

/// A variant in a shell enum.
#[derive(Debug, Clone, PartialEq)]
pub struct EnumVariant {
    pub name: String,
    pub value: Option<u64>,
}

/// A mutation transform declaration.
///
/// ```text
/// transform Translate(by: u8 mod 96) -> u8 {
///     add = ring_add_96(input, by)
///     sub = ring_sub_96(input, by)
/// }
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct TransformDef {
    pub name: String,
    pub params: Vec<Param>,
    pub return_type: FieldType,
    pub operations: Vec<TransformOp>,
}

/// A named operation within a transform.
#[derive(Debug, Clone, PartialEq)]
pub struct TransformOp {
    pub name: String,
    pub resolver: ResolverExpr,
}

// ============================================================================
// ISA-layer constructs (isa.shell)
// ============================================================================

/// A uniform-signature instruction group.
///
/// ```text
/// group lut_activation(dst: buf, src: buf, count: usize) @suffix("LUT") {
///     sigmoid = SIGMOID_256
///     tanh    = TANH_256
/// }
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct GroupDef {
    /// Group name (e.g., "lut_activation").
    pub name: String,
    /// Shared parameter signature for all members.
    pub params: Vec<Param>,
    /// Named operations within the group.
    pub members: Vec<GroupMember>,
    /// Annotations on the group (e.g., `@suffix("LUT")`).
    pub annotations: Vec<Annotation>,
}

/// A named operation within a group.
#[derive(Debug, Clone, PartialEq)]
pub struct GroupMember {
    /// Operation name (e.g., "sigmoid").
    pub name: String,
    /// Optional LUT table reference (e.g., "SIGMOID_256").
    pub table_ref: Option<String>,
    /// Optional doc comment.
    pub doc: Option<String>,
}

/// A custom-signature ISA instruction.
///
/// ```text
/// op conv2d(
///     dst: buf, input: buf, weight: buf, bias: buf?,
///     @pair kernel(kernel_h: usize = 3, kernel_w: usize = 3),
///     groups: usize = 1,
///     @group input_shape(batch: usize, in_channels: usize, in_h: usize, in_w: usize),
/// ) @builder
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct OpDef {
    /// Operation name (e.g., "conv2d").
    pub name: String,
    /// Parameters (including those inside @pair/@group).
    pub params: Vec<OpParam>,
    /// Top-level annotations (e.g., `@builder`, `@feature("tokenization")`).
    pub annotations: Vec<Annotation>,
    /// Optional doc comment.
    pub doc: Option<String>,
}

/// A parameter in an op definition — may be simple or grouped.
#[derive(Debug, Clone, PartialEq)]
pub enum OpParam {
    /// A simple parameter: `name: type [= default]`
    Simple(Param),
    /// A pair of related parameters: `@pair kernel(kernel_h: usize = 3, kernel_w: usize = 3)`
    Pair {
        group_name: String,
        params: Vec<Param>,
    },
    /// A group of related parameters: `@group input_shape(batch: usize, ...)`
    Group {
        group_name: String,
        params: Vec<Param>,
    },
}

impl OpParam {
    /// Flatten to individual params (for enum variant field generation).
    pub fn flat_params(&self) -> Vec<&Param> {
        match self {
            OpParam::Simple(p) => vec![p],
            OpParam::Pair { params, .. } | OpParam::Group { params, .. } => params.iter().collect(),
        }
    }
}

impl OpDef {
    /// All individual params, flattened from pairs/groups.
    pub fn all_params(&self) -> Vec<&Param> {
        self.params.iter().flat_map(|p| p.flat_params()).collect()
    }

    /// Whether this op has a `@builder` annotation.
    pub fn has_builder(&self) -> bool {
        self.annotations
            .iter()
            .any(|a| matches!(a, Annotation::Builder))
    }

    /// Feature gate name, if any.
    pub fn feature_gate(&self) -> Option<&str> {
        self.annotations.iter().find_map(|a| match a {
            Annotation::Feature(f) => Some(f.as_str()),
            _ => None,
        })
    }
}

/// Compile-time table composition.
///
/// ```text
/// compose standard_normalize = [sigmoid, tanh, relu]
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct ComposeDef {
    /// Composed table name.
    pub name: String,
    /// Ordered list of operations to compose.
    pub chain: Vec<String>,
}

// ============================================================================
// Shared types
// ============================================================================

/// A parameter with optional constraint and default.
///
/// ```text
/// value: u8
/// value: u8 mod 96
/// kernel_h: usize = 3
/// bias: buf?
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct Param {
    pub name: String,
    pub ty: FieldType,
    pub constraint: Option<Constraint>,
    pub default: Option<DefaultValue>,
}

/// A type reference in the shell DSL.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FieldType {
    // Primitives
    U8,
    U16,
    U32,
    U64,
    Usize,
    I32,
    I64,
    F32,
    // Buffer reference (maps to u32 in ISA)
    Buf,
    /// Optional buffer: `buf?` → `Option<u32>`
    OptBuf,
    /// Fixed-size array: `[T; N]`
    Array(Box<FieldType>, usize),
    /// Dynamic-length list: `vec<T>` → `Vec<T>` in enum, `&[T]` in trait
    Vec(Box<FieldType>),
    /// Domain enum reference
    Domain,
    /// String type (for query-layer glyphs etc.)
    String,
    /// User-defined type name
    Named(std::string::String),
    /// List type for query-layer: `[T]`
    List(Box<FieldType>),
}

/// A constraint on a parameter value.
#[derive(Debug, Clone, PartialEq)]
pub enum Constraint {
    /// `mod N` — auto-reduce input.
    Mod(u64),
    /// `N..M` — reject out of range.
    Range(u64, u64),
}

/// A default value for a parameter.
#[derive(Debug, Clone, PartialEq)]
pub enum DefaultValue {
    /// Integer literal: `= 3`
    Int(u64),
    /// Float literal: `= 1e-5`
    Float(f64),
    /// None/null: `= none`
    None,
    /// Named constant: `= SIGMOID_256`
    Ident(String),
}

/// Annotations on shell items.
#[derive(Debug, Clone, PartialEq)]
pub enum Annotation {
    /// `@builder` — generate a builder struct for this op.
    Builder,
    /// `@suffix("LUT")` — append suffix to generated enum variant names.
    Suffix(String),
    /// `@variant("ElemMin")` — override generated enum variant name.
    Variant(String),
    /// `@feature("tokenization")` — wrap in `#[cfg(feature = "...")]`.
    Feature(String),
    /// `@kernel("ElementWise")` — GPU kernel classification category.
    Kernel(String),
}

// ============================================================================
// SHACL-layer constructs (*.ttl shapes)
// ============================================================================

/// A SHACL node shape parsed from a Turtle file.
#[derive(Debug, Clone, PartialEq)]
pub struct ShaclShape {
    /// Shape name (e.g., "Q1DatumShape").
    pub name: String,
    /// Target class local name (e.g., "Q1Datum").
    pub target_class: String,
    /// Human-readable label.
    pub label: String,
    /// Human-readable description.
    pub comment: String,
    /// Property constraints.
    pub properties: Vec<ShaclProperty>,
}

/// A single property constraint within a SHACL shape.
#[derive(Debug, Clone, PartialEq)]
pub struct ShaclProperty {
    /// Property name from `sh:name` (e.g., "value", "stratum").
    pub name: String,
    /// Property path local name (e.g., "value", "stratum").
    pub path: String,
    /// XSD datatype (`None` = untyped, maps to `serde_json::Value`).
    pub datatype: Option<XsdType>,
    /// Minimum cardinality (from `sh:minCount`).
    pub min_count: Option<u64>,
    /// Maximum cardinality (from `sh:maxCount`).
    pub max_count: Option<u64>,
    /// Minimum inclusive value (from `sh:minInclusive`).
    pub min_inclusive: Option<i64>,
    /// Maximum inclusive value (from `sh:maxInclusive`).
    pub max_inclusive: Option<i64>,
    /// Enumerated allowed values (from `sh:in`).
    pub in_values: Option<Vec<String>>,
    /// Minimum string length (from `sh:minLength`).
    pub min_length: Option<u64>,
    /// Maximum string length (from `sh:maxLength`).
    pub max_length: Option<u64>,
}

/// XSD datatypes relevant to SHACL shapes.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum XsdType {
    UnsignedShort,
    UnsignedByte,
    UnsignedInt,
    HexBinary,
    String,
    NonNegativeInteger,
    PositiveInteger,
    Integer,
    Double,
    DateTime,
    Boolean,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn op_param_flatten() {
        let op = OpDef {
            name: "conv2d".into(),
            params: vec![
                OpParam::Simple(Param {
                    name: "dst".into(),
                    ty: FieldType::Buf,
                    constraint: None,
                    default: None,
                }),
                OpParam::Pair {
                    group_name: "kernel".into(),
                    params: vec![
                        Param {
                            name: "kernel_h".into(),
                            ty: FieldType::Usize,
                            constraint: None,
                            default: Some(DefaultValue::Int(3)),
                        },
                        Param {
                            name: "kernel_w".into(),
                            ty: FieldType::Usize,
                            constraint: None,
                            default: Some(DefaultValue::Int(3)),
                        },
                    ],
                },
            ],
            annotations: vec![Annotation::Builder],
            doc: None,
        };

        let all = op.all_params();
        assert_eq!(all.len(), 3);
        assert_eq!(all[0].name, "dst");
        assert_eq!(all[1].name, "kernel_h");
        assert_eq!(all[2].name, "kernel_w");
        assert!(op.has_builder());
    }

    #[test]
    fn field_type_equality() {
        assert_eq!(FieldType::Buf, FieldType::Buf);
        assert_ne!(FieldType::Buf, FieldType::OptBuf);
        assert_eq!(
            FieldType::Array(Box::new(FieldType::Usize), 8),
            FieldType::Array(Box::new(FieldType::Usize), 8),
        );
        assert_ne!(
            FieldType::Array(Box::new(FieldType::Usize), 8),
            FieldType::Array(Box::new(FieldType::U8), 8),
        );
    }

    #[test]
    fn op_feature_gate() {
        let op = OpDef {
            name: "viterbi".into(),
            params: vec![],
            annotations: vec![Annotation::Feature("tokenization".into())],
            doc: None,
        };
        assert_eq!(op.feature_gate(), Some("tokenization"));

        let plain = OpDef {
            name: "matmul".into(),
            params: vec![],
            annotations: vec![],
            doc: None,
        };
        assert_eq!(plain.feature_gate(), None);
    }
}
