//! Codec registry for ISA encode/decode operations.
//!
//! Maps numeric codec IDs to codec implementations from `categorical-codec`.
//! Codecs transform byte sequences through different representations (binary,
//! decimal, hexadecimal, mod96crt, continued fraction).
//!
//! # Codec IDs
//!
//! | ID | Codec | Radix | JSON-LD @id |
//! |----|-------|-------|-------------|
//! | 0 | Binary | 2 | `cxs:numerals/systems/binary` |
//! | 1 | Decimal | 10 | `cxs:numerals/systems/decimal` |
//! | 2 | Hexadecimal | 16 | `cxs:numerals/systems/hexadecimal` |
//! | 3 | Mod96CRT | \[32,3\] | `cxs:numerals/systems/mod96crt` |
//! | 4 | ContinuedFraction | - | `cxs:numerals/systems/continuedFraction` |

use categorical_codec::Codec;

/// Number of available codecs.
pub const CODEC_COUNT: usize = 5;

/// Binary codec (radix 2) - identity transform.
pub const CODEC_BINARY: u32 = 0;
/// Decimal codec (radix 10).
pub const CODEC_DECIMAL: u32 = 1;
/// Hexadecimal codec (radix 16).
pub const CODEC_HEXADECIMAL: u32 = 2;
/// Mod96CRT codec (mixed radix \[32,3\]).
pub const CODEC_MOD96CRT: u32 = 3;
/// Continued fraction codec.
pub const CODEC_CONTINUED_FRACTION: u32 = 4;

/// Get a codec by numeric ID.
///
/// Returns `None` if the codec ID is out of range (>= `CODEC_COUNT`).
///
/// # Example
///
/// ```ignore
/// let codec = get_codec(1).unwrap(); // decimal
/// let encoded = codec.encode(&[255]).unwrap();
/// ```
#[must_use]
pub fn get_codec(id: u32) -> Option<&'static dyn Codec> {
    static BINARY: categorical_codec::NumeralsSystemsBinary =
        categorical_codec::NumeralsSystemsBinary;
    static DECIMAL: categorical_codec::NumeralsSystemsDecimal =
        categorical_codec::NumeralsSystemsDecimal;
    static HEXADECIMAL: categorical_codec::NumeralsSystemsHexadecimal =
        categorical_codec::NumeralsSystemsHexadecimal;
    static MOD96CRT: categorical_codec::NumeralsSystemsMod96crt =
        categorical_codec::NumeralsSystemsMod96crt;
    static CONTINUED_FRACTION: categorical_codec::NumeralsSystemsContinuedFraction =
        categorical_codec::NumeralsSystemsContinuedFraction;

    match id {
        CODEC_BINARY => Some(&BINARY),
        CODEC_DECIMAL => Some(&DECIMAL),
        CODEC_HEXADECIMAL => Some(&HEXADECIMAL),
        CODEC_MOD96CRT => Some(&MOD96CRT),
        CODEC_CONTINUED_FRACTION => Some(&CONTINUED_FRACTION),
        _ => None,
    }
}

/// Get codec ID from JSON-LD string identifier.
///
/// Returns `None` if the identifier is not recognized.
///
/// # Example
///
/// ```ignore
/// let id = codec_id_from_str("cxs:numerals/systems/decimal").unwrap();
/// assert_eq!(id, 1);
/// ```
#[must_use]
pub fn codec_id_from_str(id: &str) -> Option<u32> {
    match id {
        "cxs:numerals/systems/binary" => Some(CODEC_BINARY),
        "cxs:numerals/systems/decimal" => Some(CODEC_DECIMAL),
        "cxs:numerals/systems/hexadecimal" => Some(CODEC_HEXADECIMAL),
        "cxs:numerals/systems/mod96crt" => Some(CODEC_MOD96CRT),
        "cxs:numerals/systems/continuedFraction" => Some(CODEC_CONTINUED_FRACTION),
        _ => None,
    }
}

/// Get JSON-LD identifier from codec ID.
///
/// Returns `None` if the codec ID is out of range.
#[must_use]
pub fn codec_id_to_str(id: u32) -> Option<&'static str> {
    match id {
        CODEC_BINARY => Some("cxs:numerals/systems/binary"),
        CODEC_DECIMAL => Some("cxs:numerals/systems/decimal"),
        CODEC_HEXADECIMAL => Some("cxs:numerals/systems/hexadecimal"),
        CODEC_MOD96CRT => Some("cxs:numerals/systems/mod96crt"),
        CODEC_CONTINUED_FRACTION => Some("cxs:numerals/systems/continuedFraction"),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_get_codec_valid_ids() {
        for id in 0u32..CODEC_COUNT.try_into().unwrap() {
            let codec = get_codec(id);
            assert!(codec.is_some(), "Codec ID {id} should be valid");
        }
    }

    #[test]
    fn test_get_codec_invalid_id() {
        assert!(get_codec(5).is_none());
        assert!(get_codec(100).is_none());
        assert!(get_codec(u32::MAX).is_none());
    }

    #[test]
    fn test_codec_id_from_str_valid() {
        assert_eq!(codec_id_from_str("cxs:numerals/systems/binary"), Some(0));
        assert_eq!(codec_id_from_str("cxs:numerals/systems/decimal"), Some(1));
        assert_eq!(
            codec_id_from_str("cxs:numerals/systems/hexadecimal"),
            Some(2)
        );
        assert_eq!(codec_id_from_str("cxs:numerals/systems/mod96crt"), Some(3));
        assert_eq!(
            codec_id_from_str("cxs:numerals/systems/continuedFraction"),
            Some(4)
        );
    }

    #[test]
    fn test_codec_id_from_str_invalid() {
        assert!(codec_id_from_str("invalid").is_none());
        assert!(codec_id_from_str("cxs:numerals/systems/octal").is_none());
        assert!(codec_id_from_str("").is_none());
    }

    #[test]
    fn test_codec_id_to_str_valid() {
        assert_eq!(codec_id_to_str(0), Some("cxs:numerals/systems/binary"));
        assert_eq!(codec_id_to_str(1), Some("cxs:numerals/systems/decimal"));
        assert_eq!(codec_id_to_str(2), Some("cxs:numerals/systems/hexadecimal"));
        assert_eq!(codec_id_to_str(3), Some("cxs:numerals/systems/mod96crt"));
        assert_eq!(
            codec_id_to_str(4),
            Some("cxs:numerals/systems/continuedFraction")
        );
    }

    #[test]
    fn test_codec_id_to_str_invalid() {
        assert!(codec_id_to_str(5).is_none());
        assert!(codec_id_to_str(u32::MAX).is_none());
    }

    #[test]
    fn test_roundtrip_str_conversion() {
        for id in 0u32..CODEC_COUNT.try_into().unwrap() {
            let str_id = codec_id_to_str(id).unwrap();
            let back = codec_id_from_str(str_id).unwrap();
            assert_eq!(id, back, "Roundtrip failed for ID {id}");
        }
    }

    #[test]
    fn test_codec_names() {
        let names = [
            (0, "NumeralsSystemsBinary"),
            (1, "NumeralsSystemsDecimal"),
            (2, "NumeralsSystemsHexadecimal"),
            (3, "NumeralsSystemsMod96crt"),
            (4, "NumeralsSystemsContinuedFraction"),
        ];

        for (id, expected_name) in names {
            let codec = get_codec(id).unwrap();
            assert_eq!(codec.name(), expected_name, "Codec {id} has wrong name");
        }
    }

    #[test]
    fn test_binary_codec_is_identity() {
        let codec = get_codec(CODEC_BINARY).unwrap();
        let input = vec![1, 2, 3, 4, 5];
        let encoded = codec.encode(&input).unwrap();
        assert_eq!(encoded, input, "Binary codec should be identity");
    }

    #[test]
    fn test_decimal_codec_roundtrip() {
        let codec = get_codec(CODEC_DECIMAL).unwrap();
        // Test with value that doesn't have leading zeros
        let input = vec![1, 2, 3];
        let encoded = codec.encode(&input).unwrap();
        let decoded = codec.decode(&encoded).unwrap();
        assert_eq!(decoded, input, "Decimal roundtrip failed");
    }

    #[test]
    fn test_hexadecimal_codec_roundtrip() {
        let codec = get_codec(CODEC_HEXADECIMAL).unwrap();
        let input = vec![0xDE, 0xAD, 0xBE, 0xEF];
        let encoded = codec.encode(&input).unwrap();
        let decoded = codec.decode(&encoded).unwrap();
        assert_eq!(decoded, input, "Hexadecimal roundtrip failed");
    }

    #[test]
    fn test_all_codecs_roundtrip() {
        // Test inputs without leading zeros (BigInt normalization)
        let test_inputs: &[&[u8]] = &[&[1], &[255], &[1, 2, 3], &[0xDE, 0xAD, 0xBE, 0xEF]];

        for id in 0u32..CODEC_COUNT.try_into().unwrap() {
            let codec = get_codec(id).unwrap();
            for &input in test_inputs {
                let encoded = codec.encode(input).unwrap();
                let decoded = codec.decode(&encoded).unwrap();
                assert_eq!(
                    decoded,
                    input,
                    "Codec {} failed roundtrip for {:?}",
                    codec.name(),
                    input
                );
            }
        }
    }
}
