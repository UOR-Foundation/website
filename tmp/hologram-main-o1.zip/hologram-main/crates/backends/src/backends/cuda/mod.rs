//! CUDA backend implementation (skeleton).
//!
//! This module provides a skeleton CUDA backend for NVIDIA GPUs.
//! The actual CUDA implementation is planned for a future sprint.
//!
//! # Architecture
//!
//! The CUDA backend will:
//! - Detect available NVIDIA GPUs via CUDA runtime
//! - Allocate device memory for buffers and constants
//! - Execute ISA operations as CUDA kernels
//! - Synchronize and transfer results back to host
//!
//! # Current Status
//!
//! This is a skeleton implementation. All methods return `NotImplemented` errors.
//! The structure demonstrates the intended API for GPU-accelerated execution.

use hologram_holo::BackendPlan;

use super::gpu::{GpuBackend, GpuBuffer, GpuDevice};
use super::Backend;
use crate::types::{BackendCapabilities, BackendError, BackendType, Result};

/// CUDA backend for NVIDIA GPU execution (skeleton).
///
/// This backend will execute ISA plans on NVIDIA GPUs using CUDA.
/// Currently a skeleton with stub implementations.
pub struct CudaBackend {
    capabilities: BackendCapabilities,
    current_device: Option<GpuDevice>,
}

impl CudaBackend {
    /// Create a new CUDA backend.
    ///
    /// # Errors
    ///
    /// Returns error if CUDA is not available (currently always succeeds
    /// as this is a skeleton).
    pub fn new() -> Result<Self> {
        Ok(Self {
            capabilities: BackendCapabilities {
                backend_type: BackendType::Cuda,
                vector_width: 32,               // CUDA warp size
                l1_cache_size: 48 * 1024,       // Typical L1 per SM
                l2_cache_size: 6 * 1024 * 1024, // Typical L2
                has_fma: true,
                has_sha: false,
                has_aes: false,
            },
            current_device: None,
        })
    }

    /// Check if CUDA is available on this system.
    ///
    /// # Returns
    ///
    /// Currently always returns `false` (skeleton implementation).
    #[must_use]
    pub fn is_available() -> bool {
        // Skeleton: would check for CUDA runtime
        false
    }
}

impl Default for CudaBackend {
    fn default() -> Self {
        Self::new().expect("CUDA backend creation should not fail in skeleton")
    }
}

impl Backend for CudaBackend {
    fn backend_type(&self) -> BackendType {
        BackendType::Cuda
    }

    fn execute_plan(
        &self,
        _plan: &BackendPlan,
        _inputs: &[&[u8]],
        _outputs: &mut [&mut [u8]],
    ) -> Result<()> {
        Err(BackendError::NotImplemented {
            feature: "CUDA plan execution".into(),
        })
    }

    fn execute_plan_with_layers(
        &self,
        _plan: &BackendPlan,
        _inputs: &[&[u8]],
        _outputs: &mut [&mut [u8]],
        _layer_executor: super::LayerExecutorFn<'_>,
    ) -> Result<()> {
        Err(BackendError::NotImplemented {
            feature: "CUDA plan execution with layers".into(),
        })
    }

    fn capabilities(&self) -> &BackendCapabilities {
        &self.capabilities
    }
}

impl GpuBackend for CudaBackend {
    fn enumerate_devices(&self) -> Result<Vec<GpuDevice>> {
        // Skeleton: would call cuDeviceGetCount and cuDeviceGet
        Err(BackendError::NotImplemented {
            feature: "CUDA device enumeration".into(),
        })
    }

    fn select_device(&mut self, _device_index: u32) -> Result<()> {
        Err(BackendError::NotImplemented {
            feature: "CUDA device selection".into(),
        })
    }

    fn current_device(&self) -> Option<&GpuDevice> {
        self.current_device.as_ref()
    }

    fn allocate(&mut self, _size: usize) -> Result<GpuBuffer> {
        // Skeleton: would call cudaMalloc
        Err(BackendError::NotImplemented {
            feature: "CUDA memory allocation".into(),
        })
    }

    fn free(&mut self, _buffer: GpuBuffer) -> Result<()> {
        // Skeleton: would call cudaFree
        Err(BackendError::NotImplemented {
            feature: "CUDA memory free".into(),
        })
    }

    fn upload(&mut self, _dst: GpuBuffer, _src: &[u8]) -> Result<()> {
        // Skeleton: would call cudaMemcpy (HostToDevice)
        Err(BackendError::NotImplemented {
            feature: "CUDA memory upload".into(),
        })
    }

    fn download(&self, _src: GpuBuffer, _dst: &mut [u8]) -> Result<()> {
        // Skeleton: would call cudaMemcpy (DeviceToHost)
        Err(BackendError::NotImplemented {
            feature: "CUDA memory download".into(),
        })
    }

    fn synchronize(&self) -> Result<()> {
        // Skeleton: would call cudaDeviceSynchronize
        Err(BackendError::NotImplemented {
            feature: "CUDA synchronization".into(),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cuda_backend_creation() {
        let backend = CudaBackend::new().unwrap();
        assert_eq!(backend.backend_type(), BackendType::Cuda);
    }

    #[test]
    fn test_cuda_backend_default() {
        let backend = CudaBackend::default();
        assert_eq!(backend.backend_type(), BackendType::Cuda);
    }

    #[test]
    fn test_cuda_is_available() {
        // Skeleton always returns false
        assert!(!CudaBackend::is_available());
    }

    #[test]
    fn test_cuda_capabilities() {
        let backend = CudaBackend::new().unwrap();
        let caps = backend.capabilities();
        assert_eq!(caps.backend_type, BackendType::Cuda);
        assert_eq!(caps.vector_width, 32); // Warp size
    }

    #[test]
    fn test_cuda_execute_returns_not_implemented() {
        use hologram_holo::PlanMetadata;

        let backend = CudaBackend::new().unwrap();
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        let result = backend.execute_plan(&plan, &[], &mut []);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_cuda_enumerate_returns_not_implemented() {
        let backend = CudaBackend::new().unwrap();
        let result = backend.enumerate_devices();
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_cuda_select_device_returns_not_implemented() {
        let mut backend = CudaBackend::new().unwrap();
        let result = backend.select_device(0);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_cuda_current_device_initially_none() {
        let backend = CudaBackend::new().unwrap();
        assert!(backend.current_device().is_none());
    }

    #[test]
    fn test_cuda_allocate_returns_not_implemented() {
        let mut backend = CudaBackend::new().unwrap();
        let result = backend.allocate(1024);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_cuda_free_returns_not_implemented() {
        let mut backend = CudaBackend::new().unwrap();
        let buffer = GpuBuffer {
            handle: 0,
            size: 1024,
        };
        let result = backend.free(buffer);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_cuda_upload_returns_not_implemented() {
        let mut backend = CudaBackend::new().unwrap();
        let buffer = GpuBuffer {
            handle: 0,
            size: 1024,
        };
        let data = [0u8; 1024];
        let result = backend.upload(buffer, &data);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_cuda_download_returns_not_implemented() {
        let backend = CudaBackend::new().unwrap();
        let buffer = GpuBuffer {
            handle: 0,
            size: 1024,
        };
        let mut data = [0u8; 1024];
        let result = backend.download(buffer, &mut data);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_cuda_synchronize_returns_not_implemented() {
        let backend = CudaBackend::new().unwrap();
        let result = backend.synchronize();
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }
}
