//! Workspace planning (Stage 5).
//!
//! This module computes static memory offsets for intermediate buffers:
//! - Liveness analysis determines which buffers are active simultaneously
//! - Non-overlapping buffers can share memory regions
//! - Offset assignment minimizes total workspace size
//!
//! The output is a `WorkspaceLayout` with `total_size` and per-buffer `slots`.

mod liveness;

use crate::graph::CompileGraph;
use crate::pipeline::{WorkspaceLayout, WorkspaceSlot};
pub use liveness::{compute_liveness, BufferInfo, LivenessInterval};

/// Plan workspace buffer allocations via liveness analysis.
///
/// This function:
/// 1. Computes liveness intervals for each intermediate buffer
/// 2. Assigns offsets to minimize total workspace (using first-fit allocation)
/// 3. Records the node-to-slot mapping for later runtime allocation
#[must_use]
pub fn plan_workspace(graph: &CompileGraph) -> WorkspaceLayout {
    let buffers = compute_liveness(graph);

    if buffers.is_empty() {
        return WorkspaceLayout::default();
    }

    // Sort buffers by size descending for better packing (largest first)
    let mut buffer_list: Vec<_> = buffers.values().collect();
    buffer_list.sort_by(|a, b| b.size.cmp(&a.size));

    // Allocate buffers using first-fit decreasing strategy
    let (slots, total_size) = allocate_buffers(&buffer_list);

    // Assign slots to graph nodes
    assign_slots_to_graph(graph, &slots);

    WorkspaceLayout { total_size, slots }
}

/// Allocate buffers using first-fit decreasing algorithm.
///
/// Returns (slots, `total_size`).
fn allocate_buffers(buffers: &[&BufferInfo]) -> (Vec<WorkspaceSlot>, usize) {
    if buffers.is_empty() {
        return (Vec::new(), 0);
    }

    // Track allocated regions as (offset, size, interval)
    let mut allocated: Vec<(usize, usize, LivenessInterval)> = Vec::new();
    let mut slots = Vec::new();
    let mut max_end = 0usize;

    for buffer in buffers {
        // Find the first gap where this buffer fits
        let offset = find_first_fit(buffer, &allocated);

        // Record the allocation
        allocated.push((offset, buffer.size, buffer.interval));

        // Create the slot
        let aligned_offset = align_up(offset, buffer.alignment);
        let slot = WorkspaceSlot {
            offset: aligned_offset,
            size: buffer.size,
            alignment: buffer.alignment,
        };

        // Track maximum end address
        max_end = max_end.max(aligned_offset + buffer.size);
        slots.push(slot);
    }

    // Align total size to largest alignment
    let max_alignment = buffers.iter().map(|b| b.alignment).max().unwrap_or(8);
    let total_size = align_up(max_end, max_alignment);

    (slots, total_size)
}

/// Find the first offset where a buffer can fit without overlapping
/// any allocated region with an overlapping liveness interval.
fn find_first_fit(buffer: &BufferInfo, allocated: &[(usize, usize, LivenessInterval)]) -> usize {
    let mut candidate_offset = 0usize;

    // Keep trying until we find a valid position
    loop {
        let aligned = align_up(candidate_offset, buffer.alignment);
        let end = aligned + buffer.size;

        // Check for conflicts with all allocated regions
        let conflict = allocated
            .iter()
            .filter(|(_, _, interval)| interval.overlaps(&buffer.interval))
            .find(|(alloc_offset, alloc_size, _)| {
                // Check if [aligned, end) overlaps with [alloc_offset, alloc_offset + alloc_size)
                aligned < alloc_offset + alloc_size && *alloc_offset < end
            });

        match conflict {
            Some((alloc_offset, alloc_size, _)) => {
                // Move past this conflicting region
                candidate_offset = alloc_offset + alloc_size;
            }
            None => {
                // No conflict, this offset works
                return aligned;
            }
        }
    }
}

/// Round up to the next aligned boundary.
const fn align_up(value: usize, alignment: usize) -> usize {
    (value + alignment - 1) & !(alignment - 1)
}

/// Assign workspace slots to graph nodes.
///
/// This records the slot index in each node's `workspace_slot` field.
fn assign_slots_to_graph(graph: &CompileGraph, slots: &[WorkspaceSlot]) {
    // For now, this is a placeholder - the actual assignment would
    // need to track the mapping from buffer to slot during allocation.
    // The graph nodes already have workspace_slot: Option<u32> field.
    let _ = (graph, slots);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpKind, OpNode, OperationGraph};

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    #[test]
    fn test_plan_workspace_empty_graph() {
        let graph = make_graph(vec![], vec![]);
        let workspace = plan_workspace(&graph);
        assert_eq!(workspace.total_size, 0);
        assert!(workspace.slots.is_empty());
    }

    #[test]
    fn test_plan_workspace_io_only() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1)],
        );

        let workspace = plan_workspace(&graph);
        // I/O nodes don't need workspace
        assert_eq!(workspace.total_size, 0);
    }

    #[test]
    fn test_plan_workspace_single_op() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let workspace = plan_workspace(&graph);

        // One intermediate buffer: 64 * 64 * 4 = 16384 bytes
        assert!(workspace.total_size >= 16384);
        assert_eq!(workspace.slots.len(), 1);
    }

    #[test]
    fn test_plan_workspace_sequential_reuse() {
        // Input -> Relu -> Sigmoid -> Tanh -> Output
        // Sequential ops can reuse the same buffer
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64], DType::F32),
                OpNode::new(3, OpKind::Tanh, vec![64], DType::F32),
                OpNode::new(4, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3), (3, 4)],
        );

        let workspace = plan_workspace(&graph);

        // With buffer reuse, we shouldn't need 3x the single buffer size
        // Each buffer is 64 * 4 = 256 bytes
        // Without reuse: 3 * 256 = 768 bytes
        // With perfect reuse: 256 bytes (but Relu and Sigmoid overlap, etc.)
        assert!(workspace.total_size < 768);
    }

    #[test]
    fn test_plan_workspace_parallel_no_reuse() {
        // Input -> [Relu, Sigmoid] -> Add -> Output
        // Parallel ops cannot share buffers
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64], DType::F32),
                OpNode::new(3, OpKind::Add, vec![64], DType::F32),
                OpNode::new(4, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1), (0, 2), (1, 3), (2, 3), (3, 4)],
        );

        let workspace = plan_workspace(&graph);

        // Relu, Sigmoid, and Add all need separate workspace
        // Each is 64 * 4 = 256 bytes
        // Minimum is 3 * 256 = 768 (but may need more due to alignment)
        assert!(workspace.total_size >= 768);
    }

    #[test]
    fn test_plan_workspace_alignment() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let workspace = plan_workspace(&graph);

        // Check that slots are properly aligned
        for slot in &workspace.slots {
            assert_eq!(slot.offset % slot.alignment, 0);
        }
    }

    #[test]
    fn test_plan_workspace_different_sizes() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![256], DType::F32), // 1024 bytes
                OpNode::new(2, OpKind::Sigmoid, vec![64], DType::F32), // 256 bytes
                OpNode::new(3, OpKind::Add, vec![256], DType::F32),  // 1024 bytes
                OpNode::new(4, OpKind::Output, vec![256], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3), (3, 4)],
        );

        let workspace = plan_workspace(&graph);

        // Should have 3 slots (Relu, Sigmoid, Add)
        assert_eq!(workspace.slots.len(), 3);
    }

    #[test]
    fn test_align_up() {
        assert_eq!(align_up(0, 32), 0);
        assert_eq!(align_up(1, 32), 32);
        assert_eq!(align_up(32, 32), 32);
        assert_eq!(align_up(33, 32), 64);
        assert_eq!(align_up(100, 8), 104);
    }

    #[test]
    fn test_workspace_slot_offset_zero() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let workspace = plan_workspace(&graph);

        // First slot should start at offset 0
        assert_eq!(workspace.slots[0].offset, 0);
    }

    #[test]
    fn test_plan_workspace_complex_dag() {
        //     Input0
        //    /      \
        //  Relu    Sigmoid
        //    |        |
        //  Tanh    Gelu
        //    \      /
        //      Add
        //       |
        //    Output
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![128], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![128], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![128], DType::F32),
                OpNode::new(3, OpKind::Tanh, vec![128], DType::F32),
                OpNode::new(4, OpKind::Gelu, vec![128], DType::F32),
                OpNode::new(5, OpKind::Add, vec![128], DType::F32),
                OpNode::new(6, OpKind::Output, vec![128], DType::F32),
            ],
            vec![(0, 1), (0, 2), (1, 3), (2, 4), (3, 5), (4, 5), (5, 6)],
        );

        let workspace = plan_workspace(&graph);

        // 5 intermediate nodes (excluding Input and Output)
        assert_eq!(workspace.slots.len(), 5);
        assert!(workspace.total_size > 0);
    }

    #[test]
    fn test_plan_workspace_matmul() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        let workspace = plan_workspace(&graph);

        // MatMul output buffer: 64 * 64 * 4 = 16384 bytes
        assert!(workspace.total_size >= 16384);
    }
}
