//! Kernel management commands.

use crate::error::{CliError, CliResult};
use clap::{Args, Subcommand};
use std::fs;
use std::path::PathBuf;

#[derive(Args, Debug)]
pub struct KernelArgs {
    #[command(subcommand)]
    pub command: KernelCommand,
}

#[derive(Subcommand, Debug)]
pub enum KernelCommand {
    /// Initialize a new kernel project
    Init {
        /// Name of the kernel project
        name: String,

        /// Language (rust or c)
        #[arg(short, long, default_value = "rust")]
        lang: String,

        /// Output directory path
        #[arg(short, long)]
        path: Option<PathBuf>,
    },
}

pub fn execute(args: KernelArgs, _verbose: bool) -> CliResult<()> {
    match args.command {
        KernelCommand::Init { name, lang, path } => init_kernel(&name, &lang, path.as_deref()),
    }
}

fn init_kernel(name: &str, lang: &str, path: Option<&std::path::Path>) -> CliResult<()> {
    // Validate language
    if lang != "rust" && lang != "c" {
        return Err(CliError::InvalidInput(format!(
            "Unsupported language '{}'. Use 'rust' or 'c'",
            lang
        )));
    }

    // Determine output directory
    let output_dir = if let Some(p) = path {
        p.join(name)
    } else {
        PathBuf::from(name)
    };

    // Check if directory already exists
    if output_dir.exists() {
        return Err(CliError::InvalidInput(format!(
            "Directory '{}' already exists",
            output_dir.display()
        )));
    }

    println!("Creating {} kernel project: {}", lang, name);
    println!("  📁 {}", output_dir.display());

    match lang {
        "rust" => create_rust_kernel(&output_dir, name)?,
        "c" => create_c_kernel(&output_dir, name)?,
        _ => unreachable!(),
    }

    println!("✅ Kernel project created successfully!");
    println!();
    println!("Next steps:");
    println!("  cd {}", name);
    if lang == "rust" {
        println!("  cargo build --release");
    } else {
        println!("  make");
    }
    println!();
    println!("See README.md for usage instructions.");

    Ok(())
}

fn create_rust_kernel(dir: &std::path::Path, name: &str) -> CliResult<()> {
    // Create directory structure
    fs::create_dir_all(dir)?;
    fs::create_dir_all(dir.join("src"))?;

    // Cargo.toml
    let cargo_toml = format!(
        r#"[package]
name = "{}"
version = "0.1.0"
edition = "2021"

[lib]
crate-type = ["cdylib"]

[dependencies]
hologram-kernel-macro = {{ path = "../../../kernel-macro" }}
# Add optimized dependencies as needed
# blas-src = {{ version = "0.10", features = ["accelerate"] }}
"#,
        name
    );
    fs::write(dir.join("Cargo.toml"), cargo_toml)?;

    // src/lib.rs
    let lib_rs = r#"//! Hologram optimized kernel.

use hologram_kernel_macro::{hologram_kernel, kernel_fn};
use std::slice;

// Initialize the kernel
#[hologram_kernel]
struct OptimizedKernel;

// Register your optimized implementations
#[kernel_fn]
pub unsafe extern "C" fn optimized_matmul(
    a: *const f32, 
    b: *const f32, 
    c: *mut f32,
    m: usize, 
    k: usize, 
    n: usize
) -> i32 {
    let a = slice::from_raw_parts(a, m * k);
    let b = slice::from_raw_parts(b, k * n);
    let c = slice::from_raw_parts_mut(c, m * n);
    
    // TODO: Replace with your optimized implementation
    // This is a simple reference implementation
    for i in 0..m {
        for j in 0..n {
            let mut sum = 0.0;
            for p in 0..k {
                sum += a[i * k + p] * b[p * n + j];
            }
            c[i * n + j] = sum;
        }
    }
    
    0 // success
}

#[cfg(test)]
mod tests {
    #[test]
    fn test_kernel_compiles() {
        // Basic compilation test
        assert!(true);
    }
}
"#;
    fs::write(dir.join("src").join("lib.rs"), lib_rs)?;

    // README.md
    let readme = format!(
        r#"# {}

Optimized hologram kernel implementation.

## Build

```bash
cargo build --release
```

Output: `target/release/lib{}.{{so,dylib,dll}}`

## Usage

### Load Individually

```rust
use hologram_backend::backends::loader::DynamicKernelProvider;

let kernel = unsafe {{
    DynamicKernelProvider::load("./target/release/lib{}.so")?
}};

kernel.matmul(&a, &b, &mut c, m, k, n);
```

### Auto-Discovery

Place built library in a `kernels/` directory:

```rust
use hologram_backend::backends::loader::KernelRegistry;

let mut registry = KernelRegistry::new();
registry.load_from_directory("./kernels")?;

if let Some(result) = registry.matmul(&a, &b, &mut c, m, k, n) {{
    result?;
}}
```

## Development

1. Modify `src/lib.rs` with your optimized implementation
2. Run `cargo build --release` to rebuild
3. Test with hologram workloads
4. Benchmark against default kernels

## Testing

```bash
cargo test
hologram kernel test ./target/release/lib{}.so
```

## Documentation

- [Kernel Loading Guide](https://github.com/hologram/docs/kernel-loading.md)
- [Kernel ABI Reference](https://docs.rs/hologram-backend/latest/hologram_backend/backends/kernel_abi/)
"#,
        name, name, name, name
    );
    fs::write(dir.join("README.md"), readme)?;

    // .gitignore
    let gitignore = r#"/target
Cargo.lock
"#;
    fs::write(dir.join(".gitignore"), gitignore)?;

    Ok(())
}

fn create_c_kernel(dir: &std::path::Path, name: &str) -> CliResult<()> {
    // Create directory structure
    fs::create_dir_all(dir)?;

    // Makefile
    let makefile = format!(
        r#"CC = gcc
CFLAGS = -O3 -fPIC -shared -Wall
TARGET = lib{}.so

all: $(TARGET)

$(TARGET): {}.c
	$(CC) $(CFLAGS) -o $(TARGET) {}.c

clean:
	rm -f $(TARGET)

.PHONY: all clean
"#,
        name, name, name
    );
    fs::write(dir.join("Makefile"), makefile)?;

    // kernel.c
    let kernel_c = r#"#include <stdint.h>
#include <stddef.h>

#define KERNEL_MAGIC 0x484F4C4F5F4B4552ULL
#define KERNEL_ABI_VERSION 1

typedef struct {
    uint64_t magic;
    uint64_t version;
    int32_t (*matmul)(const float*, const float*, float*, size_t, size_t, size_t);
    int32_t (*batch_matmul)(const float*, const float*, float*, size_t, size_t, size_t, size_t);
    void (*reserved[16])(void);
} KernelVTable;

static int32_t optimized_matmul(
    const float* a, const float* b, float* c,
    size_t m, size_t k, size_t n
) {
    // TODO: Replace with your optimized implementation
    for (size_t i = 0; i < m; i++) {
        for (size_t j = 0; j < n; j++) {
            float sum = 0.0f;
            for (size_t p = 0; p < k; p++) {
                sum += a[i * k + p] * b[p * n + j];
            }
            c[i * n + j] = sum;
        }
    }
    return 0; // success
}

static KernelVTable vtable = {
    .magic = KERNEL_MAGIC,
    .version = KERNEL_ABI_VERSION,
    .matmul = optimized_matmul,
    .batch_matmul = NULL,
    .reserved = {NULL}
};

__attribute__((visibility("default")))
const KernelVTable* hologram_kernel_vtable(void) {
    return &vtable;
}
"#;
    fs::write(dir.join(format!("{}.c", name)), kernel_c)?;

    // README.md
    let readme = format!(
        r#"# {}

Optimized hologram kernel implementation in C.

## Build

```bash
make
```

Output: `lib{}.so`

## Usage

```rust
use hologram_backend::backends::loader::DynamicKernelProvider;

let kernel = unsafe {{
    DynamicKernelProvider::load("./lib{}.so")?
}};

kernel.matmul(&a, &b, &mut c, m, k, n);
```

## Development

1. Modify `{}.c` with your optimized implementation
2. Run `make` to rebuild
3. Test with hologram workloads

## Documentation

- [Kernel Loading Guide](https://github.com/hologram/docs/kernel-loading.md)
"#,
        name, name, name, name
    );
    fs::write(dir.join("README.md"), readme)?;

    // .gitignore
    let gitignore = "*.so\n*.o\n";
    fs::write(dir.join(".gitignore"), gitignore)?;

    Ok(())
}
