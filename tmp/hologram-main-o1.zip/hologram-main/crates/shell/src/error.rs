//! Shell DSL parse error types.

use std::fmt;

/// Error returned when parsing a `.shell` file fails.
#[derive(Debug, Clone, PartialEq)]
pub struct ParseError {
    /// Human-readable error message.
    pub message: String,
    /// Byte offset into the input where the error occurred.
    pub offset: usize,
    /// The remaining unparsed input (truncated for display).
    pub remaining: String,
}

impl ParseError {
    pub(crate) fn from_nom(input: &str, original: &str, msg: &str) -> Self {
        let offset = original.len() - input.len();
        let remaining = if input.len() > 40 {
            format!("{}...", &input[..40])
        } else {
            input.to_string()
        };
        Self {
            message: msg.to_string(),
            offset,
            remaining,
        }
    }
}

impl fmt::Display for ParseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "parse error at offset {}: {} (near: {:?})",
            self.offset, self.message, self.remaining
        )
    }
}

impl std::error::Error for ParseError {}
