//! Bitcoin mining optimization.
//!
//! Provides `MiningState` which precomputes the first block's hash state (midstate),
//! reducing the mining loop to 2 compression functions instead of 3.

use crate::compress::H0;
use crate::simd::{compress, compress_second_hash};

/// Optimized mining state for a Bitcoin block header.
///
/// Precomputes the SHA-256 state after the first 64-byte block (Version, PrevHash, MerkleRoot[0..28]).
/// The second block contains the nonce, so we only need to compress the second block and the
/// final double-hash block for each nonce attempt.
#[derive(Clone, Debug)]
pub struct MiningState {
    /// State after processing the first 64 bytes of the header.
    midstate: [u32; 8],
    /// Template for the second 64-byte block.
    /// Bytes 0-11: MerkleRoot[28..32], Time, Bits
    /// Bytes 12-15: Nonce (variable)
    /// Bytes 16-63: Padding + Length
    block2_template: [u8; 64],
}

impl MiningState {
    /// Create a new mining state from a block header.
    ///
    /// # Arguments
    /// * `header` - 80-byte Bitcoin block header
    pub fn new(header: &[u8; 80]) -> Self {
        // 1. Compute midstate (Hash of first 64 bytes)
        let mut midstate = H0;
        let mut block1 = [0u8; 64];
        block1.copy_from_slice(&header[0..64]);
        compress(&mut midstate, &block1);

        // 2. Prepare block 2 template
        let mut block2 = [0u8; 64];
        // Copy remaining 16 bytes of header (Merkle suffix, Time, Bits, Nonce)
        // Header bytes 64-79
        block2[0..16].copy_from_slice(&header[64..80]);

        // Add padding (0x80 already set? Standard SHA-256 padding)
        // Length of header is 80 bytes = 640 bits.
        // Padding: 0x80 at byte 80 (index 16 in block 2)
        block2[16] = 0x80;

        // Length (640 bits = 0x0280) in big-endian at end of block 2
        // 640 = 0x0000_0000_0000_0280
        block2[62] = 0x02;
        block2[63] = 0x80;

        Self {
            midstate,
            block2_template: block2,
        }
    }

    /// Check a single nonce.
    #[inline]
    pub fn check_nonce(&self, nonce: u32, target: &[u8; 32]) -> bool {
        let mut state = self.midstate;
        let mut block2 = self.block2_template;

        // Update nonce (bytes 12-15 of block 2, corresponding to bytes 76-79 of header)
        // Bitcoin nonce is little-endian in the header
        block2[12..16].copy_from_slice(&nonce.to_le_bytes());

        // Compress block 2
        compress(&mut state, &block2);

        // Compress second hash (SHA256(hash1))
        // This takes the raw state (32 bytes) + padding + length
        // compress_second_hash handles padding/length for 32-byte input
        let hash = compress_second_hash(&state);

        // Compare with target (hash <= target, interpreted as Little Endian integers)
        // Iterate mainly from most significant byte (index 31 in LE array) down to 0
        for i in (0..32).rev() {
            match hash[i].cmp(&target[i]) {
                std::cmp::Ordering::Less => return true,
                std::cmp::Ordering::Greater => return false,
                std::cmp::Ordering::Equal => continue,
            }
        }
        // If equal, it's a match (hash <= target includes equality)
        true
    }

    /// Check a range of nonces efficiently using 4-way instruction-level parallelism.
    ///
    /// This function unrolls the mining loop to process 4 nonces per iteration,
    /// allowing superscalar CPUs to pipeline the SHA-256 instructions.
    ///
    /// # Arguments
    /// * `start_nonce` - Starting nonce (inclusive)
    /// * `end_nonce` - Ending nonce (exclusive)
    /// * `target` - 32-byte target (little-endian comparison)
    ///
    /// # Returns
    /// A list of winning nonces found in the range.
    pub fn check_range(&self, start_nonce: u32, end_nonce: u32, target: &[u8; 32]) -> Vec<u32> {
        let mut winners = Vec::new();
        let mut nonce = start_nonce;

        // Process 4 nonces at a time
        while nonce.checked_add(4).is_some_and(|next| next <= end_nonce) {
            let n0 = nonce;
            let n1 = nonce + 1;
            let n2 = nonce + 2;
            let n3 = nonce + 3;

            // Prepare 4 independent states (copy from midstate)
            let mut s0 = self.midstate;
            let mut s1 = self.midstate;
            let mut s2 = self.midstate;
            let mut s3 = self.midstate;

            // Prepare 4 blocks
            let mut b0 = self.block2_template;
            let mut b1 = self.block2_template;
            let mut b2 = self.block2_template;
            let mut b3 = self.block2_template;

            b0[12..16].copy_from_slice(&n0.to_le_bytes());
            b1[12..16].copy_from_slice(&n1.to_le_bytes());
            b2[12..16].copy_from_slice(&n2.to_le_bytes());
            b3[12..16].copy_from_slice(&n3.to_le_bytes());

            // Compress 4 blocks (CPU should interleave these)
            compress(&mut s0, &b0);
            compress(&mut s1, &b1);
            compress(&mut s2, &b2);
            compress(&mut s3, &b3);

            // Compress 4 second hashes
            let h0 = compress_second_hash(&s0);
            let h1 = compress_second_hash(&s1);
            let h2 = compress_second_hash(&s2);
            let h3 = compress_second_hash(&s3);

            // Check targets
            if check_hash(&h0, target) {
                winners.push(n0);
            }
            if check_hash(&h1, target) {
                winners.push(n1);
            }
            if check_hash(&h2, target) {
                winners.push(n2);
            }
            if check_hash(&h3, target) {
                winners.push(n3);
            }

            nonce += 4;
        }

        // Handle remaining nonces
        while nonce < end_nonce {
            if self.check_nonce(nonce, target) {
                winners.push(nonce);
            }
            nonce += 1;
        }

        winners
    }
}

/// Helper for target comparison (Little Endian u256)
#[inline]
fn check_hash(hash: &[u8; 32], target: &[u8; 32]) -> bool {
    // Compare bytes from most significant (index 31) down to 0
    for i in (0..32).rev() {
        match hash[i].cmp(&target[i]) {
            std::cmp::Ordering::Less => return true,
            std::cmp::Ordering::Greater => return false,
            std::cmp::Ordering::Equal => continue,
        }
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::double_sha256;

    #[test]
    fn test_mining_state_correctness() {
        // Bitcoin genesis header
        let header: [u8; 80] = [
            0x01, 0x00, 0x00, 0x00, // Version
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, // Merkle root (32 bytes)
            0x3b, 0xa3, 0xed, 0xfd, 0x7a, 0x7b, 0x12, 0xb2, 0x7a, 0xc7, 0x2c, 0x3e, 0x67, 0x76,
            0x8f, 0x61, 0x7f, 0xc8, 0x1b, 0xc3, 0x88, 0x8a, 0x51, 0x32, 0x3a, 0x9f, 0xb8, 0xaa,
            0x4b, 0x1e, 0x5e, 0x4a, // Timestamp
            0x29, 0xab, 0x5f, 0x49, // Bits
            0xff, 0xff, 0x00, 0x1d, // Nonce (2083236893)
            0x1d, 0xac, 0x2b, 0x7c,
        ];

        let mining_state = MiningState::new(&header);
        let nonce = 2083236893;

        // Target is set very high (easier) to ensure check passes for valid nonce
        let easy_target = [0xff; 32];

        assert!(mining_state.check_nonce(nonce, &easy_target));

        // Verify against manually constructed double_sha256
        let _hash = double_sha256(&header);

        // Manual verification logic
        let mut midstate = H0;
        let mut block1 = [0u8; 64];
        block1.copy_from_slice(&header[0..64]);
        compress(&mut midstate, &block1);
        assert_eq!(midstate, mining_state.midstate, "Midstate mismatch");
    }

    #[test]
    fn test_range_mining() {
        let mut header = [0u8; 80];
        // Set a nonce that we will search for: 100
        let nonce: u32 = 100;
        header[76..80].copy_from_slice(&nonce.to_le_bytes());

        let mining_state = MiningState::new(&header);
        let target = [0xff; 32];

        let winners = mining_state.check_range(0, 200, &target);
        assert!(winners.contains(&100));
        assert!(winners.len() == 200); // All should win with target=0xff..ff
    }
}
