//! Integration edge case tests for compiler-backend handoff.
//!
//! These tests verify that edge cases in the compilation pipeline
//! are handled gracefully rather than panicking or producing
//! incorrect results.

use hologram_compiler::{
    compile, CompilerConfig, ConstantData, DType, OpKind, OpNode, OperationGraph,
};

// ============================================================================
// Zero-sized and empty tensor tests
// ============================================================================

#[test]
fn test_zero_element_tensor_in_shape() {
    // Shape with zero dimension should still compile (produces empty buffer)
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![0, 64], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Relu, vec![0, 64], DType::F32));
    graph.add_node(OpNode::new(2, OpKind::Output, vec![0, 64], DType::F32));
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    let config = CompilerConfig::default();
    let result = compile(&graph, &config);
    // Should compile successfully - zero-sized tensors are valid
    assert!(result.is_ok());
}

#[test]
fn test_scalar_tensor() {
    // Shape [] (scalar) should compile correctly
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Relu, vec![1], DType::F32));
    graph.add_node(OpNode::new(2, OpKind::Output, vec![1], DType::F32));
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    let config = CompilerConfig::default();
    let result = compile(&graph, &config);
    assert!(result.is_ok());
}

// ============================================================================
// Large tensor overflow protection tests
// ============================================================================

#[test]
fn test_large_tensor_no_overflow() {
    // Large but valid tensor size (should NOT overflow usize)
    // 1024 * 1024 * 4 = 4MB - reasonable size
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![1024, 1024], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Relu, vec![1024, 1024], DType::F32));
    graph.add_node(OpNode::new(2, OpKind::Output, vec![1024, 1024], DType::F32));
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    let config = CompilerConfig::default();
    let result = compile(&graph, &config);
    assert!(result.is_ok());

    let plan = result.unwrap();
    // Verify buffer size is computed correctly
    let expected_size = 1024 * 1024 * 4; // elements * sizeof(f32)
    assert!(plan.buffers.iter().any(|b| b.size == expected_size));
}

// ============================================================================
// Constant data edge cases
// ============================================================================

#[test]
fn test_constant_with_matching_data() {
    // Constant node with properly sized constant data
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![4], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![4], DType::F32));
    graph.add_constant_for_node(1, ConstantData::F32(vec![1.0, 2.0, 3.0, 4.0]));
    graph.add_node(OpNode::new(2, OpKind::Add, vec![4], DType::F32));
    graph.add_node(OpNode::new(3, OpKind::Output, vec![4], DType::F32));
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    let config = CompilerConfig::default();
    let result = compile(&graph, &config);
    assert!(result.is_ok());
}

#[test]
fn test_multiple_constants_correct_ordering() {
    // Multiple constants should all be serialized with correct data
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Constant, vec![2], DType::F32));
    graph.add_constant_for_node(0, ConstantData::F32(vec![1.0, 2.0]));
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![2], DType::F32));
    graph.add_constant_for_node(1, ConstantData::F32(vec![3.0, 4.0]));
    graph.add_node(OpNode::new(2, OpKind::Add, vec![2], DType::F32));
    graph.add_node(OpNode::new(3, OpKind::Output, vec![2], DType::F32));
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    let config = CompilerConfig::default();
    let result = compile(&graph, &config);
    assert!(result.is_ok());

    let plan = result.unwrap();
    // Constants should be serialized - verify non-empty
    assert!(!plan.constants.is_empty());
}

// ============================================================================
// Shape validation tests
// ============================================================================

#[test]
fn test_matmul_dimension_validation() {
    // Valid MatMul dimensions
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![8, 16], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Input, vec![16, 32], DType::F32));
    graph.add_node(OpNode::new(
        2,
        OpKind::MatMul { m: 8, k: 16, n: 32 },
        vec![8, 32],
        DType::F32,
    ));
    graph.add_node(OpNode::new(3, OpKind::Output, vec![8, 32], DType::F32));
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    let config = CompilerConfig::default();
    let result = compile(&graph, &config);
    assert!(result.is_ok());
}

#[test]
fn test_layernorm_requires_scale_bias() {
    // LayerNorm with scale and bias constants
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![2, 64], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![64], DType::F32)); // scale
    graph.add_constant_for_node(1, ConstantData::F32(vec![1.0; 64]));
    graph.add_node(OpNode::new(2, OpKind::Constant, vec![64], DType::F32)); // bias
    graph.add_constant_for_node(2, ConstantData::F32(vec![0.0; 64]));
    graph.add_node(OpNode::new(
        3,
        OpKind::LayerNorm {
            normalized_dims: 1,
            epsilon: 1e-5,
        },
        vec![2, 64],
        DType::F32,
    ));
    graph.add_node(OpNode::new(4, OpKind::Output, vec![2, 64], DType::F32));
    graph.add_edge(0, 3);
    graph.add_edge(1, 3);
    graph.add_edge(2, 3);
    graph.add_edge(3, 4);

    let config = CompilerConfig::default();
    let result = compile(&graph, &config);
    assert!(result.is_ok());
}

#[test]
fn test_softmax_axis_normalization() {
    // Softmax with various axis values including negative
    let test_cases = vec![
        (vec![4, 8], 1),     // axis=1
        (vec![4, 8], -1),    // axis=-1 (same as 1)
        (vec![2, 3, 4], 2),  // axis=2 on 3D
        (vec![2, 3, 4], -1), // axis=-1 on 3D
    ];

    for (shape, axis) in test_cases {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, shape.clone(), DType::F32));
        graph.add_node(OpNode::new(
            1,
            OpKind::Softmax { axis },
            shape.clone(),
            DType::F32,
        ));
        graph.add_node(OpNode::new(2, OpKind::Output, shape, DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        let config = CompilerConfig::default();
        let result = compile(&graph, &config);
        assert!(result.is_ok(), "Softmax axis={axis} should compile");
    }
}

// ============================================================================
// Buffer type and ordering tests
// ============================================================================

#[test]
fn test_buffer_types_in_plan() {
    use hologram_holo::types::BufferType;

    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![64], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Constant, vec![64], DType::F32));
    graph.add_constant_for_node(1, ConstantData::F32(vec![1.0; 64]));
    graph.add_node(OpNode::new(2, OpKind::Add, vec![64], DType::F32));
    graph.add_node(OpNode::new(3, OpKind::Relu, vec![64], DType::F32));
    graph.add_node(OpNode::new(4, OpKind::Output, vec![64], DType::F32));
    graph.add_edge(0, 2);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);
    graph.add_edge(3, 4);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).unwrap();

    // Verify all expected buffer types are present
    let types: Vec<_> = plan.buffers.iter().map(|b| b.buffer_type).collect();
    assert!(types.contains(&BufferType::Input), "Missing Input buffer");
    assert!(
        types.contains(&BufferType::Constant),
        "Missing Constant buffer"
    );
    assert!(types.contains(&BufferType::Output), "Missing Output buffer");
}

// ============================================================================
// Instruction encoding tests
// ============================================================================

#[test]
fn test_binary_ops_emit_instructions() {
    use hologram_holo::IsaInstruction;

    let ops = vec![
        (OpKind::Add, "Add"),
        (OpKind::Sub, "Sub"),
        (OpKind::Mul, "Mul"),
    ];

    for (op_kind, name) in ops {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![64], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![64], DType::F32));
        graph.add_node(OpNode::new(2, op_kind, vec![64], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![64], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);

        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).unwrap();

        // Should have at least one instruction for the binary op
        let has_binary = plan.instructions.iter().any(|i| {
            matches!(
                i,
                IsaInstruction::Add { .. }
                    | IsaInstruction::Sub { .. }
                    | IsaInstruction::Mul { .. }
            )
        });
        assert!(has_binary, "{name} should emit an instruction");
    }
}

#[test]
fn test_unary_ops_emit_instructions() {
    use hologram_holo::IsaInstruction;

    let ops = vec![
        OpKind::Relu,
        OpKind::Sigmoid,
        OpKind::Tanh,
        OpKind::Sqrt,
        OpKind::Exp,
        OpKind::Log,
        OpKind::Abs,
    ];

    for op_kind in ops {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![64], DType::F32));
        graph.add_node(OpNode::new(1, op_kind.clone(), vec![64], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![64], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);

        let config = CompilerConfig::default();
        let plan = compile(&graph, &config).unwrap();

        // Should have at least one instruction for the unary op
        let has_unary = plan.instructions.iter().any(|i| {
            matches!(
                i,
                IsaInstruction::Relu { .. }
                    | IsaInstruction::Sigmoid { .. }
                    | IsaInstruction::Tanh { .. }
                    | IsaInstruction::Sqrt { .. }
                    | IsaInstruction::Exp { .. }
                    | IsaInstruction::Log { .. }
                    | IsaInstruction::Abs { .. }
            )
        });
        assert!(has_unary, "{:?} should emit an instruction", op_kind);
    }
}

// ============================================================================
// Node buffer map tests
// ============================================================================

#[test]
fn test_node_buffer_map_coverage() {
    // Ensure all nodes have buffer mappings
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![32], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Relu, vec![32], DType::F32));
    graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![32], DType::F32));
    graph.add_node(OpNode::new(3, OpKind::Output, vec![32], DType::F32));
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);
    graph.add_edge(2, 3);

    let config = CompilerConfig::default();
    let plan = compile(&graph, &config).unwrap();

    // Verify node_buffer_map has entries for all nodes
    // The map is indexed by node_id, so entries should cover 0, 1, 2, 3
    for node_id in 0..=3u32 {
        let idx = node_id as usize;
        if idx < plan.node_buffer_map.len() {
            // Entry exists (may be None if node was fused away)
            let _ = plan.node_buffer_map[idx];
        }
    }
}

// ============================================================================
// Multi-output graph tests
// ============================================================================

#[test]
fn test_diamond_graph_compiles() {
    // Input -> [Branch1, Branch2] -> Output (diamond pattern)
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![64], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Relu, vec![64], DType::F32));
    graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![64], DType::F32));
    graph.add_node(OpNode::new(3, OpKind::Add, vec![64], DType::F32));
    graph.add_node(OpNode::new(4, OpKind::Output, vec![64], DType::F32));
    graph.add_edge(0, 1);
    graph.add_edge(0, 2);
    graph.add_edge(1, 3);
    graph.add_edge(2, 3);
    graph.add_edge(3, 4);

    let config = CompilerConfig::default();
    let result = compile(&graph, &config);
    assert!(result.is_ok());
}

#[test]
fn test_multiple_outputs_graph() {
    // Graph with two separate output branches
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(0, OpKind::Input, vec![64], DType::F32));
    graph.add_node(OpNode::new(1, OpKind::Relu, vec![64], DType::F32));
    graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![64], DType::F32));
    graph.add_node(OpNode::new(3, OpKind::Output, vec![64], DType::F32));
    graph.add_node(OpNode::new(4, OpKind::Output, vec![64], DType::F32));
    graph.add_edge(0, 1);
    graph.add_edge(0, 2);
    graph.add_edge(1, 3);
    graph.add_edge(2, 4);
    graph.add_output("out1", 3);
    graph.add_output("out2", 4);

    let config = CompilerConfig::default();
    let result = compile(&graph, &config);
    assert!(result.is_ok());
}

// ============================================================================
// High-rank tensor tests
// ============================================================================

#[test]
fn test_5d_tensor_support() {
    // 5D tensor (batch, channels, depth, height, width)
    let mut graph = OperationGraph::new();
    graph.add_node(OpNode::new(
        0,
        OpKind::Input,
        vec![2, 3, 4, 5, 6],
        DType::F32,
    ));
    graph.add_node(OpNode::new(
        1,
        OpKind::Relu,
        vec![2, 3, 4, 5, 6],
        DType::F32,
    ));
    graph.add_node(OpNode::new(
        2,
        OpKind::Output,
        vec![2, 3, 4, 5, 6],
        DType::F32,
    ));
    graph.add_edge(0, 1);
    graph.add_edge(1, 2);

    let config = CompilerConfig::default();
    let result = compile(&graph, &config);
    assert!(result.is_ok());
}

// ============================================================================
// Data type tests
// ============================================================================

#[test]
fn test_all_supported_dtypes() {
    let dtypes = vec![
        DType::F32,
        DType::F64,
        DType::I32,
        DType::I64,
        DType::U8,
        DType::I8,
    ];

    for dtype in dtypes {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![16], dtype));
        graph.add_node(OpNode::new(1, OpKind::Output, vec![16], dtype));
        graph.add_edge(0, 1);

        let config = CompilerConfig::default();
        let result = compile(&graph, &config);
        assert!(result.is_ok(), "DType {:?} should compile", dtype);
    }
}
