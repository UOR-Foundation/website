//! Registry trait definitions.
//!
//! This module provides abstract interfaces for registry implementations,
//! enabling both local and remote registries to share a common API.

use std::path::{Path, PathBuf};

use crate::error::Result;
use crate::layer_ref::LayerReference;
use crate::metadata::{LayerMetadata, SearchResult};

/// Trait for layer registry implementations.
///
/// This trait provides a unified interface for interacting with layer registries,
/// whether local file-based or remote HTTP-based.
///
/// # Example
///
/// ```rust,ignore
/// use hologram_registry::{Registry, LocalRegistry};
///
/// let registry = LocalRegistry::default_location()?;
/// let layer_ref = "my-model:v1.0".parse()?;
///
/// if registry.exists(&layer_ref)? {
///     let metadata = registry.metadata(&layer_ref)?;
///     println!("Layer size: {} bytes", metadata.size);
/// }
/// ```
pub trait Registry: Send + Sync {
    /// Check if a layer exists in the registry.
    fn exists(&self, layer: &LayerReference) -> Result<bool>;

    /// Get metadata for a layer.
    fn metadata(&self, layer: &LayerReference) -> Result<LayerMetadata>;

    /// Pull a layer from the registry to a local directory.
    ///
    /// Returns the path to the downloaded layer file.
    fn pull(&self, layer: &LayerReference, output_dir: &Path) -> Result<PathBuf>;

    /// Push a layer to the registry.
    ///
    /// Returns the digest of the uploaded layer.
    fn push(&self, layer: &LayerReference, source_path: &Path) -> Result<String>;

    /// Search for layers matching a query.
    fn search(&self, query: &str, limit: usize) -> Result<Vec<SearchResult>>;

    /// List available tags for a layer.
    fn tags(&self, layer: &LayerReference) -> Result<Vec<String>>;

    /// Delete a layer from the registry.
    fn delete(&self, layer: &LayerReference) -> Result<()>;
}

/// Async version of the Registry trait.
///
/// This trait provides async versions of all registry operations,
/// suitable for use with async HTTP clients like reqwest.
#[cfg(feature = "http-async")]
#[async_trait::async_trait]
pub trait AsyncRegistry: Send + Sync {
    /// Check if a layer exists in the registry.
    async fn exists(&self, layer: &LayerReference) -> Result<bool>;

    /// Get metadata for a layer.
    async fn metadata(&self, layer: &LayerReference) -> Result<LayerMetadata>;

    /// Pull a layer from the registry to a local directory.
    async fn pull(&self, layer: &LayerReference, output_dir: &Path) -> Result<PathBuf>;

    /// Push a layer to the registry.
    async fn push(&self, layer: &LayerReference, source_path: &Path) -> Result<String>;

    /// Search for layers matching a query.
    async fn search(&self, query: &str, limit: usize) -> Result<Vec<SearchResult>>;

    /// List available tags for a layer.
    async fn tags(&self, layer: &LayerReference) -> Result<Vec<String>>;

    /// Delete a layer from the registry.
    async fn delete(&self, layer: &LayerReference) -> Result<()>;
}

#[cfg(test)]
mod tests {
    #[test]
    fn test_trait_object_safety() {
        // Verify Registry trait is object-safe by attempting to create a dyn reference
        fn _takes_registry(_r: &dyn super::Registry) {}
    }
}
