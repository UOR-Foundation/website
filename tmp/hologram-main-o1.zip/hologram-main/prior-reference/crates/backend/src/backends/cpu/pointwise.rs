//! SIMD-optimized pointwise (1×1) convolution kernels.
//!
//! Pointwise convolution is a special case where the kernel is 1×1, which means
//! no spatial information is used - only channel mixing. This makes it equivalent
//! to a matrix multiplication with proper reshaping.
//!
//! # Performance Characteristics
//!
//! Pointwise convolution is typically memory-bandwidth bound since:
//! - Compute: O(N×H×W×C_in×C_out) - same as standard 1×1 conv
//! - Memory: O(N×H×W×(C_in + C_out)) for input + output
//! - No kernel reuse across spatial positions
//!
//! # Implementation Strategy
//!
//! Convert to GEMM:
//! - Input [N, C_in, H, W] → [N×H×W, C_in]
//! - Kernel [C_out, C_in, 1, 1] → [C_in, C_out]
//! - Output [N×H×W, C_out] → [N, C_out, H, W]
//!
//! This allows reusing the highly optimized GEMM kernels.

use crate::{BackendError, PointwiseConvParams};

/// Optimized pointwise convolution via GEMM.
///
/// This implementation avoids explicit transpose by computing the output
/// directly in the correct layout using tiled access patterns.
pub fn pointwise_conv_f32(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &PointwiseConvParams,
) -> Result<(), BackendError> {
    let batch = params.batch_size() as usize;
    let c_in = params.input_channels() as usize;
    let c_out = params.out_channels as usize;
    let height = params.input_dims[2] as usize;
    let width = params.input_dims[3] as usize;
    let spatial = height * width;

    // Validate buffer sizes
    let expected_input = batch * c_in * spatial;
    let expected_output = batch * c_out * spatial;
    let expected_kernel = c_out * c_in;

    if input.len() < expected_input {
        return Err(BackendError::buffer(
            "input buffer too small for pointwise conv",
        ));
    }
    if output.len() < expected_output {
        return Err(BackendError::buffer(
            "output buffer too small for pointwise conv",
        ));
    }
    if kernel.len() < expected_kernel {
        return Err(BackendError::buffer(
            "kernel buffer too small for pointwise conv",
        ));
    }

    // Choose implementation based on CPU capability
    #[cfg(target_arch = "x86_64")]
    {
        if is_x86_feature_detected!("avx2") && is_x86_feature_detected!("fma") {
            return unsafe {
                pointwise_avx2(
                    output, input, kernel, bias, batch, c_in, c_out, height, width,
                )
            };
        }
    }

    // Fallback to scalar
    pointwise_scalar(
        output, input, kernel, bias, batch, c_in, c_out, height, width,
    )
}

/// Scalar implementation of pointwise convolution.
#[allow(clippy::too_many_arguments)]
fn pointwise_scalar(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    batch: usize,
    c_in: usize,
    c_out: usize,
    height: usize,
    width: usize,
) -> Result<(), BackendError> {
    let spatial = height * width;

    // Kernel layout: [C_out, C_in]
    // Input layout: [N, C_in, H, W]
    // Output layout: [N, C_out, H, W]

    for n in 0..batch {
        for h in 0..height {
            for w in 0..width {
                for oc in 0..c_out {
                    let mut sum = 0.0f32;

                    // Dot product over input channels
                    for ic in 0..c_in {
                        let in_idx = (n * c_in + ic) * spatial + h * width + w;
                        let k_idx = oc * c_in + ic;
                        sum += input[in_idx] * kernel[k_idx];
                    }

                    // Add bias
                    if let Some(b) = bias {
                        if oc < b.len() {
                            sum += b[oc];
                        }
                    }

                    let out_idx = (n * c_out + oc) * spatial + h * width + w;
                    output[out_idx] = sum;
                }
            }
        }
    }

    Ok(())
}

/// AVX2-optimized pointwise convolution.
///
/// Processes multiple output channels simultaneously using FMA.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2", enable = "fma")]
#[allow(clippy::too_many_arguments, clippy::needless_range_loop)]
unsafe fn pointwise_avx2(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    batch: usize,
    c_in: usize,
    c_out: usize,
    height: usize,
    width: usize,
) -> Result<(), BackendError> {
    use std::arch::x86_64::*;

    let spatial = height * width;

    // Process 8 output channels at a time
    let c_out_vec = c_out / 8 * 8;

    for n in 0..batch {
        // Process spatial positions
        for pos in 0..spatial {
            // SIMD path: 8 output channels at once
            for oc_base in (0..c_out_vec).step_by(8) {
                let mut sum = _mm256_setzero_ps();

                // Accumulate over input channels
                for ic in 0..c_in {
                    let in_idx = (n * c_in + ic) * spatial + pos;
                    let in_val = *input.get(in_idx).unwrap_or(&0.0);
                    let in_broadcast = _mm256_set1_ps(in_val);

                    // Load 8 kernel weights: kernel[oc_base..oc_base+8, ic]
                    // Kernel is [C_out, C_in], so stride by c_in
                    let mut k_vals = [0.0f32; 8];
                    for i in 0..8 {
                        let k_idx = (oc_base + i) * c_in + ic;
                        k_vals[i] = *kernel.get(k_idx).unwrap_or(&0.0);
                    }
                    let k_vec = _mm256_loadu_ps(k_vals.as_ptr());

                    sum = _mm256_fmadd_ps(in_broadcast, k_vec, sum);
                }

                // Add bias
                if let Some(b) = bias {
                    let mut bias_arr = [0.0f32; 8];
                    for i in 0..8 {
                        bias_arr[i] = *b.get(oc_base + i).unwrap_or(&0.0);
                    }
                    let bias_vec = _mm256_loadu_ps(bias_arr.as_ptr());
                    sum = _mm256_add_ps(sum, bias_vec);
                }

                // Store results
                let mut result = [0.0f32; 8];
                _mm256_storeu_ps(result.as_mut_ptr(), sum);

                for i in 0..8 {
                    let out_idx = (n * c_out + oc_base + i) * spatial + pos;
                    if out_idx < output.len() {
                        output[out_idx] = result[i];
                    }
                }
            }

            // Scalar path for remaining output channels
            for oc in c_out_vec..c_out {
                let mut sum = 0.0f32;

                for ic in 0..c_in {
                    let in_idx = (n * c_in + ic) * spatial + pos;
                    let k_idx = oc * c_in + ic;
                    sum += input.get(in_idx).copied().unwrap_or(0.0)
                        * kernel.get(k_idx).copied().unwrap_or(0.0);
                }

                if let Some(b) = bias {
                    sum += b.get(oc).copied().unwrap_or(0.0);
                }

                let out_idx = (n * c_out + oc) * spatial + pos;
                if out_idx < output.len() {
                    output[out_idx] = sum;
                }
            }
        }
    }

    Ok(())
}

/// Convert pointwise conv to equivalent GEMM operation.
///
/// Returns (M, K, N) dimensions where:
/// - M = batch × height × width (spatial positions)
/// - K = input_channels
/// - N = output_channels
pub fn to_gemm_dims(params: &PointwiseConvParams) -> (usize, usize, usize) {
    let (m, k, n) = params.as_matmul_dims();
    (m as usize, k as usize, n as usize)
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_isa::Type;

    #[test]
    fn test_pointwise_basic() {
        // 1 batch, 2 input channels, 2×2 spatial, 3 output channels
        let params = PointwiseConvParams::new([1, 2, 2, 2], 3, Type::F32);

        // Input: [1, 2, 2, 2] = 8 elements
        // Channel 0: all 1s, Channel 1: all 2s
        let input = vec![
            1.0, 1.0, 1.0, 1.0, // channel 0
            2.0, 2.0, 2.0, 2.0, // channel 1
        ];

        // Kernel: [3, 2] - 3 output channels, 2 input channels
        let kernel = vec![
            1.0, 1.0, // out_ch 0: sum both input channels
            1.0, 0.0, // out_ch 1: only input channel 0
            0.0, 1.0, // out_ch 2: only input channel 1
        ];

        let mut output = vec![0.0f32; 12]; // 1 × 3 × 2 × 2

        pointwise_conv_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Output channel 0: 1*1 + 2*1 = 3 for each position
        // Output channel 1: 1*1 + 2*0 = 1 for each position
        // Output channel 2: 1*0 + 2*1 = 2 for each position
        let expected = vec![
            3.0, 3.0, 3.0, 3.0, // out channel 0
            1.0, 1.0, 1.0, 1.0, // out channel 1
            2.0, 2.0, 2.0, 2.0, // out channel 2
        ];

        for (i, (&out, &exp)) in output.iter().zip(expected.iter()).enumerate() {
            assert!(
                (out - exp).abs() < 1e-5,
                "mismatch at {}: got {}, expected {}",
                i,
                out,
                exp
            );
        }
    }

    #[test]
    fn test_pointwise_with_bias() {
        let params = PointwiseConvParams::new([1, 1, 2, 2], 2, Type::F32);

        let input = vec![1.0f32; 4];
        let kernel = vec![1.0, 2.0]; // [2, 1]
        let bias = vec![10.0, 20.0]; // bias per output channel

        let mut output = vec![0.0f32; 8];

        pointwise_conv_f32(&mut output, &input, &kernel, Some(&bias), &params).unwrap();

        // Out channel 0: 1*1 + 10 = 11
        // Out channel 1: 1*2 + 20 = 22
        for i in 0..4 {
            assert!((output[i] - 11.0).abs() < 1e-5);
            assert!((output[4 + i] - 22.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_pointwise_batch() {
        // 2 batches
        let params = PointwiseConvParams::new([2, 1, 2, 2], 1, Type::F32);

        // Batch 0: 1s, Batch 1: 2s
        let input = vec![
            1.0, 1.0, 1.0, 1.0, // batch 0
            2.0, 2.0, 2.0, 2.0, // batch 1
        ];
        let kernel = vec![3.0]; // single weight

        let mut output = vec![0.0f32; 8];

        pointwise_conv_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Batch 0: 1*3 = 3, Batch 1: 2*3 = 6
        for i in 0..4 {
            assert!((output[i] - 3.0).abs() < 1e-5);
            assert!((output[4 + i] - 6.0).abs() < 1e-5);
        }
    }

    #[test]
    fn test_to_gemm_dims() {
        let params = PointwiseConvParams::new([2, 64, 14, 14], 128, Type::F32);
        let (m, k, n) = to_gemm_dims(&params);

        assert_eq!(m, 2 * 14 * 14); // batch × spatial
        assert_eq!(k, 64); // input channels
        assert_eq!(n, 128); // output channels
    }

    #[test]
    fn test_pointwise_identity() {
        // Identity: kernel = eye(3)
        let params = PointwiseConvParams::new([1, 3, 2, 2], 3, Type::F32);

        let input = vec![
            1.0, 2.0, 3.0, 4.0, // channel 0
            5.0, 6.0, 7.0, 8.0, // channel 1
            9.0, 10.0, 11.0, 12.0, // channel 2
        ];

        // Identity kernel
        let kernel = vec![
            1.0, 0.0, 0.0, // out 0 = in 0
            0.0, 1.0, 0.0, // out 1 = in 1
            0.0, 0.0, 1.0, // out 2 = in 2
        ];

        let mut output = vec![0.0f32; 12];

        pointwise_conv_f32(&mut output, &input, &kernel, None, &params).unwrap();

        // Output should equal input
        for (out, inp) in output.iter().zip(input.iter()) {
            assert!((out - inp).abs() < 1e-5);
        }
    }
}
