export { default } from "@/modules/identity/components/CoverImage";
