//! Benchmarks for grouped convolution optimizations.
//!
//! Compares performance of different grouped convolution implementations:
//! - Direct nested loops (baseline)
//! - Im2col + GEMM (optimized)
//! - Parallel execution (multi-threaded)

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use hologram_backend::cpu::grouped::grouped_conv2d_f32;
use hologram_backend::GroupedConv2DParams;
use hologram_isa::Type;

/// Benchmark grouped convolution with various configurations.
fn bench_grouped_conv(c: &mut Criterion) {
    let mut group = c.benchmark_group("grouped_conv");

    // Test configurations: (batch, channels, height, width, groups, kernel_size)
    let configs = [
        // Small: might use direct path
        (1, 16, 8, 8, 4, 3),
        // Medium: should use Im2col+GEMM
        (1, 64, 28, 28, 8, 3),
        // Large: should use parallel
        (4, 128, 56, 56, 8, 3),
        // ResNeXt-like configuration
        (1, 256, 14, 14, 32, 3),
    ];

    for (batch, channels, height, width, groups, kernel_size) in configs {
        let in_ch_per_group = channels / groups;

        let params = GroupedConv2DParams::new(
            [batch, channels, height, width],
            [channels, in_ch_per_group, kernel_size, kernel_size],
            groups,
            Type::F32,
        )
        .with_padding(1, 1);

        let out_dims = params.output_dims();
        let input_size = batch * channels * height * width;
        let kernel_size_total = channels * in_ch_per_group * kernel_size * kernel_size;
        let output_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        let input: Vec<f32> = (0..input_size).map(|i| (i % 7) as f32 * 0.1).collect();
        let kernel: Vec<f32> = (0..kernel_size_total)
            .map(|i| (i % 5) as f32 * 0.1)
            .collect();
        let mut output = vec![0.0f32; output_size];

        let config_name = format!(
            "b{}c{}h{}w{}g{}k{}",
            batch, channels, height, width, groups, kernel_size
        );

        // Set throughput in terms of output elements
        group.throughput(Throughput::Elements(output_size as u64));

        group.bench_with_input(
            BenchmarkId::new("grouped_conv2d", &config_name),
            &(&input, &kernel, &params),
            |b, (input, kernel, params)| {
                b.iter(|| {
                    grouped_conv2d_f32(
                        black_box(&mut output),
                        black_box(input),
                        black_box(kernel),
                        None,
                        black_box(params),
                    )
                    .unwrap();
                });
            },
        );
    }

    group.finish();
}

/// Benchmark scaling with different group counts.
fn bench_group_scaling(c: &mut Criterion) {
    let mut group = c.benchmark_group("group_scaling");

    let batch = 1;
    let channels = 64;
    let height = 28;
    let width = 28;
    let kernel_size = 3;

    // Test different group counts
    let group_counts = [1, 2, 4, 8, 16, 32, 64];

    for groups in group_counts {
        if channels % groups != 0 {
            continue;
        }

        let in_ch_per_group = channels / groups;

        let params = GroupedConv2DParams::new(
            [batch, channels, height, width],
            [channels, in_ch_per_group, kernel_size, kernel_size],
            groups,
            Type::F32,
        )
        .with_padding(1, 1);

        let out_dims = params.output_dims();
        let input_size = batch * channels * height * width;
        let kernel_size_total = channels * in_ch_per_group * kernel_size * kernel_size;
        let output_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        let input: Vec<f32> = (0..input_size).map(|i| (i % 7) as f32 * 0.1).collect();
        let kernel: Vec<f32> = (0..kernel_size_total)
            .map(|i| (i % 5) as f32 * 0.1)
            .collect();
        let mut output = vec![0.0f32; output_size];

        group.throughput(Throughput::Elements(output_size as u64));

        group.bench_with_input(
            BenchmarkId::new("groups", groups),
            &(&input, &kernel, &params),
            |b, (input, kernel, params)| {
                b.iter(|| {
                    grouped_conv2d_f32(
                        black_box(&mut output),
                        black_box(input),
                        black_box(kernel),
                        None,
                        black_box(params),
                    )
                    .unwrap();
                });
            },
        );
    }

    group.finish();
}

/// Benchmark scaling with batch size.
fn bench_batch_scaling(c: &mut Criterion) {
    let mut group = c.benchmark_group("batch_scaling");

    let channels = 64;
    let height = 14;
    let width = 14;
    let groups = 8;
    let kernel_size = 3;
    let in_ch_per_group = channels / groups;

    // Test different batch sizes
    let batch_sizes = [1, 2, 4, 8, 16];

    for batch in batch_sizes {
        let params = GroupedConv2DParams::new(
            [batch, channels, height, width],
            [channels, in_ch_per_group, kernel_size, kernel_size],
            groups,
            Type::F32,
        )
        .with_padding(1, 1);

        let out_dims = params.output_dims();
        let input_size = batch * channels * height * width;
        let kernel_size_total = channels * in_ch_per_group * kernel_size * kernel_size;
        let output_size = out_dims[0] as usize
            * out_dims[1] as usize
            * out_dims[2] as usize
            * out_dims[3] as usize;

        let input: Vec<f32> = (0..input_size).map(|i| (i % 7) as f32 * 0.1).collect();
        let kernel: Vec<f32> = (0..kernel_size_total)
            .map(|i| (i % 5) as f32 * 0.1)
            .collect();
        let mut output = vec![0.0f32; output_size];

        group.throughput(Throughput::Elements(output_size as u64));

        group.bench_with_input(
            BenchmarkId::new("batch", batch),
            &(&input, &kernel, &params),
            |b, (input, kernel, params)| {
                b.iter(|| {
                    grouped_conv2d_f32(
                        black_box(&mut output),
                        black_box(input),
                        black_box(kernel),
                        None,
                        black_box(params),
                    )
                    .unwrap();
                });
            },
        );
    }

    group.finish();
}

criterion_group!(
    benches,
    bench_grouped_conv,
    bench_group_scaling,
    bench_batch_scaling
);
criterion_main!(benches);
