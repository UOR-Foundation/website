//! API router setup.

use crate::api::handlers;
use crate::state::AppState;
use axum::{
    routing::{get, patch, post},
    Router,
};
use std::sync::Arc;
use tower_http::cors::{Any, CorsLayer};
use tower_http::trace::TraceLayer;

/// Build the API router.
pub fn build_router(state: Arc<AppState>) -> Router {
    let cors = CorsLayer::new()
        .allow_origin(Any)
        .allow_methods(Any)
        .allow_headers(Any);

    Router::new()
        // Home
        .route("/", get(handlers::home))
        // Schemas
        .route("/api/schemas", get(handlers::list_schemas))
        .route("/api/schemas/:id", get(handlers::get_schema))
        .route(
            "/api/schemas/:id/context",
            get(handlers::get_schema_context),
        )
        .route("/api/schemas/:id/graph", get(handlers::get_schema_graph))
        // Taxons
        .route("/api/taxons", get(handlers::list_taxons))
        .route(
            "/api/taxons/by-domain/:domain",
            get(handlers::get_taxons_by_domain),
        )
        .route("/api/taxons/:value", get(handlers::get_taxon))
        // Domains
        .route("/api/domains", get(handlers::list_domains))
        .route("/api/domains/:name", get(handlers::get_domain))
        // Constants
        .route("/api/constants", get(handlers::list_constants))
        .route("/api/constants/:name", get(handlers::get_constant))
        .route("/api/constants/:name", patch(handlers::update_constant))
        // Mutations
        .route("/api/mutations/preview", post(handlers::preview_mutation))
        .route("/api/mutations/reset", post(handlers::reset_constants))
        // Gauge Tower
        .route("/api/gauge-tower", get(handlers::get_gauge_tower))
        .route("/api/gauge-tower/levels", get(handlers::get_gauge_levels))
        .route(
            "/api/gauge-tower/levels/:index",
            get(handlers::get_gauge_level),
        )
        // Dynamic query endpoint
        .route("/api/query", post(handlers::execute_query))
        // Query-layer routes (LUT-backed, O(1))
        .route("/api/query/byte/:value", get(handlers::resolve_byte))
        .route("/api/query/ring/:value", get(handlers::resolve_ring))
        .route("/api/query/ring/:op/:a/:b", get(handlers::ring_op))
        .route(
            "/api/query/activation/:value",
            get(handlers::resolve_activation),
        )
        // HTML routes (same as API but for browser navigation)
        .route("/schemas", get(handlers::list_schemas))
        .route("/schemas/:id", get(handlers::get_schema))
        .route("/taxons", get(handlers::list_taxons))
        .route(
            "/taxons/by-domain/:domain",
            get(handlers::get_taxons_by_domain),
        )
        .route("/taxons/:value", get(handlers::get_taxon))
        .route("/domains", get(handlers::list_domains))
        .route("/domains/:name", get(handlers::get_domain))
        .route("/constants", get(handlers::list_constants))
        .route("/constants/:name", get(handlers::get_constant))
        .route("/gauge-tower", get(handlers::get_gauge_tower))
        .route("/gauge-tower/levels/:index", get(handlers::get_gauge_level))
        // Middleware
        .layer(cors)
        .layer(TraceLayer::new_for_http())
        .with_state(state)
}
