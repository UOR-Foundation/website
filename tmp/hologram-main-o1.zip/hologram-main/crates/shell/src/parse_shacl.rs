//! SHACL Turtle subset parser built on nom combinators.
//!
//! Parses `.ttl` SHACL shape files into [`ShaclShape`] AST nodes.
//! Only the Turtle subset used by `descriptors/shacl/*.ttl` is supported.

use nom::{
    branch::alt,
    bytes::complete::{tag, take_until, take_while, take_while1},
    character::complete::{char, multispace0},
    combinator::{map, opt, recognize},
    multi::many0,
    sequence::{delimited, preceded, tuple},
    IResult,
};

use crate::ast::{ShaclProperty, ShaclShape, XsdType};
use crate::error::ParseError;

// ============================================================================
// Whitespace and comments
// ============================================================================

/// Consume whitespace and `# ...` line comments.
fn ws(input: &str) -> IResult<&str, ()> {
    let (input, _) = multispace0(input)?;
    let mut remaining = input;
    loop {
        let (r, _) = multispace0(remaining)?;
        if r.starts_with('#') {
            let newline_pos = r.find('\n').unwrap_or(r.len());
            remaining = &r[newline_pos..];
        } else {
            remaining = r;
            break;
        }
    }
    Ok((remaining, ()))
}

/// Wrap a parser to consume leading whitespace/comments.
fn wsp<'a, O, F>(f: F) -> impl FnMut(&'a str) -> IResult<&'a str, O>
where
    F: FnMut(&'a str) -> IResult<&'a str, O>,
{
    preceded(ws, f)
}

// ============================================================================
// Turtle primitives
// ============================================================================

/// Parse a prefixed name: `prefix:local`
fn prefixed_name(input: &str) -> IResult<&str, (&str, &str)> {
    let (input, prefix) = take_while(|c: char| c.is_ascii_alphanumeric())(input)?;
    let (input, _) = char(':')(input)?;
    let (input, local) = take_while1(|c: char| c.is_ascii_alphanumeric() || c == '_')(input)?;
    Ok((input, (prefix, local)))
}

/// Parse a full IRI: `<https://...>`
fn full_iri(input: &str) -> IResult<&str, &str> {
    delimited(char('<'), take_until(">"), char('>'))(input)
}

/// Parse either a prefixed name or a full IRI, returning the string form.
fn iri_ref(input: &str) -> IResult<&str, String> {
    alt((
        map(full_iri, |s| s.to_string()),
        map(prefixed_name, |(p, l)| format!("{p}:{l}")),
    ))(input)
}

/// Parse a quoted string: `"contents"`
fn quoted_string(input: &str) -> IResult<&str, &str> {
    delimited(char('"'), take_while(|c: char| c != '"'), char('"'))(input)
}

/// Parse an integer literal (possibly negative).
fn integer_literal(input: &str) -> IResult<&str, i64> {
    let (input, s) = recognize(tuple((
        opt(char('-')),
        take_while1(|c: char| c.is_ascii_digit()),
    )))(input)?;
    let val = s.parse::<i64>().map_err(|_| {
        nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Digit))
    })?;
    Ok((input, val))
}

// ============================================================================
// Prefix declarations
// ============================================================================

/// Parse `@prefix foo: <uri> .`
fn prefix_decl(input: &str) -> IResult<&str, (String, String)> {
    let (input, _) = wsp(tag("@prefix"))(input)?;
    let (input, _) = multispace0(input)?;
    let (input, name) = take_while(|c: char| c.is_ascii_alphanumeric())(input)?;
    let (input, _) = char(':')(input)?;
    let (input, _) = multispace0(input)?;
    let (input, uri) = full_iri(input)?;
    let (input, _) = wsp(char('.'))(input)?;
    Ok((input, (name.to_string(), uri.to_string())))
}

// ============================================================================
// SHACL property block
// ============================================================================

/// Internal representation of a predicate-object pair inside a blank node.
#[derive(Debug)]
enum PropPair {
    Path(String),
    Datatype(XsdType),
    MinCount(u64),
    MaxCount(u64),
    MinInclusive(i64),
    MaxInclusive(i64),
    MinLength(u64),
    MaxLength(u64),
    Name(String),
    InValues(Vec<String>),
    Other,
}

/// Map an IRI to an `XsdType`.
fn parse_xsd_type(iri: &str) -> Option<XsdType> {
    match iri {
        "xsd:unsignedShort" => Some(XsdType::UnsignedShort),
        "xsd:unsignedByte" => Some(XsdType::UnsignedByte),
        "xsd:unsignedInt" => Some(XsdType::UnsignedInt),
        "xsd:hexBinary" => Some(XsdType::HexBinary),
        "xsd:string" => Some(XsdType::String),
        "xsd:nonNegativeInteger" => Some(XsdType::NonNegativeInteger),
        "xsd:positiveInteger" => Some(XsdType::PositiveInteger),
        "xsd:integer" => Some(XsdType::Integer),
        "xsd:double" => Some(XsdType::Double),
        "xsd:dateTime" => Some(XsdType::DateTime),
        "xsd:boolean" => Some(XsdType::Boolean),
        _ => None,
    }
}

/// Parse `sh:in ( "val1" "val2" ... )`
fn sh_in_list(input: &str) -> IResult<&str, Vec<String>> {
    let (input, _) = wsp(char('('))(input)?;
    let (input, values) = many0(wsp(map(quoted_string, String::from)))(input)?;
    let (input, _) = wsp(char(')'))(input)?;
    Ok((input, values))
}

/// Parse a single predicate-object pair within a property blank node.
fn prop_pair(input: &str) -> IResult<&str, PropPair> {
    let (input, predicate) = wsp(iri_ref)(input)?;
    let (input, _) = multispace0(input)?;

    match predicate.as_str() {
        "sh:path" => {
            let (input, obj) = iri_ref(input)?;
            Ok((input, PropPair::Path(obj)))
        }
        "sh:datatype" => {
            let (input, obj) = iri_ref(input)?;
            Ok((
                input,
                parse_xsd_type(&obj).map_or(PropPair::Other, PropPair::Datatype),
            ))
        }
        "sh:minCount" => {
            let (input, v) = integer_literal(input)?;
            Ok((input, PropPair::MinCount(v as u64)))
        }
        "sh:maxCount" => {
            let (input, v) = integer_literal(input)?;
            Ok((input, PropPair::MaxCount(v as u64)))
        }
        "sh:minInclusive" => {
            let (input, v) = integer_literal(input)?;
            Ok((input, PropPair::MinInclusive(v)))
        }
        "sh:maxInclusive" => {
            let (input, v) = integer_literal(input)?;
            Ok((input, PropPair::MaxInclusive(v)))
        }
        "sh:minLength" => {
            let (input, v) = integer_literal(input)?;
            Ok((input, PropPair::MinLength(v as u64)))
        }
        "sh:maxLength" => {
            let (input, v) = integer_literal(input)?;
            Ok((input, PropPair::MaxLength(v as u64)))
        }
        "sh:name" => {
            let (input, s) = quoted_string(input)?;
            Ok((input, PropPair::Name(s.to_string())))
        }
        "sh:in" => {
            let (input, vals) = sh_in_list(input)?;
            Ok((input, PropPair::InValues(vals)))
        }
        _ => {
            // Skip unknown predicates: consume object (iri or string or integer)
            let (input, _) = alt((
                map(quoted_string, |_| ()),
                map(iri_ref, |_| ()),
                map(integer_literal, |_| ()),
            ))(input)?;
            Ok((input, PropPair::Other))
        }
    }
}

/// Parse a blank node `[ pairs... ]` into a `ShaclProperty`.
fn property_blank_node(input: &str) -> IResult<&str, ShaclProperty> {
    let (input, _) = wsp(char('['))(input)?;

    let mut path = String::new();
    let mut datatype = None;
    let mut min_count = None;
    let mut max_count = None;
    let mut min_inclusive = None;
    let mut max_inclusive = None;
    let mut min_length = None;
    let mut max_length = None;
    let mut name = String::new();
    let mut in_values = None;

    let mut remaining = input;
    loop {
        let (r, _) = ws(remaining)?;
        if let Some(rest) = r.strip_prefix(']') {
            remaining = rest;
            break;
        }
        let (r, pair) = prop_pair(r)?;
        match pair {
            PropPair::Path(v) => path = local_name(&v),
            PropPair::Datatype(t) => datatype = Some(t),
            PropPair::MinCount(v) => min_count = Some(v),
            PropPair::MaxCount(v) => max_count = Some(v),
            PropPair::MinInclusive(v) => min_inclusive = Some(v),
            PropPair::MaxInclusive(v) => max_inclusive = Some(v),
            PropPair::MinLength(v) => min_length = Some(v),
            PropPair::MaxLength(v) => max_length = Some(v),
            PropPair::Name(s) => name = s,
            PropPair::InValues(v) => in_values = Some(v),
            PropPair::Other => {}
        }
        // Consume optional `;` separator
        let (r, _) = ws(r)?;
        let (r, _) = opt(char(';'))(r)?;
        remaining = r;
    }

    Ok((
        remaining,
        ShaclProperty {
            name,
            path,
            datatype,
            min_count,
            max_count,
            min_inclusive,
            max_inclusive,
            in_values,
            min_length,
            max_length,
        },
    ))
}

// ============================================================================
// Node shape parsing
// ============================================================================

/// Internal representation of a top-level shape predicate-object pair.
#[derive(Debug)]
enum ShapePair {
    TargetClass(String),
    Label(String),
    Comment(String),
    Property(ShaclProperty),
    Other,
}

/// Parse a single predicate-object pair at the shape level.
fn shape_pair(input: &str) -> IResult<&str, ShapePair> {
    let (input, predicate) = wsp(iri_ref)(input)?;
    let (input, _) = multispace0(input)?;

    match predicate.as_str() {
        "sh:targetClass" => {
            let (input, obj) = iri_ref(input)?;
            Ok((input, ShapePair::TargetClass(obj)))
        }
        "rdfs:label" => {
            let (input, s) = quoted_string(input)?;
            Ok((input, ShapePair::Label(s.to_string())))
        }
        "rdfs:comment" => {
            let (input, s) = quoted_string(input)?;
            Ok((input, ShapePair::Comment(s.to_string())))
        }
        "sh:property" => {
            let (input, prop) = property_blank_node(input)?;
            Ok((input, ShapePair::Property(prop)))
        }
        _ => {
            // Skip unknown: consume object
            let (input, _) = alt((
                map(quoted_string, |_| ()),
                map(iri_ref, |_| ()),
                map(integer_literal, |_| ()),
            ))(input)?;
            Ok((input, ShapePair::Other))
        }
    }
}

/// Parse a complete node shape: `name a sh:NodeShape ; ... .`
fn node_shape(input: &str) -> IResult<&str, ShaclShape> {
    // Subject
    let (input, subject) = wsp(iri_ref)(input)?;
    // `a sh:NodeShape ;`
    let (input, _) = wsp(tag("a"))(input)?;
    let (input, _) = wsp(tag("sh:NodeShape"))(input)?;
    let (input, _) = wsp(char(';'))(input)?;

    let mut target_class = String::new();
    let mut label = String::new();
    let mut comment = String::new();
    let mut properties = Vec::new();

    let mut remaining = input;
    loop {
        let (r, _) = ws(remaining)?;
        if let Some(rest) = r.strip_prefix('.') {
            remaining = rest;
            break;
        }
        if r.is_empty() {
            remaining = r;
            break;
        }
        let (r, pair) = shape_pair(r)?;
        match pair {
            ShapePair::TargetClass(v) => target_class = local_name(&v),
            ShapePair::Label(s) => label = s,
            ShapePair::Comment(s) => comment = s,
            ShapePair::Property(p) => properties.push(p),
            ShapePair::Other => {}
        }
        let (r, _) = ws(r)?;
        let (r, _) = opt(char(';'))(r)?;
        remaining = r;
    }

    Ok((
        remaining,
        ShaclShape {
            name: local_name(&subject),
            target_class,
            label,
            comment,
            properties,
        },
    ))
}

// ============================================================================
// Top-level parser
// ============================================================================

/// Extract the local name from a prefixed name or full IRI.
///
/// `"datum:Q1Datum"` → `"Q1Datum"`
/// `"https://uor.foundation/certificate/Q1ScalingCertificate"` → `"Q1ScalingCertificate"`
fn local_name(iri: &str) -> String {
    // Full IRIs (contain "://") → take after last '/'
    if iri.contains("://") {
        return iri.rsplit('/').next().unwrap_or(iri).to_string();
    }
    // Prefixed names → take after ':'
    if let Some(pos) = iri.rfind(':') {
        iri[pos + 1..].to_string()
    } else {
        iri.to_string()
    }
}

/// Parse a complete SHACL Turtle file into a list of shapes.
///
/// # Errors
///
/// Returns `ParseError` if the Turtle syntax is malformed.
pub fn parse_shacl_file(input: &str) -> Result<Vec<ShaclShape>, ParseError> {
    let original = input;
    let mut remaining = input;
    let mut shapes = Vec::new();

    // Parse prefix declarations
    loop {
        let (r, _) = ws(remaining).map_err(|_| ParseError {
            message: "whitespace".into(),
            offset: 0,
            remaining: remaining[..remaining.len().min(40)].into(),
        })?;
        if r.starts_with("@prefix") {
            let (r, _pair) = prefix_decl(r)
                .map_err(|_| ParseError::from_nom(r, original, "expected @prefix declaration"))?;
            remaining = r;
        } else {
            remaining = r;
            break;
        }
    }

    // Parse node shapes
    loop {
        let (r, _) = ws(remaining).unwrap_or((remaining, ()));
        if r.is_empty() {
            break;
        }
        let (r, shape) = node_shape(r)
            .map_err(|_| ParseError::from_nom(r, original, "expected SHACL node shape"))?;
        shapes.push(shape);
        remaining = r;
    }

    Ok(shapes)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn local_name_prefixed() {
        assert_eq!(local_name("datum:Q1Datum"), "Q1Datum");
        assert_eq!(local_name("sh:NodeShape"), "NodeShape");
    }

    #[test]
    fn local_name_full_iri() {
        assert_eq!(
            local_name("https://uor.foundation/certificate/Q1ScalingCertificate"),
            "Q1ScalingCertificate"
        );
    }

    #[test]
    fn parse_xsd_types() {
        assert_eq!(
            parse_xsd_type("xsd:unsignedShort"),
            Some(XsdType::UnsignedShort)
        );
        assert_eq!(parse_xsd_type("xsd:boolean"), Some(XsdType::Boolean));
        assert_eq!(parse_xsd_type("xsd:unknown"), None);
    }

    #[test]
    fn parse_datum_shapes() {
        let input = include_str!("../../../descriptors/shacl/datum-shapes.ttl");
        let shapes = parse_shacl_file(input).unwrap();
        assert_eq!(shapes.len(), 2);

        let datum = &shapes[0];
        assert_eq!(datum.name, "Q1DatumShape");
        assert_eq!(datum.target_class, "Q1Datum");
        assert_eq!(datum.properties.len(), 7);

        let value_prop = &datum.properties[0];
        assert_eq!(value_prop.name, "value");
        assert_eq!(value_prop.datatype, Some(XsdType::UnsignedShort));
        assert_eq!(value_prop.min_count, Some(1));
        assert_eq!(value_prop.max_count, Some(1));
        assert_eq!(value_prop.min_inclusive, Some(0));
        assert_eq!(value_prop.max_inclusive, Some(65535));

        let curvature = &datum.properties[4];
        assert_eq!(curvature.name, "curvature");
        assert_eq!(curvature.min_inclusive, Some(1));
        assert_eq!(curvature.max_inclusive, Some(17));

        let cert = &shapes[1];
        assert_eq!(cert.name, "Q1ScalingCertificateShape");
        assert_eq!(cert.target_class, "Q1ScalingCertificate");
        assert_eq!(cert.properties.len(), 3);
    }

    #[test]
    fn parse_derivation_shapes() {
        let input = include_str!("../../../descriptors/shacl/derivation-shapes.ttl");
        let shapes = parse_shacl_file(input).unwrap();
        assert_eq!(shapes.len(), 3);

        let step = &shapes[0];
        assert_eq!(step.name, "DerivationStepShape");
        assert_eq!(step.properties.len(), 5);

        // Check sh:in list on kind property
        let kind_prop = &step.properties[2];
        assert_eq!(kind_prop.name, "kind");
        let in_vals = kind_prop.in_values.as_ref().unwrap();
        assert_eq!(in_vals.len(), 10);
        assert_eq!(in_vals[0], "type_declaration");
        assert_eq!(in_vals[9], "compute");

        let chain = &shapes[1];
        assert_eq!(chain.name, "DerivationChainShape");
        assert_eq!(chain.properties.len(), 4);

        let result = &shapes[2];
        assert_eq!(result.name, "FactorizationResultShape");
        assert_eq!(result.properties.len(), 5);
        assert_eq!(result.properties[4].name, "verified");
        assert_eq!(result.properties[4].datatype, Some(XsdType::Boolean));
    }

    #[test]
    fn parse_observable_shapes() {
        let input = include_str!("../../../descriptors/shacl/observable-shapes.ttl");
        let shapes = parse_shacl_file(input).unwrap();
        assert_eq!(shapes.len(), 4);

        assert_eq!(shapes[0].name, "WindingNumberShape");
        assert_eq!(shapes[0].properties.len(), 1);
        assert_eq!(shapes[0].properties[0].datatype, Some(XsdType::Integer));

        assert_eq!(shapes[1].name, "TotalVariationShape");
        assert_eq!(
            shapes[1].properties[0].datatype,
            Some(XsdType::NonNegativeInteger)
        );

        assert_eq!(shapes[2].name, "CascadeSpectrumShape");
        assert_eq!(shapes[2].properties[0].datatype, None); // untyped

        assert_eq!(shapes[3].name, "MonodromySignatureShape");
        assert_eq!(shapes[3].properties.len(), 3);
    }

    #[test]
    fn parse_mining_shapes() {
        let input = include_str!("../../../descriptors/shacl/mining-shapes.ttl");
        let shapes = parse_shacl_file(input).unwrap();
        assert_eq!(shapes.len(), 3);

        // BlockHeaderShape
        let header = &shapes[0];
        assert_eq!(header.name, "BlockHeaderShape");
        assert_eq!(header.target_class, "BlockHeader");
        assert_eq!(header.properties.len(), 6);
        assert_eq!(header.properties[0].name, "version");
        assert_eq!(header.properties[0].datatype, Some(XsdType::UnsignedInt));
        // prevBlockHash: hexBinary with length 64
        assert_eq!(header.properties[1].name, "prevBlockHash");
        assert_eq!(header.properties[1].datatype, Some(XsdType::HexBinary));
        assert_eq!(header.properties[1].min_length, Some(64));
        assert_eq!(header.properties[1].max_length, Some(64));

        // MiningConfigShape
        let config = &shapes[1];
        assert_eq!(config.name, "MiningConfigShape");
        assert_eq!(config.properties.len(), 4);
        assert_eq!(config.properties[0].name, "requiredZeroBytes");
        assert_eq!(config.properties[0].datatype, Some(XsdType::UnsignedByte));
        assert_eq!(config.properties[0].min_inclusive, Some(1));
        assert_eq!(config.properties[0].max_inclusive, Some(32));

        // MiningResultShape
        let result = &shapes[2];
        assert_eq!(result.name, "MiningResultShape");
        assert_eq!(result.properties.len(), 3);
        assert_eq!(result.properties[2].name, "found");
        assert_eq!(result.properties[2].datatype, Some(XsdType::Boolean));
    }

    #[test]
    fn parse_xsd_unsigned_int() {
        assert_eq!(
            parse_xsd_type("xsd:unsignedInt"),
            Some(XsdType::UnsignedInt)
        );
    }

    #[test]
    fn parse_xsd_hex_binary() {
        assert_eq!(parse_xsd_type("xsd:hexBinary"), Some(XsdType::HexBinary));
    }
}
