//! Hologram Schema Server
//!
//! An API-driven schema viewer for JSON-LD files, similar to schema.org.
//! Provides REST API and HTML views for browsing, querying, and mutating
//! UOR/Hologram schemas.
//!
//! # Features
//!
//! - Browse JSON-LD schemas (UOR, Taxon Catalog, Hologram Ontology)
//! - View taxons with Braille mappings
//! - Query mathematical constants and axioms
//! - Mutate constant values with cascade preview
//! - Content negotiation (JSON/HTML)
//!
//! # Usage
//!
//! ```no_run
//! use hologram_schema_server::{Config, run_server};
//!
//! #[tokio::main]
//! async fn main() {
//!     let config = Config::from_env();
//!     run_server(config).await.unwrap();
//! }
//! ```

pub mod api;
pub mod config;
pub mod error;
pub mod generated;
pub mod html;
pub mod schema;
pub mod state;

pub use config::Config;
pub use error::{Result, ServerError};
pub use state::AppState;

use crate::api::build_router;
use crate::schema::{load_schemas, SchemaStore};
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::net::TcpListener;
use tracing::info;

/// Run the schema server with the given configuration.
pub async fn run_server(config: Config) -> Result<()> {
    // Load schemas
    info!("Loading schemas...");
    let loaded = load_schemas(&config)?;
    info!(
        "Loaded {} taxons, {} constants",
        loaded.taxons.len(),
        loaded.constants.len()
    );

    // Build store and state
    let store = SchemaStore::new(loaded);
    let state = Arc::new(AppState::new(store));

    // Build router
    let app = build_router(state);

    // Start server
    let addr = SocketAddr::from(([0, 0, 0, 0], config.port));
    info!("Starting server on http://{}", addr);

    let listener = TcpListener::bind(addr).await?;
    axum::serve(listener, app)
        .with_graceful_shutdown(shutdown_signal())
        .await
        .map_err(std::io::Error::other)?;

    Ok(())
}

/// Signal handler for graceful shutdown.
async fn shutdown_signal() {
    tokio::signal::ctrl_c()
        .await
        .expect("Failed to install CTRL+C signal handler");
    info!("Shutdown signal received");
}
