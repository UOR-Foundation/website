//! Codec usage examples demonstrating common patterns.
//!
//! Run with: `cargo run -p categorical-codec --example codec_usage`

use categorical_codec::{
    Codec, CodecsBrailleQ0, CodecsBrailleQ1, NumeralsSystemsDecimal, NumeralsSystemsHexadecimal,
};

fn main() {
    println!("=== Codec Usage Examples ===\n");

    // Example 1: Basic decimal encoding
    basic_decimal_encoding();

    // Example 2: Hexadecimal encoding
    hexadecimal_encoding();

    // Example 3: Braille encoding for human-readable output
    braille_encoding();

    // Example 4: Dynamic codec selection
    dynamic_codec_selection();

    // Example 5: Codec metadata inspection
    codec_metadata();
}

/// Basic decimal encoding: convert bytes to base-10 digits.
fn basic_decimal_encoding() {
    println!("1. Decimal Encoding");
    println!("-------------------");

    let codec = NumeralsSystemsDecimal;
    let input = vec![0xDE, 0xAD, 0xBE, 0xEF]; // 0xDEADBEEF = 3735928559

    let encoded = codec.encode(&input).unwrap();
    println!("Input bytes:    {:?}", input);
    println!("Decimal digits: {:?}", encoded);

    // Decode back
    let decoded = codec.decode(&encoded).unwrap();
    assert_eq!(decoded, input);
    println!("Roundtrip OK:   {:?}", decoded);
    println!();
}

/// Hexadecimal encoding: each byte becomes two hex digits.
fn hexadecimal_encoding() {
    println!("2. Hexadecimal Encoding");
    println!("-----------------------");

    let codec = NumeralsSystemsHexadecimal;
    let input = vec![0xCA, 0xFE];

    let encoded = codec.encode(&input).unwrap();
    println!("Input bytes: {:?}", input);
    println!("Hex digits:  {:?}", encoded);

    // Decode back
    let decoded = codec.decode(&encoded).unwrap();
    assert_eq!(decoded, input);
    println!("Roundtrip OK: {:?}", decoded);
    println!();
}

/// Braille encoding: bijective mapping to Unicode Braille characters.
fn braille_encoding() {
    println!("3. Braille Encoding");
    println!("-------------------");

    // Q0: 1 byte = 1 glyph
    let q0 = CodecsBrailleQ0;

    println!("Q0 (single byte):");
    for byte in [0u8, 42, 128, 255] {
        let encoded = q0.encode(&[byte]).unwrap();
        let glyph = std::str::from_utf8(&encoded).unwrap();
        println!("  Byte {:3} → '{}'", byte, glyph);
    }
    println!();

    // Q1: 2 bytes = 2 glyphs (16-bit values)
    let q1 = CodecsBrailleQ1;

    println!("Q1 (two bytes):");
    let values: Vec<[u8; 2]> = vec![[0x00, 0x00], [0x12, 0x34], [0xFF, 0xFF]];

    for bytes in values {
        let encoded = q1.encode(&bytes).unwrap();
        let glyphs = std::str::from_utf8(&encoded).unwrap();
        let decoded = q1.decode(&encoded).unwrap();
        println!(
            "  {:02X}{:02X} → '{}' → {:02X}{:02X}",
            bytes[0], bytes[1], glyphs, decoded[0], decoded[1]
        );
    }
    println!();
}

/// Dynamic codec selection using trait objects.
fn dynamic_codec_selection() {
    println!("4. Dynamic Codec Selection");
    println!("--------------------------");

    // Store codecs as trait objects for runtime selection
    let codecs: Vec<(&str, Box<dyn Codec>)> = vec![
        ("decimal", Box::new(NumeralsSystemsDecimal)),
        ("hex", Box::new(NumeralsSystemsHexadecimal)),
        ("braille_q1", Box::new(CodecsBrailleQ1)),
    ];

    let input = vec![0x42, 0x00];

    for (name, codec) in &codecs {
        let encoded = codec.encode(&input).unwrap();
        let decoded = codec.decode(&encoded).unwrap();
        println!("  {}: {:?} → {:?} → {:?}", name, input, encoded, decoded);
    }
    println!();
}

/// Inspect codec metadata via the Codec trait.
fn codec_metadata() {
    println!("5. Codec Metadata");
    println!("-----------------");

    let codecs: Vec<Box<dyn Codec>> = vec![
        Box::new(NumeralsSystemsDecimal),
        Box::new(NumeralsSystemsHexadecimal),
        Box::new(CodecsBrailleQ0),
        Box::new(CodecsBrailleQ1),
    ];

    for codec in &codecs {
        let sf = codec.scale_factor();
        println!("  {} ({})", codec.name(), codec.id());
        println!(
            "    radix: {}, arbitrary: {}, max_bits: {:?}",
            sf.radix, sf.arbitrary, sf.max_precision_bits
        );
    }
}
