/**
 * TrustGraph — Force-directed visualization of your trust network.
 *
 * Uses react-force-graph-2d (d3-force + Canvas) to render an interactive
 * graph of connections between people, agents, experiences, and objects.
 * Styled to match the sanctuary aesthetic with warm golds and linen tones.
 */

import { useRef, useState, useCallback, useEffect, useMemo } from "react";
import ForceGraph2D from "react-force-graph-2d";
import { useTheme } from "@/hooks/use-theme";

/* ── Types ── */

export type NodeType = "person" | "agent" | "experience" | "object" | "self";

export interface GraphNode {
  id: string;
  name: string;
  type: NodeType;
  group?: string;
  trustLevel?: number; // 0–1
  verified?: boolean;
  description?: string;
}

export type EdgeType = "trusts" | "verified" | "interacted" | "witnessed" | "created";

export interface GraphLink {
  source: string;
  target: string;
  type: EdgeType;
  strength?: number; // 0–1
}

export interface TrustGraphData {
  nodes: GraphNode[];
  links: GraphLink[];
}

/* ── Color palette ── */

const NODE_COLORS: Record<NodeType, { light: string; dark: string }> = {
  self:       { light: "hsl(33, 55%, 42%)",  dark: "hsl(35, 55%, 58%)" },
  person:     { light: "hsl(200, 45%, 48%)", dark: "hsl(200, 50%, 60%)" },
  agent:      { light: "hsl(280, 40%, 50%)", dark: "hsl(280, 45%, 62%)" },
  experience: { light: "hsl(150, 40%, 42%)", dark: "hsl(150, 45%, 55%)" },
  object:     { light: "hsl(25, 50%, 50%)",  dark: "hsl(25, 55%, 60%)" },
};

const EDGE_COLORS: Record<EdgeType, { light: string; dark: string }> = {
  trusts:     { light: "hsla(33, 40%, 50%, 0.3)",  dark: "hsla(35, 40%, 50%, 0.25)" },
  verified:   { light: "hsla(150, 40%, 45%, 0.4)", dark: "hsla(150, 40%, 55%, 0.3)" },
  interacted: { light: "hsla(200, 35%, 50%, 0.25)", dark: "hsla(200, 40%, 55%, 0.2)" },
  witnessed:  { light: "hsla(280, 30%, 50%, 0.2)", dark: "hsla(280, 35%, 55%, 0.15)" },
  created:    { light: "hsla(25, 40%, 50%, 0.3)",  dark: "hsla(25, 45%, 55%, 0.25)" },
};

const NODE_TYPE_LABELS: Record<NodeType, string> = {
  self: "You",
  person: "People",
  agent: "Agents",
  experience: "Experiences",
  object: "Objects",
};

const EDGE_TYPE_LABELS: Record<EdgeType, string> = {
  trusts: "Trusts",
  verified: "Verified",
  interacted: "Interacted",
  witnessed: "Witnessed",
  created: "Created",
};

const NODE_TYPE_ICONS: Record<NodeType, string> = {
  self: "◉",
  person: "●",
  agent: "◆",
  experience: "△",
  object: "○",
};

/* ── Component ── */

interface Props {
  data: TrustGraphData;
  width?: number;
  height?: number;
  onNodeClick?: (node: GraphNode) => void;
  onRequestConnect?: () => void;
  activeNodeTypes?: Set<NodeType>;
  activeEdgeTypes?: Set<EdgeType>;
  searchQuery?: string;
}

export default function TrustGraph({
  data,
  width,
  height,
  onNodeClick,
  onRequestConnect,
  activeNodeTypes,
  activeEdgeTypes,
  searchQuery = "",
}: Props) {
  const graphRef = useRef<any>();
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [hoveredNode, setHoveredNode] = useState<GraphNode | null>(null);
  const [dimensions, setDimensions] = useState({ w: width ?? 800, h: height ?? 600 });
  const containerRef = useRef<HTMLDivElement>(null);

  // ── Monad entrance animation state ──
  const monadStartTime = useRef<number>(Date.now());
  const [monadPhase, setMonadPhase] = useState<"dot" | "expand" | "name" | "reveal">("dot");
  const nameCharsRevealed = useRef(0);
  const selfNodeName = useRef("");

  // ── Ambient particles (deterministic, seeded once) ──
  const monadParticles = useRef(
    Array.from({ length: 12 }, (_, i) => ({
      angle: (i / 12) * Math.PI * 2 + (i * 0.618) % 1, // golden-ratio offset
      speed: 0.012 + (i % 3) * 0.005,       // pixels per frame-tick in seconds
      maxDist: 35 + (i % 4) * 12,            // how far they drift
      size: 0.8 + (i % 3) * 0.4,             // dot radius
      phase: (i * 1.3) % (Math.PI * 2),      // stagger the cycle
      lifetime: 6 + (i % 3) * 3,             // seconds per cycle
    }))
  );

  // ── Outer depth ring — slower, fainter, larger orbit ──
  const monadParticlesOuter = useRef(
    Array.from({ length: 8 }, (_, i) => ({
      angle: (i / 8) * Math.PI * 2 + 0.4,
      maxDist: 55 + (i % 3) * 18,
      size: 0.5 + (i % 2) * 0.3,
      phase: (i * 2.1) % (Math.PI * 2),
      lifetime: 10 + (i % 3) * 4,
    }))
  );

  // ── Starlight ring — ultra-faint, maximum distance, barely shimmering ──
  const monadParticlesStarlight = useRef(
    Array.from({ length: 14 }, (_, i) => ({
      angle: (i / 14) * Math.PI * 2 + 1.2,
      maxDist: 80 + (i % 4) * 22,
      size: 0.3 + (i % 3) * 0.15,
      phase: (i * 2.7) % (Math.PI * 2),
      lifetime: 14 + (i % 4) * 5,
      twinkleSpeed: 2.5 + (i % 3) * 1.2,
    }))
  );

  useEffect(() => {
    monadStartTime.current = Date.now();
    setMonadPhase("dot");
    nameCharsRevealed.current = 0;

    // dot → expand after 1.2s
    const t1 = setTimeout(() => setMonadPhase("expand"), 1200);
    // expand → name after 2.8s
    const t2 = setTimeout(() => setMonadPhase("name"), 2800);
    // name → reveal after name is typed (approx 4.5s)
    const t3 = setTimeout(() => setMonadPhase("reveal"), 5500);

    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  // Continuously re-render for heartbeat animation (never stops)
  useEffect(() => {
    let raf: number;
    const tick = () => {
      // Light reheat keeps canvas painting without disturbing settled positions
      const fg = graphRef.current;
      if (fg) {
        fg.d3ReheatSimulation();
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);
  // Responsive sizing
  useEffect(() => {
    if (width && height) {
      setDimensions({ w: width, h: height });
      return;
    }
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      const { width: w, height: h } = entries[0].contentRect;
      setDimensions({ w: Math.floor(w), h: Math.floor(Math.max(h, 500)) });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [width, height]);

  // Filter data
  const filteredData = useMemo(() => {
    const query = searchQuery.toLowerCase().trim();
    let nodes = data.nodes;
    let links = data.links;

    if (activeNodeTypes && activeNodeTypes.size > 0) {
      nodes = nodes.filter((n) => activeNodeTypes.has(n.type));
    }
    if (activeEdgeTypes && activeEdgeTypes.size > 0) {
      links = links.filter((l) => activeEdgeTypes.has(l.type));
    }
    if (query) {
      const matchingIds = new Set(
        nodes.filter((n) => n.name.toLowerCase().includes(query) || n.id.toLowerCase().includes(query)).map((n) => n.id)
      );
      // Keep matched nodes + their direct neighbors
      const neighborIds = new Set(matchingIds);
      links.forEach((l) => {
        const src = typeof l.source === "object" ? (l.source as any).id : l.source;
        const tgt = typeof l.target === "object" ? (l.target as any).id : l.target;
        if (matchingIds.has(src)) neighborIds.add(tgt);
        if (matchingIds.has(tgt)) neighborIds.add(src);
      });
      nodes = nodes.filter((n) => neighborIds.has(n.id));
    }

    const nodeIds = new Set(nodes.map((n) => n.id));
    links = links.filter((l) => {
      const src = typeof l.source === "object" ? (l.source as any).id : l.source;
      const tgt = typeof l.target === "object" ? (l.target as any).id : l.target;
      return nodeIds.has(src) && nodeIds.has(tgt);
    });

    return { nodes, links };
  }, [data, activeNodeTypes, activeEdgeTypes, searchQuery]);

  // Zoom to fit on mount — cap max zoom so single nodes don't fill the screen
  useEffect(() => {
    const timer = setTimeout(() => {
      const fg = graphRef.current;
      if (!fg) return;
      fg.zoomToFit(600, 120);
      setTimeout(() => {
        const currentZoom = fg.zoom();
        if (currentZoom > 3) {
          fg.zoom(2.5, 400);
        }
      }, 650);
    }, 800);
    return () => clearTimeout(timer);
  }, [filteredData]);

  const nodeColor = useCallback(
    (node: any) => {
      const n = node as GraphNode;
      const colors = NODE_COLORS[n.type] || NODE_COLORS.object;
      const base = isDark ? colors.dark : colors.light;
      
      if (searchQuery && !n.name.toLowerCase().includes(searchQuery.toLowerCase())) {
        return isDark ? "hsla(30, 10%, 30%, 0.4)" : "hsla(30, 10%, 70%, 0.4)";
      }
      return base;
    },
    [isDark, searchQuery]
  );

  const nodeRadius = useCallback((node: any) => {
    const n = node as GraphNode;
    if (n.type === "self") return 12;
    const trust = n.trustLevel ?? 0.5;
    return 4 + trust * 5;
  }, []);

  const paintNode = useCallback(
    (node: any, ctx: CanvasRenderingContext2D, globalScale: number) => {
      const n = node as GraphNode;
      const x = node.x as number;
      const y = node.y as number;
      if (!isFinite(x) || !isFinite(y)) return;
      const r = nodeRadius(n);
      const color = nodeColor(n);

      if (n.type === "self") {
        selfNodeName.current = n.name;
        const elapsed = (Date.now() - monadStartTime.current) / 1000;

        // ── Phase 1: Just the dot ──
        const dotR = 2.5;

        if (monadPhase === "dot") {
          // Breathing dot
          const breathe = 1 + Math.sin(elapsed * 3) * 0.15;
          ctx.beginPath();
          ctx.arc(x, y, dotR * breathe, 0, 2 * Math.PI);
          ctx.fillStyle = isDark ? "hsl(35, 45%, 62%)" : "hsl(33, 40%, 38%)";
          ctx.fill();
          return;
        }

        // ── Phase 2+: Circle expands from dot ──
        const expandProgress = Math.min((elapsed - 1.2) / 1.2, 1);
        const easedExpand = 1 - Math.pow(1 - expandProgress, 3); // easeOutCubic
        const currentR = r * easedExpand;

        // Heartbeat pulsing glow
        const heartbeat = Math.sin(elapsed * 1.8) * 0.5 + 0.5; // slow peaceful pulse
        const glowIntensity = 0.04 + heartbeat * 0.06;

        // Outer ambient glow (breathing)
        const outerGlow = ctx.createRadialGradient(x, y, currentR * 0.5, x, y, currentR * 3);
        outerGlow.addColorStop(0, isDark ? `hsla(35, 50%, 55%, ${glowIntensity})` : `hsla(33, 50%, 42%, ${glowIntensity * 0.8})`);
        outerGlow.addColorStop(1, "transparent");
        ctx.beginPath();
        ctx.arc(x, y, currentR * 3, 0, 2 * Math.PI);
        ctx.fillStyle = outerGlow;
        ctx.fill();

        // Inner warm light from center (heartbeat)
        const innerGlow = ctx.createRadialGradient(x, y, 0, x, y, currentR * 0.8);
        innerGlow.addColorStop(0, isDark ? `hsla(35, 55%, 60%, ${0.12 + heartbeat * 0.08})` : `hsla(33, 45%, 50%, ${0.08 + heartbeat * 0.06})`);
        innerGlow.addColorStop(1, "transparent");
        ctx.beginPath();
        ctx.arc(x, y, currentR * 0.8, 0, 2 * Math.PI);
        ctx.fillStyle = innerGlow;
        ctx.fill();

        // Main circle ring
        if (currentR > 1) {
          ctx.beginPath();
          ctx.arc(x, y, currentR, 0, 2 * Math.PI);
          ctx.strokeStyle = isDark
            ? `hsla(35, 40%, 65%, ${0.4 + heartbeat * 0.2})`
            : `hsla(33, 35%, 40%, ${0.35 + heartbeat * 0.15})`;
          ctx.lineWidth = 1.2;
          ctx.stroke();
        }

        // Center dot (always present — the origin)
        const dotBreathe = 1 + Math.sin(elapsed * 1.8) * 0.1;
        ctx.beginPath();
        ctx.arc(x, y, dotR * dotBreathe, 0, 2 * Math.PI);
        ctx.fillStyle = isDark ? "hsl(35, 45%, 62%)" : "hsl(33, 40%, 38%)";
        ctx.fill();

        // ── Ambient drifting particles ──
        if (currentR > 2) {
          for (const p of monadParticles.current) {
            // Cycle position: 0→1→0 over lifetime
            const t = ((elapsed + p.phase) % p.lifetime) / p.lifetime;
            const dist = currentR * 0.6 + t * p.maxDist;
            // Fade: appear, drift, fade out
            const fade = t < 0.15 ? t / 0.15 : t > 0.7 ? (1 - t) / 0.3 : 1;
            const alpha = fade * (0.15 + heartbeat * 0.08);
            const px = x + Math.cos(p.angle + elapsed * 0.08) * dist;
            const py = y + Math.sin(p.angle + elapsed * 0.08) * dist;

            ctx.beginPath();
            ctx.arc(px, py, p.size, 0, 2 * Math.PI);
            ctx.fillStyle = isDark
              ? `hsla(35, 50%, 65%, ${alpha})`
              : `hsla(33, 45%, 45%, ${alpha * 0.7})`;
            ctx.fill();
          }

          // ── Outer depth ring — slower, fainter ──
          for (const p of monadParticlesOuter.current) {
            const t = ((elapsed + p.phase) % p.lifetime) / p.lifetime;
            const dist = currentR * 1.2 + t * p.maxDist;
            const fade = t < 0.2 ? t / 0.2 : t > 0.65 ? (1 - t) / 0.35 : 1;
            const alpha = fade * (0.07 + heartbeat * 0.04);
            const px = x + Math.cos(p.angle + elapsed * 0.03) * dist;
            const py = y + Math.sin(p.angle + elapsed * 0.03) * dist;

            ctx.beginPath();
            ctx.arc(px, py, p.size, 0, 2 * Math.PI);
            ctx.fillStyle = isDark
              ? `hsla(35, 40%, 60%, ${alpha})`
              : `hsla(33, 35%, 50%, ${alpha * 0.6})`;
            ctx.fill();
          }

          // ── Starlight ring — barely-there shimmer at max distance ──
          for (const p of monadParticlesStarlight.current) {
            const t = ((elapsed + p.phase) % p.lifetime) / p.lifetime;
            const dist = currentR * 1.8 + t * p.maxDist;
            const fade = t < 0.25 ? t / 0.25 : t > 0.6 ? (1 - t) / 0.4 : 1;
            const twinkle = 0.5 + Math.sin(elapsed * p.twinkleSpeed) * 0.5;
            const alpha = fade * twinkle * (0.035 + heartbeat * 0.02);
            const px = x + Math.cos(p.angle + elapsed * 0.015) * dist;
            const py = y + Math.sin(p.angle + elapsed * 0.015) * dist;

            ctx.beginPath();
            ctx.arc(px, py, p.size, 0, 2 * Math.PI);
            ctx.fillStyle = isDark
              ? `hsla(35, 30%, 70%, ${alpha})`
              : `hsla(33, 25%, 55%, ${alpha * 0.5})`;
            ctx.fill();
          }
        }

        // ── Phase 3+: Name types in letter by letter ──
        if (monadPhase === "name" || monadPhase === "reveal") {
          const nameElapsed = Math.max(elapsed - 2.8, 0);
          const charsToShow = Math.min(Math.floor(nameElapsed / 0.12), n.name.length);
          nameCharsRevealed.current = charsToShow;
          const visibleName = n.name.substring(0, charsToShow);

          if (visibleName.length > 0) {
            const fontSize = Math.max(18 / globalScale, 6);
            ctx.font = `500 ${fontSize}px 'Playfair Display', serif`;
            ctx.textAlign = "center";
            ctx.textBaseline = "top";
            ctx.fillStyle = isDark ? `hsla(35, 25%, 80%, ${Math.min(nameElapsed * 2, 1)})` : `hsla(28, 20%, 30%, ${Math.min(nameElapsed * 2, 1)})`;
            ctx.fillText(visibleName, x, y + currentR + 12);
          }
        }

        return;
      }

      // ── Regular nodes ──
      if (n.verified) {
        ctx.beginPath();
        ctx.arc(x, y, r + 2, 0, 2 * Math.PI);
        ctx.strokeStyle = isDark ? "hsl(150, 45%, 55%)" : "hsl(150, 40%, 42%)";
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }

      ctx.beginPath();
      ctx.arc(x, y, r, 0, 2 * Math.PI);
      ctx.fillStyle = color;
      ctx.fill();

      const fontSize = Math.max(14 / globalScale, 4);
      if (globalScale > 0.4) {
        ctx.font = `400 ${fontSize}px 'DM Sans', sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "top";
        ctx.fillStyle = isDark ? "hsl(35, 22%, 82%)" : "hsl(28, 20%, 25%)";
        ctx.fillText(n.name, x, y + r + 4);
      }
    },
    [isDark, nodeColor, nodeRadius, monadPhase]
  );

  const linkColor = useCallback(
    (link: any) => {
      const l = link as GraphLink;
      const colors = EDGE_COLORS[l.type] || EDGE_COLORS.interacted;
      return isDark ? colors.dark : colors.light;
    },
    [isDark]
  );

  const linkWidth = useCallback((link: any) => {
    const l = link as GraphLink;
    return 0.5 + (l.strength ?? 0.5) * 2;
  }, []);

  const handleNodeClick = useCallback(
    (node: any) => {
      const n = node as GraphNode;
      onNodeClick?.(n);
      // Zoom to clicked node
      graphRef.current?.centerAt(node.x, node.y, 500);
      graphRef.current?.zoom(2.5, 500);
    },
    [onNodeClick]
  );

  const bgColor = isDark ? "hsl(28, 12%, 9%)" : "hsl(35, 25%, 95%)";

  return (
    <div ref={containerRef} className="w-full h-full relative">
      <ForceGraph2D
        ref={graphRef}
        graphData={filteredData}
        width={dimensions.w}
        height={dimensions.h}
        backgroundColor={bgColor}
        nodeCanvasObject={paintNode}
        nodePointerAreaPaint={(node: any, color, ctx) => {
          const r = nodeRadius(node);
          ctx.beginPath();
          ctx.arc(node.x, node.y, r + 4, 0, 2 * Math.PI);
          ctx.fillStyle = color;
          ctx.fill();
        }}
        linkColor={linkColor}
        linkWidth={linkWidth}
        linkCurvature={0.15}
        linkDirectionalParticles={(link: any) => (link as GraphLink).type === "verified" ? 2 : 0}
        linkDirectionalParticleWidth={2}
        linkDirectionalParticleSpeed={0.005}
        onNodeClick={handleNodeClick}
        onNodeHover={(node: any) => setHoveredNode(node as GraphNode | null)}
        cooldownTicks={80}
        d3AlphaDecay={0.02}
        d3VelocityDecay={0.3}
        enableZoomInteraction={true}
        enablePanInteraction={true}
        enableNodeDrag={true}
        warmupTicks={30}
      />

      {/* Empty-state welcome message — sequenced with monad animation */}
      {filteredData.links.length === 0 && filteredData.nodes.length <= 1 && (
        <div className="absolute inset-0 flex items-end justify-center pointer-events-none pb-[14%]">
          <div className="text-center max-w-lg mx-auto">
            <p
              className="text-2xl sm:text-3xl font-display text-foreground/60 mb-3 transition-all duration-1000"
              style={{ opacity: monadPhase === "reveal" ? 1 : 0, transform: monadPhase === "reveal" ? "translateY(0)" : "translateY(12px)" }}
            >
              This is you.
            </p>
            <p
              className="text-lg sm:text-xl text-foreground/35 leading-relaxed mb-8 transition-all duration-1000 delay-500"
              style={{ opacity: monadPhase === "reveal" ? 1 : 0, transform: monadPhase === "reveal" ? "translateY(0)" : "translateY(12px)" }}
            >
              Your trust network starts here. Add the people, agents, and experiences that matter to you — and watch your world take shape.
            </p>
            {onRequestConnect && (
              <div
                className="transition-all duration-1000 delay-1000"
                style={{ opacity: monadPhase === "reveal" ? 1 : 0, transform: monadPhase === "reveal" ? "translateY(0)" : "translateY(12px)" }}
              >
                <button
                  onClick={onRequestConnect}
                  className="pointer-events-auto inline-flex items-center gap-2 px-8 py-3.5 rounded-full border border-primary/20 text-lg font-medium text-primary hover:bg-primary/5 hover:border-primary/35 transition-all duration-500"
                >
                  Add your first connection →
                </button>
              </div>
            )}
          </div>
        </div>
      )}
      {hoveredNode && (
        <div className="absolute top-4 left-4 bg-card/90 backdrop-blur-sm border border-border/30 rounded-xl px-5 py-4 max-w-xs pointer-events-none animate-fade-in">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-lg">{NODE_TYPE_ICONS[hoveredNode.type]}</span>
            <span className="text-base font-display font-medium text-foreground">{hoveredNode.name}</span>
          </div>
          <p className="text-sm text-muted-foreground capitalize">{NODE_TYPE_LABELS[hoveredNode.type]}</p>
          {hoveredNode.description && (
            <p className="text-sm text-muted-foreground/70 mt-1">{hoveredNode.description}</p>
          )}
          {hoveredNode.trustLevel !== undefined && (
            <div className="mt-2 flex items-center gap-2">
              <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full rounded-full bg-primary transition-all"
                  style={{ width: `${hoveredNode.trustLevel * 100}%` }}
                />
              </div>
              <span className="text-xs text-muted-foreground">{Math.round(hoveredNode.trustLevel * 100)}%</span>
            </div>
          )}
          {hoveredNode.verified && (
            <p className="text-xs text-green-500 mt-1">✓ Verified connection</p>
          )}
        </div>
      )}
    </div>
  );
}

export { NODE_TYPE_LABELS, EDGE_TYPE_LABELS, NODE_TYPE_ICONS, NODE_COLORS, EDGE_COLORS };
