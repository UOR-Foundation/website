//! Streaming codec support for large data handling.
//!
//! This module provides streaming encode/decode capabilities that process
//! data in chunks, enabling efficient handling of large inputs without
//! loading everything into memory.

use crate::error::CodecError;
use std::io::{Read, Write};

/// State for incremental encoding operations.
///
/// Encoders accumulate input and produce output in chunks. Call `finish()`
/// to complete encoding and flush any remaining data.
pub trait ChunkEncoder: Send {
    /// Feed input bytes to the encoder.
    ///
    /// Returns encoded bytes that are ready. The encoder may buffer
    /// data internally if more input is needed to produce output.
    fn feed(&mut self, input: &[u8]) -> Result<Vec<u8>, CodecError>;

    /// Finish encoding and return any remaining output.
    ///
    /// After calling `finish()`, the encoder is consumed and cannot be reused.
    fn finish(self: Box<Self>) -> Result<Vec<u8>, CodecError>;

    /// Returns the recommended chunk size for optimal throughput.
    fn recommended_chunk_size(&self) -> usize {
        4096
    }
}

/// State for incremental decoding operations.
///
/// Decoders accumulate encoded input and produce decoded output in chunks.
/// Call `finish()` to complete decoding and validate any remaining data.
pub trait ChunkDecoder: Send {
    /// Feed encoded bytes to the decoder.
    ///
    /// Returns decoded bytes that are ready. The decoder may buffer
    /// data internally if more input is needed to produce output.
    fn feed(&mut self, input: &[u8]) -> Result<Vec<u8>, CodecError>;

    /// Finish decoding and return any remaining output.
    ///
    /// Returns an error if the input was incomplete or malformed.
    fn finish(self: Box<Self>) -> Result<Vec<u8>, CodecError>;

    /// Returns the recommended chunk size for optimal throughput.
    fn recommended_chunk_size(&self) -> usize {
        4096
    }
}

/// Extension trait for codecs that support streaming operations.
///
/// This trait provides default implementations that fall back to batch
/// processing, but codecs can override for more efficient streaming.
pub trait StreamingCodec: super::Codec {
    /// Create a new streaming encoder.
    ///
    /// The returned encoder accumulates input via `feed()` and produces
    /// encoded chunks. Call `finish()` to complete encoding.
    fn encoder(&self) -> Box<dyn ChunkEncoder>;

    /// Create a new streaming decoder.
    ///
    /// The returned decoder accumulates encoded input via `feed()` and
    /// produces decoded chunks. Call `finish()` to complete decoding.
    fn decoder(&self) -> Box<dyn ChunkDecoder>;

    /// Encode from a reader to a writer, streaming in chunks.
    ///
    /// This is a convenience method that reads chunks from `input`,
    /// encodes them, and writes to `output`.
    fn encode_stream<R: Read, W: Write>(
        &self,
        mut input: R,
        mut output: W,
    ) -> Result<u64, CodecError>
    where
        Self: Sized,
    {
        let mut encoder = self.encoder();
        let chunk_size = encoder.recommended_chunk_size();
        let mut buffer = vec![0u8; chunk_size];
        let mut total_written = 0u64;

        loop {
            let bytes_read = input
                .read(&mut buffer)
                .map_err(|e| CodecError::encode(format!("read error: {}", e)))?;

            if bytes_read == 0 {
                break;
            }

            let encoded = encoder.feed(&buffer[..bytes_read])?;
            if !encoded.is_empty() {
                output
                    .write_all(&encoded)
                    .map_err(|e| CodecError::encode(format!("write error: {}", e)))?;
                total_written += encoded.len() as u64;
            }
        }

        let final_chunk = encoder.finish()?;
        if !final_chunk.is_empty() {
            output
                .write_all(&final_chunk)
                .map_err(|e| CodecError::encode(format!("write error: {}", e)))?;
            total_written += final_chunk.len() as u64;
        }

        Ok(total_written)
    }

    /// Decode from a reader to a writer, streaming in chunks.
    ///
    /// This is a convenience method that reads encoded chunks from `input`,
    /// decodes them, and writes to `output`.
    fn decode_stream<R: Read, W: Write>(
        &self,
        mut input: R,
        mut output: W,
    ) -> Result<u64, CodecError>
    where
        Self: Sized,
    {
        let mut decoder = self.decoder();
        let chunk_size = decoder.recommended_chunk_size();
        let mut buffer = vec![0u8; chunk_size];
        let mut total_written = 0u64;

        loop {
            let bytes_read = input
                .read(&mut buffer)
                .map_err(|e| CodecError::decode(format!("read error: {}", e)))?;

            if bytes_read == 0 {
                break;
            }

            let decoded = decoder.feed(&buffer[..bytes_read])?;
            if !decoded.is_empty() {
                output
                    .write_all(&decoded)
                    .map_err(|e| CodecError::decode(format!("write error: {}", e)))?;
                total_written += decoded.len() as u64;
            }
        }

        let final_chunk = decoder.finish()?;
        if !final_chunk.is_empty() {
            output
                .write_all(&final_chunk)
                .map_err(|e| CodecError::decode(format!("write error: {}", e)))?;
            total_written += final_chunk.len() as u64;
        }

        Ok(total_written)
    }
}

// ============================================================================
// Default implementations for batch-mode fallback
// ============================================================================

/// A batch encoder that buffers all input and encodes on finish.
///
/// This is the fallback for codecs that don't have native streaming support.
pub struct BatchEncoder<F>
where
    F: Fn(&[u8]) -> Result<Vec<u8>, CodecError> + Send,
{
    buffer: Vec<u8>,
    encode_fn: F,
}

impl<F> BatchEncoder<F>
where
    F: Fn(&[u8]) -> Result<Vec<u8>, CodecError> + Send,
{
    /// Create a new batch encoder with the given encode function.
    pub fn new(encode_fn: F) -> Self {
        Self {
            buffer: Vec::new(),
            encode_fn,
        }
    }
}

impl<F> ChunkEncoder for BatchEncoder<F>
where
    F: Fn(&[u8]) -> Result<Vec<u8>, CodecError> + Send,
{
    fn feed(&mut self, input: &[u8]) -> Result<Vec<u8>, CodecError> {
        self.buffer.extend_from_slice(input);
        Ok(Vec::new()) // Batch mode: no output until finish
    }

    fn finish(self: Box<Self>) -> Result<Vec<u8>, CodecError> {
        (self.encode_fn)(&self.buffer)
    }
}

/// A batch decoder that buffers all input and decodes on finish.
///
/// This is the fallback for codecs that don't have native streaming support.
pub struct BatchDecoder<F>
where
    F: Fn(&[u8]) -> Result<Vec<u8>, CodecError> + Send,
{
    buffer: Vec<u8>,
    decode_fn: F,
}

impl<F> BatchDecoder<F>
where
    F: Fn(&[u8]) -> Result<Vec<u8>, CodecError> + Send,
{
    /// Create a new batch decoder with the given decode function.
    pub fn new(decode_fn: F) -> Self {
        Self {
            buffer: Vec::new(),
            decode_fn,
        }
    }
}

impl<F> ChunkDecoder for BatchDecoder<F>
where
    F: Fn(&[u8]) -> Result<Vec<u8>, CodecError> + Send,
{
    fn feed(&mut self, input: &[u8]) -> Result<Vec<u8>, CodecError> {
        self.buffer.extend_from_slice(input);
        Ok(Vec::new()) // Batch mode: no output until finish
    }

    fn finish(self: Box<Self>) -> Result<Vec<u8>, CodecError> {
        (self.decode_fn)(&self.buffer)
    }
}

// ============================================================================
// Braille streaming encoder/decoder (true streaming - bijective byte mapping)
// ============================================================================

/// Streaming encoder for Braille codecs.
///
/// Braille encoding is bijective (1 byte = 1 glyph), so it can stream
/// byte-by-byte without buffering.
pub struct BrailleStreamEncoder;

impl ChunkEncoder for BrailleStreamEncoder {
    fn feed(&mut self, input: &[u8]) -> Result<Vec<u8>, CodecError> {
        let mut output = Vec::with_capacity(input.len() * 3);
        let mut buf = [0u8; 4];

        for &byte_val in input {
            let codepoint = 0x2800 + u32::from(byte_val);
            let ch = char::from_u32(codepoint).unwrap();
            let encoded = ch.encode_utf8(&mut buf);
            output.extend_from_slice(encoded.as_bytes());
        }

        Ok(output)
    }

    fn finish(self: Box<Self>) -> Result<Vec<u8>, CodecError> {
        Ok(Vec::new()) // No buffered state
    }

    fn recommended_chunk_size(&self) -> usize {
        4096 // Process 4KB at a time
    }
}

/// Streaming decoder for Braille codecs.
///
/// Handles UTF-8 byte boundaries by buffering incomplete sequences.
pub struct BrailleStreamDecoder {
    /// Buffer for incomplete UTF-8 sequences
    pending: Vec<u8>,
}

impl BrailleStreamDecoder {
    /// Create a new Braille stream decoder.
    pub fn new() -> Self {
        Self {
            pending: Vec::with_capacity(4),
        }
    }
}

impl Default for BrailleStreamDecoder {
    fn default() -> Self {
        Self::new()
    }
}

impl ChunkDecoder for BrailleStreamDecoder {
    fn feed(&mut self, input: &[u8]) -> Result<Vec<u8>, CodecError> {
        // Combine pending bytes with new input
        let mut data = std::mem::take(&mut self.pending);
        data.extend_from_slice(input);

        let mut output = Vec::with_capacity(data.len() / 3);
        let mut pos = 0;

        while pos < data.len() {
            // Try to parse a UTF-8 character
            match std::str::from_utf8(&data[pos..]) {
                Ok(s) => {
                    // All remaining data is valid UTF-8
                    for ch in s.chars() {
                        let codepoint = ch as u32;
                        if !(0x2800..=0x28FF).contains(&codepoint) {
                            return Err(CodecError::invalid_input(
                                "codepoint not in Braille range",
                            ));
                        }
                        output.push((codepoint - 0x2800) as u8);
                    }
                    pos = data.len();
                }
                Err(e) => {
                    let valid_up_to = e.valid_up_to();
                    if valid_up_to > 0 {
                        // Process valid portion
                        let valid_str = std::str::from_utf8(&data[pos..pos + valid_up_to]).unwrap();
                        for ch in valid_str.chars() {
                            let codepoint = ch as u32;
                            if !(0x2800..=0x28FF).contains(&codepoint) {
                                return Err(CodecError::invalid_input(
                                    "codepoint not in Braille range",
                                ));
                            }
                            output.push((codepoint - 0x2800) as u8);
                        }
                        pos += valid_up_to;
                    }

                    // Check if it's an incomplete sequence at the end
                    if e.error_len().is_some() {
                        // Invalid sequence - not just incomplete
                        return Err(CodecError::invalid_input("invalid UTF-8 sequence"));
                    }
                    // Incomplete sequence - save for next feed
                    self.pending = data[pos..].to_vec();
                    break;
                }
            }
        }

        Ok(output)
    }

    fn finish(self: Box<Self>) -> Result<Vec<u8>, CodecError> {
        if self.pending.is_empty() {
            Ok(Vec::new())
        } else {
            Err(CodecError::invalid_input(
                "incomplete UTF-8 sequence at end of input",
            ))
        }
    }

    fn recommended_chunk_size(&self) -> usize {
        4096
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_braille_stream_encoder() {
        let mut encoder = BrailleStreamEncoder;

        let chunk1 = encoder.feed(&[0, 1, 2]).unwrap();
        let chunk2 = encoder.feed(&[253, 254, 255]).unwrap();
        let final_chunk = Box::new(encoder).finish().unwrap();

        // Verify UTF-8 encoding
        let combined: Vec<u8> = [chunk1, chunk2, final_chunk].concat();
        let s = std::str::from_utf8(&combined).unwrap();
        assert_eq!(s.chars().count(), 6);
    }

    #[test]
    fn test_braille_stream_decoder() {
        let mut decoder = BrailleStreamDecoder::new();

        // Encode some test data
        let test_bytes = vec![0, 1, 17, 255];
        let mut encoded = Vec::new();
        let mut buf = [0u8; 4];
        for &b in &test_bytes {
            let ch = char::from_u32(0x2800 + u32::from(b)).unwrap();
            let s = ch.encode_utf8(&mut buf);
            encoded.extend_from_slice(s.as_bytes());
        }

        // Decode in one chunk
        let decoded = decoder.feed(&encoded).unwrap();
        let final_chunk = Box::new(decoder).finish().unwrap();

        let result: Vec<u8> = [decoded, final_chunk].concat();
        assert_eq!(result, test_bytes);
    }

    #[test]
    fn test_braille_stream_decoder_split_utf8() {
        // Test decoding when UTF-8 sequence is split across chunks
        let mut decoder = BrailleStreamDecoder::new();

        // Braille char is 3 UTF-8 bytes: E2 A0 80 (for byte 0)
        let full_char = [0xE2, 0xA0, 0x80];

        // Feed first 2 bytes
        let chunk1 = decoder.feed(&full_char[0..2]).unwrap();
        assert!(chunk1.is_empty()); // Should buffer incomplete sequence

        // Feed final byte
        let chunk2 = decoder.feed(&full_char[2..3]).unwrap();
        assert_eq!(chunk2, vec![0]); // Now should decode

        let final_chunk = Box::new(decoder).finish().unwrap();
        assert!(final_chunk.is_empty());
    }

    #[test]
    fn test_braille_roundtrip_streaming() {
        // Full roundtrip test
        let original: Vec<u8> = (0..=255).collect();

        let mut encoder = BrailleStreamEncoder;
        let mut encoded = encoder.feed(&original).unwrap();
        encoded.extend(Box::new(encoder).finish().unwrap());

        let mut decoder = BrailleStreamDecoder::new();
        let mut decoded = decoder.feed(&encoded).unwrap();
        decoded.extend(Box::new(decoder).finish().unwrap());

        assert_eq!(decoded, original);
    }

    #[test]
    fn test_batch_encoder_fallback() {
        let encode_fn = |input: &[u8]| -> Result<Vec<u8>, CodecError> {
            // Simple test: double each byte
            Ok(input.iter().flat_map(|&b| [b, b]).collect())
        };

        let mut encoder = BatchEncoder::new(encode_fn);

        // Feed multiple chunks
        let _ = encoder.feed(&[1, 2]).unwrap();
        let _ = encoder.feed(&[3, 4]).unwrap();

        // All output comes on finish
        let output = Box::new(encoder).finish().unwrap();
        assert_eq!(output, vec![1, 1, 2, 2, 3, 3, 4, 4]);
    }
}
