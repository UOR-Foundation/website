
import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { MOCK_GRAPH_DATA } from "./mock-graph-data";
import type { GraphNode, GraphLink, NodeType, EdgeType, TrustGraphData } from "../components/TrustGraph";
import { toast } from "sonner";

export function useTrustGraph() {
  const [data, setData] = useState<TrustGraphData>({ nodes: [], links: [] });
  const [constellation, setConstellation] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);

  // Initialize
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        setUserId(session.user.id);
        fetchGraphData(session.user.id);
      } else {
        // Fallback to mock data for demo/unauthenticated
        setData(MOCK_GRAPH_DATA);
        setLoading(false);
      }
    });
  }, []);

  const fetchGraphData = async (uid: string) => {
    try {
      setLoading(true);
      
      // Fetch nodes
      const { data: nodesData, error: nodesError } = await supabase
        .from("trust_nodes")
        .select("*");
      
      if (nodesError) throw nodesError;

      // If no nodes exist for user, seed with self node
      if (!nodesData || nodesData.length === 0) {
        await seedInitialData(uid);
        return;
      }

      // Fetch edges
      const { data: edgesData, error: edgesError } = await supabase
        .from("trust_edges")
        .select("*");
      
      if (edgesError) throw edgesError;

      // Fetch constellation
      const { data: constellationData, error: constellationError } = await supabase
        .from("trust_constellations")
        .select("node_id");
        
      if (constellationError) throw constellationError;

      // Transform to graph format
      const nodes: GraphNode[] = nodesData.map(n => ({
        id: n.id,
        name: n.name,
        type: n.type as NodeType,
        trustLevel: n.trust_level,
        verified: n.verified,
        description: n.description,
      }));

      const links: GraphLink[] = edgesData.map(e => ({
        source: e.source_node_id,
        target: e.target_node_id,
        type: e.type as EdgeType,
        strength: e.strength,
      }));

      setData({ nodes, links });
      setConstellation(new Set(constellationData.map(c => c.node_id)));
    } catch (error) {
      console.error("Error fetching graph data:", error);
      toast.error("Failed to load trust network");
    } finally {
      setLoading(false);
    }
  };

  const seedInitialData = async (uid: string) => {
    try {
      // Get user profile for name
      const { data: profile } = await supabase
        .from("profiles")
        .select("display_name")
        .eq("user_id", uid)
        .single();
        
      const name = profile?.display_name || "You";

      // Create self node
      const { data: node, error } = await supabase
        .from("trust_nodes")
        .insert({
          user_id: uid,
          name: name,
          type: "self",
          trust_level: 1.0,
          verified: true,
          description: "Your sovereign identity"
        })
        .select()
        .single();

      if (error) throw error;
      if (node) {
        setData({ 
          nodes: [{
            id: node.id,
            name: node.name,
            type: "self",
            trustLevel: 1.0,
            verified: true,
            description: "Your sovereign identity"
          }], 
          links: [] 
        });
      }
    } catch (error) {
      console.error("Error seeding initial data:", error);
    } finally {
      setLoading(false);
    }
  };

  const addNode = useCallback(async (node: Omit<GraphNode, "id">) => {
    if (!userId) return null;
    try {
      const { data: newNode, error } = await supabase
        .from("trust_nodes")
        .insert({
          user_id: userId,
          name: node.name,
          type: node.type,
          description: node.description,
          trust_level: node.trustLevel,
          verified: node.verified
        })
        .select()
        .single();

      if (error) throw error;

      const graphNode: GraphNode = {
        id: newNode.id,
        name: newNode.name,
        type: newNode.type as NodeType,
        trustLevel: newNode.trust_level,
        verified: newNode.verified,
        description: newNode.description
      };

      setData(prev => ({ ...prev, nodes: [...prev.nodes, graphNode] }));
      return graphNode;
    } catch (error) {
      console.error("Error adding node:", error);
      toast.error("Failed to add node");
      return null;
    }
  }, [userId]);

  const addLink = useCallback(async (sourceId: string, targetId: string, type: EdgeType) => {
    if (!userId) return;
    try {
      const { error } = await supabase
        .from("trust_edges")
        .insert({
          user_id: userId,
          source_node_id: sourceId,
          target_node_id: targetId,
          type: type,
          strength: 0.5
        });

      if (error) throw error;

      setData(prev => ({
        ...prev,
        links: [...prev.links, { source: sourceId, target: targetId, type, strength: 0.5 }]
      }));
      toast.success("Connection created");
    } catch (error) {
      console.error("Error adding link:", error);
      toast.error("Failed to create connection");
    }
  }, [userId]);

  const toggleConstellation = useCallback(async (nodeId: string) => {
    if (!userId) {
      // Local only fallback
      setConstellation(prev => {
        const next = new Set(prev);
        if (next.has(nodeId)) next.delete(nodeId);
        else next.add(nodeId);
        return next;
      });
      return;
    }

    try {
      if (constellation.has(nodeId)) {
        // Remove
        const { error } = await supabase
          .from("trust_constellations")
          .delete()
          .match({ user_id: userId, node_id: nodeId });
        if (error) throw error;
        
        setConstellation(prev => {
          const next = new Set(prev);
          next.delete(nodeId);
          return next;
        });
      } else {
        // Add
        const { error } = await supabase
          .from("trust_constellations")
          .insert({ user_id: userId, node_id: nodeId });
        if (error) throw error;

        setConstellation(prev => {
          const next = new Set(prev);
          next.add(nodeId);
          return next;
        });
      }
    } catch (error) {
      console.error("Error toggling constellation:", error);
      toast.error("Failed to update constellation");
    }
  }, [userId, constellation]);

  return {
    graphData: data,
    loading,
    constellation,
    addNode,
    addLink,
    toggleConstellation,
    isReadOnly: !userId
  };
}
