//! Unicode normalization for tokenization.
//!
//! Implements text normalization steps required for SentencePiece tokenization:
//! - Lowercase conversion
//! - NFKC/NFC normalization
//! - Whitespace handling
//! - Accent stripping
//! - SentencePiece space encoding (space → ▁)

use unicode_normalization::UnicodeNormalization;

use crate::Result;

/// Configuration for text normalization.
#[derive(Debug, Clone, Default)]
pub struct NormalizerConfig {
    /// Ordered list of normalization steps to apply.
    pub steps: Vec<NormalizerStep>,
}

/// Individual normalization step.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NormalizerStep {
    /// Convert to lowercase.
    Lowercase,
    /// Apply NFKC Unicode normalization.
    Nfkc,
    /// Apply NFC Unicode normalization.
    Nfc,
    /// Replace all whitespace with space.
    ReplaceWhitespace,
    /// Collapse consecutive spaces to single space.
    CollapseWhitespace,
    /// Remove accents/diacritics.
    StripAccents,
    /// Replace space with SentencePiece underscore (▁).
    SpaceToUnderscore,
    /// Prepend underscore at start of text.
    PrependUnderscore,
}

/// Text normalizer that applies configured normalization steps.
#[derive(Debug, Clone)]
pub struct Normalizer {
    config: NormalizerConfig,
}

impl Normalizer {
    /// Create a new normalizer with the given configuration.
    pub fn new(config: NormalizerConfig) -> Self {
        Self { config }
    }

    /// Create a normalizer with default SentencePiece settings.
    pub fn sentencepiece_default() -> Self {
        Self::new(NormalizerConfig {
            steps: vec![
                NormalizerStep::Nfkc,
                NormalizerStep::ReplaceWhitespace,
                NormalizerStep::CollapseWhitespace,
                NormalizerStep::SpaceToUnderscore,
                NormalizerStep::PrependUnderscore,
            ],
        })
    }

    /// Normalize input text according to configuration.
    ///
    /// Returns normalized text as a vector of Unicode codepoints.
    pub fn normalize(&self, text: &str) -> Result<Vec<u32>> {
        let mut result = text.to_string();

        for step in &self.config.steps {
            result = self.apply_step(&result, *step)?;
        }

        // Convert to codepoints
        Ok(result.chars().map(|c| c as u32).collect())
    }

    /// Normalize and return as string (for testing).
    pub fn normalize_to_string(&self, text: &str) -> Result<String> {
        let mut result = text.to_string();

        for step in &self.config.steps {
            result = self.apply_step(&result, *step)?;
        }

        Ok(result)
    }

    fn apply_step(&self, text: &str, step: NormalizerStep) -> Result<String> {
        match step {
            NormalizerStep::Lowercase => Ok(text.to_lowercase()),

            NormalizerStep::Nfkc => Ok(text.nfkc().collect()),

            NormalizerStep::Nfc => Ok(text.nfc().collect()),

            NormalizerStep::ReplaceWhitespace => Ok(text
                .chars()
                .map(|c| if c.is_whitespace() { ' ' } else { c })
                .collect()),

            NormalizerStep::CollapseWhitespace => {
                let mut result = String::with_capacity(text.len());
                let mut prev_space = false;
                for c in text.chars() {
                    if c == ' ' {
                        if !prev_space {
                            result.push(c);
                        }
                        prev_space = true;
                    } else {
                        result.push(c);
                        prev_space = false;
                    }
                }
                Ok(result)
            }

            NormalizerStep::StripAccents => {
                // Use NFD to decompose, then filter combining marks
                Ok(text.nfd().filter(|c| !is_combining_mark(*c)).collect())
            }

            NormalizerStep::SpaceToUnderscore => {
                // Replace space with SentencePiece underscore ▁ (U+2581)
                Ok(text.replace(' ', "\u{2581}"))
            }

            NormalizerStep::PrependUnderscore => {
                // Prepend ▁ if not already present
                if text.starts_with('\u{2581}') {
                    Ok(text.to_string())
                } else {
                    Ok(format!("\u{2581}{}", text))
                }
            }
        }
    }
}

/// Check if a character is a Unicode combining mark.
fn is_combining_mark(c: char) -> bool {
    matches!(
        unicode_general_category(c),
        UnicodeCategory::Mn | // Nonspacing Mark
        UnicodeCategory::Mc | // Spacing Combining Mark
        UnicodeCategory::Me // Enclosing Mark
    )
}

/// Simple Unicode general category detection for combining marks.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[allow(dead_code)] // Mc and Me are for completeness, currently only Mn is detected
enum UnicodeCategory {
    Mn, // Nonspacing Mark
    Mc, // Spacing Combining Mark
    Me, // Enclosing Mark
    Other,
}

fn unicode_general_category(c: char) -> UnicodeCategory {
    let cp = c as u32;
    // Combining Diacritical Marks: U+0300–U+036F
    // Combining Diacritical Marks Extended: U+1AB0–U+1AFF
    // Combining Diacritical Marks Supplement: U+1DC0–U+1DFF
    // Combining Diacritical Marks for Symbols: U+20D0–U+20FF
    // Combining Half Marks: U+FE20–U+FE2F
    if (0x0300..=0x036F).contains(&cp)
        || (0x1AB0..=0x1AFF).contains(&cp)
        || (0x1DC0..=0x1DFF).contains(&cp)
        || (0x20D0..=0x20FF).contains(&cp)
        || (0xFE20..=0xFE2F).contains(&cp)
    {
        UnicodeCategory::Mn
    } else {
        UnicodeCategory::Other
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_lowercase() {
        let normalizer = Normalizer::new(NormalizerConfig {
            steps: vec![NormalizerStep::Lowercase],
        });
        assert_eq!(
            normalizer.normalize_to_string("Hello WORLD").unwrap(),
            "hello world"
        );
    }

    #[test]
    fn test_lowercase_unicode() {
        let normalizer = Normalizer::new(NormalizerConfig {
            steps: vec![NormalizerStep::Lowercase],
        });
        assert_eq!(normalizer.normalize_to_string("ÜBER").unwrap(), "über");
    }

    #[test]
    fn test_nfkc() {
        let normalizer = Normalizer::new(NormalizerConfig {
            steps: vec![NormalizerStep::Nfkc],
        });
        // Full-width A (U+FF21) -> A
        assert_eq!(normalizer.normalize_to_string("\u{FF21}").unwrap(), "A");
    }

    #[test]
    fn test_replace_whitespace() {
        let normalizer = Normalizer::new(NormalizerConfig {
            steps: vec![NormalizerStep::ReplaceWhitespace],
        });
        assert_eq!(normalizer.normalize_to_string("a\tb\nc").unwrap(), "a b c");
    }

    #[test]
    fn test_collapse_whitespace() {
        let normalizer = Normalizer::new(NormalizerConfig {
            steps: vec![NormalizerStep::CollapseWhitespace],
        });
        assert_eq!(normalizer.normalize_to_string("a   b  c").unwrap(), "a b c");
    }

    #[test]
    fn test_strip_accents() {
        let normalizer = Normalizer::new(NormalizerConfig {
            steps: vec![NormalizerStep::StripAccents],
        });
        assert_eq!(normalizer.normalize_to_string("café").unwrap(), "cafe");
    }

    #[test]
    fn test_space_to_underscore() {
        let normalizer = Normalizer::new(NormalizerConfig {
            steps: vec![NormalizerStep::SpaceToUnderscore],
        });
        assert_eq!(
            normalizer.normalize_to_string("hello world").unwrap(),
            "hello\u{2581}world"
        );
    }

    #[test]
    fn test_prepend_underscore() {
        let normalizer = Normalizer::new(NormalizerConfig {
            steps: vec![NormalizerStep::PrependUnderscore],
        });
        assert_eq!(
            normalizer.normalize_to_string("hello").unwrap(),
            "\u{2581}hello"
        );
    }

    #[test]
    fn test_prepend_underscore_already_present() {
        let normalizer = Normalizer::new(NormalizerConfig {
            steps: vec![NormalizerStep::PrependUnderscore],
        });
        assert_eq!(
            normalizer.normalize_to_string("\u{2581}hello").unwrap(),
            "\u{2581}hello"
        );
    }

    #[test]
    fn test_sentencepiece_default() {
        let normalizer = Normalizer::sentencepiece_default();
        // "Hello World" -> NFKC -> replace ws -> collapse -> space_to_▁ -> prepend_▁
        // -> "▁Hello▁World"
        assert_eq!(
            normalizer.normalize_to_string("Hello World").unwrap(),
            "\u{2581}Hello\u{2581}World"
        );
    }

    #[test]
    fn test_normalize_to_codepoints() {
        let normalizer = Normalizer::new(NormalizerConfig {
            steps: vec![NormalizerStep::Lowercase],
        });
        let codepoints = normalizer.normalize("AB").unwrap();
        assert_eq!(codepoints, vec![0x61, 0x62]); // 'a', 'b'
    }

    #[test]
    fn test_empty_input() {
        let normalizer = Normalizer::sentencepiece_default();
        let result = normalizer.normalize_to_string("").unwrap();
        assert_eq!(result, "\u{2581}");
    }

    #[test]
    fn test_is_combining_mark() {
        // U+0301 is COMBINING ACUTE ACCENT
        assert!(is_combining_mark('\u{0301}'));
        // Regular 'a' is not a combining mark
        assert!(!is_combining_mark('a'));
    }
}
