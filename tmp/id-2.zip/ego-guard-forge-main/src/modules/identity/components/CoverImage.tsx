/**
 * CoverImage — A personal cover photo for the identity sanctuary.
 * 
 * Elegant, full-width with soft gradient fade and parallax depth.
 * Uploads to cloud storage for persistence across sessions.
 */

import { useState, useRef, useEffect, useCallback } from "react";
import { Camera, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import defaultCover from "@/assets/default-cover.jpg";

interface CoverImageProps {
  src?: string;
  onImageChange?: (url: string) => void;
}

export default function CoverImage({ src, onImageChange }: CoverImageProps) {
  const [hovering, setHovering] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const imageSrc = src || defaultCover;

  const handleScroll = useCallback(() => {
    setScrollY(window.scrollY);
  }, []);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file
    if (!file.type.startsWith("image/")) {
      toast({ title: "Please select an image file", variant: "destructive" });
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "Image must be under 5MB", variant: "destructive" });
      return;
    }

    setUploading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast({ title: "Please sign in to change your cover", variant: "destructive" });
        return;
      }

      const userId = session.user.id;
      const ext = file.name.split(".").pop() || "jpg";
      const filePath = `${userId}/cover.${ext}`;

      // Upload to storage (upsert)
      const { error: uploadError } = await supabase.storage
        .from("cover-images")
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from("cover-images")
        .getPublicUrl(filePath);

      // Add cache-busting param
      const url = `${publicUrl}?t=${Date.now()}`;

      // Save URL to profile
      await supabase
        .from("profiles")
        .update({ cover_image_url: url } as any)
        .eq("user_id", userId);

      onImageChange?.(url);
      toast({ title: "Cover image updated" });
    } catch (err: any) {
      console.error("Cover upload error:", err);
      toast({ title: "Failed to upload cover image", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  // Parallax: image moves at 40% of scroll speed
  const parallaxOffset = scrollY * 0.4;

  return (
    <div
      ref={containerRef}
      className="relative w-full overflow-hidden"
      style={{ height: "clamp(240px, 38vh, 480px)" }}
      onMouseEnter={() => setHovering(true)}
      onMouseLeave={() => setHovering(false)}
    >
      {/* Image with parallax */}
      <img
        src={imageSrc}
        alt="Your personal cover"
        className="absolute inset-0 w-full object-cover object-center will-change-transform"
        style={{
          filter: "saturate(0.85) brightness(0.95)",
          height: "130%",
          top: "-15%",
          transform: `translateY(${parallaxOffset}px)`,
        }}
      />

      {/* Bottom gradient — fades into background */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `linear-gradient(to bottom, 
            transparent 0%, 
            transparent 40%, 
            hsl(var(--background) / 0.3) 65%, 
            hsl(var(--background) / 0.7) 82%, 
            hsl(var(--background)) 100%
          )`,
        }}
      />

      {/* Top subtle vignette */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "linear-gradient(to bottom, hsl(var(--background) / 0.15) 0%, transparent 30%)",
        }}
      />

      {/* Change button — always visible as a subtle icon, more prominent on hover */}
      <button
        onClick={() => inputRef.current?.click()}
        disabled={uploading}
        className="absolute bottom-4 right-6 flex items-center justify-center w-9 h-9 rounded-full 
          bg-background/50 backdrop-blur-md border border-border/20
          text-foreground/40 hover:text-foreground hover:bg-background/80
          transition-all duration-500 disabled:opacity-50"
      >
        {uploading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <Camera className="h-4 w-4" />
        )}
      </button>

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  );
}
