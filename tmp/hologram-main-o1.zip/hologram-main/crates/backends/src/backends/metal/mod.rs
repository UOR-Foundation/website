//! Metal backend implementation (skeleton).
//!
//! This module provides a skeleton Metal backend for Apple GPUs.
//! The actual Metal implementation is planned for a future sprint.
//!
//! # Architecture
//!
//! The Metal backend will:
//! - Detect available Apple GPUs via Metal framework
//! - Allocate MTLBuffer for buffers and constants
//! - Execute ISA operations as Metal compute pipelines
//! - Synchronize via command buffer completion
//!
//! # Current Status
//!
//! This is a skeleton implementation. All methods return `NotImplemented` errors.
//! The structure demonstrates the intended API for Apple GPU execution.
//!
//! # Platform Support
//!
//! Metal is only available on macOS, iOS, and tvOS. On other platforms,
//! `is_available()` returns `false`.

use hologram_holo::BackendPlan;

use super::gpu::{GpuBackend, GpuBuffer, GpuDevice};
use super::Backend;
use crate::types::{BackendCapabilities, BackendError, BackendType, Result};

/// Metal backend for Apple GPU execution (skeleton).
///
/// This backend will execute ISA plans on Apple GPUs using Metal.
/// Currently a skeleton with stub implementations.
pub struct MetalBackend {
    capabilities: BackendCapabilities,
    current_device: Option<GpuDevice>,
}

impl MetalBackend {
    /// Create a new Metal backend.
    ///
    /// # Errors
    ///
    /// Returns error if Metal is not available (currently always succeeds
    /// as this is a skeleton).
    pub fn new() -> Result<Self> {
        Ok(Self {
            capabilities: BackendCapabilities {
                backend_type: BackendType::Metal,
                vector_width: 32,               // Metal SIMD group size
                l1_cache_size: 32 * 1024,       // Typical L1 per GPU core
                l2_cache_size: 8 * 1024 * 1024, // Typical L2
                has_fma: true,
                has_sha: false,
                has_aes: false,
            },
            current_device: None,
        })
    }

    /// Check if Metal is available on this system.
    ///
    /// # Returns
    ///
    /// Currently always returns `false` (skeleton implementation).
    /// In a real implementation, would check for Metal framework availability.
    #[must_use]
    pub fn is_available() -> bool {
        // Skeleton: would check for Metal framework
        // Real impl: MTLCreateSystemDefaultDevice() != nil
        false
    }
}

impl Default for MetalBackend {
    fn default() -> Self {
        Self::new().expect("Metal backend creation should not fail in skeleton")
    }
}

impl Backend for MetalBackend {
    fn backend_type(&self) -> BackendType {
        BackendType::Metal
    }

    fn execute_plan(
        &self,
        _plan: &BackendPlan,
        _inputs: &[&[u8]],
        _outputs: &mut [&mut [u8]],
    ) -> Result<()> {
        Err(BackendError::NotImplemented {
            feature: "Metal plan execution".into(),
        })
    }

    fn execute_plan_with_layers(
        &self,
        _plan: &BackendPlan,
        _inputs: &[&[u8]],
        _outputs: &mut [&mut [u8]],
        _layer_executor: super::LayerExecutorFn<'_>,
    ) -> Result<()> {
        Err(BackendError::NotImplemented {
            feature: "Metal plan execution with layers".into(),
        })
    }

    fn capabilities(&self) -> &BackendCapabilities {
        &self.capabilities
    }
}

impl GpuBackend for MetalBackend {
    fn enumerate_devices(&self) -> Result<Vec<GpuDevice>> {
        // Skeleton: would call MTLCopyAllDevices()
        Err(BackendError::NotImplemented {
            feature: "Metal device enumeration".into(),
        })
    }

    fn select_device(&mut self, _device_index: u32) -> Result<()> {
        Err(BackendError::NotImplemented {
            feature: "Metal device selection".into(),
        })
    }

    fn current_device(&self) -> Option<&GpuDevice> {
        self.current_device.as_ref()
    }

    fn allocate(&mut self, _size: usize) -> Result<GpuBuffer> {
        // Skeleton: would call device.makeBuffer(length:options:)
        Err(BackendError::NotImplemented {
            feature: "Metal buffer allocation".into(),
        })
    }

    fn free(&mut self, _buffer: GpuBuffer) -> Result<()> {
        // Skeleton: Metal uses ARC, explicit free not needed
        Err(BackendError::NotImplemented {
            feature: "Metal buffer free".into(),
        })
    }

    fn upload(&mut self, _dst: GpuBuffer, _src: &[u8]) -> Result<()> {
        // Skeleton: would copy to buffer.contents()
        Err(BackendError::NotImplemented {
            feature: "Metal buffer upload".into(),
        })
    }

    fn download(&self, _src: GpuBuffer, _dst: &mut [u8]) -> Result<()> {
        // Skeleton: would copy from buffer.contents()
        Err(BackendError::NotImplemented {
            feature: "Metal buffer download".into(),
        })
    }

    fn synchronize(&self) -> Result<()> {
        // Skeleton: would wait on command buffer completion
        Err(BackendError::NotImplemented {
            feature: "Metal synchronization".into(),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_metal_backend_creation() {
        let backend = MetalBackend::new().unwrap();
        assert_eq!(backend.backend_type(), BackendType::Metal);
    }

    #[test]
    fn test_metal_backend_default() {
        let backend = MetalBackend::default();
        assert_eq!(backend.backend_type(), BackendType::Metal);
    }

    #[test]
    fn test_metal_is_available() {
        // Skeleton always returns false
        assert!(!MetalBackend::is_available());
    }

    #[test]
    fn test_metal_capabilities() {
        let backend = MetalBackend::new().unwrap();
        let caps = backend.capabilities();
        assert_eq!(caps.backend_type, BackendType::Metal);
        assert_eq!(caps.vector_width, 32); // SIMD group size
    }

    #[test]
    fn test_metal_execute_returns_not_implemented() {
        use hologram_holo::PlanMetadata;

        let backend = MetalBackend::new().unwrap();
        let plan = BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        let result = backend.execute_plan(&plan, &[], &mut []);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_metal_enumerate_returns_not_implemented() {
        let backend = MetalBackend::new().unwrap();
        let result = backend.enumerate_devices();
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_metal_select_device_returns_not_implemented() {
        let mut backend = MetalBackend::new().unwrap();
        let result = backend.select_device(0);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_metal_current_device_initially_none() {
        let backend = MetalBackend::new().unwrap();
        assert!(backend.current_device().is_none());
    }

    #[test]
    fn test_metal_allocate_returns_not_implemented() {
        let mut backend = MetalBackend::new().unwrap();
        let result = backend.allocate(1024);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_metal_free_returns_not_implemented() {
        let mut backend = MetalBackend::new().unwrap();
        let buffer = GpuBuffer {
            handle: 0,
            size: 1024,
        };
        let result = backend.free(buffer);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_metal_upload_returns_not_implemented() {
        let mut backend = MetalBackend::new().unwrap();
        let buffer = GpuBuffer {
            handle: 0,
            size: 1024,
        };
        let data = [0u8; 1024];
        let result = backend.upload(buffer, &data);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_metal_download_returns_not_implemented() {
        let backend = MetalBackend::new().unwrap();
        let buffer = GpuBuffer {
            handle: 0,
            size: 1024,
        };
        let mut data = [0u8; 1024];
        let result = backend.download(buffer, &mut data);
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }

    #[test]
    fn test_metal_synchronize_returns_not_implemented() {
        let backend = MetalBackend::new().unwrap();
        let result = backend.synchronize();
        assert!(matches!(result, Err(BackendError::NotImplemented { .. })));
    }
}
