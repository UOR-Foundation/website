//! JSON exporter for machine-readable metric output.

use crate::exporters::MetricExporter;
use crate::metrics::{HistogramSummary, MetricsRegistry};
use tracing::info;

/// JSON exporter that produces machine-readable output.
pub struct JsonExporter;

impl MetricExporter for JsonExporter {
    fn export(&self, registry: &MetricsRegistry) -> String {
        let counters = registry.counters();
        let histograms = registry.histograms();

        let mut json = String::from("{\n");

        // Export counters
        json.push_str("  \"counters\": {\n");
        let counter_entries: Vec<String> = counters
            .iter()
            .map(|(name, value)| format!("    \"{}\": {}", name, value))
            .collect();
        json.push_str(&counter_entries.join(",\n"));
        if !counter_entries.is_empty() {
            json.push('\n');
        }
        json.push_str("  },\n");

        // Export histograms
        json.push_str("  \"histograms\": {\n");
        let histogram_entries: Vec<String> = histograms
            .iter()
            .map(|(name, summary)| format!("    \"{}\": {}", name, format_summary_json(summary)))
            .collect();
        json.push_str(&histogram_entries.join(",\n"));
        if !histogram_entries.is_empty() {
            json.push('\n');
        }
        json.push_str("  }\n");

        json.push('}');
        json
    }
}

impl JsonExporter {
    /// Create a new JSON exporter.
    #[must_use]
    pub const fn new() -> Self {
        Self
    }

    /// Export metrics and log to tracing.
    pub fn print(&self, registry: &MetricsRegistry) {
        info!("{}", self.export(registry));
    }
}

impl Default for JsonExporter {
    fn default() -> Self {
        Self::new()
    }
}

/// Format a histogram summary as JSON.
fn format_summary_json(summary: &HistogramSummary) -> String {
    format!(
        "{{\"count\": {}, \"sum\": {:.6}, \"mean\": {:.6}, \"min\": {:.6}, \"max\": {:.6}, \"p50\": {:.6}, \"p95\": {:.6}, \"p99\": {:.6}}}",
        summary.count,
        summary.sum,
        summary.mean,
        summary.min,
        summary.max,
        summary.p50,
        summary.p95,
        summary.p99
    )
}

/// Parse a simple JSON metric export (for testing).
#[must_use]
pub fn parse_counter_value(json: &str, counter_name: &str) -> Option<u64> {
    // Simple parsing without external dependencies
    let search = format!("\"{}\": ", counter_name);
    if let Some(pos) = json.find(&search) {
        let start = pos + search.len();
        let rest = &json[start..];
        let end = rest
            .find(|c: char| !c.is_ascii_digit())
            .unwrap_or(rest.len());
        rest[..end].parse().ok()
    } else {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_json_exporter_empty() {
        let registry = MetricsRegistry::new();
        let exporter = JsonExporter::new();
        let output = exporter.export(&registry);

        assert!(output.contains("\"counters\""));
        assert!(output.contains("\"histograms\""));
    }

    #[test]
    fn test_json_exporter_counters() {
        let registry = MetricsRegistry::new();
        registry.increment("requests", 100);
        registry.increment("errors", 5);

        let exporter = JsonExporter::new();
        let output = exporter.export(&registry);

        assert!(output.contains("\"requests\": 100"));
        assert!(output.contains("\"errors\": 5"));
    }

    #[test]
    fn test_json_exporter_histograms() {
        let registry = MetricsRegistry::new();
        registry.record("latency", 10.5);

        let exporter = JsonExporter::new();
        let output = exporter.export(&registry);

        assert!(output.contains("\"latency\":"));
        assert!(output.contains("\"count\": 1"));
    }

    #[test]
    fn test_format_summary_json() {
        let summary = HistogramSummary {
            count: 10,
            sum: 55.0,
            mean: 5.5,
            min: 1.0,
            max: 10.0,
            p50: 5.0,
            p95: 9.5,
            p99: 9.9,
        };

        let json = format_summary_json(&summary);
        assert!(json.contains("\"count\": 10"));
        assert!(json.contains("\"mean\": 5.5"));
    }

    #[test]
    fn test_parse_counter_value() {
        let json = r#"{"counters": {"requests": 100, "errors": 5}}"#;
        assert_eq!(parse_counter_value(json, "requests"), Some(100));
        assert_eq!(parse_counter_value(json, "errors"), Some(5));
        assert_eq!(parse_counter_value(json, "missing"), None);
    }

    #[test]
    fn test_json_exporter_default() {
        let exporter = JsonExporter;
        let registry = MetricsRegistry::new();
        let _ = exporter.export(&registry);
    }
}
