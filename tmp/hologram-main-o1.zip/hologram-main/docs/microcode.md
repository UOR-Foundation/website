# Microcode Architecture

This document describes the microcode architecture used in the Hologram framework. Microcode provides a universal backend implementation strategy where all operations are derived from 5 fundamental primitives.

## Overview

The microcode system enables:
- **Universal portability**: Any backend (CPU, GPU, WASM) can implement the 5 primitives and automatically gain all derived operations
- **Hardware optimization**: Backends can override derived operations with native hardware instructions for better performance
- **Formal verification**: Derived operations have provable correctness through their microcode definitions

## The 5 Fundamental Primitives

All arithmetic and logical operations are synthesized from these 5 primitives:

| Primitive | Symbol | Description | Hardware Mapping |
|-----------|--------|-------------|------------------|
| `bnot` | `!a` | Bitwise NOT | AVX2: `vpxor` with all-ones; NEON: `vmvnq_u32` |
| `neg` | `-a` | Two's complement negation | AVX2: `vpsubd` from zero; NEON: `vnegq_s32` |
| `xor` | `a ^ b` | Bitwise XOR | AVX2: `vpxor`; NEON: `veorq_u32` |
| `and` | `a & b` | Bitwise AND | AVX2: `vpand`; NEON: `vandq_u32` |
| `or` | `a \| b` | Bitwise OR | AVX2: `vpor`; NEON: `vorrq_u32` |

### Mathematical Properties

- **Functional completeness**: `{NOT, AND}` and `{NOT, OR}` are each functionally complete
- **Involutions**: `bnot(bnot(x)) = x` and `neg(neg(x)) = x`
- **XOR identity**: `xor(a, a) = 0` (self-canceling)

## Critical Identities

The most important discovery is that `neg` and `bnot` together generate the successor function:

```
neg(bnot(x)) = x + 1  (INC)
bnot(neg(x)) = x - 1  (DEC)
```

This means the two involutions (`neg` and `bnot`) generate the entire integer ring.

## Derived Operations

### Arithmetic Operations

| Operation | Microcode Definition | Complexity |
|-----------|---------------------|------------|
| `inc(a)` | `neg(bnot(a))` | 2 primitives |
| `dec(a)` | `bnot(neg(a))` | 2 primitives |
| `add(a, b)` | Kogge-Stone parallel prefix | ~160 primitives (32-bit) |
| `sub(a, b)` | `add(a, neg(b))` | ~161 primitives (32-bit) |

### Shift/Rotate Operations

| Operation | Description | Complexity |
|-----------|-------------|------------|
| `shl(a, n)` | Logical shift left | Native (1 instruction) |
| `shr(a, n)` | Logical shift right | Native (1 instruction) |
| `rotl(a, n)` | Rotate left | Native (1 instruction) |
| `rotr(a, n)` | Rotate right | Native (1 instruction) |

### Comparison Operations

All comparison operations return boolean masks (all-ones for true, all-zeros for false):

| Operation | Microcode Definition | Description |
|-----------|---------------------|-------------|
| `eq(a, b)` | `not(is_nonzero(xor(a, b)))` | Equal |
| `ne(a, b)` | `is_nonzero(xor(a, b))` | Not equal |
| `lt(a, b)` | Native comparison | Less than (unsigned) |
| `le(a, b)` | `not(lt(b, a))` | Less than or equal |
| `gt(a, b)` | `lt(b, a)` | Greater than |
| `ge(a, b)` | `not(lt(a, b))` | Greater than or equal |

### Conditional Operations

| Operation | Microcode Definition | Description |
|-----------|---------------------|-------------|
| `select(mask, a, b)` | `(a & mask) \| (b & !mask)` | Branchless select |
| `is_nonzero(a)` | `sar(neg(a) \| a, BITS-1)` | Returns mask if a != 0 |

## Kogge-Stone Parallel Prefix Adder

Addition is implemented using the Kogge-Stone algorithm, which computes carry propagation in O(log n) parallel steps:

```
For 32-bit addition:
- Generate (G) = a & b
- Propagate (P) = a ^ b
- 5 levels of parallel prefix computation
- Final sum = P ^ (G << 1)
```

The Kogge-Stone adder uses approximately 160 primitive operations for 32-bit addition. This is significantly slower than native hardware addition (1 cycle), which is why backends should override `add` with native instructions when available.

## Backend Integration

### Trait Hierarchy

```
MicrocodeWord          -- Word type requirements (ONES, ZEROS, BITS, etc.)
    │
MicrocodePrimitives    -- The 5 fundamental operations (must implement)
    │
MicrocodeOps           -- Derived operations (default implementations)
```

### Implementing a Backend

1. Implement `MicrocodePrimitives` for your word type:

```rust
impl MicrocodePrimitives<u32> for MyBackend {
    fn bnot(&self, a: u32) -> u32 { !a }
    fn neg(&self, a: u32) -> u32 { a.wrapping_neg() }
    fn xor(&self, a: u32, b: u32) -> u32 { a ^ b }
    fn and(&self, a: u32, b: u32) -> u32 { a & b }
    fn or(&self, a: u32, b: u32) -> u32 { a | b }
}
```

2. All derived operations (`inc`, `dec`, `add`, `sub`, etc.) are automatically available.

3. Override for performance where native hardware support exists:

```rust
impl MicrocodeOps<u32> for MyBackend {
    fn add(&self, a: u32, b: u32) -> u32 {
        a.wrapping_add(b)  // Native add instead of Kogge-Stone
    }
}
```

## Word Types

The microcode system supports multiple word types:

| Type | BITS | ELEMENT_BITS | Use Case |
|------|------|--------------|----------|
| `u32` | 32 | 32 | Scalar operations |
| `u64` | 64 | 64 | 64-bit scalar |
| `[u32; 4]` | 128 | 32 | WASM SIMD128, NEON |
| `[u32; 8]` | 256 | 32 | AVX2 |
| `[u64; 4]` | 256 | 64 | AVX2 64-bit lanes |

`ELEMENT_BITS` is used for per-element shift operations in SIMD contexts.

## Performance Characteristics

### Microcode vs Native Overhead

| Operation | Microcode Complexity | Expected Overhead |
|-----------|---------------------|-------------------|
| `inc` | 2 primitives | ~1x (compiler optimizes) |
| `dec` | 2 primitives | ~1x (compiler optimizes) |
| `add` | ~160 primitives | 5-20x slower |
| `sub` | ~161 primitives | 5-20x slower |

### When to Override

Always override with native instructions when available:
- `add`/`sub`: vpaddd, vpsubd (x86), vaddq_u32 (NEON)
- `mul`: vpmulld (x86), vmulq_u32 (NEON)
- Shifts: vpsrld, vpslld (x86), vshlq_n_u32 (NEON)

### CI Benchmark Gates

The CI system verifies that native overrides are at least 3x faster than microcode fallbacks. This ensures:
1. Native overrides are actually being used
2. Performance hasn't regressed
3. The overhead threshold is maintained

## Instrumentation

When the `instrumentation` feature is enabled, the backend system logs:
- Which backend variant was auto-selected
- Whether SIMD is being used
- The vector width in bits

Enable with:
```bash
cargo build --features instrumentation
```

## Content-Addressed Derivations

Each derived operation has a unique content-addressed ID computed from its microcode definition. This enables:
- Caching of computed derivations
- Verification of derivation correctness
- Reproducible computation across backends

## See Also

- `crates/uor/src/microcode/` - Core microcode implementation
- `crates/backends/src/microcode.rs` - Backend integration
- `crates/backends/tests/microcode_cross_backend.rs` - Cross-backend verification tests
