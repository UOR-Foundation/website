//! Buffer handles and launch configuration types.
//!
//! This module provides types for managing GPU/CPU buffers and
//! configuring kernel launches.

use super::markers::ZeroCopyPath;

/// Handle to a buffer allocated by a backend.
///
/// Buffer handles are opaque identifiers that reference memory
/// allocated by a specific backend. They are not transferable
/// between backends.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct BufferHandle(u64);

impl BufferHandle {
    /// Create a new buffer handle with the given ID.
    #[must_use]
    pub const fn new(id: u64) -> Self {
        Self(id)
    }

    /// Get the raw ID of this handle.
    #[must_use]
    pub const fn id(&self) -> u64 {
        self.0
    }

    /// Create a null/invalid handle.
    #[must_use]
    pub const fn null() -> Self {
        Self(u64::MAX)
    }

    /// Check if this is a null handle.
    #[must_use]
    pub const fn is_null(&self) -> bool {
        self.0 == u64::MAX
    }
}

impl Default for BufferHandle {
    fn default() -> Self {
        Self::null()
    }
}

impl std::fmt::Display for BufferHandle {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if self.is_null() {
            write!(f, "BufferHandle(null)")
        } else {
            write!(f, "BufferHandle({})", self.0)
        }
    }
}

/// Configuration for launching a compute kernel or program.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LaunchConfig {
    /// Number of work groups in the X dimension.
    pub grid_x: u32,
    /// Number of work groups in the Y dimension.
    pub grid_y: u32,
    /// Number of work groups in the Z dimension.
    pub grid_z: u32,
    /// Number of threads per work group in the X dimension.
    pub block_x: u32,
    /// Number of threads per work group in the Y dimension.
    pub block_y: u32,
    /// Number of threads per work group in the Z dimension.
    pub block_z: u32,
    /// Shared memory size in bytes.
    pub shared_memory: usize,
}

impl LaunchConfig {
    /// Create a new launch configuration.
    #[must_use]
    pub const fn new() -> Self {
        Self {
            grid_x: 1,
            grid_y: 1,
            grid_z: 1,
            block_x: 1,
            block_y: 1,
            block_z: 1,
            shared_memory: 0,
        }
    }

    /// Create a 1D launch configuration.
    #[must_use]
    pub const fn dim1(grid: u32, block: u32) -> Self {
        Self {
            grid_x: grid,
            grid_y: 1,
            grid_z: 1,
            block_x: block,
            block_y: 1,
            block_z: 1,
            shared_memory: 0,
        }
    }

    /// Create a 2D launch configuration.
    #[must_use]
    pub const fn dim2(grid_x: u32, grid_y: u32, block_x: u32, block_y: u32) -> Self {
        Self {
            grid_x,
            grid_y,
            grid_z: 1,
            block_x,
            block_y,
            block_z: 1,
            shared_memory: 0,
        }
    }

    /// Create a 3D launch configuration.
    #[must_use]
    pub const fn dim3(
        grid_x: u32,
        grid_y: u32,
        grid_z: u32,
        block_x: u32,
        block_y: u32,
        block_z: u32,
    ) -> Self {
        Self {
            grid_x,
            grid_y,
            grid_z,
            block_x,
            block_y,
            block_z,
            shared_memory: 0,
        }
    }

    /// Set the shared memory size.
    #[must_use]
    pub const fn with_shared_memory(mut self, size: usize) -> Self {
        self.shared_memory = size;
        self
    }

    /// Get the total number of work groups.
    #[must_use]
    pub const fn total_groups(&self) -> u64 {
        self.grid_x as u64 * self.grid_y as u64 * self.grid_z as u64
    }

    /// Get the total number of threads per work group.
    #[must_use]
    pub const fn threads_per_group(&self) -> u64 {
        self.block_x as u64 * self.block_y as u64 * self.block_z as u64
    }

    /// Get the total number of threads.
    #[must_use]
    pub const fn total_threads(&self) -> u64 {
        self.total_groups() * self.threads_per_group()
    }

    /// Check if the configuration is valid.
    #[must_use]
    pub const fn is_valid(&self) -> bool {
        self.grid_x > 0
            && self.grid_y > 0
            && self.grid_z > 0
            && self.block_x > 0
            && self.block_y > 0
            && self.block_z > 0
    }

    /// Create a configuration for processing N elements with given block size.
    #[must_use]
    pub fn for_elements(count: usize, block_size: u32) -> Self {
        let grid = (count as u32).div_ceil(block_size);
        Self::dim1(grid.max(1), block_size)
    }
}

impl Default for LaunchConfig {
    fn default() -> Self {
        Self::new()
    }
}

/// Descriptor for buffer creation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BufferDescriptor {
    /// Size of the buffer in bytes.
    pub size: usize,
    /// Buffer usage flags.
    pub usage: BufferUsage,
    /// Optional label for debugging.
    pub label: Option<String>,
}

impl BufferDescriptor {
    /// Create a new buffer descriptor.
    #[must_use]
    pub const fn new(size: usize) -> Self {
        Self {
            size,
            usage: BufferUsage::STORAGE,
            label: None,
        }
    }

    /// Set the buffer usage.
    #[must_use]
    pub const fn with_usage(mut self, usage: BufferUsage) -> Self {
        self.usage = usage;
        self
    }

    /// Set the buffer label.
    #[must_use]
    pub fn with_label(mut self, label: impl Into<String>) -> Self {
        self.label = Some(label.into());
        self
    }
}

/// Buffer usage flags.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BufferUsage(u32);

impl BufferUsage {
    /// Buffer can be used as a storage buffer.
    pub const STORAGE: Self = Self(1 << 0);
    /// Buffer can be used as a uniform buffer.
    pub const UNIFORM: Self = Self(1 << 1);
    /// Buffer can be copied from.
    pub const COPY_SRC: Self = Self(1 << 2);
    /// Buffer can be copied to.
    pub const COPY_DST: Self = Self(1 << 3);
    /// Buffer can be mapped for reading.
    pub const MAP_READ: Self = Self(1 << 4);
    /// Buffer can be mapped for writing.
    pub const MAP_WRITE: Self = Self(1 << 5);

    /// Create a new buffer usage with the given flags.
    #[must_use]
    pub const fn new(flags: u32) -> Self {
        Self(flags)
    }

    /// Get the raw flags.
    #[must_use]
    pub const fn bits(&self) -> u32 {
        self.0
    }

    /// Check if this usage contains the given usage.
    #[must_use]
    pub const fn contains(&self, other: Self) -> bool {
        (self.0 & other.0) == other.0
    }

    /// Combine two usages.
    #[must_use]
    pub const fn union(self, other: Self) -> Self {
        Self(self.0 | other.0)
    }
}

impl std::ops::BitOr for BufferUsage {
    type Output = Self;

    fn bitor(self, rhs: Self) -> Self::Output {
        Self(self.0 | rhs.0)
    }
}

impl std::ops::BitOrAssign for BufferUsage {
    fn bitor_assign(&mut self, rhs: Self) {
        self.0 |= rhs.0;
    }
}

// === Zero-Copy Path Implementations ===
//
// These marker trait implementations guarantee that the types can be safely
// used in allocation-free hot paths.

// SAFETY: BufferHandle is Copy, Send, Sync, has no heap allocation, and is fixed size (u64).
unsafe impl ZeroCopyPath for BufferHandle {}

// SAFETY: BufferUsage is Copy, Send, Sync, has no heap allocation, and is fixed size (u32).
unsafe impl ZeroCopyPath for BufferUsage {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_buffer_handle_new() {
        let handle = BufferHandle::new(42);
        assert_eq!(handle.id(), 42);
    }

    #[test]
    fn test_buffer_handle_null() {
        let handle = BufferHandle::null();
        assert!(handle.is_null());
        assert_eq!(handle.id(), u64::MAX);
    }

    #[test]
    fn test_buffer_handle_default() {
        let handle = BufferHandle::default();
        assert!(handle.is_null());
    }

    #[test]
    fn test_buffer_handle_display() {
        let handle = BufferHandle::new(42);
        assert_eq!(format!("{handle}"), "BufferHandle(42)");

        let null = BufferHandle::null();
        assert_eq!(format!("{null}"), "BufferHandle(null)");
    }

    #[test]
    fn test_buffer_handle_equality() {
        let h1 = BufferHandle::new(1);
        let h2 = BufferHandle::new(1);
        let h3 = BufferHandle::new(2);
        assert_eq!(h1, h2);
        assert_ne!(h1, h3);
    }

    #[test]
    fn test_buffer_handle_hash() {
        use std::collections::HashSet;
        let mut set = HashSet::new();
        set.insert(BufferHandle::new(1));
        set.insert(BufferHandle::new(2));
        set.insert(BufferHandle::new(1));
        assert_eq!(set.len(), 2);
    }

    #[test]
    fn test_launch_config_new() {
        let config = LaunchConfig::new();
        assert_eq!(config.grid_x, 1);
        assert_eq!(config.grid_y, 1);
        assert_eq!(config.grid_z, 1);
        assert_eq!(config.block_x, 1);
        assert_eq!(config.block_y, 1);
        assert_eq!(config.block_z, 1);
        assert_eq!(config.shared_memory, 0);
    }

    #[test]
    fn test_launch_config_dim1() {
        let config = LaunchConfig::dim1(10, 256);
        assert_eq!(config.grid_x, 10);
        assert_eq!(config.grid_y, 1);
        assert_eq!(config.block_x, 256);
        assert_eq!(config.block_y, 1);
    }

    #[test]
    fn test_launch_config_dim2() {
        let config = LaunchConfig::dim2(10, 20, 16, 16);
        assert_eq!(config.grid_x, 10);
        assert_eq!(config.grid_y, 20);
        assert_eq!(config.block_x, 16);
        assert_eq!(config.block_y, 16);
    }

    #[test]
    fn test_launch_config_dim3() {
        let config = LaunchConfig::dim3(4, 4, 4, 8, 8, 8);
        assert_eq!(config.grid_x, 4);
        assert_eq!(config.grid_y, 4);
        assert_eq!(config.grid_z, 4);
        assert_eq!(config.block_x, 8);
        assert_eq!(config.block_y, 8);
        assert_eq!(config.block_z, 8);
    }

    #[test]
    fn test_launch_config_shared_memory() {
        let config = LaunchConfig::dim1(1, 256).with_shared_memory(1024);
        assert_eq!(config.shared_memory, 1024);
    }

    #[test]
    fn test_launch_config_total_groups() {
        let config = LaunchConfig::dim3(4, 5, 6, 1, 1, 1);
        assert_eq!(config.total_groups(), 120);
    }

    #[test]
    fn test_launch_config_threads_per_group() {
        let config = LaunchConfig::dim3(1, 1, 1, 8, 8, 8);
        assert_eq!(config.threads_per_group(), 512);
    }

    #[test]
    fn test_launch_config_total_threads() {
        let config = LaunchConfig::dim3(2, 2, 2, 4, 4, 4);
        assert_eq!(config.total_threads(), 8 * 64);
    }

    #[test]
    fn test_launch_config_is_valid() {
        assert!(LaunchConfig::dim1(1, 1).is_valid());
        assert!(LaunchConfig::dim2(10, 10, 16, 16).is_valid());

        let invalid = LaunchConfig {
            grid_x: 0,
            ..LaunchConfig::new()
        };
        assert!(!invalid.is_valid());
    }

    #[test]
    fn test_launch_config_for_elements() {
        let config = LaunchConfig::for_elements(1000, 256);
        assert_eq!(config.grid_x, 4);
        assert_eq!(config.block_x, 256);
        assert!(config.total_threads() >= 1000);
    }

    #[test]
    fn test_launch_config_for_elements_exact() {
        let config = LaunchConfig::for_elements(512, 256);
        assert_eq!(config.grid_x, 2);
    }

    #[test]
    fn test_launch_config_for_elements_small() {
        let config = LaunchConfig::for_elements(10, 256);
        assert_eq!(config.grid_x, 1);
    }

    #[test]
    fn test_buffer_descriptor_new() {
        let desc = BufferDescriptor::new(1024);
        assert_eq!(desc.size, 1024);
        assert_eq!(desc.usage, BufferUsage::STORAGE);
        assert!(desc.label.is_none());
    }

    #[test]
    fn test_buffer_descriptor_with_usage() {
        let desc = BufferDescriptor::new(1024).with_usage(BufferUsage::UNIFORM);
        assert_eq!(desc.usage, BufferUsage::UNIFORM);
    }

    #[test]
    fn test_buffer_descriptor_with_label() {
        let desc = BufferDescriptor::new(1024).with_label("test buffer");
        assert_eq!(desc.label, Some("test buffer".to_string()));
    }

    #[test]
    fn test_buffer_usage_contains() {
        let usage = BufferUsage::STORAGE | BufferUsage::COPY_SRC;
        assert!(usage.contains(BufferUsage::STORAGE));
        assert!(usage.contains(BufferUsage::COPY_SRC));
        assert!(!usage.contains(BufferUsage::UNIFORM));
    }

    #[test]
    fn test_buffer_usage_union() {
        let usage = BufferUsage::STORAGE.union(BufferUsage::COPY_DST);
        assert!(usage.contains(BufferUsage::STORAGE));
        assert!(usage.contains(BufferUsage::COPY_DST));
    }

    #[test]
    fn test_buffer_usage_bitor_assign() {
        let mut usage = BufferUsage::STORAGE;
        usage |= BufferUsage::MAP_READ;
        assert!(usage.contains(BufferUsage::STORAGE));
        assert!(usage.contains(BufferUsage::MAP_READ));
    }
}
