//! Constant data providers for zero-copy reads.
//!
//! A `ConstProvider` yields byte slices for constants without forcing the
//! runtime to materialize whole files into memory.

use crate::core::mapped_input::MappedInput;
use crate::error::{BackendError, BackendResult};
use std::collections::{HashMap, VecDeque};
use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use std::path::Path;
use std::sync::{Arc, Mutex};

/// Borrowed constant data slice.
pub struct ConstChunk<'a> {
    /// Borrowed bytes from the underlying provider.
    pub data: &'a [u8],
}

/// Trait for zero-copy constant access.
///
/// Implementations should avoid allocations and return borrowed slices that
/// remain valid for the lifetime of the provider.
pub trait ConstProvider: Send + Sync {
    /// Total bytes available.
    fn len(&self) -> usize;

    /// Whether provider is empty (default derived from len()).
    fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Borrow a slice at `offset..offset+len`.
    fn read_at<'a>(&'a self, offset: usize, len: usize) -> BackendResult<ConstChunk<'a>>;
}

/// Memory-mapped provider backed by a file.
#[derive(Debug)]
pub struct MmapConstProvider {
    mmap: Arc<MappedInput>,
    base_offset: usize,
}

impl MmapConstProvider {
    /// Open and memory-map a file as a constant provider.
    pub fn open(path: &Path, base_offset: usize) -> BackendResult<Self> {
        let mmap = MappedInput::open(path).map_err(|e| {
            BackendError::buffer(format!(
                "Failed to mmap constants file '{}': {}",
                path.display(),
                e
            ))
        })?;
        mmap.advise_random();
        Ok(Self {
            mmap: Arc::new(mmap),
            base_offset,
        })
    }

    /// Use an existing mmap.
    pub fn from_mmap(mmap: Arc<MappedInput>, base_offset: usize) -> Self {
        mmap.advise_random();
        Self { mmap, base_offset }
    }
}

impl ConstProvider for MmapConstProvider {
    fn len(&self) -> usize {
        self.mmap.len().saturating_sub(self.base_offset)
    }

    fn read_at<'a>(&'a self, offset: usize, len: usize) -> BackendResult<ConstChunk<'a>> {
        let start = self
            .base_offset
            .checked_add(offset)
            .ok_or_else(|| BackendError::buffer("offset overflow"))?;
        let end = start
            .checked_add(len)
            .ok_or_else(|| BackendError::buffer("len overflow"))?;

        if end > self.mmap.len() {
            return Err(BackendError::buffer(format!(
                "ConstProvider read out of bounds: start={} end={} mmap_len={}",
                start,
                end,
                self.mmap.len()
            )));
        }

        let data = &self.mmap.as_slice()[start..end];
        Ok(ConstChunk { data })
    }
}

struct ChunkCache {
    map: HashMap<usize, Arc<Vec<u8>>>,
    order: VecDeque<usize>,
    bytes: usize,
    max_bytes: usize,
}

impl ChunkCache {
    fn new(max_bytes: usize) -> Self {
        Self {
            map: HashMap::new(),
            order: VecDeque::new(),
            bytes: 0,
            max_bytes,
        }
    }

    fn insert(&mut self, key: usize, chunk: Arc<Vec<u8>>) {
        let size = chunk.len();
        if self.map.contains_key(&key) {
            return;
        }
        self.map.insert(key, chunk.clone());
        self.order.push_back(key);
        self.bytes = self.bytes.saturating_add(size);

        while self.bytes > self.max_bytes {
            if let Some(old_key) = self.order.pop_front() {
                if let Some(evicted) = self.map.remove(&old_key) {
                    self.bytes = self.bytes.saturating_sub(evicted.len());
                }
            } else {
                break;
            }
        }
    }

    fn get(&mut self, key: &usize) -> Option<Arc<Vec<u8>>> {
        if let Some(value) = self.map.get(key) {
            // Move to back for simple LRU behavior.
            self.order.retain(|k| k != key);
            self.order.push_back(*key);
            return Some(value.clone());
        }
        None
    }
}

/// Chunked file-backed provider with bounded cache (useful for streaming/decompressed sources).
pub struct ChunkedFileConstProvider {
    file: Mutex<File>,
    chunk_size: usize,
    cache: Mutex<ChunkCache>,
    file_len: usize,
}

impl ChunkedFileConstProvider {
    /// Open a file-backed provider with a bounded cache.
    pub fn open(path: &Path, chunk_size: usize, max_cached_bytes: usize) -> BackendResult<Self> {
        let file = File::open(path).map_err(|e| {
            BackendError::buffer(format!(
                "Failed to open chunked const provider '{}': {}",
                path.display(),
                e
            ))
        })?;
        let file_len = file.metadata().map(|m| m.len() as usize).map_err(|e| {
            BackendError::buffer(format!(
                "Failed to read metadata for '{}': {}",
                path.display(),
                e
            ))
        })?;
        let cache_cap = max_cached_bytes.max(chunk_size.max(4096));
        Ok(Self {
            file: Mutex::new(file),
            chunk_size: chunk_size.max(4096),
            cache: Mutex::new(ChunkCache::new(cache_cap)),
            file_len,
        })
    }

    fn read_chunk(&self, chunk_start: usize) -> BackendResult<Arc<Vec<u8>>> {
        let mut file = self.file.lock().unwrap();
        let mut buf = vec![
            0u8;
            self.chunk_size
                .min(self.file_len.saturating_sub(chunk_start))
        ];
        file.seek(SeekFrom::Start(chunk_start as u64))
            .map_err(|e| BackendError::buffer(format!("Failed to seek chunk: {}", e)))?;
        file.read_exact(&mut buf)
            .map_err(|e| BackendError::buffer(format!("Failed to read chunk: {}", e)))?;
        Ok(Arc::new(buf))
    }

    /// Total cached bytes (test visibility).
    #[cfg(test)]
    pub fn cached_bytes(&self) -> usize {
        self.cache.lock().unwrap().bytes
    }
}

impl ConstProvider for ChunkedFileConstProvider {
    fn len(&self) -> usize {
        self.file_len
    }

    fn read_at<'a>(&'a self, offset: usize, len: usize) -> BackendResult<ConstChunk<'a>> {
        if len > self.chunk_size {
            return Err(BackendError::buffer(format!(
                "ChunkedConstProvider request too large: {} > chunk_size {}",
                len, self.chunk_size
            )));
        }
        let chunk_start = (offset / self.chunk_size) * self.chunk_size;
        if chunk_start >= self.file_len {
            return Err(BackendError::buffer("offset past end of file"));
        }
        {
            let mut cache = self.cache.lock().unwrap();
            if cache.get(&chunk_start).is_none() {
                drop(cache);
                let fresh = self.read_chunk(chunk_start)?;
                let mut cache = self.cache.lock().unwrap();
                cache.insert(chunk_start, fresh);
            }
        }
        let local_offset = offset - chunk_start;
        let end = local_offset.saturating_add(len);
        let cache = self.cache.lock().unwrap();
        let entry = cache
            .map
            .get(&chunk_start)
            .ok_or_else(|| BackendError::buffer("missing cached chunk"))?;
        if end > entry.len() {
            return Err(BackendError::buffer("chunk slice out of bounds"));
        }
        // SAFETY: The chunk is retained in the cache (owned by self) until it is evicted.
        // Callers access the slice immediately in the same thread before another cache miss
        // can evict it, keeping the pointer valid for the duration of use.
        let ptr = unsafe { entry.as_ptr().add(local_offset) };
        let data = unsafe { std::slice::from_raw_parts(ptr, len) };
        Ok(ConstChunk { data })
    }
}

/// Streaming provider that produces chunks via a user-supplied fetch function (e.g., decompression).
pub struct StreamingConstProvider<F>
where
    F: Fn(usize, usize) -> BackendResult<Vec<u8>> + Send + Sync + 'static,
{
    len: usize,
    chunk_size: usize,
    cache: Mutex<ChunkCache>,
    fetch: Arc<F>,
}

impl<F> StreamingConstProvider<F>
where
    F: Fn(usize, usize) -> BackendResult<Vec<u8>> + Send + Sync + 'static,
{
    /// Create a streaming provider with bounded cache.
    pub fn new(len: usize, chunk_size: usize, max_cached_bytes: usize, fetch: F) -> Self {
        let chunk = chunk_size.max(4096);
        let cache_cap = max_cached_bytes.max(chunk);
        Self {
            len,
            chunk_size: chunk,
            cache: Mutex::new(ChunkCache::new(cache_cap)),
            fetch: Arc::new(fetch),
        }
    }

    fn read_chunk(&self, chunk_start: usize) -> BackendResult<Arc<Vec<u8>>> {
        let remaining = self.len.saturating_sub(chunk_start);
        if remaining == 0 {
            return Err(BackendError::buffer("offset past end of streaming source"));
        }
        let want = remaining.min(self.chunk_size);
        let buf = (self.fetch)(chunk_start, want)?;
        if buf.len() > self.chunk_size {
            return Err(BackendError::buffer(format!(
                "StreamingConstProvider chunk too large: {} > {}",
                buf.len(),
                self.chunk_size
            )));
        }
        Ok(Arc::new(buf))
    }

    /// Total cached bytes (for tests).
    #[cfg(test)]
    pub fn cached_bytes(&self) -> usize {
        self.cache.lock().unwrap().bytes
    }
}

impl<F> ConstProvider for StreamingConstProvider<F>
where
    F: Fn(usize, usize) -> BackendResult<Vec<u8>> + Send + Sync + 'static,
{
    fn len(&self) -> usize {
        self.len
    }

    fn read_at<'a>(&'a self, offset: usize, len: usize) -> BackendResult<ConstChunk<'a>> {
        if len > self.chunk_size {
            return Err(BackendError::buffer(format!(
                "StreamingConstProvider request too large: {} > chunk_size {}",
                len, self.chunk_size
            )));
        }
        let chunk_start = (offset / self.chunk_size) * self.chunk_size;
        if chunk_start >= self.len {
            return Err(BackendError::buffer("offset past end of stream"));
        }
        {
            let mut cache = self.cache.lock().unwrap();
            if cache.get(&chunk_start).is_none() {
                drop(cache);
                let fresh = self.read_chunk(chunk_start)?;
                let mut cache = self.cache.lock().unwrap();
                cache.insert(chunk_start, fresh);
            }
        }
        let cache = self.cache.lock().unwrap();
        let entry = cache
            .map
            .get(&chunk_start)
            .ok_or_else(|| BackendError::buffer("missing cached chunk"))?;
        let local_offset = offset - chunk_start;
        let end = local_offset.saturating_add(len);
        if end > entry.len() {
            return Err(BackendError::buffer("chunk slice out of bounds"));
        }
        // SAFETY: The chunk is retained in the cache (owned by self) until it is evicted.
        // Callers access the slice immediately in the same thread before another cache miss
        // can evict it, keeping the pointer valid for the duration of use.
        let ptr = unsafe { entry.as_ptr().add(local_offset) };
        let data = unsafe { std::slice::from_raw_parts(ptr, len) };
        Ok(ConstChunk { data })
    }
}
