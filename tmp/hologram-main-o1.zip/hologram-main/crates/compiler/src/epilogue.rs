//! Epilogue chain fusion (Stage 7).
//!
//! This module fuses post-operations (bias addition, activation, scaling)
//! into kernel writeback phase. Instead of separate memory passes for each
//! operation, the kernel applies them all during its final write.
//!
//! Epilogue pattern: `MatMul -> [Bias Add] -> [Activation] -> [Scale]`
//!
//! Each component is optional. The fused epilogue chain is stored on the
//! `MatMul` node and the intermediate operations are marked for removal.

use crate::graph::{CompileGraph, OpKind};

/// Fuse post-operations (bias, activation, scaling) into kernel writeback.
///
/// This function scans for fusable epilogue patterns:
/// 1. `MatMul` followed by bias addition (Add where one input is Constant)
/// 2. The result followed by activation function
/// 3. The result followed by scaling (Mul where one input is Constant)
///
/// Fused operations are recorded in the `MatMul` node's `epilogue` field
/// so the kernel can apply them during writeback.
pub fn fuse_epilogues(graph: &mut CompileGraph) {
    let node_ids: Vec<u32> = graph.nodes().map(|(id, _)| id).collect();

    for id in node_ids {
        let Some(node) = graph.get_node(id) else {
            continue;
        };

        // Only fuse epilogues for `MatMul` operations
        if !matches!(node.op, OpKind::MatMul { .. }) {
            continue;
        }

        // Try to build epilogue chain starting from this `MatMul`
        let chain = build_epilogue_chain(graph, id);

        // Apply the chain to the `MatMul` node
        if !chain.is_empty() {
            apply_epilogue_chain(graph, id, &chain);
        }
    }
}

/// Information about an epilogue chain being built.
#[derive(Debug, Default)]
struct EpilogueChainInfo {
    /// Bias add node ID (Add with Constant input).
    bias_add: Option<u32>,
    /// Activation node ID.
    activation: Option<u32>,
    /// Scale node ID (Mul with Constant input).
    scale: Option<u32>,
    /// Final output node of the chain (used to rewire successors).
    final_node: Option<u32>,
}

impl EpilogueChainInfo {
    fn is_empty(&self) -> bool {
        self.bias_add.is_none() && self.activation.is_none() && self.scale.is_none()
    }
}

/// Build an epilogue chain starting from a `MatMul` node.
///
/// Scans successors in order: bias -> activation -> scale
fn build_epilogue_chain(graph: &CompileGraph, matmul_id: u32) -> EpilogueChainInfo {
    let mut chain = EpilogueChainInfo::default();
    let mut current_id = matmul_id;

    // Step 1: Check for bias addition
    if let Some(bias_id) = find_bias_add(graph, current_id) {
        chain.bias_add = Some(bias_id);
        chain.final_node = Some(bias_id);
        current_id = bias_id;
    }

    // Step 2: Check for activation
    if let Some(activation_id) = find_activation(graph, current_id) {
        chain.activation = Some(activation_id);
        chain.final_node = Some(activation_id);
        current_id = activation_id;
    }

    // Step 3: Check for scaling
    if let Some(scale_id) = find_scale(graph, current_id) {
        chain.scale = Some(scale_id);
        chain.final_node = Some(scale_id);
    }

    chain
}

/// Find a bias addition successor of the given node.
///
/// Returns the Add node ID if:
/// - There's exactly one successor
/// - The successor is an Add operation
/// - One of the Add's inputs is a Constant (the bias)
/// - The Add's successor chain is epilogue-compatible (activation, scale, or output)
///
/// Note: We check successor compatibility to avoid fusing Add operations that feed
/// into non-epilogue operations like Softmax (e.g., attention masking).
fn find_bias_add(graph: &CompileGraph, node_id: u32) -> Option<u32> {
    let successors = graph.successors(node_id);
    if successors.len() != 1 {
        return None;
    }

    let succ_id = successors[0];
    let succ = graph.get_node(succ_id)?;

    if !matches!(succ.op, OpKind::Add) {
        return None;
    }

    // Check if one of the Add's predecessors is a Constant (bias)
    let preds = graph.predecessors(succ_id);
    let has_constant_input = preds.iter().any(|&pred_id| graph.is_constant(pred_id));

    if !has_constant_input {
        return None;
    }

    // Check if the Add's successors are epilogue-compatible
    // (activation, scale with constant, or output). If not, we shouldn't fuse.
    let add_successors = graph.successors(succ_id);
    if add_successors.is_empty() {
        return None;
    }

    let all_successors_epilogue_compatible = add_successors.iter().all(|&add_succ_id| {
        let Some(add_succ) = graph.get_node(add_succ_id) else {
            return false;
        };
        // Check if successor is an activation, or Output, or Mul with constant (scale)
        add_succ.op.is_activation()
            || matches!(add_succ.op, OpKind::Output)
            || (matches!(add_succ.op, OpKind::Mul)
                && graph
                    .predecessors(add_succ_id)
                    .iter()
                    .any(|&p| graph.is_constant(p)))
    });

    if all_successors_epilogue_compatible {
        Some(succ_id)
    } else {
        None
    }
}

/// Find an activation successor of the given node.
///
/// Returns the activation node ID if:
/// - There's exactly one successor
/// - The successor is an activation function (Relu, Sigmoid, Tanh, Gelu, Silu)
fn find_activation(graph: &CompileGraph, node_id: u32) -> Option<u32> {
    let successors = graph.successors(node_id);
    if successors.len() != 1 {
        return None;
    }

    let succ_id = successors[0];
    let succ = graph.get_node(succ_id)?;

    if succ.op.is_activation() {
        Some(succ_id)
    } else {
        None
    }
}

/// Find a scaling successor of the given node.
///
/// Returns the Mul node ID if:
/// - There's exactly one successor
/// - The successor is a Mul operation
/// - One of the Mul's inputs is a Constant (the scale factor)
fn find_scale(graph: &CompileGraph, node_id: u32) -> Option<u32> {
    let successors = graph.successors(node_id);
    if successors.len() != 1 {
        return None;
    }

    let succ_id = successors[0];
    let succ = graph.get_node(succ_id)?;

    if !matches!(succ.op, OpKind::Mul) {
        return None;
    }

    // Check if one of the Mul's predecessors is a Constant (scale)
    let preds = graph.predecessors(succ_id);
    let has_constant_input = preds.iter().any(|&pred_id| graph.is_constant(pred_id));

    if has_constant_input {
        Some(succ_id)
    } else {
        None
    }
}

/// Apply an epilogue chain to a `MatMul` node.
///
/// Records the fused operations in the `MatMul`'s epilogue field
/// and rewires the graph to skip intermediate nodes.
fn apply_epilogue_chain(graph: &mut CompileGraph, matmul_id: u32, chain: &EpilogueChainInfo) {
    // Update the `MatMul` node's epilogue field
    if let Some(node) = graph.get_node_mut(matmul_id) {
        node.epilogue.bias_add = chain.bias_add;
        node.epilogue.activation = chain.activation;
        node.epilogue.scale = chain.scale;
    }

    // Rewire successors of the final fused node to point to the `MatMul`
    // This allows the `MatMul` kernel to write directly to the final destination
    if let Some(final_id) = chain.final_node {
        // Get successors of the final node before rewiring
        let final_successors = graph.successors(final_id);

        // For each successor of the final fused node, replace its
        // predecessor reference from final_id to matmul_id
        for succ_id in final_successors {
            graph.replace_predecessor(succ_id, final_id, matmul_id);
        }
    }
}

/// Count epilogue operations fused in the graph.
#[must_use]
pub fn count_fused_epilogues(graph: &CompileGraph) -> usize {
    graph
        .nodes()
        .filter(|(_, node)| !node.epilogue.is_empty())
        .count()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpNode, OperationGraph};

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    #[test]
    fn test_fuse_epilogues_empty_graph() {
        let mut graph = make_graph(vec![], vec![]);
        fuse_epilogues(&mut graph);
        assert_eq!(count_fused_epilogues(&graph), 0);
    }

    #[test]
    fn test_fuse_epilogues_no_matmul() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        fuse_epilogues(&mut graph);
        assert_eq!(count_fused_epilogues(&graph), 0);
    }

    #[test]
    fn test_fuse_epilogues_matmul_with_bias() {
        // `MatMul` -> Add(Constant) -> Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Constant, vec![64, 64], DType::F32), // Bias
                OpNode::new(4, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(5, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 4), (3, 4), (4, 5)],
        );

        fuse_epilogues(&mut graph);

        // `MatMul` should have bias fused
        let matmul_node = graph.get_node(2).unwrap();
        assert_eq!(matmul_node.epilogue.bias_add, Some(4));
        assert_eq!(matmul_node.epilogue.activation, None);
        assert_eq!(matmul_node.epilogue.scale, None);

        assert_eq!(count_fused_epilogues(&graph), 1);
    }

    #[test]
    fn test_fuse_epilogues_matmul_with_activation() {
        // `MatMul` -> Relu -> Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(4, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3), (3, 4)],
        );

        fuse_epilogues(&mut graph);

        let matmul_node = graph.get_node(2).unwrap();
        assert_eq!(matmul_node.epilogue.bias_add, None);
        assert_eq!(matmul_node.epilogue.activation, Some(3));
        assert_eq!(matmul_node.epilogue.scale, None);
    }

    #[test]
    fn test_fuse_epilogues_matmul_with_bias_and_activation() {
        // `MatMul` -> Add(Constant) -> Relu -> Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Constant, vec![64, 64], DType::F32), // Bias
                OpNode::new(4, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(5, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(6, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 4), (3, 4), (4, 5), (5, 6)],
        );

        fuse_epilogues(&mut graph);

        let matmul_node = graph.get_node(2).unwrap();
        assert_eq!(matmul_node.epilogue.bias_add, Some(4));
        assert_eq!(matmul_node.epilogue.activation, Some(5));
        assert_eq!(matmul_node.epilogue.scale, None);
    }

    #[test]
    fn test_fuse_epilogues_full_chain() {
        // `MatMul` -> Add(Constant) -> Relu -> Mul(Constant) -> Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Constant, vec![64, 64], DType::F32), // Bias
                OpNode::new(4, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(5, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(6, OpKind::Constant, vec![64, 64], DType::F32), // Scale
                OpNode::new(7, OpKind::Mul, vec![64, 64], DType::F32),
                OpNode::new(8, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![
                (0, 2),
                (1, 2),
                (2, 4),
                (3, 4),
                (4, 5),
                (5, 7),
                (6, 7),
                (7, 8),
            ],
        );

        fuse_epilogues(&mut graph);

        let matmul_node = graph.get_node(2).unwrap();
        assert_eq!(matmul_node.epilogue.bias_add, Some(4));
        assert_eq!(matmul_node.epilogue.activation, Some(5));
        assert_eq!(matmul_node.epilogue.scale, Some(7));
    }

    #[test]
    fn test_fuse_epilogues_no_constant_bias() {
        // `MatMul` -> Add(non-constant) -> Output
        // Should NOT fuse because the Add input isn't a Constant
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Input, vec![64, 64], DType::F32), // Not a Constant
                OpNode::new(4, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(5, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 4), (3, 4), (4, 5)],
        );

        fuse_epilogues(&mut graph);

        // `MatMul` should still have activation fused but not bias
        let matmul_node = graph.get_node(2).unwrap();
        assert_eq!(matmul_node.epilogue.bias_add, None);
    }

    #[test]
    fn test_fuse_epilogues_multiple_successors() {
        // `MatMul` -> [Relu, Sigmoid] (forked)
        // Should NOT fuse because `MatMul` has multiple successors
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(4, OpKind::Sigmoid, vec![64, 64], DType::F32),
                OpNode::new(5, OpKind::Output, vec![64, 64], DType::F32),
                OpNode::new(6, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3), (2, 4), (3, 5), (4, 6)],
        );

        fuse_epilogues(&mut graph);

        let matmul_node = graph.get_node(2).unwrap();
        assert!(matmul_node.epilogue.is_empty());
    }

    #[test]
    fn test_fuse_epilogues_different_activations() {
        // Test each activation type can be fused
        for activation_op in [
            OpKind::Relu,
            OpKind::Sigmoid,
            OpKind::Tanh,
            OpKind::Gelu,
            OpKind::Silu,
        ] {
            let mut graph = make_graph(
                vec![
                    OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                    OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                    OpNode::new(
                        2,
                        OpKind::MatMul {
                            m: 64,
                            k: 64,
                            n: 64,
                        },
                        vec![64, 64],
                        DType::F32,
                    ),
                    OpNode::new(3, activation_op.clone(), vec![64, 64], DType::F32),
                    OpNode::new(4, OpKind::Output, vec![64, 64], DType::F32),
                ],
                vec![(0, 2), (1, 2), (2, 3), (3, 4)],
            );

            fuse_epilogues(&mut graph);

            let matmul_node = graph.get_node(2).unwrap();
            assert_eq!(matmul_node.epilogue.activation, Some(3));
        }
    }

    #[test]
    fn test_fuse_epilogues_scale_only() {
        // `MatMul` -> Mul(Constant) -> Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Constant, vec![64, 64], DType::F32), // Scale
                OpNode::new(4, OpKind::Mul, vec![64, 64], DType::F32),
                OpNode::new(5, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 4), (3, 4), (4, 5)],
        );

        fuse_epilogues(&mut graph);

        let matmul_node = graph.get_node(2).unwrap();
        assert_eq!(matmul_node.epilogue.bias_add, None);
        assert_eq!(matmul_node.epilogue.activation, None);
        assert_eq!(matmul_node.epilogue.scale, Some(4));
    }

    #[test]
    fn test_fuse_epilogues_multiple_matmuls() {
        // Two independent `MatMul` chains
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                // First `MatMul` chain
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Relu, vec![64, 64], DType::F32),
                // Second `MatMul` chain
                OpNode::new(
                    4,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(5, OpKind::Sigmoid, vec![64, 64], DType::F32),
                // Outputs
                OpNode::new(6, OpKind::Output, vec![64, 64], DType::F32),
                OpNode::new(7, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![
                (0, 2),
                (1, 2),
                (2, 3),
                (3, 6),
                (0, 4),
                (1, 4),
                (4, 5),
                (5, 7),
            ],
        );

        fuse_epilogues(&mut graph);

        // Both `MatMul`s should have their activations fused
        let matmul1 = graph.get_node(2).unwrap();
        assert_eq!(matmul1.epilogue.activation, Some(3));

        let matmul2 = graph.get_node(4).unwrap();
        assert_eq!(matmul2.epilogue.activation, Some(5));

        assert_eq!(count_fused_epilogues(&graph), 2);
    }

    #[test]
    fn test_is_activation() {
        assert!(OpKind::Relu.is_activation());
        assert!(OpKind::Sigmoid.is_activation());
        assert!(OpKind::Tanh.is_activation());
        assert!(OpKind::Gelu.is_activation());
        assert!(OpKind::Silu.is_activation());

        assert!(!OpKind::Add.is_activation());
        assert!(!OpKind::Mul.is_activation());
        assert!(!OpKind::Softmax { axis: -1 }.is_activation());
    }

    #[test]
    fn test_epilogue_chain_is_empty() {
        use crate::graph::EpilogueChain;

        let empty = EpilogueChain::default();
        assert!(empty.is_empty());

        let with_bias = EpilogueChain {
            bias_add: Some(1),
            activation: None,
            scale: None,
        };
        assert!(!with_bias.is_empty());

        let with_activation = EpilogueChain {
            bias_add: None,
            activation: Some(2),
            scale: None,
        };
        assert!(!with_activation.is_empty());

        let with_scale = EpilogueChain {
            bias_add: None,
            activation: None,
            scale: Some(3),
        };
        assert!(!with_scale.is_empty());
    }

    #[test]
    fn test_fuse_epilogues_matmul_standalone() {
        // `MatMul` with no epilogue-fusable successors
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        fuse_epilogues(&mut graph);

        let matmul_node = graph.get_node(2).unwrap();
        assert!(matmul_node.epilogue.is_empty());
        assert_eq!(count_fused_epilogues(&graph), 0);
    }
}
