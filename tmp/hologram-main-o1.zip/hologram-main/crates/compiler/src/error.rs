//! Compilation error types.

use thiserror::Error;

/// Errors that can occur during compilation.
#[derive(Error, Debug)]
pub enum CompileError {
    /// The operation graph contains a cycle.
    #[error("graph contains a cycle")]
    CycleDetected,

    /// Shape mismatch between connected operations.
    #[error("shape mismatch at node {node_id}: expected {expected:?}, got {actual:?}")]
    ShapeMismatch {
        /// Node where mismatch occurred.
        node_id: u32,
        /// Expected shape (from producer).
        expected: Vec<usize>,
        /// Actual shape (at consumer).
        actual: Vec<usize>,
    },

    /// Data type mismatch between connected operations.
    #[error("dtype mismatch at node {node_id}: expected {expected:?}, got {actual:?}")]
    DTypeMismatch {
        /// Node where mismatch occurred.
        node_id: u32,
        /// Expected dtype (from producer).
        expected: String,
        /// Actual dtype (at consumer).
        actual: String,
    },

    /// Invalid node reference.
    #[error("invalid node id: {0}")]
    InvalidNodeId(u32),

    /// Edge references a non-existent node.
    #[error("edge ({src}, {dst}) references invalid node")]
    InvalidEdge {
        /// Source node id.
        src: u32,
        /// Target node id.
        dst: u32,
    },

    /// Node has no inputs when required.
    #[error("node {node_id} ({op_name}) requires inputs but has none")]
    MissingInputs {
        /// Node id.
        node_id: u32,
        /// Operation name.
        op_name: String,
    },

    /// Input node has incoming edges.
    #[error("input node {node_id} should not have incoming edges")]
    InputHasEdges {
        /// Node id.
        node_id: u32,
    },

    /// Output node referenced does not exist.
    #[error("output '{name}' references non-existent node {node_id}")]
    InvalidOutput {
        /// Output name.
        name: String,
        /// Node id.
        node_id: u32,
    },

    /// Input node referenced does not exist.
    #[error("input '{name}' references non-existent node {node_id}")]
    InvalidInput {
        /// Input name.
        name: String,
        /// Node id.
        node_id: u32,
    },

    /// Duplicate node id in graph.
    #[error("duplicate node id: {0}")]
    DuplicateNodeId(u32),

    /// Unsupported operation for the target backend.
    #[error("unsupported operation: {0}")]
    UnsupportedOperation(String),

    /// No suitable kernel found for the operation.
    #[error("no kernel available for operation: {0}")]
    NoKernelAvailable(String),

    /// Node is unreachable from inputs.
    #[error("node {node_id} ({op_name}) is unreachable from inputs")]
    UnreachableFromInputs {
        /// Node id.
        node_id: u32,
        /// Operation name.
        op_name: String,
    },

    /// Node does not lead to any output.
    #[error("node {node_id} ({op_name}) does not contribute to any output")]
    DeadNode {
        /// Node id.
        node_id: u32,
        /// Operation name.
        op_name: String,
    },

    /// Buffer size does not match shape requirements.
    #[error("buffer size mismatch at node {node_id}: shape {shape:?} requires {expected} elements, buffer has {actual}")]
    BufferSizeMismatch {
        /// Node id.
        node_id: u32,
        /// Shape that was specified.
        shape: Vec<usize>,
        /// Expected number of elements.
        expected: usize,
        /// Actual number of elements.
        actual: usize,
    },

    /// Constant node missing data.
    #[error("constant node {node_id} has no associated constant data")]
    MissingConstantData {
        /// Node id.
        node_id: u32,
    },

    /// Internal compiler error.
    #[error("internal error: {0}")]
    Internal(String),
}

impl CompileError {
    /// Get actionable help text for this error.
    ///
    /// Returns guidance on how to resolve or investigate the error.
    #[must_use]
    pub fn help(&self) -> Option<&'static str> {
        match self {
            Self::CycleDetected => Some(
                "The operation graph contains a cycle which prevents topological ordering. \
                 Check for circular dependencies between operations.",
            ),
            Self::ShapeMismatch { .. } => Some(
                "Tensor shapes must match between connected operations. \
                 Verify that producer output shape matches consumer input expectations.",
            ),
            Self::DTypeMismatch { .. } => Some(
                "Data types must be compatible between connected operations. \
                 Add explicit type conversion if needed.",
            ),
            Self::InvalidNodeId(_) => Some(
                "The referenced node does not exist in the graph. \
                 Check that all node references are valid.",
            ),
            Self::InvalidEdge { .. } => Some(
                "An edge references a node that doesn't exist. \
                 Ensure nodes are added before edges that reference them.",
            ),
            Self::MissingInputs { .. } => Some(
                "This operation requires input connections. \
                 Add edges from producer nodes to this consumer.",
            ),
            Self::InputHasEdges { .. } => Some(
                "Input nodes should not have incoming edges from other nodes. \
                 Input nodes are data entry points to the graph.",
            ),
            Self::InvalidOutput { .. } | Self::InvalidInput { .. } => Some(
                "The named input/output references a non-existent node. \
                 Update the reference to point to a valid node.",
            ),
            Self::DuplicateNodeId(_) => {
                Some("Each node must have a unique ID. Use a different ID for the new node.")
            }
            Self::UnsupportedOperation(_) | Self::NoKernelAvailable(_) => Some(
                "This operation is not supported on the target backend. \
                 Try a different backend or decompose into supported primitives.",
            ),
            Self::UnreachableFromInputs { .. } => Some(
                "This node cannot be reached from any input node. \
                 Add edges connecting it to the input path or remove the node.",
            ),
            Self::DeadNode { .. } => Some(
                "This node's output is never used. \
                 Connect it to downstream operations or remove it.",
            ),
            Self::BufferSizeMismatch { .. } => Some(
                "The buffer size doesn't match the tensor dimensions. \
                 Ensure buffer allocation matches shape requirements.",
            ),
            Self::MissingConstantData { .. } => Some(
                "Constant nodes must have associated data. \
                 Set the constant data before compilation.",
            ),
            Self::Internal(_) => None,
        }
    }

    /// Check if this error indicates a graph structure problem.
    #[must_use]
    pub fn is_graph_error(&self) -> bool {
        matches!(
            self,
            Self::CycleDetected
                | Self::InvalidNodeId(_)
                | Self::InvalidEdge { .. }
                | Self::DuplicateNodeId(_)
                | Self::InvalidOutput { .. }
                | Self::InvalidInput { .. }
                | Self::InputHasEdges { .. }
                | Self::MissingInputs { .. }
                | Self::UnreachableFromInputs { .. }
                | Self::DeadNode { .. }
        )
    }

    /// Check if this error indicates a type/shape problem.
    #[must_use]
    pub fn is_type_error(&self) -> bool {
        matches!(
            self,
            Self::ShapeMismatch { .. }
                | Self::DTypeMismatch { .. }
                | Self::BufferSizeMismatch { .. }
        )
    }

    /// Check if this error indicates a backend capability problem.
    #[must_use]
    pub fn is_backend_error(&self) -> bool {
        matches!(
            self,
            Self::UnsupportedOperation(_) | Self::NoKernelAvailable(_)
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // ========================================================================
    // Error Construction Tests (TASK-183)
    // ========================================================================

    #[test]
    fn test_cycle_detected_construction() {
        let err = CompileError::CycleDetected;
        assert!(matches!(err, CompileError::CycleDetected));
    }

    #[test]
    fn test_shape_mismatch_construction() {
        let err = CompileError::ShapeMismatch {
            node_id: 5,
            expected: vec![1, 64, 32, 32],
            actual: vec![1, 64, 16, 16],
        };
        assert!(matches!(
            err,
            CompileError::ShapeMismatch { node_id: 5, .. }
        ));
    }

    #[test]
    fn test_dtype_mismatch_construction() {
        let err = CompileError::DTypeMismatch {
            node_id: 3,
            expected: "f32".to_string(),
            actual: "i32".to_string(),
        };
        assert!(matches!(
            err,
            CompileError::DTypeMismatch { node_id: 3, .. }
        ));
    }

    #[test]
    fn test_invalid_node_id_construction() {
        let err = CompileError::InvalidNodeId(42);
        assert!(matches!(err, CompileError::InvalidNodeId(42)));
    }

    #[test]
    fn test_invalid_edge_construction() {
        let err = CompileError::InvalidEdge { src: 1, dst: 99 };
        assert!(matches!(err, CompileError::InvalidEdge { src: 1, dst: 99 }));
    }

    #[test]
    fn test_missing_inputs_construction() {
        let err = CompileError::MissingInputs {
            node_id: 7,
            op_name: "MatMul".to_string(),
        };
        assert!(matches!(
            err,
            CompileError::MissingInputs { node_id: 7, .. }
        ));
    }

    #[test]
    fn test_input_has_edges_construction() {
        let err = CompileError::InputHasEdges { node_id: 0 };
        assert!(matches!(err, CompileError::InputHasEdges { node_id: 0 }));
    }

    #[test]
    fn test_invalid_output_construction() {
        let err = CompileError::InvalidOutput {
            name: "predictions".to_string(),
            node_id: 100,
        };
        assert!(matches!(
            err,
            CompileError::InvalidOutput { node_id: 100, .. }
        ));
    }

    #[test]
    fn test_invalid_input_construction() {
        let err = CompileError::InvalidInput {
            name: "features".to_string(),
            node_id: 999,
        };
        assert!(matches!(
            err,
            CompileError::InvalidInput { node_id: 999, .. }
        ));
    }

    #[test]
    fn test_duplicate_node_id_construction() {
        let err = CompileError::DuplicateNodeId(5);
        assert!(matches!(err, CompileError::DuplicateNodeId(5)));
    }

    #[test]
    fn test_unsupported_operation_construction() {
        let err = CompileError::UnsupportedOperation("GroupNorm".to_string());
        assert!(matches!(err, CompileError::UnsupportedOperation(_)));
    }

    #[test]
    fn test_no_kernel_available_construction() {
        let err = CompileError::NoKernelAvailable("Conv3d".to_string());
        assert!(matches!(err, CompileError::NoKernelAvailable(_)));
    }

    #[test]
    fn test_unreachable_from_inputs_construction() {
        let err = CompileError::UnreachableFromInputs {
            node_id: 15,
            op_name: "BatchNorm".to_string(),
        };
        assert!(matches!(
            err,
            CompileError::UnreachableFromInputs { node_id: 15, .. }
        ));
    }

    #[test]
    fn test_dead_node_construction() {
        let err = CompileError::DeadNode {
            node_id: 8,
            op_name: "Dropout".to_string(),
        };
        assert!(matches!(err, CompileError::DeadNode { node_id: 8, .. }));
    }

    #[test]
    fn test_buffer_size_mismatch_construction() {
        let err = CompileError::BufferSizeMismatch {
            node_id: 2,
            shape: vec![1, 3, 224, 224],
            expected: 150_528,
            actual: 100_000,
        };
        assert!(matches!(
            err,
            CompileError::BufferSizeMismatch {
                node_id: 2,
                expected: 150_528,
                actual: 100_000,
                ..
            }
        ));
    }

    #[test]
    fn test_missing_constant_data_construction() {
        let err = CompileError::MissingConstantData { node_id: 10 };
        assert!(matches!(
            err,
            CompileError::MissingConstantData { node_id: 10 }
        ));
    }

    #[test]
    fn test_internal_error_construction() {
        let err = CompileError::Internal("unexpected state".to_string());
        assert!(matches!(err, CompileError::Internal(_)));
    }

    // ========================================================================
    // Error Display Tests (TASK-183)
    // ========================================================================

    #[test]
    fn test_cycle_detected_display() {
        let err = CompileError::CycleDetected;
        let msg = err.to_string();
        assert!(msg.contains("cycle"));
    }

    #[test]
    fn test_shape_mismatch_display() {
        let err = CompileError::ShapeMismatch {
            node_id: 5,
            expected: vec![1, 64, 32, 32],
            actual: vec![1, 64, 16, 16],
        };
        let msg = err.to_string();
        assert!(msg.contains("shape mismatch"));
        assert!(msg.contains("node 5"));
        assert!(msg.contains("[1, 64, 32, 32]"));
        assert!(msg.contains("[1, 64, 16, 16]"));
    }

    #[test]
    fn test_dtype_mismatch_display() {
        let err = CompileError::DTypeMismatch {
            node_id: 3,
            expected: "f32".to_string(),
            actual: "i32".to_string(),
        };
        let msg = err.to_string();
        assert!(msg.contains("dtype mismatch"));
        assert!(msg.contains("node 3"));
        assert!(msg.contains("f32"));
        assert!(msg.contains("i32"));
    }

    #[test]
    fn test_invalid_node_id_display() {
        let err = CompileError::InvalidNodeId(42);
        let msg = err.to_string();
        assert!(msg.contains("invalid node id"));
        assert!(msg.contains("42"));
    }

    #[test]
    fn test_invalid_edge_display() {
        let err = CompileError::InvalidEdge { src: 1, dst: 99 };
        let msg = err.to_string();
        assert!(msg.contains("edge"));
        assert!(msg.contains('1'));
        assert!(msg.contains("99"));
        assert!(msg.contains("invalid"));
    }

    #[test]
    fn test_missing_inputs_display() {
        let err = CompileError::MissingInputs {
            node_id: 7,
            op_name: "MatMul".to_string(),
        };
        let msg = err.to_string();
        assert!(msg.contains("node 7"));
        assert!(msg.contains("MatMul"));
        assert!(msg.contains("inputs"));
    }

    #[test]
    fn test_input_has_edges_display() {
        let err = CompileError::InputHasEdges { node_id: 0 };
        let msg = err.to_string();
        assert!(msg.contains("input node"));
        assert!(msg.contains('0'));
        assert!(msg.contains("edges"));
    }

    #[test]
    fn test_invalid_output_display() {
        let err = CompileError::InvalidOutput {
            name: "predictions".to_string(),
            node_id: 100,
        };
        let msg = err.to_string();
        assert!(msg.contains("output"));
        assert!(msg.contains("predictions"));
        assert!(msg.contains("100"));
    }

    #[test]
    fn test_invalid_input_display() {
        let err = CompileError::InvalidInput {
            name: "features".to_string(),
            node_id: 999,
        };
        let msg = err.to_string();
        assert!(msg.contains("input"));
        assert!(msg.contains("features"));
        assert!(msg.contains("999"));
    }

    #[test]
    fn test_duplicate_node_id_display() {
        let err = CompileError::DuplicateNodeId(5);
        let msg = err.to_string();
        assert!(msg.contains("duplicate"));
        assert!(msg.contains('5'));
    }

    #[test]
    fn test_unsupported_operation_display() {
        let err = CompileError::UnsupportedOperation("GroupNorm".to_string());
        let msg = err.to_string();
        assert!(msg.contains("unsupported"));
        assert!(msg.contains("GroupNorm"));
    }

    #[test]
    fn test_no_kernel_available_display() {
        let err = CompileError::NoKernelAvailable("Conv3d".to_string());
        let msg = err.to_string();
        assert!(msg.contains("no kernel"));
        assert!(msg.contains("Conv3d"));
    }

    #[test]
    fn test_unreachable_from_inputs_display() {
        let err = CompileError::UnreachableFromInputs {
            node_id: 15,
            op_name: "BatchNorm".to_string(),
        };
        let msg = err.to_string();
        assert!(msg.contains("unreachable"));
        assert!(msg.contains("15"));
        assert!(msg.contains("BatchNorm"));
    }

    #[test]
    fn test_dead_node_display() {
        let err = CompileError::DeadNode {
            node_id: 8,
            op_name: "Dropout".to_string(),
        };
        let msg = err.to_string();
        assert!(msg.contains("node 8"));
        assert!(msg.contains("Dropout"));
        assert!(msg.contains("output"));
    }

    #[test]
    fn test_buffer_size_mismatch_display() {
        let err = CompileError::BufferSizeMismatch {
            node_id: 2,
            shape: vec![1, 3, 224, 224],
            expected: 150_528,
            actual: 100_000,
        };
        let msg = err.to_string();
        assert!(msg.contains("buffer size mismatch"));
        assert!(msg.contains("node 2"));
        assert!(msg.contains("150528"));
        assert!(msg.contains("100000"));
    }

    #[test]
    fn test_missing_constant_data_display() {
        let err = CompileError::MissingConstantData { node_id: 10 };
        let msg = err.to_string();
        assert!(msg.contains("constant node"));
        assert!(msg.contains("10"));
        assert!(msg.contains("no associated"));
    }

    #[test]
    fn test_internal_error_display() {
        let err = CompileError::Internal("unexpected state".to_string());
        let msg = err.to_string();
        assert!(msg.contains("internal error"));
        assert!(msg.contains("unexpected state"));
    }

    // ========================================================================
    // Error Debug Format Tests (TASK-183)
    // ========================================================================

    #[test]
    fn test_all_errors_have_debug_format() {
        let errors: Vec<CompileError> = vec![
            CompileError::CycleDetected,
            CompileError::ShapeMismatch {
                node_id: 0,
                expected: vec![],
                actual: vec![],
            },
            CompileError::DTypeMismatch {
                node_id: 0,
                expected: String::new(),
                actual: String::new(),
            },
            CompileError::InvalidNodeId(0),
            CompileError::InvalidEdge { src: 0, dst: 0 },
            CompileError::MissingInputs {
                node_id: 0,
                op_name: String::new(),
            },
            CompileError::InputHasEdges { node_id: 0 },
            CompileError::InvalidOutput {
                name: String::new(),
                node_id: 0,
            },
            CompileError::InvalidInput {
                name: String::new(),
                node_id: 0,
            },
            CompileError::DuplicateNodeId(0),
            CompileError::UnsupportedOperation(String::new()),
            CompileError::NoKernelAvailable(String::new()),
            CompileError::UnreachableFromInputs {
                node_id: 0,
                op_name: String::new(),
            },
            CompileError::DeadNode {
                node_id: 0,
                op_name: String::new(),
            },
            CompileError::BufferSizeMismatch {
                node_id: 0,
                shape: vec![],
                expected: 0,
                actual: 0,
            },
            CompileError::MissingConstantData { node_id: 0 },
            CompileError::Internal(String::new()),
        ];

        for err in errors {
            let debug_str = format!("{err:?}");
            assert!(!debug_str.is_empty());
        }
    }

    #[test]
    fn test_error_is_std_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}

        let err = CompileError::CycleDetected;
        assert_error(&err);
    }

    // ========================================================================
    // Help Text Tests (TASK-183)
    // ========================================================================

    #[test]
    fn test_help_cycle_detected() {
        let err = CompileError::CycleDetected;
        let help = err.help();
        assert!(help.is_some());
        assert!(help.unwrap().contains("cycle"));
    }

    #[test]
    fn test_help_shape_mismatch() {
        let err = CompileError::ShapeMismatch {
            node_id: 0,
            expected: vec![],
            actual: vec![],
        };
        assert!(err.help().is_some());
        assert!(err.help().unwrap().contains("shape"));
    }

    #[test]
    fn test_help_dtype_mismatch() {
        let err = CompileError::DTypeMismatch {
            node_id: 0,
            expected: String::new(),
            actual: String::new(),
        };
        assert!(err.help().is_some());
        assert!(err.help().unwrap().contains("type"));
    }

    #[test]
    fn test_help_invalid_node_id() {
        let err = CompileError::InvalidNodeId(0);
        assert!(err.help().is_some());
    }

    #[test]
    fn test_help_invalid_edge() {
        let err = CompileError::InvalidEdge { src: 0, dst: 0 };
        assert!(err.help().is_some());
    }

    #[test]
    fn test_help_missing_inputs() {
        let err = CompileError::MissingInputs {
            node_id: 0,
            op_name: String::new(),
        };
        assert!(err.help().is_some());
    }

    #[test]
    fn test_help_internal_none() {
        let err = CompileError::Internal("bug".to_string());
        assert!(err.help().is_none());
    }

    #[test]
    fn test_help_all_variants_except_internal() {
        let errors_with_help: Vec<CompileError> = vec![
            CompileError::CycleDetected,
            CompileError::ShapeMismatch {
                node_id: 0,
                expected: vec![],
                actual: vec![],
            },
            CompileError::DTypeMismatch {
                node_id: 0,
                expected: String::new(),
                actual: String::new(),
            },
            CompileError::InvalidNodeId(0),
            CompileError::InvalidEdge { src: 0, dst: 0 },
            CompileError::MissingInputs {
                node_id: 0,
                op_name: String::new(),
            },
            CompileError::InputHasEdges { node_id: 0 },
            CompileError::InvalidOutput {
                name: String::new(),
                node_id: 0,
            },
            CompileError::InvalidInput {
                name: String::new(),
                node_id: 0,
            },
            CompileError::DuplicateNodeId(0),
            CompileError::UnsupportedOperation(String::new()),
            CompileError::NoKernelAvailable(String::new()),
            CompileError::UnreachableFromInputs {
                node_id: 0,
                op_name: String::new(),
            },
            CompileError::DeadNode {
                node_id: 0,
                op_name: String::new(),
            },
            CompileError::BufferSizeMismatch {
                node_id: 0,
                shape: vec![],
                expected: 0,
                actual: 0,
            },
            CompileError::MissingConstantData { node_id: 0 },
        ];

        for err in errors_with_help {
            assert!(err.help().is_some(), "Expected help for error: {err:?}");
        }
    }

    // ========================================================================
    // Error Classification Tests (TASK-183)
    // ========================================================================

    #[test]
    fn test_is_graph_error() {
        // Graph errors
        assert!(CompileError::CycleDetected.is_graph_error());
        assert!(CompileError::InvalidNodeId(0).is_graph_error());
        assert!(CompileError::InvalidEdge { src: 0, dst: 0 }.is_graph_error());
        assert!(CompileError::DuplicateNodeId(0).is_graph_error());
        assert!(CompileError::InvalidOutput {
            name: String::new(),
            node_id: 0
        }
        .is_graph_error());
        assert!(CompileError::InvalidInput {
            name: String::new(),
            node_id: 0
        }
        .is_graph_error());
        assert!(CompileError::InputHasEdges { node_id: 0 }.is_graph_error());
        assert!(CompileError::MissingInputs {
            node_id: 0,
            op_name: String::new()
        }
        .is_graph_error());
        assert!(CompileError::UnreachableFromInputs {
            node_id: 0,
            op_name: String::new()
        }
        .is_graph_error());
        assert!(CompileError::DeadNode {
            node_id: 0,
            op_name: String::new()
        }
        .is_graph_error());

        // Not graph errors
        assert!(!CompileError::ShapeMismatch {
            node_id: 0,
            expected: vec![],
            actual: vec![]
        }
        .is_graph_error());
        assert!(!CompileError::UnsupportedOperation(String::new()).is_graph_error());
        assert!(!CompileError::Internal(String::new()).is_graph_error());
    }

    #[test]
    fn test_is_type_error() {
        // Type errors
        assert!(CompileError::ShapeMismatch {
            node_id: 0,
            expected: vec![],
            actual: vec![]
        }
        .is_type_error());
        assert!(CompileError::DTypeMismatch {
            node_id: 0,
            expected: String::new(),
            actual: String::new()
        }
        .is_type_error());
        assert!(CompileError::BufferSizeMismatch {
            node_id: 0,
            shape: vec![],
            expected: 0,
            actual: 0
        }
        .is_type_error());

        // Not type errors
        assert!(!CompileError::CycleDetected.is_type_error());
        assert!(!CompileError::InvalidNodeId(0).is_type_error());
        assert!(!CompileError::UnsupportedOperation(String::new()).is_type_error());
    }

    #[test]
    fn test_is_backend_error() {
        // Backend errors
        assert!(CompileError::UnsupportedOperation(String::new()).is_backend_error());
        assert!(CompileError::NoKernelAvailable(String::new()).is_backend_error());

        // Not backend errors
        assert!(!CompileError::CycleDetected.is_backend_error());
        assert!(!CompileError::ShapeMismatch {
            node_id: 0,
            expected: vec![],
            actual: vec![]
        }
        .is_backend_error());
        assert!(!CompileError::Internal(String::new()).is_backend_error());
    }

    // ========================================================================
    // Edge Cases (TASK-183)
    // ========================================================================

    #[test]
    fn test_shape_mismatch_empty_shapes() {
        let err = CompileError::ShapeMismatch {
            node_id: 0,
            expected: vec![],
            actual: vec![],
        };
        let msg = err.to_string();
        assert!(msg.contains("[]"));
    }

    #[test]
    fn test_shape_mismatch_large_shape() {
        let err = CompileError::ShapeMismatch {
            node_id: u32::MAX,
            expected: vec![usize::MAX, usize::MAX],
            actual: vec![0, 0],
        };
        // Should not panic
        let msg = err.to_string();
        assert!(msg.contains("shape mismatch"));
    }

    #[test]
    fn test_invalid_node_id_max() {
        let err = CompileError::InvalidNodeId(u32::MAX);
        let msg = err.to_string();
        assert!(msg.contains(&u32::MAX.to_string()));
    }

    #[test]
    fn test_invalid_edge_same_node() {
        let err = CompileError::InvalidEdge { src: 5, dst: 5 };
        let msg = err.to_string();
        assert!(msg.contains('5'));
    }

    #[test]
    fn test_dtype_empty_strings() {
        let err = CompileError::DTypeMismatch {
            node_id: 0,
            expected: String::new(),
            actual: String::new(),
        };
        let msg = err.to_string();
        assert!(msg.contains("dtype mismatch"));
    }

    #[test]
    fn test_missing_inputs_empty_op_name() {
        let err = CompileError::MissingInputs {
            node_id: 0,
            op_name: String::new(),
        };
        let msg = err.to_string();
        assert!(msg.contains("requires inputs"));
    }

    #[test]
    fn test_buffer_size_mismatch_zero_values() {
        let err = CompileError::BufferSizeMismatch {
            node_id: 0,
            shape: vec![0, 0, 0],
            expected: 0,
            actual: 0,
        };
        let msg = err.to_string();
        assert!(msg.contains("buffer size mismatch"));
    }

    #[test]
    fn test_internal_empty_message() {
        let err = CompileError::Internal(String::new());
        let msg = err.to_string();
        assert!(msg.contains("internal error"));
    }

    #[test]
    fn test_output_with_unicode_name() {
        let err = CompileError::InvalidOutput {
            name: "预测结果".to_string(),
            node_id: 42,
        };
        let msg = err.to_string();
        assert!(msg.contains("预测结果"));
    }

    #[test]
    fn test_input_with_special_chars() {
        let err = CompileError::InvalidInput {
            name: "input/data:0".to_string(),
            node_id: 1,
        };
        let msg = err.to_string();
        assert!(msg.contains("input/data:0"));
    }
}
