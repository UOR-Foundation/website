//! Render functions for HTML views.

use crate::html::templates::base;
use crate::schema::{
    Constant, DomainDto, GaugeLevel, GaugeTower, ListResponse, SchemaInfo, TaxonDto,
};

/// Render home page.
pub fn render_home(schemas: &[SchemaInfo]) -> String {
    let schema_cards: String = schemas
        .iter()
        .map(|s| {
            format!(
                r#"<div class="card">
                <h3><a href="/schemas/{id}">{name}</a></h3>
                <p>{description}</p>
                <p><code>{count} entities</code></p>
            </div>"#,
                id = s.id,
                name = s.name,
                description = s.description,
                count = s.entity_count
            )
        })
        .collect();

    let content = format!(
        r#"<h1>UOR Schema Viewer</h1>
        <p>Browse and explore the Universal Object Reference schema definitions.</p>

        <h2>Available Schemas</h2>
        <div class="grid">{schema_cards}</div>

        <h2>Quick Links</h2>
        <div class="grid">
            <div class="card">
                <h3><a href="/taxons">Taxons</a></h3>
                <p>Browse all 256 taxons with Braille mappings</p>
            </div>
            <div class="card">
                <h3><a href="/constants">Constants</a></h3>
                <p>View mathematical constants and axioms</p>
            </div>
            <div class="card">
                <h3><a href="/gauge-tower">Gauge Tower</a></h3>
                <p>Explore the hierarchical addressing system</p>
            </div>
        </div>

        <h2>API</h2>
        <p>All endpoints also return JSON when accessed with <code>Accept: application/json</code>.</p>
        <table>
            <tr><th>Endpoint</th><th>Description</th></tr>
            <tr><td><code>GET /api/schemas</code></td><td>List all schemas</td></tr>
            <tr><td><code>GET /api/taxons</code></td><td>List all taxons</td></tr>
            <tr><td><code>GET /api/constants</code></td><td>List all constants</td></tr>
            <tr><td><code>PATCH /api/constants/:name</code></td><td>Mutate a constant</td></tr>
            <tr><td><code>POST /api/mutations/reset</code></td><td>Reset all mutations</td></tr>
        </table>"#,
        schema_cards = schema_cards
    );

    base("Home", &content)
}

/// Render schemas list.
pub fn render_schemas_list(schemas: &[SchemaInfo]) -> String {
    let rows: String = schemas
        .iter()
        .map(|s| {
            format!(
                r#"<tr>
                <td><a href="/schemas/{id}">{name}</a></td>
                <td>{description}</td>
                <td>{count}</td>
            </tr>"#,
                id = s.id,
                name = s.name,
                description = s.description,
                count = s.entity_count
            )
        })
        .collect();

    let content = format!(
        r#"<h1>Schemas</h1>
        <table>
            <tr><th>Name</th><th>Description</th><th>Entities</th></tr>
            {rows}
        </table>"#,
        rows = rows
    );

    base("Schemas", &content)
}

/// Render schema detail.
pub fn render_schema_detail(info: Option<&SchemaInfo>, schema: &serde_json::Value) -> String {
    let name = info.map(|i| i.name.as_str()).unwrap_or("Schema");
    let description = info.map(|i| i.description.as_str()).unwrap_or("");

    let json_preview = serde_json::to_string_pretty(schema)
        .unwrap_or_default()
        .chars()
        .take(2000)
        .collect::<String>();

    let content = format!(
        r#"<div class="breadcrumb"><a href="/schemas">Schemas</a> / {name}</div>
        <h1>{name}</h1>
        <p>{description}</p>
        <h2>Raw JSON</h2>
        <pre><code>{json}</code></pre>"#,
        name = name,
        description = description,
        json = html_escape(&json_preview)
    );

    base(name, &content)
}

/// Render taxons list with Braille grid.
pub fn render_taxons_list(response: &ListResponse<TaxonDto>) -> String {
    let grid_cells: String = response
        .items
        .iter()
        .map(|t| {
            let _domain_class = t.domain.to_lowercase();
            format!(
                r#"<a href="/taxons/{value}" class="braille-cell">
                <div class="char">{braille}</div>
                <div class="val">{value}</div>
            </a>"#,
                value = t.value,
                braille = t.braille,
            )
        })
        .collect();

    let content = format!(
        r#"<h1>Taxons</h1>
        <p>The 256 fundamental units of the UOR system, each mapped to a unique Braille character.</p>

        <h2>Braille Grid</h2>
        <div class="braille-grid">{grid}</div>

        <p style="margin-top: 1rem; color: #888;">
            Showing {shown} of {total} taxons.
            <a href="/api/taxons">View as JSON</a>
        </p>"#,
        grid = grid_cells,
        shown = response.items.len(),
        total = response.total
    );

    base("Taxons", &content)
}

/// Render single taxon detail.
pub fn render_taxon_detail(taxon: &TaxonDto) -> String {
    let domain_class = taxon.domain.to_lowercase();

    let content = format!(
        r#"<div class="breadcrumb"><a href="/taxons">Taxons</a> / {value}</div>
        <h1>Taxon {value}</h1>

        <div class="braille">{braille}</div>

        <div class="card">
            <div class="property">
                <span class="property-label">Value</span>
                <span class="property-value">{value}</span>
            </div>
            <div class="property">
                <span class="property-label">Codepoint</span>
                <span class="property-value">U+{codepoint:04X} ({codepoint})</span>
            </div>
            <div class="property">
                <span class="property-label">Braille</span>
                <span class="property-value">{braille}</span>
            </div>
            <div class="property">
                <span class="property-label">Domain</span>
                <span class="property-value">
                    <span class="tag {domain_class}">{domain}</span>
                </span>
            </div>
            <div class="property">
                <span class="property-label">Rank</span>
                <span class="property-value">{rank}</span>
            </div>
            <div class="property">
                <span class="property-label">IRI</span>
                <span class="property-value"><code>{iri}</code></span>
            </div>
        </div>

        <p>
            <a href="/taxons/{prev}">&larr; Previous</a> |
            <a href="/taxons/{next}">Next &rarr;</a>
        </p>"#,
        value = taxon.value,
        codepoint = taxon.codepoint,
        braille = taxon.braille,
        domain = taxon.domain,
        domain_class = domain_class,
        rank = taxon.rank,
        iri = taxon.iri,
        prev = taxon.value.saturating_sub(1),
        next = taxon.value.saturating_add(1)
    );

    base(&format!("Taxon {}", taxon.value), &content)
}

/// Render domains list.
pub fn render_domains_list(domains: &[DomainDto]) -> String {
    let cards: String = domains
        .iter()
        .map(|d| {
            let class = d.name.to_lowercase();
            format!(
                r#"<div class="card">
                <h3>
                    <span class="tag {class}">{symbol}</span>
                    <a href="/domains/{name}">{name}</a>
                </h3>
                <p>{description}</p>
                <p><code>Cardinality: {cardinality}</code></p>
            </div>"#,
                name = d.name,
                symbol = d.symbol,
                class = class,
                description = d.description,
                cardinality = d.cardinality
            )
        })
        .collect();

    let content = format!(
        r#"<h1>Domains</h1>
        <p>The triadic partition of taxons based on residue mod 3.</p>
        <div class="grid">{cards}</div>"#,
        cards = cards
    );

    base("Domains", &content)
}

/// Render domain detail.
pub fn render_domain_detail(domain: &DomainDto) -> String {
    let class = domain.name.to_lowercase();

    let content = format!(
        r#"<div class="breadcrumb"><a href="/domains">Domains</a> / {name}</div>
        <h1><span class="tag {class}">{symbol}</span> {name}</h1>
        <p>{description}</p>

        <div class="card">
            <div class="property">
                <span class="property-label">Residue</span>
                <span class="property-value">{residue} (value mod 3 == {residue})</span>
            </div>
            <div class="property">
                <span class="property-label">Symbol</span>
                <span class="property-value">{symbol}</span>
            </div>
            <div class="property">
                <span class="property-label">Cardinality</span>
                <span class="property-value">{cardinality} taxons</span>
            </div>
            <div class="property">
                <span class="property-label">IRI</span>
                <span class="property-value"><code>{id}</code></span>
            </div>
        </div>

        <p><a href="/api/taxons/by-domain/{name}">View taxons in this domain</a></p>"#,
        name = domain.name,
        symbol = domain.symbol,
        class = class,
        description = domain.description,
        residue = domain.residue,
        cardinality = domain.cardinality,
        id = domain.id
    );

    base(&domain.name, &content)
}

/// Render constants list.
pub fn render_constants_list(constants: &[Constant]) -> String {
    let rows: String = constants
        .iter()
        .map(|c| {
            let mutable = if c.is_mutable { "Yes" } else { "No" };
            let formula = c.formula.as_deref().unwrap_or("-");
            format!(
                r#"<tr>
                <td><a href="/constants/{name}">{symbol}</a></td>
                <td><code>{value}</code></td>
                <td>{formula}</td>
                <td>{description}</td>
                <td>{mutable}</td>
            </tr>"#,
                name = c.name,
                symbol = c.symbol,
                value = c.value,
                formula = formula,
                description = c.description,
                mutable = mutable
            )
        })
        .collect();

    let content = format!(
        r#"<h1>Constants</h1>
        <p>Mathematical constants and axioms that define the UOR system.</p>

        <table>
            <tr>
                <th>Symbol</th>
                <th>Value</th>
                <th>Formula</th>
                <th>Description</th>
                <th>Mutable</th>
            </tr>
            {rows}
        </table>

        <h2>Mutation API</h2>
        <p>Mutable constants can be changed via the API:</p>
        <pre><code>curl -X PATCH http://localhost:3000/api/constants/T \
  -H "Content-Type: application/json" \
  -d '{{"value": 4}}'</code></pre>
        <p>Reset all mutations: <code>POST /api/mutations/reset</code></p>"#,
        rows = rows
    );

    base("Constants", &content)
}

/// Render constant detail.
pub fn render_constant_detail(constant: &Constant) -> String {
    let formula = constant.formula.as_deref().unwrap_or("(fundamental axiom)");
    let derived: String = if constant.derived_from.is_empty() {
        "None (fundamental)".to_string()
    } else {
        constant.derived_from.join(", ")
    };
    let mutable = if constant.is_mutable {
        "Yes - can be mutated via API"
    } else {
        "No - fundamental axiom"
    };

    let content = format!(
        r#"<div class="breadcrumb"><a href="/constants">Constants</a> / {name}</div>
        <h1>{symbol} = {value}</h1>
        <p>{description}</p>

        <div class="card">
            <div class="property">
                <span class="property-label">Name</span>
                <span class="property-value">{name}</span>
            </div>
            <div class="property">
                <span class="property-label">Symbol</span>
                <span class="property-value">{symbol}</span>
            </div>
            <div class="property">
                <span class="property-label">Value</span>
                <span class="property-value"><code>{value}</code></span>
            </div>
            <div class="property">
                <span class="property-label">Formula</span>
                <span class="property-value">{formula}</span>
            </div>
            <div class="property">
                <span class="property-label">Derived From</span>
                <span class="property-value">{derived}</span>
            </div>
            <div class="property">
                <span class="property-label">Mutable</span>
                <span class="property-value">{mutable}</span>
            </div>
        </div>"#,
        name = constant.name,
        symbol = constant.symbol,
        value = constant.value,
        description = constant.description,
        formula = formula,
        derived = derived,
        mutable = mutable
    );

    base(&constant.name, &content)
}

/// Render gauge tower.
pub fn render_gauge_tower(tower: &GaugeTower) -> String {
    let rows: String = tower
        .levels
        .iter()
        .map(|l| {
            let primes: String = l
                .primes
                .iter()
                .map(|p| p.to_string())
                .collect::<Vec<_>>()
                .join(", ");
            format!(
                r#"<tr>
                <td><a href="/gauge-tower/levels/{index}">{index}</a></td>
                <td><code>{modulus}</code></td>
                <td><code>{boundary}</code></td>
                <td>[{primes}]</td>
                <td>{label}</td>
            </tr>"#,
                index = l.index,
                modulus = l.modulus,
                boundary = l.boundary,
                primes = primes,
                label = l.label
            )
        })
        .collect();

    let content = format!(
        r#"<h1>Gauge Tower</h1>
        <p>{description}</p>

        <table>
            <tr>
                <th>Level</th>
                <th>Modulus</th>
                <th>Boundary</th>
                <th>Primes</th>
                <th>Label</th>
            </tr>
            {rows}
        </table>

        <h2>Structure</h2>
        <p>Each level multiplies the previous modulus by the next prime,
        enabling O(1) byte addressing via the Chinese Remainder Theorem.</p>"#,
        description = tower.description,
        rows = rows
    );

    base("Gauge Tower", &content)
}

/// Render single gauge level.
pub fn render_gauge_level(level: &GaugeLevel) -> String {
    let primes: String = level
        .primes
        .iter()
        .map(|p| p.to_string())
        .collect::<Vec<_>>()
        .join(" × ");

    let content = format!(
        r#"<div class="breadcrumb"><a href="/gauge-tower">Gauge Tower</a> / Level {index}</div>
        <h1>Gauge Level {index}</h1>
        <p>{label}</p>

        <div class="card">
            <div class="property">
                <span class="property-label">Index</span>
                <span class="property-value">{index}</span>
            </div>
            <div class="property">
                <span class="property-label">Modulus</span>
                <span class="property-value"><code>{modulus}</code></span>
            </div>
            <div class="property">
                <span class="property-label">Boundary</span>
                <span class="property-value"><code>{boundary}</code> bytes</span>
            </div>
            <div class="property">
                <span class="property-label">Primes</span>
                <span class="property-value">{primes}</span>
            </div>
        </div>"#,
        index = level.index,
        label = level.label,
        modulus = level.modulus,
        boundary = level.boundary,
        primes = primes
    );

    base(&format!("Level {}", level.index), &content)
}

/// HTML-escape a string.
fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}
