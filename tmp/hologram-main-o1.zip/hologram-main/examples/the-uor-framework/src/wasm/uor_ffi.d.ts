/* tslint:disable */
/* eslint-disable */

/**
 * A cell address on the toroidal boundary (index in [0, 12287]).
 */
export class Cell {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Calculate the distance to another cell.
     */
    distanceTo(other: Cell): number;
    /**
     * Create a new cell with the given index.
     * The index wraps around at 12288 (BOUNDARY_SIZE).
     */
    constructor(index: number);
    /**
     * Get the next cell (wraps around).
     */
    next(): Cell;
    /**
     * Offset the cell by a signed delta.
     */
    offset(delta: number): Cell;
    /**
     * Get the previous cell (wraps around).
     */
    prev(): Cell;
    /**
     * The cell index (0-12287).
     */
    readonly index: number;
}

/**
 * Registry of available codecs.
 *
 * This is a placeholder - full codec support will be implemented later.
 */
export class CodecRegistry {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get a codec by name.
     *
     * Always returns None (placeholder).
     */
    getCodec(_name: string): FfiCodec | undefined;
    /**
     * List available codec names.
     *
     * Returns an empty array (placeholder).
     */
    listCodecs(): any[];
    /**
     * Create a new codec registry.
     */
    constructor();
}

/**
 * A codec for encoding/decoding data.
 *
 * This is a placeholder - full codec support will be implemented later.
 */
export class FfiCodec {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Decode data using this codec.
     *
     * Returns input unchanged (placeholder).
     */
    decode(data: Uint8Array): Uint8Array;
    /**
     * Encode data using this codec.
     *
     * Returns input unchanged (placeholder).
     */
    encode(data: Uint8Array): Uint8Array;
    /**
     * Get the codec name.
     */
    readonly name: string;
}

/**
 * Factory for creating mutation JSON strings for WASM.
 */
export class MutationFactory {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Create an Add mutation JSON string.
     */
    static add(cell: number, delta: number): string;
    /**
     * Create a BitwiseAnd mutation JSON string.
     */
    static bitwiseAnd(source: number, target: number): string;
    /**
     * Create a BitwiseNot mutation JSON string.
     */
    static bitwiseNot(cell: number): string;
    /**
     * Create a BitwiseOr mutation JSON string.
     */
    static bitwiseOr(source: number, target: number): string;
    /**
     * Create a BitwiseXor mutation JSON string.
     */
    static bitwiseXor(source: number, target: number): string;
    /**
     * Create a Fma mutation JSON string.
     */
    static fma(a: number, b: number, target: number): string;
    /**
     * Create an IndexedCopy mutation JSON string.
     */
    static indexedCopy(index_cell: number, source: number): string;
    /**
     * Create an IndexedWrite mutation JSON string.
     */
    static indexedWrite(index_cell: number, value: number): string;
    /**
     * Create an IndirectMulFrom mutation JSON string.
     */
    static indirectMulFrom(base_cell: number, offset: number, target: number): string;
    /**
     * Create an IndirectRead mutation JSON string.
     */
    static indirectRead(base_cell: number, offset: number, target: number): string;
    /**
     * Create a Mirror mutation JSON string.
     */
    static mirror(cell: number): string;
    /**
     * Create a Mul mutation JSON string.
     */
    static mul(cell: number, scalar: number): string;
    /**
     * Create a MulFrom mutation JSON string.
     */
    static mulFrom(source: number, target: number): string;
    /**
     * Create a Multiply mutation JSON string.
     */
    static multiply(cell: number, scalar: number): string;
    /**
     * Create a Set mutation JSON string.
     */
    static set(cell: number, value: number): string;
    /**
     * Create a ShiftLeft mutation JSON string.
     */
    static shiftLeft(cell: number, amount: number): string;
    /**
     * Create a ShiftRight mutation JSON string.
     */
    static shiftRight(cell: number, amount: number): string;
    /**
     * Create a Swap mutation JSON string.
     */
    static swap(cell1: number, cell2: number): string;
}

/**
 * A mod-96 residue value (value in [0, 95]).
 */
export class Res96 {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Add another Res96 value (mod 96).
     */
    add(other: Res96): Res96;
    /**
     * Check if this is a unit (has a multiplicative inverse).
     */
    isUnit(): boolean;
    /**
     * Multiply by another Res96 value (mod 96).
     */
    mul(other: Res96): Res96;
    /**
     * Negate the value (mod 96).
     */
    neg(): Res96;
    /**
     * Create a new Res96 value (automatically reduced mod 96).
     */
    constructor(value: number);
    /**
     * Subtract another Res96 value (mod 96).
     */
    sub(other: Res96): Res96;
    /**
     * Get the multiplicative inverse if it exists.
     */
    tryInverse(): Res96 | undefined;
    /**
     * The residue value (0-95).
     */
    readonly value: number;
    /**
     * The one value (multiplicative identity).
     */
    static readonly one: Res96;
    /**
     * The zero value.
     */
    static readonly zero: Res96;
}

/**
 * The 12,288-cell toroidal boundary execution substrate.
 */
export class ToroidalBoundary {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Apply a batch of mutations (JSON array string).
     */
    applyBatch(json: string): void;
    /**
     * Apply a single mutation (JSON string).
     */
    applyMutation(json: string): void;
    /**
     * Clear all cells to zero.
     */
    clear(): void;
    /**
     * Create a boundary from a Uint8Array.
     */
    static fromUint8Array(data: Uint8Array): ToroidalBoundary;
    /**
     * Get the value at a cell.
     */
    get(cell: Cell): Res96;
    /**
     * Create a new boundary with all cells set to a specific value.
     */
    static newFill(value: Res96): ToroidalBoundary;
    /**
     * Create a new boundary with all cells set to one.
     */
    static newOne(): ToroidalBoundary;
    /**
     * Create a new boundary with all cells set to zero.
     */
    static newZero(): ToroidalBoundary;
    /**
     * Set the value at a cell.
     */
    set(cell: Cell, value: Res96): void;
    /**
     * Calculate the signed budget (treating values > 47 as negative).
     */
    signedBudget(): bigint;
    /**
     * Convert to a Uint8Array.
     */
    toUint8Array(): Uint8Array;
    /**
     * Calculate the total budget (sum of all cell values).
     */
    totalBudget(): bigint;
    /**
     * Create a new boundary with all cells set to zero.
     */
    constructor();
}

export class WasmView {
    free(): void;
    [Symbol.dispose](): void;
    apply(byte_value: number): number;
    applySlice(input: Uint8Array): Uint8Array;
    static constant(value: number): WasmView;
    constructor();
    inverse(): WasmView;
    isBijective(): boolean;
    table(): Uint8Array;
    then(other: WasmView): WasmView;
}

export function braille_base(): number;

export function braille_max(): number;

/**
 * Initialize the WASM module.
 *
 * This sets up panic hooks for better error messages in the browser console.
 */
export function init(): void;

export function octave_constant(): number;

export function state_bits(): number;

export function state_taxons(): number;

export function triadic_constant(): number;

export function wasm_byte_not(value: number): number;

export function wasm_byte_pred(value: number): number;

export function wasm_byte_rank(value: number): number;

export function wasm_byte_succ(value: number): number;

export function wasm_byte_to_braille(value: number): string;

export function wasm_byte_to_codepoint(value: number): number;

export function wasm_byte_to_domain(value: number): number;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_mutationfactory_free: (a: number, b: number) => void;
    readonly mutationfactory_add: (a: number, b: number) => [number, number];
    readonly mutationfactory_bitwiseAnd: (a: number, b: number) => [number, number];
    readonly mutationfactory_bitwiseNot: (a: number) => [number, number];
    readonly mutationfactory_bitwiseOr: (a: number, b: number) => [number, number];
    readonly mutationfactory_bitwiseXor: (a: number, b: number) => [number, number];
    readonly mutationfactory_fma: (a: number, b: number, c: number) => [number, number];
    readonly mutationfactory_indexedCopy: (a: number, b: number) => [number, number];
    readonly mutationfactory_indexedWrite: (a: number, b: number) => [number, number];
    readonly mutationfactory_indirectMulFrom: (a: number, b: number, c: number) => [number, number];
    readonly mutationfactory_indirectRead: (a: number, b: number, c: number) => [number, number];
    readonly mutationfactory_mirror: (a: number) => [number, number];
    readonly mutationfactory_mul: (a: number, b: number) => [number, number];
    readonly mutationfactory_mulFrom: (a: number, b: number) => [number, number];
    readonly mutationfactory_multiply: (a: number, b: number) => [number, number];
    readonly mutationfactory_set: (a: number, b: number) => [number, number];
    readonly mutationfactory_shiftLeft: (a: number, b: number) => [number, number];
    readonly mutationfactory_shiftRight: (a: number, b: number) => [number, number];
    readonly mutationfactory_swap: (a: number, b: number) => [number, number];
    readonly __wbg_toroidalboundary_free: (a: number, b: number) => void;
    readonly toroidalboundary_applyBatch: (a: number, b: number, c: number) => [number, number];
    readonly toroidalboundary_applyMutation: (a: number, b: number, c: number) => [number, number];
    readonly toroidalboundary_clear: (a: number) => void;
    readonly toroidalboundary_fromUint8Array: (a: number, b: number) => [number, number, number];
    readonly toroidalboundary_get: (a: number, b: number) => number;
    readonly toroidalboundary_newFill: (a: number) => number;
    readonly toroidalboundary_newOne: () => number;
    readonly toroidalboundary_newZero: () => number;
    readonly toroidalboundary_set: (a: number, b: number, c: number) => void;
    readonly toroidalboundary_signedBudget: (a: number) => bigint;
    readonly toroidalboundary_toUint8Array: (a: number) => [number, number];
    readonly toroidalboundary_totalBudget: (a: number) => bigint;
    readonly toroidalboundary_wasm_new: () => number;
    readonly __wbg_codecregistry_free: (a: number, b: number) => void;
    readonly __wbg_fficodec_free: (a: number, b: number) => void;
    readonly codecregistry_getCodec: (a: number, b: number, c: number) => number;
    readonly codecregistry_listCodecs: (a: number) => [number, number];
    readonly fficodec_decode: (a: number, b: number, c: number) => [number, number];
    readonly fficodec_name: (a: number) => [number, number];
    readonly fficodec_encode: (a: number, b: number, c: number) => [number, number];
    readonly codecregistry_new: () => number;
    readonly uor_braille_base: () => number;
    readonly uor_braille_max: () => number;
    readonly uor_byte_not: (a: number) => number;
    readonly uor_byte_pred: (a: number) => number;
    readonly uor_byte_rank: (a: number) => number;
    readonly uor_byte_succ: (a: number) => number;
    readonly uor_byte_to_braille: (a: number) => number;
    readonly uor_byte_to_codepoint: (a: number) => number;
    readonly uor_byte_to_domain: (a: number) => number;
    readonly uor_octave_constant: () => number;
    readonly uor_state_bits: () => number;
    readonly uor_state_free: (a: number) => void;
    readonly uor_state_from_bytes: (a: number, b: number) => number;
    readonly uor_state_get_taxon: (a: number, b: number) => number;
    readonly uor_state_is_zero: (a: number) => number;
    readonly uor_state_new: () => number;
    readonly uor_state_set_taxon: (a: number, b: number, c: number) => void;
    readonly uor_state_taxons: () => number;
    readonly uor_state_to_bytes: (a: number, b: number) => void;
    readonly uor_string_free: (a: number) => void;
    readonly uor_triadic_constant: () => number;
    readonly uor_view_apply: (a: number, b: number) => number;
    readonly uor_view_apply_slice: (a: number, b: number, c: number, d: number) => void;
    readonly uor_view_constant: (a: number) => number;
    readonly uor_view_free: (a: number) => void;
    readonly uor_view_identity: () => number;
    readonly uor_view_inverse: (a: number) => number;
    readonly uor_view_is_bijective: (a: number) => number;
    readonly uor_view_then: (a: number, b: number) => number;
    readonly __wbg_wasmview_free: (a: number, b: number) => void;
    readonly braille_base: () => number;
    readonly braille_max: () => number;
    readonly octave_constant: () => number;
    readonly state_bits: () => number;
    readonly state_taxons: () => number;
    readonly triadic_constant: () => number;
    readonly wasm_byte_not: (a: number) => number;
    readonly wasm_byte_pred: (a: number) => number;
    readonly wasm_byte_rank: (a: number) => number;
    readonly wasm_byte_succ: (a: number) => number;
    readonly wasm_byte_to_braille: (a: number) => [number, number];
    readonly wasm_byte_to_codepoint: (a: number) => number;
    readonly wasm_byte_to_domain: (a: number) => number;
    readonly wasmview_apply: (a: number, b: number) => number;
    readonly wasmview_applySlice: (a: number, b: number, c: number) => [number, number];
    readonly wasmview_constant: (a: number) => [number, number, number];
    readonly wasmview_identity: () => number;
    readonly wasmview_inverse: (a: number) => [number, number, number];
    readonly wasmview_isBijective: (a: number) => number;
    readonly wasmview_table: (a: number) => [number, number];
    readonly wasmview_then: (a: number, b: number) => number;
    readonly init: () => void;
    readonly __wbg_cell_free: (a: number, b: number) => void;
    readonly __wbg_get_cell_index: (a: number) => number;
    readonly __wbg_res96_free: (a: number, b: number) => void;
    readonly cell_distanceTo: (a: number, b: number) => number;
    readonly cell_new: (a: number) => number;
    readonly cell_next: (a: number) => number;
    readonly cell_offset: (a: number, b: number) => number;
    readonly cell_prev: (a: number) => number;
    readonly res96_add: (a: number, b: number) => number;
    readonly res96_isUnit: (a: number) => number;
    readonly res96_mul: (a: number, b: number) => number;
    readonly res96_neg: (a: number) => number;
    readonly res96_new: (a: number) => number;
    readonly res96_one: () => number;
    readonly res96_sub: (a: number, b: number) => number;
    readonly res96_tryInverse: (a: number) => number;
    readonly res96_zero: () => number;
    readonly __wbg_get_res96_value: (a: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
