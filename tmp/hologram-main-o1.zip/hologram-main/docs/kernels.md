# Native AI Kernels Guide

Hologram supports loading external, optimized native kernels at runtime. This allows you to plug in high-performance implementations (e.g., CUDA, AVX-512, oneDNN) without recompiling the main application.

## 1. Quick Start

### Create a New Kernel

```bash
# Rust (Recommended)
hologram kernel init my-fast-kernel --lang rust

# C / C++
hologram kernel init my-legacy-kernel --lang c
```

### Build

```bash
cd my-fast-kernel
cargo build --release
# Output: target/release/libmy_fast_kernel.so  (or .dylib / .dll)
```

### Load and Use

Hologram automatically loads kernels from standard directories:

1. `./kernels/` (Project-local)
2. `~/.hologram/kernels/` (User-wide)
3. `/usr/local/lib/hologram/kernels/` (System-wide)

Just drop your built library into one of these folders!

## 2. Developing Rust Kernels

We provide a procedural macro to make Rust kernel development effortless.

```rust
use hologram_kernel_macro::{hologram_kernel, kernel_fn};

// 1. Initialize the kernel struct
#[hologram_kernel]
struct MyKernel;

// 2. Implement your optimized functions
#[kernel_fn]
pub unsafe extern "C" fn optimized_matmul(
    a: *const f32, b: *const f32, c: *mut f32,
    m: usize, k: usize, n: usize
) -> i32 {
    // efficient implementation...
    0 // return 0 on success
}
```

The macros automatically generate the required C-ABI boilerplate and register your functions.

## 3. Developing C Kernels

For C/C++, you must manually implement the VTable ABI.

```c
#include <stdint.h>

#define KERNEL_MAGIC 0x484F4C4F5F4B4552ULL
#define KERNEL_ABI_VERSION 1

typedef struct {
    uint64_t magic;
    uint64_t version;
    // ... function pointers ...
} KernelVTable;

// Your implementation
int32_t my_matmul(...) { return 0; }

// VTable export
static KernelVTable vtable = {
    .magic = KERNEL_MAGIC,
    .version = KERNEL_ABI_VERSION,
    .matmul = my_matmul
};

const KernelVTable* hologram_kernel_vtable(void) {
    return &vtable;
}
```

## 4. Kernel Registry & Auto-Discovery

You can programmaticallly control kernel loading:

```rust
use hologram_backend::backends::loader::KernelRegistry;

let mut registry = KernelRegistry::new();

// Explicitly load a directory
registry.load_from_directory("/opt/custom-kernels")?;

// Use the best available kernel (try-first fallback)
if let Some(result) = registry.matmul(&a, &b, &mut c, m, k, n) {
    result?; // Computation succeeded
} else {
    // No external kernel found, fallback to default
}
```

## 5. ABI & Versioning

- **Magic Number**: `0x484F_4C4F_5F4B_4552` ("HOLO_KER")
- **Versioning**: Semantic versioning of the ABI structure.
- **Safety**: The loader verifies magic and version before executing any code.
