//! Arena-based buffer management for CPU backend execution.
//!
//! The `BufferManager` provides a unified buffer space for plan execution,
//! mapping buffer indices from compiled plans to actual storage. It handles:
//! - Input buffers (data copied from caller-provided slices)
//! - Output buffers (data to be copied back to caller)
//! - Workspace buffers (intermediate results)
//! - Constant buffers (embedded in plan, read-only)
//!
//! # Arena Allocation
//!
//! All buffers are backed by a single contiguous allocation (the "arena").
//! Each buffer is an `(offset, len)` slice into the arena, with 64-byte
//! cache-line alignment between buffers for SIMD load/store compatibility.
//! This eliminates per-buffer heap allocation overhead, reducing
//! `BufferManager::new()` cost from O(N) allocations to O(1).
//!
//! # Lazy Zeroing (TASK-323)
//!
//! The arena is allocated without zeroing (`Vec::with_capacity` + `set_len`).
//! Only buffers that genuinely need zero-initialization are memset:
//! - **Input/Constant**: fully overwritten by data copies — never zeroed.
//! - **Output/Workspace with `fully_written`**: first instruction overwrites
//!   all bytes — never zeroed.
//! - **Output/Workspace without `fully_written`**: explicitly zeroed.

use hologram_holo::types::{BufferMetadata, BufferType};

use crate::types::{BackendError, Result};

/// Cache-line alignment for arena buffer boundaries.
/// 64 bytes covers AVX-512 (64B), AVX2 (32B), and NEON (16B).
const CACHE_LINE: usize = 64;

/// Round `offset` up to the next multiple of `align`.
#[inline]
const fn align_up(offset: usize, align: usize) -> usize {
    (offset + align - 1) & !(align - 1)
}

/// A buffer's location within the arena.
#[derive(Clone, Copy)]
struct BufferSlot {
    offset: usize,
    len: usize,
}

/// Manages a unified buffer space during plan execution.
///
/// All buffers reside in a single contiguous arena allocation. Buffer indices
/// from compiled plans map to `(offset, len)` slots within this arena.
///
/// # Arena Layout
///
/// ```text
/// [ buf0 (aligned) | pad | buf1 (aligned) | pad | buf2 (aligned) | ... ]
/// ```
///
/// Each buffer starts at a 64-byte cache-line boundary, ensuring SIMD
/// loads/stores never cross cache lines.
///
/// # Reuse
///
/// Call `reset()` to zero workspace/output buffers without reallocating.
/// This enables amortized-zero allocation cost across repeated executions.
pub struct BufferManager {
    /// Single contiguous allocation backing all buffers.
    arena: Vec<u8>,

    /// Slot descriptors: `(offset, len)` for each buffer index.
    slots: Vec<BufferSlot>,

    /// Indices of input buffers (for validation).
    input_indices: Vec<usize>,

    /// Indices of output buffers (for `extract_outputs`).
    output_indices: Vec<usize>,
}

impl BufferManager {
    /// Create a new buffer manager from plan metadata and input data.
    ///
    /// Performs a single arena allocation sized to hold all buffers with
    /// 64-byte alignment between each. Input data is copied in, workspace
    /// and output buffers are zeroed, constant data is copied from the plan.
    ///
    /// # Errors
    ///
    /// Returns error if input count doesn't match expected input buffers
    /// or constants blob is undersized.
    #[allow(clippy::cast_possible_truncation)]
    pub fn new(
        buffer_metadata: &[BufferMetadata],
        inputs: &[&[u8]],
        constants: &[u8],
    ) -> Result<Self> {
        // Phase 1: compute arena size and slot offsets.
        let mut slots = Vec::with_capacity(buffer_metadata.len());
        let mut arena_size = 0usize;

        for meta in buffer_metadata {
            let offset = align_up(arena_size, CACHE_LINE);
            slots.push(BufferSlot {
                offset,
                len: meta.size,
            });
            arena_size = offset + meta.size;
        }

        // Phase 2: allocate arena WITHOUT zeroing.
        //
        // Instead of `vec![0u8; arena_size]` which memsets the entire arena,
        // we allocate uninitialized memory and selectively zero only the
        // buffers that need it.  Input and Constant buffers get fully
        // overwritten by data copies.  Output/Workspace buffers marked
        // `fully_written` will be overwritten by their first instruction.
        // Only unmarked Output/Workspace buffers need explicit zeroing.
        let mut arena = Vec::with_capacity(arena_size);
        // Safety: all bytes are written before being read -- either by data
        // copies (Input/Constant), selective zeroing below (Output/Workspace
        // without fully_written), or instruction output (fully_written).
        // Alignment padding between slots is never read.
        #[allow(clippy::uninit_vec)]
        unsafe {
            arena.set_len(arena_size);
        }

        // Phase 3: populate buffers.
        let mut input_indices = Vec::new();
        let mut output_indices = Vec::new();
        let mut input_idx = 0;
        let mut constant_offset = 0;

        for (idx, meta) in buffer_metadata.iter().enumerate() {
            let slot = slots[idx];
            match meta.buffer_type {
                BufferType::Input => {
                    if input_idx >= inputs.len() {
                        return Err(BackendError::InvalidBufferIndex {
                            kind: "input",
                            index: input_idx as u32,
                            count: inputs.len(),
                        });
                    }
                    let src = inputs[input_idx];
                    if src.len() != meta.size {
                        return Err(BackendError::SizeMismatch {
                            expected: meta.size,
                            actual: src.len(),
                        });
                    }
                    arena[slot.offset..slot.offset + slot.len].copy_from_slice(src);
                    input_indices.push(idx);
                    input_idx += 1;
                }
                BufferType::Output => {
                    if !meta.fully_written {
                        arena[slot.offset..slot.offset + slot.len].fill(0);
                    }
                    output_indices.push(idx);
                }
                BufferType::Workspace => {
                    if !meta.fully_written {
                        arena[slot.offset..slot.offset + slot.len].fill(0);
                    }
                }
                BufferType::Constant => {
                    let avail = constants.len().saturating_sub(constant_offset);
                    if avail < meta.size {
                        return Err(BackendError::SizeMismatch {
                            expected: constant_offset + meta.size,
                            actual: constants.len(),
                        });
                    }
                    arena[slot.offset..slot.offset + slot.len]
                        .copy_from_slice(&constants[constant_offset..constant_offset + meta.size]);

                    #[cfg(feature = "debug-large-graph")]
                    {
                        let non_zero = arena[slot.offset..slot.offset + slot.len]
                            .iter()
                            .filter(|&&b| b != 0)
                            .count();
                        if non_zero == 0 && meta.size > 0 {
                            eprintln!(
                                "[BUG] Constant buffer {} (size={}) is ALL ZEROS at offset={}",
                                idx, meta.size, constant_offset
                            );
                        }
                    }

                    constant_offset += meta.size;
                }
            }
        }

        if input_idx != inputs.len() {
            return Err(BackendError::InvalidBufferIndex {
                kind: "input",
                index: inputs.len() as u32,
                count: input_idx,
            });
        }

        Ok(Self {
            arena,
            slots,
            input_indices,
            output_indices,
        })
    }

    /// Create an empty buffer manager (for tests with no plan metadata).
    #[must_use]
    pub fn empty() -> Self {
        Self {
            arena: Vec::new(),
            slots: Vec::new(),
            input_indices: Vec::new(),
            output_indices: Vec::new(),
        }
    }

    /// Reset workspace and output buffers to zero without reallocating.
    ///
    /// This enables reuse of the same `BufferManager` across multiple
    /// `execute_plan()` calls, amortizing allocation cost to zero after
    /// the first invocation.
    ///
    /// Input and constant buffers are preserved. Call with new input data
    /// via `reload_inputs()` if inputs change between invocations.
    pub fn reset(&mut self, buffer_metadata: &[BufferMetadata]) {
        for (idx, meta) in buffer_metadata.iter().enumerate() {
            if matches!(meta.buffer_type, BufferType::Workspace | BufferType::Output) {
                if let Some(slot) = self.slots.get(idx) {
                    let end = slot.offset + slot.len;
                    if end <= self.arena.len() {
                        self.arena[slot.offset..end].fill(0);
                    }
                }
            }
        }
    }

    /// Read data from a buffer by unified index.
    ///
    /// # Errors
    ///
    /// Returns error if index is out of bounds.
    pub fn read(&self, index: u32) -> Result<&[u8]> {
        let slot = self.slot(index)?;
        Ok(&self.arena[slot.offset..slot.offset + slot.len])
    }

    /// Write data to a buffer by unified index.
    ///
    /// # Errors
    ///
    /// Returns error if index is out of bounds or data exceeds buffer capacity.
    pub fn write(&mut self, index: u32, data: &[u8]) -> Result<()> {
        let slot = self.slot(index)?;

        if data.len() > slot.len {
            return Err(BackendError::SizeMismatch {
                expected: slot.len,
                actual: data.len(),
            });
        }

        self.arena[slot.offset..slot.offset + data.len()].copy_from_slice(data);
        Ok(())
    }

    /// Get a mutable reference to buffer data.
    ///
    /// # Errors
    ///
    /// Returns error if index is out of bounds.
    pub fn get_mut(&mut self, index: u32) -> Result<&mut [u8]> {
        let slot = self.slot(index)?;
        Ok(&mut self.arena[slot.offset..slot.offset + slot.len])
    }

    /// Read f32 values from a buffer.
    ///
    /// # Errors
    ///
    /// Returns error if buffer is too small or misaligned.
    #[allow(clippy::cast_ptr_alignment)]
    pub fn read_f32_slice(&self, index: u32, count: usize) -> Result<&[f32]> {
        let bytes = self.read(index)?;
        let byte_len = count * std::mem::size_of::<f32>();

        if bytes.len() < byte_len {
            return Err(BackendError::SizeMismatch {
                expected: byte_len,
                actual: bytes.len(),
            });
        }

        let ptr = bytes.as_ptr().cast::<f32>();
        if ptr.align_offset(std::mem::align_of::<f32>()) != 0 {
            return Err(BackendError::AlignmentError {
                required: std::mem::align_of::<f32>(),
                actual: ptr.align_offset(std::mem::align_of::<f32>()),
            });
        }

        // Safety: We've verified length and alignment
        Ok(unsafe { std::slice::from_raw_parts(ptr, count) })
    }

    /// Get a mutable f32 slice from a buffer (zero-copy).
    ///
    /// This allows SIMD functions to write directly into the buffer without
    /// intermediate allocations.
    ///
    /// # Errors
    ///
    /// Returns error if buffer is too small or misaligned.
    #[allow(clippy::cast_ptr_alignment)]
    pub fn get_f32_mut(&mut self, index: u32, count: usize) -> Result<&mut [f32]> {
        let bytes = self.get_mut(index)?;
        let byte_len = count * std::mem::size_of::<f32>();

        if bytes.len() < byte_len {
            return Err(BackendError::SizeMismatch {
                expected: byte_len,
                actual: bytes.len(),
            });
        }

        let ptr = bytes.as_mut_ptr().cast::<f32>();
        if ptr.align_offset(std::mem::align_of::<f32>()) != 0 {
            return Err(BackendError::AlignmentError {
                required: std::mem::align_of::<f32>(),
                actual: ptr.align_offset(std::mem::align_of::<f32>()),
            });
        }

        // Safety: We've verified length and alignment
        Ok(unsafe { std::slice::from_raw_parts_mut(ptr, count) })
    }

    /// Write f32 values to a buffer.
    ///
    /// # Errors
    ///
    /// Returns error if buffer is too small or misaligned.
    #[allow(clippy::cast_ptr_alignment)]
    pub fn write_f32_slice(&mut self, index: u32, data: &[f32]) -> Result<()> {
        let bytes = self.get_mut(index)?;
        let byte_len = std::mem::size_of_val(data);

        if bytes.len() < byte_len {
            return Err(BackendError::SizeMismatch {
                expected: byte_len,
                actual: bytes.len(),
            });
        }

        let ptr = bytes.as_mut_ptr().cast::<f32>();
        if ptr.align_offset(std::mem::align_of::<f32>()) != 0 {
            return Err(BackendError::AlignmentError {
                required: std::mem::align_of::<f32>(),
                actual: ptr.align_offset(std::mem::align_of::<f32>()),
            });
        }

        // Safety: We've verified length and alignment
        unsafe {
            std::ptr::copy_nonoverlapping(data.as_ptr(), ptr, data.len());
        }

        Ok(())
    }

    /// Extract output buffer data into caller-provided output slices.
    ///
    /// # Errors
    ///
    /// Returns error if output count doesn't match or buffers are too small.
    #[allow(clippy::cast_possible_truncation)]
    pub fn extract_outputs(&self, outputs: &mut [&mut [u8]]) -> Result<()> {
        if outputs.len() != self.output_indices.len() {
            return Err(BackendError::InvalidBufferIndex {
                kind: "output",
                index: outputs.len() as u32,
                count: self.output_indices.len(),
            });
        }

        for (out_idx, &buf_idx) in self.output_indices.iter().enumerate() {
            let slot = self.slots[buf_idx];
            let src = &self.arena[slot.offset..slot.offset + slot.len];
            let dst = &mut outputs[out_idx];
            let copy_len = src.len().min(dst.len());
            dst[..copy_len].copy_from_slice(&src[..copy_len]);
        }

        Ok(())
    }

    /// Get number of buffers.
    #[must_use]
    pub fn buffer_count(&self) -> usize {
        self.slots.len()
    }

    /// Get number of output buffers.
    #[must_use]
    pub fn output_count(&self) -> usize {
        self.output_indices.len()
    }

    /// Get number of input buffers.
    #[must_use]
    pub fn input_count(&self) -> usize {
        self.input_indices.len()
    }

    /// Resolve a buffer index to its slot descriptor.
    #[inline]
    fn slot(&self, index: u32) -> Result<BufferSlot> {
        self.slots
            .get(index as usize)
            .copied()
            .ok_or(BackendError::InvalidBufferIndex {
                kind: "unified",
                index,
                count: self.slots.len(),
            })
    }
}

#[cfg(test)]
#[allow(clippy::similar_names)]
mod tests {
    use super::*;

    fn make_metadata(types: &[BufferType], sizes: &[usize]) -> Vec<BufferMetadata> {
        types
            .iter()
            .zip(sizes.iter())
            .map(|(&bt, &sz)| BufferMetadata::new(sz, bt))
            .collect()
    }

    #[test]
    fn test_buffer_manager_creation() {
        let metadata = make_metadata(
            &[BufferType::Input, BufferType::Workspace, BufferType::Output],
            &[16, 32, 16],
        );
        let input_data = vec![1u8; 16];
        let inputs: &[&[u8]] = &[&input_data];

        let manager = BufferManager::new(&metadata, inputs, &[]).unwrap();

        assert_eq!(manager.buffer_count(), 3);
        assert_eq!(manager.input_count(), 1);
        assert_eq!(manager.output_count(), 1);
    }

    #[test]
    fn test_read_input_buffer() {
        let metadata = make_metadata(&[BufferType::Input], &[16]);
        let mut input_data = vec![1u8, 2, 3, 4, 5, 6, 7, 8];
        input_data.extend(vec![0u8; 8]);
        let inputs: &[&[u8]] = &[&input_data];

        let manager = BufferManager::new(&metadata, inputs, &[]).unwrap();

        let data = manager.read(0).unwrap();
        assert_eq!(&data[..8], &[1, 2, 3, 4, 5, 6, 7, 8]);
    }

    #[test]
    fn test_input_size_mismatch_returns_error() {
        let metadata = make_metadata(&[BufferType::Input], &[20]);
        let input_data = vec![0u8; 10];
        let inputs: &[&[u8]] = &[&input_data];

        let result = BufferManager::new(&metadata, inputs, &[]);
        assert!(
            matches!(
                result,
                Err(BackendError::SizeMismatch {
                    expected: 20,
                    actual: 10
                })
            ),
            "Should return SizeMismatch when input size doesn't match metadata"
        );
    }

    #[test]
    fn test_write_and_read_workspace() {
        let metadata = make_metadata(&[BufferType::Workspace], &[16]);

        let mut manager = BufferManager::new(&metadata, &[], &[]).unwrap();

        manager.write(0, &[10, 20, 30, 40]).unwrap();

        let data = manager.read(0).unwrap();
        assert_eq!(&data[..4], &[10, 20, 30, 40]);
    }

    #[test]
    fn test_extract_outputs() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Output], &[16, 16]);
        let input_data = vec![0u8; 16];
        let inputs: &[&[u8]] = &[&input_data];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();

        manager.write(1, &[5, 6, 7, 8]).unwrap();

        let mut out_buf = vec![0u8; 16];
        let outputs: &mut [&mut [u8]] = &mut [&mut out_buf];

        manager.extract_outputs(outputs).unwrap();

        assert_eq!(&out_buf[..4], &[5, 6, 7, 8]);
    }

    #[test]
    fn test_f32_read_write() {
        let metadata = make_metadata(&[BufferType::Workspace], &[64]);

        let mut manager = BufferManager::new(&metadata, &[], &[]).unwrap();

        manager.write_f32_slice(0, &[1.0, 2.0, 3.0, 4.0]).unwrap();

        let floats = manager.read_f32_slice(0, 4).unwrap();
        assert_eq!(floats, &[1.0, 2.0, 3.0, 4.0]);
    }

    #[test]
    fn test_invalid_buffer_index() {
        let metadata = make_metadata(&[BufferType::Input], &[16]);
        let input_data = vec![0u8; 16];
        let inputs: &[&[u8]] = &[&input_data];

        let manager = BufferManager::new(&metadata, inputs, &[]).unwrap();

        assert!(manager.read(5).is_err());
    }

    #[test]
    fn test_input_count_mismatch() {
        let metadata = make_metadata(&[BufferType::Input, BufferType::Input], &[16, 16]);
        let input_data = vec![0u8; 16];
        let inputs: &[&[u8]] = &[&input_data];

        let result = BufferManager::new(&metadata, inputs, &[]);
        assert!(result.is_err());
    }

    #[test]
    fn test_constant_buffer() {
        let metadata = make_metadata(&[BufferType::Constant], &[8]);
        let constants = vec![1u8, 2, 3, 4, 5, 6, 7, 8];

        let manager = BufferManager::new(&metadata, &[], &constants).unwrap();

        let data = manager.read(0).unwrap();
        assert_eq!(data, &[1, 2, 3, 4, 5, 6, 7, 8]);
    }

    #[test]
    fn test_mixed_buffer_types() {
        let metadata = make_metadata(
            &[
                BufferType::Input,
                BufferType::Input,
                BufferType::Workspace,
                BufferType::Output,
            ],
            &[16, 16, 16, 16],
        );

        let a_data = vec![1u8; 16];
        let b_data = vec![2u8; 16];
        let inputs: &[&[u8]] = &[&a_data, &b_data];

        let mut manager = BufferManager::new(&metadata, inputs, &[]).unwrap();

        assert_eq!(manager.input_count(), 2);
        assert_eq!(manager.output_count(), 1);
        assert_eq!(manager.buffer_count(), 4);

        manager.write(2, &[3u8; 16]).unwrap();
        manager.write(3, &[4u8; 16]).unwrap();

        let mut out_buf = vec![0u8; 16];
        let outputs: &mut [&mut [u8]] = &mut [&mut out_buf];
        manager.extract_outputs(outputs).unwrap();

        assert_eq!(out_buf, vec![4u8; 16]);
    }

    #[test]
    fn test_empty_manager() {
        let manager = BufferManager::empty();

        assert_eq!(manager.buffer_count(), 0);
        assert_eq!(manager.input_count(), 0);
        assert_eq!(manager.output_count(), 0);
    }

    #[test]
    fn test_size_mismatch() {
        let metadata = make_metadata(&[BufferType::Workspace], &[8]);

        let manager = BufferManager::new(&metadata, &[], &[]).unwrap();

        let err = manager.read_f32_slice(0, 4);
        assert!(err.is_err());
    }

    #[test]
    fn test_multiple_constant_buffers() {
        let metadata = make_metadata(
            &[
                BufferType::Constant,
                BufferType::Constant,
                BufferType::Workspace,
            ],
            &[8, 8, 8],
        );
        let constants = vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16];

        let manager = BufferManager::new(&metadata, &[], &constants).unwrap();

        assert_eq!(manager.read(0).unwrap(), &[1, 2, 3, 4, 5, 6, 7, 8]);
        assert_eq!(manager.read(1).unwrap(), &[9, 10, 11, 12, 13, 14, 15, 16]);
    }

    #[test]
    fn test_undersized_constants_returns_error() {
        let metadata = make_metadata(&[BufferType::Constant], &[16]);
        let constants = vec![1, 2, 3, 4];

        let result = BufferManager::new(&metadata, &[], &constants);
        assert!(result.is_err(), "Should error when constants undersized");
    }

    #[test]
    fn test_write_truncation_returns_error() {
        let metadata = make_metadata(&[BufferType::Workspace], &[4]);
        let mut manager = BufferManager::new(&metadata, &[], &[]).unwrap();

        let result = manager.write(0, &[1, 2, 3, 4, 5, 6, 7, 8]);
        assert!(
            result.is_err(),
            "Should error when data exceeds buffer capacity"
        );
    }

    // ========================================================================
    // Arena-specific tests
    // ========================================================================

    #[test]
    fn test_arena_single_allocation() {
        // Verify the arena is a single contiguous allocation
        let metadata = make_metadata(
            &[
                BufferType::Workspace,
                BufferType::Workspace,
                BufferType::Workspace,
            ],
            &[1024, 2048, 512],
        );

        let manager = BufferManager::new(&metadata, &[], &[]).unwrap();

        // All three buffers should reside in a single arena
        assert_eq!(manager.buffer_count(), 3);
        // Arena should be large enough for all buffers + alignment padding
        assert!(manager.arena.len() >= 1024 + 2048 + 512);
    }

    #[test]
    fn test_arena_alignment() {
        // Verify buffers are 64-byte aligned within the arena
        let metadata = make_metadata(
            &[BufferType::Workspace, BufferType::Workspace],
            &[100, 200], // Non-aligned sizes
        );

        let manager = BufferManager::new(&metadata, &[], &[]).unwrap();

        // First buffer at offset 0 (aligned)
        assert_eq!(manager.slots[0].offset % CACHE_LINE, 0);
        // Second buffer also aligned
        assert_eq!(manager.slots[1].offset % CACHE_LINE, 0);
        // Second buffer starts after first + padding
        assert!(manager.slots[1].offset >= 100);
    }

    #[test]
    fn test_reset_preserves_inputs_and_constants() {
        let metadata = make_metadata(
            &[
                BufferType::Input,
                BufferType::Workspace,
                BufferType::Constant,
                BufferType::Output,
            ],
            &[8, 8, 8, 8],
        );
        let input_data = vec![0xAAu8; 8];
        let constants = vec![0xBBu8; 8];
        let inputs: &[&[u8]] = &[&input_data];

        let mut manager = BufferManager::new(&metadata, inputs, &constants).unwrap();

        // Write to workspace and output
        manager.write(1, &[0xCC; 8]).unwrap();
        manager.write(3, &[0xDD; 8]).unwrap();

        // Reset
        manager.reset(&metadata);

        // Input preserved
        assert_eq!(manager.read(0).unwrap(), &[0xAA; 8]);
        // Workspace zeroed
        assert_eq!(manager.read(1).unwrap(), &[0; 8]);
        // Constant preserved
        assert_eq!(manager.read(2).unwrap(), &[0xBB; 8]);
        // Output zeroed
        assert_eq!(manager.read(3).unwrap(), &[0; 8]);
    }

    #[test]
    fn test_arena_f32_alignment() {
        // Verify f32 operations work with arena-backed buffers
        let metadata = make_metadata(&[BufferType::Workspace, BufferType::Workspace], &[64, 64]);

        let mut manager = BufferManager::new(&metadata, &[], &[]).unwrap();

        // Write f32s to both buffers
        manager.write_f32_slice(0, &[1.0, 2.0, 3.0]).unwrap();
        manager.write_f32_slice(1, &[4.0, 5.0, 6.0]).unwrap();

        // Read back
        assert_eq!(manager.read_f32_slice(0, 3).unwrap(), &[1.0, 2.0, 3.0]);
        assert_eq!(manager.read_f32_slice(1, 3).unwrap(), &[4.0, 5.0, 6.0]);
    }

    // ========================================================================
    // Lazy zeroing tests (TASK-323)
    // ========================================================================

    #[test]
    fn test_lazy_zeroing_non_fully_written_is_zeroed() {
        // Output/Workspace without fully_written must be zeroed
        let metadata = vec![
            BufferMetadata::new(64, BufferType::Output),
            BufferMetadata::new(64, BufferType::Workspace),
        ];

        let manager = BufferManager::new(&metadata, &[], &[]).unwrap();

        assert_eq!(manager.read(0).unwrap(), &[0u8; 64]);
        assert_eq!(manager.read(1).unwrap(), &[0u8; 64]);
    }

    #[test]
    fn test_lazy_zeroing_fully_written_skips_zero() {
        // Buffers marked fully_written are NOT zeroed.  We verify that the
        // constructor succeeds and the buffer is accessible (contents are
        // undefined but the buffer is valid).
        let metadata = vec![
            BufferMetadata::new(64, BufferType::Output).with_fully_written(),
            BufferMetadata::new(64, BufferType::Workspace).with_fully_written(),
        ];

        let mut manager = BufferManager::new(&metadata, &[], &[]).unwrap();

        // Write and readback to confirm the buffer is usable
        manager.write(0, &[0xAA; 64]).unwrap();
        assert_eq!(manager.read(0).unwrap(), &[0xAA; 64]);
        manager.write(1, &[0xBB; 64]).unwrap();
        assert_eq!(manager.read(1).unwrap(), &[0xBB; 64]);
    }

    #[test]
    fn test_lazy_zeroing_mixed() {
        // Mix of fully_written and non-fully_written buffers
        let metadata = vec![
            BufferMetadata::new(32, BufferType::Input),
            BufferMetadata::new(32, BufferType::Output), // NOT fully_written
            BufferMetadata::new(32, BufferType::Output).with_fully_written(), // fully_written
            BufferMetadata::new(32, BufferType::Workspace), // NOT fully_written
        ];

        let input = vec![1u8; 32];
        let manager = BufferManager::new(&metadata, &[&input], &[]).unwrap();

        // Input: data copied
        assert_eq!(manager.read(0).unwrap(), &[1u8; 32]);
        // Output (not fully_written): zeroed
        assert_eq!(manager.read(1).unwrap(), &[0u8; 32]);
        // Output (fully_written): accessible (contents undefined, but valid)
        assert_eq!(manager.read(2).unwrap().len(), 32);
        // Workspace (not fully_written): zeroed
        assert_eq!(manager.read(3).unwrap(), &[0u8; 32]);
    }
}
