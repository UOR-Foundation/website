import { OntologyGraph, D3Node, D3Link } from '../types';

export const transformOntologyToD3 = (ontology: OntologyGraph): { nodes: D3Node[], links: D3Link[] } => {
  const nodes: D3Node[] = [];
  const links: D3Link[] = [];
  const idSet = new Set<string>();

  ontology["@graph"].forEach(item => {
    const id = item["@id"];
    const type = Array.isArray(item["@type"]) ? item["@type"][0] : item["@type"] || 'Unknown';
    const label = item.label || id.split('/').pop() || id;
    
    // Create Node
    if (!idSet.has(id)) {
      nodes.push({
        id,
        group: type,
        label,
        val: 1
      });
      idSet.add(id);
    }

    // Create Links based on standard relationships
    const relationships = ['partOf', 'contains', 'derivedFrom', 'embedsInto', 'satisfies'];
    
    relationships.forEach(rel => {
      if (item[rel]) {
        const targets = Array.isArray(item[rel]) ? item[rel] : [item[rel]];
        targets.forEach((target: string) => {
          links.push({
            source: id,
            target: target,
            relationship: rel
          });
          
          // Ensure target node exists implicitly if not explicitly defined
          if (!idSet.has(target)) {
            nodes.push({
              id: target,
              group: 'Implicit',
              label: target.split('/').pop() || target,
              val: 0.5
            });
            idSet.add(target);
          }
        });
      }
    });
  });

  return { nodes, links };
};