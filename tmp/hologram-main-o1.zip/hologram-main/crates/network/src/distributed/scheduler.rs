//! Work scheduling for distributed execution.

use super::executor::ExecutionResult;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use thiserror::Error;
use tokio::sync::RwLock;

/// Error type for scheduler operations.
#[derive(Debug, Error)]
pub enum SchedulerError {
    /// No workers available.
    #[error("No workers available")]
    NoWorkers,

    /// Worker failed.
    #[error("Worker {0} failed: {1}")]
    WorkerFailed(WorkerId, String),

    /// Request timeout.
    #[error("Request timed out")]
    Timeout,

    /// Invalid request.
    #[error("Invalid request: {0}")]
    InvalidRequest(String),
}

/// Unique identifier for a worker.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Default)]
pub struct WorkerId(pub u64);

impl std::fmt::Display for WorkerId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "worker-{}", self.0)
    }
}

/// State of a worker.
#[derive(Debug, Clone)]
pub struct WorkerState {
    /// Worker ID.
    pub id: WorkerId,
    /// Whether the worker is available.
    pub available: bool,
    /// Current load (0-100).
    pub load: u8,
    /// Layers available on this worker.
    pub layers: Vec<String>,
    /// Last heartbeat time.
    pub last_heartbeat: std::time::Instant,
}

impl WorkerState {
    /// Create a new worker state.
    #[must_use]
    pub fn new(id: WorkerId, layers: Vec<String>) -> Self {
        Self {
            id,
            available: true,
            load: 0,
            layers,
            last_heartbeat: std::time::Instant::now(),
        }
    }

    /// Check if worker can accept work.
    #[must_use]
    pub fn can_accept_work(&self) -> bool {
        self.available && self.load < 100
    }

    /// Check if worker has a specific layer.
    #[must_use]
    pub fn has_layer(&self, layer: &str) -> bool {
        self.layers.iter().any(|l| l == layer)
    }
}

/// Configuration for the scheduler.
#[derive(Debug, Clone)]
pub struct SchedulerConfig {
    /// Maximum concurrent requests per worker.
    pub max_concurrent: usize,
    /// Request timeout in seconds.
    pub timeout_secs: u64,
    /// Heartbeat interval in seconds.
    pub heartbeat_interval_secs: u64,
    /// Maximum retries for failed requests.
    pub max_retries: u32,
}

impl Default for SchedulerConfig {
    fn default() -> Self {
        Self {
            max_concurrent: 10,
            timeout_secs: 60,
            heartbeat_interval_secs: 5,
            max_retries: 3,
        }
    }
}

/// A request for distributed execution.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionRequest {
    /// Request ID.
    pub id: u64,
    /// Layer to execute.
    pub layer_ref: String,
    /// Input data (serialized).
    pub input: Vec<u8>,
    /// Priority (higher = more urgent).
    pub priority: u32,
}

impl ExecutionRequest {
    /// Create a new execution request.
    pub fn new(layer_ref: impl Into<String>, input: Vec<u8>) -> Self {
        static COUNTER: AtomicU64 = AtomicU64::new(0);
        Self {
            id: COUNTER.fetch_add(1, Ordering::SeqCst),
            layer_ref: layer_ref.into(),
            input,
            priority: 0,
        }
    }

    /// Set the priority.
    #[must_use]
    pub fn with_priority(mut self, priority: u32) -> Self {
        self.priority = priority;
        self
    }
}

/// Scheduler for distributing work across workers.
pub struct Scheduler {
    /// Configuration.
    config: SchedulerConfig,
    /// Available workers.
    workers: Arc<RwLock<HashMap<WorkerId, WorkerState>>>,
    /// Next worker ID.
    next_worker_id: AtomicU64,
    /// Pending requests.
    pending: Arc<RwLock<Vec<ExecutionRequest>>>,
    /// Completed results awaiting pickup.
    results: Arc<RwLock<HashMap<u64, ExecutionResult>>>,
}

impl Scheduler {
    /// Create a new scheduler.
    #[must_use]
    pub fn new(config: SchedulerConfig) -> Self {
        Self {
            config,
            workers: Arc::new(RwLock::new(HashMap::new())),
            next_worker_id: AtomicU64::new(0),
            pending: Arc::new(RwLock::new(Vec::new())),
            results: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    /// Get the scheduler configuration.
    #[must_use]
    pub fn config(&self) -> &SchedulerConfig {
        &self.config
    }

    /// Register a new worker.
    pub async fn register_worker(&self, layers: Vec<String>) -> WorkerId {
        let id = WorkerId(self.next_worker_id.fetch_add(1, Ordering::SeqCst));
        let state = WorkerState::new(id, layers);

        self.workers.write().await.insert(id, state);
        tracing::info!("Registered worker: {}", id);
        id
    }

    /// Unregister a worker.
    pub async fn unregister_worker(&self, id: WorkerId) {
        self.workers.write().await.remove(&id);
        tracing::info!("Unregistered worker: {}", id);
    }

    /// Update worker heartbeat.
    pub async fn heartbeat(&self, id: WorkerId, load: u8) {
        if let Some(worker) = self.workers.write().await.get_mut(&id) {
            worker.last_heartbeat = std::time::Instant::now();
            worker.load = load;
        }
    }

    /// Set worker availability.
    pub async fn set_worker_available(&self, id: WorkerId, available: bool) {
        if let Some(worker) = self.workers.write().await.get_mut(&id) {
            worker.available = available;
        }
    }

    /// Find the best worker for a layer.
    pub async fn find_worker(&self, layer_ref: &str) -> Option<WorkerId> {
        let workers = self.workers.read().await;

        // Find workers that have the layer and are available
        let mut candidates: Vec<_> = workers
            .values()
            .filter(|w| w.can_accept_work() && w.has_layer(layer_ref))
            .collect();

        // Sort by load (lowest first)
        candidates.sort_by_key(|w| w.load);

        candidates.first().map(|w| w.id)
    }

    /// Find any available worker.
    pub async fn find_any_worker(&self) -> Option<WorkerId> {
        let workers = self.workers.read().await;

        workers
            .values()
            .filter(|w| w.can_accept_work())
            .min_by_key(|w| w.load)
            .map(|w| w.id)
    }

    /// Submit a request for execution.
    pub async fn submit(&self, request: ExecutionRequest) -> Result<u64, SchedulerError> {
        // Find a worker (try specific first, then fall back to any available)
        let worker_id = match self.find_worker(&request.layer_ref).await {
            Some(id) => id,
            None => self
                .find_any_worker()
                .await
                .ok_or(SchedulerError::NoWorkers)?,
        };

        let request_id = request.id;
        tracing::info!("Scheduling request {} to worker {}", request_id, worker_id);

        // Mark worker as busier
        if let Some(worker) = self.workers.write().await.get_mut(&worker_id) {
            worker.load = (worker.load + 10).min(100);
        }

        // Add to pending
        self.pending.write().await.push(request);

        Ok(request_id)
    }

    /// Execute a request and wait for result.
    ///
    /// Submits the request and polls for the result with exponential backoff
    /// until the configured timeout is reached.
    pub async fn execute(
        &self,
        request: ExecutionRequest,
    ) -> Result<ExecutionResult, SchedulerError> {
        let request_id = request.id;
        self.submit(request).await?;

        // Poll for result with exponential backoff
        let timeout = std::time::Duration::from_secs(self.config.timeout_secs);
        let start = std::time::Instant::now();
        let mut poll_interval = std::time::Duration::from_millis(10);
        let max_interval = std::time::Duration::from_millis(500);

        loop {
            // Check if result is available
            if let Some(result) = self.results.write().await.remove(&request_id) {
                return Ok(result);
            }

            // Check timeout
            if start.elapsed() >= timeout {
                // Remove from pending if still there
                self.pending.write().await.retain(|r| r.id != request_id);
                return Err(SchedulerError::Timeout);
            }

            // Wait with exponential backoff
            tokio::time::sleep(poll_interval).await;
            poll_interval = (poll_interval * 2).min(max_interval);
        }
    }

    /// Complete a request with a result (called by workers).
    pub async fn complete(&self, result: ExecutionResult) {
        let request_id = result.request_id;

        // Remove from pending
        self.pending.write().await.retain(|r| r.id != request_id);

        // Store result for pickup
        self.results.write().await.insert(request_id, result);
    }

    /// Get a pending request for a worker.
    pub async fn get_pending(&self, worker_id: WorkerId) -> Option<ExecutionRequest> {
        let workers = self.workers.read().await;
        let worker = workers.get(&worker_id)?;

        let mut pending = self.pending.write().await;

        // Find a request this worker can handle
        let pos = pending
            .iter()
            .position(|r| worker.has_layer(&r.layer_ref) || worker.layers.is_empty())?;

        Some(pending.remove(pos))
    }

    /// Get the number of registered workers.
    pub async fn worker_count(&self) -> usize {
        self.workers.read().await.len()
    }

    /// Get the number of pending requests.
    pub async fn pending_count(&self) -> usize {
        self.pending.read().await.len()
    }

    /// Get the number of completed results awaiting pickup.
    pub async fn results_count(&self) -> usize {
        self.results.read().await.len()
    }

    /// Get all worker states.
    pub async fn worker_states(&self) -> Vec<WorkerState> {
        self.workers.read().await.values().cloned().collect()
    }

    /// Get available worker IDs.
    pub async fn available_workers(&self) -> Vec<WorkerId> {
        self.workers
            .read()
            .await
            .values()
            .filter(|w| w.can_accept_work())
            .map(|w| w.id)
            .collect()
    }
}

impl Default for Scheduler {
    fn default() -> Self {
        Self::new(SchedulerConfig::default())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_scheduler_creation() {
        let scheduler = Scheduler::default();
        assert_eq!(scheduler.worker_count().await, 0);
        assert_eq!(scheduler.pending_count().await, 0);
    }

    #[tokio::test]
    async fn test_scheduler_config() {
        let config = SchedulerConfig {
            max_concurrent: 5,
            timeout_secs: 30,
            heartbeat_interval_secs: 10,
            max_retries: 5,
        };
        let scheduler = Scheduler::new(config);
        assert_eq!(scheduler.config().max_concurrent, 5);
        assert_eq!(scheduler.config().timeout_secs, 30);
    }

    #[tokio::test]
    async fn test_register_worker() {
        let scheduler = Scheduler::default();
        let id = scheduler
            .register_worker(vec!["bert/embeddings:v1.0".to_string()])
            .await;

        assert_eq!(scheduler.worker_count().await, 1);
        assert_eq!(id.0, 0);
    }

    #[tokio::test]
    async fn test_register_multiple_workers() {
        let scheduler = Scheduler::default();
        let id1 = scheduler.register_worker(vec![]).await;
        let id2 = scheduler.register_worker(vec![]).await;

        assert_eq!(scheduler.worker_count().await, 2);
        assert_ne!(id1, id2);
    }

    #[tokio::test]
    async fn test_unregister_worker() {
        let scheduler = Scheduler::default();
        let id = scheduler.register_worker(vec![]).await;
        assert_eq!(scheduler.worker_count().await, 1);

        scheduler.unregister_worker(id).await;
        assert_eq!(scheduler.worker_count().await, 0);
    }

    #[tokio::test]
    async fn test_find_worker() {
        let scheduler = Scheduler::default();

        // No workers yet
        assert!(scheduler
            .find_worker("bert/embeddings:v1.0")
            .await
            .is_none());

        // Register worker with the layer
        scheduler
            .register_worker(vec!["bert/embeddings:v1.0".to_string()])
            .await;

        // Now should find it
        assert!(scheduler
            .find_worker("bert/embeddings:v1.0")
            .await
            .is_some());

        // Different layer should not match
        assert!(scheduler.find_worker("other:v1.0").await.is_none());
    }

    #[tokio::test]
    async fn test_find_any_worker() {
        let scheduler = Scheduler::default();

        // No workers
        assert!(scheduler.find_any_worker().await.is_none());

        // Register worker
        let id = scheduler.register_worker(vec![]).await;

        // Should find it
        assert_eq!(scheduler.find_any_worker().await, Some(id));
    }

    #[tokio::test]
    async fn test_submit_no_workers() {
        let scheduler = Scheduler::default();
        let request = ExecutionRequest::new("bert/embeddings:v1.0", vec![]);

        let result = scheduler.submit(request).await;
        assert!(matches!(result, Err(SchedulerError::NoWorkers)));
    }

    #[tokio::test]
    async fn test_submit_success() {
        let scheduler = Scheduler::default();
        scheduler
            .register_worker(vec!["bert/embeddings:v1.0".to_string()])
            .await;

        let request = ExecutionRequest::new("bert/embeddings:v1.0", vec![1, 2, 3]);
        let result = scheduler.submit(request).await;
        assert!(result.is_ok());
        assert_eq!(scheduler.pending_count().await, 1);
    }

    #[tokio::test]
    async fn test_submit_fallback_to_any_worker() {
        let scheduler = Scheduler::default();
        // Register worker without specific layer
        scheduler.register_worker(vec![]).await;

        // Submit request for layer the worker doesn't have
        let request = ExecutionRequest::new("unknown:v1.0", vec![]);
        let result = scheduler.submit(request).await;
        assert!(result.is_ok());
    }

    #[tokio::test]
    async fn test_complete() {
        let scheduler = Scheduler::default();
        scheduler.register_worker(vec!["test:v1".to_string()]).await;

        let request = ExecutionRequest::new("test:v1", vec![]);
        let request_id = scheduler.submit(request).await.unwrap();
        assert_eq!(scheduler.pending_count().await, 1);

        let result = ExecutionResult {
            request_id,
            output: vec![1, 2, 3],
            duration_ms: 100,
            worker_id: WorkerId(0),
        };

        scheduler.complete(result).await;
        assert_eq!(scheduler.pending_count().await, 0);
        assert_eq!(scheduler.results_count().await, 1);
    }

    #[tokio::test]
    async fn test_heartbeat() {
        let scheduler = Scheduler::default();
        let id = scheduler.register_worker(vec![]).await;

        scheduler.heartbeat(id, 50).await;

        let states = scheduler.worker_states().await;
        assert_eq!(states[0].load, 50);
    }

    #[tokio::test]
    async fn test_set_worker_available() {
        let scheduler = Scheduler::default();
        let id = scheduler.register_worker(vec![]).await;

        // Initially available
        let states = scheduler.worker_states().await;
        assert!(states[0].available);

        // Set unavailable
        scheduler.set_worker_available(id, false).await;
        let states = scheduler.worker_states().await;
        assert!(!states[0].available);

        // Worker should not be found
        assert!(scheduler.find_any_worker().await.is_none());
    }

    #[tokio::test]
    async fn test_get_pending() {
        let scheduler = Scheduler::default();
        let worker_id = scheduler.register_worker(vec!["test:v1".to_string()]).await;

        // No pending requests
        assert!(scheduler.get_pending(worker_id).await.is_none());

        // Add a request
        let request = ExecutionRequest::new("test:v1", vec![1, 2, 3]);
        scheduler.submit(request).await.unwrap();

        // Should get the pending request
        let pending = scheduler.get_pending(worker_id).await;
        assert!(pending.is_some());
        assert_eq!(pending.unwrap().layer_ref, "test:v1");
    }

    #[tokio::test]
    async fn test_available_workers() {
        let scheduler = Scheduler::default();
        let id1 = scheduler.register_worker(vec![]).await;
        let id2 = scheduler.register_worker(vec![]).await;

        let available = scheduler.available_workers().await;
        assert_eq!(available.len(), 2);

        // Make one unavailable
        scheduler.set_worker_available(id1, false).await;
        let available = scheduler.available_workers().await;
        assert_eq!(available.len(), 1);
        assert_eq!(available[0], id2);
    }

    #[test]
    fn test_execution_request() {
        let req = ExecutionRequest::new("layer:v1", vec![1, 2, 3]).with_priority(10);
        assert_eq!(req.layer_ref, "layer:v1");
        assert_eq!(req.priority, 10);
        assert_eq!(req.input, vec![1, 2, 3]);
    }

    #[test]
    fn test_worker_id_display() {
        let id = WorkerId(42);
        assert_eq!(format!("{id}"), "worker-42");
    }

    #[test]
    fn test_worker_id_default() {
        let id = WorkerId::default();
        assert_eq!(id.0, 0);
    }

    #[test]
    fn test_worker_state() {
        let state = WorkerState::new(WorkerId(1), vec!["layer:v1".to_string()]);
        assert!(state.can_accept_work());
        assert!(state.has_layer("layer:v1"));
        assert!(!state.has_layer("other:v1"));
    }

    #[test]
    fn test_worker_state_load() {
        let mut state = WorkerState::new(WorkerId(1), vec![]);
        assert!(state.can_accept_work());

        state.load = 100;
        assert!(!state.can_accept_work());
    }

    #[test]
    fn test_scheduler_error_display() {
        let err = SchedulerError::NoWorkers;
        assert_eq!(err.to_string(), "No workers available");

        let err = SchedulerError::WorkerFailed(WorkerId(1), "crashed".to_string());
        assert!(err.to_string().contains("worker-1"));
        assert!(err.to_string().contains("crashed"));

        let err = SchedulerError::Timeout;
        assert_eq!(err.to_string(), "Request timed out");

        let err = SchedulerError::InvalidRequest("bad input".to_string());
        assert!(err.to_string().contains("bad input"));
    }
}
