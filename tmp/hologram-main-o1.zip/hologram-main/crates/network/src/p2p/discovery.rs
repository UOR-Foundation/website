//! Peer discovery service.

use super::protocol::PeerId;
use parking_lot::RwLock;
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use std::time::{SystemTime, UNIX_EPOCH};

/// Discovery event.
#[derive(Debug, Clone)]
pub enum DiscoveryEvent {
    /// A new peer was discovered.
    PeerDiscovered(PeerId),
    /// A peer was lost.
    PeerLost(PeerId),
    /// A layer was announced by a peer.
    LayerAnnounced {
        /// Layer reference.
        layer_ref: String,
        /// Peer providing the layer.
        peer_id: PeerId,
    },
}

/// Record of a layer and its providers.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerRecord {
    /// Layer reference.
    pub layer_ref: String,
    /// Peer IDs that have this layer.
    pub providers: HashSet<PeerId>,
    /// Last update timestamp.
    pub last_updated: u64,
}

impl LayerRecord {
    /// Create a new layer record.
    #[must_use]
    pub fn new(layer_ref: impl Into<String>) -> Self {
        Self {
            layer_ref: layer_ref.into(),
            providers: HashSet::new(),
            last_updated: now_secs(),
        }
    }

    /// Add a provider.
    pub fn add_provider(&mut self, peer_id: PeerId) {
        self.providers.insert(peer_id);
        self.last_updated = now_secs();
    }

    /// Remove a provider.
    pub fn remove_provider(&mut self, peer_id: &PeerId) {
        self.providers.remove(peer_id);
        self.last_updated = now_secs();
    }

    /// Check if there are any providers.
    #[must_use]
    pub fn has_providers(&self) -> bool {
        !self.providers.is_empty()
    }
}

/// Peer info.
#[derive(Debug, Clone)]
struct PeerInfo {
    /// Peer address.
    address: Option<String>,
    /// Last seen timestamp.
    last_seen: u64,
}

/// DHT-based peer discovery system.
pub struct Discovery {
    /// Known peers.
    peers: RwLock<HashMap<PeerId, PeerInfo>>,
    /// Layer records (layer_ref -> record).
    layers: RwLock<HashMap<String, LayerRecord>>,
}

impl Discovery {
    /// Create a new discovery service.
    #[must_use]
    pub fn new() -> Self {
        Self {
            peers: RwLock::new(HashMap::new()),
            layers: RwLock::new(HashMap::new()),
        }
    }

    /// Add a known peer.
    pub fn add_peer(&self, peer_id: PeerId, address: Option<String>) {
        self.peers.write().insert(
            peer_id,
            PeerInfo {
                address,
                last_seen: now_secs(),
            },
        );
    }

    /// Remove a peer.
    pub fn remove_peer(&self, peer_id: &PeerId) {
        self.peers.write().remove(peer_id);

        // Remove from all layer records
        let mut layers = self.layers.write();
        for record in layers.values_mut() {
            record.remove_provider(peer_id);
        }
    }

    /// Update peer's last seen time.
    pub fn touch_peer(&self, peer_id: &PeerId) {
        if let Some(info) = self.peers.write().get_mut(peer_id) {
            info.last_seen = now_secs();
        }
    }

    /// Get all known peer IDs.
    #[must_use]
    pub fn known_peers(&self) -> Vec<PeerId> {
        self.peers.read().keys().copied().collect()
    }

    /// Get peer address.
    #[must_use]
    pub fn peer_address(&self, peer_id: &PeerId) -> Option<String> {
        self.peers
            .read()
            .get(peer_id)
            .and_then(|info| info.address.clone())
    }

    /// Get number of known peers.
    #[must_use]
    pub fn peer_count(&self) -> usize {
        self.peers.read().len()
    }

    /// Record that a peer has a layer.
    pub fn record_layer_provider(&self, layer_ref: &str, peer_id: PeerId) {
        let mut layers = self.layers.write();
        layers
            .entry(layer_ref.to_string())
            .or_insert_with(|| LayerRecord::new(layer_ref))
            .add_provider(peer_id);
    }

    /// Find providers for a layer.
    #[must_use]
    pub fn find_providers(&self, layer_ref: &str) -> Vec<PeerId> {
        self.layers
            .read()
            .get(layer_ref)
            .map(|r| r.providers.iter().copied().collect())
            .unwrap_or_default()
    }

    /// Get all known layer references.
    #[must_use]
    pub fn known_layers(&self) -> Vec<String> {
        self.layers.read().keys().cloned().collect()
    }

    /// Get layer record.
    #[must_use]
    pub fn layer_record(&self, layer_ref: &str) -> Option<LayerRecord> {
        self.layers.read().get(layer_ref).cloned()
    }

    /// Remove stale peers (not seen within timeout).
    pub fn remove_stale_peers(&self, timeout_secs: u64) {
        let cutoff = now_secs().saturating_sub(timeout_secs);
        let stale: Vec<PeerId> = self
            .peers
            .read()
            .iter()
            .filter(|(_, info)| info.last_seen < cutoff)
            .map(|(id, _)| *id)
            .collect();

        for peer_id in stale {
            self.remove_peer(&peer_id);
        }
    }
}

impl Default for Discovery {
    fn default() -> Self {
        Self::new()
    }
}

/// Get current time in seconds since Unix epoch.
fn now_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_discovery_add_peer() {
        let discovery = Discovery::new();
        let peer = PeerId::random();

        discovery.add_peer(peer, Some("127.0.0.1:8080".to_string()));

        let peers = discovery.known_peers();
        assert_eq!(peers.len(), 1);
        assert!(peers.contains(&peer));

        let addr = discovery.peer_address(&peer);
        assert_eq!(addr, Some("127.0.0.1:8080".to_string()));
    }

    #[test]
    fn test_discovery_remove_peer() {
        let discovery = Discovery::new();
        let peer = PeerId::random();

        discovery.add_peer(peer, None);
        assert_eq!(discovery.peer_count(), 1);

        discovery.remove_peer(&peer);
        assert_eq!(discovery.peer_count(), 0);
    }

    #[test]
    fn test_discovery_layer_providers() {
        let discovery = Discovery::new();
        let peer1 = PeerId::random();
        let peer2 = PeerId::random();

        discovery.record_layer_provider("model:v1", peer1);
        discovery.record_layer_provider("model:v1", peer2);
        discovery.record_layer_provider("model:v2", peer1);

        let providers = discovery.find_providers("model:v1");
        assert_eq!(providers.len(), 2);
        assert!(providers.contains(&peer1));
        assert!(providers.contains(&peer2));

        let providers = discovery.find_providers("model:v2");
        assert_eq!(providers.len(), 1);

        let providers = discovery.find_providers("nonexistent");
        assert!(providers.is_empty());
    }

    #[test]
    fn test_discovery_known_layers() {
        let discovery = Discovery::new();
        let peer = PeerId::random();

        discovery.record_layer_provider("model:v1", peer);
        discovery.record_layer_provider("model:v2", peer);

        let layers = discovery.known_layers();
        assert_eq!(layers.len(), 2);
        assert!(layers.contains(&"model:v1".to_string()));
        assert!(layers.contains(&"model:v2".to_string()));
    }

    #[test]
    fn test_discovery_remove_peer_from_layers() {
        let discovery = Discovery::new();
        let peer = PeerId::random();

        discovery.add_peer(peer, None);
        discovery.record_layer_provider("model:v1", peer);

        let providers = discovery.find_providers("model:v1");
        assert_eq!(providers.len(), 1);

        discovery.remove_peer(&peer);

        let providers = discovery.find_providers("model:v1");
        assert!(providers.is_empty());
    }

    #[test]
    fn test_layer_record() {
        let mut record = LayerRecord::new("test:v1");
        let peer1 = PeerId::random();
        let peer2 = PeerId::random();

        assert!(!record.has_providers());

        record.add_provider(peer1);
        record.add_provider(peer2);

        assert!(record.has_providers());
        assert_eq!(record.providers.len(), 2);

        record.remove_provider(&peer1);
        assert_eq!(record.providers.len(), 1);
    }

    #[test]
    fn test_discovery_event() {
        let peer = PeerId::random();

        let event = DiscoveryEvent::PeerDiscovered(peer);
        assert!(matches!(event, DiscoveryEvent::PeerDiscovered(_)));

        let event = DiscoveryEvent::LayerAnnounced {
            layer_ref: "model:v1".to_string(),
            peer_id: peer,
        };
        assert!(matches!(event, DiscoveryEvent::LayerAnnounced { .. }));
    }
}
