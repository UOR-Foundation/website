//! Pre-computed transform cache for layout transformations.
//!
//! This module provides [`TransformCache`] for storing pre-computed layout
//! transformations like Winograd filter transforms and packed weight matrices.
//! All transforms are computed once at plan creation time and referenced by
//! pointer at runtime - zero allocation in hot paths.
//!
//! # Design Philosophy
//!
//! - Transforms are computed once during graph compilation
//! - Runtime execution uses direct pointer references
//! - No reallocation - buffers are stable for the lifetime of the plan
//!
//! # Example
//!
//! ```rust,ignore
//! use hologram_backend::transform_cache::{TransformCache, FilterId};
//!
//! let mut cache = TransformCache::new();
//!
//! // Pre-compute Winograd filter transform
//! let filter_id = FilterId(0);
//! let filter_data = vec![1.0f32; 3 * 3 * 64 * 128];
//! cache.add_winograd_filter(filter_id, &filter_data, [128, 64, 3, 3]);
//!
//! // Access at runtime (zero allocation)
//! let transformed = cache.get_winograd_filter(filter_id);
//! ```

use crate::layout::WinogradVariant;
use rkyv::util::AlignedVec;
use rustc_hash::FxHashMap;

/// Unique identifier for a filter in the cache.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct FilterId(pub u32);

/// Unique identifier for a weight matrix in the cache.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct WeightId(pub u32);

/// Pre-packed Winograd filter.
///
/// Contains the filter transformed into Winograd domain for direct use
/// in Winograd convolution kernels.
#[derive(Debug, Clone)]
pub struct PrepackedFilter {
    /// Transformed filter data.
    pub data: Vec<f32>,
    /// Output channels.
    pub out_channels: usize,
    /// Input channels.
    pub in_channels: usize,
    /// Winograd variant used.
    pub variant: WinogradVariant,
    /// Tile size in the transform domain.
    pub tile_size: usize,
}

impl PrepackedFilter {
    /// Get the transform domain size per filter.
    pub fn transform_size(&self) -> usize {
        self.tile_size * self.tile_size
    }

    /// Get total size in elements.
    pub fn total_elements(&self) -> usize {
        self.out_channels * self.in_channels * self.transform_size()
    }

    /// Get data as slice.
    pub fn as_slice(&self) -> &[f32] {
        &self.data
    }

    /// Get data pointer for FFI/kernel access.
    pub fn as_ptr(&self) -> *const f32 {
        self.data.as_ptr()
    }
}

/// Pre-packed weight matrix for efficient GEMM.
///
/// Contains the weight matrix packed into blocks optimized for
/// the target microkernel (e.g., 6x16 for AVX2).
#[derive(Debug, Clone)]
pub struct PackedWeight {
    /// Packed weight data.
    pub data: AlignedVec<64>,
    /// Original M dimension.
    pub m: usize,
    /// Original K dimension.
    pub k: usize,
    /// Block size in M.
    pub block_m: usize,
    /// Block size in K.
    pub block_k: usize,
    /// Whether this is transposed.
    pub transposed: bool,
    /// Prefetch distance in bytes for micro-kernel hot paths.
    pub prefetch_distance_bytes: usize,
}

impl PackedWeight {
    /// Get data as slice.
    pub fn as_slice(&self) -> &[f32] {
        let len = self.data.len() / std::mem::size_of::<f32>();
        // SAFETY: packed weights are stored as f32 bytes with 64B alignment.
        unsafe { std::slice::from_raw_parts(self.data.as_ptr() as *const f32, len) }
    }

    /// Get data pointer for FFI/kernel access.
    pub fn as_ptr(&self) -> *const f32 {
        self.data.as_ptr() as *const f32
    }

    /// Get total packed size in elements.
    pub fn packed_size(&self) -> usize {
        self.data.len() / std::mem::size_of::<f32>()
    }

    /// Prefetch distance hint (bytes).
    pub fn prefetch_distance(&self) -> usize {
        self.prefetch_distance_bytes
    }
}

/// Cache for pre-computed layout transformations.
///
/// Stores Winograd filter transforms and packed weight matrices for
/// reuse across multiple executions of the same plan.
#[derive(Debug, Default)]
pub struct TransformCache {
    /// Pre-computed Winograd filter transforms.
    winograd_filters: FxHashMap<FilterId, PrepackedFilter>,
    /// Pre-packed weight matrices.
    packed_weights: FxHashMap<WeightId, PackedWeight>,
    /// Next filter ID for auto-assignment.
    next_filter_id: u32,
    /// Next weight ID for auto-assignment.
    next_weight_id: u32,
}

impl TransformCache {
    /// Create a new empty transform cache.
    pub fn new() -> Self {
        Self::default()
    }

    /// Create a cache with pre-allocated capacity.
    pub fn with_capacity(filter_capacity: usize, weight_capacity: usize) -> Self {
        Self {
            winograd_filters: FxHashMap::with_capacity_and_hasher(
                filter_capacity,
                Default::default(),
            ),
            packed_weights: FxHashMap::with_capacity_and_hasher(
                weight_capacity,
                Default::default(),
            ),
            next_filter_id: 0,
            next_weight_id: 0,
        }
    }

    // ========================================================================
    // WINOGRAD FILTER TRANSFORMS
    // ========================================================================

    /// Add a pre-computed Winograd filter transform.
    ///
    /// # Arguments
    /// * `id` - Unique identifier for this filter
    /// * `filter` - Original filter data (OIHW format)
    /// * `shape` - Filter shape [out_channels, in_channels, height, width]
    /// * `variant` - Winograd variant (F23 or F43)
    pub fn add_winograd_filter(
        &mut self,
        id: FilterId,
        filter: &[f32],
        shape: [usize; 4],
        variant: WinogradVariant,
    ) {
        let [out_channels, in_channels, kernel_h, kernel_w] = shape;
        assert_eq!(kernel_h, 3, "Winograd requires 3x3 kernels");
        assert_eq!(kernel_w, 3, "Winograd requires 3x3 kernels");
        assert_eq!(
            filter.len(),
            out_channels * in_channels * 9,
            "Filter size mismatch"
        );

        let tile_size = match variant {
            WinogradVariant::F23 => 4, // F(2,3) uses 4x4 tiles
            WinogradVariant::F43 => 6, // F(4,3) uses 6x6 tiles
        };

        // Transform filter to Winograd domain
        let transformed = transform_filter_winograd(filter, out_channels, in_channels, variant);

        let prepacked = PrepackedFilter {
            data: transformed,
            out_channels,
            in_channels,
            variant,
            tile_size,
        };

        self.winograd_filters.insert(id, prepacked);
    }

    /// Add a Winograd filter and return its auto-assigned ID.
    pub fn add_winograd_filter_auto(
        &mut self,
        filter: &[f32],
        shape: [usize; 4],
        variant: WinogradVariant,
    ) -> FilterId {
        let id = FilterId(self.next_filter_id);
        self.next_filter_id += 1;
        self.add_winograd_filter(id, filter, shape, variant);
        id
    }

    /// Get a pre-computed Winograd filter transform.
    pub fn get_winograd_filter(&self, id: FilterId) -> Option<&PrepackedFilter> {
        self.winograd_filters.get(&id)
    }

    /// Get or compute a Winograd filter transform.
    ///
    /// If the filter is already cached, return it.
    /// Otherwise, compute and cache it.
    pub fn get_or_compute_winograd(
        &mut self,
        id: FilterId,
        filter: &[f32],
        shape: [usize; 4],
        variant: WinogradVariant,
    ) -> &PrepackedFilter {
        if !self.winograd_filters.contains_key(&id) {
            self.add_winograd_filter(id, filter, shape, variant);
        }
        self.winograd_filters.get(&id).unwrap()
    }

    // ========================================================================
    // PACKED WEIGHT MATRICES
    // ========================================================================

    /// Add a pre-packed weight matrix.
    ///
    /// # Arguments
    /// * `id` - Unique identifier for this weight
    /// * `weight` - Original weight data (row-major)
    /// * `m` - Number of rows
    /// * `k` - Number of columns
    /// * `block_m` - Block size in M dimension
    /// * `block_k` - Block size in K dimension
    /// * `transpose` - Whether to transpose during packing
    #[allow(clippy::too_many_arguments)]
    pub fn add_packed_weight(
        &mut self,
        id: WeightId,
        weight: &[f32],
        m: usize,
        k: usize,
        block_m: usize,
        block_k: usize,
        transpose: bool,
    ) {
        assert_eq!(weight.len(), m * k, "Weight size mismatch");

        let packed = pack_weight_matrix(weight, m, k, block_m, block_k, transpose);

        let prepacked = PackedWeight {
            data: packed,
            m,
            k,
            block_m,
            block_k,
            transposed: transpose,
            prefetch_distance_bytes: compute_prefetch_distance(block_m, block_k),
        };

        self.packed_weights.insert(id, prepacked);
    }

    /// Add a packed weight and return its auto-assigned ID.
    pub fn add_packed_weight_auto(
        &mut self,
        weight: &[f32],
        m: usize,
        k: usize,
        block_m: usize,
        block_k: usize,
        transpose: bool,
    ) -> WeightId {
        let id = WeightId(self.next_weight_id);
        self.next_weight_id += 1;
        self.add_packed_weight(id, weight, m, k, block_m, block_k, transpose);
        id
    }

    /// Get or insert a packed weight (avoids redundant packing for same id).
    #[allow(clippy::too_many_arguments)]
    pub fn get_or_pack_weight(
        &mut self,
        id: WeightId,
        weight: &[f32],
        m: usize,
        k: usize,
        block_m: usize,
        block_k: usize,
        transpose: bool,
    ) -> &PackedWeight {
        if !self.packed_weights.contains_key(&id) {
            self.add_packed_weight(id, weight, m, k, block_m, block_k, transpose);
        }
        self.packed_weights.get(&id).expect("packed weight present")
    }

    /// Get a pre-packed weight matrix.
    pub fn get_packed_weight(&self, id: WeightId) -> Option<&PackedWeight> {
        self.packed_weights.get(&id)
    }

    // ========================================================================
    // CACHE MANAGEMENT
    // ========================================================================

    /// Check if the cache contains a Winograd filter.
    pub fn has_winograd_filter(&self, id: FilterId) -> bool {
        self.winograd_filters.contains_key(&id)
    }

    /// Check if the cache contains a packed weight.
    pub fn has_packed_weight(&self, id: WeightId) -> bool {
        self.packed_weights.contains_key(&id)
    }

    /// Remove a Winograd filter from the cache.
    pub fn remove_winograd_filter(&mut self, id: FilterId) -> Option<PrepackedFilter> {
        self.winograd_filters.remove(&id)
    }

    /// Remove a packed weight from the cache.
    pub fn remove_packed_weight(&mut self, id: WeightId) -> Option<PackedWeight> {
        self.packed_weights.remove(&id)
    }

    /// Clear all cached transforms.
    pub fn clear(&mut self) {
        self.winograd_filters.clear();
        self.packed_weights.clear();
    }

    /// Get the number of cached Winograd filters.
    pub fn winograd_filter_count(&self) -> usize {
        self.winograd_filters.len()
    }

    /// Get the number of cached packed weights.
    pub fn packed_weight_count(&self) -> usize {
        self.packed_weights.len()
    }

    /// Get total memory usage in bytes.
    pub fn memory_usage(&self) -> usize {
        let filter_bytes: usize = self
            .winograd_filters
            .values()
            .map(|f| f.data.len() * std::mem::size_of::<f32>())
            .sum();
        let weight_bytes: usize = self
            .packed_weights
            .values()
            .map(|w| w.data.len() * std::mem::size_of::<f32>())
            .sum();
        filter_bytes + weight_bytes
    }

    /// Iterate over all Winograd filters.
    pub fn winograd_filters(&self) -> impl Iterator<Item = (&FilterId, &PrepackedFilter)> {
        self.winograd_filters.iter()
    }

    /// Iterate over all packed weights.
    pub fn packed_weights(&self) -> impl Iterator<Item = (&WeightId, &PackedWeight)> {
        self.packed_weights.iter()
    }
}

// ============================================================================
// TRANSFORM FUNCTIONS
// ============================================================================

/// Transform a 3x3 filter to Winograd domain.
///
/// Applies the Winograd transform G @ g @ G^T where G is the transform matrix.
fn transform_filter_winograd(
    filter: &[f32],
    out_channels: usize,
    in_channels: usize,
    variant: WinogradVariant,
) -> Vec<f32> {
    let tile_size = match variant {
        WinogradVariant::F23 => 4,
        WinogradVariant::F43 => 6,
    };

    let transform_elements = tile_size * tile_size;
    let mut output = vec![0.0f32; out_channels * in_channels * transform_elements];

    // Winograd G matrix for F(2,3)
    // G = [[1, 0, 0],
    //      [1/2, 1/2, 1/2],
    //      [1/2, -1/2, 1/2],
    //      [0, 0, 1]]
    let g_f23: [[f32; 3]; 4] = [
        [1.0, 0.0, 0.0],
        [0.5, 0.5, 0.5],
        [0.5, -0.5, 0.5],
        [0.0, 0.0, 1.0],
    ];

    // Winograd G matrix for F(4,3)
    // More complex, approximated here
    let g_f43: [[f32; 3]; 6] = [
        [1.0, 0.0, 0.0],
        [-2.0 / 9.0, -2.0 / 9.0, -2.0 / 9.0],
        [-2.0 / 9.0, 2.0 / 9.0, -2.0 / 9.0],
        [1.0 / 90.0, 1.0 / 45.0, 2.0 / 45.0],
        [1.0 / 90.0, -1.0 / 45.0, 2.0 / 45.0],
        [0.0, 0.0, 1.0],
    ];

    for oc in 0..out_channels {
        for ic in 0..in_channels {
            let filter_offset = (oc * in_channels + ic) * 9;
            let output_offset = (oc * in_channels + ic) * transform_elements;

            // Extract 3x3 filter
            let g = [
                [
                    filter[filter_offset],
                    filter[filter_offset + 1],
                    filter[filter_offset + 2],
                ],
                [
                    filter[filter_offset + 3],
                    filter[filter_offset + 4],
                    filter[filter_offset + 5],
                ],
                [
                    filter[filter_offset + 6],
                    filter[filter_offset + 7],
                    filter[filter_offset + 8],
                ],
            ];

            match variant {
                WinogradVariant::F23 => {
                    // Compute G @ g @ G^T for F(2,3)
                    // First: temp = G @ g
                    let mut temp = [[0.0f32; 3]; 4];
                    for i in 0..4 {
                        for j in 0..3 {
                            temp[i][j] = g_f23[i][0] * g[0][j]
                                + g_f23[i][1] * g[1][j]
                                + g_f23[i][2] * g[2][j];
                        }
                    }

                    // Then: out = temp @ G^T
                    for i in 0..4 {
                        for j in 0..4 {
                            output[output_offset + i * 4 + j] = temp[i][0] * g_f23[j][0]
                                + temp[i][1] * g_f23[j][1]
                                + temp[i][2] * g_f23[j][2];
                        }
                    }
                }
                WinogradVariant::F43 => {
                    // Compute G @ g @ G^T for F(4,3)
                    let mut temp = [[0.0f32; 3]; 6];
                    for i in 0..6 {
                        for j in 0..3 {
                            temp[i][j] = g_f43[i][0] * g[0][j]
                                + g_f43[i][1] * g[1][j]
                                + g_f43[i][2] * g[2][j];
                        }
                    }

                    for i in 0..6 {
                        for j in 0..6 {
                            output[output_offset + i * 6 + j] = temp[i][0] * g_f43[j][0]
                                + temp[i][1] * g_f43[j][1]
                                + temp[i][2] * g_f43[j][2];
                        }
                    }
                }
            }
        }
    }

    output
}

/// Pack a weight matrix into blocks for efficient GEMM.
///
/// Packing reorders data to improve cache locality in the inner loops.
fn pack_weight_matrix(
    weight: &[f32],
    m: usize,
    k: usize,
    block_m: usize,
    block_k: usize,
    transpose: bool,
) -> AlignedVec<64> {
    // Calculate padded dimensions (block-aligned).
    let padded_m = m.div_ceil(block_m) * block_m;
    let padded_k = k.div_ceil(block_k) * block_k;

    let total_elems = padded_m * padded_k;
    let mut packed: AlignedVec<64> = AlignedVec::new();
    packed.resize(total_elems * std::mem::size_of::<f32>(), 0);
    // SAFETY: packed has capacity for total_elems f32s and is 64-byte aligned.
    let slice =
        unsafe { std::slice::from_raw_parts_mut(packed.as_mut_ptr() as *mut f32, total_elems) };

    if transpose {
        // Pack for B matrix (K x N) -> packed as NxK blocks
        for block_j in (0..padded_k).step_by(block_k) {
            for block_i in (0..padded_m).step_by(block_m) {
                for jj in 0..block_k {
                    for ii in 0..block_m {
                        let i = block_i + ii;
                        let j = block_j + jj;

                        let src_val = if i < m && j < k {
                            weight[j * m + i] // Transposed access
                        } else {
                            0.0
                        };

                        let dst_idx =
                            (block_j / block_k) * (padded_m / block_m) * block_m * block_k
                                + (block_i / block_m) * block_m * block_k
                                + jj * block_m
                                + ii;
                        slice[dst_idx] = src_val;
                    }
                }
            }
        }
    } else {
        // Pack for A matrix (M x K) -> packed as MxK blocks
        for block_i in (0..padded_m).step_by(block_m) {
            for block_j in (0..padded_k).step_by(block_k) {
                for ii in 0..block_m {
                    for jj in 0..block_k {
                        let i = block_i + ii;
                        let j = block_j + jj;

                        let src_val = if i < m && j < k {
                            weight[i * k + j]
                        } else {
                            0.0
                        };

                        let dst_idx =
                            (block_i / block_m) * (padded_k / block_k) * block_m * block_k
                                + (block_j / block_k) * block_m * block_k
                                + ii * block_k
                                + jj;
                        slice[dst_idx] = src_val;
                    }
                }
            }
        }
    }

    packed
}

const ALIGN_BYTES: usize = 64;

fn compute_prefetch_distance(block_m: usize, block_k: usize) -> usize {
    let block_bytes = block_m * block_k * std::mem::size_of::<f32>();
    // Two cache lines ahead, minimum one full block.
    (block_bytes.max(ALIGN_BYTES)) * 2
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_filter_id() {
        let id1 = FilterId(0);
        let id2 = FilterId(1);
        assert_ne!(id1, id2);
    }

    #[test]
    fn test_weight_id() {
        let id1 = WeightId(0);
        let id2 = WeightId(1);
        assert_ne!(id1, id2);
    }

    #[test]
    fn test_transform_cache_new() {
        let cache = TransformCache::new();
        assert_eq!(cache.winograd_filter_count(), 0);
        assert_eq!(cache.packed_weight_count(), 0);
    }

    #[test]
    fn test_add_winograd_filter() {
        let mut cache = TransformCache::new();

        // 3x3 filter with 2 output and 2 input channels
        let filter = vec![1.0f32; 2 * 2 * 9];
        let shape = [2, 2, 3, 3];

        cache.add_winograd_filter(FilterId(0), &filter, shape, WinogradVariant::F23);

        assert!(cache.has_winograd_filter(FilterId(0)));
        assert!(!cache.has_winograd_filter(FilterId(1)));

        let prepacked = cache.get_winograd_filter(FilterId(0)).unwrap();
        assert_eq!(prepacked.out_channels, 2);
        assert_eq!(prepacked.in_channels, 2);
        assert_eq!(prepacked.tile_size, 4);
        assert_eq!(prepacked.total_elements(), 2 * 2 * 16); // 4x4 tiles
    }

    #[test]
    fn test_add_winograd_filter_f43() {
        let mut cache = TransformCache::new();

        let filter = vec![1.0f32; 64 * 64 * 9];
        let shape = [64, 64, 3, 3];

        cache.add_winograd_filter(FilterId(0), &filter, shape, WinogradVariant::F43);

        let prepacked = cache.get_winograd_filter(FilterId(0)).unwrap();
        assert_eq!(prepacked.tile_size, 6);
        assert_eq!(prepacked.total_elements(), 64 * 64 * 36); // 6x6 tiles
    }

    #[test]
    fn test_add_winograd_filter_auto() {
        let mut cache = TransformCache::new();

        let filter = vec![1.0f32; 9];
        let shape = [1, 1, 3, 3];

        let id1 = cache.add_winograd_filter_auto(&filter, shape, WinogradVariant::F23);
        let id2 = cache.add_winograd_filter_auto(&filter, shape, WinogradVariant::F23);

        assert_eq!(id1, FilterId(0));
        assert_eq!(id2, FilterId(1));
    }

    #[test]
    fn test_add_packed_weight() {
        let mut cache = TransformCache::new();

        let weight = vec![1.0f32; 64 * 64];

        cache.add_packed_weight(WeightId(0), &weight, 64, 64, 8, 8, false);

        assert!(cache.has_packed_weight(WeightId(0)));

        let packed = cache.get_packed_weight(WeightId(0)).unwrap();
        assert_eq!(packed.m, 64);
        assert_eq!(packed.k, 64);
        assert_eq!(packed.block_m, 8);
        assert_eq!(packed.block_k, 8);
        assert!(!packed.transposed);
    }

    #[test]
    fn test_add_packed_weight_auto() {
        let mut cache = TransformCache::new();

        let weight = vec![1.0f32; 16];

        let id1 = cache.add_packed_weight_auto(&weight, 4, 4, 2, 2, false);
        let id2 = cache.add_packed_weight_auto(&weight, 4, 4, 2, 2, true);

        assert_eq!(id1, WeightId(0));
        assert_eq!(id2, WeightId(1));
    }

    #[test]
    fn test_get_or_compute_winograd() {
        let mut cache = TransformCache::new();

        let filter = vec![1.0f32; 9];
        let shape = [1, 1, 3, 3];
        let id = FilterId(0);

        // First call computes
        let p1 = cache.get_or_compute_winograd(id, &filter, shape, WinogradVariant::F23);
        let ptr1 = p1.as_ptr();

        // Second call returns cached
        let p2 = cache.get_or_compute_winograd(id, &filter, shape, WinogradVariant::F23);
        let ptr2 = p2.as_ptr();

        // Should be same pointer (cached)
        assert_eq!(ptr1, ptr2);
    }

    #[test]
    fn test_remove_operations() {
        let mut cache = TransformCache::new();

        let filter = vec![1.0f32; 9];
        cache.add_winograd_filter(FilterId(0), &filter, [1, 1, 3, 3], WinogradVariant::F23);

        let weight = vec![1.0f32; 16];
        cache.add_packed_weight(WeightId(0), &weight, 4, 4, 2, 2, false);

        assert_eq!(cache.winograd_filter_count(), 1);
        assert_eq!(cache.packed_weight_count(), 1);

        cache.remove_winograd_filter(FilterId(0));
        assert_eq!(cache.winograd_filter_count(), 0);

        cache.remove_packed_weight(WeightId(0));
        assert_eq!(cache.packed_weight_count(), 0);
    }

    #[test]
    fn test_clear() {
        let mut cache = TransformCache::new();

        let filter = vec![1.0f32; 9];
        cache.add_winograd_filter(FilterId(0), &filter, [1, 1, 3, 3], WinogradVariant::F23);

        let weight = vec![1.0f32; 16];
        cache.add_packed_weight(WeightId(0), &weight, 4, 4, 2, 2, false);

        cache.clear();

        assert_eq!(cache.winograd_filter_count(), 0);
        assert_eq!(cache.packed_weight_count(), 0);
    }

    #[test]
    fn test_memory_usage() {
        let mut cache = TransformCache::new();

        let filter = vec![1.0f32; 9];
        cache.add_winograd_filter(FilterId(0), &filter, [1, 1, 3, 3], WinogradVariant::F23);

        // 1 x 1 x 16 elements x 4 bytes = 64 bytes
        assert_eq!(cache.memory_usage(), 64);
    }

    #[test]
    fn test_iterators() {
        let mut cache = TransformCache::new();

        let filter = vec![1.0f32; 9];
        cache.add_winograd_filter(FilterId(0), &filter, [1, 1, 3, 3], WinogradVariant::F23);
        cache.add_winograd_filter(FilterId(1), &filter, [1, 1, 3, 3], WinogradVariant::F23);

        let weight = vec![1.0f32; 16];
        cache.add_packed_weight(WeightId(0), &weight, 4, 4, 2, 2, false);

        assert_eq!(cache.winograd_filters().count(), 2);
        assert_eq!(cache.packed_weights().count(), 1);
    }

    #[test]
    fn test_winograd_transform_correctness() {
        // Test that the Winograd transform produces the correct output size
        let filter = vec![1.0f32; 64 * 64 * 9];
        let transformed = transform_filter_winograd(&filter, 64, 64, WinogradVariant::F23);

        // F(2,3) produces 4x4 tiles
        assert_eq!(transformed.len(), 64 * 64 * 16);
    }

    #[test]
    fn test_pack_weight_size() {
        // Test that packed weight has correct size
        let weight = vec![1.0f32; 100 * 100];
        let packed = pack_weight_matrix(&weight, 100, 100, 8, 8, false);

        // Padded to 104 x 104 (next multiple of 8)
        assert_eq!(packed.len() / std::mem::size_of::<f32>(), 104 * 104);
    }

    #[test]
    fn test_pack_weight_transpose() {
        let weight = vec![1.0f32; 16];
        let packed_normal = pack_weight_matrix(&weight, 4, 4, 2, 2, false);
        let packed_transposed = pack_weight_matrix(&weight, 4, 4, 2, 2, true);

        // Both should have same size but different layout
        assert_eq!(packed_normal.len(), packed_transposed.len());
    }

    #[test]
    fn test_packed_weight_alignment_and_prefetch() {
        let mut cache = TransformCache::new();
        let weight = vec![1.0f32; 64];
        cache.add_packed_weight(WeightId(0), &weight, 8, 8, 4, 4, false);
        let packed = cache.get_packed_weight(WeightId(0)).unwrap();

        assert_eq!(
            (packed.as_ptr() as usize) % ALIGN_BYTES,
            0,
            "packed weight should be 64B aligned"
        );
        assert!(packed.prefetch_distance() >= ALIGN_BYTES * 2);
    }

    #[test]
    fn test_prepacked_filter_methods() {
        let mut cache = TransformCache::new();

        let filter = vec![1.0f32; 2 * 4 * 9];
        cache.add_winograd_filter(FilterId(0), &filter, [2, 4, 3, 3], WinogradVariant::F23);

        let prepacked = cache.get_winograd_filter(FilterId(0)).unwrap();

        assert_eq!(prepacked.transform_size(), 16);
        assert_eq!(prepacked.total_elements(), 2 * 4 * 16);
        assert!(!prepacked.as_slice().is_empty());
        assert!(!prepacked.as_ptr().is_null());
    }

    #[test]
    fn test_packed_weight_methods() {
        let mut cache = TransformCache::new();

        let weight = vec![1.0f32; 64];
        cache.add_packed_weight(WeightId(0), &weight, 8, 8, 4, 4, false);

        let packed = cache.get_packed_weight(WeightId(0)).unwrap();

        assert!(!packed.as_slice().is_empty());
        assert!(!packed.as_ptr().is_null());
        assert_eq!(packed.packed_size(), 64);
    }
}
