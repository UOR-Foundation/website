//! Registry command: publish to or fetch from a layer registry.

use std::path::{Path, PathBuf};

use clap::{Args, Subcommand};
use hologram_registry::{LayerReference, LocalRegistry, NameIndex};

use crate::error::{CliError, CliResult};

/// Arguments for the registry command.
#[derive(Args, Debug)]
pub struct RegistryArgs {
    #[command(subcommand)]
    pub command: RegistryCommand,
}

/// Registry subcommands.
#[derive(Subcommand, Debug)]
pub enum RegistryCommand {
    /// Publish a layer to the registry
    Publish {
        /// Layer file to publish
        #[arg(value_name = "FILE")]
        file: PathBuf,

        /// Layer name (optional, derived from filename if not provided)
        #[arg(short, long)]
        name: Option<String>,

        /// Version tag
        #[arg(short, long)]
        version: Option<String>,
    },

    /// Fetch a layer from the registry
    Fetch {
        /// Layer reference (hash, name:version, or path)
        #[arg(value_name = "REF")]
        layer_ref: String,

        /// Output path (defaults to current directory)
        #[arg(short, long)]
        output: Option<PathBuf>,
    },

    /// Search for layers in the registry
    Search {
        /// Search query (name pattern)
        #[arg(value_name = "QUERY")]
        query: String,

        /// Maximum results to show
        #[arg(short, long, default_value = "10")]
        limit: u32,
    },

    /// List locally cached layers
    List {
        /// Show detailed information
        #[arg(short, long)]
        detailed: bool,
    },
}

/// Execute the registry command.
pub fn execute(args: RegistryArgs, verbose: bool) -> CliResult<()> {
    match args.command {
        RegistryCommand::Publish {
            file,
            name,
            version,
        } => publish(&file, name.as_deref(), version.as_deref(), verbose),
        RegistryCommand::Fetch { layer_ref, output } => {
            fetch(&layer_ref, output.as_deref(), verbose)
        }
        RegistryCommand::Search { query, limit } => search(&query, limit, verbose),
        RegistryCommand::List { detailed } => list(detailed, verbose),
    }
}

/// Publish a layer to the registry.
fn publish(file: &Path, name: Option<&str>, version: Option<&str>, verbose: bool) -> CliResult<()> {
    if !file.exists() {
        return Err(CliError::FileNotFound(file.to_path_buf()));
    }

    // Read the layer file
    let data = std::fs::read(file)?;

    // Create or open registry at default location
    let registry = LocalRegistry::default_location()?;

    // Store the layer (content-addressed by BLAKE3 hash)
    let hash = registry.store(&data)?;
    let hash_hex = hex::encode(hash);

    // Register name if provided
    if let Some(n) = name {
        let layer_version = version.unwrap_or("latest");
        let mut index = NameIndex::load(&registry.index_path()).unwrap_or_default();
        index.register(None, n, layer_version, &hash);
        index.save(&registry.index_path())?;

        if verbose {
            println!("Registered as: {n}:{layer_version}");
        }
    } else if verbose {
        let layer_name = file
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap_or("unnamed");
        println!("Published {} ({} bytes)", layer_name, data.len());
        println!("Hint: Use --name to register a friendly name");
    }

    // Always print the hash (for scripting)
    println!("blake3:{hash_hex}");
    Ok(())
}

/// Fetch a layer from the registry.
fn fetch(layer_ref: &str, output: Option<&Path>, verbose: bool) -> CliResult<()> {
    // Parse the layer reference
    let reference: LayerReference = layer_ref
        .parse()
        .map_err(|e| CliError::InvalidInput(format!("{e}")))?;

    // Create or open registry
    let registry = LocalRegistry::default_location()?;

    // Resolve and fetch data
    let (data, resolved_hash) = match &reference {
        LayerReference::ByPath(path) => {
            if verbose {
                println!("Reading from path: {}", path.display());
            }
            let data = std::fs::read(path)?;
            let hash = hologram_registry::hash_data(&data);
            (data, hash)
        }
        LayerReference::ByHash(hash) => {
            if verbose {
                println!("Fetching by hash: blake3:{}", hex::encode(hash));
            }
            let data = registry.fetch(hash)?;
            (data, *hash)
        }
        LayerReference::ByName {
            namespace,
            name,
            version,
        } => {
            if verbose {
                let ns_str = namespace.as_deref().unwrap_or("default");
                println!("Resolving name: {ns_str}/{name}:{version}");
            }

            // Load index and resolve
            let index = NameIndex::load(&registry.index_path())?;
            let hash = index
                .lookup(namespace.as_deref(), name, version)
                .ok_or_else(|| {
                    CliError::InvalidInput(format!(
                        "layer not found: {}{}:{}",
                        namespace
                            .as_ref()
                            .map(|ns| format!("{ns}/"))
                            .unwrap_or_default(),
                        name,
                        version
                    ))
                })?;

            if verbose {
                println!("Resolved to: blake3:{}", hex::encode(hash));
            }

            let data = registry.fetch(&hash)?;
            (data, hash)
        }
    };

    let data_len = data.len();

    // Determine output path
    let output_path = match output {
        Some(p) => p.to_path_buf(),
        None => {
            // Generate filename from hash
            let hash_short = &hex::encode(resolved_hash)[..16];
            PathBuf::from(format!("layer_{hash_short}.holb"))
        }
    };

    // Write output
    std::fs::write(&output_path, &data)?;

    if verbose {
        println!("Wrote {} bytes to {}", data_len, output_path.display());
    } else {
        println!("{}", output_path.display());
    }

    Ok(())
}

/// Search for layers in the registry.
fn search(query: &str, limit: u32, verbose: bool) -> CliResult<()> {
    // Create or open registry
    let registry = LocalRegistry::default_location()?;

    // Load index
    let index = NameIndex::load(&registry.index_path()).unwrap_or_default();

    // Search
    let results = index.search(query);

    if results.is_empty() {
        println!("No layers found matching '{query}'");
        return Ok(());
    }

    if verbose {
        println!("Found {} results for '{query}':", results.len());
        println!();
    }

    for (name, hash) in results.iter().take(limit as usize) {
        if verbose {
            println!("  {name}");
            println!("    -> blake3:{hash}");
        } else {
            println!("{name}");
        }
    }

    if results.len() > limit as usize {
        println!(
            "... and {} more (use --limit to see more)",
            results.len() - limit as usize
        );
    }

    Ok(())
}

/// List locally cached layers.
fn list(detailed: bool, verbose: bool) -> CliResult<()> {
    // Create or open registry
    let registry = LocalRegistry::default_location()?;

    // Check if registry exists and has content
    let hashes = registry.list()?;

    if hashes.is_empty() {
        println!("No layers in local registry.");
        println!("Hint: Use 'hologram registry publish' to add layers.");
        return Ok(());
    }

    // Load index for name lookup
    let index = NameIndex::load(&registry.index_path()).unwrap_or_default();
    let reverse_index = index.reverse_lookup();

    if verbose {
        println!("Found {} layers in registry:", hashes.len());
        println!();
    }

    for hash in &hashes {
        let hash_hex = hex::encode(hash);
        let names = reverse_index.get(hash_hex.as_str());

        if detailed {
            // Get blob size
            let blob_path = registry
                .root()
                .join("blobs")
                .join(&hash_hex[..2])
                .join(&hash_hex);
            let size = std::fs::metadata(&blob_path).map(|m| m.len()).unwrap_or(0);

            print!("blake3:{hash_hex}");
            print!("  ({size} bytes)");

            if let Some(names) = names {
                let names_str = names.join(", ");
                print!("  [{names_str}]");
            }
            println!();
        } else if let Some(names) = names {
            // Print first name
            println!("{}", names[0]);
        } else {
            println!("blake3:{hash_hex}");
        }
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    fn with_temp_home<F: FnOnce()>(f: F) {
        // Use a static mutex to ensure only one test modifies HOME at a time
        use std::sync::Mutex;
        static HOME_LOCK: Mutex<()> = Mutex::new(());
        let _guard = HOME_LOCK.lock().unwrap();

        let temp = TempDir::new().unwrap();
        let old_home = std::env::var("HOME").ok();
        std::env::set_var("HOME", temp.path());
        f();
        if let Some(h) = old_home {
            std::env::set_var("HOME", h);
        }
        // temp is dropped here, after HOME is restored
    }

    #[test]
    fn test_publish_file_not_found() {
        with_temp_home(|| {
            let result = publish(Path::new("/nonexistent/file.holb"), None, None, false);
            assert!(matches!(result, Err(CliError::FileNotFound(_))));
        });
    }

    #[test]
    fn test_publish_and_fetch_roundtrip() {
        with_temp_home(|| {
            let temp = TempDir::new().unwrap();
            let test_file = temp.path().join("test.holb");
            let test_data = b"test layer content";
            std::fs::write(&test_file, test_data).unwrap();

            // Publish
            let result = publish(&test_file, Some("test-layer"), Some("v1"), false);
            assert!(result.is_ok());

            // Fetch by name
            let output = temp.path().join("fetched.holb");
            let result = fetch("test-layer:v1", Some(&output), false);
            assert!(result.is_ok());

            // Verify content
            let fetched = std::fs::read(&output).unwrap();
            assert_eq!(fetched, test_data);
        });
    }

    #[test]
    fn test_fetch_not_found() {
        with_temp_home(|| {
            let result = fetch("nonexistent:v1", None, false);
            assert!(result.is_err());
        });
    }

    #[test]
    fn test_search_empty_registry() {
        with_temp_home(|| {
            let result = search("anything", 10, false);
            assert!(result.is_ok());
        });
    }

    #[test]
    fn test_list_empty_registry() {
        with_temp_home(|| {
            let result = list(false, false);
            assert!(result.is_ok());
        });
    }

    #[test]
    fn test_parse_layer_ref_hash() {
        let hash_hex = "ab".repeat(32);
        let ref_str = format!("blake3:{hash_hex}");
        let layer_ref: LayerReference = ref_str.parse().unwrap();
        assert!(layer_ref.is_hash());
    }

    #[test]
    fn test_parse_layer_ref_name() {
        let layer_ref: LayerReference = "my-model:v1".parse().unwrap();
        assert!(layer_ref.is_name());
    }

    #[test]
    fn test_parse_layer_ref_path() {
        let layer_ref: LayerReference = "./local/model.holb".parse().unwrap();
        assert!(layer_ref.is_path());
    }
}
