#!/usr/bin/env python3
"""
Python FFI Example (ctypes-based, ~50-100ns/call)

Demonstrates UOR Rust bindings via high-performance C FFI.

Run:
    python3 examples/python/example.py
"""

from uor_ctypes import UOR, View

def main():
    print("=== UOR Python (ctypes) Example ===\n")

    uor = UOR()

    # Constants
    print(f"Braille base: U+{uor.braille_base:04X}")
    assert uor.braille_base == 0x2800, f"Expected braille_base=0x2800, got {uor.braille_base:04X}"

    print(f"Braille max: U+{uor.braille_max:04X}")
    assert uor.braille_max == 0x28FF, f"Expected braille_max=0x28FF, got {uor.braille_max:04X}"

    print(f"Triadic constant (T): {uor.triadic_constant}")
    assert uor.triadic_constant == 3, f"Expected triadic_constant=3, got {uor.triadic_constant}"

    print(f"Octave constant (O): {uor.octave_constant}")
    assert uor.octave_constant == 8, f"Expected octave_constant=8, got {uor.octave_constant}"

    print(f"State taxons: {uor.state_taxons}")
    assert uor.state_taxons == 624, f"Expected state_taxons=624, got {uor.state_taxons}"

    print(f"State bits: {uor.state_bits}")
    assert uor.state_bits == 4992, f"Expected state_bits=4992, got {uor.state_bits}"
    
    # Taxon Operations
    print("\n--- Taxon Operations ---")
    value = 42
    braille = uor.byte_to_braille(value)
    print(f"byte_to_braille({value}) = '{braille}'")
    assert len(braille) > 0, "byte_to_braille should return non-empty string"

    codepoint = uor.byte_to_codepoint(value)
    print(f"byte_to_codepoint({value}) = {codepoint} (U+{codepoint:04X})")
    assert 0x2800 <= codepoint <= 0x28FF, f"Codepoint {codepoint:04X} out of Braille range"
    assert codepoint == 0x2800 + value, f"Expected codepoint {0x2800 + value:04X}, got {codepoint:04X}"

    domain = uor.byte_to_domain(value)
    print(f"byte_to_domain({value}) = {domain}")
    assert 0 <= domain <= 2, f"Domain {domain} not in valid range [0,2]"

    rank = uor.byte_rank(value)
    print(f"byte_rank({value}) = {rank}")
    assert 0 <= rank < 96, f"Rank {rank} not in valid range [0,96)"
    
    # Ring Operations
    print("\n--- Ring Operations ---")
    succ = uor.byte_succ(value)
    print(f"byte_succ({value}) = {succ}")
    assert succ == 43, f"Expected succ(42)=43, got {succ}"

    pred = uor.byte_pred(value)
    print(f"byte_pred({value}) = {pred}")
    assert pred == 41, f"Expected pred(42)=41, got {pred}"

    notval = uor.byte_not(value)
    print(f"byte_not({value}) = {notval}")
    assert 0 <= notval <= 255, f"NOT value {notval} out of byte range"
    
    # View Operations
    print("\n--- View Operations ---")
    identity = View.identity()
    identity_result = identity.apply(value)
    print(f"identity.apply({value}) = {identity_result}")
    assert identity_result == value, f"Identity should preserve value, got {identity_result}"

    is_bij = identity.is_bijective()
    print(f"identity.is_bijective() = {is_bij}")
    assert is_bij, "Identity view should be bijective"

    constant = View.constant(99)
    const_result = constant.apply(value)
    print(f"constant(99).apply({value}) = {const_result}")
    assert const_result == 99, f"Constant(99) should always return 99, got {const_result}"

    # Composition
    composed = identity.then(constant)
    composed_result = composed.apply(value)
    print(f"identity.then(constant(99)).apply({value}) = {composed_result}")
    assert composed_result == 99, f"identity.then(constant(99)) should return 99, got {composed_result}"

    # Batch Operations
    print("\n--- Batch Operations ---")
    data = bytes([0, 1, 2, 3, 4, 5, 6, 7])
    result = identity.apply_slice(data)
    print(f"identity.apply_slice({list(data)}) = {list(result)}")
    assert list(result) == list(data), f"Identity should preserve array, got {list(result)}"

    # Inverse
    print("\n--- Inverse Operations ---")
    if identity.is_bijective():
        inv = identity.inverse()
        if inv:
            inv_result = inv.apply(value)
            print(f"identity.inverse().apply({value}) = {inv_result}")
            assert inv_result == value, f"identity.inverse() should equal identity, got {inv_result}"

            inv_bij = inv.is_bijective()
            print(f"identity.inverse().is_bijective() = {inv_bij}")
            assert inv_bij, "Inverse of bijective view should be bijective"

    print("\n=== All tests passed! ===")


if __name__ == "__main__":
    main()
