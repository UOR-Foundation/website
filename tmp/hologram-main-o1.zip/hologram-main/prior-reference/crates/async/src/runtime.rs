//! Tokio runtime configuration and management.
//!
//! This module provides utilities for creating and managing the tokio async runtime.

use tokio::runtime::{Builder, Runtime};

/// Configuration for the async runtime.
#[derive(Debug, Clone)]
pub struct RuntimeConfig {
    /// Number of worker threads (None = num_cpus)
    pub worker_threads: Option<usize>,
    /// Enable I/O driver
    pub enable_io: bool,
    /// Enable time driver
    pub enable_time: bool,
    /// Thread name prefix
    pub thread_name: String,
    /// Thread stack size in bytes (None = default)
    pub thread_stack_size: Option<usize>,
}

impl Default for RuntimeConfig {
    fn default() -> Self {
        Self {
            worker_threads: None,
            enable_io: true,
            enable_time: true,
            thread_name: "hologram-async".into(),
            thread_stack_size: None,
        }
    }
}

impl RuntimeConfig {
    /// Create a new runtime configuration with default settings.
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the number of worker threads.
    pub fn with_worker_threads(mut self, threads: usize) -> Self {
        self.worker_threads = Some(threads);
        self
    }

    /// Set whether to enable the I/O driver.
    pub fn with_io(mut self, enable: bool) -> Self {
        self.enable_io = enable;
        self
    }

    /// Set whether to enable the time driver.
    pub fn with_time(mut self, enable: bool) -> Self {
        self.enable_time = enable;
        self
    }

    /// Set the thread name prefix.
    pub fn with_thread_name(mut self, name: impl Into<String>) -> Self {
        self.thread_name = name.into();
        self
    }

    /// Set the thread stack size.
    pub fn with_stack_size(mut self, size: usize) -> Self {
        self.thread_stack_size = Some(size);
        self
    }

    /// Create a configuration for a single-threaded runtime.
    pub fn single_threaded() -> Self {
        Self {
            worker_threads: Some(1),
            enable_io: true,
            enable_time: true,
            thread_name: "hologram-async-single".into(),
            thread_stack_size: None,
        }
    }

    /// Create a configuration optimized for I/O-bound workloads.
    pub fn io_optimized() -> Self {
        Self {
            worker_threads: None,
            enable_io: true,
            enable_time: true,
            thread_name: "hologram-io".into(),
            thread_stack_size: None,
        }
    }
}

/// Create a new tokio runtime with the given configuration.
pub fn create_runtime(config: RuntimeConfig) -> std::io::Result<Runtime> {
    let mut builder = Builder::new_multi_thread();

    if let Some(threads) = config.worker_threads {
        builder.worker_threads(threads);
    }

    if config.enable_io {
        builder.enable_io();
    }

    if config.enable_time {
        builder.enable_time();
    }

    if let Some(stack_size) = config.thread_stack_size {
        builder.thread_stack_size(stack_size);
    }

    builder.thread_name(&config.thread_name).build()
}

/// Get or create a global runtime.
pub fn global_runtime() -> &'static Runtime {
    use std::sync::OnceLock;
    static RUNTIME: OnceLock<Runtime> = OnceLock::new();
    RUNTIME.get_or_init(|| {
        create_runtime(RuntimeConfig::default()).expect("Failed to create global runtime")
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_runtime_config_default() {
        let config = RuntimeConfig::default();
        assert!(config.worker_threads.is_none());
        assert!(config.enable_io);
        assert!(config.enable_time);
        assert_eq!(config.thread_name, "hologram-async");
    }

    #[test]
    fn test_runtime_config_builder() {
        let config = RuntimeConfig::new()
            .with_worker_threads(4)
            .with_io(false)
            .with_time(true)
            .with_thread_name("test-runtime")
            .with_stack_size(2 * 1024 * 1024);

        assert_eq!(config.worker_threads, Some(4));
        assert!(!config.enable_io);
        assert!(config.enable_time);
        assert_eq!(config.thread_name, "test-runtime");
        assert_eq!(config.thread_stack_size, Some(2 * 1024 * 1024));
    }

    #[test]
    fn test_runtime_config_single_threaded() {
        let config = RuntimeConfig::single_threaded();
        assert_eq!(config.worker_threads, Some(1));
    }

    #[test]
    fn test_runtime_config_io_optimized() {
        let config = RuntimeConfig::io_optimized();
        assert!(config.worker_threads.is_none());
        assert!(config.enable_io);
    }

    #[test]
    fn test_create_runtime() {
        let config = RuntimeConfig::new().with_worker_threads(2);
        let runtime = create_runtime(config);
        assert!(runtime.is_ok());
    }

    #[test]
    fn test_create_runtime_single_thread() {
        let config = RuntimeConfig::single_threaded();
        let runtime = create_runtime(config);
        assert!(runtime.is_ok());
    }

    #[test]
    fn test_global_runtime() {
        let runtime1 = global_runtime();
        let runtime2 = global_runtime();
        assert!(std::ptr::eq(runtime1, runtime2));
    }

    #[test]
    fn test_runtime_block_on() {
        let config = RuntimeConfig::new().with_worker_threads(1);
        let runtime = create_runtime(config).unwrap();
        let result = runtime.block_on(async { 42 });
        assert_eq!(result, 42);
    }

    #[test]
    fn test_runtime_spawn() {
        let config = RuntimeConfig::new().with_worker_threads(2);
        let runtime = create_runtime(config).unwrap();
        let result = runtime.block_on(async {
            let handle = tokio::spawn(async { 100 });
            handle.await.unwrap()
        });
        assert_eq!(result, 100);
    }
}
