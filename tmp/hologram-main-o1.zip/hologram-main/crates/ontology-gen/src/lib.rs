//! Ontology type generation from JSON-LD schemas.
//!
//! This crate generates Rust types from JSON-LD schema definitions at build time.
//! The primary type is `Datum16`, representing a 16-bit value with computed observables.
//!
//! # Generated Types
//!
//! - `Datum16`: Q1 datum (16-bit) with stratum, spectrum, glyph, curvature
//! - `all_q1_datums()`: Iterator over all 65536 Q1 datums
//!
//! # Example
//!
//! ```
//! use ontology_gen::{Datum16, all_q1_datums};
//!
//! let datum = Datum16::from_value(0x1234);
//! assert_eq!(datum.high_byte(), 0x12);
//! assert_eq!(datum.low_byte(), 0x34);
//! assert_eq!(datum.stratum(), 5); // popcount(0x1234) = 5
//!
//! // Iterate over all datums
//! for datum in all_q1_datums().take(10) {
//!     println!("{}: stratum={}", datum.value, datum.stratum());
//! }
//! ```
//!
//! # JSON-LD Emission
//!
//! Generate Q1 datum files as JSON-LD:
//!
//! ```no_run
//! use ontology_gen::emit_q1_datums;
//! use std::path::Path;
//!
//! emit_q1_datums(Path::new("/tmp/q1")).unwrap();
//! // Creates 256 files: datum_00xx.jsonld through datum_ffxx.jsonld
//! ```

use std::fs::File;
use std::io::{self, Write};
use std::path::Path;

// Include build-time generated code
include!(concat!(env!("OUT_DIR"), "/generated.rs"));

// Include SHACL-generated types and validators
include!(concat!(env!("OUT_DIR"), "/generated_shacl.rs"));

/// Emit all Q1 datums as chunked JSON-LD files.
///
/// Creates 256 files in the output directory, each containing 256 datums.
/// File naming: `datum_00xx.jsonld` through `datum_ffxx.jsonld`.
///
/// # Arguments
///
/// * `output_dir` - Directory to write JSON-LD files
///
/// # Errors
///
/// Returns IO error if file creation or writing fails.
pub fn emit_q1_datums(output_dir: &Path) -> io::Result<()> {
    std::fs::create_dir_all(output_dir)?;

    for high_byte in 0..=255u8 {
        let filename = format!("datum_{:02x}xx.jsonld", high_byte);
        let file_path = output_dir.join(&filename);
        let mut file = File::create(&file_path)?;

        // Build datums array for this file
        let mut datums = Vec::with_capacity(256);
        for low_byte in 0..=255u8 {
            let value = ((high_byte as u16) << 8) | (low_byte as u16);
            datums.push(Datum16::from_value(value).to_jsonld());
        }

        // Create JSON-LD document
        let doc = serde_json::json!({
            "@context": {
                "datum": "https://uor.foundation/datum/",
                "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
                "xsd": "http://www.w3.org/2001/XMLSchema#"
            },
            "@id": format!("datum:q1/block/{:02x}", high_byte),
            "rdfs:label": format!("Q1 Datum Block 0x{:02X}xx", high_byte),
            "@graph": datums
        });

        serde_json::to_writer_pretty(&mut file, &doc)?;
        file.write_all(b"\n")?;
    }

    Ok(())
}

/// Emit a single Q1 datum as JSON-LD.
pub fn emit_datum_jsonld(datum: &Datum16) -> serde_json::Value {
    datum.to_jsonld()
}

/// Compute Q1 scaling statistics (mean curvature, stratum distribution).
pub fn compute_q1_statistics() -> Q1Statistics {
    let mut total_curvature: u64 = 0;
    let mut stratum_counts = [0u32; 17]; // 0-16 strata

    for datum in all_q1_datums() {
        total_curvature += datum.curvature() as u64;
        stratum_counts[datum.stratum() as usize] += 1;
    }

    let mean_curvature = total_curvature as f64 / CARDINALITY as f64;

    Q1Statistics {
        mean_curvature,
        stratum_counts,
    }
}

/// Statistics computed over all Q1 datums.
#[derive(Debug, Clone)]
pub struct Q1Statistics {
    /// Mean curvature across all datums.
    pub mean_curvature: f64,
    /// Count of datums at each stratum (0-16).
    pub stratum_counts: [u32; 17],
}

impl Q1Statistics {
    /// Convert to JSON-LD certificate format.
    pub fn to_jsonld(&self) -> serde_json::Value {
        serde_json::json!({
            "@context": {
                "datum": "https://uor.foundation/datum/",
                "cert": "https://uor.foundation/certificate/"
            },
            "@type": "cert:Q1ScalingCertificate",
            "cert:meanCurvature": self.mean_curvature,
            "cert:stratumDistribution": self.stratum_counts.to_vec(),
            "cert:cardinality": CARDINALITY
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_datum16_basic() {
        let datum = Datum16::from_value(0x1234);
        assert_eq!(datum.value, 0x1234);
        assert_eq!(datum.high_byte(), 0x12);
        assert_eq!(datum.low_byte(), 0x34);
    }

    #[test]
    fn test_datum16_from_bytes() {
        let datum = Datum16::from_bytes(0xAB, 0xCD);
        assert_eq!(datum.value, 0xABCD);
    }

    #[test]
    fn test_stratum() {
        assert_eq!(Datum16::from_value(0).stratum(), 0);
        assert_eq!(Datum16::from_value(1).stratum(), 1);
        assert_eq!(Datum16::from_value(0xFF).stratum(), 8);
        assert_eq!(Datum16::from_value(0xFFFF).stratum(), 16);
    }

    #[test]
    fn test_curvature() {
        // Curvature of 0 is popcount(0 XOR 1) = popcount(1) = 1
        assert_eq!(Datum16::from_value(0).curvature(), 1);
        // Curvature of 1 is popcount(1 XOR 2) = popcount(3) = 2
        assert_eq!(Datum16::from_value(1).curvature(), 2);
        // Curvature of 0xFF is popcount(0xFF XOR 0x100) = popcount(0x1FF) = 9
        assert_eq!(Datum16::from_value(0xFF).curvature(), 9);
    }

    #[test]
    fn test_spectrum() {
        let datum = Datum16::from_value(0b1010_0101);
        let spectrum = datum.spectrum();
        assert_eq!(spectrum, vec![0, 2, 5, 7]);
    }

    #[test]
    fn test_spectrum_string() {
        let datum = Datum16::from_value(0b1010_0101);
        assert_eq!(datum.spectrum_string(), "0,2,5,7");
    }

    #[test]
    fn test_glyph() {
        let datum = Datum16::from_value(0);
        let glyph = datum.glyph();
        assert_eq!(glyph.chars().count(), 2);
        assert!(glyph
            .chars()
            .all(|c| ('\u{2800}'..='\u{28FF}').contains(&c)));
    }

    #[test]
    fn test_all_datums_iterator() {
        let count = all_q1_datums().count();
        assert_eq!(count, 65536);
    }

    #[test]
    fn test_all_datums_exact_size() {
        let iter = all_q1_datums();
        assert_eq!(iter.len(), 65536);
    }

    #[test]
    fn test_to_jsonld() {
        let datum = Datum16::from_value(0x1234);
        let json = datum.to_jsonld();

        assert_eq!(json["@type"], "datum:Q1Datum");
        assert_eq!(json["datum:value"], 0x1234);
        assert!(json["datum:stratum"].is_number());
        assert!(json["datum:glyph"].is_string());
    }

    #[test]
    fn test_statistics() {
        let stats = compute_q1_statistics();

        // Mean curvature should be approximately 2.0
        assert!(stats.mean_curvature > 1.9 && stats.mean_curvature < 2.1);

        // Stratum distribution should follow binomial coefficients
        // C(16, 0) = 1, C(16, 1) = 16, ..., C(16, 8) = 12870, ...
        assert_eq!(stats.stratum_counts[0], 1);
        assert_eq!(stats.stratum_counts[1], 16);
        assert_eq!(stats.stratum_counts[8], 12870);
        assert_eq!(stats.stratum_counts[16], 1);

        // Total should be 65536
        let total: u32 = stats.stratum_counts.iter().sum();
        assert_eq!(total, 65536);
    }

    // ====================================================================
    // SHACL-generated type tests
    // ====================================================================

    #[test]
    fn validate_q1_datum_valid() {
        let datum = Datum16::from_value(0x1234);
        assert!(validate_q1_datum(&datum).is_ok());
    }

    #[test]
    fn validate_q1_datum_boundary() {
        // Datum16 value is always 0-65535 by type
        // Stratum is always 0-16 by LUT
        // Curvature is always 1-17 by LUT
        let datum = Datum16::from_value(0);
        assert!(validate_q1_datum(&datum).is_ok());
        let datum = Datum16::from_value(0xFFFF);
        assert!(validate_q1_datum(&datum).is_ok());
    }

    #[test]
    fn derivation_step_dto_valid() {
        let step = DerivationStepDto {
            index: 0,
            label: "test step".into(),
            kind: DerivationStepKind::TypeDeclaration,
            input: serde_json::json!(42),
            output: serde_json::json!("result"),
        };
        assert!(step.validate().is_ok());
    }

    #[test]
    fn derivation_step_kind_all_variants() {
        let kinds = [
            DerivationStepKind::TypeDeclaration,
            DerivationStepKind::QuantumSelection,
            DerivationStepKind::StepPrediction,
            DerivationStepKind::OrbitGeneration,
            DerivationStepKind::CoordinateReading,
            DerivationStepKind::FactorCompletion,
            DerivationStepKind::CertificateEmission,
            DerivationStepKind::Gcd,
            DerivationStepKind::IntegerDivision,
            DerivationStepKind::Compute,
        ];
        assert_eq!(kinds.len(), 10);
    }

    #[test]
    fn derivation_step_kind_from_str() {
        let kind: DerivationStepKind = "type_declaration".parse().unwrap();
        assert_eq!(kind, DerivationStepKind::TypeDeclaration);
        let kind: DerivationStepKind = "compute".parse().unwrap();
        assert_eq!(kind, DerivationStepKind::Compute);
        assert!("invalid".parse::<DerivationStepKind>().is_err());
    }

    #[test]
    fn factorization_result_valid() {
        let result = FactorizationResultDto {
            semiprime: 10403,
            factor_p: 101,
            factor_q: 103,
            quantum: 0,
            verified: true,
        };
        assert!(result.validate().is_ok());
    }

    #[test]
    fn factorization_result_invalid_zero_semiprime() {
        let result = FactorizationResultDto {
            semiprime: 0,
            factor_p: 101,
            factor_q: 103,
            quantum: 0,
            verified: true,
        };
        let violations = result.validate().unwrap_err();
        assert!(violations.iter().any(|v| v.property == "semiprime"));
    }

    #[test]
    fn factorization_result_invalid_zero_factors() {
        let result = FactorizationResultDto {
            semiprime: 10403,
            factor_p: 0,
            factor_q: 0,
            quantum: 0,
            verified: true,
        };
        let violations = result.validate().unwrap_err();
        assert!(violations.iter().any(|v| v.property == "factor_p"));
        assert!(violations.iter().any(|v| v.property == "factor_q"));
    }

    #[test]
    fn derivation_chain_dto_valid() {
        let chain = DerivationChainDto {
            label: "test chain".into(),
            timestamp: "2024-01-01T00:00:00Z".into(),
            step_count: 5,
            steps: serde_json::json!([]),
        };
        assert!(chain.validate().is_ok());
    }

    #[test]
    fn winding_number_dto_valid() {
        let w = WindingNumberDto { value: -3 };
        assert!(w.validate().is_ok());
    }

    #[test]
    fn total_variation_dto_valid() {
        let tv = TotalVariationDto { value: 42 };
        assert!(tv.validate().is_ok());
    }

    #[test]
    fn cascade_spectrum_dto_valid() {
        let cs = CascadeSpectrumDto {
            bins: serde_json::json!([4, 2, 1]),
        };
        assert!(cs.validate().is_ok());
    }

    #[test]
    fn monodromy_signature_dto_valid() {
        let ms = MonodromySignatureDto {
            winding: -3,
            total_variation: 42,
            cascade_spectrum: serde_json::json!({"bins": [4, 2, 1]}),
        };
        assert!(ms.validate().is_ok());
    }

    #[test]
    fn scaling_certificate_dto_valid() {
        let cert = Q1ScalingCertificateDto {
            mean_curvature: 2.0,
            stratum_distribution: serde_json::json!([1, 16, 120]),
            cardinality: 65536,
        };
        assert!(cert.validate().is_ok());
    }

    #[test]
    fn scaling_certificate_invalid_zero_cardinality() {
        let cert = Q1ScalingCertificateDto {
            mean_curvature: 2.0,
            stratum_distribution: serde_json::json!([1, 16, 120]),
            cardinality: 0,
        };
        let violations = cert.validate().unwrap_err();
        assert!(violations.iter().any(|v| v.property == "cardinality"));
    }

    #[test]
    fn factorization_result_try_from_json() {
        let json = serde_json::json!({
            "derivation:semiprime": 10403,
            "derivation:factor_p": 101,
            "derivation:factor_q": 103,
            "derivation:quantum": 0,
            "derivation:verified": true
        });
        let result = FactorizationResultDto::try_from(json).unwrap();
        assert_eq!(result.semiprime, 10403);
        assert_eq!(result.factor_p, 101);
        assert_eq!(result.factor_q, 103);
        assert!(result.verified);
    }

    #[test]
    fn winding_number_try_from_json() {
        let json = serde_json::json!({ "observable:value": -5 });
        let w = WindingNumberDto::try_from(json).unwrap();
        assert_eq!(w.value, -5);
    }

    #[test]
    fn derivation_step_kind_serde_roundtrip() {
        let kind = DerivationStepKind::OrbitGeneration;
        let json = serde_json::to_string(&kind).unwrap();
        assert_eq!(json, "\"orbit_generation\"");
        let back: DerivationStepKind = serde_json::from_str(&json).unwrap();
        assert_eq!(back, kind);
    }

    // ====================================================================
    // Mining DTO tests
    // ====================================================================

    fn valid_hash_hex() -> String {
        "a".repeat(64)
    }

    #[test]
    fn block_header_dto_valid() {
        let header = BlockHeaderDto {
            version: 2,
            prev_block_hash: valid_hash_hex(),
            merkle_root: valid_hash_hex(),
            timestamp: 1_700_000_000,
            bits: 0x1d00_ffff,
            nonce: 42,
        };
        assert!(header.validate().is_ok());
    }

    #[test]
    fn block_header_dto_invalid_hash_length() {
        let header = BlockHeaderDto {
            version: 2,
            prev_block_hash: "abc".into(),
            merkle_root: valid_hash_hex(),
            timestamp: 1_700_000_000,
            bits: 0x1d00_ffff,
            nonce: 0,
        };
        let violations = header.validate().unwrap_err();
        assert!(violations.iter().any(|v| v.property == "prevBlockHash"));
    }

    #[test]
    fn block_header_dto_invalid_merkle_length() {
        let header = BlockHeaderDto {
            version: 2,
            prev_block_hash: valid_hash_hex(),
            merkle_root: "too_short".into(),
            timestamp: 1_700_000_000,
            bits: 0x1d00_ffff,
            nonce: 0,
        };
        let violations = header.validate().unwrap_err();
        assert!(violations.iter().any(|v| v.property == "merkleRoot"));
    }

    #[test]
    fn mining_config_dto_valid() {
        let config = MiningConfigDto {
            required_zero_bytes: 3,
            nonce_start: 0,
            nonce_end: 1_000_000,
            chunk_size: 4096,
        };
        assert!(config.validate().is_ok());
    }

    #[test]
    fn mining_config_dto_invalid_zero_bytes_zero() {
        let config = MiningConfigDto {
            required_zero_bytes: 0,
            nonce_start: 0,
            nonce_end: 1_000_000,
            chunk_size: 4096,
        };
        let violations = config.validate().unwrap_err();
        assert!(violations.iter().any(|v| v.property == "requiredZeroBytes"));
    }

    #[test]
    fn mining_config_dto_invalid_zero_bytes_too_large() {
        let config = MiningConfigDto {
            required_zero_bytes: 33,
            nonce_start: 0,
            nonce_end: 1_000_000,
            chunk_size: 4096,
        };
        let violations = config.validate().unwrap_err();
        assert!(violations.iter().any(|v| v.property == "requiredZeroBytes"));
    }

    #[test]
    fn mining_config_dto_invalid_chunk_size_zero() {
        let config = MiningConfigDto {
            required_zero_bytes: 3,
            nonce_start: 0,
            nonce_end: 1_000_000,
            chunk_size: 0,
        };
        let violations = config.validate().unwrap_err();
        assert!(violations.iter().any(|v| v.property == "chunkSize"));
    }

    #[test]
    fn mining_config_dto_boundary_values() {
        // Min boundary
        let config = MiningConfigDto {
            required_zero_bytes: 1,
            nonce_start: 0,
            nonce_end: 0,
            chunk_size: 1,
        };
        assert!(config.validate().is_ok());

        // Max boundary
        let config = MiningConfigDto {
            required_zero_bytes: 32,
            nonce_start: u32::MAX,
            nonce_end: u32::MAX,
            chunk_size: u32::MAX,
        };
        assert!(config.validate().is_ok());
    }

    #[test]
    fn mining_result_dto_valid() {
        let result = MiningResultDto {
            nonce: 42,
            hash: valid_hash_hex(),
            found: true,
        };
        assert!(result.validate().is_ok());
    }

    #[test]
    fn mining_result_dto_invalid_hash_length() {
        let result = MiningResultDto {
            nonce: 42,
            hash: "short".into(),
            found: true,
        };
        let violations = result.validate().unwrap_err();
        assert!(violations.iter().any(|v| v.property == "hash"));
    }

    #[test]
    fn mining_result_dto_not_found() {
        let result = MiningResultDto {
            nonce: 0,
            hash: "0".repeat(64),
            found: false,
        };
        assert!(result.validate().is_ok());
    }

    #[test]
    fn block_header_try_from_json() {
        let json = serde_json::json!({
            "mining:version": 2,
            "mining:prevBlockHash": valid_hash_hex(),
            "mining:merkleRoot": valid_hash_hex(),
            "mining:timestamp": 1_700_000_000u64,
            "mining:bits": 0x1d00_ffffu64,
            "mining:nonce": 42
        });
        let header = BlockHeaderDto::try_from(json).unwrap();
        assert_eq!(header.version, 2);
        assert_eq!(header.nonce, 42);
    }

    #[test]
    fn mining_config_try_from_json() {
        let json = serde_json::json!({
            "mining:requiredZeroBytes": 3,
            "mining:nonceStart": 0,
            "mining:nonceEnd": 1_000_000,
            "mining:chunkSize": 4096
        });
        let config = MiningConfigDto::try_from(json).unwrap();
        assert_eq!(config.required_zero_bytes, 3);
        assert_eq!(config.chunk_size, 4096);
    }

    #[test]
    fn mining_result_try_from_json() {
        let json = serde_json::json!({
            "mining:nonce": 42,
            "mining:hash": valid_hash_hex(),
            "mining:found": true
        });
        let result = MiningResultDto::try_from(json).unwrap();
        assert_eq!(result.nonce, 42);
        assert!(result.found);
    }

    #[test]
    fn mining_config_serde_roundtrip() {
        let config = MiningConfigDto {
            required_zero_bytes: 3,
            nonce_start: 0,
            nonce_end: 1_000_000,
            chunk_size: 4096,
        };
        let json = serde_json::to_string(&config).unwrap();
        let back: MiningConfigDto = serde_json::from_str(&json).unwrap();
        assert_eq!(config, back);
    }

    #[test]
    fn mining_result_serde_roundtrip() {
        let result = MiningResultDto {
            nonce: 42,
            hash: valid_hash_hex(),
            found: true,
        };
        let json = serde_json::to_string(&result).unwrap();
        let back: MiningResultDto = serde_json::from_str(&json).unwrap();
        assert_eq!(result, back);
    }
}
