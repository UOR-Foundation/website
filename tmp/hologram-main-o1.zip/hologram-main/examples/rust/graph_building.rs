//! Graph building example.
//!
//! Demonstrates how to build operation graphs programmatically and compile them.
//!
//! Run with: `cargo run --example graph_building`

use hologram_compiler::{compile, CompilerConfig, DType, OpKind, OpNode, OperationGraph};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("=== Graph Building Example ===\n");

    // Example 1: Simple linear layer (MatMul + Bias + ReLU)
    println!("--- Building a Linear Layer ---");
    let linear_graph = build_linear_layer();
    print_graph_info(&linear_graph);
    compile_and_show(&linear_graph)?;

    // Example 2: Multi-layer network
    println!("\n--- Building a Multi-Layer Network ---");
    let mlp_graph = build_mlp();
    print_graph_info(&mlp_graph);
    compile_and_show(&mlp_graph)?;

    // Example 3: Matrix multiplication
    println!("\n--- Building a Matrix Multiplication ---");
    let matmul_graph = build_matmul_example();
    print_graph_info(&matmul_graph);
    compile_and_show(&matmul_graph)?;

    // Example 4: Reduction pipeline (dot product)
    println!("\n--- Building a Reduction Pipeline (Dot Product) ---");
    let reduction_graph = build_reduction_pipeline();
    print_graph_info(&reduction_graph);
    compile_and_show(&reduction_graph)?;

    Ok(())
}

/// Build a simple activation chain: y = sigmoid(tanh(relu(x)))
fn build_linear_layer() -> OperationGraph {
    let mut graph = OperationGraph::new();

    // Input: vector of 16 features
    let input = graph.add_node(OpNode::new(0, OpKind::Input, vec![16], DType::F32));

    // ReLU activation
    let relu = graph.add_node(OpNode::new(1, OpKind::Relu, vec![16], DType::F32));
    graph.add_edge(input, relu);

    // Tanh activation
    let tanh = graph.add_node(OpNode::new(2, OpKind::Tanh, vec![16], DType::F32));
    graph.add_edge(relu, tanh);

    // Sigmoid activation
    let sigmoid = graph.add_node(OpNode::new(3, OpKind::Sigmoid, vec![16], DType::F32));
    graph.add_edge(tanh, sigmoid);

    // Output
    let output = graph.add_node(OpNode::new(4, OpKind::Output, vec![16], DType::F32));
    graph.add_edge(sigmoid, output);

    // Register I/O
    graph.add_input("x", input);
    graph.add_output("y", output);

    graph
}

/// Build an element-wise computation: y = (a * b) + c
fn build_mlp() -> OperationGraph {
    let mut graph = OperationGraph::new();

    // Three inputs of same shape
    let input_a = graph.add_node(OpNode::new(0, OpKind::Input, vec![64], DType::F32));
    let input_b = graph.add_node(OpNode::new(1, OpKind::Input, vec![64], DType::F32));
    let input_c = graph.add_node(OpNode::new(2, OpKind::Input, vec![64], DType::F32));

    // Multiply a * b
    let mul = graph.add_node(OpNode::new(3, OpKind::Mul, vec![64], DType::F32));
    graph.add_edge(input_a, mul);
    graph.add_edge(input_b, mul);

    // Add (a * b) + c
    let add = graph.add_node(OpNode::new(4, OpKind::Add, vec![64], DType::F32));
    graph.add_edge(mul, add);
    graph.add_edge(input_c, add);

    // Apply ReLU
    let relu = graph.add_node(OpNode::new(5, OpKind::Relu, vec![64], DType::F32));
    graph.add_edge(add, relu);

    // Output
    let output = graph.add_node(OpNode::new(6, OpKind::Output, vec![64], DType::F32));
    graph.add_edge(relu, output);

    // Register I/O
    graph.add_input("a", input_a);
    graph.add_input("b", input_b);
    graph.add_input("c", input_c);
    graph.add_output("result", output);

    graph
}

/// Build a matrix multiplication example: C = A @ B
fn build_matmul_example() -> OperationGraph {
    let mut graph = OperationGraph::new();

    // Matrix A: 4x8 (m=4, k=8)
    let input_a = graph.add_node(OpNode::new(0, OpKind::Input, vec![4, 8], DType::F32));

    // Matrix B: 8x16 (k=8, n=16)
    let input_b = graph.add_node(OpNode::new(1, OpKind::Input, vec![8, 16], DType::F32));

    // MatMul: C = A @ B -> 4x16 (m=4, n=16)
    let matmul = graph.add_node(OpNode::new(
        2,
        OpKind::MatMul { m: 4, k: 8, n: 16 },
        vec![4, 16],
        DType::F32,
    ));
    graph.add_edge(input_a, matmul);
    graph.add_edge(input_b, matmul);

    // Apply ReLU to result
    let relu = graph.add_node(OpNode::new(3, OpKind::Relu, vec![4, 16], DType::F32));
    graph.add_edge(matmul, relu);

    // Output
    let output = graph.add_node(OpNode::new(4, OpKind::Output, vec![4, 16], DType::F32));
    graph.add_edge(relu, output);

    // Register I/O
    graph.add_input("A", input_a);
    graph.add_input("B", input_b);
    graph.add_output("C", output);

    graph
}

/// Build a reduction pipeline: input -> mul -> sum -> output
fn build_reduction_pipeline() -> OperationGraph {
    let mut graph = OperationGraph::new();

    // Two inputs
    let input_a = graph.add_node(OpNode::new(0, OpKind::Input, vec![1024], DType::F32));
    let input_b = graph.add_node(OpNode::new(1, OpKind::Input, vec![1024], DType::F32));

    // Element-wise multiply
    let mul = graph.add_node(OpNode::new(2, OpKind::Mul, vec![1024], DType::F32));
    graph.add_edge(input_a, mul);
    graph.add_edge(input_b, mul);

    // Sum reduction
    let sum = graph.add_node(OpNode::new(3, OpKind::Sum, vec![1], DType::F32));
    graph.add_edge(mul, sum);

    // Output (dot product result)
    let output = graph.add_node(OpNode::new(4, OpKind::Output, vec![1], DType::F32));
    graph.add_edge(sum, output);

    // Register I/O
    graph.add_input("a", input_a);
    graph.add_input("b", input_b);
    graph.add_output("dot_product", output);

    graph
}

/// Print graph statistics.
fn print_graph_info(graph: &OperationGraph) {
    println!("  Nodes: {}", graph.node_count());
    println!("  Edges: {}", graph.edge_count());
    println!(
        "  Inputs: {:?}",
        graph.inputs.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );
    println!(
        "  Outputs: {:?}",
        graph.outputs.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );
    println!("  Constants: {}", graph.constants.len());
}

/// Compile the graph and show plan info.
fn compile_and_show(graph: &OperationGraph) -> Result<(), Box<dyn std::error::Error>> {
    let config = CompilerConfig::default();
    let plan = compile(graph, &config)?;

    println!("  Compiled plan:");
    println!("    Instructions: {}", plan.instructions.len());
    println!("    Buffers: {}", plan.buffers.len());
    println!("    Workspace: {} bytes", plan.workspace_size);

    Ok(())
}
