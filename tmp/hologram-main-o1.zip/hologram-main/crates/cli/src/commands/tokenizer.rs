//! Tokenizer command: compile tokenizer.json to .holo format.

use std::path::PathBuf;
use std::time::Instant;

use clap::{Args, Subcommand};
use hologram_tokenizer::compile_tokenizer;
use owo_colors::OwoColorize;

use crate::error::{CliError, CliResult};

/// Arguments for the tokenizer command.
#[derive(Args, Debug)]
pub struct TokenizerArgs {
    #[command(subcommand)]
    pub command: TokenizerCommand,
}

/// Tokenizer subcommands.
#[derive(Subcommand, Debug)]
pub enum TokenizerCommand {
    /// Compile a tokenizer.json file to .holo format
    Compile(CompileTokenizerArgs),

    /// Show information about a compiled tokenizer
    Info(InfoArgs),
}

/// Arguments for compile-tokenizer subcommand.
#[derive(Args, Debug)]
pub struct CompileTokenizerArgs {
    /// Input tokenizer.json file (HuggingFace format)
    #[arg(value_name = "INPUT")]
    pub input: PathBuf,

    /// Output .holo file path
    #[arg(short, long, value_name = "OUTPUT")]
    pub output: Option<PathBuf>,
}

/// Arguments for tokenizer info subcommand.
#[derive(Args, Debug)]
pub struct InfoArgs {
    /// Compiled tokenizer .holo file
    #[arg(value_name = "FILE")]
    pub file: PathBuf,
}

/// Execute the tokenizer command.
pub fn execute(args: TokenizerArgs, verbose: bool) -> CliResult<()> {
    match args.command {
        TokenizerCommand::Compile(compile_args) => execute_compile(compile_args, verbose),
        TokenizerCommand::Info(info_args) => execute_info(info_args, verbose),
    }
}

/// Execute the compile subcommand.
fn execute_compile(args: CompileTokenizerArgs, verbose: bool) -> CliResult<()> {
    // Verify input file exists
    if !args.input.exists() {
        return Err(CliError::FileNotFound(args.input));
    }

    // Determine output path
    let output = args
        .output
        .unwrap_or_else(|| args.input.with_extension("holo"));

    let start = Instant::now();

    if verbose {
        println!(
            "{} {} -> {}",
            "Compiling tokenizer".green().bold(),
            args.input.display(),
            output.display()
        );
        println!();
    }

    // Compile the tokenizer
    compile_tokenizer(&args.input, &output)
        .map_err(|e| CliError::CompilationFailed(format!("tokenizer compilation failed: {e}")))?;

    let elapsed = start.elapsed();
    let file_size = std::fs::metadata(&output)?.len();

    if verbose {
        println!("{}", "Compilation Complete:".green().bold());
        println!("    {} {}", "Output:".dimmed(), output.display());
        println!(
            "    {} {} bytes ({})",
            "Size:".dimmed(),
            file_size.to_string().cyan(),
            format_size(file_size as usize)
        );
        println!("    {} {:.2?}", "Time:".dimmed(), elapsed);
    } else {
        println!(
            "{} {} ({})",
            "Compiled".green(),
            output.display(),
            format_size(file_size as usize)
        );
    }

    Ok(())
}

/// Execute the info subcommand.
fn execute_info(args: InfoArgs, verbose: bool) -> CliResult<()> {
    // Verify file exists
    if !args.file.exists() {
        return Err(CliError::FileNotFound(args.file));
    }

    // Read and deserialize the tokenizer
    let data = std::fs::read(&args.file)?;

    let (vocab, _trie, normalizer_config) = hologram_tokenizer::deserialize_tokenizer(&data)
        .map_err(|e| CliError::InvalidInput(format!("failed to deserialize tokenizer: {e}")))?;

    if verbose {
        println!("{}", "Tokenizer Info:".bold());
    }

    println!("    {} {}", "File:".dimmed(), args.file.display());
    println!(
        "    {} {} bytes ({})",
        "Size:".dimmed(),
        data.len().to_string().cyan(),
        format_size(data.len())
    );
    println!(
        "    {} {}",
        "Vocab size:".dimmed(),
        vocab.size.to_string().cyan()
    );
    println!(
        "    {} pad={}, eos={}, unk={}",
        "Special tokens:".dimmed(),
        vocab.special_tokens.pad.to_string().cyan(),
        vocab.special_tokens.eos.to_string().cyan(),
        vocab.special_tokens.unk.to_string().cyan()
    );
    println!(
        "    {} {} steps",
        "Normalizer:".dimmed(),
        normalizer_config.steps.len().to_string().cyan()
    );

    if verbose {
        println!();
        println!("{}", "Normalizer steps:".dimmed());
        for (i, step) in normalizer_config.steps.iter().enumerate() {
            println!("    {}. {:?}", i + 1, step);
        }
    }

    Ok(())
}

/// Format a size in bytes as human-readable.
fn format_size(bytes: usize) -> String {
    if bytes >= 1024 * 1024 {
        format!("{:.2} MB", bytes as f64 / 1024.0 / 1024.0)
    } else if bytes >= 1024 {
        format!("{:.2} KB", bytes as f64 / 1024.0)
    } else {
        format!("{bytes} B")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    const SAMPLE_TOKENIZER_JSON: &str = r#"{
        "model": {
            "vocab": [
                ["<pad>", 0.0],
                ["</s>", 0.0],
                ["<unk>", 0.0],
                ["\u2581", -0.5],
                ["\u2581hello", -1.0],
                ["\u2581world", -1.5]
            ]
        },
        "added_tokens": [
            {"id": 0, "content": "<pad>", "special": true},
            {"id": 1, "content": "</s>", "special": true},
            {"id": 2, "content": "<unk>", "special": true}
        ]
    }"#;

    #[test]
    fn test_compile_tokenizer_roundtrip() {
        let dir = tempdir().unwrap();
        let input = dir.path().join("tokenizer.json");
        let output = dir.path().join("tokenizer.holo");

        // Write sample tokenizer.json
        std::fs::write(&input, SAMPLE_TOKENIZER_JSON).unwrap();

        // Compile
        let args = CompileTokenizerArgs {
            input: input.clone(),
            output: Some(output.clone()),
        };

        let result = execute_compile(args, false);
        assert!(result.is_ok(), "compile failed: {result:?}");

        // Verify output exists
        assert!(output.exists());

        // Verify we can read info
        let info_args = InfoArgs {
            file: output.clone(),
        };
        let result = execute_info(info_args, false);
        assert!(result.is_ok(), "info failed: {result:?}");
    }

    #[test]
    fn test_compile_tokenizer_default_output() {
        let dir = tempdir().unwrap();
        let input = dir.path().join("test.json");

        std::fs::write(&input, SAMPLE_TOKENIZER_JSON).unwrap();

        let args = CompileTokenizerArgs {
            input: input.clone(),
            output: None, // Should default to test.holo
        };

        let result = execute_compile(args, false);
        assert!(result.is_ok());

        // Check default output path
        let expected_output = input.with_extension("holo");
        assert!(expected_output.exists());
    }

    #[test]
    fn test_compile_missing_file() {
        let args = CompileTokenizerArgs {
            input: PathBuf::from("/nonexistent/tokenizer.json"),
            output: None,
        };

        let result = execute_compile(args, false);
        assert!(result.is_err());
    }
}
