export { IdentityJourney as default } from "@/modules/identity/components/IdentityJourney";
