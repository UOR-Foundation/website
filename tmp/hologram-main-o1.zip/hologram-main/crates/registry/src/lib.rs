//! Content-addressed layer registry for Hologram.
//!
//! This crate provides:
//! - [`LayerReference`] - Flexible layer addressing by hash, name, or path
//! - [`LocalRegistry`] - Content-addressed filesystem storage using BLAKE3
//! - [`NameIndex`] - Name-to-hash resolution index
//! - [`PlanCache`] - Disk-persistent cache for compiled plans
//! - [`Registry`] - Trait for registry implementations
//! - [`LayerMetadata`], [`SearchResult`] - Metadata types
//!
//! # Features
//!
//! - `http-async`: Enable async HTTP client (reqwest)
//! - `http-sync`: Enable sync HTTP client (ureq)
//! - `http`: Enable both HTTP clients
//!
//! # Example
//!
//! ```no_run
//! use hologram_registry::{LayerReference, LocalRegistry};
//!
//! // Parse a layer reference
//! let layer_ref: LayerReference = "my-model:v1.0".parse().unwrap();
//!
//! // Store a layer in the local registry
//! let registry = LocalRegistry::default_location().unwrap();
//! let data = std::fs::read("model.holb").unwrap();
//! let hash = registry.store(&data).unwrap();
//!
//! // Fetch it back
//! let fetched = registry.fetch(&hash).unwrap();
//! assert_eq!(data, fetched);
//! ```

mod error;
mod index;
mod layer_ref;
mod local;
mod metadata;
mod plan_cache;
mod traits;

#[cfg(any(feature = "http-async", feature = "http-sync"))]
mod http;

pub use error::{RegistryError, Result};
pub use index::NameIndex;
pub use layer_ref::LayerReference;
pub use local::LocalRegistry;
pub use metadata::{LayerMetadata, SearchResult};
pub use plan_cache::{CacheConfig, CacheStats, PlanCache};
pub use traits::Registry;

#[cfg(feature = "http-async")]
pub use http::AsyncHttpRegistry;
#[cfg(feature = "http-async")]
pub use traits::AsyncRegistry;

#[cfg(feature = "http-sync")]
pub use http::SyncHttpRegistry;

/// Re-export blake3 for hash computation.
pub use blake3;

/// Compute the BLAKE3 hash of data.
///
/// This is a convenience function wrapping `blake3::hash`.
#[must_use]
pub fn hash_data(data: &[u8]) -> [u8; 32] {
    *blake3::hash(data).as_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hash_data() {
        let data = b"hello world";
        let hash = hash_data(data);
        assert_eq!(hash.len(), 32);

        // Same data should produce same hash
        let hash2 = hash_data(data);
        assert_eq!(hash, hash2);

        // Different data should produce different hash
        let hash3 = hash_data(b"different");
        assert_ne!(hash, hash3);
    }
}
