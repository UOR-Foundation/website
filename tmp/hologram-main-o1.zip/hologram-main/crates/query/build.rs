use std::env;
use std::fs;
use std::path::Path;

fn main() {
    println!("cargo:rerun-if-changed=build.rs");

    let shells_dir = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../descriptors/shells");
    let out_dir = env::var_os("OUT_DIR").unwrap();

    let mut combined = String::from("// Auto-generated from query .shell files — do not edit.\n\n");

    // Emit FieldValue enum once (shared across all shell types)
    let field_value = hologram_shell::emit_query::emit_field_value_type();
    combined.push_str(&format!("{field_value}\n\n"));

    for name in ["datum", "ring", "activation", "observable"] {
        let shell_path = shells_dir.join(format!("{name}.shell"));
        println!("cargo:rerun-if-changed={}", shell_path.display());

        let input = fs::read_to_string(&shell_path)
            .unwrap_or_else(|e| panic!("failed to read {}: {e}", shell_path.display()));

        let shell = hologram_shell::parse_shell(&input)
            .unwrap_or_else(|e| panic!("failed to parse {name}.shell: {e}"));

        let code = hologram_shell::emit_query::emit_all(&shell);
        combined.push_str(&format!("// --- {name}.shell ---\n\n{code}\n\n"));
    }

    fs::write(Path::new(&out_dir).join("generated_query.rs"), combined).unwrap();
}
