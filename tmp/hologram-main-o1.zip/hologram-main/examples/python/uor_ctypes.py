"""
UOR Python bindings via ctypes (C FFI).

This module provides high-performance Python bindings (~50-100ns/call)
by wrapping the C FFI layer directly using ctypes.

Performance:
- C FFI: ~1-2ns/call  
- Python ctypes: ~50-100ns/call (50x faster than UniFFI at ~1200ns)

Example:
    >>> from uor_ctypes import UOR
    >>> uor = UOR()
    >>> uor.byte_to_braille(42)
    '⠪'
    >>> uor.byte_to_codepoint(42)
    10282
"""

import ctypes
import platform
import os
from pathlib import Path
from typing import List, Optional

# Determine library extension based on platform
if platform.system() == "Darwin":
    LIB_EXT = ".dylib"
elif platform.system() == "Windows":
    LIB_EXT = ".dll"
else:
    LIB_EXT = ".so"

# Find the UOR library
def find_library() -> Path:
    """Locate the libuor_ffi library."""
    # Try release build first
    release_path = Path(__file__).parent / "../../target/release" / f"libuor_ffi{LIB_EXT}"
    if release_path.exists():
        return release_path.resolve()
    
    # Try debug build
    debug_path = Path(__file__).parent / "../../target/debug" / f"libuor_ffi{LIB_EXT}"
    if debug_path.exists():
        return debug_path.resolve()
    
    raise FileNotFoundError(
        f"Could not find libuor_ffi{LIB_EXT}. "
        "Run: cargo build -p uor-ffi --release"
    )


class UorView(ctypes.Structure):
    """Opaque handle to a UOR view (256-byte lookup table)."""
    pass


class UOR:
    """High-performance UOR bindings via C FFI."""
    
    def __init__(self, lib_path: Optional[Path] = None):
        """Initialize UOR bindings.
        
        Args:
            lib_path: Optional path to libuor_ffi library.
                     If None, searches in target/release and target/debug.
        """
        if lib_path is None:
            lib_path = find_library()
        
        self._lib = ctypes.CDLL(str(lib_path))
        self._setup_functions()
    
    def _setup_functions(self):
        """Configure ctypes function signatures for type safety and performance."""
        lib = self._lib
        
        # ============================================================================
        # TAXON OPERATIONS
        # ============================================================================
        
        # uor_byte_to_braille(uint8_t) -> char*
        lib.uor_byte_to_braille.argtypes = [ctypes.c_ubyte]
        lib.uor_byte_to_braille.restype = ctypes.c_char_p
        
        # uor_byte_to_codepoint(uint8_t) -> uint32_t
        lib.uor_byte_to_codepoint.argtypes = [ctypes.c_ubyte]
        lib.uor_byte_to_codepoint.restype = ctypes.c_uint32
        
        # uor_byte_to_domain(uint8_t) -> uint8_t
        lib.uor_byte_to_domain.argtypes = [ctypes.c_ubyte]
        lib.uor_byte_to_domain.restype = ctypes.c_ubyte
        
        # uor_byte_rank(uint8_t) -> uint8_t
        lib.uor_byte_rank.argtypes = [ctypes.c_ubyte]
        lib.uor_byte_rank.restype = ctypes.c_ubyte
        
        # ============================================================================
        # RING OPERATIONS
        # ============================================================================
        
        # uor_byte_succ(uint8_t) -> uint8_t
        lib.uor_byte_succ.argtypes = [ctypes.c_ubyte]
        lib.uor_byte_succ.restype = ctypes.c_ubyte
        
        # uor_byte_pred(uint8_t) -> uint8_t
        lib.uor_byte_pred.argtypes = [ctypes.c_ubyte]
        lib.uor_byte_pred.restype = ctypes.c_ubyte
        
        # uor_byte_not(uint8_t) -> uint8_t
        lib.uor_byte_not.argtypes = [ctypes.c_ubyte]
        lib.uor_byte_not.restype = ctypes.c_ubyte
        
        # ============================================================================
        # VIEW OPERATIONS
        # ============================================================================
        
        # uor_view_identity() -> UorView*
        lib.uor_view_identity.argtypes = []
        lib.uor_view_identity.restype = ctypes.POINTER(UorView)
        
        # uor_view_constant(uint8_t) -> UorView*
        lib.uor_view_constant.argtypes = [ctypes.c_ubyte]
        lib.uor_view_constant.restype = ctypes.POINTER(UorView)
        
        # uor_view_apply(UorView*, uint8_t) -> uint8_t
        lib.uor_view_apply.argtypes = [ctypes.POINTER(UorView), ctypes.c_ubyte]
        lib.uor_view_apply.restype = ctypes.c_ubyte
        
        # uor_view_apply_slice(UorView*, uint8_t*, size_t, uint8_t*)
        lib.uor_view_apply_slice.argtypes = [
            ctypes.POINTER(UorView),
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_size_t,
            ctypes.POINTER(ctypes.c_ubyte)
        ]
        lib.uor_view_apply_slice.restype = None
        
        # uor_view_is_bijective(UorView*) -> bool
        lib.uor_view_is_bijective.argtypes = [ctypes.POINTER(UorView)]
        lib.uor_view_is_bijective.restype = ctypes.c_bool
        
        # uor_view_inverse(UorView*) -> UorView*
        lib.uor_view_inverse.argtypes = [ctypes.POINTER(UorView)]
        lib.uor_view_inverse.restype = ctypes.POINTER(UorView)
        
        # uor_view_then(UorView*, UorView*) -> UorView*
        lib.uor_view_then.argtypes = [ctypes.POINTER(UorView), ctypes.POINTER(UorView)]
        lib.uor_view_then.restype = ctypes.POINTER(UorView)
        
        # uor_view_free(UorView*)
        lib.uor_view_free.argtypes = [ctypes.POINTER(UorView)]
        lib.uor_view_free.restype = None
        
        # ============================================================================
        # CONSTANTS
        # ============================================================================
        
        lib.uor_braille_base.argtypes = []
        lib.uor_braille_base.restype = ctypes.c_uint32
        
        lib.uor_braille_max.argtypes = []
        lib.uor_braille_max.restype = ctypes.c_uint32
        
        lib.uor_triadic_constant.argtypes = []
        lib.uor_triadic_constant.restype = ctypes.c_ubyte
        
        lib.uor_octave_constant.argtypes = []
        lib.uor_octave_constant.restype = ctypes.c_ubyte
        
        lib.uor_state_taxons.argtypes = []
        lib.uor_state_taxons.restype = ctypes.c_uint16
        
        lib.uor_state_bits.argtypes = []
        lib.uor_state_bits.restype = ctypes.c_uint16
        
        # ============================================================================
        # MEMORY MANAGEMENT
        # ============================================================================
        
        # uor_string_free(char*)
        lib.uor_string_free.argtypes = [ctypes.c_char_p]
        lib.uor_string_free.restype = None
    
    # ============================================================================
    # TAXON OPERATIONS (Python API)
    # ============================================================================
    
    def byte_to_braille(self, value: int) -> str:
        """Get Braille character for a byte value (bijective mapping).
        
        Args:
            value: Byte value (0-255)
        
        Returns:
            Braille character (U+2800 - U+28FF)
        
        Example:
            >>> uor.byte_to_braille(42)
            '⠪'
        """
        result = self._lib.uor_byte_to_braille(value)
        return result.decode('utf-8')
    
    def byte_to_codepoint(self, value: int) -> int:
        """Get Unicode codepoint for a byte value.
        
        Args:
            value: Byte value (0-255)
        
        Returns:
            Unicode codepoint (0x2800 - 0x28FF)
        
        Example:
            >>> uor.byte_to_codepoint(42)
            10282
            >>> hex(uor.byte_to_codepoint(42))
            '0x282a'
        """
        return self._lib.uor_byte_to_codepoint(value)
    
    def byte_to_domain(self, value: int) -> int:
        """Get triadic domain for a byte value.
        
        Args:
            value: Byte value (0-255)
        
        Returns:
            Domain index: 0=Theta, 1=Psi, 2=Delta
        """
        return self._lib.uor_byte_to_domain(value)
    
    def byte_rank(self, value: int) -> int:
        """Get rank within domain for a byte value.
        
        Args:
            value: Byte value (0-255)
        
        Returns:
            Rank within domain (0-84)
        """
        return self._lib.uor_byte_rank(value)
    
    # ============================================================================
    # RING OPERATIONS (Python API)
    # ============================================================================
    
    def byte_succ(self, value: int) -> int:
        """Get successor in ring.
        
        Args:
            value: Byte value (0-255)
        
        Returns:
            Successor byte value (wraps at 255 -> 0)
        """
        return self._lib.uor_byte_succ(value)
    
    def byte_pred(self, value: int) -> int:
        """Get predecessor in ring.
        
        Args:
            value: Byte value (0-255)
        
        Returns:
            Predecessor byte value (wraps at 0 -> 255)
        """
        return self._lib.uor_byte_pred(value)
    
    def byte_not(self, value: int) -> int:
        """Bitwise NOT.
        
        Args:
            value: Byte value (0-255)
        
        Returns:
            Bitwise NOT of value
        """
        return self._lib.uor_byte_not(value)
    
    # ============================================================================
    # VIEW OPERATIONS (Python API)
    # ============================================================================
    
    def view_identity(self) -> ctypes.POINTER(UorView):
        """Create an identity view.
        
        Returns:
            Opaque view pointer (must be freed with view_free)
        """
        return self._lib.uor_view_identity()
    
    def view_constant(self, value: int) -> Optional[ctypes.POINTER(UorView)]:
        """Create a constant view (all inputs map to the same output).
        
        Args:
            value: Constant output value (0-255)
        
        Returns:
            Opaque view pointer, or None if value is invalid
        """
        result = self._lib.uor_view_constant(value)
        return result if result else None
    
    def view_apply(self, view: ctypes.POINTER(UorView), byte_value: int) -> int:
        """Apply a view to a single byte.
        
        Args:
            view: View pointer from view_identity() or view_constant()
            byte_value: Input byte (0-255)
        
        Returns:
            Transformed byte value
        """
        return self._lib.uor_view_apply(view, byte_value)
    
    def view_apply_slice(self, view: ctypes.POINTER(UorView), data: bytes) -> bytes:
        """Apply a view to a byte array (batch operation).
        
        Args:
            view: View pointer
            data: Input bytes
        
        Returns:
            Transformed bytes (same length as input)
        """
        input_len = len(data)
        input_arr = (ctypes.c_ubyte * input_len).from_buffer_copy(data)
        output_arr = (ctypes.c_ubyte * input_len)()
        
        self._lib.uor_view_apply_slice(view, input_arr, input_len, output_arr)
        
        return bytes(output_arr)
    
    def view_is_bijective(self, view: ctypes.POINTER(UorView)) -> bool:
        """Check if a view is bijective (1-to-1 mapping).
        
        Args:
            view: View pointer
        
        Returns:
            True if bijective, False otherwise
        """
        return self._lib.uor_view_is_bijective(view)
    
    def view_inverse(self, view: ctypes.POINTER(UorView)) -> Optional[ctypes.POINTER(UorView)]:
        """Get the inverse of a bijective view.
        
        Args:
            view: View pointer (must be bijective)
        
        Returns:
            Inverse view pointer, or None if not bijective
        """
        result = self._lib.uor_view_inverse(view)
        return result if result else None
    
    def view_then(self, self_view: ctypes.POINTER(UorView), other_view: ctypes.POINTER(UorView)) -> ctypes.POINTER(UorView):
        """Compose two views: result[x] = other[self[x]].
        
        Args:
            self_view: First view
            other_view: Second view
        
        Returns:
            Composed view pointer
        """
        return self._lib.uor_view_then(self_view, other_view)
    
    def view_free(self, view: ctypes.POINTER(UorView)):
        """Free a view created by view_* functions.
        
        Args:
            view: View pointer to free
        
        Warning:
            Do not use the view after calling this function.
        """
        self._lib.uor_view_free(view)
    
    # ============================================================================
    # CONSTANTS (Python API)
    # ============================================================================
    
    @property
    def braille_base(self) -> int:
        """Braille base codepoint (U+2800 = 10240)."""
        return self._lib.uor_braille_base()
    
    @property
    def braille_max(self) -> int:
        """Braille max codepoint (U+28FF = 10495)."""
        return self._lib.uor_braille_max()
    
    @property
    def triadic_constant(self) -> int:
        """Triadic constant (T = 3)."""
        return self._lib.uor_triadic_constant()
    
    @property
    def octave_constant(self) -> int:
        """Octave constant (O = 8)."""
        return self._lib.uor_octave_constant()
    
    @property
    def state_taxons(self) -> int:
        """State taxon count (624)."""
        return self._lib.uor_state_taxons()
    
    @property
    def state_bits(self) -> int:
        """State bit count (4992)."""
        return self._lib.uor_state_bits()


# Convenience singleton instance
_uor_instance = None

def get_uor() -> UOR:
    """Get global UOR instance (lazy initialization)."""
    global _uor_instance
    if _uor_instance is None:
        _uor_instance = UOR()
    return _uor_instance


# Export convenience functions (match UniFFI API)
def byte_to_braille(value: int) -> str:
    """Get Braille character for a byte value."""
    return get_uor().byte_to_braille(value)

def byte_to_codepoint(value: int) -> int:
    """Get Unicode codepoint for a byte value."""
    return get_uor().byte_to_codepoint(value)

def byte_to_domain(value: int) -> int:
    """Get triadic domain for a byte value."""
    return get_uor().byte_to_domain(value)

def byte_rank(value: int) -> int:
    """Get rank within domain for a byte value."""
    return get_uor().byte_rank(value)

def byte_succ(value: int) -> int:
    """Get successor in ring."""
    return get_uor().byte_succ(value)

def byte_pred(value: int) -> int:
    """Get predecessor in ring."""
    return get_uor().byte_pred(value)

def byte_not(value: int) -> int:
    """Bitwise NOT."""
    return get_uor().byte_not(value)


class View:
    """High-level Python wrapper for UOR views."""
    
    def __init__(self, ptr: ctypes.POINTER(UorView)):
        """Initialize view wrapper.
        
        Args:
            ptr: View pointer from UOR.view_* functions
        """
        self._ptr = ptr
        self._uor = get_uor()
    
    @classmethod
    def identity(cls) -> 'View':
        """Create an identity view."""
        return cls(get_uor().view_identity())
    
    @classmethod
    def constant(cls, value: int) -> 'View':
        """Create a constant view."""
        ptr = get_uor().view_constant(value)
        if ptr is None:
            raise ValueError(f"Invalid constant value: {value}")
        return cls(ptr)
    
    def apply(self, byte_value: int) -> int:
        """Apply view to a single byte."""
        return self._uor.view_apply(self._ptr, byte_value)
    
    def apply_slice(self, data: bytes) -> bytes:
        """Apply view to a byte array (batch operation)."""
        return self._uor.view_apply_slice(self._ptr, data)
    
    def is_bijective(self) -> bool:
        """Check if view is bijective."""
        return self._uor.view_is_bijective(self._ptr)
    
    def inverse(self) -> Optional['View']:
        """Get inverse of a bijective view."""
        inv_ptr = self._uor.view_inverse(self._ptr)
        return View(inv_ptr) if inv_ptr else None
    
    def then(self, other: 'View') -> 'View':
        """Compose with another view."""
        return View(self._uor.view_then(self._ptr, other._ptr))
    
    def __del__(self):
        """Free view on garbage collection."""
        if hasattr(self, '_ptr') and self._ptr:
            self._uor.view_free(self._ptr)


if __name__ == "__main__":
    # Quick test
    uor = UOR()
    print(f"UOR Python (ctypes) bindings loaded successfully")
    print(f"byte_to_braille(42) = {uor.byte_to_braille(42)}")
    print(f"byte_to_codepoint(42) = {uor.byte_to_codepoint(42)} (0x{uor.byte_to_codepoint(42):04x})")
    print(f"byte_to_domain(42) = {uor.byte_to_domain(42)}")
    print(f"byte_rank(42) = {uor.byte_rank(42)}")
    print(f"Triadic constant (T) = {uor.triadic_constant}")
    print(f"Octave constant (O) = {uor.octave_constant}")
    print(f"State taxons = {uor.state_taxons}")
    print(f"State bits = {uor.state_bits}")
    
    # Test view operations
    print("\nTesting View operations:")
    identity = View.identity()
    print(f"identity.apply(42) = {identity.apply(42)}")
    print(f"identity.is_bijective() = {identity.is_bijective()}")
    
    data = bytes(range(256))
    result = identity.apply_slice(data)
    print(f"identity.apply_slice(range(256)) = {result[:10]}... (length: {len(result)})")
