//! Build script for categorical-codec.
//!
//! Automatically generates codec implementations from JSON-LD descriptors
//! at compile time.

use std::env;
use std::fs;
use std::path::Path;

fn main() {
    let out_dir = env::var("OUT_DIR").unwrap();
    let manifest_dir = env::var("CARGO_MANIFEST_DIR").unwrap();

    // Path to the descriptors directory (at workspace root)
    let workspace_root = Path::new(&manifest_dir).parent().unwrap().parent().unwrap();
    let descriptors_dir = workspace_root.join("descriptors");

    // Rerun if the descriptors directory or build.rs changes
    println!("cargo:rerun-if-changed={}", descriptors_dir.display());
    println!("cargo:rerun-if-changed=build.rs");

    // Check if descriptors directory exists
    if !descriptors_dir.exists() {
        eprintln!(
            "Warning: Descriptors directory not found at {}",
            descriptors_dir.display()
        );
        // Generate empty module
        let output_path = Path::new(&out_dir).join("generated.rs");
        let empty_code = r#"// No descriptors directory found - no codecs generated
/// Returns all generated codecs (empty if no descriptors found).
#[must_use]
pub fn all_codecs() -> Vec<Box<dyn crate::Codec>> {
    vec![]
}
"#;
        fs::write(&output_path, empty_code).expect("Failed to write generated.rs");
        return;
    }

    // Collect codecs from all .jsonld files in the descriptors directory
    let mut all_codecs = Vec::new();
    let mut file_count = 0;

    let entries = fs::read_dir(&descriptors_dir).expect("Failed to read descriptors directory");
    for entry in entries {
        let entry = entry.expect("Failed to read directory entry");
        let path = entry.path();

        // Only process .jsonld files
        if path.extension().is_some_and(|ext| ext == "jsonld") {
            // Rerun if this file changes
            println!("cargo:rerun-if-changed={}", path.display());

            let content = fs::read_to_string(&path)
                .unwrap_or_else(|e| panic!("Failed to read {}: {}", path.display(), e));

            let codecs = parse_jsonld(&content);
            all_codecs.extend(codecs);
            file_count += 1;
        }
    }

    // Generate Rust code from all collected codecs
    let code = generate_rust_code(&all_codecs);

    // Write to OUT_DIR
    let output_path = Path::new(&out_dir).join("generated.rs");
    fs::write(&output_path, code).expect("Failed to write generated.rs");

    println!(
        "cargo:warning=Generated {} codec(s) from {} file(s) in {}",
        all_codecs.len(),
        file_count,
        descriptors_dir.display()
    );
}

/// Supported encoding algorithms.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum EncodingAlgorithm {
    /// Identity transform (input == output)
    Identity,
    /// Base-N positional encoding
    BaseN,
    /// Mixed-radix encoding
    MixedRadix,
    /// Braille bijective encoding
    Braille,
}

/// Codec definition extracted from JSON-LD.
#[allow(dead_code)]
struct CodecDef {
    id: String,
    rust_name: String,
    algorithm: EncodingAlgorithm,
    radix: u32,
    radices: Option<Vec<u32>>,
    braille_glyph_count: Option<u64>,
    quantum_level: Option<u64>,
    doc: Option<String>,
    precision_bits: Option<u64>,
}

/// Parse JSON-LD content to extract codec definitions.
fn parse_jsonld(content: &str) -> Vec<CodecDef> {
    let value: serde_json::Value = serde_json::from_str(content).expect("Invalid JSON");

    let graph = match value.get("@graph").and_then(|g| g.as_array()) {
        Some(g) => g,
        None => return Vec::new(),
    };

    let mut codecs = Vec::new();

    for node in graph {
        if let Some(codec) = try_parse_codec(node) {
            codecs.push(codec);
        }
    }

    codecs
}

/// Try to parse a JSON-LD node as a codec definition.
fn try_parse_codec(node: &serde_json::Value) -> Option<CodecDef> {
    let types = get_types(node);

    // Must be a NumeralSystem to be a codec
    if !types.iter().any(|t| t.contains("NumeralSystem")) {
        return None;
    }

    let id = get_string(node, "@id")?;
    let rust_name = id_to_rust_name(&id);

    // Get encoding algorithm - prefer explicit field, fall back to type inference
    let algorithm = match get_string(node, "encodingAlgorithm").as_deref() {
        Some("identity") => EncodingAlgorithm::Identity,
        Some("base_n") => EncodingAlgorithm::BaseN,
        Some("mixed_radix") => EncodingAlgorithm::MixedRadix,
        Some("braille") => EncodingAlgorithm::Braille,
        Some(other) => {
            eprintln!(
                "Warning: unknown encodingAlgorithm '{}' for codec '{}', using base_n",
                other, id
            );
            EncodingAlgorithm::BaseN
        }
        None => {
            // Fall back to type inference for backwards compatibility
            if types.iter().any(|t| t.contains("BrailleCodec")) {
                EncodingAlgorithm::Braille
            } else if types.iter().any(|t| t.contains("MixedRadixSystem")) {
                EncodingAlgorithm::MixedRadix
            } else if types.iter().any(|t| t.contains("PositionalSystem")) {
                let radix = get_radix(node).unwrap_or(10);
                if radix == 2 {
                    EncodingAlgorithm::Identity
                } else {
                    EncodingAlgorithm::BaseN
                }
            } else {
                EncodingAlgorithm::BaseN
            }
        }
    };

    // Get radix/radices based on algorithm
    let (radix, radices) = match algorithm {
        EncodingAlgorithm::MixedRadix => {
            let radices = get_radices(node).unwrap_or_else(|| vec![10]);
            let first_radix = radices.first().copied().unwrap_or(10);
            (first_radix, Some(radices))
        }
        _ => {
            let radix = get_radix(node).unwrap_or(10);
            (radix, None)
        }
    };

    let doc = get_string(node, "rdfs:label")
        .or_else(|| get_string(node, "label"))
        .or_else(|| get_string(node, "rdfs:comment"))
        .or_else(|| get_string(node, "comment"));

    let precision_bits = get_u64(node, "precisionBits");
    let braille_glyph_count = get_u64(node, "brailleGlyphCount");
    let quantum_level = get_u64(node, "quantumLevel");

    Some(CodecDef {
        id,
        rust_name,
        algorithm,
        radix,
        radices,
        braille_glyph_count,
        quantum_level,
        doc,
        precision_bits,
    })
}

/// Get @type(s) from a node.
fn get_types(node: &serde_json::Value) -> Vec<String> {
    match node.get("@type") {
        Some(serde_json::Value::String(s)) => vec![s.clone()],
        Some(serde_json::Value::Array(arr)) => arr
            .iter()
            .filter_map(|v| v.as_str().map(String::from))
            .collect(),
        _ => Vec::new(),
    }
}

/// Get a string property.
fn get_string(node: &serde_json::Value, key: &str) -> Option<String> {
    node.get(key).and_then(|v| match v {
        serde_json::Value::String(s) => Some(s.clone()),
        serde_json::Value::Object(obj) => {
            obj.get("@value").and_then(|v| v.as_str()).map(String::from)
        }
        _ => None,
    })
}

/// Get a u64 property.
fn get_u64(node: &serde_json::Value, key: &str) -> Option<u64> {
    node.get(key).and_then(|v| match v {
        serde_json::Value::Number(n) => n.as_u64(),
        serde_json::Value::Object(obj) => obj.get("@value").and_then(|v| v.as_u64()),
        _ => None,
    })
}

/// Get hasRadix property.
fn get_radix(node: &serde_json::Value) -> Option<u32> {
    get_u64(node, "hasRadix").map(|r| r as u32)
}

/// Get hasRadices property.
fn get_radices(node: &serde_json::Value) -> Option<Vec<u32>> {
    node.get("hasRadices").and_then(|v| {
        if let serde_json::Value::Array(arr) = v {
            let radices: Vec<u32> = arr
                .iter()
                .filter_map(|r| r.as_u64().map(|n| n as u32))
                .collect();
            if radices.is_empty() {
                None
            } else {
                Some(radices)
            }
        } else if let serde_json::Value::String(s) = v {
            let radices: Vec<u32> = s.split(',').filter_map(|r| r.trim().parse().ok()).collect();
            if radices.is_empty() {
                None
            } else {
                Some(radices)
            }
        } else {
            None
        }
    })
}

/// Convert JSON-LD @id to Rust identifier.
fn id_to_rust_name(id: &str) -> String {
    let name = if let Some(pos) = id.rfind(':') {
        &id[pos + 1..]
    } else if let Some(pos) = id.rfind('/') {
        &id[pos + 1..]
    } else {
        id
    };

    let mut result = String::new();
    let mut capitalize_next = true;

    for ch in name.chars() {
        if ch.is_alphanumeric() {
            if capitalize_next {
                result.extend(ch.to_uppercase());
                capitalize_next = false;
            } else {
                result.push(ch);
            }
        } else if ch == '_' || ch == '-' || ch == '/' {
            capitalize_next = true;
        }
    }

    if result.chars().next().is_some_and(|c| c.is_numeric()) {
        result = format!("Codec{}", result);
    }

    if result.is_empty() {
        "UnnamedCodec".to_string()
    } else {
        result
    }
}

/// Generate Rust code from codec definitions.
fn generate_rust_code(codecs: &[CodecDef]) -> String {
    let mut output = String::new();

    output.push_str("// Auto-generated from JSON-LD descriptor\n");
    output.push_str("// DO NOT EDIT - regenerate by rebuilding the crate\n\n");

    // Generate each codec
    for codec in codecs {
        output.push_str(&generate_codec(codec));
        output.push('\n');
        output.push_str(&generate_streaming_impl(codec));
        output.push('\n');
    }

    // Generate all_codecs function
    output.push_str("/// Returns all generated codecs.\n");
    output.push_str("#[must_use]\n");
    output.push_str("pub fn all_codecs() -> Vec<Box<dyn crate::Codec>> {\n");
    output.push_str("    vec![\n");
    for codec in codecs {
        output.push_str(&format!("        Box::new({}),\n", codec.rust_name));
    }
    output.push_str("    ]\n");
    output.push_str("}\n\n");

    // Generate all_streaming_codecs function
    output.push_str("/// Returns all generated codecs with streaming support.\n");
    output.push_str("#[must_use]\n");
    output.push_str("pub fn all_streaming_codecs() -> Vec<Box<dyn crate::StreamingCodec>> {\n");
    output.push_str("    vec![\n");
    for codec in codecs {
        output.push_str(&format!("        Box::new({}),\n", codec.rust_name));
    }
    output.push_str("    ]\n");
    output.push_str("}\n");

    output
}

/// Generate Rust code for a single codec.
fn generate_codec(codec: &CodecDef) -> String {
    let mut output = String::new();

    // Doc comment
    if let Some(doc) = &codec.doc {
        // Escape any problematic characters in doc comments
        let escaped_doc = doc.replace('\n', "\n/// ");
        output.push_str(&format!("/// {}\n", escaped_doc));
    }
    output.push_str(&format!("///\n/// JSON-LD ID: `{}`\n", codec.id));

    // Struct
    output.push_str("#[derive(Debug, Clone, Copy, Default)]\n");
    output.push_str(&format!("pub struct {};\n\n", codec.rust_name));

    // Impl Codec
    output.push_str(&format!("impl crate::Codec for {} {{\n", codec.rust_name));

    // id()
    output.push_str(&format!(
        "    fn id(&self) -> &'static str {{ \"{}\" }}\n\n",
        codec.id
    ));

    // name()
    output.push_str(&format!(
        "    fn name(&self) -> &'static str {{ \"{}\" }}\n\n",
        codec.rust_name
    ));

    // scale_factor()
    let (arbitrary, max_bits) = match codec.precision_bits {
        Some(bits) => ("false", format!("Some({})", bits)),
        None => ("true", "None".to_string()),
    };
    output.push_str("    fn scale_factor(&self) -> crate::ScaleFactor {\n");
    output.push_str("        crate::ScaleFactor {\n");
    output.push_str(&format!("            radix: {},\n", codec.radix));
    output.push_str(&format!("            arbitrary: {},\n", arbitrary));
    output.push_str(&format!("            max_precision_bits: {},\n", max_bits));
    output.push_str("        }\n");
    output.push_str("    }\n\n");

    // encode()
    output.push_str("    fn encode(&self, input: &[u8]) -> Result<Vec<u8>, crate::CodecError> {\n");
    match codec.algorithm {
        EncodingAlgorithm::Identity => {
            output.push_str("        Ok(input.to_vec())\n");
        }
        EncodingAlgorithm::BaseN => {
            output.push_str(&format!(
                "        crate::generated::encode_base_n(input, {})\n",
                codec.radix
            ));
        }
        EncodingAlgorithm::MixedRadix => {
            let radices = codec.radices.as_ref().unwrap();
            output.push_str(&format!(
                "        crate::generated::encode_mixed_radix(input, &{:?})\n",
                radices
            ));
        }
        EncodingAlgorithm::Braille => {
            let glyph_count = codec.braille_glyph_count.unwrap_or(1);
            output.push_str(&format!(
                "        crate::generated::encode_braille(input, {})\n",
                glyph_count
            ));
        }
    }
    output.push_str("    }\n\n");

    // decode()
    output.push_str("    fn decode(&self, input: &[u8]) -> Result<Vec<u8>, crate::CodecError> {\n");
    match codec.algorithm {
        EncodingAlgorithm::Identity => {
            output.push_str("        Ok(input.to_vec())\n");
        }
        EncodingAlgorithm::BaseN => {
            output.push_str(&format!(
                "        crate::generated::decode_base_n(input, {})\n",
                codec.radix
            ));
        }
        EncodingAlgorithm::MixedRadix => {
            let radices = codec.radices.as_ref().unwrap();
            output.push_str(&format!(
                "        crate::generated::decode_mixed_radix(input, &{:?})\n",
                radices
            ));
        }
        EncodingAlgorithm::Braille => {
            let glyph_count = codec.braille_glyph_count.unwrap_or(1);
            output.push_str(&format!(
                "        crate::generated::decode_braille(input, {})\n",
                glyph_count
            ));
        }
    }
    output.push_str("    }\n");

    output.push_str("}\n");

    output
}

/// Generate StreamingCodec implementation for a codec.
fn generate_streaming_impl(codec: &CodecDef) -> String {
    let mut output = String::new();

    output.push_str(&format!(
        "impl crate::StreamingCodec for {} {{\n",
        codec.rust_name
    ));

    // encoder()
    output.push_str("    fn encoder(&self) -> Box<dyn crate::ChunkEncoder> {\n");
    match codec.algorithm {
        EncodingAlgorithm::Braille => {
            // Native Braille streaming encoder
            output.push_str("        Box::new(crate::BrailleStreamEncoder)\n");
        }
        EncodingAlgorithm::Identity => {
            // Batch fallback - identity
            output.push_str(
                "        Box::new(crate::BatchEncoder::new(|input| Ok(input.to_vec())))\n",
            );
        }
        EncodingAlgorithm::MixedRadix => {
            // Batch fallback - mixed radix
            let radices = codec.radices.as_ref().unwrap();
            output.push_str(&format!(
                "        Box::new(crate::BatchEncoder::new(|input| crate::generated::encode_mixed_radix(input, &{:?})))\n",
                radices
            ));
        }
        EncodingAlgorithm::BaseN => {
            // Batch fallback - base N
            output.push_str(&format!(
                "        Box::new(crate::BatchEncoder::new(|input| crate::generated::encode_base_n(input, {})))\n",
                codec.radix
            ));
        }
    }
    output.push_str("    }\n\n");

    // decoder()
    output.push_str("    fn decoder(&self) -> Box<dyn crate::ChunkDecoder> {\n");
    match codec.algorithm {
        EncodingAlgorithm::Braille => {
            // Native Braille streaming decoder
            output.push_str("        Box::new(crate::BrailleStreamDecoder::new())\n");
        }
        EncodingAlgorithm::Identity => {
            // Batch fallback - identity
            output.push_str(
                "        Box::new(crate::BatchDecoder::new(|input| Ok(input.to_vec())))\n",
            );
        }
        EncodingAlgorithm::MixedRadix => {
            // Batch fallback - mixed radix
            let radices = codec.radices.as_ref().unwrap();
            output.push_str(&format!(
                "        Box::new(crate::BatchDecoder::new(|input| crate::generated::decode_mixed_radix(input, &{:?})))\n",
                radices
            ));
        }
        EncodingAlgorithm::BaseN => {
            // Batch fallback - base N
            output.push_str(&format!(
                "        Box::new(crate::BatchDecoder::new(|input| crate::generated::decode_base_n(input, {})))\n",
                codec.radix
            ));
        }
    }
    output.push_str("    }\n");

    output.push_str("}\n");

    output
}
