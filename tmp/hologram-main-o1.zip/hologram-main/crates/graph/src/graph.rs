//! Arena-based compute graph with O(1) node access.
//!
//! The graph uses an arena allocator with generational indices for safe,
//! efficient node access. Removed nodes leave holes that are reused for
//! new allocations, with generation counters ensuring stale references
//! fail gracefully.

use crate::ids::{GroupId, NodeId};
use crate::node::{InputSlot, Node};

/// Slot in the node arena.
#[derive(Debug, Clone)]
enum Slot<Op> {
    /// Occupied slot with a node.
    Occupied(Node<Op>),
    /// Free slot with pointer to next free slot.
    Free { next_free: Option<u32> },
}

/// A directed acyclic graph of compute operations.
///
/// Generic over the operation type `Op`, allowing different backends
/// to define their own operation sets while sharing graph algorithms.
#[derive(Debug, Clone)]
pub struct ComputeGraph<Op> {
    /// Arena of node slots.
    slots: Vec<Slot<Op>>,
    /// Generation counter per slot.
    generations: Vec<u32>,
    /// Head of the free list.
    free_head: Option<u32>,
    /// Number of active nodes.
    node_count: usize,
    /// Named graph inputs.
    inputs: Vec<(String, u32)>,
    /// Named graph outputs.
    outputs: Vec<(String, NodeId)>,
}

impl<Op> Default for ComputeGraph<Op> {
    fn default() -> Self {
        Self::new()
    }
}

impl<Op> ComputeGraph<Op> {
    /// Create a new empty graph.
    #[must_use]
    pub fn new() -> Self {
        Self {
            slots: Vec::new(),
            generations: Vec::new(),
            free_head: None,
            node_count: 0,
            inputs: Vec::new(),
            outputs: Vec::new(),
        }
    }

    /// Create a graph with pre-allocated capacity.
    #[must_use]
    pub fn with_capacity(capacity: usize) -> Self {
        Self {
            slots: Vec::with_capacity(capacity),
            generations: Vec::with_capacity(capacity),
            free_head: None,
            node_count: 0,
            inputs: Vec::new(),
            outputs: Vec::new(),
        }
    }

    /// Add a node with the given operation.
    ///
    /// Returns the `NodeId` for the new node.
    pub fn add_node(&mut self, op: Op) -> NodeId {
        let (index, generation) = self.allocate_slot();
        let id = NodeId::new(index, generation);
        self.slots[index as usize] = Slot::Occupied(Node::new(id, op));
        self.node_count += 1;
        id
    }

    /// Add a fully constructed node.
    ///
    /// The node's ID will be updated to match the allocated slot.
    pub fn add_constructed_node(&mut self, mut node: Node<Op>) -> NodeId {
        let (index, generation) = self.allocate_slot();
        let id = NodeId::new(index, generation);
        node.id = id;
        self.slots[index as usize] = Slot::Occupied(node);
        self.node_count += 1;
        id
    }

    /// Remove a node by ID.
    ///
    /// Returns the removed node if it existed.
    pub fn remove_node(&mut self, id: NodeId) -> Option<Node<Op>> {
        if !self.contains(id) {
            return None;
        }

        let index = id.index() as usize;
        let old_slot = std::mem::replace(
            &mut self.slots[index],
            Slot::Free {
                next_free: self.free_head,
            },
        );

        self.free_head = Some(id.index());
        self.generations[index] += 1;
        self.node_count -= 1;

        match old_slot {
            Slot::Occupied(node) => Some(node),
            Slot::Free { .. } => None,
        }
    }

    /// Get a node by ID.
    #[must_use]
    pub fn get(&self, id: NodeId) -> Option<&Node<Op>> {
        if !self.is_valid_id(id) {
            return None;
        }
        match &self.slots[id.index() as usize] {
            Slot::Occupied(node) => Some(node),
            Slot::Free { .. } => None,
        }
    }

    /// Get a mutable reference to a node by ID.
    pub fn get_mut(&mut self, id: NodeId) -> Option<&mut Node<Op>> {
        if !self.is_valid_id(id) {
            return None;
        }
        match &mut self.slots[id.index() as usize] {
            Slot::Occupied(node) => Some(node),
            Slot::Free { .. } => None,
        }
    }

    /// Check if a node ID is valid and points to an existing node.
    #[must_use]
    pub fn contains(&self, id: NodeId) -> bool {
        self.is_valid_id(id)
            && matches!(self.slots.get(id.index() as usize), Some(Slot::Occupied(_)))
    }

    /// Add an edge from source to target.
    ///
    /// The target node will have the source added to its inputs.
    pub fn add_edge(&mut self, source: NodeId, target: NodeId) -> bool {
        if !self.contains(source) || !self.contains(target) {
            return false;
        }
        if let Some(node) = self.get_mut(target) {
            node.add_input(source);
            true
        } else {
            false
        }
    }

    /// Get all edges as (source, target) pairs.
    #[must_use]
    pub fn edges(&self) -> Vec<(NodeId, NodeId)> {
        let mut edges = Vec::new();
        for node in self.nodes() {
            for dep in node.dependencies() {
                edges.push((dep, node.id));
            }
        }
        edges
    }

    /// Get predecessors (nodes that this node depends on).
    #[must_use]
    pub fn predecessors(&self, id: NodeId) -> Vec<NodeId> {
        self.get(id)
            .map(|node| node.dependencies().collect())
            .unwrap_or_default()
    }

    /// Get successors (nodes that depend on this node).
    #[must_use]
    pub fn successors(&self, id: NodeId) -> Vec<NodeId> {
        self.nodes()
            .filter(|node| node.dependencies().any(|dep| dep == id))
            .map(|node| node.id)
            .collect()
    }

    /// Iterate over all active nodes.
    pub fn nodes(&self) -> impl Iterator<Item = &Node<Op>> {
        self.slots.iter().filter_map(|slot| match slot {
            Slot::Occupied(node) => Some(node),
            Slot::Free { .. } => None,
        })
    }

    /// Iterate over all active nodes mutably.
    pub fn nodes_mut(&mut self) -> impl Iterator<Item = &mut Node<Op>> {
        self.slots.iter_mut().filter_map(|slot| match slot {
            Slot::Occupied(node) => Some(node),
            Slot::Free { .. } => None,
        })
    }

    /// Get all node IDs.
    #[must_use]
    pub fn node_ids(&self) -> Vec<NodeId> {
        self.nodes().map(|n| n.id).collect()
    }

    /// Get the number of active nodes.
    #[must_use]
    pub fn node_count(&self) -> usize {
        self.node_count
    }

    /// Check if the graph is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.node_count == 0
    }

    /// Register a named graph input.
    pub fn add_input(&mut self, name: impl Into<String>) -> u32 {
        let index = self.inputs.len() as u32;
        self.inputs.push((name.into(), index));
        index
    }

    /// Register a named graph output.
    pub fn add_output(&mut self, name: impl Into<String>, node: NodeId) {
        self.outputs.push((name.into(), node));
    }

    /// Get named inputs.
    #[must_use]
    pub fn inputs(&self) -> &[(String, u32)] {
        &self.inputs
    }

    /// Get named outputs.
    #[must_use]
    pub fn outputs(&self) -> &[(String, NodeId)] {
        &self.outputs
    }

    /// Get source nodes (nodes with no dependencies).
    #[must_use]
    pub fn sources(&self) -> Vec<NodeId> {
        self.nodes()
            .filter(|node| node.dependencies().next().is_none())
            .map(|node| node.id)
            .collect()
    }

    /// Get sink nodes (nodes with no dependents).
    #[must_use]
    pub fn sinks(&self) -> Vec<NodeId> {
        let has_dependents: std::collections::HashSet<_> =
            self.nodes().flat_map(|node| node.dependencies()).collect();

        self.nodes()
            .filter(|node| !has_dependents.contains(&node.id))
            .map(|node| node.id)
            .collect()
    }

    /// Set the group for a node.
    pub fn set_group(&mut self, id: NodeId, group: GroupId) -> bool {
        if let Some(node) = self.get_mut(id) {
            node.group = group;
            true
        } else {
            false
        }
    }

    /// Allocate a slot, returning (index, generation).
    fn allocate_slot(&mut self) -> (u32, u32) {
        if let Some(index) = self.free_head {
            // Reuse a free slot
            let generation = self.generations[index as usize];
            if let Slot::Free { next_free } = self.slots[index as usize] {
                self.free_head = next_free;
            }
            (index, generation)
        } else {
            // Allocate a new slot
            let index = self.slots.len() as u32;
            self.slots.push(Slot::Free { next_free: None });
            self.generations.push(0);
            (index, 0)
        }
    }

    /// Check if a node ID has a valid generation.
    fn is_valid_id(&self, id: NodeId) -> bool {
        let index = id.index() as usize;
        index < self.generations.len() && self.generations[index] == id.generation()
    }
}

/// Connect a node's input to a source node.
pub fn connect<Op>(
    graph: &mut ComputeGraph<Op>,
    source: NodeId,
    target: NodeId,
    input_index: usize,
) {
    if let Some(node) = graph.get_mut(target) {
        while node.inputs.len() <= input_index {
            node.inputs.push(InputSlot::default());
        }
        node.inputs[input_index] = InputSlot::from_node(source);
    }
}

/// Connect a node's input to a graph input.
pub fn connect_graph_input<Op>(
    graph: &mut ComputeGraph<Op>,
    graph_input: u32,
    target: NodeId,
    input_index: usize,
) {
    if let Some(node) = graph.get_mut(target) {
        while node.inputs.len() <= input_index {
            node.inputs.push(InputSlot::default());
        }
        node.inputs[input_index] = InputSlot::from_graph_input(graph_input);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::node::InputSource;

    #[derive(Debug, Clone, PartialEq)]
    enum TestOp {
        Input,
        Add,
        Mul,
        Output,
    }

    #[test]
    fn test_empty_graph() {
        let graph: ComputeGraph<TestOp> = ComputeGraph::new();
        assert!(graph.is_empty());
        assert_eq!(graph.node_count(), 0);
    }

    #[test]
    fn test_add_node() {
        let mut graph = ComputeGraph::new();
        let id = graph.add_node(TestOp::Add);

        assert!(!graph.is_empty());
        assert_eq!(graph.node_count(), 1);
        assert!(graph.contains(id));

        let node = graph.get(id).unwrap();
        assert_eq!(node.id, id);
        assert_eq!(node.op, TestOp::Add);
    }

    #[test]
    fn test_remove_node() {
        let mut graph = ComputeGraph::new();
        let id = graph.add_node(TestOp::Add);

        let removed = graph.remove_node(id);
        assert!(removed.is_some());
        assert_eq!(removed.unwrap().op, TestOp::Add);
        assert!(!graph.contains(id));
        assert!(graph.is_empty());
    }

    #[test]
    fn test_stale_reference() {
        let mut graph = ComputeGraph::new();
        let id1 = graph.add_node(TestOp::Add);
        graph.remove_node(id1);

        // New node reuses the slot but has different generation
        let id2 = graph.add_node(TestOp::Mul);

        // Old ID no longer valid
        assert!(!graph.contains(id1));
        assert!(graph.contains(id2));
        assert_eq!(id1.index(), id2.index());
        assert_ne!(id1.generation(), id2.generation());
    }

    #[test]
    fn test_add_edge() {
        let mut graph = ComputeGraph::new();
        let a = graph.add_node(TestOp::Input);
        let b = graph.add_node(TestOp::Add);

        assert!(graph.add_edge(a, b));

        let node_b = graph.get(b).unwrap();
        assert_eq!(node_b.inputs.len(), 1);
        assert_eq!(node_b.inputs[0].source, InputSource::Node(a));
    }

    #[test]
    fn test_predecessors_successors() {
        let mut graph = ComputeGraph::new();
        let a = graph.add_node(TestOp::Input);
        let b = graph.add_node(TestOp::Input);
        let c = graph.add_node(TestOp::Add);
        graph.add_edge(a, c);
        graph.add_edge(b, c);

        let preds = graph.predecessors(c);
        assert_eq!(preds.len(), 2);
        assert!(preds.contains(&a));
        assert!(preds.contains(&b));

        let succs_a = graph.successors(a);
        assert_eq!(succs_a.len(), 1);
        assert!(succs_a.contains(&c));
    }

    #[test]
    fn test_sources_sinks() {
        let mut graph = ComputeGraph::new();
        let a = graph.add_node(TestOp::Input);
        let b = graph.add_node(TestOp::Input);
        let c = graph.add_node(TestOp::Add);
        let d = graph.add_node(TestOp::Output);

        graph.add_edge(a, c);
        graph.add_edge(b, c);
        graph.add_edge(c, d);

        let sources = graph.sources();
        assert_eq!(sources.len(), 2);
        assert!(sources.contains(&a));
        assert!(sources.contains(&b));

        let sinks = graph.sinks();
        assert_eq!(sinks.len(), 1);
        assert!(sinks.contains(&d));
    }

    #[test]
    fn test_edges() {
        let mut graph = ComputeGraph::new();
        let a = graph.add_node(TestOp::Input);
        let b = graph.add_node(TestOp::Add);
        let c = graph.add_node(TestOp::Output);

        graph.add_edge(a, b);
        graph.add_edge(b, c);

        let edges = graph.edges();
        assert_eq!(edges.len(), 2);
        assert!(edges.contains(&(a, b)));
        assert!(edges.contains(&(b, c)));
    }

    #[test]
    fn test_named_inputs_outputs() {
        let mut graph = ComputeGraph::new();
        let inp = graph.add_input("x");
        let node = graph.add_node(TestOp::Output);
        graph.add_output("y", node);

        assert_eq!(graph.inputs().len(), 1);
        assert_eq!(graph.inputs()[0].0, "x");
        assert_eq!(graph.inputs()[0].1, inp);

        assert_eq!(graph.outputs().len(), 1);
        assert_eq!(graph.outputs()[0].0, "y");
        assert_eq!(graph.outputs()[0].1, node);
    }

    #[test]
    fn test_connect_functions() {
        let mut graph = ComputeGraph::new();
        let a = graph.add_node(TestOp::Input);
        let b = graph.add_node(TestOp::Add);

        connect(&mut graph, a, b, 0);
        let gi = graph.add_input("x");
        connect_graph_input(&mut graph, gi, b, 1);

        let node = graph.get(b).unwrap();
        assert_eq!(node.inputs.len(), 2);
        assert_eq!(node.inputs[0].source, InputSource::Node(a));
        assert_eq!(node.inputs[1].source, InputSource::GraphInput { index: gi });
    }

    #[test]
    fn test_nodes_iteration() {
        let mut graph = ComputeGraph::new();
        graph.add_node(TestOp::Input);
        graph.add_node(TestOp::Add);
        graph.add_node(TestOp::Output);

        let ops: Vec<_> = graph.nodes().map(|n| n.op.clone()).collect();
        assert_eq!(ops.len(), 3);
        assert!(ops.contains(&TestOp::Input));
        assert!(ops.contains(&TestOp::Add));
        assert!(ops.contains(&TestOp::Output));
    }

    #[test]
    fn test_nodes_mut() {
        let mut graph = ComputeGraph::new();
        graph.add_node(TestOp::Input);
        let id = graph.add_node(TestOp::Add);

        for node in graph.nodes_mut() {
            node.num_outputs = 5;
        }

        assert_eq!(graph.get(id).unwrap().num_outputs, 5);
    }

    #[test]
    fn test_set_group() {
        let mut graph = ComputeGraph::new();
        let id = graph.add_node(TestOp::Add);

        assert!(graph.set_group(id, GroupId::new(7)));
        assert_eq!(graph.get(id).unwrap().group, GroupId::new(7));
    }

    #[test]
    fn test_with_capacity() {
        let graph: ComputeGraph<TestOp> = ComputeGraph::with_capacity(100);
        assert!(graph.is_empty());
    }

    #[test]
    fn test_add_constructed_node() {
        let mut graph = ComputeGraph::new();
        let node = Node::new(NodeId::null(), TestOp::Mul)
            .with_group(GroupId::new(3))
            .with_outputs(2);

        let id = graph.add_constructed_node(node);
        let stored = graph.get(id).unwrap();

        assert_eq!(stored.id, id);
        assert_eq!(stored.op, TestOp::Mul);
        assert_eq!(stored.group, GroupId::new(3));
        assert_eq!(stored.num_outputs, 2);
    }

    #[test]
    fn test_node_ids() {
        let mut graph = ComputeGraph::new();
        let a = graph.add_node(TestOp::Input);
        let b = graph.add_node(TestOp::Add);

        let ids = graph.node_ids();
        assert_eq!(ids.len(), 2);
        assert!(ids.contains(&a));
        assert!(ids.contains(&b));
    }

    #[test]
    fn test_remove_nonexistent() {
        let mut graph: ComputeGraph<TestOp> = ComputeGraph::new();
        let result = graph.remove_node(NodeId::new(0, 0));
        assert!(result.is_none());
    }

    #[test]
    fn test_add_edge_invalid_nodes() {
        let mut graph = ComputeGraph::new();
        let a = graph.add_node(TestOp::Input);
        let invalid = NodeId::new(999, 0);

        assert!(!graph.add_edge(invalid, a));
        assert!(!graph.add_edge(a, invalid));
    }
}
