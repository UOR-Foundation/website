fn main() {
    // Generate C header via cbindgen
    generate_c_header();
}

fn generate_c_header() {
    use std::env;
    use std::path::PathBuf;
    use std::process::Command;

    let workspace_dir = env::var("CARGO_MANIFEST_DIR")
        .map(PathBuf::from)
        .unwrap()
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .to_path_buf();

    let output_dir = workspace_dir.join("bindings/c");
    let output_file = output_dir.join("uor.h");

    // Create output directory
    if let Err(e) = std::fs::create_dir_all(&output_dir) {
        eprintln!("Failed to create directory: {}", e);
        return;
    }

    // Run cbindgen as a command (more reliable than the library API)
    let crate_path = workspace_dir.join("crates/ffi");
    let output = Command::new("cbindgen")
        .arg(&crate_path)
        .arg("--output")
        .arg(&output_file)
        .arg("--lang")
        .arg("c")
        .output();

    match output {
        Ok(result) if result.status.success() => {
            println!("cargo:warning=Generated C bindings at bindings/c/uor.h");
        }
        Ok(result) => {
            eprintln!(
                "cbindgen failed: {}",
                String::from_utf8_lossy(&result.stderr)
            );
        }
        Err(_) => {
            // cbindgen not found - silently continue
            // The ffi-c Justfile command will run it explicitly
        }
    }
}
