export { AvatarUpload as default } from "@/modules/identity/components/AvatarUpload";
