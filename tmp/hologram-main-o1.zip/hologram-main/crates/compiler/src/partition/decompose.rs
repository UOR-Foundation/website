//! Operation decomposition strategies.
//!
//! This module provides strategies for decomposing large operations
//! into smaller, parallelizable sub-operations.

use crate::graph::{CompileGraph, DType, OpKind};

/// `MatMul` decomposition strategy.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum MatMulStrategy {
    /// No decomposition - execute as single operation.
    #[default]
    Direct,
    /// Block decomposition along M and N dimensions.
    Block {
        /// Number of blocks along M dimension.
        m_blocks: usize,
        /// Number of blocks along N dimension.
        n_blocks: usize,
    },
}

/// Configuration for `MatMul` decomposition.
#[derive(Debug, Clone, Copy)]
pub struct DecomposeConfig {
    /// Minimum total elements (M*N) to consider decomposition.
    pub min_elements: usize,
    /// Target block size for each sub-`MatMul`.
    pub target_block_size: usize,
    /// Maximum aspect ratio (M/N or N/M) before forcing split.
    pub max_aspect_ratio: f64,
}

impl Default for DecomposeConfig {
    fn default() -> Self {
        Self {
            min_elements: 65536,
            target_block_size: 64,
            max_aspect_ratio: 4.0,
        }
    }
}

/// Determine the decomposition strategy for a `MatMul` operation.
///
/// # Arguments
///
/// * `m` - Number of rows in output (rows of A)
/// * `_k` - Shared dimension (cols of A, rows of B) - reserved for future use
/// * `n` - Number of columns in output (cols of B)
/// * `config` - Decomposition configuration
///
/// # Returns
///
/// The recommended decomposition strategy.
#[must_use]
pub fn choose_matmul_strategy(
    m: usize,
    _k: usize,
    n: usize,
    config: &DecomposeConfig,
) -> MatMulStrategy {
    let total_output = m * n;

    if total_output < config.min_elements {
        return MatMulStrategy::Direct;
    }

    #[allow(clippy::cast_precision_loss)]
    let aspect_ratio = if m > n {
        m as f64 / n as f64
    } else {
        n as f64 / m as f64
    };

    let m_blocks = compute_block_count(m, config.target_block_size);
    let n_blocks = compute_block_count(n, config.target_block_size);

    let (m_blocks, n_blocks) = if aspect_ratio > config.max_aspect_ratio {
        if m > n {
            (m_blocks.max(2), n_blocks.max(1))
        } else {
            (m_blocks.max(1), n_blocks.max(2))
        }
    } else {
        (m_blocks, n_blocks)
    };

    if m_blocks > 1 || n_blocks > 1 {
        MatMulStrategy::Block { m_blocks, n_blocks }
    } else {
        MatMulStrategy::Direct
    }
}

/// Compute the number of blocks for a dimension.
fn compute_block_count(dim: usize, target_block_size: usize) -> usize {
    if dim <= target_block_size {
        1
    } else {
        dim.div_ceil(target_block_size)
    }
}

/// Information about a decomposed `MatMul` sub-operation.
#[derive(Debug, Clone)]
pub struct MatMulBlock {
    /// Block index along M dimension.
    pub m_idx: usize,
    /// Block index along N dimension.
    pub n_idx: usize,
    /// Starting row in output.
    pub m_start: usize,
    /// Number of rows in this block.
    pub m_size: usize,
    /// Starting column in output.
    pub n_start: usize,
    /// Number of columns in this block.
    pub n_size: usize,
    /// K dimension (unchanged).
    pub k: usize,
}

/// Generate the blocks for a decomposed `MatMul`.
///
/// # Arguments
///
/// * `m` - Total rows in output
/// * `k` - Shared dimension
/// * `n` - Total columns in output
/// * `m_blocks` - Number of blocks along M
/// * `n_blocks` - Number of blocks along N
///
/// # Returns
///
/// A vector of `MatMulBlock` describing each sub-operation.
#[must_use]
pub fn generate_matmul_blocks(
    m: usize,
    k: usize,
    n: usize,
    m_blocks: usize,
    n_blocks: usize,
) -> Vec<MatMulBlock> {
    let mut blocks = Vec::with_capacity(m_blocks * n_blocks);

    for m_idx in 0..m_blocks {
        let m_start = m_idx * m / m_blocks;
        let m_end = (m_idx + 1) * m / m_blocks;
        let m_size = m_end - m_start;

        for n_idx in 0..n_blocks {
            let n_start = n_idx * n / n_blocks;
            let n_end = (n_idx + 1) * n / n_blocks;
            let n_size = n_end - n_start;

            blocks.push(MatMulBlock {
                m_idx,
                n_idx,
                m_start,
                m_size,
                n_start,
                n_size,
                k,
            });
        }
    }

    blocks
}

/// Decompose large `MatMul` operations in a graph.
///
/// This function finds `MatMul` nodes that exceed the cost threshold
/// and replaces them with multiple smaller `MatMul` operations that
/// can be executed in parallel.
///
/// # Arguments
///
/// * `graph` - The compile graph to modify
/// * `config` - Decomposition configuration
///
/// # Returns
///
/// The number of `MatMul` nodes that were decomposed.
pub fn decompose_matmuls(graph: &mut CompileGraph, config: &DecomposeConfig) -> usize {
    let mut decomposed_count = 0;

    let matmul_nodes: Vec<(u32, usize, usize, usize, DType)> = graph
        .nodes()
        .filter_map(|(id, node)| {
            if let OpKind::MatMul { m, k, n } = node.op {
                Some((id, m, k, n, node.dtype))
            } else {
                None
            }
        })
        .collect();

    for (node_id, m, k, n, _dtype) in matmul_nodes {
        let strategy = choose_matmul_strategy(m, k, n, config);

        if let MatMulStrategy::Block { m_blocks, n_blocks } = strategy {
            if let Some(node) = graph.get_node_mut(node_id) {
                node.annotations
                    .push(format!("decomposed:{m_blocks}x{n_blocks}"));
            }
            decomposed_count += 1;
        }
    }

    decomposed_count
}

/// Estimate the cost of a `MatMul` operation.
///
/// Cost is approximated as M * K * N (number of multiply-accumulate operations).
#[must_use]
pub const fn matmul_cost(m: usize, k: usize, n: usize) -> usize {
    m * k * n
}

/// Check if a `MatMul` should be decomposed based on cost threshold.
#[must_use]
pub fn should_decompose(m: usize, k: usize, n: usize, cost_threshold: usize) -> bool {
    matmul_cost(m, k, n) >= cost_threshold
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{OpNode, OperationGraph};

    #[test]
    fn test_choose_strategy_small_matrix() {
        let config = DecomposeConfig::default();
        let strategy = choose_matmul_strategy(32, 32, 32, &config);
        assert_eq!(strategy, MatMulStrategy::Direct);
    }

    #[test]
    fn test_choose_strategy_large_matrix() {
        let config = DecomposeConfig::default();
        let strategy = choose_matmul_strategy(512, 256, 512, &config);
        assert!(matches!(strategy, MatMulStrategy::Block { .. }));
    }

    #[test]
    fn test_choose_strategy_extreme_aspect_ratio() {
        let config = DecomposeConfig::default();
        let strategy = choose_matmul_strategy(1024, 128, 64, &config);
        if let MatMulStrategy::Block { m_blocks, n_blocks } = strategy {
            assert!(m_blocks >= n_blocks);
        }
    }

    #[test]
    fn test_compute_block_count_small() {
        assert_eq!(compute_block_count(32, 64), 1);
        assert_eq!(compute_block_count(64, 64), 1);
    }

    #[test]
    fn test_compute_block_count_large() {
        assert_eq!(compute_block_count(128, 64), 2);
        assert_eq!(compute_block_count(256, 64), 4);
        assert_eq!(compute_block_count(200, 64), 4);
    }

    #[test]
    fn test_generate_blocks_2x2() {
        let blocks = generate_matmul_blocks(128, 64, 128, 2, 2);
        assert_eq!(blocks.len(), 4);

        assert_eq!(blocks[0].m_idx, 0);
        assert_eq!(blocks[0].n_idx, 0);
        assert_eq!(blocks[0].m_start, 0);
        assert_eq!(blocks[0].m_size, 64);
        assert_eq!(blocks[0].n_start, 0);
        assert_eq!(blocks[0].n_size, 64);

        assert_eq!(blocks[3].m_idx, 1);
        assert_eq!(blocks[3].n_idx, 1);
        assert_eq!(blocks[3].m_start, 64);
        assert_eq!(blocks[3].m_size, 64);
        assert_eq!(blocks[3].n_start, 64);
        assert_eq!(blocks[3].n_size, 64);
    }

    #[test]
    fn test_generate_blocks_covers_all() {
        let m = 100;
        let n = 100;
        let blocks = generate_matmul_blocks(m, 50, n, 3, 3);

        let total_m: usize = blocks
            .iter()
            .filter(|b| b.n_idx == 0)
            .map(|b| b.m_size)
            .sum();
        let total_n: usize = blocks
            .iter()
            .filter(|b| b.m_idx == 0)
            .map(|b| b.n_size)
            .sum();
        assert_eq!(total_m, m);
        assert_eq!(total_n, n);
    }

    #[test]
    fn test_generate_blocks_single() {
        let blocks = generate_matmul_blocks(64, 32, 64, 1, 1);
        assert_eq!(blocks.len(), 1);
        assert_eq!(blocks[0].m_size, 64);
        assert_eq!(blocks[0].n_size, 64);
    }

    #[test]
    fn test_matmul_cost() {
        assert_eq!(matmul_cost(10, 10, 10), 1000);
        assert_eq!(matmul_cost(100, 100, 100), 1_000_000);
    }

    #[test]
    fn test_should_decompose() {
        assert!(!should_decompose(10, 10, 10, 10000));
        assert!(should_decompose(100, 100, 100, 10000));
    }

    #[test]
    fn test_decompose_matmuls_empty_graph() {
        let graph = OperationGraph::new();
        let mut compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        let config = DecomposeConfig::default();

        let count = decompose_matmuls(&mut compile_graph, &config);
        assert_eq!(count, 0);
    }

    #[test]
    fn test_decompose_matmuls_small_matmul() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![32, 32], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![32, 32], DType::F32));
        graph.add_node(OpNode::new(
            2,
            OpKind::MatMul {
                m: 32,
                k: 32,
                n: 32,
            },
            vec![32, 32],
            DType::F32,
        ));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![32, 32], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);

        let mut compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        let config = DecomposeConfig::default();

        let count = decompose_matmuls(&mut compile_graph, &config);
        assert_eq!(count, 0);
    }

    #[test]
    fn test_decompose_matmuls_large_matmul() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![512, 256], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![256, 512], DType::F32));
        graph.add_node(OpNode::new(
            2,
            OpKind::MatMul {
                m: 512,
                k: 256,
                n: 512,
            },
            vec![512, 512],
            DType::F32,
        ));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![512, 512], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);

        let mut compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        let config = DecomposeConfig::default();

        let count = decompose_matmuls(&mut compile_graph, &config);
        assert_eq!(count, 1);

        let node = compile_graph.get_node(2).unwrap();
        assert!(node
            .annotations
            .iter()
            .any(|a| a.starts_with("decomposed:")));
    }

    #[test]
    fn test_decompose_config_custom() {
        let config = DecomposeConfig {
            min_elements: 1024,
            target_block_size: 32,
            max_aspect_ratio: 2.0,
        };

        let strategy = choose_matmul_strategy(64, 64, 64, &config);
        assert!(matches!(strategy, MatMulStrategy::Block { .. }));
    }

    #[test]
    fn test_strategy_default() {
        assert_eq!(MatMulStrategy::default(), MatMulStrategy::Direct);
    }

    #[test]
    fn test_blocks_k_preserved() {
        let k = 128;
        let blocks = generate_matmul_blocks(256, k, 256, 4, 4);

        for block in &blocks {
            assert_eq!(block.k, k);
        }
    }
}
