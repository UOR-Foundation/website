//! Activation fusion pass.
//!
//! Detects chains of activation functions and collapses them into single
//! fused lookup table operations.

use crate::graph::CompileGraph;

/// Detect chains of activation functions and collapse into lookup tables.
///
/// This pass finds sequences like sigmoid -> tanh -> relu and fuses them:
/// 1. Identify chains of element-wise activation functions
/// 2. Mark the chain head with the composed activation sequence
/// 3. Remove intermediate nodes, rewiring edges
///
/// The actual lookup table composition is deferred to code generation.
/// This pass only identifies fusable chains and marks them.
pub fn activation_fusion(graph: &mut CompileGraph) {
    // Find activation chains starting from each activation node
    let mut chains = find_activation_chains(graph);

    // Sort chains by length (longest first) to handle overlapping chains
    chains.sort_by_key(|c| std::cmp::Reverse(c.len()));

    // Process each chain
    for chain in chains {
        if chain.len() < 2 {
            continue;
        }

        // Verify chain is still valid (nodes haven't been removed)
        if !chain_valid(graph, &chain) {
            continue;
        }

        // Fuse the chain
        fuse_activation_chain(graph, &chain);
    }
}

/// Find all activation chains in the graph.
fn find_activation_chains(graph: &CompileGraph) -> Vec<Vec<u32>> {
    let mut chains = Vec::new();
    let mut visited = std::collections::HashSet::new();

    // Start chains from activation nodes that aren't successors of other activations
    for (id, node) in graph.nodes() {
        if !node.op.is_activation() {
            continue;
        }

        // Skip if already part of a chain
        if visited.contains(&id) {
            continue;
        }

        // Check if this could be a chain start (predecessor is not an activation,
        // or this is the start of the chain)
        let preds = graph.predecessors(id);
        let is_chain_start = preds.is_empty()
            || preds
                .iter()
                .any(|&p| graph.get_node(p).is_none_or(|n| !n.op.is_activation()));

        if !is_chain_start {
            continue;
        }

        // Build chain from this node
        let mut chain = vec![id];
        let mut current = id;
        visited.insert(id);

        // Follow successors that are single-successor activations
        loop {
            let succs = graph.successors(current);

            // Must have exactly one successor
            if succs.len() != 1 {
                break;
            }

            let next = succs[0];

            // Successor must be an activation
            let Some(next_node) = graph.get_node(next) else {
                break;
            };
            if !next_node.op.is_activation() {
                break;
            }

            // Next node must have exactly one predecessor (this node)
            let next_preds = graph.predecessors(next);
            if next_preds.len() != 1 || next_preds[0] != current {
                break;
            }

            // Add to chain
            chain.push(next);
            visited.insert(next);
            current = next;
        }

        if chain.len() >= 2 {
            chains.push(chain);
        }
    }

    chains
}

/// Check if a chain is still valid (all nodes exist).
fn chain_valid(graph: &CompileGraph, chain: &[u32]) -> bool {
    chain.iter().all(|&id| graph.get_node(id).is_some())
}

/// Fuse an activation chain by keeping only the last node.
///
/// The last node in the chain is marked as the fused result.
/// All other chain nodes are removed after rewiring edges.
fn fuse_activation_chain(graph: &mut CompileGraph, chain: &[u32]) {
    if chain.len() < 2 {
        return;
    }

    let first = chain[0];
    let last = *chain.last().unwrap();

    // Build fusion annotation (e.g., "fused:sigmoid->tanh->relu")
    let chain_ops: Vec<_> = chain
        .iter()
        .filter_map(|&id| graph.get_node(id).map(|n| format!("{:?}", n.op)))
        .collect();
    let fusion_name = format!("fused:{}", chain_ops.join("->"));

    // Set the name on the last node
    if let Some(node) = graph.get_node_mut(last) {
        node.name = Some(fusion_name);
    }

    // Get first node's predecessors (these will become last's predecessors)
    let first_preds = graph.predecessors(first);

    // The last node's current predecessor is second-to-last in chain
    let second_to_last = chain[chain.len() - 2];

    // Rewire: make last's predecessor be first's predecessors instead of second_to_last
    for &pred in &first_preds {
        graph.replace_predecessor(last, second_to_last, pred);
    }

    // Remove all chain nodes except last
    for &id in &chain[..chain.len() - 1] {
        graph.remove_node(id);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpKind, OpNode, OperationGraph};

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    #[test]
    fn test_activation_fusion_empty_graph() {
        let mut graph = make_graph(vec![], vec![]);
        activation_fusion(&mut graph);
        assert_eq!(graph.node_count(), 0);
    }

    #[test]
    fn test_activation_fusion_no_chain() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let initial_count = graph.node_count();
        activation_fusion(&mut graph);

        // Single activation, no chain to fuse
        assert_eq!(graph.node_count(), initial_count);
    }

    #[test]
    fn test_activation_fusion_simple_chain() {
        // Input -> Sigmoid -> Tanh -> Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Sigmoid, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Tanh, vec![2, 3], DType::F32),
                OpNode::new(3, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3)],
        );

        let initial_count = graph.node_count();
        activation_fusion(&mut graph);

        // One intermediate node should be removed
        assert!(graph.node_count() < initial_count);

        // Last activation should be marked as fused
        let last = graph.get_node(2).unwrap();
        assert!(last.name.as_ref().is_some_and(|n| n.starts_with("fused:")));
    }

    #[test]
    fn test_activation_fusion_long_chain() {
        // Input -> Sigmoid -> Tanh -> Relu -> Gelu -> Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Sigmoid, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Tanh, vec![2, 3], DType::F32),
                OpNode::new(3, OpKind::Relu, vec![2, 3], DType::F32),
                OpNode::new(4, OpKind::Gelu, vec![2, 3], DType::F32),
                OpNode::new(5, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3), (3, 4), (4, 5)],
        );

        let initial_count = graph.node_count();
        activation_fusion(&mut graph);

        // Multiple intermediate nodes should be removed
        assert!(graph.node_count() < initial_count);
    }

    #[test]
    fn test_activation_fusion_branching_not_fused() {
        // Input -> Sigmoid -> [Tanh1, Tanh2] -> ...
        // Branching breaks the chain
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Sigmoid, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Tanh, vec![2, 3], DType::F32),
                OpNode::new(3, OpKind::Tanh, vec![2, 3], DType::F32),
            ],
            vec![(0, 1), (1, 2), (1, 3)],
        );

        let initial_count = graph.node_count();
        activation_fusion(&mut graph);

        // Branching prevents fusion
        assert_eq!(graph.node_count(), initial_count);
    }

    #[test]
    fn test_activation_fusion_mixed_ops_break_chain() {
        // Input -> Sigmoid -> Add -> Tanh -> Output
        // Add is not an activation, breaks the chain
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3], DType::F32),
                OpNode::new(1, OpKind::Sigmoid, vec![2, 3], DType::F32),
                OpNode::new(2, OpKind::Add, vec![2, 3], DType::F32),
                OpNode::new(3, OpKind::Tanh, vec![2, 3], DType::F32),
                OpNode::new(4, OpKind::Output, vec![2, 3], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3), (3, 4)],
        );

        let initial_count = graph.node_count();
        activation_fusion(&mut graph);

        // Add breaks the chain, no fusion
        assert_eq!(graph.node_count(), initial_count);
    }

    #[test]
    fn test_is_activation() {
        assert!(OpKind::Sigmoid.is_activation());
        assert!(OpKind::Tanh.is_activation());
        assert!(OpKind::Relu.is_activation());
        assert!(OpKind::Gelu.is_activation());
        assert!(OpKind::Silu.is_activation());

        assert!(!OpKind::Add.is_activation());
        assert!(!OpKind::MatMul { m: 1, k: 1, n: 1 }.is_activation());
        assert!(!OpKind::Softmax { axis: -1 }.is_activation());
        assert!(!OpKind::Input.is_activation());
        assert!(!OpKind::Output.is_activation());
    }
}
