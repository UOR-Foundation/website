use std::env;
use std::fs;
use std::path::Path;

fn main() {
    let shell_path =
        Path::new(env!("CARGO_MANIFEST_DIR")).join("../../descriptors/shells/isa.shell");

    println!("cargo:rerun-if-changed={}", shell_path.display());

    let input = fs::read_to_string(&shell_path)
        .unwrap_or_else(|e| panic!("failed to read {}: {e}", shell_path.display()));

    let shell = hologram_shell::parse_shell(&input)
        .unwrap_or_else(|e| panic!("failed to parse isa.shell: {e}"));

    let out_dir = env::var_os("OUT_DIR").unwrap();

    // Generate the ISA instruction enum
    let enum_code = hologram_shell::emit_isa::emit_instruction_enum(&shell);
    fs::write(
        Path::new(&out_dir).join("generated_instruction.rs"),
        format!("// Auto-generated from isa.shell — do not edit.\n\n{enum_code}"),
    )
    .unwrap();

    // Generate builder structs + factory methods
    let builder_code = hologram_shell::emit_isa::emit_builder_structs(&shell);
    fs::write(
        Path::new(&out_dir).join("generated_builder.rs"),
        format!("// Auto-generated from isa.shell — do not edit.\n\n{builder_code}"),
    )
    .unwrap();

    // Generate IsaInstruction::name() method
    let name_code = hologram_shell::emit_isa::emit_instruction_name(&shell);
    fs::write(
        Path::new(&out_dir).join("generated_instruction_name.rs"),
        format!("// Auto-generated from isa.shell — do not edit.\n\n{name_code}"),
    )
    .unwrap();
}
