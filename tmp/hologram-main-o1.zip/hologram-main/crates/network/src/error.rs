//! Error types for network operations.

use thiserror::Error;

/// Error type for network operations.
#[derive(Debug, Error)]
pub enum NetworkError {
    /// Peer not found.
    #[error("peer not found: {0}")]
    PeerNotFound(String),

    /// Peer disconnected.
    #[error("peer disconnected: {0}")]
    PeerDisconnected(String),

    /// Connection failed.
    #[error("connection failed: {message}")]
    ConnectionFailed {
        /// Error message.
        message: String,
    },

    /// Request timeout.
    #[error("request timeout after {duration_ms}ms")]
    Timeout {
        /// Timeout duration in milliseconds.
        duration_ms: u64,
    },

    /// Request cancelled.
    #[error("request cancelled")]
    RequestCancelled,

    /// Content not found.
    #[error("content not found: {0}")]
    ContentNotFound(String),

    /// Content hash mismatch.
    #[error("content hash mismatch: expected {expected}, got {actual}")]
    HashMismatch {
        /// Expected hash.
        expected: String,
        /// Actual hash.
        actual: String,
    },

    /// Storage full.
    #[error("storage full: capacity {capacity} bytes")]
    StorageFull {
        /// Storage capacity.
        capacity: u64,
    },

    /// Layer not found.
    #[error("layer not found: {0}")]
    LayerNotFound(String),

    /// Invalid message.
    #[error("invalid message: {0}")]
    InvalidMessage(String),

    /// Protocol error.
    #[error("protocol error: {0}")]
    ProtocolError(String),

    /// Scheduler error.
    #[error("scheduler error: {message}")]
    SchedulerError {
        /// Error message.
        message: String,
    },

    /// Executor error.
    #[error("executor error: {message}")]
    ExecutorError {
        /// Error message.
        message: String,
    },

    /// No workers available.
    #[error("no workers available for layer: {layer}")]
    NoWorkersAvailable {
        /// Layer reference.
        layer: String,
    },

    /// Worker failed.
    #[error("worker failed: {message}")]
    WorkerFailed {
        /// Error message.
        message: String,
    },

    /// IO error.
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),

    /// Serialization error.
    #[error("serialization error: {0}")]
    Serialization(String),

    /// Registry error.
    #[error("registry error: {0}")]
    Registry(#[from] hologram_registry::RegistryError),
}

impl NetworkError {
    /// Create a connection failed error.
    #[must_use]
    pub fn connection_failed(message: impl Into<String>) -> Self {
        Self::ConnectionFailed {
            message: message.into(),
        }
    }

    /// Create a timeout error.
    #[must_use]
    pub fn timeout(duration_ms: u64) -> Self {
        Self::Timeout { duration_ms }
    }

    /// Create a scheduler error.
    #[must_use]
    pub fn scheduler(message: impl Into<String>) -> Self {
        Self::SchedulerError {
            message: message.into(),
        }
    }

    /// Create an executor error.
    #[must_use]
    pub fn executor(message: impl Into<String>) -> Self {
        Self::ExecutorError {
            message: message.into(),
        }
    }

    /// Create a no workers error.
    #[must_use]
    pub fn no_workers(layer: impl Into<String>) -> Self {
        Self::NoWorkersAvailable {
            layer: layer.into(),
        }
    }

    /// Create a serialization error.
    #[must_use]
    pub fn serialization(message: impl Into<String>) -> Self {
        Self::Serialization(message.into())
    }

    /// Check if this error is retryable.
    #[must_use]
    pub fn is_retryable(&self) -> bool {
        matches!(
            self,
            Self::Timeout { .. }
                | Self::PeerDisconnected(_)
                | Self::ConnectionFailed { .. }
                | Self::NoWorkersAvailable { .. }
        )
    }

    /// Check if this error indicates content not found.
    #[must_use]
    pub fn is_not_found(&self) -> bool {
        matches!(
            self,
            Self::ContentNotFound(_) | Self::LayerNotFound(_) | Self::PeerNotFound(_)
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_error_display() {
        let err = NetworkError::PeerNotFound("peer-123".to_string());
        assert!(err.to_string().contains("peer-123"));

        let err = NetworkError::timeout(5000);
        assert!(err.to_string().contains("5000"));

        let err = NetworkError::ContentNotFound("abc123".to_string());
        assert!(err.to_string().contains("abc123"));
    }

    #[test]
    fn test_error_constructors() {
        let _ = NetworkError::connection_failed("refused");
        let _ = NetworkError::timeout(1000);
        let _ = NetworkError::scheduler("no workers");
        let _ = NetworkError::executor("failed");
        let _ = NetworkError::no_workers("layer1");
        let _ = NetworkError::serialization("invalid json");
    }

    #[test]
    fn test_is_retryable() {
        assert!(NetworkError::timeout(1000).is_retryable());
        assert!(NetworkError::PeerDisconnected("p".to_string()).is_retryable());
        assert!(NetworkError::connection_failed("c").is_retryable());
        assert!(NetworkError::no_workers("l").is_retryable());
        assert!(!NetworkError::ContentNotFound("c".to_string()).is_retryable());
    }

    #[test]
    fn test_is_not_found() {
        assert!(NetworkError::ContentNotFound("c".to_string()).is_not_found());
        assert!(NetworkError::LayerNotFound("l".to_string()).is_not_found());
        assert!(NetworkError::PeerNotFound("p".to_string()).is_not_found());
        assert!(!NetworkError::timeout(1000).is_not_found());
    }

    #[test]
    fn test_io_error_from() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "file not found");
        let err: NetworkError = io_err.into();
        assert!(matches!(err, NetworkError::Io(_)));
    }
}
