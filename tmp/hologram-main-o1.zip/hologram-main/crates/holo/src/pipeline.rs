//! Pipeline bundle (HOLM) reader and writer.
//!
//! This module provides reader and writer for `.holo` pipeline bundles
//! containing multiple models.

// Allow casts in this module since we're working with file format offsets
// that are designed for 64-bit but safe for practical file sizes.
#![allow(clippy::cast_possible_truncation)]

use std::fs::File;
use std::io::Write;
use std::path::Path;

use crate::error::HoloError;
use crate::format::{
    align_to_page, crc32, HolmHeader, PipelineModelEntry, HOLB_MAGIC, HOLM_HEADER_SIZE,
};
use crate::Result;

/// Writer for pipeline bundles (HOLM format).
///
/// Creates `.holo` files containing multiple HOLB models.
///
/// # Example
///
/// ```rust
/// use hologram_holo::pipeline::HolmWriter;
/// use hologram_holo::writer::HolbWriter;
///
/// // Create individual HOLB bundles
/// let mut holb1 = HolbWriter::new();
/// holb1.set_graph(&[1, 2, 3]);
/// let model1 = holb1.build().unwrap();
///
/// let mut holb2 = HolbWriter::new();
/// holb2.set_graph(&[4, 5, 6]);
/// let model2 = holb2.build().unwrap();
///
/// // Package into pipeline
/// let mut writer = HolmWriter::new();
/// writer.add_model("encoder", &model1).unwrap();
/// writer.add_model("decoder", &model2).unwrap();
/// let pipeline = writer.build().unwrap();
/// ```
pub struct HolmWriter {
    models: Vec<(String, Vec<u8>)>,
}

impl HolmWriter {
    /// Create a new HOLM writer.
    #[must_use]
    pub fn new() -> Self {
        Self { models: Vec::new() }
    }

    /// Add a model to the pipeline.
    ///
    /// The model data should be a complete HOLB bundle.
    ///
    /// # Errors
    /// Returns error if:
    /// - The bundle data doesn't start with HOLB magic bytes
    /// - A model with the same name already exists
    pub fn add_model(&mut self, name: &str, bundle_data: &[u8]) -> Result<()> {
        // Verify it's a HOLB bundle
        if bundle_data.len() < 4 || &bundle_data[0..4] != HOLB_MAGIC {
            return Err(HoloError::invalid_magic(
                HOLB_MAGIC,
                &bundle_data[..4.min(bundle_data.len())],
            ));
        }

        // Check for duplicate name
        if self.models.iter().any(|(n, _)| n == name) {
            return Err(HoloError::duplicate_model(name));
        }

        self.models.push((name.to_string(), bundle_data.to_vec()));
        Ok(())
    }

    /// Add a model without validation.
    ///
    /// Use this when you know the data is a valid HOLB bundle.
    pub fn add_model_unchecked(&mut self, name: impl Into<String>, bundle_data: Vec<u8>) {
        self.models.push((name.into(), bundle_data));
    }

    /// Get the number of models in the pipeline.
    #[must_use]
    pub fn model_count(&self) -> usize {
        self.models.len()
    }

    /// Build the pipeline bundle and return the bytes.
    ///
    /// # Errors
    /// Returns error if no models have been added.
    pub fn build(&mut self) -> Result<Vec<u8>> {
        if self.models.is_empty() {
            return Err(HoloError::EmptyBundle);
        }

        // Calculate index
        let index_entries: Vec<PipelineModelEntry> = self
            .models
            .iter()
            .map(|(name, _)| PipelineModelEntry::new(name.clone(), 0, 0, 0))
            .collect();

        // Calculate index size
        let index_size: usize = index_entries
            .iter()
            .map(PipelineModelEntry::serialized_size)
            .sum();

        // Calculate models offset (page-aligned after index)
        let models_offset = align_to_page(HOLM_HEADER_SIZE as u64 + index_size as u64);

        // Calculate model offsets and total size
        let mut model_entries: Vec<PipelineModelEntry> = Vec::with_capacity(self.models.len());
        let mut current_offset = models_offset;

        for (name, data) in &self.models {
            let entry = PipelineModelEntry::new(
                name.clone(),
                current_offset,
                data.len() as u64,
                crc32(data),
            );
            model_entries.push(entry);

            // Next model starts at page-aligned offset after this one
            current_offset = align_to_page(current_offset + data.len() as u64);
        }

        let models_total_size = model_entries.iter().map(|e| e.size).sum::<u64>();

        // Build index bytes
        let mut index_bytes = Vec::with_capacity(index_size);
        for entry in &model_entries {
            index_bytes.extend_from_slice(&entry.to_bytes());
        }

        let index_checksum = crc32(&index_bytes);

        // Build header
        let header = HolmHeader {
            magic: *crate::HOLM_MAGIC,
            version: 1,
            flags: 0,
            model_count: self.models.len() as u32,
            index_offset: HOLM_HEADER_SIZE as u64,
            index_size: index_bytes.len() as u64,
            models_offset,
            models_total_size,
            index_checksum,
            _reserved: 0,
        };

        // Allocate buffer
        let last_model = model_entries.last().unwrap();
        let total_size = (last_model.offset + last_model.size) as usize;
        let mut buf = vec![0u8; total_size];

        // Write header
        buf[..HOLM_HEADER_SIZE].copy_from_slice(&header.to_bytes());

        // Write index
        buf[HOLM_HEADER_SIZE..HOLM_HEADER_SIZE + index_bytes.len()].copy_from_slice(&index_bytes);

        // Write models
        for (entry, (_, data)) in model_entries.iter().zip(&self.models) {
            buf[entry.offset as usize..entry.offset as usize + data.len()].copy_from_slice(data);
        }

        Ok(buf)
    }

    /// Write the pipeline to a file.
    ///
    /// # Errors
    /// Returns error if file cannot be written.
    pub fn write_to_file(&mut self, path: impl AsRef<Path>) -> Result<()> {
        let data = self.build()?;
        let mut file = File::create(path)?;
        file.write_all(&data)?;
        Ok(())
    }
}

impl Default for HolmWriter {
    fn default() -> Self {
        Self::new()
    }
}

/// Reader for pipeline bundles (HOLM format).
///
/// Provides zero-copy access to models within a `.holo` pipeline.
///
/// # Example
///
/// ```rust,no_run
/// use hologram_holo::pipeline::HolmReader;
///
/// let data: Vec<u8> = std::fs::read("pipeline.holo").unwrap();
/// let reader = HolmReader::from_bytes(&data).unwrap();
///
/// println!("Models: {:?}", reader.model_names());
///
/// if let Some(encoder) = reader.get_model("encoder").unwrap() {
///     println!("Encoder size: {} bytes", encoder.len());
/// }
/// ```
pub struct HolmReader<'a> {
    data: &'a [u8],
    header: HolmHeader,
    entries: Vec<PipelineModelEntry>,
}

impl<'a> HolmReader<'a> {
    /// Create a reader from raw bytes.
    ///
    /// # Errors
    /// Returns error if the data is not a valid HOLM bundle.
    pub fn from_bytes(data: &'a [u8]) -> Result<Self> {
        if data.len() < HOLM_HEADER_SIZE {
            return Err(HoloError::Other(format!(
                "Buffer too small: expected at least {HOLM_HEADER_SIZE}, got {}",
                data.len()
            )));
        }

        let header = HolmHeader::from_bytes(data)?;
        header.validate()?;

        // Parse model index
        let index_start = header.index_offset as usize;
        let index_end = index_start + header.index_size as usize;

        if index_end > data.len() {
            return Err(HoloError::invalid_bounds(
                index_start,
                header.index_size as usize,
                data.len(),
            ));
        }

        // Verify index checksum
        let index_bytes = &data[index_start..index_end];
        let computed_checksum = crc32(index_bytes);
        if computed_checksum != header.index_checksum {
            return Err(HoloError::checksum_mismatch(
                header.index_checksum,
                computed_checksum,
            ));
        }

        // Parse entries
        let mut entries = Vec::with_capacity(header.model_count as usize);
        let mut offset = 0;

        for _ in 0..header.model_count {
            let (entry, consumed) = PipelineModelEntry::from_bytes(&index_bytes[offset..])?;
            entries.push(entry);
            offset += consumed;
        }

        Ok(Self {
            data,
            header,
            entries,
        })
    }

    /// Get the format version.
    #[must_use]
    pub const fn version(&self) -> u32 {
        self.header.version
    }

    /// Get the number of models in the pipeline.
    #[must_use]
    pub fn model_count(&self) -> usize {
        self.entries.len()
    }

    /// Get the names of all models.
    #[must_use]
    pub fn model_names(&self) -> Vec<&str> {
        self.entries.iter().map(|e| e.name.as_str()).collect()
    }

    /// Get the model index entries.
    #[must_use]
    pub fn entries(&self) -> &[PipelineModelEntry] {
        &self.entries
    }

    /// Get a model by name.
    ///
    /// Returns `None` if the model doesn't exist.
    ///
    /// # Errors
    /// Returns error if the model data is out of bounds.
    pub fn get_model(&self, name: &str) -> Result<Option<&'a [u8]>> {
        let Some(entry) = self.entries.iter().find(|e| e.name == name) else {
            return Ok(None);
        };

        self.get_model_data(entry)
    }

    /// Get a model by index.
    ///
    /// # Errors
    /// Returns error if the index is out of bounds or model data is invalid.
    pub fn get_model_by_index(&self, index: usize) -> Result<Option<&'a [u8]>> {
        let Some(entry) = self.entries.get(index) else {
            return Ok(None);
        };

        self.get_model_data(entry)
    }

    /// Get model data and verify checksum.
    fn get_model_data(&self, entry: &PipelineModelEntry) -> Result<Option<&'a [u8]>> {
        let start = entry.offset as usize;
        let end = start + entry.size as usize;

        if end > self.data.len() {
            return Err(HoloError::invalid_bounds(
                start,
                entry.size as usize,
                self.data.len(),
            ));
        }

        let model_data = &self.data[start..end];

        // Verify checksum
        let computed = crc32(model_data);
        if computed != entry.checksum {
            return Err(HoloError::checksum_mismatch(entry.checksum, computed));
        }

        Ok(Some(model_data))
    }

    /// Iterate over all models.
    ///
    /// Yields `(name, data)` pairs. Checksum verification is performed for each model.
    pub fn iter_models(&'a self) -> impl Iterator<Item = (&'a str, Result<&'a [u8]>)> {
        self.entries.iter().map(move |entry| {
            let result = self.get_model_data(entry).map(|opt| opt.unwrap());
            (entry.name.as_str(), result)
        })
    }

    /// Verify all model checksums without returning data.
    #[must_use]
    pub fn verify_all_checksums(&self) -> bool {
        for entry in &self.entries {
            let start = entry.offset as usize;
            let end = start + entry.size as usize;

            if end > self.data.len() {
                return false;
            }

            let model_data = &self.data[start..end];
            if crc32(model_data) != entry.checksum {
                return false;
            }
        }
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::writer::HolbWriter;

    fn create_test_holb(data: &[u8]) -> Vec<u8> {
        let mut writer = HolbWriter::new();
        writer.set_graph(data);
        writer.build().unwrap()
    }

    #[test]
    fn test_writer_new() {
        let writer = HolmWriter::new();
        assert_eq!(writer.model_count(), 0);
    }

    #[test]
    fn test_writer_empty_pipeline() {
        let mut writer = HolmWriter::new();
        assert!(writer.build().is_err());
    }

    #[test]
    fn test_writer_single_model() {
        let holb = create_test_holb(&[1, 2, 3]);

        let mut writer = HolmWriter::new();
        writer.add_model("test", &holb).unwrap();

        let pipeline = writer.build().unwrap();

        let header = HolmHeader::from_bytes(&pipeline).unwrap();
        assert_eq!(header.model_count, 1);
    }

    #[test]
    fn test_writer_multiple_models() {
        let holb1 = create_test_holb(&[1, 2, 3]);
        let holb2 = create_test_holb(&[4, 5, 6, 7]);
        let holb3 = create_test_holb(&[8, 9]);

        let mut writer = HolmWriter::new();
        writer.add_model("encoder", &holb1).unwrap();
        writer.add_model("decoder", &holb2).unwrap();
        writer.add_model("classifier", &holb3).unwrap();

        let pipeline = writer.build().unwrap();

        let header = HolmHeader::from_bytes(&pipeline).unwrap();
        assert_eq!(header.model_count, 3);
    }

    #[test]
    fn test_writer_duplicate_name() {
        let holb1 = create_test_holb(&[1, 2]);
        let holb2 = create_test_holb(&[3, 4]);

        let mut writer = HolmWriter::new();
        writer.add_model("model", &holb1).unwrap();

        let result = writer.add_model("model", &holb2);
        assert!(result.is_err());
    }

    #[test]
    fn test_writer_invalid_holb() {
        let mut writer = HolmWriter::new();
        let result = writer.add_model("bad", &[1, 2, 3, 4]);
        assert!(result.is_err());
    }

    #[test]
    fn test_reader_roundtrip() {
        let holb1 = create_test_holb(&[1, 2, 3]);
        let holb2 = create_test_holb(&[4, 5, 6, 7, 8]);

        let mut writer = HolmWriter::new();
        writer.add_model("model_a", &holb1).unwrap();
        writer.add_model("model_b", &holb2).unwrap();

        let pipeline = writer.build().unwrap();

        let reader = HolmReader::from_bytes(&pipeline).unwrap();

        assert_eq!(reader.model_count(), 2);
        assert_eq!(reader.model_names(), vec!["model_a", "model_b"]);
        assert_eq!(reader.version(), 1);
    }

    #[test]
    fn test_reader_get_model() {
        let holb1 = create_test_holb(&[10, 20]);
        let holb2 = create_test_holb(&[30, 40, 50]);

        let mut writer = HolmWriter::new();
        writer.add_model("first", &holb1).unwrap();
        writer.add_model("second", &holb2).unwrap();

        let pipeline = writer.build().unwrap();
        let reader = HolmReader::from_bytes(&pipeline).unwrap();

        let first = reader.get_model("first").unwrap().unwrap();
        assert_eq!(first, &holb1[..]);

        let second = reader.get_model("second").unwrap().unwrap();
        assert_eq!(second, &holb2[..]);

        let missing = reader.get_model("missing").unwrap();
        assert!(missing.is_none());
    }

    #[test]
    fn test_reader_get_model_by_index() {
        let holb = create_test_holb(&[1, 2, 3]);

        let mut writer = HolmWriter::new();
        writer.add_model("test", &holb).unwrap();

        let pipeline = writer.build().unwrap();
        let reader = HolmReader::from_bytes(&pipeline).unwrap();

        let model = reader.get_model_by_index(0).unwrap().unwrap();
        assert_eq!(model, &holb[..]);

        let missing = reader.get_model_by_index(99).unwrap();
        assert!(missing.is_none());
    }

    #[test]
    fn test_reader_iter_models() {
        let holb1 = create_test_holb(&[1]);
        let holb2 = create_test_holb(&[2]);

        let mut writer = HolmWriter::new();
        writer.add_model("a", &holb1).unwrap();
        writer.add_model("b", &holb2).unwrap();

        let pipeline = writer.build().unwrap();
        let reader = HolmReader::from_bytes(&pipeline).unwrap();

        let models: Vec<_> = reader.iter_models().collect();
        assert_eq!(models.len(), 2);
        assert_eq!(models[0].0, "a");
        assert_eq!(models[1].0, "b");
    }

    #[test]
    fn test_reader_verify_checksums() {
        let holb = create_test_holb(&[1, 2, 3, 4, 5]);

        let mut writer = HolmWriter::new();
        writer.add_model("test", &holb).unwrap();

        let pipeline = writer.build().unwrap();
        let reader = HolmReader::from_bytes(&pipeline).unwrap();

        assert!(reader.verify_all_checksums());
    }

    #[test]
    fn test_reader_invalid_magic() {
        let bad_data = vec![b'J', b'U', b'N', b'K', 0, 0, 0, 0];
        let result = HolmReader::from_bytes(&bad_data);
        assert!(result.is_err());
    }

    #[test]
    fn test_reader_too_small() {
        let small_data = vec![0u8; 10];
        let result = HolmReader::from_bytes(&small_data);
        assert!(result.is_err());
    }

    #[test]
    fn test_writer_default() {
        let writer = HolmWriter::default();
        assert_eq!(writer.model_count(), 0);
    }
}
