//! Benchmarks for microcode operations vs native implementations.
//!
//! This benchmark suite compares:
//! - Microcode primitives (bnot, neg, xor, and, or)
//! - Microcode derived ops (inc, dec, add, sub) vs native equivalents
//! - Kogge-Stone adder vs native addition
//!
//! The goal is to measure the overhead of microcode-based operations
//! and validate that native overrides provide significant speedup.

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};

use hologram_backend::microcode::BackendImpl;
use uor::microcode::{KoggeStoneAdder, MicrocodeOps, MicrocodePrimitives, ScalarPrimitives};

/// Number of iterations for throughput measurement.
const ITERATIONS: u64 = 1000;

// =============================================================================
// Primitive Benchmarks
// =============================================================================

fn bench_primitives_u32(c: &mut Criterion) {
    let mut group = c.benchmark_group("primitives_u32");
    group.throughput(Throughput::Elements(ITERATIONS));

    let backend = BackendImpl::auto_select();
    let scalar = ScalarPrimitives;

    // Test values
    let a: u32 = 0xDEAD_BEEF;
    let b: u32 = 0xCAFE_BABE;

    // bnot
    group.bench_function("bnot_backend", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = backend.bnot(black_box(result));
            }
            result
        })
    });

    group.bench_function("bnot_scalar", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = scalar.bnot(black_box(result));
            }
            result
        })
    });

    group.bench_function("bnot_native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = !black_box(result);
            }
            result
        })
    });

    // neg
    group.bench_function("neg_backend", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = backend.neg(black_box(result));
            }
            result
        })
    });

    group.bench_function("neg_native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = black_box(result).wrapping_neg();
            }
            result
        })
    });

    // xor
    group.bench_function("xor_backend", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = backend.xor(black_box(result), black_box(b));
            }
            result
        })
    });

    group.bench_function("xor_native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = black_box(result) ^ black_box(b);
            }
            result
        })
    });

    // and
    group.bench_function("and_backend", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = backend.and(black_box(result), black_box(b));
            }
            result
        })
    });

    group.bench_function("and_native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = black_box(result) & black_box(b);
            }
            result
        })
    });

    // or
    group.bench_function("or_backend", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = backend.or(black_box(result), black_box(b));
            }
            result
        })
    });

    group.bench_function("or_native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = black_box(result) | black_box(b);
            }
            result
        })
    });

    group.finish();
}

// =============================================================================
// Derived Operation Benchmarks
// =============================================================================

fn bench_derived_ops_u32(c: &mut Criterion) {
    let mut group = c.benchmark_group("derived_ops_u32");
    group.throughput(Throughput::Elements(ITERATIONS));

    let backend = BackendImpl::auto_select();
    let a: u32 = 0xDEAD_BEEF;
    let b: u32 = 0x0000_1000;

    // inc (microcode: neg(bnot(x)))
    group.bench_function("inc_microcode", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = backend.inc(black_box(result));
            }
            result
        })
    });

    group.bench_function("inc_native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = black_box(result).wrapping_add(1);
            }
            result
        })
    });

    // dec (microcode: bnot(neg(x)))
    group.bench_function("dec_microcode", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = backend.dec(black_box(result));
            }
            result
        })
    });

    group.bench_function("dec_native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = black_box(result).wrapping_sub(1);
            }
            result
        })
    });

    // add (microcode: Kogge-Stone)
    group.bench_function("add_microcode", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = backend.add(black_box(result), black_box(b));
            }
            result
        })
    });

    group.bench_function("add_native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = black_box(result).wrapping_add(black_box(b));
            }
            result
        })
    });

    // sub (microcode: add(a, neg(b)))
    group.bench_function("sub_microcode", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = backend.sub(black_box(result), black_box(b));
            }
            result
        })
    });

    group.bench_function("sub_native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = black_box(result).wrapping_sub(black_box(b));
            }
            result
        })
    });

    group.finish();
}

// =============================================================================
// Kogge-Stone Adder Benchmarks
// =============================================================================

fn bench_kogge_stone(c: &mut Criterion) {
    let mut group = c.benchmark_group("kogge_stone");
    let scalar = ScalarPrimitives;

    // Single operation latency
    group.bench_function("add_single_u32", |bench| {
        let a: u32 = 0xDEAD_BEEF;
        let b: u32 = 0xCAFE_BABE;
        bench.iter(|| KoggeStoneAdder::add(&scalar, black_box(a), black_box(b)))
    });

    group.bench_function("add_single_native_u32", |bench| {
        let a: u32 = 0xDEAD_BEEF;
        let b: u32 = 0xCAFE_BABE;
        bench.iter(|| black_box(a).wrapping_add(black_box(b)))
    });

    // Array (SIMD-like) operations
    group.bench_function("add_array_4xu32", |bench| {
        let a: [u32; 4] = [1, 2, 3, 4];
        let b: [u32; 4] = [5, 6, 7, 8];
        bench.iter(|| KoggeStoneAdder::add(&scalar, black_box(a), black_box(b)))
    });

    group.bench_function("add_array_8xu32", |bench| {
        let a: [u32; 8] = [1, 2, 3, 4, 5, 6, 7, 8];
        let b: [u32; 8] = [9, 10, 11, 12, 13, 14, 15, 16];
        bench.iter(|| KoggeStoneAdder::add(&scalar, black_box(a), black_box(b)))
    });

    group.finish();
}

// =============================================================================
// Backend Selection Overhead
// =============================================================================

fn bench_backend_selection(c: &mut Criterion) {
    let mut group = c.benchmark_group("backend_selection");

    // Measure auto_select overhead
    group.bench_function("auto_select", |bench| bench.iter(BackendImpl::auto_select));

    // Measure compile_time_optimal (should be essentially free)
    group.bench_function("compile_time_optimal", |bench| {
        bench.iter(BackendImpl::compile_time_optimal)
    });

    // Measure the cost of creating a backend and performing one operation
    group.bench_function("select_and_inc", |bench| {
        let a: u32 = 42;
        bench.iter(|| {
            let backend = BackendImpl::auto_select();
            backend.inc(black_box(a))
        })
    });

    // Pre-selected backend (amortized cost)
    let backend = BackendImpl::auto_select();
    group.bench_function("pre_selected_inc", |bench| {
        let a: u32 = 42;
        bench.iter(|| backend.inc(black_box(a)))
    });

    group.finish();
}

// =============================================================================
// Cached Target Selection Benchmarks (TASK-124)
// =============================================================================

fn bench_cached_target(c: &mut Criterion) {
    use hologram_backend::{auto_select_target, cached_target};

    let mut group = c.benchmark_group("cached_target");

    // Warm up the cache (first call initializes)
    let _ = cached_target();

    // Measure cached_target access (should be < 1ns)
    // This is the critical benchmark - after first call, access should be
    // essentially just an atomic load.
    group.bench_function("cached_access", |bench| {
        bench.iter(|| black_box(cached_target()))
    });

    // Measure fresh auto_select (no caching)
    group.bench_function("fresh_auto_select", |bench| {
        bench.iter(|| black_box(auto_select_target()))
    });

    // Compare name() access from cached vs fresh
    group.bench_function("cached_name", |bench| {
        bench.iter(|| black_box(cached_target().name()))
    });

    group.bench_function("fresh_name", |bench| {
        bench.iter(|| black_box(auto_select_target().name()))
    });

    // Multiple cached accesses in a loop (amortized)
    group.bench_function("cached_100_accesses", |bench| {
        bench.iter(|| {
            let mut sum = 0u32;
            for _ in 0..100 {
                sum += cached_target().capabilities().vector_bits;
            }
            black_box(sum)
        })
    });

    group.finish();
}

// =============================================================================
// Batch Operations (throughput focus)
// =============================================================================

fn bench_batch_operations(c: &mut Criterion) {
    let mut group = c.benchmark_group("batch_operations");
    let backend = BackendImpl::auto_select();

    // Process arrays of values
    for size in [64, 256, 1024, 4096] {
        group.throughput(Throughput::Elements(size as u64));

        let data: Vec<u32> = (0..size).map(|i| i as u32).collect();
        let addend: Vec<u32> = vec![1; size];

        // Batch add using microcode
        group.bench_with_input(
            BenchmarkId::new("add_microcode", size),
            &size,
            |bench, _| {
                bench.iter(|| {
                    data.iter()
                        .zip(addend.iter())
                        .map(|(&a, &b)| backend.add(black_box(a), black_box(b)))
                        .collect::<Vec<_>>()
                })
            },
        );

        // Batch add using native
        group.bench_with_input(BenchmarkId::new("add_native", size), &size, |bench, _| {
            bench.iter(|| {
                data.iter()
                    .zip(addend.iter())
                    .map(|(&a, &b)| black_box(a).wrapping_add(black_box(b)))
                    .collect::<Vec<_>>()
            })
        });

        // Batch inc using microcode
        group.bench_with_input(
            BenchmarkId::new("inc_microcode", size),
            &size,
            |bench, _| {
                bench.iter(|| {
                    data.iter()
                        .map(|&a| backend.inc(black_box(a)))
                        .collect::<Vec<_>>()
                })
            },
        );

        // Batch inc using native
        group.bench_with_input(BenchmarkId::new("inc_native", size), &size, |bench, _| {
            bench.iter(|| {
                data.iter()
                    .map(|&a| black_box(a).wrapping_add(1))
                    .collect::<Vec<_>>()
            })
        });
    }

    group.finish();
}

// =============================================================================
// Algebraic Identity Verification (with timing)
// =============================================================================

fn bench_algebraic_identities(c: &mut Criterion) {
    let mut group = c.benchmark_group("algebraic_identities");
    group.throughput(Throughput::Elements(ITERATIONS));

    let backend = BackendImpl::auto_select();

    // Verify: neg(bnot(x)) = x + 1 (via actual computation, not just verification)
    group.bench_function("inc_identity_microcode", |bench| {
        let mut x: u32 = 0;
        bench.iter(|| {
            for _ in 0..ITERATIONS {
                x = backend.neg(backend.bnot(black_box(x)));
            }
            x
        })
    });

    // Compare with native equivalent
    group.bench_function("inc_identity_native", |bench| {
        let mut x: u32 = 0;
        bench.iter(|| {
            for _ in 0..ITERATIONS {
                x = black_box(x).wrapping_add(1);
            }
            x
        })
    });

    // Verify: bnot(neg(x)) = x - 1
    group.bench_function("dec_identity_microcode", |bench| {
        let mut x: u32 = u32::MAX;
        bench.iter(|| {
            for _ in 0..ITERATIONS {
                x = backend.bnot(backend.neg(black_box(x)));
            }
            x
        })
    });

    group.bench_function("dec_identity_native", |bench| {
        let mut x: u32 = u32::MAX;
        bench.iter(|| {
            for _ in 0..ITERATIONS {
                x = black_box(x).wrapping_sub(1);
            }
            x
        })
    });

    group.finish();
}

// =============================================================================
// Generated Backend Comparison Benchmarks (TASK-126)
// =============================================================================

fn bench_generated_backends(c: &mut Criterion) {
    use hologram_backend::microcode::generated::GeneratedBackend;
    use hologram_backend::target::{ScalarTarget, Simd128Target, Simd256Target};

    let mut group = c.benchmark_group("generated_backends");
    group.throughput(Throughput::Elements(ITERATIONS));

    let backend_impl = BackendImpl::auto_select();
    let generated = GeneratedBackend::auto_select();
    let scalar_target = ScalarTarget::new();
    let simd128_target = Simd128Target::new();
    let simd256_target = Simd256Target::new();

    let a: u32 = 0xDEAD_BEEF;
    let b: u32 = 0xCAFE_BABE;

    // Compare BackendImpl vs GeneratedBackend
    group.bench_function("backendimpl_add", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = backend_impl.add(black_box(result), black_box(b));
            }
            result
        })
    });

    group.bench_function("generated_add", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            let impl_ = generated.to_backend_impl();
            for _ in 0..ITERATIONS {
                result = impl_.add(black_box(result), black_box(b));
            }
            result
        })
    });

    // Compare different target implementations
    group.bench_function("scalar_target_add", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..ITERATIONS {
                result = scalar_target.add(black_box(result), black_box(b));
            }
            result
        })
    });

    // SIMD targets with array ops
    let a_arr4: [u32; 4] = [a, b, a ^ b, a & b];
    let b_arr4: [u32; 4] = [b, a, a | b, a ^ b];

    group.bench_function("simd128_target_add", |bench| {
        bench.iter(|| {
            let mut result = black_box(a_arr4);
            for _ in 0..ITERATIONS {
                result = simd128_target.add(black_box(result), black_box(b_arr4));
            }
            result
        })
    });

    let a_arr8: [u32; 8] = [
        a,
        b,
        a ^ b,
        a & b,
        !a,
        !b,
        a.wrapping_add(b),
        a.wrapping_sub(b),
    ];
    let b_arr8: [u32; 8] = [
        b,
        a,
        a | b,
        a ^ b,
        !b,
        !a,
        b.wrapping_add(a),
        b.wrapping_sub(a),
    ];

    group.bench_function("simd256_target_add", |bench| {
        bench.iter(|| {
            let mut result = black_box(a_arr8);
            for _ in 0..ITERATIONS {
                result = simd256_target.add(black_box(result), black_box(b_arr8));
            }
            result
        })
    });

    // Measure dispatch overhead
    group.bench_function("generated_dispatch_overhead", |bench| {
        bench.iter(|| {
            let backend = GeneratedBackend::auto_select();
            let impl_ = backend.to_backend_impl();
            impl_.xor(black_box(a), black_box(b))
        })
    });

    group.bench_function("direct_impl_no_dispatch", |bench| {
        bench.iter(|| backend_impl.xor(black_box(a), black_box(b)))
    });

    group.finish();
}

fn bench_target_selection_overhead(c: &mut Criterion) {
    use hologram_backend::microcode::generated::GeneratedBackend;
    use hologram_backend::target::{auto_select_target, cached_target};

    let mut group = c.benchmark_group("target_selection_overhead");

    // Measure different selection mechanisms
    group.bench_function("backendimpl_auto_select", |bench| {
        bench.iter(BackendImpl::auto_select)
    });

    group.bench_function("generated_auto_select", |bench| {
        bench.iter(GeneratedBackend::auto_select)
    });

    group.bench_function("auto_select_target", |bench| bench.iter(auto_select_target));

    group.bench_function("cached_target", |bench| bench.iter(cached_target));

    // Measure complete operation including selection
    let a: u32 = 42;
    let b: u32 = 10;

    group.bench_function("select_and_add_backendimpl", |bench| {
        bench.iter(|| {
            let backend = BackendImpl::auto_select();
            backend.add(black_box(a), black_box(b))
        })
    });

    group.bench_function("select_and_add_generated", |bench| {
        bench.iter(|| {
            let backend = GeneratedBackend::auto_select();
            backend.to_backend_impl().add(black_box(a), black_box(b))
        })
    });

    group.bench_function("select_and_add_cached_target", |bench| {
        bench.iter(|| {
            use uor::microcode::MicrocodeOps;
            let target = cached_target();
            match target.as_scalar() {
                Some(s) => s.add(black_box(a), black_box(b)),
                None => 0, // Fallback (shouldn't happen in this test)
            }
        })
    });

    group.finish();
}

// =============================================================================
// Microcode vs Native Overhead Ratio Benchmarks (TASK-170)
// =============================================================================

/// Minimum expected speedup of native operations over microcode.
///
/// Native hardware add should be at least this many times faster than
/// Kogge-Stone microcode add. The actual ratio varies by CPU but is
/// typically 5-20x on modern hardware.
///
/// We use 3x as a conservative threshold that accounts for:
/// - Modern CPU out-of-order execution partially parallelizing Kogge-Stone
/// - Compiler optimizations on the microcode path
/// - Measurement variance
const NATIVE_SPEEDUP_THRESHOLD: f64 = 3.0;

/// Benchmark pure microcode paths vs native hardware instructions.
///
/// This function measures the actual overhead ratio and reports it for CI tracking.
/// The key insight is that microcode `add` uses Kogge-Stone parallel prefix adder
/// (~5-7 primitive ops per bit of width), while native `add` is a single instruction.
fn bench_microcode_vs_native_gates(c: &mut Criterion) {
    let mut group = c.benchmark_group("microcode_vs_native_gates");

    // Use a large iteration count for stable measurements
    const GATE_ITERATIONS: u64 = 10_000;
    group.throughput(Throughput::Elements(GATE_ITERATIONS));

    let scalar = ScalarPrimitives;
    let a: u32 = 0xDEAD_BEEF;
    let b: u32 = 0xCAFE_BABE;

    // -------------------------------------------------------------------------
    // ADD: Kogge-Stone vs Native
    // -------------------------------------------------------------------------

    // Pure microcode add (Kogge-Stone adder - ~160 primitive operations for 32-bit)
    group.bench_function("add/kogge_stone", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..GATE_ITERATIONS {
                result = KoggeStoneAdder::add(&scalar, black_box(result), black_box(b));
            }
            result
        })
    });

    // Native hardware add (single instruction)
    group.bench_function("add/native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..GATE_ITERATIONS {
                result = black_box(result).wrapping_add(black_box(b));
            }
            result
        })
    });

    // -------------------------------------------------------------------------
    // INC: neg(bnot(x)) vs Native
    // -------------------------------------------------------------------------

    // Pure microcode inc (2 primitive ops)
    group.bench_function("inc/microcode", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..GATE_ITERATIONS {
                // Explicit microcode: inc(x) = neg(bnot(x))
                result = scalar.neg(scalar.bnot(black_box(result)));
            }
            result
        })
    });

    // Native hardware inc
    group.bench_function("inc/native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..GATE_ITERATIONS {
                result = black_box(result).wrapping_add(1);
            }
            result
        })
    });

    // -------------------------------------------------------------------------
    // DEC: bnot(neg(x)) vs Native
    // -------------------------------------------------------------------------

    // Pure microcode dec (2 primitive ops)
    group.bench_function("dec/microcode", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..GATE_ITERATIONS {
                // Explicit microcode: dec(x) = bnot(neg(x))
                result = scalar.bnot(scalar.neg(black_box(result)));
            }
            result
        })
    });

    // Native hardware dec
    group.bench_function("dec/native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..GATE_ITERATIONS {
                result = black_box(result).wrapping_sub(1);
            }
            result
        })
    });

    // -------------------------------------------------------------------------
    // SUB: add(a, neg(b)) via Kogge-Stone vs Native
    // -------------------------------------------------------------------------

    // Pure microcode sub (neg + Kogge-Stone add)
    group.bench_function("sub/microcode", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..GATE_ITERATIONS {
                // Explicit microcode: sub(a, b) = add(a, neg(b))
                let neg_b = scalar.neg(black_box(b));
                result = KoggeStoneAdder::add(&scalar, black_box(result), neg_b);
            }
            result
        })
    });

    // Native hardware sub
    group.bench_function("sub/native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a);
            for _ in 0..GATE_ITERATIONS {
                result = black_box(result).wrapping_sub(black_box(b));
            }
            result
        })
    });

    group.finish();
}

/// Benchmark SIMD array operations: microcode vs native.
fn bench_simd_microcode_vs_native(c: &mut Criterion) {
    use hologram_backend::target::{Simd128Target, Simd256Target};

    let mut group = c.benchmark_group("simd_microcode_vs_native");

    const SIMD_ITERATIONS: u64 = 5_000;
    group.throughput(Throughput::Elements(SIMD_ITERATIONS));

    let simd128 = Simd128Target::new();
    let simd256 = Simd256Target::new();
    let scalar = ScalarPrimitives;

    let a4: [u32; 4] = [0xDEAD_BEEF, 0xCAFE_BABE, 0x1234_5678, 0x9ABC_DEF0];
    let b4: [u32; 4] = [0x1111_1111, 0x2222_2222, 0x3333_3333, 0x4444_4444];

    let a8: [u32; 8] = [
        0xDEAD_BEEF,
        0xCAFE_BABE,
        0x1234_5678,
        0x9ABC_DEF0,
        0xFEDC_BA98,
        0x7654_3210,
        0x0F0F_0F0F,
        0xF0F0_F0F0,
    ];
    let b8: [u32; 8] = [
        0x1111_1111,
        0x2222_2222,
        0x3333_3333,
        0x4444_4444,
        0x5555_5555,
        0x6666_6666,
        0x7777_7777,
        0x8888_8888,
    ];

    // -------------------------------------------------------------------------
    // 128-bit (4 x u32) ADD
    // -------------------------------------------------------------------------

    // Microcode path (uses portable array implementation with Kogge-Stone)
    group.bench_function("add_4xu32/microcode", |bench| {
        bench.iter(|| {
            let mut result = black_box(a4);
            for _ in 0..SIMD_ITERATIONS {
                result = KoggeStoneAdder::add(&scalar, black_box(result), black_box(b4));
            }
            result
        })
    });

    // Target-optimized path (portable SIMD)
    group.bench_function("add_4xu32/simd128_target", |bench| {
        bench.iter(|| {
            let mut result = black_box(a4);
            for _ in 0..SIMD_ITERATIONS {
                result = simd128.add(black_box(result), black_box(b4));
            }
            result
        })
    });

    // Native element-wise (baseline)
    group.bench_function("add_4xu32/native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a4);
            for _ in 0..SIMD_ITERATIONS {
                let r = black_box(result);
                let bb = black_box(b4);
                result = [
                    r[0].wrapping_add(bb[0]),
                    r[1].wrapping_add(bb[1]),
                    r[2].wrapping_add(bb[2]),
                    r[3].wrapping_add(bb[3]),
                ];
            }
            result
        })
    });

    // -------------------------------------------------------------------------
    // 256-bit (8 x u32) ADD
    // -------------------------------------------------------------------------

    // Microcode path
    group.bench_function("add_8xu32/microcode", |bench| {
        bench.iter(|| {
            let mut result = black_box(a8);
            for _ in 0..SIMD_ITERATIONS {
                result = KoggeStoneAdder::add(&scalar, black_box(result), black_box(b8));
            }
            result
        })
    });

    // Target-optimized path
    group.bench_function("add_8xu32/simd256_target", |bench| {
        bench.iter(|| {
            let mut result = black_box(a8);
            for _ in 0..SIMD_ITERATIONS {
                result = simd256.add(black_box(result), black_box(b8));
            }
            result
        })
    });

    // Native element-wise
    group.bench_function("add_8xu32/native", |bench| {
        bench.iter(|| {
            let mut result = black_box(a8);
            for _ in 0..SIMD_ITERATIONS {
                let r = black_box(result);
                let bb = black_box(b8);
                result = [
                    r[0].wrapping_add(bb[0]),
                    r[1].wrapping_add(bb[1]),
                    r[2].wrapping_add(bb[2]),
                    r[3].wrapping_add(bb[3]),
                    r[4].wrapping_add(bb[4]),
                    r[5].wrapping_add(bb[5]),
                    r[6].wrapping_add(bb[6]),
                    r[7].wrapping_add(bb[7]),
                ];
            }
            result
        })
    });

    group.finish();
}

/// Report overhead ratios for CI tracking.
///
/// This benchmark outputs overhead ratios that can be captured by CI
/// for regression detection. Format: "overhead_ratio/<op>: <microcode_ns>/<native_ns> = <ratio>x"
fn bench_overhead_ratios(c: &mut Criterion) {
    use std::time::Instant;

    let mut group = c.benchmark_group("overhead_ratios");

    // Disable default output - we'll print custom format
    group.sample_size(100);

    let scalar = ScalarPrimitives;
    let a: u32 = 0xDEAD_BEEF;
    let b: u32 = 0xCAFE_BABE;

    const WARMUP_ITERS: u32 = 1000;
    const MEASURE_ITERS: u32 = 100_000;

    // Warmup
    for _ in 0..WARMUP_ITERS {
        let _ = KoggeStoneAdder::add(&scalar, a, b);
        let _ = a.wrapping_add(b);
    }

    // Measure Kogge-Stone add
    let start = Instant::now();
    let mut result_ks = a;
    for _ in 0..MEASURE_ITERS {
        result_ks = KoggeStoneAdder::add(&scalar, result_ks, b);
    }
    let ks_time = start.elapsed();
    let _ = black_box(result_ks);

    // Measure native add
    let start = Instant::now();
    let mut result_native = a;
    for _ in 0..MEASURE_ITERS {
        result_native = result_native.wrapping_add(b);
    }
    let native_time = start.elapsed();
    let _ = black_box(result_native);

    let ratio = ks_time.as_nanos() as f64 / native_time.as_nanos().max(1) as f64;

    // Report for CI
    eprintln!(
        "OVERHEAD_RATIO add/kogge_stone_vs_native: {:.2}x (threshold: {:.1}x)",
        ratio, NATIVE_SPEEDUP_THRESHOLD
    );

    // Benchmark function (for criterion output)
    group.bench_function("add_ratio_measurement", |bench| {
        bench.iter(|| {
            let ks = KoggeStoneAdder::add(&scalar, black_box(a), black_box(b));
            let native = black_box(a).wrapping_add(black_box(b));
            (ks, native)
        })
    });

    group.finish();

    // Print summary
    eprintln!("\n=== Overhead Ratio Summary ===");
    eprintln!(
        "Kogge-Stone add: {:.2}ns/iter",
        ks_time.as_nanos() as f64 / MEASURE_ITERS as f64
    );
    eprintln!(
        "Native add:      {:.2}ns/iter",
        native_time.as_nanos() as f64 / MEASURE_ITERS as f64
    );
    eprintln!("Overhead ratio:  {:.2}x", ratio);
    if ratio >= NATIVE_SPEEDUP_THRESHOLD {
        eprintln!(
            "✓ Native override meets {:.0}x threshold",
            NATIVE_SPEEDUP_THRESHOLD
        );
    } else {
        eprintln!(
            "⚠ Native override below {:.0}x threshold (actual: {:.2}x)",
            NATIVE_SPEEDUP_THRESHOLD, ratio
        );
    }
    eprintln!("==============================\n");
}

criterion_group!(
    benches,
    bench_primitives_u32,
    bench_derived_ops_u32,
    bench_kogge_stone,
    bench_backend_selection,
    bench_cached_target,
    bench_batch_operations,
    bench_algebraic_identities,
    bench_generated_backends,
    bench_target_selection_overhead,
    bench_microcode_vs_native_gates,
    bench_simd_microcode_vs_native,
    bench_overhead_ratios,
);
criterion_main!(benches);
