//! Disk-persistent cache for compiled BackendPlans.
//!
//! The cache supports LRU eviction to prevent unbounded memory growth.
//! When a maximum size is configured, the cache automatically evicts
//! least-recently-used entries when the limit is exceeded.

use std::fs::{self, File};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::SystemTime;

use hologram_holo::BackendPlan;
use rkyv::ser::serializers::AllocSerializer;
use rkyv::ser::Serializer;
use rkyv::Deserialize;

use crate::error::{RegistryError, Result};

/// Cache configuration options.
#[derive(Debug, Clone)]
pub struct CacheConfig {
    /// Maximum cache size in bytes. None means unlimited.
    pub max_size: Option<u64>,
    /// Whether to update access times on get (enables true LRU).
    /// Disable for read-heavy workloads where LRU precision is less important.
    pub track_access: bool,
}

impl Default for CacheConfig {
    fn default() -> Self {
        Self {
            max_size: None,
            track_access: true,
        }
    }
}

impl CacheConfig {
    /// Create a config with a maximum cache size.
    #[must_use]
    pub fn with_max_size(max_bytes: u64) -> Self {
        Self {
            max_size: Some(max_bytes),
            track_access: true,
        }
    }

    /// Create an unlimited cache config.
    #[must_use]
    pub fn unlimited() -> Self {
        Self {
            max_size: None,
            track_access: true,
        }
    }
}

/// Cache statistics for monitoring and debugging.
#[derive(Debug, Default)]
pub struct CacheStats {
    hits: AtomicU64,
    misses: AtomicU64,
    evictions: AtomicU64,
}

impl CacheStats {
    /// Number of cache hits.
    #[must_use]
    pub fn hits(&self) -> u64 {
        self.hits.load(Ordering::Relaxed)
    }

    /// Number of cache misses.
    #[must_use]
    pub fn misses(&self) -> u64 {
        self.misses.load(Ordering::Relaxed)
    }

    /// Number of evictions performed.
    #[must_use]
    pub fn evictions(&self) -> u64 {
        self.evictions.load(Ordering::Relaxed)
    }

    /// Cache hit rate (0.0 to 1.0).
    ///
    /// Returns `None` if no requests have been made.
    #[must_use]
    pub fn hit_rate(&self) -> Option<f64> {
        let hits = self.hits.load(Ordering::Relaxed);
        let misses = self.misses.load(Ordering::Relaxed);
        let total = hits + misses;

        if total == 0 {
            None
        } else {
            Some(hits as f64 / total as f64)
        }
    }

    /// Cache miss rate (0.0 to 1.0).
    ///
    /// Returns `None` if no requests have been made.
    #[must_use]
    pub fn miss_rate(&self) -> Option<f64> {
        self.hit_rate().map(|hr| 1.0 - hr)
    }

    /// Total number of requests (hits + misses).
    #[must_use]
    pub fn total_requests(&self) -> u64 {
        self.hits.load(Ordering::Relaxed) + self.misses.load(Ordering::Relaxed)
    }

    /// Reset all statistics to zero.
    pub fn reset(&self) {
        self.hits.store(0, Ordering::Relaxed);
        self.misses.store(0, Ordering::Relaxed);
        self.evictions.store(0, Ordering::Relaxed);
    }

    fn record_hit(&self) {
        self.hits.fetch_add(1, Ordering::Relaxed);
    }

    fn record_miss(&self) {
        self.misses.fetch_add(1, Ordering::Relaxed);
    }

    fn record_evictions(&self, count: u64) {
        self.evictions.fetch_add(count, Ordering::Relaxed);
    }
}

/// Disk-persistent cache for compiled `BackendPlan`s with LRU eviction.
///
/// Plans are stored by their layer content hash in a sharded directory structure:
/// ```text
/// ~/.hologram/cache/plans/
/// └── ab/
///     └── ab1234...5678.holb
/// ```
///
/// # LRU Eviction
///
/// When configured with a maximum size, the cache automatically evicts
/// least-recently-used entries when space is needed. Access times are
/// tracked by touching files on read.
///
/// # Example
///
/// ```no_run
/// use hologram_registry::{PlanCache, CacheConfig};
/// use hologram_holo::{BackendPlan, PlanMetadata};
///
/// // Create cache with 100MB limit
/// let cache = PlanCache::with_config(
///     PlanCache::default_root().unwrap(),
///     CacheConfig::with_max_size(100 * 1024 * 1024),
/// ).unwrap();
///
/// let hash = [0xab; 32];
///
/// // Check cache
/// if let Some(plan) = cache.get(&hash) {
///     // Cache hit - stats updated automatically
/// } else {
///     // Cache miss - compile and store
///     let plan = BackendPlan {
///         instructions: vec![],
///         buffers: vec![],
///         constants: vec![],
///         workspace_size: 0,
///         dependencies: vec![],
///         metadata: PlanMetadata::default(),
///         node_buffer_map: vec![],
///     };
///     // Automatic LRU eviction if limit exceeded
///     cache.put(&hash, &plan).unwrap();
/// }
///
/// // Check statistics
/// println!("Hit rate: {:?}", cache.stats().hit_rate());
/// ```
#[derive(Debug)]
pub struct PlanCache {
    /// Root directory for the cache.
    root: PathBuf,
    /// Cache configuration.
    config: CacheConfig,
    /// Runtime statistics.
    stats: CacheStats,
}

impl PlanCache {
    /// Default cache location: `~/.hologram/cache/plans/`.
    const DEFAULT_SUBDIR: &'static str = ".hologram/cache/plans";

    /// Get the default root path for the cache.
    ///
    /// # Errors
    ///
    /// Returns an error if the home directory cannot be determined.
    pub fn default_root() -> Result<PathBuf> {
        let home = home_dir()?;
        Ok(home.join(Self::DEFAULT_SUBDIR))
    }

    /// Create a cache at the default location with default config.
    ///
    /// # Errors
    ///
    /// Returns an error if the home directory cannot be determined or
    /// if the cache directories cannot be created.
    pub fn default_location() -> Result<Self> {
        Self::with_config(Self::default_root()?, CacheConfig::default())
    }

    /// Create a cache at a custom location with default config.
    ///
    /// Creates the directory if it doesn't exist.
    ///
    /// # Errors
    ///
    /// Returns an error if the directory cannot be created.
    pub fn new(root: impl Into<PathBuf>) -> Result<Self> {
        Self::with_config(root, CacheConfig::default())
    }

    /// Create a cache with custom configuration.
    ///
    /// # Errors
    ///
    /// Returns an error if the directory cannot be created.
    pub fn with_config(root: impl Into<PathBuf>, config: CacheConfig) -> Result<Self> {
        let root = root.into();
        fs::create_dir_all(&root).map_err(|e| RegistryError::io(&root, e))?;
        Ok(Self {
            root,
            config,
            stats: CacheStats::default(),
        })
    }

    /// Get the cache configuration.
    #[must_use]
    pub fn config(&self) -> &CacheConfig {
        &self.config
    }

    /// Get cache statistics.
    #[must_use]
    pub fn stats(&self) -> &CacheStats {
        &self.stats
    }

    /// Get the root directory of the cache.
    #[must_use]
    pub fn root(&self) -> &Path {
        &self.root
    }

    /// Get a cached plan by layer content hash.
    ///
    /// Returns `None` if the plan is not cached.
    /// Updates access time for LRU tracking (if `track_access` is enabled).
    #[must_use]
    pub fn get(&self, layer_hash: &[u8; 32]) -> Option<BackendPlan> {
        let path = self.plan_path(layer_hash);

        if !path.exists() {
            self.stats.record_miss();
            return None;
        }

        let data = match fs::read(&path) {
            Ok(d) => d,
            Err(_) => {
                self.stats.record_miss();
                return None;
            }
        };

        let plan = deserialize_plan(&data);

        if plan.is_some() {
            self.stats.record_hit();
            // Touch file to update access time for LRU
            if self.config.track_access {
                let _ = touch_file(&path);
            }
        } else {
            self.stats.record_miss();
        }

        plan
    }

    /// Store a compiled plan by layer content hash.
    ///
    /// If a maximum cache size is configured and the cache would exceed
    /// that limit, LRU eviction is performed automatically.
    ///
    /// # Errors
    ///
    /// Returns an error if the plan cannot be serialized or written.
    pub fn put(&self, layer_hash: &[u8; 32], plan: &BackendPlan) -> Result<()> {
        let path = self.plan_path(layer_hash);

        // Create shard directory
        let shard_dir = path.parent().expect("plan path has parent");
        fs::create_dir_all(shard_dir).map_err(|e| RegistryError::io(shard_dir, e))?;

        // Serialize plan
        let data = serialize_plan(plan)?;

        // Write to temp file, then rename (atomic)
        let temp_path = path.with_extension("tmp");
        let mut file = File::create(&temp_path).map_err(|e| RegistryError::io(&temp_path, e))?;
        file.write_all(&data)
            .map_err(|e| RegistryError::io(&temp_path, e))?;
        file.sync_all()
            .map_err(|e| RegistryError::io(&temp_path, e))?;

        fs::rename(&temp_path, &path).map_err(|e| RegistryError::io(&path, e))?;

        // Evict if over limit
        if let Some(max_size) = self.config.max_size {
            let evicted = self.evict_lru_to_size(max_size)?;
            if evicted > 0 {
                self.stats.record_evictions(evicted as u64);
            }
        }

        Ok(())
    }

    /// Check if a plan is cached.
    #[must_use]
    pub fn contains(&self, layer_hash: &[u8; 32]) -> bool {
        self.plan_path(layer_hash).exists()
    }

    /// Remove a cached plan.
    ///
    /// Returns `true` if the plan was removed, `false` if it didn't exist.
    ///
    /// # Errors
    ///
    /// Returns an error if the file cannot be deleted.
    pub fn remove(&self, layer_hash: &[u8; 32]) -> Result<bool> {
        let path = self.plan_path(layer_hash);

        if !path.exists() {
            return Ok(false);
        }

        fs::remove_file(&path).map_err(|e| RegistryError::io(&path, e))?;
        Ok(true)
    }

    /// Clear all cached plans.
    ///
    /// # Errors
    ///
    /// Returns an error if the cache directory cannot be cleared.
    pub fn clear(&self) -> Result<()> {
        if self.root.exists() {
            fs::remove_dir_all(&self.root).map_err(|e| RegistryError::io(&self.root, e))?;
            fs::create_dir_all(&self.root).map_err(|e| RegistryError::io(&self.root, e))?;
        }
        Ok(())
    }

    /// Get the total size of cached plans in bytes.
    ///
    /// # Errors
    ///
    /// Returns an error if the cache directory cannot be read.
    pub fn size(&self) -> Result<u64> {
        let mut total = 0u64;

        for entry in walkdir(&self.root)? {
            if entry.is_file() {
                if let Ok(meta) = fs::metadata(&entry) {
                    total += meta.len();
                }
            }
        }

        Ok(total)
    }

    /// List all cached plan hashes.
    ///
    /// # Errors
    ///
    /// Returns an error if the cache directory cannot be read.
    pub fn list(&self) -> Result<Vec<[u8; 32]>> {
        let mut hashes = Vec::new();

        for entry in walkdir(&self.root)? {
            if entry.is_file() && entry.extension().is_some_and(|e| e == "holb") {
                if let Some(hash) = parse_hash_from_filename(&entry) {
                    hashes.push(hash);
                }
            }
        }

        hashes.sort();
        Ok(hashes)
    }

    /// Evict entries to bring cache size under a limit.
    ///
    /// Removes oldest entries (by modification time) first.
    /// Use `evict_lru_to_size` for true LRU eviction based on access time.
    ///
    /// # Errors
    ///
    /// Returns an error if entries cannot be removed.
    pub fn evict_to_size(&self, max_bytes: u64) -> Result<usize> {
        self.evict_by_time(max_bytes, |meta| {
            meta.modified().unwrap_or(SystemTime::UNIX_EPOCH)
        })
    }

    /// Evict least-recently-used entries to bring cache size under a limit.
    ///
    /// Removes entries by access time (oldest accessed first).
    /// Requires `track_access` to be enabled for accurate LRU behavior.
    ///
    /// # Errors
    ///
    /// Returns an error if entries cannot be removed.
    pub fn evict_lru_to_size(&self, max_bytes: u64) -> Result<usize> {
        self.evict_by_time(max_bytes, |meta| {
            meta.accessed().unwrap_or(SystemTime::UNIX_EPOCH)
        })
    }

    /// Internal: evict entries sorted by a time function.
    fn evict_by_time<F>(&self, max_bytes: u64, time_fn: F) -> Result<usize>
    where
        F: Fn(&fs::Metadata) -> SystemTime,
    {
        let current_size = self.size()?;
        if current_size <= max_bytes {
            return Ok(0);
        }

        // Collect entries with times
        let mut entries: Vec<(PathBuf, u64, SystemTime)> = Vec::new();

        for entry in walkdir(&self.root)? {
            if entry.is_file() {
                if let Ok(meta) = fs::metadata(&entry) {
                    let time = time_fn(&meta);
                    entries.push((entry, meta.len(), time));
                }
            }
        }

        // Sort by time (oldest first for eviction)
        entries.sort_by_key(|(_, _, time)| *time);

        let mut to_free = current_size - max_bytes;
        let mut removed = 0;

        for (path, size, _) in entries {
            if to_free == 0 {
                break;
            }

            if fs::remove_file(&path).is_ok() {
                to_free = to_free.saturating_sub(size);
                removed += 1;
            }
        }

        Ok(removed)
    }

    /// Evict the N least-recently-used entries.
    ///
    /// # Errors
    ///
    /// Returns an error if entries cannot be removed.
    pub fn evict_lru_count(&self, count: usize) -> Result<usize> {
        if count == 0 {
            return Ok(0);
        }

        // Collect entries with access times
        let mut entries: Vec<(PathBuf, SystemTime)> = Vec::new();

        for entry in walkdir(&self.root)? {
            if entry.is_file() {
                if let Ok(meta) = fs::metadata(&entry) {
                    let atime = meta.accessed().unwrap_or(SystemTime::UNIX_EPOCH);
                    entries.push((entry, atime));
                }
            }
        }

        // Sort by access time (oldest first)
        entries.sort_by_key(|(_, atime)| *atime);

        let mut removed = 0;

        for (path, _) in entries.into_iter().take(count) {
            if fs::remove_file(&path).is_ok() {
                removed += 1;
            }
        }

        Ok(removed)
    }

    /// Get the file path for a cached plan.
    fn plan_path(&self, hash: &[u8; 32]) -> PathBuf {
        let hex = hex::encode(hash);
        let shard = &hex[0..2];
        self.root.join(shard).join(format!("{hex}.holb"))
    }
}

/// Serialize a BackendPlan using rkyv.
fn serialize_plan(plan: &BackendPlan) -> Result<Vec<u8>> {
    let mut serializer = AllocSerializer::<1024>::default();
    serializer
        .serialize_value(plan)
        .map_err(|e| RegistryError::IndexCorrupted(format!("serialization failed: {e}")))?;
    Ok(serializer.into_serializer().into_inner().to_vec())
}

/// Deserialize a BackendPlan from rkyv bytes.
fn deserialize_plan(data: &[u8]) -> Option<BackendPlan> {
    let archived = rkyv::check_archived_root::<BackendPlan>(data).ok()?;
    let plan: BackendPlan = archived.deserialize(&mut rkyv::Infallible).ok()?;
    Some(plan)
}

/// Get the user's home directory.
fn home_dir() -> Result<PathBuf> {
    std::env::var("HOME")
        .map(PathBuf::from)
        .map_err(|_| RegistryError::InvalidRef("HOME environment variable not set".to_string()))
}

/// Touch a file to update its access time.
fn touch_file(path: &Path) -> std::io::Result<()> {
    // Open file for reading to update access time
    let file = File::open(path)?;
    // On Unix, we can use filetime crate or just rely on the open() updating atime
    // For portability, we use a minimal approach: read one byte
    let _ = std::io::Read::read(&mut &file, &mut [0u8; 1]);
    drop(file);
    Ok(())
}

/// Walk a directory tree, returning all file paths.
fn walkdir(root: &Path) -> Result<Vec<PathBuf>> {
    let mut paths = Vec::new();

    if !root.exists() {
        return Ok(paths);
    }

    fn walk_recursive(dir: &Path, paths: &mut Vec<PathBuf>) -> Result<()> {
        let entries = fs::read_dir(dir).map_err(|e| RegistryError::io(dir, e))?;

        for entry in entries {
            let entry = entry.map_err(|e| RegistryError::io(dir, e))?;
            let path = entry.path();

            if path.is_dir() {
                walk_recursive(&path, paths)?;
            } else {
                paths.push(path);
            }
        }
        Ok(())
    }

    walk_recursive(root, &mut paths)?;
    Ok(paths)
}

/// Parse a hash from a filename (expects format: {hash}.holb).
fn parse_hash_from_filename(path: &Path) -> Option<[u8; 32]> {
    let stem = path.file_stem()?.to_str()?;

    if stem.len() != 64 {
        return None;
    }

    let bytes = hex::decode(stem).ok()?;
    bytes.try_into().ok()
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_holo::PlanMetadata;
    use tempfile::TempDir;

    fn temp_cache() -> (TempDir, PlanCache) {
        let temp = TempDir::new().unwrap();
        let cache = PlanCache::new(temp.path()).unwrap();
        (temp, cache)
    }

    fn make_test_plan() -> BackendPlan {
        BackendPlan {
            instructions: vec![],
            buffers: vec![],
            constants: vec![1, 2, 3, 4],
            workspace_size: 1024,
            dependencies: vec![],
            metadata: PlanMetadata {
                name: "test".to_string(),
                version: "1.0".to_string(),
                author: Some("tester".to_string()),
                description: Some("test plan".to_string()),
            },
            node_buffer_map: vec![Some(0), None, Some(1)],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        }
    }

    #[test]
    fn test_new_creates_directory() {
        let temp = TempDir::new().unwrap();
        let root = temp.path().join("cache");
        let cache = PlanCache::new(&root).unwrap();

        assert!(cache.root().exists());
    }

    #[test]
    fn test_put_and_get() {
        let (_temp, cache) = temp_cache();
        let hash = [0xab; 32];
        let plan = make_test_plan();

        cache.put(&hash, &plan).unwrap();

        let retrieved = cache.get(&hash);
        assert!(retrieved.is_some());
        let retrieved = retrieved.unwrap();
        assert_eq!(retrieved.workspace_size, plan.workspace_size);
        assert_eq!(retrieved.constants, plan.constants);
        assert_eq!(retrieved.metadata.name, plan.metadata.name);
    }

    #[test]
    fn test_get_not_found() {
        let (_temp, cache) = temp_cache();
        let hash = [0x00; 32];

        let result = cache.get(&hash);
        assert!(result.is_none());
    }

    #[test]
    fn test_contains() {
        let (_temp, cache) = temp_cache();
        let hash = [0xcd; 32];
        let plan = make_test_plan();

        assert!(!cache.contains(&hash));

        cache.put(&hash, &plan).unwrap();

        assert!(cache.contains(&hash));
    }

    #[test]
    fn test_remove() {
        let (_temp, cache) = temp_cache();
        let hash = [0xef; 32];
        let plan = make_test_plan();

        cache.put(&hash, &plan).unwrap();
        assert!(cache.contains(&hash));

        let removed = cache.remove(&hash).unwrap();
        assert!(removed);
        assert!(!cache.contains(&hash));

        // Remove again should return false
        let removed_again = cache.remove(&hash).unwrap();
        assert!(!removed_again);
    }

    #[test]
    fn test_clear() {
        let (_temp, cache) = temp_cache();

        cache.put(&[1; 32], &make_test_plan()).unwrap();
        cache.put(&[2; 32], &make_test_plan()).unwrap();

        let list = cache.list().unwrap();
        assert_eq!(list.len(), 2);

        cache.clear().unwrap();

        let list = cache.list().unwrap();
        assert!(list.is_empty());
    }

    #[test]
    fn test_list() {
        let (_temp, cache) = temp_cache();
        let hash1 = [0x11; 32];
        let hash2 = [0x22; 32];

        cache.put(&hash1, &make_test_plan()).unwrap();
        cache.put(&hash2, &make_test_plan()).unwrap();

        let mut list = cache.list().unwrap();
        list.sort();

        let mut expected = vec![hash1, hash2];
        expected.sort();

        assert_eq!(list, expected);
    }

    #[test]
    fn test_size() {
        let (_temp, cache) = temp_cache();

        let initial_size = cache.size().unwrap();
        assert_eq!(initial_size, 0);

        cache.put(&[1; 32], &make_test_plan()).unwrap();

        let size = cache.size().unwrap();
        assert!(size > 0);
    }

    #[test]
    fn test_evict_to_size() {
        let (_temp, cache) = temp_cache();

        // Add several plans
        for i in 0u8..5 {
            let mut plan = make_test_plan();
            plan.constants = vec![i; 1000]; // Make each plan ~1KB
            cache.put(&[i; 32], &plan).unwrap();
        }

        let initial = cache.list().unwrap().len();
        assert_eq!(initial, 5);

        // Evict to very small size
        let removed = cache.evict_to_size(100).unwrap();
        assert!(removed > 0);

        let final_list = cache.list().unwrap();
        assert!(final_list.len() < initial);
    }

    #[test]
    fn test_evict_when_under_limit() {
        let (_temp, cache) = temp_cache();

        cache.put(&[1; 32], &make_test_plan()).unwrap();

        let removed = cache.evict_to_size(u64::MAX).unwrap();
        assert_eq!(removed, 0);
    }

    #[test]
    fn test_plan_path_sharding() {
        let (_temp, cache) = temp_cache();
        let hash = [0xab; 32];

        let path = cache.plan_path(&hash);
        let path_str = path.to_string_lossy();
        let expected_shard = format!("ab{}", std::path::MAIN_SEPARATOR);
        assert!(path_str.contains(&expected_shard));
        assert!(path_str.ends_with(".holb"));
    }

    #[test]
    fn test_serialize_deserialize() {
        let plan = make_test_plan();
        let data = serialize_plan(&plan).unwrap();
        let restored = deserialize_plan(&data).unwrap();

        assert_eq!(restored.workspace_size, plan.workspace_size);
        assert_eq!(restored.constants, plan.constants);
        assert_eq!(restored.metadata.name, plan.metadata.name);
        assert_eq!(restored.node_buffer_map, plan.node_buffer_map);
    }

    #[test]
    fn test_root_accessor() {
        let temp = TempDir::new().unwrap();
        let cache = PlanCache::new(temp.path()).unwrap();

        assert_eq!(cache.root(), temp.path());
    }

    #[test]
    fn test_parse_hash_from_filename() {
        let hash = [0xab; 32];
        let hex = hex::encode(hash);
        let path = PathBuf::from(format!("/some/path/{hex}.holb"));

        let parsed = parse_hash_from_filename(&path);
        assert_eq!(parsed, Some(hash));
    }

    #[test]
    fn test_parse_hash_invalid() {
        let path = PathBuf::from("/some/path/invalid.holb");
        let parsed = parse_hash_from_filename(&path);
        assert!(parsed.is_none());
    }

    // ========================================================================
    // LRU Eviction and Cache Statistics Tests
    // ========================================================================

    fn temp_cache_with_config(config: CacheConfig) -> (TempDir, PlanCache) {
        let temp = TempDir::new().unwrap();
        let cache = PlanCache::with_config(temp.path(), config).unwrap();
        (temp, cache)
    }

    #[test]
    fn test_cache_stats_initial() {
        let (_temp, cache) = temp_cache();

        assert_eq!(cache.stats().hits(), 0);
        assert_eq!(cache.stats().misses(), 0);
        assert_eq!(cache.stats().evictions(), 0);
        assert_eq!(cache.stats().total_requests(), 0);
        assert!(cache.stats().hit_rate().is_none());
    }

    #[test]
    fn test_cache_stats_hit_miss() {
        let (_temp, cache) = temp_cache();
        let hash = [0xaa; 32];

        // Miss
        let _ = cache.get(&hash);
        assert_eq!(cache.stats().misses(), 1);
        assert_eq!(cache.stats().hits(), 0);

        // Put and hit
        cache.put(&hash, &make_test_plan()).unwrap();
        let _ = cache.get(&hash);
        assert_eq!(cache.stats().hits(), 1);
        assert_eq!(cache.stats().misses(), 1);

        // Hit rate should be 0.5
        let hit_rate = cache.stats().hit_rate().unwrap();
        assert!((hit_rate - 0.5).abs() < 0.01);
    }

    #[test]
    fn test_cache_stats_reset() {
        let (_temp, cache) = temp_cache();
        let hash = [0xbb; 32];

        cache.put(&hash, &make_test_plan()).unwrap();
        let _ = cache.get(&hash);
        let _ = cache.get(&[0x00; 32]); // miss

        assert!(cache.stats().total_requests() > 0);

        cache.stats().reset();

        assert_eq!(cache.stats().hits(), 0);
        assert_eq!(cache.stats().misses(), 0);
        assert_eq!(cache.stats().total_requests(), 0);
    }

    #[test]
    fn test_cache_config_max_size() {
        let config = CacheConfig::with_max_size(1024);

        assert_eq!(config.max_size, Some(1024));
        assert!(config.track_access);
    }

    #[test]
    fn test_cache_config_unlimited() {
        let config = CacheConfig::unlimited();

        assert!(config.max_size.is_none());
    }

    #[test]
    fn test_auto_eviction_on_put() {
        // Create cache with tiny limit
        let config = CacheConfig::with_max_size(100);
        let (_temp, cache) = temp_cache_with_config(config);

        // Add plans that exceed the limit
        for i in 0u8..5 {
            let mut plan = make_test_plan();
            plan.constants = vec![i; 500]; // Each plan is ~500 bytes
            cache.put(&[i; 32], &plan).unwrap();
        }

        // Cache should have evicted some entries
        let remaining = cache.list().unwrap().len();
        assert!(
            remaining < 5,
            "Expected eviction, got {} entries",
            remaining
        );

        // Evictions should be recorded
        assert!(cache.stats().evictions() > 0);
    }

    #[test]
    fn test_evict_lru_count() {
        let (_temp, cache) = temp_cache();

        // Add 5 plans
        for i in 0u8..5 {
            cache.put(&[i; 32], &make_test_plan()).unwrap();
            std::thread::sleep(std::time::Duration::from_millis(10));
        }

        let initial = cache.list().unwrap().len();
        assert_eq!(initial, 5);

        // Evict 2 entries
        let evicted = cache.evict_lru_count(2).unwrap();
        assert_eq!(evicted, 2);

        let remaining = cache.list().unwrap().len();
        assert_eq!(remaining, 3);
    }

    #[test]
    fn test_evict_lru_count_zero() {
        let (_temp, cache) = temp_cache();
        cache.put(&[1; 32], &make_test_plan()).unwrap();

        let evicted = cache.evict_lru_count(0).unwrap();
        assert_eq!(evicted, 0);
        assert_eq!(cache.list().unwrap().len(), 1);
    }

    #[test]
    fn test_evict_lru_to_size() {
        let (_temp, cache) = temp_cache();

        // Add several plans with delay to differentiate access times
        for i in 0u8..5 {
            let mut plan = make_test_plan();
            plan.constants = vec![i; 1000];
            cache.put(&[i; 32], &plan).unwrap();
            std::thread::sleep(std::time::Duration::from_millis(10));
        }

        let initial = cache.list().unwrap().len();
        assert_eq!(initial, 5);

        // Evict LRU entries to small size
        let evicted = cache.evict_lru_to_size(100).unwrap();
        assert!(evicted > 0);

        let final_count = cache.list().unwrap().len();
        assert!(final_count < initial);
    }

    #[test]
    fn test_config_accessor() {
        let config = CacheConfig::with_max_size(5000);
        let (_temp, cache) = temp_cache_with_config(config);

        assert_eq!(cache.config().max_size, Some(5000));
    }

    #[test]
    fn test_miss_rate() {
        let (_temp, cache) = temp_cache();

        // All misses
        for i in 0u8..4 {
            let _ = cache.get(&[i; 32]);
        }

        let miss_rate = cache.stats().miss_rate().unwrap();
        assert!((miss_rate - 1.0).abs() < 0.01);
    }
}
