//! Tokenizer compilation to .holo format.
//!
//! Compiles tokenizer.json files to hologram-executable format.

use std::fs;
use std::path::Path;

use crate::{
    serialization, Normalizer, NormalizerConfig, NormalizerStep, PrefixTrie, Result,
    ViterbiTokenizer, Vocabulary,
};

/// Compiled tokenizer ready for execution.
#[derive(Debug, Clone)]
pub struct CompiledTokenizer {
    /// Normalizer for text preprocessing.
    normalizer: Normalizer,
    /// Viterbi tokenizer with vocabulary trie.
    tokenizer: ViterbiTokenizer,
    /// Vocabulary for ID ↔ token lookups.
    vocab: Vocabulary,
    /// Maximum sequence length.
    pub max_length: usize,
}

impl CompiledTokenizer {
    /// Load a tokenizer from tokenizer.json.
    pub fn from_json(json: &str) -> Result<Self> {
        // Parse vocabulary
        let vocab = Vocabulary::from_json(json)?;

        // Build prefix trie from vocabulary
        let mut trie = PrefixTrie::new();
        for (token, id, score) in vocab.iter() {
            trie.insert_str(token, id, score);
        }

        // Default SentencePiece normalizer
        let normalizer = Normalizer::sentencepiece_default();

        // Create Viterbi tokenizer
        let tokenizer = ViterbiTokenizer::new(
            trie,
            vocab.special_tokens.unk,
            -10.0, // UNK score
        );

        Ok(Self {
            normalizer,
            tokenizer,
            vocab,
            max_length: 512,
        })
    }

    /// Load a tokenizer from a file.
    pub fn from_file<P: AsRef<Path>>(path: P) -> Result<Self> {
        let json = fs::read_to_string(path)?;
        Self::from_json(&json)
    }

    /// Tokenize text to token IDs.
    ///
    /// # Arguments
    /// * `text` - Input text to tokenize
    /// * `max_length` - Maximum output length (will truncate/pad)
    /// * `add_eos` - Whether to append EOS token
    ///
    /// # Returns
    /// (token_ids, attention_mask) tuple
    pub fn encode(
        &self,
        text: &str,
        max_length: Option<usize>,
        add_eos: bool,
    ) -> Result<(Vec<u32>, Vec<u32>)> {
        let max_len = max_length.unwrap_or(self.max_length);

        // Normalize text
        let codepoints = self.normalizer.normalize(text)?;

        // Tokenize using Viterbi
        let result = self.tokenizer.tokenize(&codepoints);
        let mut tokens = result.tokens;

        // Add EOS if requested
        if add_eos {
            tokens.push(self.vocab.special_tokens.eos);
        }

        // Truncate if needed
        if tokens.len() > max_len {
            tokens.truncate(max_len);
        }

        // Create attention mask (1 for real tokens, 0 for padding)
        let actual_len = tokens.len();
        let mut attention_mask = vec![1u32; actual_len];

        // Pad if needed
        while tokens.len() < max_len {
            tokens.push(self.vocab.special_tokens.pad);
            attention_mask.push(0);
        }

        Ok((tokens, attention_mask))
    }

    /// Decode token IDs back to text.
    pub fn decode(&self, token_ids: &[u32]) -> String {
        let mut result = String::new();

        for &id in token_ids {
            // Skip special tokens
            if id == self.vocab.special_tokens.pad {
                continue;
            }
            if id == self.vocab.special_tokens.eos {
                break;
            }

            if let Some(token) = self.vocab.get_token(id) {
                result.push_str(token);
            }
        }

        // Convert SentencePiece underscores back to spaces
        result.replace('\u{2581}', " ").trim().to_string()
    }

    /// Get vocabulary size.
    pub fn vocab_size(&self) -> usize {
        self.vocab.size
    }

    /// Get the underlying vocabulary.
    pub fn vocabulary(&self) -> &Vocabulary {
        &self.vocab
    }

    /// Create a builder for constructing a tokenizer with custom options.
    pub fn builder() -> TokenizerBuilder {
        TokenizerBuilder::new()
    }
}

/// Builder for constructing a [`CompiledTokenizer`] with custom configuration.
///
/// # Example
///
/// ```ignore
/// use hologram_tokenizer::CompiledTokenizer;
///
/// let tokenizer = CompiledTokenizer::builder()
///     .max_length(256)
///     .unk_score(-15.0)
///     .with_lowercase()
///     .build_from_json(json)?;
/// ```
#[derive(Debug, Clone)]
pub struct TokenizerBuilder {
    max_length: usize,
    unk_score: f32,
    normalizer_steps: Vec<NormalizerStep>,
}

impl Default for TokenizerBuilder {
    fn default() -> Self {
        Self::new()
    }
}

impl TokenizerBuilder {
    /// Create a new tokenizer builder with default settings.
    pub fn new() -> Self {
        Self {
            max_length: 512,
            unk_score: -10.0,
            normalizer_steps: vec![
                NormalizerStep::Nfkc,
                NormalizerStep::ReplaceWhitespace,
                NormalizerStep::CollapseWhitespace,
                NormalizerStep::SpaceToUnderscore,
                NormalizerStep::PrependUnderscore,
            ],
        }
    }

    /// Set the maximum sequence length.
    pub fn max_length(mut self, max_length: usize) -> Self {
        self.max_length = max_length;
        self
    }

    /// Set the UNK token score.
    pub fn unk_score(mut self, score: f32) -> Self {
        self.unk_score = score;
        self
    }

    /// Clear all normalizer steps.
    pub fn clear_normalizer(mut self) -> Self {
        self.normalizer_steps.clear();
        self
    }

    /// Add lowercase normalization step.
    pub fn with_lowercase(mut self) -> Self {
        if !self.normalizer_steps.contains(&NormalizerStep::Lowercase) {
            self.normalizer_steps.insert(0, NormalizerStep::Lowercase);
        }
        self
    }

    /// Add NFKC normalization step.
    pub fn with_nfkc(mut self) -> Self {
        if !self.normalizer_steps.contains(&NormalizerStep::Nfkc) {
            self.normalizer_steps.push(NormalizerStep::Nfkc);
        }
        self
    }

    /// Add NFC normalization step.
    pub fn with_nfc(mut self) -> Self {
        if !self.normalizer_steps.contains(&NormalizerStep::Nfc) {
            self.normalizer_steps.push(NormalizerStep::Nfc);
        }
        self
    }

    /// Add accent stripping step.
    pub fn with_strip_accents(mut self) -> Self {
        if !self
            .normalizer_steps
            .contains(&NormalizerStep::StripAccents)
        {
            self.normalizer_steps.push(NormalizerStep::StripAccents);
        }
        self
    }

    /// Set custom normalizer steps, replacing the defaults.
    pub fn normalizer_steps(mut self, steps: Vec<NormalizerStep>) -> Self {
        self.normalizer_steps = steps;
        self
    }

    /// Build the tokenizer from JSON string.
    pub fn build_from_json(self, json: &str) -> Result<CompiledTokenizer> {
        let vocab = Vocabulary::from_json(json)?;
        self.build_from_vocab(vocab)
    }

    /// Build the tokenizer from a file path.
    pub fn build_from_file<P: AsRef<Path>>(self, path: P) -> Result<CompiledTokenizer> {
        let json = fs::read_to_string(path)?;
        self.build_from_json(&json)
    }

    /// Build the tokenizer from a vocabulary.
    pub fn build_from_vocab(self, vocab: Vocabulary) -> Result<CompiledTokenizer> {
        // Build prefix trie from vocabulary
        let mut trie = PrefixTrie::new();
        for (token, id, score) in vocab.iter() {
            trie.insert_str(token, id, score);
        }

        // Create normalizer from configured steps
        let normalizer = Normalizer::new(NormalizerConfig {
            steps: self.normalizer_steps,
        });

        // Create Viterbi tokenizer
        let tokenizer = ViterbiTokenizer::new(trie, vocab.special_tokens.unk, self.unk_score);

        Ok(CompiledTokenizer {
            normalizer,
            tokenizer,
            vocab,
            max_length: self.max_length,
        })
    }
}

/// Compile a tokenizer.json file to .holo format.
///
/// # Arguments
/// * `input_path` - Path to tokenizer.json
/// * `output_path` - Path for output .holo file
pub fn compile_tokenizer<P: AsRef<Path>>(input_path: P, output_path: P) -> Result<()> {
    let json = fs::read_to_string(&input_path)?;
    let tokenizer = CompiledTokenizer::from_json(&json)?;

    // Build trie for serialization
    let mut trie = PrefixTrie::new();
    for (token, id, score) in tokenizer.vocab.iter() {
        trie.insert_str(token, id, score);
    }

    // Serialize
    let normalizer_config = NormalizerConfig {
        steps: vec![
            NormalizerStep::Nfkc,
            NormalizerStep::ReplaceWhitespace,
            NormalizerStep::CollapseWhitespace,
            NormalizerStep::SpaceToUnderscore,
            NormalizerStep::PrependUnderscore,
        ],
    };

    let data =
        serialization::serialize_tokenizer(tokenizer.vocabulary(), &trie, &normalizer_config)?;

    fs::write(output_path, data)?;

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE_TOKENIZER_JSON: &str = r#"{
        "model": {
            "vocab": [
                ["<pad>", 0.0],
                ["</s>", 0.0],
                ["<unk>", 0.0],
                ["\u2581", -0.5],
                ["\u2581hello", -1.0],
                ["\u2581world", -1.5],
                ["h", -2.0],
                ["e", -2.0],
                ["l", -2.0],
                ["o", -2.0],
                ["w", -2.0],
                ["r", -2.0],
                ["d", -2.0]
            ]
        },
        "added_tokens": [
            {"id": 0, "content": "<pad>", "special": true},
            {"id": 1, "content": "</s>", "special": true},
            {"id": 2, "content": "<unk>", "special": true}
        ]
    }"#;

    #[test]
    fn test_compiled_tokenizer_from_json() {
        let tokenizer = CompiledTokenizer::from_json(SAMPLE_TOKENIZER_JSON).unwrap();
        assert_eq!(tokenizer.vocab_size(), 13);
    }

    #[test]
    fn test_encode_simple() {
        let tokenizer = CompiledTokenizer::from_json(SAMPLE_TOKENIZER_JSON).unwrap();
        let (tokens, mask) = tokenizer.encode("hello", Some(10), true).unwrap();

        assert_eq!(tokens.len(), 10);
        assert_eq!(mask.len(), 10);

        // Should have some real tokens followed by EOS and padding
        let non_pad_count = mask.iter().filter(|&&x| x == 1).count();
        assert!(non_pad_count > 0);
    }

    #[test]
    fn test_encode_with_eos() {
        let tokenizer = CompiledTokenizer::from_json(SAMPLE_TOKENIZER_JSON).unwrap();
        let (tokens, _) = tokenizer.encode("hello", Some(20), true).unwrap();

        // Should end with EOS token (id=1) before padding
        let eos_pos = tokens.iter().position(|&t| t == 1);
        assert!(eos_pos.is_some());
    }

    #[test]
    fn test_decode() {
        let tokenizer = CompiledTokenizer::from_json(SAMPLE_TOKENIZER_JSON).unwrap();

        // Encode then decode
        let (tokens, _) = tokenizer.encode("hello world", Some(20), false).unwrap();
        let decoded = tokenizer.decode(&tokens);

        // Should get back the original text (approximately)
        assert!(
            decoded.contains("hello") || decoded.chars().filter(|c| !c.is_whitespace()).count() > 0
        );
    }

    #[test]
    fn test_truncation() {
        let tokenizer = CompiledTokenizer::from_json(SAMPLE_TOKENIZER_JSON).unwrap();
        let (tokens, mask) = tokenizer
            .encode("hello world hello world", Some(5), false)
            .unwrap();

        assert_eq!(tokens.len(), 5);
        assert_eq!(mask.len(), 5);
    }

    #[test]
    fn test_padding() {
        let tokenizer = CompiledTokenizer::from_json(SAMPLE_TOKENIZER_JSON).unwrap();
        let (tokens, mask) = tokenizer.encode("hi", Some(10), false).unwrap();

        assert_eq!(tokens.len(), 10);

        // First few should be real tokens, rest should be padding
        let pad_count = mask.iter().filter(|&&x| x == 0).count();
        assert!(pad_count > 0);
    }

    #[test]
    fn test_attention_mask() {
        let tokenizer = CompiledTokenizer::from_json(SAMPLE_TOKENIZER_JSON).unwrap();
        let (tokens, mask) = tokenizer.encode("hello", Some(10), true).unwrap();

        // Attention mask should have 1s for real tokens, 0s for padding
        for i in 0..tokens.len() {
            if tokens[i] == 0 && mask[i] == 0 {
                // Padding token with 0 mask - correct
            } else if mask[i] == 1 {
                // Real token with 1 mask - correct
            } else if tokens[i] == 0 && i == 0 {
                // First token might be pad if empty - edge case
            }
        }
    }

    #[test]
    fn test_special_tokens() {
        let tokenizer = CompiledTokenizer::from_json(SAMPLE_TOKENIZER_JSON).unwrap();
        let vocab = tokenizer.vocabulary();

        assert_eq!(vocab.special_tokens.pad, 0);
        assert_eq!(vocab.special_tokens.eos, 1);
        assert_eq!(vocab.special_tokens.unk, 2);
    }

    #[test]
    fn test_empty_input() {
        let tokenizer = CompiledTokenizer::from_json(SAMPLE_TOKENIZER_JSON).unwrap();
        let (tokens, _mask) = tokenizer.encode("", Some(5), true).unwrap();

        assert_eq!(tokens.len(), 5);
        // Should have at least the underscore prepended and EOS
    }

    #[test]
    fn test_unicode_input() {
        let tokenizer = CompiledTokenizer::from_json(SAMPLE_TOKENIZER_JSON).unwrap();
        // Should handle Unicode without panicking
        let result = tokenizer.encode("こんにちは", Some(10), false);
        assert!(result.is_ok());
    }

    // ========================================================================
    // Builder Pattern Tests
    // ========================================================================

    #[test]
    fn test_builder_default() {
        let tokenizer = CompiledTokenizer::builder()
            .build_from_json(SAMPLE_TOKENIZER_JSON)
            .unwrap();

        assert_eq!(tokenizer.max_length, 512);
        assert_eq!(tokenizer.vocab_size(), 13);
    }

    #[test]
    fn test_builder_max_length() {
        let tokenizer = CompiledTokenizer::builder()
            .max_length(128)
            .build_from_json(SAMPLE_TOKENIZER_JSON)
            .unwrap();

        assert_eq!(tokenizer.max_length, 128);
    }

    #[test]
    fn test_builder_unk_score() {
        let tokenizer = CompiledTokenizer::builder()
            .unk_score(-20.0)
            .build_from_json(SAMPLE_TOKENIZER_JSON)
            .unwrap();

        // Tokenizer should work with custom UNK score
        let (tokens, _) = tokenizer.encode("test", Some(10), false).unwrap();
        assert!(!tokens.is_empty());
    }

    #[test]
    fn test_builder_with_lowercase() {
        let tokenizer = CompiledTokenizer::builder()
            .with_lowercase()
            .build_from_json(SAMPLE_TOKENIZER_JSON)
            .unwrap();

        // Should work with lowercase normalization
        let (tokens1, _) = tokenizer.encode("HELLO", Some(10), false).unwrap();
        let (tokens2, _) = tokenizer.encode("hello", Some(10), false).unwrap();

        // With lowercase normalization, both should produce similar tokenization
        assert_eq!(tokens1.len(), tokens2.len());
    }

    #[test]
    fn test_builder_clear_normalizer() {
        let tokenizer = CompiledTokenizer::builder()
            .clear_normalizer()
            .build_from_json(SAMPLE_TOKENIZER_JSON)
            .unwrap();

        // Should still work with no normalizer steps
        let result = tokenizer.encode("hello", Some(10), false);
        assert!(result.is_ok());
    }

    #[test]
    fn test_builder_custom_normalizer_steps() {
        let tokenizer = CompiledTokenizer::builder()
            .normalizer_steps(vec![
                NormalizerStep::Lowercase,
                NormalizerStep::CollapseWhitespace,
            ])
            .build_from_json(SAMPLE_TOKENIZER_JSON)
            .unwrap();

        let result = tokenizer.encode("HELLO   WORLD", Some(10), false);
        assert!(result.is_ok());
    }

    #[test]
    fn test_builder_chained() {
        let tokenizer = CompiledTokenizer::builder()
            .max_length(256)
            .unk_score(-15.0)
            .with_lowercase()
            .with_nfkc()
            .build_from_json(SAMPLE_TOKENIZER_JSON)
            .unwrap();

        assert_eq!(tokenizer.max_length, 256);
        let (tokens, _) = tokenizer.encode("Test", Some(10), false).unwrap();
        assert!(!tokens.is_empty());
    }

    #[test]
    fn test_tokenizer_builder_default_impl() {
        let builder1 = TokenizerBuilder::new();
        let builder2 = TokenizerBuilder::default();

        // Both should have same defaults
        assert_eq!(builder1.max_length, builder2.max_length);
        assert_eq!(builder1.unk_score, builder2.unk_score);
    }
}
