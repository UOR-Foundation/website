/**
 * Identity Module — Barrel Export
 * ═══════════════════════════════
 *
 * This extends the existing identity module (addressing.ts) with
 * the trust/privacy/permissions layer.
 *
 * On merge:
 *   1. Copy this module to src/modules/identity/ in the main repo
 *   2. Merge this index.ts with the existing one (keep addressing exports)
 *   3. Delete compat/ folder
 *   4. Update imports from compat/ → hologram-ui
 *   5. Add route: <Route path="/identity" element={<IdentityDashboard />} />
 *   6. Register in namespace-registry.ts (already under u: prefix)
 *
 * @module identity
 */

// ── Types (pure data) ──────────────────────────────────────────────────────
export type {
  IdentityProfile,
  TrustAttestation,
  TrustLevel,
  TrustScore,
  DataCategory,
  ConsentStatus,
  PrivacyConsent,
  PrivacyPolicy,
  PolicySection,
  PermissionAction,
  PermissionScope,
  Permission,
  IdentityModuleState,
  CeremonyRecord,
  CeremonyType,
  KeyFingerprint,
  KeyPairMeta,
  CeremonyIdentityProfile,
  SovereigntyDimension,
  SovereigntyDimensionId,
  BoundaryEdge,
  EdgeState,
  SovereigntySurface,
  BoundaryCommitment,
  EdgeDiff,
} from "./types";

// ── Engine (pure functions) ─────────────────────────────────────────────────
export {
  computeTrustScore,
  hasPermission,
  permissionsByScope,
  isConsentActive,
  activeConsents,
  generateKeyPair,
  computeFingerprint,
  createFoundingCeremony,
  isCeremonyValid,
  ceremoniesByType,
  trustLevelFromCeremonies,
  initiatePeerCeremony,
  acceptPeerCeremony,
  completePeerCeremony,
  SOVEREIGNTY_DIMENSIONS,
  createDefaultSurface,
  flipEdge,
  flipEdges,
  diffSurfaces,
  createBoundaryCommitment,
  edgesByDimension,
  edgesByState,
  disclosureRatio,
  dimensionDisclosureRatios,
  edgesForDataCategory,
  buildMerkleTree,
  createDisclosureProof,
  verifyDisclosureProof,
  proofSummary,
  treeDepth,
  computePathIntegral,
  buildValueGraph,
  pairValueBreakdown,
  pathEfficiency,
  DEFAULT_PATH_INTEGRAL_CONFIG,
  computeThreeAxisSeparation,
  computeAgentAxis,
  computeDataAxis,
  computeInferenceAxis,
  DEFAULT_THREE_AXIS_CONFIG,
} from "./engine";

// ── Hooks ───────────────────────────────────────────────────────────────────
export { useIdentity } from "./hooks";

// ── Pages ───────────────────────────────────────────────────────────────────
export { default as IdentityDashboard } from "./pages/IdentityDashboard";

// ── Components ──────────────────────────────────────────────────────────────
export {
  IdentityProfileCard,
  TrustMeter,
  PermissionsPanel,
  ConsentManager,
  PrivacyPolicyViewer,
  CeremonyHistory,
  SelectiveDisclosurePanel,
  TrustCeremonyDialog,
  SovereigntyMap,
  CommitmentHistory,
  PathIntegralPanel,
  ThreeAxisPanel,
} from "./components";
