//! Streaming execution for batch processing.
//!
//! This module provides async streaming for processing large batches of data.

use crate::executor::AsyncExecutor;
use crate::Result;
use futures::stream::Stream;
use std::pin::Pin;
use std::task::{Context, Poll};

/// A stream of execution results for large batch processing.
pub struct ExecutionStream<T> {
    inner: Pin<Box<dyn Stream<Item = Result<T>> + Send>>,
}

impl<T> ExecutionStream<T> {
    /// Create a new execution stream.
    pub fn new<S>(stream: S) -> Self
    where
        S: Stream<Item = Result<T>> + Send + 'static,
    {
        Self {
            inner: Box::pin(stream),
        }
    }

    /// Create a stream from an iterator of items.
    pub fn from_items<I>(iter: I) -> Self
    where
        I: IntoIterator<Item = T> + Send + 'static,
        I::IntoIter: Send,
        T: Send + 'static,
    {
        let stream = futures::stream::iter(iter.into_iter().map(Ok));
        Self::new(stream)
    }

    /// Create an empty stream.
    pub fn empty() -> Self
    where
        T: Send + 'static,
    {
        Self::new(futures::stream::empty())
    }

    /// Create a stream that yields a single item.
    pub fn once(item: T) -> Self
    where
        T: Send + 'static,
    {
        Self::new(futures::stream::once(async { Ok(item) }))
    }
}

impl<T> Stream for ExecutionStream<T> {
    type Item = Result<T>;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.inner.as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

/// Execute a batch of inputs as an async stream.
///
/// This function processes inputs in batches and yields results as they become available.
pub fn execute_stream<T, I>(
    executor: AsyncExecutor,
    inputs: I,
    batch_size: usize,
) -> ExecutionStream<Vec<T>>
where
    T: Clone + Send + Sync + 'static,
    I: IntoIterator<Item = T> + Send + 'static,
    I::IntoIter: Send,
{
    let inputs: Vec<T> = inputs.into_iter().collect();
    let batch_size = batch_size.max(1);

    let stream = async_stream::stream! {
        let _executor = executor; // Keep executor alive

        for chunk in inputs.chunks(batch_size) {
            // Yield each batch as a result
            yield Ok(chunk.to_vec());
        }
    };

    ExecutionStream::new(stream)
}

/// Execute a batch of inputs with a transformation function.
pub fn execute_stream_map<T, U, F, I>(
    executor: AsyncExecutor,
    inputs: I,
    batch_size: usize,
    transform: F,
) -> ExecutionStream<Vec<U>>
where
    T: Clone + Send + Sync + 'static,
    U: Send + 'static,
    I: IntoIterator<Item = T> + Send + 'static,
    I::IntoIter: Send,
    F: Fn(T) -> U + Send + Sync + 'static,
{
    let inputs: Vec<T> = inputs.into_iter().collect();
    let batch_size = batch_size.max(1);

    let stream = async_stream::stream! {
        let _executor = executor;

        for chunk in inputs.chunks(batch_size) {
            let results: Vec<U> = chunk.iter().cloned().map(&transform).collect();
            yield Ok(results);
        }
    };

    ExecutionStream::new(stream)
}

/// Stream utilities for ExecutionStream.
pub trait ExecutionStreamExt<T>: Sized {
    /// Collect all results into a vector.
    fn collect_all(self) -> impl std::future::Future<Output = Result<Vec<T>>> + Send;

    /// Map each item in the stream.
    fn map_items<U, F>(self, f: F) -> ExecutionStream<U>
    where
        F: Fn(T) -> U + Send + Sync + 'static,
        T: Send + 'static,
        U: Send + 'static;

    /// Filter items in the stream.
    fn filter_items<F>(self, predicate: F) -> ExecutionStream<T>
    where
        F: Fn(&T) -> bool + Send + Sync + 'static,
        T: Send + 'static;
}

impl<T: Send + 'static> ExecutionStreamExt<T> for ExecutionStream<T> {
    async fn collect_all(self) -> Result<Vec<T>> {
        use futures::StreamExt;

        let mut results = Vec::new();
        let mut stream = self;

        while let Some(result) = stream.next().await {
            results.push(result?);
        }

        Ok(results)
    }

    fn map_items<U, F>(self, f: F) -> ExecutionStream<U>
    where
        F: Fn(T) -> U + Send + Sync + 'static,
        U: Send + 'static,
    {
        use futures::StreamExt;

        let mapped = self.map(move |result| result.map(&f));
        ExecutionStream::new(mapped)
    }

    fn filter_items<F>(self, predicate: F) -> ExecutionStream<T>
    where
        F: Fn(&T) -> bool + Send + Sync + 'static,
    {
        use futures::StreamExt;
        use std::sync::Arc;

        let predicate = Arc::new(predicate);
        let filtered = self.filter_map(move |result| {
            let pred = Arc::clone(&predicate);
            async move {
                match result {
                    Ok(item) if pred(&item) => Some(Ok(item)),
                    Ok(_) => None,
                    Err(e) => Some(Err(e)),
                }
            }
        });

        ExecutionStream::new(filtered)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use futures::StreamExt;
    use hologram_core::BackendType;

    #[tokio::test]
    async fn test_execution_stream_new() {
        let stream = ExecutionStream::from_items(vec![1, 2, 3]);
        let results: Vec<_> = stream.collect().await;
        assert_eq!(results.len(), 3);
    }

    #[tokio::test]
    async fn test_execution_stream_empty() {
        let stream: ExecutionStream<i32> = ExecutionStream::empty();
        let results: Vec<_> = stream.collect().await;
        assert!(results.is_empty());
    }

    #[tokio::test]
    async fn test_execution_stream_once() {
        let stream = ExecutionStream::once(42);
        let results: Vec<_> = stream.collect().await;
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].as_ref().unwrap(), &42);
    }

    #[tokio::test]
    async fn test_execution_stream_from_items() {
        let stream = ExecutionStream::from_items(0..5);
        let results: Vec<_> = stream.collect().await;
        assert_eq!(results.len(), 5);

        for (i, result) in results.iter().enumerate() {
            assert_eq!(result.as_ref().unwrap(), &i);
        }
    }

    #[tokio::test]
    async fn test_execute_stream() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let inputs = vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
        let stream = execute_stream(exec, inputs, 3);

        let batches: Vec<_> = stream.collect().await;
        assert_eq!(batches.len(), 4); // 3 + 3 + 3 + 1

        assert_eq!(batches[0].as_ref().unwrap().len(), 3);
        assert_eq!(batches[1].as_ref().unwrap().len(), 3);
        assert_eq!(batches[2].as_ref().unwrap().len(), 3);
        assert_eq!(batches[3].as_ref().unwrap().len(), 1);
    }

    #[tokio::test]
    async fn test_execute_stream_batch_size_one() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let inputs = vec![1, 2, 3];
        let stream = execute_stream(exec, inputs, 1);

        let batches: Vec<_> = stream.collect().await;
        assert_eq!(batches.len(), 3);
    }

    #[tokio::test]
    async fn test_execute_stream_batch_size_larger_than_input() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let inputs = vec![1, 2, 3];
        let stream = execute_stream(exec, inputs, 100);

        let batches: Vec<_> = stream.collect().await;
        assert_eq!(batches.len(), 1);
        assert_eq!(batches[0].as_ref().unwrap().len(), 3);
    }

    #[tokio::test]
    async fn test_execute_stream_map() {
        let exec = AsyncExecutor::with_backend(BackendType::Cpu).await.unwrap();
        let inputs = vec![1, 2, 3, 4];
        let stream = execute_stream_map(exec, inputs, 2, |x| x * 2);

        let batches: Vec<_> = stream.collect().await;
        assert_eq!(batches.len(), 2);
        assert_eq!(batches[0].as_ref().unwrap(), &vec![2, 4]);
        assert_eq!(batches[1].as_ref().unwrap(), &vec![6, 8]);
    }

    #[tokio::test]
    async fn test_execution_stream_collect_all() {
        let stream = ExecutionStream::from_items(vec![1, 2, 3, 4, 5]);
        let results = stream.collect_all().await.unwrap();
        assert_eq!(results, vec![1, 2, 3, 4, 5]);
    }

    #[tokio::test]
    async fn test_execution_stream_map_items() {
        let stream = ExecutionStream::from_items(vec![1, 2, 3]);
        let mapped = stream.map_items(|x| x * 10);
        let results = mapped.collect_all().await.unwrap();
        assert_eq!(results, vec![10, 20, 30]);
    }

    #[tokio::test]
    async fn test_execution_stream_filter_items() {
        let stream = ExecutionStream::from_items(vec![1, 2, 3, 4, 5, 6]);
        let filtered = stream.filter_items(|x| x % 2 == 0);
        let results = filtered.collect_all().await.unwrap();
        assert_eq!(results, vec![2, 4, 6]);
    }

    #[tokio::test]
    async fn test_execution_stream_size_hint() {
        let stream = ExecutionStream::from_items(vec![1, 2, 3, 4, 5]);
        let (lower, upper) = stream.size_hint();
        assert_eq!(lower, 5);
        assert_eq!(upper, Some(5));
    }

    #[tokio::test]
    async fn test_execution_stream_chain() {
        let stream = ExecutionStream::from_items(vec![1, 2, 3])
            .map_items(|x| x * 2)
            .filter_items(|x| *x > 2);
        let results = stream.collect_all().await.unwrap();
        assert_eq!(results, vec![4, 6]);
    }
}
