//! Cross-backend verification tests for microcode operations (TASK-169).
//!
//! Property-based tests using proptest to verify that microcode-derived operations
//! (inc, dec, add, sub) produce identical results across all backend variants:
//! - ScalarTarget (u32)
//! - Simd128Target ([u32; 4])
//! - Simd256Target ([u32; 8])
//! - BackendImpl (auto-selected)
//!
//! These tests verify mathematical equivalence across all execution paths.

use hologram_backend::microcode::BackendImpl;
use hologram_backend::target::{ScalarTarget, Simd128Target, Simd256Target};
use proptest::prelude::*;
use uor::microcode::{MicrocodeOps, MicrocodePrimitives};

// =============================================================================
// Property-Based Tests: Scalar Operations (u32)
// =============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(1000))]

    /// Verify inc(x) produces identical results across all backends.
    #[test]
    fn prop_inc_cross_backend_u32(x in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        let result_scalar = scalar.inc(x);
        let result_backend = backend.inc(x);
        let expected = x.wrapping_add(1);

        prop_assert_eq!(result_scalar, expected, "ScalarTarget inc mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl inc mismatch");
        prop_assert_eq!(result_scalar, result_backend, "Cross-backend inc mismatch");
    }

    /// Verify dec(x) produces identical results across all backends.
    #[test]
    fn prop_dec_cross_backend_u32(x in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        let result_scalar = scalar.dec(x);
        let result_backend = backend.dec(x);
        let expected = x.wrapping_sub(1);

        prop_assert_eq!(result_scalar, expected, "ScalarTarget dec mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl dec mismatch");
        prop_assert_eq!(result_scalar, result_backend, "Cross-backend dec mismatch");
    }

    /// Verify add(a, b) produces identical results across all backends.
    #[test]
    fn prop_add_cross_backend_u32(a in any::<u32>(), b in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        let result_scalar = scalar.add(a, b);
        let result_backend = backend.add(a, b);
        let expected = a.wrapping_add(b);

        prop_assert_eq!(result_scalar, expected, "ScalarTarget add mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl add mismatch");
        prop_assert_eq!(result_scalar, result_backend, "Cross-backend add mismatch");
    }

    /// Verify sub(a, b) produces identical results across all backends.
    #[test]
    fn prop_sub_cross_backend_u32(a in any::<u32>(), b in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        let result_scalar = scalar.sub(a, b);
        let result_backend = backend.sub(a, b);
        let expected = a.wrapping_sub(b);

        prop_assert_eq!(result_scalar, expected, "ScalarTarget sub mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl sub mismatch");
        prop_assert_eq!(result_scalar, result_backend, "Cross-backend sub mismatch");
    }
}

// =============================================================================
// Property-Based Tests: Primitives (u32)
// =============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(1000))]

    /// Verify bnot(x) produces identical results across all backends.
    #[test]
    fn prop_bnot_cross_backend_u32(x in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        let result_scalar = scalar.bnot(x);
        let result_backend = backend.bnot(x);
        let expected = !x;

        prop_assert_eq!(result_scalar, expected, "ScalarTarget bnot mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl bnot mismatch");
        prop_assert_eq!(result_scalar, result_backend, "Cross-backend bnot mismatch");
    }

    /// Verify neg(x) produces identical results across all backends.
    #[test]
    fn prop_neg_cross_backend_u32(x in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        let result_scalar = scalar.neg(x);
        let result_backend = backend.neg(x);
        let expected = x.wrapping_neg();

        prop_assert_eq!(result_scalar, expected, "ScalarTarget neg mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl neg mismatch");
        prop_assert_eq!(result_scalar, result_backend, "Cross-backend neg mismatch");
    }

    /// Verify xor(a, b) produces identical results across all backends.
    #[test]
    fn prop_xor_cross_backend_u32(a in any::<u32>(), b in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        let result_scalar = scalar.xor(a, b);
        let result_backend = backend.xor(a, b);
        let expected = a ^ b;

        prop_assert_eq!(result_scalar, expected);
        prop_assert_eq!(result_backend, expected);
        prop_assert_eq!(result_scalar, result_backend);
    }

    /// Verify and(a, b) produces identical results across all backends.
    #[test]
    fn prop_and_cross_backend_u32(a in any::<u32>(), b in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        let result_scalar = scalar.and(a, b);
        let result_backend = backend.and(a, b);
        let expected = a & b;

        prop_assert_eq!(result_scalar, expected);
        prop_assert_eq!(result_backend, expected);
        prop_assert_eq!(result_scalar, result_backend);
    }

    /// Verify or(a, b) produces identical results across all backends.
    #[test]
    fn prop_or_cross_backend_u32(a in any::<u32>(), b in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        let result_scalar = scalar.or(a, b);
        let result_backend = backend.or(a, b);
        let expected = a | b;

        prop_assert_eq!(result_scalar, expected);
        prop_assert_eq!(result_backend, expected);
        prop_assert_eq!(result_scalar, result_backend);
    }
}

// =============================================================================
// Property-Based Tests: SIMD-128 ([u32; 4])
// =============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(500))]

    /// Verify inc produces element-wise identical results for [u32; 4].
    #[test]
    fn prop_inc_cross_backend_simd128(
        a0 in any::<u32>(),
        a1 in any::<u32>(),
        a2 in any::<u32>(),
        a3 in any::<u32>(),
    ) {
        let simd128 = Simd128Target::new();
        let backend = BackendImpl::auto_select();

        let arr = [a0, a1, a2, a3];
        let result_simd = simd128.inc(arr);
        let result_backend = backend.inc(arr);
        let expected = [
            a0.wrapping_add(1),
            a1.wrapping_add(1),
            a2.wrapping_add(1),
            a3.wrapping_add(1),
        ];

        prop_assert_eq!(result_simd, expected, "Simd128Target inc mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl inc mismatch");
        prop_assert_eq!(result_simd, result_backend, "Cross-backend inc mismatch");
    }

    /// Verify dec produces element-wise identical results for [u32; 4].
    #[test]
    fn prop_dec_cross_backend_simd128(
        a0 in any::<u32>(),
        a1 in any::<u32>(),
        a2 in any::<u32>(),
        a3 in any::<u32>(),
    ) {
        let simd128 = Simd128Target::new();
        let backend = BackendImpl::auto_select();

        let arr = [a0, a1, a2, a3];
        let result_simd = simd128.dec(arr);
        let result_backend = backend.dec(arr);
        let expected = [
            a0.wrapping_sub(1),
            a1.wrapping_sub(1),
            a2.wrapping_sub(1),
            a3.wrapping_sub(1),
        ];

        prop_assert_eq!(result_simd, expected, "Simd128Target dec mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl dec mismatch");
        prop_assert_eq!(result_simd, result_backend, "Cross-backend dec mismatch");
    }

    /// Verify add produces element-wise identical results for [u32; 4].
    #[test]
    fn prop_add_cross_backend_simd128(
        a0 in any::<u32>(), a1 in any::<u32>(), a2 in any::<u32>(), a3 in any::<u32>(),
        b0 in any::<u32>(), b1 in any::<u32>(), b2 in any::<u32>(), b3 in any::<u32>(),
    ) {
        let simd128 = Simd128Target::new();
        let backend = BackendImpl::auto_select();

        let a = [a0, a1, a2, a3];
        let b = [b0, b1, b2, b3];

        let result_simd = simd128.add(a, b);
        let result_backend = backend.add(a, b);
        let expected = [
            a0.wrapping_add(b0),
            a1.wrapping_add(b1),
            a2.wrapping_add(b2),
            a3.wrapping_add(b3),
        ];

        prop_assert_eq!(result_simd, expected, "Simd128Target add mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl add mismatch");
        prop_assert_eq!(result_simd, result_backend, "Cross-backend add mismatch");
    }

    /// Verify sub produces element-wise identical results for [u32; 4].
    #[test]
    fn prop_sub_cross_backend_simd128(
        a0 in any::<u32>(), a1 in any::<u32>(), a2 in any::<u32>(), a3 in any::<u32>(),
        b0 in any::<u32>(), b1 in any::<u32>(), b2 in any::<u32>(), b3 in any::<u32>(),
    ) {
        let simd128 = Simd128Target::new();
        let backend = BackendImpl::auto_select();

        let a = [a0, a1, a2, a3];
        let b = [b0, b1, b2, b3];

        let result_simd = simd128.sub(a, b);
        let result_backend = backend.sub(a, b);
        let expected = [
            a0.wrapping_sub(b0),
            a1.wrapping_sub(b1),
            a2.wrapping_sub(b2),
            a3.wrapping_sub(b3),
        ];

        prop_assert_eq!(result_simd, expected, "Simd128Target sub mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl sub mismatch");
        prop_assert_eq!(result_simd, result_backend, "Cross-backend sub mismatch");
    }

    /// Verify primitives produce element-wise identical results for [u32; 4].
    #[test]
    fn prop_primitives_cross_backend_simd128(
        a0 in any::<u32>(), a1 in any::<u32>(), a2 in any::<u32>(), a3 in any::<u32>(),
        b0 in any::<u32>(), b1 in any::<u32>(), b2 in any::<u32>(), b3 in any::<u32>(),
    ) {
        let simd128 = Simd128Target::new();
        let backend = BackendImpl::auto_select();

        let a = [a0, a1, a2, a3];
        let b = [b0, b1, b2, b3];

        // bnot
        let bnot_simd = simd128.bnot(a);
        let bnot_backend = backend.bnot(a);
        prop_assert_eq!(bnot_simd, bnot_backend, "bnot mismatch");

        // neg
        let neg_simd = simd128.neg(a);
        let neg_backend = backend.neg(a);
        prop_assert_eq!(neg_simd, neg_backend, "neg mismatch");

        // xor
        let xor_simd = simd128.xor(a, b);
        let xor_backend = backend.xor(a, b);
        prop_assert_eq!(xor_simd, xor_backend, "xor mismatch");

        // and
        let and_simd = simd128.and(a, b);
        let and_backend = backend.and(a, b);
        prop_assert_eq!(and_simd, and_backend, "and mismatch");

        // or
        let or_simd = simd128.or(a, b);
        let or_backend = backend.or(a, b);
        prop_assert_eq!(or_simd, or_backend, "or mismatch");
    }
}

// =============================================================================
// Property-Based Tests: SIMD-256 ([u32; 8])
// =============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(250))]

    /// Verify inc produces element-wise identical results for [u32; 8].
    #[test]
    fn prop_inc_cross_backend_simd256(
        a0 in any::<u32>(), a1 in any::<u32>(), a2 in any::<u32>(), a3 in any::<u32>(),
        a4 in any::<u32>(), a5 in any::<u32>(), a6 in any::<u32>(), a7 in any::<u32>(),
    ) {
        let simd256 = Simd256Target::new();
        let backend = BackendImpl::auto_select();

        let arr = [a0, a1, a2, a3, a4, a5, a6, a7];
        let result_simd = simd256.inc(arr);
        let result_backend = backend.inc(arr);
        let expected = [
            a0.wrapping_add(1), a1.wrapping_add(1), a2.wrapping_add(1), a3.wrapping_add(1),
            a4.wrapping_add(1), a5.wrapping_add(1), a6.wrapping_add(1), a7.wrapping_add(1),
        ];

        prop_assert_eq!(result_simd, expected, "Simd256Target inc mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl inc mismatch");
        prop_assert_eq!(result_simd, result_backend, "Cross-backend inc mismatch");
    }

    /// Verify dec produces element-wise identical results for [u32; 8].
    #[test]
    fn prop_dec_cross_backend_simd256(
        a0 in any::<u32>(), a1 in any::<u32>(), a2 in any::<u32>(), a3 in any::<u32>(),
        a4 in any::<u32>(), a5 in any::<u32>(), a6 in any::<u32>(), a7 in any::<u32>(),
    ) {
        let simd256 = Simd256Target::new();
        let backend = BackendImpl::auto_select();

        let arr = [a0, a1, a2, a3, a4, a5, a6, a7];
        let result_simd = simd256.dec(arr);
        let result_backend = backend.dec(arr);
        let expected = [
            a0.wrapping_sub(1), a1.wrapping_sub(1), a2.wrapping_sub(1), a3.wrapping_sub(1),
            a4.wrapping_sub(1), a5.wrapping_sub(1), a6.wrapping_sub(1), a7.wrapping_sub(1),
        ];

        prop_assert_eq!(result_simd, expected, "Simd256Target dec mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl dec mismatch");
        prop_assert_eq!(result_simd, result_backend, "Cross-backend dec mismatch");
    }

    /// Verify add produces element-wise identical results for [u32; 8].
    #[test]
    fn prop_add_cross_backend_simd256(
        a0 in any::<u32>(), a1 in any::<u32>(), a2 in any::<u32>(), a3 in any::<u32>(),
        a4 in any::<u32>(), a5 in any::<u32>(), a6 in any::<u32>(), a7 in any::<u32>(),
        b0 in any::<u32>(), b1 in any::<u32>(), b2 in any::<u32>(), b3 in any::<u32>(),
        b4 in any::<u32>(), b5 in any::<u32>(), b6 in any::<u32>(), b7 in any::<u32>(),
    ) {
        let simd256 = Simd256Target::new();
        let backend = BackendImpl::auto_select();

        let a = [a0, a1, a2, a3, a4, a5, a6, a7];
        let b = [b0, b1, b2, b3, b4, b5, b6, b7];

        let result_simd = simd256.add(a, b);
        let result_backend = backend.add(a, b);
        let expected = [
            a0.wrapping_add(b0), a1.wrapping_add(b1), a2.wrapping_add(b2), a3.wrapping_add(b3),
            a4.wrapping_add(b4), a5.wrapping_add(b5), a6.wrapping_add(b6), a7.wrapping_add(b7),
        ];

        prop_assert_eq!(result_simd, expected, "Simd256Target add mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl add mismatch");
        prop_assert_eq!(result_simd, result_backend, "Cross-backend add mismatch");
    }

    /// Verify sub produces element-wise identical results for [u32; 8].
    #[test]
    fn prop_sub_cross_backend_simd256(
        a0 in any::<u32>(), a1 in any::<u32>(), a2 in any::<u32>(), a3 in any::<u32>(),
        a4 in any::<u32>(), a5 in any::<u32>(), a6 in any::<u32>(), a7 in any::<u32>(),
        b0 in any::<u32>(), b1 in any::<u32>(), b2 in any::<u32>(), b3 in any::<u32>(),
        b4 in any::<u32>(), b5 in any::<u32>(), b6 in any::<u32>(), b7 in any::<u32>(),
    ) {
        let simd256 = Simd256Target::new();
        let backend = BackendImpl::auto_select();

        let a = [a0, a1, a2, a3, a4, a5, a6, a7];
        let b = [b0, b1, b2, b3, b4, b5, b6, b7];

        let result_simd = simd256.sub(a, b);
        let result_backend = backend.sub(a, b);
        let expected = [
            a0.wrapping_sub(b0), a1.wrapping_sub(b1), a2.wrapping_sub(b2), a3.wrapping_sub(b3),
            a4.wrapping_sub(b4), a5.wrapping_sub(b5), a6.wrapping_sub(b6), a7.wrapping_sub(b7),
        ];

        prop_assert_eq!(result_simd, expected, "Simd256Target sub mismatch");
        prop_assert_eq!(result_backend, expected, "BackendImpl sub mismatch");
        prop_assert_eq!(result_simd, result_backend, "Cross-backend sub mismatch");
    }

    /// Verify primitives produce element-wise identical results for [u32; 8].
    #[test]
    fn prop_primitives_cross_backend_simd256(
        a0 in any::<u32>(), a1 in any::<u32>(), a2 in any::<u32>(), a3 in any::<u32>(),
        a4 in any::<u32>(), a5 in any::<u32>(), a6 in any::<u32>(), a7 in any::<u32>(),
        b0 in any::<u32>(), b1 in any::<u32>(), b2 in any::<u32>(), b3 in any::<u32>(),
        b4 in any::<u32>(), b5 in any::<u32>(), b6 in any::<u32>(), b7 in any::<u32>(),
    ) {
        let simd256 = Simd256Target::new();
        let backend = BackendImpl::auto_select();

        let a = [a0, a1, a2, a3, a4, a5, a6, a7];
        let b = [b0, b1, b2, b3, b4, b5, b6, b7];

        // bnot
        let bnot_simd = simd256.bnot(a);
        let bnot_backend = backend.bnot(a);
        prop_assert_eq!(bnot_simd, bnot_backend, "bnot mismatch");

        // neg
        let neg_simd = simd256.neg(a);
        let neg_backend = backend.neg(a);
        prop_assert_eq!(neg_simd, neg_backend, "neg mismatch");

        // xor
        let xor_simd = simd256.xor(a, b);
        let xor_backend = backend.xor(a, b);
        prop_assert_eq!(xor_simd, xor_backend, "xor mismatch");

        // and
        let and_simd = simd256.and(a, b);
        let and_backend = backend.and(a, b);
        prop_assert_eq!(and_simd, and_backend, "and mismatch");

        // or
        let or_simd = simd256.or(a, b);
        let or_backend = backend.or(a, b);
        prop_assert_eq!(or_simd, or_backend, "or mismatch");
    }
}

// =============================================================================
// Property-Based Tests: Algebraic Identities
// =============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(1000))]

    /// Verify inc(dec(x)) = x for all backends.
    #[test]
    fn prop_inc_dec_identity_u32(x in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        // inc(dec(x)) = x
        prop_assert_eq!(scalar.inc(scalar.dec(x)), x, "ScalarTarget inc(dec(x)) != x");
        prop_assert_eq!(backend.inc(backend.dec(x)), x, "BackendImpl inc(dec(x)) != x");

        // dec(inc(x)) = x
        prop_assert_eq!(scalar.dec(scalar.inc(x)), x, "ScalarTarget dec(inc(x)) != x");
        prop_assert_eq!(backend.dec(backend.inc(x)), x, "BackendImpl dec(inc(x)) != x");
    }

    /// Verify add(x, 0) = x for all backends.
    #[test]
    fn prop_add_identity_u32(x in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        prop_assert_eq!(scalar.add(x, 0), x, "ScalarTarget add(x, 0) != x");
        prop_assert_eq!(backend.add(x, 0), x, "BackendImpl add(x, 0) != x");
        prop_assert_eq!(scalar.add(0, x), x, "ScalarTarget add(0, x) != x");
        prop_assert_eq!(backend.add(0, x), x, "BackendImpl add(0, x) != x");
    }

    /// Verify sub(x, x) = 0 for all backends.
    #[test]
    fn prop_sub_self_zero_u32(x in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        prop_assert_eq!(scalar.sub(x, x), 0, "ScalarTarget sub(x, x) != 0");
        prop_assert_eq!(backend.sub(x, x), 0, "BackendImpl sub(x, x) != 0");
    }

    /// Verify add(sub(x, y), y) = x for all backends.
    #[test]
    fn prop_add_sub_inverse_u32(x in any::<u32>(), y in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        // add(sub(x, y), y) = x
        prop_assert_eq!(
            scalar.add(scalar.sub(x, y), y), x,
            "ScalarTarget add(sub(x, y), y) != x"
        );
        prop_assert_eq!(
            backend.add(backend.sub(x, y), y), x,
            "BackendImpl add(sub(x, y), y) != x"
        );

        // sub(add(x, y), y) = x
        prop_assert_eq!(
            scalar.sub(scalar.add(x, y), y), x,
            "ScalarTarget sub(add(x, y), y) != x"
        );
        prop_assert_eq!(
            backend.sub(backend.add(x, y), y), x,
            "BackendImpl sub(add(x, y), y) != x"
        );
    }

    /// Verify neg(neg(x)) = x (involution) for all backends.
    #[test]
    fn prop_neg_involution_u32(x in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        prop_assert_eq!(scalar.neg(scalar.neg(x)), x, "ScalarTarget neg involution failed");
        prop_assert_eq!(backend.neg(backend.neg(x)), x, "BackendImpl neg involution failed");
    }

    /// Verify bnot(bnot(x)) = x (involution) for all backends.
    #[test]
    fn prop_bnot_involution_u32(x in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        prop_assert_eq!(scalar.bnot(scalar.bnot(x)), x, "ScalarTarget bnot involution failed");
        prop_assert_eq!(backend.bnot(backend.bnot(x)), x, "BackendImpl bnot involution failed");
    }

    /// Verify the microcode identity: neg(bnot(x)) = x + 1.
    #[test]
    fn prop_microcode_inc_identity_u32(x in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();
        let expected = x.wrapping_add(1);

        // neg(bnot(x)) = x + 1
        prop_assert_eq!(
            scalar.neg(scalar.bnot(x)), expected,
            "ScalarTarget neg(bnot(x)) != x + 1"
        );
        prop_assert_eq!(
            backend.neg(backend.bnot(x)), expected,
            "BackendImpl neg(bnot(x)) != x + 1"
        );
    }

    /// Verify the microcode identity: bnot(neg(x)) = x - 1.
    #[test]
    fn prop_microcode_dec_identity_u32(x in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();
        let expected = x.wrapping_sub(1);

        // bnot(neg(x)) = x - 1
        prop_assert_eq!(
            scalar.bnot(scalar.neg(x)), expected,
            "ScalarTarget bnot(neg(x)) != x - 1"
        );
        prop_assert_eq!(
            backend.bnot(backend.neg(x)), expected,
            "BackendImpl bnot(neg(x)) != x - 1"
        );
    }
}

// =============================================================================
// Property-Based Tests: Commutativity and Associativity
// =============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(1000))]

    /// Verify add is commutative: add(a, b) = add(b, a).
    #[test]
    fn prop_add_commutative_u32(a in any::<u32>(), b in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        prop_assert_eq!(scalar.add(a, b), scalar.add(b, a), "ScalarTarget add not commutative");
        prop_assert_eq!(backend.add(a, b), backend.add(b, a), "BackendImpl add not commutative");
    }

    /// Verify xor is commutative: xor(a, b) = xor(b, a).
    #[test]
    fn prop_xor_commutative_u32(a in any::<u32>(), b in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        prop_assert_eq!(scalar.xor(a, b), scalar.xor(b, a), "ScalarTarget xor not commutative");
        prop_assert_eq!(backend.xor(a, b), backend.xor(b, a), "BackendImpl xor not commutative");
    }

    /// Verify and is commutative: and(a, b) = and(b, a).
    #[test]
    fn prop_and_commutative_u32(a in any::<u32>(), b in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        prop_assert_eq!(scalar.and(a, b), scalar.and(b, a), "ScalarTarget and not commutative");
        prop_assert_eq!(backend.and(a, b), backend.and(b, a), "BackendImpl and not commutative");
    }

    /// Verify or is commutative: or(a, b) = or(b, a).
    #[test]
    fn prop_or_commutative_u32(a in any::<u32>(), b in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        prop_assert_eq!(scalar.or(a, b), scalar.or(b, a), "ScalarTarget or not commutative");
        prop_assert_eq!(backend.or(a, b), backend.or(b, a), "BackendImpl or not commutative");
    }

    /// Verify add is associative: add(add(a, b), c) = add(a, add(b, c)).
    #[test]
    fn prop_add_associative_u32(a in any::<u32>(), b in any::<u32>(), c in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        let lhs_scalar = scalar.add(scalar.add(a, b), c);
        let rhs_scalar = scalar.add(a, scalar.add(b, c));
        prop_assert_eq!(lhs_scalar, rhs_scalar, "ScalarTarget add not associative");

        let lhs_backend = backend.add(backend.add(a, b), c);
        let rhs_backend = backend.add(a, backend.add(b, c));
        prop_assert_eq!(lhs_backend, rhs_backend, "BackendImpl add not associative");
    }

    /// Verify xor is associative: xor(xor(a, b), c) = xor(a, xor(b, c)).
    #[test]
    fn prop_xor_associative_u32(a in any::<u32>(), b in any::<u32>(), c in any::<u32>()) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        let lhs_scalar = scalar.xor(scalar.xor(a, b), c);
        let rhs_scalar = scalar.xor(a, scalar.xor(b, c));
        prop_assert_eq!(lhs_scalar, rhs_scalar, "ScalarTarget xor not associative");

        let lhs_backend = backend.xor(backend.xor(a, b), c);
        let rhs_backend = backend.xor(a, backend.xor(b, c));
        prop_assert_eq!(lhs_backend, rhs_backend, "BackendImpl xor not associative");
    }
}

// =============================================================================
// Categorical Operation Verification
// =============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(500))]

    /// Verify operations preserve consistency for ring-relevant values (mod 96).
    #[test]
    fn prop_ring_consistency_u32(x in 0u32..96, y in 0u32..96) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        // Ring add: (x + y) mod 96
        let scalar_add = scalar.add(x, y) % 96;
        let backend_add = backend.add(x, y) % 96;
        let expected_add = (x + y) % 96;

        prop_assert_eq!(scalar_add, expected_add, "ScalarTarget ring add mismatch");
        prop_assert_eq!(backend_add, expected_add, "BackendImpl ring add mismatch");
        prop_assert_eq!(scalar_add, backend_add, "Cross-backend ring add mismatch");

        // Ring sub: (x - y + 96) mod 96
        let scalar_sub = (scalar.sub(x, y).wrapping_add(96)) % 96;
        let backend_sub = (backend.sub(x, y).wrapping_add(96)) % 96;
        // For x >= y, this is (x - y) % 96; for x < y, wrapping behavior applies
        let expected_sub = if x >= y { (x - y) % 96 } else { (96 - (y - x)) % 96 };

        prop_assert_eq!(scalar_sub, expected_sub, "ScalarTarget ring sub mismatch");
        prop_assert_eq!(backend_sub, expected_sub, "BackendImpl ring sub mismatch");
        prop_assert_eq!(scalar_sub, backend_sub, "Cross-backend ring sub mismatch");
    }

    /// Verify inc/dec preserve ring structure for values in [0, 95].
    #[test]
    fn prop_ring_inc_dec_u32(x in 0u32..96) {
        let scalar = ScalarTarget::new();
        let backend = BackendImpl::auto_select();

        // Ring inc: (x + 1) mod 96
        let scalar_inc = scalar.inc(x) % 96;
        let backend_inc = backend.inc(x) % 96;
        let expected_inc = (x + 1) % 96;

        prop_assert_eq!(scalar_inc, expected_inc, "ScalarTarget ring inc mismatch");
        prop_assert_eq!(backend_inc, expected_inc, "BackendImpl ring inc mismatch");
        prop_assert_eq!(scalar_inc, backend_inc, "Cross-backend ring inc mismatch");

        // Ring dec: (x - 1 + 96) mod 96
        let scalar_dec = scalar.dec(x).wrapping_add(96) % 96;
        let backend_dec = backend.dec(x).wrapping_add(96) % 96;
        let expected_dec = (x + 95) % 96; // (x - 1 + 96) mod 96

        prop_assert_eq!(scalar_dec, expected_dec, "ScalarTarget ring dec mismatch");
        prop_assert_eq!(backend_dec, expected_dec, "BackendImpl ring dec mismatch");
        prop_assert_eq!(scalar_dec, backend_dec, "Cross-backend ring dec mismatch");
    }
}

// =============================================================================
// Edge Case Tests (Non-proptest)
// =============================================================================

#[test]
fn test_edge_cases_u32_boundaries() {
    let scalar = ScalarTarget::new();
    let simd128 = Simd128Target::new();
    let simd256 = Simd256Target::new();
    let backend = BackendImpl::auto_select();

    // Test boundary values
    let boundaries = [0u32, 1, u32::MAX - 1, u32::MAX];

    for &x in &boundaries {
        // inc
        let expected_inc = x.wrapping_add(1);
        assert_eq!(scalar.inc(x), expected_inc, "scalar inc({x})");
        assert_eq!(backend.inc(x), expected_inc, "backend inc({x})");

        // dec
        let expected_dec = x.wrapping_sub(1);
        assert_eq!(scalar.dec(x), expected_dec, "scalar dec({x})");
        assert_eq!(backend.dec(x), expected_dec, "backend dec({x})");

        for &y in &boundaries {
            // add
            let expected_add = x.wrapping_add(y);
            assert_eq!(scalar.add(x, y), expected_add, "scalar add({x}, {y})");
            assert_eq!(backend.add(x, y), expected_add, "backend add({x}, {y})");

            // sub
            let expected_sub = x.wrapping_sub(y);
            assert_eq!(scalar.sub(x, y), expected_sub, "scalar sub({x}, {y})");
            assert_eq!(backend.sub(x, y), expected_sub, "backend sub({x}, {y})");
        }
    }

    // Test SIMD boundaries
    let arr4: [u32; 4] = [0, 1, u32::MAX - 1, u32::MAX];
    let arr8: [u32; 8] = [0, 1, 2, u32::MAX - 2, u32::MAX - 1, u32::MAX, 42, 96];

    // simd128 inc
    let simd128_inc = simd128.inc(arr4);
    let backend_inc4 = backend.inc(arr4);
    for i in 0..4 {
        assert_eq!(simd128_inc[i], arr4[i].wrapping_add(1), "simd128 inc[{i}]");
        assert_eq!(
            backend_inc4[i],
            arr4[i].wrapping_add(1),
            "backend inc4[{i}]"
        );
    }

    // simd256 inc
    let simd256_inc = simd256.inc(arr8);
    let backend_inc8 = backend.inc(arr8);
    for i in 0..8 {
        assert_eq!(simd256_inc[i], arr8[i].wrapping_add(1), "simd256 inc[{i}]");
        assert_eq!(
            backend_inc8[i],
            arr8[i].wrapping_add(1),
            "backend inc8[{i}]"
        );
    }
}

#[test]
fn test_edge_cases_overflow_patterns() {
    let scalar = ScalarTarget::new();
    let backend = BackendImpl::auto_select();

    // Test specific overflow patterns
    let patterns = [
        (u32::MAX, 1u32, 0u32),             // MAX + 1 = 0
        (u32::MAX, u32::MAX, u32::MAX - 1), // MAX + MAX = MAX - 1 (with wrap)
        (0u32, 0u32, 0u32),                 // 0 + 0 = 0
        (0x8000_0000, 0x8000_0000, 0u32),   // MSB + MSB = 0 (with wrap)
    ];

    for (a, b, expected) in patterns {
        assert_eq!(scalar.add(a, b), expected, "scalar add({a}, {b})");
        assert_eq!(backend.add(a, b), expected, "backend add({a}, {b})");
    }
}

#[test]
fn test_cross_target_consistency() {
    // Verify all targets produce the same results for the same inputs
    let scalar = ScalarTarget::new();
    let simd128 = Simd128Target::new();
    let simd256 = Simd256Target::new();
    let backend = BackendImpl::auto_select();

    let test_values = [0u32, 1, 42, 96, 255, 1000, u32::MAX / 2, u32::MAX];

    for &a in &test_values {
        for &b in &test_values {
            // Scalar results
            let scalar_add = scalar.add(a, b);
            let scalar_sub = scalar.sub(a, b);

            // Backend results
            let backend_add = backend.add(a, b);
            let backend_sub = backend.sub(a, b);

            assert_eq!(
                scalar_add, backend_add,
                "add({a}, {b}) mismatch scalar vs backend"
            );
            assert_eq!(
                scalar_sub, backend_sub,
                "sub({a}, {b}) mismatch scalar vs backend"
            );

            // SIMD-128 (element 0)
            let arr4_a = [a, a, a, a];
            let arr4_b = [b, b, b, b];
            let simd128_add = simd128.add(arr4_a, arr4_b);
            let simd128_sub = simd128.sub(arr4_a, arr4_b);

            assert_eq!(
                simd128_add[0], scalar_add,
                "simd128 add({a}, {b})[0] mismatch"
            );
            assert_eq!(
                simd128_sub[0], scalar_sub,
                "simd128 sub({a}, {b})[0] mismatch"
            );

            // SIMD-256 (element 0)
            let arr8_a = [a; 8];
            let arr8_b = [b; 8];
            let simd256_add = simd256.add(arr8_a, arr8_b);
            let simd256_sub = simd256.sub(arr8_a, arr8_b);

            assert_eq!(
                simd256_add[0], scalar_add,
                "simd256 add({a}, {b})[0] mismatch"
            );
            assert_eq!(
                simd256_sub[0], scalar_sub,
                "simd256 sub({a}, {b})[0] mismatch"
            );
        }
    }
}
