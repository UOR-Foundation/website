//! Vocabulary management for tokenizers.
//!
//! Handles loading vocabulary from tokenizer.json files (HuggingFace format)
//! and provides efficient token ID ↔ string lookups.

use std::collections::HashMap;

use serde::Deserialize;

use crate::{Result, SpecialTokens};

/// A vocabulary entry with ID and score.
#[derive(Debug, Clone)]
pub struct VocabEntry {
    /// Token string.
    pub token: String,
    /// Token ID (index in vocabulary).
    pub id: u32,
    /// Token score (log probability for Unigram).
    pub score: f32,
    /// Whether this is a special token.
    pub is_special: bool,
}

/// Vocabulary for tokenization.
#[derive(Debug, Clone)]
pub struct Vocabulary {
    /// Token string → ID mapping.
    token_to_id: HashMap<String, u32>,
    /// ID → Token string mapping.
    id_to_token: HashMap<u32, String>,
    /// Token → score mapping.
    token_scores: HashMap<String, f32>,
    /// Special tokens.
    pub special_tokens: SpecialTokens,
    /// Vocabulary size.
    pub size: usize,
}

impl Vocabulary {
    /// Create a new vocabulary from entries.
    pub fn new(entries: Vec<VocabEntry>, special_tokens: SpecialTokens) -> Self {
        let size = entries.len();
        let mut token_to_id = HashMap::with_capacity(size);
        let mut id_to_token = HashMap::with_capacity(size);
        let mut token_scores = HashMap::with_capacity(size);

        for entry in entries {
            token_to_id.insert(entry.token.clone(), entry.id);
            id_to_token.insert(entry.id, entry.token.clone());
            token_scores.insert(entry.token, entry.score);
        }

        Self {
            token_to_id,
            id_to_token,
            token_scores,
            special_tokens,
            size,
        }
    }

    /// Load vocabulary from a tokenizer.json file.
    pub fn from_json(json: &str) -> Result<Self> {
        let config: TokenizerJson = serde_json::from_str(json)?;
        Self::from_tokenizer_json(config)
    }

    /// Load vocabulary from parsed tokenizer.json.
    fn from_tokenizer_json(config: TokenizerJson) -> Result<Self> {
        let mut entries = Vec::new();
        let mut special_tokens = SpecialTokens::default();

        // Parse vocabulary based on format
        match &config.model.vocab {
            VocabFormat::Object(map) => {
                // Format: { "token": id, ... }
                for (token, &id) in map {
                    entries.push(VocabEntry {
                        token: token.clone(),
                        id,
                        score: 0.0, // No scores in object format
                        is_special: false,
                    });
                }
            }
            VocabFormat::Array(arr) => {
                // Format: [["token", score], ...]
                for (id, (token, score)) in arr.iter().enumerate() {
                    entries.push(VocabEntry {
                        token: token.clone(),
                        id: id as u32,
                        score: *score,
                        is_special: false,
                    });
                }
            }
        }

        // Parse added tokens (special tokens)
        if let Some(added) = &config.added_tokens {
            for added_token in added {
                // Update special tokens
                match added_token.content.as_str() {
                    "<pad>" | "[PAD]" => special_tokens.pad = added_token.id,
                    "</s>" | "<eos>" | "[SEP]" => special_tokens.eos = added_token.id,
                    "<unk>" | "[UNK]" => special_tokens.unk = added_token.id,
                    "<s>" | "<bos>" | "[CLS]" => special_tokens.bos = Some(added_token.id),
                    _ => {}
                }

                // Check if this token already exists
                let existing_idx = entries.iter().position(|e| e.token == added_token.content);
                if let Some(idx) = existing_idx {
                    entries[idx].is_special = added_token.special;
                } else {
                    // Add new special token
                    entries.push(VocabEntry {
                        token: added_token.content.clone(),
                        id: added_token.id,
                        score: 0.0,
                        is_special: added_token.special,
                    });
                }
            }
        }

        Ok(Self::new(entries, special_tokens))
    }

    /// Get token ID for a string.
    pub fn get_id(&self, token: &str) -> Option<u32> {
        self.token_to_id.get(token).copied()
    }

    /// Get string for a token ID.
    pub fn get_token(&self, id: u32) -> Option<&str> {
        self.id_to_token.get(&id).map(|s| s.as_str())
    }

    /// Get score for a token.
    pub fn get_score(&self, token: &str) -> Option<f32> {
        self.token_scores.get(token).copied()
    }

    /// Get score for a token ID.
    pub fn get_score_by_id(&self, id: u32) -> Option<f32> {
        self.id_to_token
            .get(&id)
            .and_then(|token| self.token_scores.get(token).copied())
    }

    /// Check if a token exists in the vocabulary.
    pub fn contains(&self, token: &str) -> bool {
        self.token_to_id.contains_key(token)
    }

    /// Get the unknown token ID.
    pub fn unk_id(&self) -> u32 {
        self.special_tokens.unk
    }

    /// Iterate over all entries.
    pub fn iter(&self) -> impl Iterator<Item = (&str, u32, f32)> + '_ {
        self.token_to_id.iter().map(|(token, &id)| {
            let score = self.token_scores.get(token).copied().unwrap_or(0.0);
            (token.as_str(), id, score)
        })
    }
}

// Tokenizer.json parsing structures

#[derive(Debug, Deserialize)]
struct TokenizerJson {
    model: ModelConfig,
    added_tokens: Option<Vec<AddedToken>>,
}

#[derive(Debug, Deserialize)]
struct ModelConfig {
    vocab: VocabFormat,
}

#[derive(Debug, Deserialize)]
#[serde(untagged)]
enum VocabFormat {
    Object(HashMap<String, u32>),
    Array(Vec<(String, f32)>),
}

#[derive(Debug, Deserialize)]
struct AddedToken {
    id: u32,
    content: String,
    #[serde(default)]
    special: bool,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_vocab() -> Vocabulary {
        let entries = vec![
            VocabEntry {
                token: "<pad>".to_string(),
                id: 0,
                score: 0.0,
                is_special: true,
            },
            VocabEntry {
                token: "</s>".to_string(),
                id: 1,
                score: 0.0,
                is_special: true,
            },
            VocabEntry {
                token: "<unk>".to_string(),
                id: 2,
                score: 0.0,
                is_special: true,
            },
            VocabEntry {
                token: "hello".to_string(),
                id: 3,
                score: -1.0,
                is_special: false,
            },
            VocabEntry {
                token: "world".to_string(),
                id: 4,
                score: -1.5,
                is_special: false,
            },
            VocabEntry {
                token: "\u{2581}".to_string(),
                id: 5,
                score: -0.5,
                is_special: false,
            },
        ];
        Vocabulary::new(entries, SpecialTokens::default())
    }

    #[test]
    fn test_vocab_new() {
        let vocab = sample_vocab();
        assert_eq!(vocab.size, 6);
    }

    #[test]
    fn test_vocab_get_id() {
        let vocab = sample_vocab();
        assert_eq!(vocab.get_id("hello"), Some(3));
        assert_eq!(vocab.get_id("world"), Some(4));
        assert_eq!(vocab.get_id("missing"), None);
    }

    #[test]
    fn test_vocab_get_token() {
        let vocab = sample_vocab();
        assert_eq!(vocab.get_token(3), Some("hello"));
        assert_eq!(vocab.get_token(4), Some("world"));
        assert_eq!(vocab.get_token(999), None);
    }

    #[test]
    fn test_vocab_get_score() {
        let vocab = sample_vocab();
        assert_eq!(vocab.get_score("hello"), Some(-1.0));
        assert_eq!(vocab.get_score("world"), Some(-1.5));
        assert_eq!(vocab.get_score("missing"), None);
    }

    #[test]
    fn test_vocab_get_score_by_id() {
        let vocab = sample_vocab();
        assert_eq!(vocab.get_score_by_id(3), Some(-1.0));
        assert_eq!(vocab.get_score_by_id(999), None);
    }

    #[test]
    fn test_vocab_contains() {
        let vocab = sample_vocab();
        assert!(vocab.contains("hello"));
        assert!(!vocab.contains("missing"));
    }

    #[test]
    fn test_vocab_special_tokens() {
        let vocab = sample_vocab();
        assert_eq!(vocab.special_tokens.pad, 0);
        assert_eq!(vocab.special_tokens.eos, 1);
        assert_eq!(vocab.special_tokens.unk, 2);
    }

    #[test]
    fn test_vocab_iter() {
        let vocab = sample_vocab();
        let entries: Vec<_> = vocab.iter().collect();
        assert_eq!(entries.len(), 6);
    }

    #[test]
    fn test_vocab_from_json_object_format() {
        let json = r#"{
            "model": {
                "vocab": {
                    "<pad>": 0,
                    "</s>": 1,
                    "hello": 2
                }
            },
            "added_tokens": [
                {"id": 0, "content": "<pad>", "special": true},
                {"id": 1, "content": "</s>", "special": true}
            ]
        }"#;

        let vocab = Vocabulary::from_json(json).unwrap();
        assert_eq!(vocab.size, 3);
        assert_eq!(vocab.get_id("<pad>"), Some(0));
        assert_eq!(vocab.special_tokens.pad, 0);
        assert_eq!(vocab.special_tokens.eos, 1);
    }

    #[test]
    fn test_vocab_from_json_array_format() {
        let json = r#"{
            "model": {
                "vocab": [
                    ["<pad>", 0.0],
                    ["</s>", 0.0],
                    ["hello", -1.0],
                    ["world", -1.5]
                ]
            }
        }"#;

        let vocab = Vocabulary::from_json(json).unwrap();
        assert_eq!(vocab.size, 4);
        assert_eq!(vocab.get_id("hello"), Some(2));
        assert_eq!(vocab.get_score("hello"), Some(-1.0));
    }

    #[test]
    fn test_vocab_unicode() {
        let vocab = sample_vocab();
        // SentencePiece underscore
        assert_eq!(vocab.get_id("\u{2581}"), Some(5));
    }

    #[test]
    fn test_vocab_unk_id() {
        let vocab = sample_vocab();
        assert_eq!(vocab.unk_id(), 2);
    }
}
