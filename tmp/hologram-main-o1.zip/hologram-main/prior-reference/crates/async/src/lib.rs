//! # hologram-async
//!
//! Async/await support for I/O-bound Hologram operations.

#![warn(clippy::all)]

pub mod buffer;
pub mod executor;
pub mod loader;
#[cfg(feature = "registry")]
pub mod registry;
pub mod runtime;
pub mod stream;

pub use buffer::AsyncBuffer;
pub use executor::AsyncExecutor;
pub use loader::{AsyncLoader, LoadProgress, LoadStage};
#[cfg(feature = "registry")]
pub use registry::{AsyncRegistry, SearchResult};
pub use runtime::{create_runtime, global_runtime, RuntimeConfig};
pub use stream::{execute_stream, ExecutionStream};

pub use error::AsyncError;

/// Error types for async operations.
pub mod error {
    use std::fmt;

    /// Error type for async hologram operations.
    #[derive(Debug)]
    pub enum AsyncError {
        Io(std::io::Error),
        Join(String),
        Backend(hologram_core::BackendError),
        Registry(String),
        Manifest(String),
        Timeout,
        Cancelled,
        #[cfg(feature = "registry")]
        Network(String),
        #[cfg(feature = "registry")]
        Http(u16, String),
        Other(String),
    }

    impl fmt::Display for AsyncError {
        fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
            match self {
                AsyncError::Io(e) => write!(f, "IO error: {}", e),
                AsyncError::Join(msg) => write!(f, "task join error: {}", msg),
                AsyncError::Backend(e) => write!(f, "backend error: {}", e),
                AsyncError::Registry(msg) => write!(f, "registry error: {}", msg),
                AsyncError::Manifest(msg) => write!(f, "manifest error: {}", msg),
                AsyncError::Timeout => write!(f, "operation timed out"),
                AsyncError::Cancelled => write!(f, "operation cancelled"),
                #[cfg(feature = "registry")]
                AsyncError::Network(msg) => write!(f, "network error: {}", msg),
                #[cfg(feature = "registry")]
                AsyncError::Http(code, msg) => write!(f, "HTTP error {}: {}", code, msg),
                AsyncError::Other(msg) => write!(f, "{}", msg),
            }
        }
    }

    impl std::error::Error for AsyncError {
        fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
            match self {
                AsyncError::Io(e) => Some(e),
                AsyncError::Backend(e) => Some(e),
                _ => None,
            }
        }
    }

    impl From<std::io::Error> for AsyncError {
        fn from(err: std::io::Error) -> Self {
            AsyncError::Io(err)
        }
    }

    impl From<hologram_core::BackendError> for AsyncError {
        fn from(err: hologram_core::BackendError) -> Self {
            AsyncError::Backend(err)
        }
    }

    impl From<tokio::task::JoinError> for AsyncError {
        fn from(err: tokio::task::JoinError) -> Self {
            AsyncError::Join(err.to_string())
        }
    }

    impl From<toml::de::Error> for AsyncError {
        fn from(err: toml::de::Error) -> Self {
            AsyncError::Manifest(err.to_string())
        }
    }

    #[cfg(feature = "registry")]
    impl From<reqwest::Error> for AsyncError {
        fn from(err: reqwest::Error) -> Self {
            AsyncError::Network(err.to_string())
        }
    }
}

/// Result type alias for async operations.
pub type Result<T> = std::result::Result<T, AsyncError>;

#[cfg(test)]
mod tests {
    use super::*;
    use std::error::Error;

    #[test]
    fn test_async_error_display() {
        let err = AsyncError::Timeout;
        assert!(err.to_string().contains("timed out"));

        let err = AsyncError::Cancelled;
        assert!(err.to_string().contains("cancelled"));

        let err = AsyncError::Other("test error".to_string());
        assert!(err.to_string().contains("test error"));
    }

    #[test]
    fn test_async_error_from_io() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "file not found");
        let async_err = AsyncError::from(io_err);
        assert!(matches!(async_err, AsyncError::Io(_)));
    }

    #[test]
    fn test_async_error_source() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "file not found");
        let async_err = AsyncError::from(io_err);
        assert!(async_err.source().is_some());

        let other_err = AsyncError::Timeout;
        assert!(other_err.source().is_none());
    }

    #[test]
    fn test_result_type_alias() {
        let ok_result: Result<i32> = Ok(42);
        assert!(ok_result.is_ok());
        assert_eq!(ok_result.ok(), Some(42));

        let err_result: Result<i32> = Err(AsyncError::Timeout);
        assert!(err_result.is_err());
    }
}
