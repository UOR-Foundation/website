//! SHA-256 compression function.
//!
//! Delegates to UOR wavefront SHA-256 programs via the appropriate
//! executor for the current architecture.
//!
//! ```
//! use prism::state::State;
//! use prism::programs::sha256::sha256_compress;
//!
//! let mut s = State::zeros();
//! sha256_compress(&mut s);
//! // State has been transformed by 64 rounds of SHA-256 compression
//! ```

use crate::state::State;
use uor::UorStep;

/// Execute the SHA-256 compression function (64 rounds).
///
/// Uses `ScalarExecutor` on all architectures (portable fallback).
/// On `x86_64` with AVX2/SHA-NI/AES-NI, uses the `Zen3Executor`
/// for hardware-accelerated execution.
///
/// ```
/// use prism::state::State;
/// use prism::programs::sha256::sha256_compress;
///
/// let mut s = State::from_bytes(&[0xAB; 624]);
/// sha256_compress(&mut s);
/// ```
pub fn sha256_compress(state: &mut State) {
    let program = uor::wavefront::sha256_compress_program();
    run_program(state, &program);
}

#[cfg(target_arch = "x86_64")]
fn run_program(state: &mut State, program: &[uor::Wavefront]) {
    if let Some(executor) = try_zen3() {
        unsafe { executor.run(state.inner_mut(), program) };
    } else {
        let executor = uor::ScalarExecutor::new();
        unsafe { executor.run(state.inner_mut(), program) };
    }
}

#[cfg(not(target_arch = "x86_64"))]
fn run_program(state: &mut State, program: &[uor::Wavefront]) {
    let executor = uor::ScalarExecutor::new();
    unsafe { executor.run(state.inner_mut(), program) };
}

#[cfg(target_arch = "x86_64")]
fn try_zen3() -> Option<uor::Zen3Executor> {
    if std::is_x86_feature_detected!("avx2")
        && std::is_x86_feature_detected!("sha")
        && std::is_x86_feature_detected!("aes")
    {
        Some(uor::Zen3Executor::new())
    } else {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sha256_compress_runs() {
        let mut s = State::zeros();
        sha256_compress(&mut s);
        // ScalarExecutor is a stub, so state may not change on non-x86_64.
        // Test verifies no panic.
    }

    #[test]
    fn test_sha256_compress_from_data() {
        let mut s = State::from_bytes(&[0xDE; 624]);
        sha256_compress(&mut s);
    }
}
