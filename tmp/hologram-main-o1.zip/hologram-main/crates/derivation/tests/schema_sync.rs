//! Schema sync tests verify that Rust types match JSON-LD schema expectations.
//!
//! These tests ensure that:
//! 1. ToJsonLd implementations produce the expected @type values
//! 2. Required fields are present in JSON-LD output
//! 3. StepKind variants match the SHACL sh:in list

use hologram_derivation::{
    DerivationChain, DerivationStep, FactorizationResult, StepKind, ToJsonLd,
};
use uor::observable::{CascadeSpectrum, MonodromySignature, TotalVariation, WindingNumber};

/// All StepKind variants that should be in the SHACL sh:in list
const VALID_STEP_KINDS: &[&str] = &[
    "type_declaration",
    "quantum_selection",
    "step_prediction",
    "orbit_generation",
    "coordinate_reading",
    "factor_completion",
    "certificate_emission",
    "gcd",
    "integer_division",
    "compute",
];

#[test]
fn step_kind_values_match_shacl_schema() {
    // Verify all StepKind variants produce valid SHACL values
    let all_kinds = [
        StepKind::TypeDeclaration,
        StepKind::QuantumSelection,
        StepKind::StepPrediction,
        StepKind::OrbitGeneration,
        StepKind::CoordinateReading,
        StepKind::FactorCompletion,
        StepKind::CertificateEmission,
        StepKind::Gcd,
        StepKind::IntegerDivision,
        StepKind::Compute,
    ];

    for kind in &all_kinds {
        let str_val = kind.as_str();
        assert!(
            VALID_STEP_KINDS.contains(&str_val),
            "StepKind::{:?} produces '{}' which is not in SHACL sh:in list",
            kind,
            str_val
        );
    }
}

#[test]
fn derivation_step_has_required_fields() {
    let step = DerivationStep::new(0, "Test Step", StepKind::Compute)
        .with_input(serde_json::json!({"x": 1}))
        .with_output(serde_json::json!({"y": 2}));

    let json = step.to_jsonld();

    // Fields required by SHACL derivation:DerivationStepShape
    assert!(json.get("@type").is_some(), "Missing @type");
    assert!(json.get("derivation:index").is_some(), "Missing index");
    assert!(json.get("rdfs:label").is_some(), "Missing label");
    assert!(json.get("derivation:kind").is_some(), "Missing kind");
    assert!(json.get("derivation:input").is_some(), "Missing input");
    assert!(json.get("derivation:output").is_some(), "Missing output");

    // Verify @type value
    assert_eq!(json["@type"], "derivation:DerivationStep");
}

#[test]
fn derivation_chain_has_required_fields() {
    let mut chain = DerivationChain::new("https://test/chain/1", "Test Chain")
        .with_description("A test chain")
        .with_timestamp("2026-02-05T00:00:00Z");

    chain.add_step(DerivationStep::new(0, "Step 0", StepKind::TypeDeclaration));

    let json = chain.to_jsonld();

    // Fields required by SHACL derivation:DerivationChainShape
    assert!(json.get("@type").is_some(), "Missing @type");
    assert!(json.get("rdfs:label").is_some(), "Missing label");
    assert!(
        json.get("derivation:timestamp").is_some(),
        "Missing timestamp"
    );
    assert!(
        json.get("derivation:stepCount").is_some(),
        "Missing stepCount"
    );
    assert!(json.get("derivation:steps").is_some(), "Missing steps");

    // Verify @type value
    assert_eq!(json["@type"], "derivation:DerivationChain");
}

#[test]
fn factorization_result_has_required_fields() {
    let result = FactorizationResult {
        n: 10403,
        p: 101,
        q: 103,
        k: 32,
        i: 33,
        v: 4294956926,
    };

    let json = result.to_jsonld();

    // Fields required by SHACL derivation:FactorizationResultShape
    assert!(json.get("@type").is_some(), "Missing @type");
    assert!(
        json.get("derivation:semiprime").is_some(),
        "Missing semiprime"
    );
    assert!(
        json.get("derivation:factor_p").is_some(),
        "Missing factor_p"
    );
    assert!(
        json.get("derivation:factor_q").is_some(),
        "Missing factor_q"
    );
    assert!(json.get("derivation:quantum").is_some(), "Missing quantum");
    assert!(
        json.get("derivation:verified").is_some(),
        "Missing verified"
    );

    // Verify @type value and verified = true
    assert_eq!(json["@type"], "derivation:FactorizationResult");
    assert_eq!(json["derivation:verified"], true);
}

#[test]
fn winding_number_has_required_fields() {
    let w = WindingNumber { value: 42 };
    let json = w.to_jsonld();

    // Fields required by SHACL observable:WindingNumberShape
    assert!(json.get("@type").is_some(), "Missing @type");
    assert!(json.get("observable:value").is_some(), "Missing value");

    assert_eq!(json["@type"], "observable:WindingNumber");
}

#[test]
fn total_variation_has_required_fields() {
    let tv = TotalVariation { value: 100 };
    let json = tv.to_jsonld();

    // Fields required by SHACL observable:TotalVariationShape
    assert!(json.get("@type").is_some(), "Missing @type");
    assert!(json.get("observable:value").is_some(), "Missing value");

    assert_eq!(json["@type"], "observable:TotalVariation");
}

#[test]
fn cascade_spectrum_has_required_fields() {
    let cs = CascadeSpectrum {
        bins: vec![128, 64, 32, 16, 8, 4, 2, 1],
    };
    let json = cs.to_jsonld();

    // Fields required by SHACL observable:CascadeSpectrumShape
    assert!(json.get("@type").is_some(), "Missing @type");
    assert!(json.get("observable:bins").is_some(), "Missing bins");

    assert_eq!(json["@type"], "observable:CascadeSpectrum");
}

#[test]
fn monodromy_signature_has_required_fields() {
    let sig = MonodromySignature {
        winding: 1,
        total_variation: 256,
        cascade_spectrum: vec![128, 64, 32, 16, 8, 4, 2, 1],
    };
    let json = sig.to_jsonld();

    // Fields required by SHACL observable:MonodromySignatureShape
    assert!(json.get("@type").is_some(), "Missing @type");
    assert!(json.get("observable:winding").is_some(), "Missing winding");
    assert!(
        json.get("observable:totalVariation").is_some(),
        "Missing totalVariation"
    );
    assert!(
        json.get("observable:cascadeSpectrum").is_some(),
        "Missing cascadeSpectrum"
    );

    assert_eq!(json["@type"], "observable:MonodromySignature");
}

#[test]
fn all_jsonld_types_use_correct_namespace() {
    // Derivation types should use "derivation:" prefix
    assert!(DerivationStep::jsonld_type().starts_with("derivation:"));
    assert!(DerivationChain::jsonld_type().starts_with("derivation:"));
    assert!(FactorizationResult::jsonld_type().starts_with("derivation:"));

    // Observable types should use "observable:" prefix
    assert!(WindingNumber::jsonld_type().starts_with("observable:"));
    assert!(TotalVariation::jsonld_type().starts_with("observable:"));
    assert!(CascadeSpectrum::jsonld_type().starts_with("observable:"));
    assert!(MonodromySignature::jsonld_type().starts_with("observable:"));
}
