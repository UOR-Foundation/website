//! Backend trait system and implementations for Hologram.
//!
//! This crate provides the backend abstraction layer with:
//! - Core traits: [`ProgramBackend`], [`ComputeBackend`]
//! - Built-in backends: CPU backend as reference implementation
//! - Feature-gated backends: Metal, CUDA, WebGPU as optional features
//!
//! # Overview
//!
//! The backend system provides an abstraction layer between compiled ISA programs
//! and hardware execution. This enables a "write-once, run-anywhere" model where
//! code compiles to ISA once and executes on any available backend.
//!
//! # Features
//!
//! - `cpu` (default): CPU backend, always available
//! - `metal`: Metal GPU backend for macOS
//! - `cuda`: CUDA GPU backend for NVIDIA GPUs
//! - `webgpu`: WebGPU backend for cross-platform GPU compute
//!
//! # Example
//!
//! ```rust
//! use hologram_backend::{create_best_backend, ProgramBackend, LaunchConfig};
//!
//! // Create the best available backend
//! let mut backend = create_best_backend();
//!
//! // Allocate a buffer
//! let handle = backend.allocate_buffer(1024).unwrap();
//!
//! // Copy data to the buffer
//! let data = vec![1u8, 2, 3, 4];
//! backend.copy_to_buffer(handle, &data).unwrap();
//!
//! // Clean up
//! backend.free_buffer(handle).unwrap();
//! ```

#![deny(missing_docs)]
#![warn(clippy::all)]

pub mod backends;
pub mod core;
pub mod providers;

// Re-export core modules at the crate root for compatibility.
#[cfg(feature = "alloc-tracking")]
pub use core::alloc_tracker;
pub use core::{
    capabilities, common_ops, const_provider, detect, epilogue, error, executor, handle, layout,
    plan, streaming_executor, threading, traits, transform_cache, view,
};

/// CPU backend module (always available).
pub use backends::cpu;

/// WebAssembly backend module.
pub use backends::wasm;

/// Metal backend module (macOS only, feature-gated).
#[cfg(all(target_os = "macos", feature = "metal"))]
pub use backends::metal;

/// CUDA backend module (NVIDIA GPUs, feature-gated).
#[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
pub use backends::cuda;

/// WebGPU backend module (cross-platform, feature-gated).
#[cfg(feature = "webgpu")]
pub use backends::webgpu;

// Re-exports for convenience
pub use detect::{create_backend, create_best_backend, detect_best_backend};
pub use error::{BackendError, BackendResult};
pub use handle::{BufferDescriptor, BufferHandle, BufferUsage, LaunchConfig};
pub use traits::{
    AspectAwareMatMulParams, BackendType, ComputeBackend, Conv2DParams, DepthwiseConv2DParams,
    GemmAspectHint, GroupedConv2DParams, MatMulParams, PointwiseConvParams, ProgramBackend,
    TensorLayout,
};

// Re-export capabilities types
pub use capabilities::{
    AlgorithmSupport, BackendCapabilities, ConvMode, MemoryLayout, WorkspaceOwnership,
};

// Re-export plan types
pub use plan::{
    // Global dynamic kernel table
    dynamic_kernel_table,
    BackendContext,
    BackendPlan,
    BufferRef,
    // Dynamic kernel support
    DynamicKernelTable,
    // Dynamic workspace types
    DynamicWorkspaceHandle,
    EpilogueChain,
    EpilogueOp,
    KernelFn,
    KernelId,
    KernelParams,
    KernelTable,
    LayoutMetadata,
    LookupTables,
    // Partition types for distributed execution (Phase 7C)
    PartitionIO,
    PartitionStrategy,
    PartitionedPlan,
    PlanOp,
    PlanPartition,
    // Resolved workspace types
    ResolvedWorkspaceLayout,
    ResolvedWorkspaceRegion,
    // Serializable types for .holo format
    SerializableBackendPlan,
    SerializableKernelInfo,
    SerializablePlanOp,
    ThreadPartition,
    TileParams,
    WorkRange,
    WorkspaceHandle,
    WorkspaceLayout,
    WorkspaceRegion,
    // Workspace size expressions for dynamic allocation
    WorkspaceSizeExpr,
    PLAN_FORMAT_VERSION,
};
pub use view::TensorView;

// Re-export layout types
pub use layout::{LayoutContract, LayoutPattern, LayoutPlanner, PackingStage, WinogradVariant};

// Re-export transform cache types
pub use transform_cache::{FilterId, PackedWeight, PrepackedFilter, TransformCache, WeightId};

// Re-export threading types
pub use threading::{PartitionBuilder, PartitionDimension, PartitionRequest, ThreadPartitioner};

// Re-export epilogue types
pub use epilogue::{EpilogueApply, EpilogueBatch, EpilogueBuilder, EpilogueMetadata};

// Re-export executor types
pub use executor::{BatchExecutor, ExecutionStats, ExecutorBuilder, PlanExecutor};

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_backend_type_is_gpu() {
        assert!(!BackendType::Cpu.is_gpu());
        assert!(!BackendType::Wasm.is_gpu());
        assert!(BackendType::Metal.is_gpu());
        assert!(BackendType::Cuda.is_gpu());
        assert!(BackendType::WebGpu.is_gpu());
    }

    #[test]
    fn test_detect_best_backend() {
        let backend = detect_best_backend();
        // The detected backend depends on enabled features
        // Just verify we get a valid backend type
        assert!(matches!(
            backend,
            BackendType::Cpu
                | BackendType::Wasm
                | BackendType::Metal
                | BackendType::Cuda
                | BackendType::WebGpu
        ));
    }

    #[test]
    fn test_create_cpu_backend() {
        let backend = create_backend(BackendType::Cpu);
        assert!(backend.is_ok());
    }

    #[test]
    fn test_exports_are_available() {
        // Verify all major types are exported
        let _: BackendType = BackendType::Cpu;
        let _: BufferHandle = BufferHandle::null();
        let _: LaunchConfig = LaunchConfig::new();
        let _: BufferDescriptor = BufferDescriptor::new(1024);
        let _: BufferUsage = BufferUsage::STORAGE;
    }

    #[test]
    fn test_cpu_backend_creation() {
        let backend = cpu::CpuBackend::new();
        assert_eq!(backend.backend_type(), BackendType::Cpu);
    }
}
