//! Error types for the tokenizer crate.

use thiserror::Error;

/// Result type for tokenizer operations.
pub type Result<T> = std::result::Result<T, TokenizerError>;

/// Errors that can occur during tokenization.
#[derive(Debug, Error)]
pub enum TokenizerError {
    /// Failed to parse tokenizer configuration.
    #[error("Failed to parse tokenizer config: {0}")]
    ConfigParse(String),

    /// Invalid UTF-8 in input.
    #[error("Invalid UTF-8 at byte offset {offset}: {message}")]
    InvalidUtf8 {
        /// Byte offset where error occurred.
        offset: usize,
        /// Error description.
        message: String,
    },

    /// Vocabulary error.
    #[error("Vocabulary error: {0}")]
    Vocabulary(String),

    /// Trie construction error.
    #[error("Trie error: {0}")]
    Trie(String),

    /// Serialization error.
    #[error("Serialization error: {0}")]
    Serialization(String),

    /// IO error.
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    /// JSON parsing error.
    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),

    /// Viterbi algorithm error.
    #[error("Viterbi error: {0}")]
    Viterbi(String),

    /// Hologram compiler error.
    #[error("Compiler error: {0}")]
    Compiler(String),
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_error_display() {
        let err = TokenizerError::InvalidUtf8 {
            offset: 10,
            message: "invalid byte sequence".to_string(),
        };
        assert!(err.to_string().contains("offset 10"));
    }

    #[test]
    fn test_io_error_conversion() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "file not found");
        let tok_err: TokenizerError = io_err.into();
        assert!(matches!(tok_err, TokenizerError::Io(_)));
    }
}
