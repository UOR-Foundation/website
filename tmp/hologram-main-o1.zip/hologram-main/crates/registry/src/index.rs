//! Name-to-hash index for layer resolution.

use std::collections::HashMap;
use std::fs::{self, File};
use std::io::{BufReader, BufWriter};
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::error::{RegistryError, Result};

/// Name-to-hash index for resolving named layer references.
///
/// The index maps layer names (with optional namespace and version) to their
/// content hashes. The format is:
/// - `name:version` -> hash (no namespace)
/// - `namespace/name:version` -> hash (with namespace)
///
/// # Persistence
///
/// The index is stored as a JSON file at `~/.hologram/registry/index/names.json`.
///
/// # Example
///
/// ```no_run
/// use hologram_registry::NameIndex;
/// use std::path::PathBuf;
///
/// let mut index = NameIndex::new();
///
/// // Register a layer
/// let hash = [0xab; 32];
/// index.register(None, "my-model", "v1.0", &hash);
///
/// // Look it up
/// let found = index.lookup(None, "my-model", "v1.0");
/// assert_eq!(found, Some(hash));
///
/// // Save to disk
/// index.save(&PathBuf::from("names.json")).unwrap();
/// ```
#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct NameIndex {
    /// Maps name keys to hex-encoded hashes.
    /// Key format: "namespace/name:version" or "name:version"
    entries: HashMap<String, String>,
}

impl NameIndex {
    /// Create a new empty index.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Load the index from a file.
    ///
    /// Returns an empty index if the file doesn't exist.
    ///
    /// # Errors
    ///
    /// Returns an error if the file exists but cannot be read or parsed.
    pub fn load(path: &Path) -> Result<Self> {
        if !path.exists() {
            return Ok(Self::new());
        }

        let file = File::open(path).map_err(|e| RegistryError::io(path, e))?;
        let reader = BufReader::new(file);
        let index: Self = serde_json::from_reader(reader)?;
        Ok(index)
    }

    /// Save the index to a file.
    ///
    /// Uses atomic write (temp file + rename) to prevent corruption.
    ///
    /// # Errors
    ///
    /// Returns an error if the file cannot be written.
    pub fn save(&self, path: &Path) -> Result<()> {
        // Ensure parent directory exists
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).map_err(|e| RegistryError::io(parent, e))?;
        }

        // Write to temp file
        let temp_path = path.with_extension("json.tmp");
        let file = File::create(&temp_path).map_err(|e| RegistryError::io(&temp_path, e))?;
        let writer = BufWriter::new(file);
        serde_json::to_writer_pretty(writer, self)?;

        // Atomic rename
        fs::rename(&temp_path, path).map_err(|e| RegistryError::io(path, e))?;
        Ok(())
    }

    /// Register a name -> hash mapping.
    ///
    /// Overwrites any existing mapping for the same name.
    pub fn register(
        &mut self,
        namespace: Option<&str>,
        name: &str,
        version: &str,
        hash: &[u8; 32],
    ) {
        let key = make_key(namespace, name, version);
        self.entries.insert(key, hex::encode(hash));
    }

    /// Look up a hash by name.
    ///
    /// Returns `None` if the name is not registered.
    #[must_use]
    pub fn lookup(&self, namespace: Option<&str>, name: &str, version: &str) -> Option<[u8; 32]> {
        let key = make_key(namespace, name, version);
        self.entries.get(&key).and_then(|hex| parse_hash(hex))
    }

    /// Remove a name mapping.
    ///
    /// Returns `true` if the mapping existed.
    pub fn unregister(&mut self, namespace: Option<&str>, name: &str, version: &str) -> bool {
        let key = make_key(namespace, name, version);
        self.entries.remove(&key).is_some()
    }

    /// Search for names matching a pattern.
    ///
    /// Returns (key, hash_hex) pairs where the key contains the pattern.
    /// Case-insensitive substring match.
    #[must_use]
    pub fn search(&self, pattern: &str) -> Vec<(&str, &str)> {
        let pattern_lower = pattern.to_lowercase();
        self.entries
            .iter()
            .filter(|(key, _)| key.to_lowercase().contains(&pattern_lower))
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect()
    }

    /// Get all entries as (key, hash_hex) pairs.
    #[must_use]
    pub fn entries(&self) -> Vec<(&str, &str)> {
        self.entries
            .iter()
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect()
    }

    /// Get the number of registered names.
    #[must_use]
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Check if the index is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Build a reverse lookup map: hash_hex -> Vec<name_keys>.
    #[must_use]
    pub fn reverse_lookup(&self) -> HashMap<&str, Vec<&str>> {
        let mut reverse: HashMap<&str, Vec<&str>> = HashMap::new();
        for (key, hash) in &self.entries {
            reverse.entry(hash.as_str()).or_default().push(key.as_str());
        }
        reverse
    }

    /// List all versions of a layer name.
    #[must_use]
    pub fn versions(&self, namespace: Option<&str>, name: &str) -> Vec<&str> {
        let prefix = match namespace {
            Some(ns) => format!("{ns}/{name}:"),
            None => format!("{name}:"),
        };

        self.entries
            .keys()
            .filter_map(|key| {
                if key.starts_with(&prefix) {
                    Some(key[prefix.len()..].as_ref())
                } else {
                    None
                }
            })
            .collect()
    }
}

/// Create a key from namespace, name, and version.
fn make_key(namespace: Option<&str>, name: &str, version: &str) -> String {
    match namespace {
        Some(ns) => format!("{ns}/{name}:{version}"),
        None => format!("{name}:{version}"),
    }
}

/// Parse a hex string to a 32-byte hash.
fn parse_hash(hex_str: &str) -> Option<[u8; 32]> {
    let bytes = hex::decode(hex_str).ok()?;
    bytes.try_into().ok()
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    #[test]
    fn test_new_empty() {
        let index = NameIndex::new();
        assert!(index.is_empty());
        assert_eq!(index.len(), 0);
    }

    #[test]
    fn test_register_and_lookup() {
        let mut index = NameIndex::new();
        let hash = [0xab; 32];

        index.register(None, "model", "v1", &hash);

        let found = index.lookup(None, "model", "v1");
        assert_eq!(found, Some(hash));
    }

    #[test]
    fn test_register_with_namespace() {
        let mut index = NameIndex::new();
        let hash = [0xcd; 32];

        index.register(Some("org"), "model", "v1", &hash);

        let found = index.lookup(Some("org"), "model", "v1");
        assert_eq!(found, Some(hash));

        // Without namespace should not find it
        let not_found = index.lookup(None, "model", "v1");
        assert!(not_found.is_none());
    }

    #[test]
    fn test_lookup_not_found() {
        let index = NameIndex::new();
        let found = index.lookup(None, "nonexistent", "v1");
        assert!(found.is_none());
    }

    #[test]
    fn test_overwrite() {
        let mut index = NameIndex::new();
        let hash1 = [0x11; 32];
        let hash2 = [0x22; 32];

        index.register(None, "model", "v1", &hash1);
        index.register(None, "model", "v1", &hash2);

        let found = index.lookup(None, "model", "v1");
        assert_eq!(found, Some(hash2));
        assert_eq!(index.len(), 1);
    }

    #[test]
    fn test_unregister() {
        let mut index = NameIndex::new();
        let hash = [0x33; 32];

        index.register(None, "model", "v1", &hash);
        assert!(!index.is_empty());

        let removed = index.unregister(None, "model", "v1");
        assert!(removed);
        assert!(index.is_empty());

        let removed_again = index.unregister(None, "model", "v1");
        assert!(!removed_again);
    }

    #[test]
    fn test_search() {
        let mut index = NameIndex::new();
        index.register(None, "bert-base", "v1", &[1; 32]);
        index.register(None, "bert-large", "v1", &[2; 32]);
        index.register(None, "gpt2", "v1", &[3; 32]);

        let results = index.search("bert");
        assert_eq!(results.len(), 2);

        let results = index.search("BERT"); // case insensitive
        assert_eq!(results.len(), 2);

        let results = index.search("gpt");
        assert_eq!(results.len(), 1);

        let results = index.search("nonexistent");
        assert!(results.is_empty());
    }

    #[test]
    fn test_entries() {
        let mut index = NameIndex::new();
        index.register(None, "a", "v1", &[1; 32]);
        index.register(None, "b", "v1", &[2; 32]);

        let entries = index.entries();
        assert_eq!(entries.len(), 2);
    }

    #[test]
    fn test_reverse_lookup() {
        let mut index = NameIndex::new();
        let hash = [0x44; 32];
        index.register(None, "model", "v1", &hash);
        index.register(None, "model", "latest", &hash); // Same hash

        let reverse = index.reverse_lookup();
        let hash_hex = hex::encode(hash);
        let names = reverse.get(hash_hex.as_str()).unwrap();

        assert_eq!(names.len(), 2);
    }

    #[test]
    fn test_versions() {
        let mut index = NameIndex::new();
        index.register(None, "model", "v1.0", &[1; 32]);
        index.register(None, "model", "v2.0", &[2; 32]);
        index.register(None, "model", "latest", &[3; 32]);
        index.register(None, "other", "v1.0", &[4; 32]);

        let versions = index.versions(None, "model");
        assert_eq!(versions.len(), 3);
        assert!(versions.contains(&"v1.0"));
        assert!(versions.contains(&"v2.0"));
        assert!(versions.contains(&"latest"));
    }

    #[test]
    fn test_versions_with_namespace() {
        let mut index = NameIndex::new();
        index.register(Some("org"), "model", "v1", &[1; 32]);
        index.register(Some("org"), "model", "v2", &[2; 32]);
        index.register(None, "model", "v1", &[3; 32]); // Different namespace

        let versions = index.versions(Some("org"), "model");
        assert_eq!(versions.len(), 2);
    }

    #[test]
    fn test_save_and_load() {
        let temp = TempDir::new().unwrap();
        let path = temp.path().join("names.json");

        let mut index = NameIndex::new();
        index.register(None, "model", "v1", &[0xab; 32]);
        index.register(Some("org"), "other", "v2", &[0xcd; 32]);
        index.save(&path).unwrap();

        let loaded = NameIndex::load(&path).unwrap();
        assert_eq!(loaded.len(), 2);
        assert_eq!(loaded.lookup(None, "model", "v1"), Some([0xab; 32]));
        assert_eq!(loaded.lookup(Some("org"), "other", "v2"), Some([0xcd; 32]));
    }

    #[test]
    fn test_load_nonexistent() {
        let temp = TempDir::new().unwrap();
        let path = temp.path().join("nonexistent.json");

        let index = NameIndex::load(&path).unwrap();
        assert!(index.is_empty());
    }

    #[test]
    fn test_make_key() {
        assert_eq!(make_key(None, "model", "v1"), "model:v1");
        assert_eq!(make_key(Some("org"), "model", "v1"), "org/model:v1");
    }

    #[test]
    fn test_parse_hash() {
        let valid = "ab".repeat(32);
        let hash = parse_hash(&valid);
        assert_eq!(hash, Some([0xab; 32]));

        let invalid = "not a hash";
        assert!(parse_hash(invalid).is_none());

        let wrong_len = "abcd";
        assert!(parse_hash(wrong_len).is_none());
    }

    #[test]
    fn test_serde_roundtrip() {
        let mut index = NameIndex::new();
        index.register(None, "a", "v1", &[1; 32]);
        index.register(Some("ns"), "b", "v2", &[2; 32]);

        let json = serde_json::to_string(&index).unwrap();
        let loaded: NameIndex = serde_json::from_str(&json).unwrap();

        assert_eq!(loaded.len(), 2);
        assert_eq!(loaded.lookup(None, "a", "v1"), Some([1; 32]));
        assert_eq!(loaded.lookup(Some("ns"), "b", "v2"), Some([2; 32]));
    }
}
