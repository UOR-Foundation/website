//! Operation graph nodes and types.

use std::collections::{HashMap, HashSet};

use serde::{Deserialize, Serialize};

use crate::error::CompileError;

/// Data type for tensors.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum DType {
    /// 32-bit floating point.
    F32,
    /// 64-bit floating point.
    F64,
    /// 8-bit signed integer.
    I8,
    /// 16-bit signed integer.
    I16,
    /// 32-bit signed integer.
    I32,
    /// 64-bit signed integer.
    I64,
    /// 8-bit unsigned integer.
    U8,
    /// 16-bit unsigned integer.
    U16,
    /// 32-bit unsigned integer.
    U32,
    /// 64-bit unsigned integer.
    U64,
    /// Boolean.
    Bool,
}

/// Padding mode for the Pad operation.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum PadMode {
    /// Fill with a constant value.
    #[default]
    Constant,
    /// Reflect values at the boundaries (mirrors the edge values).
    Reflect,
    /// Replicate the edge values.
    Edge,
}

/// Operation kind enumeration.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum OpKind {
    // Arithmetic operations
    /// Element-wise addition.
    Add,
    /// Element-wise subtraction.
    Sub,
    /// Element-wise multiplication.
    Mul,
    /// Element-wise division.
    Div,
    /// Element-wise square root.
    Sqrt,
    /// Element-wise natural logarithm.
    Log,
    /// Element-wise power: a^b.
    Pow,
    /// Element-wise exponential.
    Exp,
    /// Element-wise absolute value.
    Abs,
    /// Element-wise minimum.
    ElemMin,
    /// Element-wise maximum.
    ElemMax,

    // Comparison operations
    /// Element-wise greater than: a > b.
    Greater,
    /// Element-wise less than: a < b.
    Less,
    /// Element-wise less than or equal: a <= b.
    LessOrEqual,
    /// Element-wise greater than or equal: a >= b.
    GreaterOrEqual,

    // Conditional operations
    /// Conditional select: where(cond, x, y) = cond ? x : y.
    Where,

    // Activation functions
    /// Sigmoid activation.
    Sigmoid,
    /// Tanh activation.
    Tanh,
    /// `ReLU` activation.
    Relu,
    /// `GELU` activation.
    Gelu,
    /// `SiLU` (Swish) activation.
    Silu,
    /// Softmax activation over specified axis.
    ///
    /// Computes softmax with numerical stability (subtract max before exp).
    /// Default axis=-1 (last dimension) for transformer attention.
    Softmax {
        /// Axis along which to compute softmax (negative indexing supported).
        /// -1 means last axis, -2 means second to last, etc.
        axis: i32,
    },

    // Linear algebra
    /// Matrix multiplication.
    MatMul {
        /// M dimension (rows of A).
        m: usize,
        /// K dimension (columns of A / rows of B).
        k: usize,
        /// N dimension (columns of B).
        n: usize,
    },
    /// Batched matrix multiplication.
    ///
    /// Performs matrix multiplication over batched dimensions.
    /// Input A: `[...batch, M, K]`, Input B: `[...batch, K, N]`
    /// Output: `[...batch, M, N]`
    BatchMatMul {
        /// Batch dimensions (product of all leading dimensions).
        batch: Vec<usize>,
        /// M dimension (rows of A's inner matrix).
        m: usize,
        /// K dimension (columns of A / rows of B).
        k: usize,
        /// N dimension (columns of B's inner matrix).
        n: usize,
    },

    // CNN operations
    /// 2D convolution.
    ///
    /// Input: `[N, C_in, H, W]`, Weight: `[C_out, C_in, K_h, K_w]`
    /// Output: `[N, C_out, H_out, W_out]`
    Conv2d {
        /// Kernel size (height, width).
        kernel: (usize, usize),
        /// Stride (height, width).
        stride: (usize, usize),
        /// Padding (height, width).
        padding: (usize, usize),
        /// Dilation (height, width).
        dilation: (usize, usize),
        /// Number of groups for grouped/depthwise convolution.
        groups: usize,
    },
    /// Batch normalization.
    ///
    /// Input: `[N, C, H, W]`, Scale/Bias/Mean/Var: `[C]`
    BatchNormalization {
        /// Epsilon for numerical stability.
        epsilon: f32,
    },
    /// Layer normalization (transformer-style).
    ///
    /// Normalizes over the last `normalized_dims` dimensions using mean and variance,
    /// then applies learnable scale (gamma) and bias (beta).
    /// Input: `[..., normalized_shape]`, Scale/Bias: `[normalized_shape]`
    /// Uses Welford's algorithm for numerical stability.
    LayerNorm {
        /// Number of dimensions to normalize over (from the end).
        normalized_dims: usize,
        /// Epsilon for numerical stability (default 1e-5).
        epsilon: f32,
    },
    /// 2D max pooling.
    ///
    /// Input: `[N, C, H, W]`, Output: `[N, C, H_out, W_out]`
    MaxPool {
        /// Kernel size (height, width).
        kernel: (usize, usize),
        /// Stride (height, width).
        stride: (usize, usize),
        /// Padding (height, width).
        padding: (usize, usize),
    },
    /// 2D average pooling.
    ///
    /// Input: `[N, C, H, W]`, Output: `[N, C, H_out, W_out]`
    AvgPool {
        /// Kernel size (height, width).
        kernel: (usize, usize),
        /// Stride (height, width).
        stride: (usize, usize),
        /// Padding (height, width).
        padding: (usize, usize),
    },
    /// Global average pooling (reduces H, W to 1).
    ///
    /// Input: `[N, C, H, W]`, Output: `[N, C, 1, 1]`
    GlobalAveragePool,
    /// Flatten tensor dimensions.
    ///
    /// Collapses dimensions from `start_dim` onwards.
    Flatten {
        /// Start dimension for flattening (default 1 preserves batch).
        start_dim: usize,
    },

    // Reduction operations
    /// Sum reduction.
    Sum,
    /// Max reduction.
    Max,
    /// Min reduction.
    Min,
    /// Mean reduction.
    Mean,

    // Categorical operations
    /// Lift to categorical space.
    Lift,
    /// Classify by orbit.
    OrbitClassify,

    // Codec operations
    /// Encode bytes using a codec.
    ///
    /// Transforms input bytes through a codec's representation.
    /// Codec ID: 0=binary, 1=decimal, 2=hexadecimal, 3=mod96crt, 4=continuedFraction.
    Encode {
        /// Codec identifier.
        codec_id: u32,
    },
    /// Decode bytes from a codec's representation.
    ///
    /// Transforms encoded data back to original bytes.
    /// Codec ID: 0=binary, 1=decimal, 2=hexadecimal, 3=mod96crt, 4=continuedFraction.
    Decode {
        /// Codec identifier.
        codec_id: u32,
    },

    // Hash operations
    /// SHA-256 hash. Output is always 32 bytes.
    Sha256 {
        /// Input byte length.
        src_len: usize,
    },
    /// Double SHA-256: SHA256(SHA256(data)). Output is always 32 bytes.
    DoubleSha256 {
        /// Input byte length.
        src_len: usize,
    },

    // Memory operations
    /// Load from buffer.
    Load,
    /// Store to buffer.
    Store,
    /// Copy buffer.
    Copy,

    // Shape operations
    /// Reshape tensor to new shape (element count must match).
    Reshape {
        /// Target shape dimensions.
        shape: Vec<usize>,
    },
    /// Transpose/permute tensor dimensions.
    Transpose {
        /// Permutation of dimensions (e.g., [0, 2, 1, 3]).
        perm: Vec<usize>,
    },
    /// Gather elements by indices (embedding lookup).
    Gather {
        /// Axis along which to gather.
        axis: usize,
    },
    /// Concatenate tensors along an axis.
    Concat {
        /// Axis along which to concatenate.
        axis: usize,
        /// Number of inputs to concatenate (2-8).
        num_inputs: usize,
    },
    /// Add size-1 dimension at specified axis.
    Unsqueeze {
        /// Axis at which to insert dimension.
        axis: usize,
    },
    /// Remove size-1 dimension at specified axis.
    Squeeze {
        /// Axis to remove (must be size 1).
        axis: usize,
    },
    /// Tile tensor by repeating along each dimension.
    ///
    /// Input shape `[d0, d1, ...]` with multiples `[m0, m1, ...]`
    /// produces output shape `[d0*m0, d1*m1, ...]`.
    Tile {
        /// Repetition count for each dimension.
        multiples: Vec<usize>,
    },
    /// Expand tensor to target shape via broadcasting.
    ///
    /// Uses `NumPy` broadcasting rules. Size-1 dimensions are repeated.
    Expand {
        /// Target shape to broadcast to.
        shape: Vec<usize>,
    },
    /// Extract a slice of the tensor with optional striding.
    ///
    /// Supports negative indexing for starts/ends (e.g., -1 = last element).
    /// Steps can be negative for reverse traversal.
    Slice {
        /// Start indices for each dimension. Negative values index from end.
        starts: Vec<isize>,
        /// End indices for each dimension. Negative values index from end.
        ends: Vec<isize>,
        /// Step/stride for each dimension. Default 1, negative for reverse.
        steps: Vec<isize>,
    },
    /// Split a tensor along an axis into multiple parts.
    ///
    /// Each Split node represents one output slice of the split operation.
    /// Multiple Split nodes with the same input and different `output_index`
    /// values represent the different outputs of a single logical split.
    /// Lowered to Slice operations during compilation.
    Split {
        /// Axis along which to split.
        axis: usize,
        /// Sizes of each split section along the axis.
        split_sizes: Vec<usize>,
        /// Which output this node produces (0-indexed).
        /// Must be < `split_sizes.len()`.
        output_index: usize,
    },
    /// Pad a tensor with values along each dimension.
    ///
    /// Adds padding before and after each dimension according to the specified amounts.
    Pad {
        /// Padding amounts per dimension: `(before, after)` pairs.
        pads: Vec<(usize, usize)>,
        /// Padding mode.
        mode: PadMode,
        /// Constant value for `PadMode::Constant` (default 0.0).
        constant_value: f32,
    },
    /// Type cast to different dtype.
    Cast {
        /// Target data type.
        to: DType,
    },

    // Control flow
    /// Call a sub-layer.
    CallLayer {
        /// Layer identifier.
        layer_id: u64,
    },

    // Special
    /// Input placeholder.
    Input,
    /// Output marker.
    Output,
    /// Constant value.
    Constant,

    // Tokenization
    /// Viterbi tokenization for `SentencePiece` Unigram models.
    ///
    /// Fused operation that performs UTF-8 decoding, normalization,
    /// vocabulary lookup via prefix trie, and Viterbi DP for optimal
    /// tokenization. Designed for high-performance tokenization in
    /// unified text-to-tensor pipelines.
    ViterbiTokenize {
        /// Maximum output tokens (truncate if exceeded).
        max_tokens: usize,
        /// Normalization flags bitfield.
        normalize_flags: u32,
        /// Unknown token ID.
        unk_token_id: u32,
        /// Unknown token score (log probability).
        unk_score: f32,
    },

    // Fused operations (TASK-327) — single dispatch, single memory pass
    /// Fused `MatMul` + `ReLU`: C = max(0, A @ B).
    MatMulRelu {
        /// M dimension (rows of A).
        m: usize,
        /// K dimension (columns of A / rows of B).
        k: usize,
        /// N dimension (columns of B).
        n: usize,
    },
    /// Fused Add + Sigmoid: dst[i] = sigmoid(a[i] + b[i]).
    AddSigmoid,
}

/// A node in the operation graph.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OpNode {
    /// Unique node identifier.
    pub id: u32,
    /// Operation kind.
    pub op: OpKind,
    /// Output shape.
    pub shape: Vec<usize>,
    /// Data type.
    pub dtype: DType,
    /// Optional debug name.
    pub name: Option<String>,
}

impl OpNode {
    /// Create a new operation node.
    #[must_use]
    pub fn new(id: u32, op: OpKind, shape: Vec<usize>, dtype: DType) -> Self {
        Self {
            id,
            op,
            shape,
            dtype,
            name: None,
        }
    }

    /// Set the debug name.
    #[must_use]
    pub fn with_name(mut self, name: impl Into<String>) -> Self {
        self.name = Some(name.into());
        self
    }
}

/// Constant data embedded in the graph.
///
/// This enum provides type-safe storage for constant tensors with compile-time
/// type checking via variants. Each variant stores a typed vector, ensuring
/// type safety throughout the compilation pipeline.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ConstantData {
    /// 32-bit floating point values.
    F32(Vec<f32>),
    /// 64-bit floating point values.
    F64(Vec<f64>),
    /// 32-bit signed integer values.
    I32(Vec<i32>),
    /// 64-bit signed integer values.
    I64(Vec<i64>),
    /// 8-bit unsigned integer values.
    U8(Vec<u8>),
    /// 16-bit unsigned integer values.
    U16(Vec<u16>),
    /// 32-bit unsigned integer values.
    U32(Vec<u32>),
    /// Boolean values.
    Bool(Vec<bool>),
}

impl ConstantData {
    /// Get the data type of this constant.
    #[must_use]
    pub const fn dtype(&self) -> DType {
        match self {
            Self::F32(_) => DType::F32,
            Self::F64(_) => DType::F64,
            Self::I32(_) => DType::I32,
            Self::I64(_) => DType::I64,
            Self::U8(_) => DType::U8,
            Self::U16(_) => DType::U16,
            Self::U32(_) => DType::U32,
            Self::Bool(_) => DType::Bool,
        }
    }

    /// Get the number of elements in this constant.
    #[must_use]
    pub fn len(&self) -> usize {
        match self {
            Self::F32(v) => v.len(),
            Self::F64(v) => v.len(),
            Self::I32(v) => v.len(),
            Self::I64(v) => v.len(),
            Self::U8(v) => v.len(),
            Self::U16(v) => v.len(),
            Self::U32(v) => v.len(),
            Self::Bool(v) => v.len(),
        }
    }

    /// Check if this constant is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Convert to raw bytes for serialization.
    ///
    /// This method converts the typed data into a raw byte vector suitable for
    /// serialization to disk or transmission over the network.
    #[must_use]
    pub fn to_bytes(&self) -> Vec<u8> {
        match self {
            Self::F32(v) => bytemuck::cast_slice(v).to_vec(),
            Self::F64(v) => bytemuck::cast_slice(v).to_vec(),
            Self::I32(v) => bytemuck::cast_slice(v).to_vec(),
            Self::I64(v) => bytemuck::cast_slice(v).to_vec(),
            Self::U8(v) => v.clone(),
            Self::U16(v) => bytemuck::cast_slice(v).to_vec(),
            Self::U32(v) => bytemuck::cast_slice(v).to_vec(),
            Self::Bool(v) => v.iter().map(|&b| u8::from(b)).collect(),
        }
    }
}

/// A lazy directed acyclic graph of operations.
///
/// This is the compiler's input type. Nodes represent operations;
/// edges represent data flow. The graph is immutable once passed
/// to the compiler.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct OperationGraph {
    /// All operation nodes.
    pub nodes: Vec<OpNode>,
    /// Directed edges as (source, target) pairs.
    pub edges: Vec<(u32, u32)>,
    /// Named inputs: (name, `node_id`).
    pub inputs: Vec<(String, u32)>,
    /// Named outputs: (name, `node_id`).
    pub outputs: Vec<(String, u32)>,
    /// Embedded constant data.
    pub constants: Vec<ConstantData>,
    /// Node IDs corresponding to each constant entry (parallel to `constants`).
    /// When populated, `constant_node_ids[i]` is the node ID that owns `constants[i]`.
    /// This enables explicit mapping independent of node iteration order.
    #[serde(default)]
    pub constant_node_ids: Vec<u32>,
}

impl OperationGraph {
    /// Create a new empty operation graph.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Add a node to the graph.
    pub fn add_node(&mut self, node: OpNode) -> u32 {
        let id = node.id;
        self.nodes.push(node);
        id
    }

    /// Add an edge from source to target.
    pub fn add_edge(&mut self, source: u32, target: u32) {
        self.edges.push((source, target));
    }

    /// Register a named input.
    pub fn add_input(&mut self, name: impl Into<String>, node_id: u32) {
        self.inputs.push((name.into(), node_id));
    }

    /// Register a named output.
    pub fn add_output(&mut self, name: impl Into<String>, node_id: u32) {
        self.outputs.push((name.into(), node_id));
    }

    /// Add constant data.
    ///
    /// Note: Prefer `add_constant_for_node()` which explicitly links the constant
    /// to its owning node, eliminating ordering assumptions.
    pub fn add_constant(&mut self, constant: ConstantData) {
        self.constants.push(constant);
    }

    /// Add constant data explicitly linked to a node.
    ///
    /// This method ensures the constant data is correctly mapped to the owning
    /// node regardless of the order nodes are added to the graph.
    ///
    /// # Arguments
    /// * `node_id` - The ID of the Constant node that owns this data
    /// * `constant` - The constant data
    pub fn add_constant_for_node(&mut self, node_id: u32, constant: ConstantData) {
        self.constant_node_ids.push(node_id);
        self.constants.push(constant);
    }

    /// Return the number of nodes.
    #[must_use]
    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }

    /// Return the number of edges.
    #[must_use]
    pub fn edge_count(&self) -> usize {
        self.edges.len()
    }

    /// Check if the graph is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.nodes.is_empty()
    }

    /// Validate the graph structure.
    ///
    /// This method performs comprehensive validation of the operation graph:
    /// - Checks for duplicate node IDs
    /// - Validates all edges reference existing nodes
    /// - Detects cycles in the graph
    /// - Identifies unreachable nodes (nodes not reachable from inputs)
    /// - Validates that named inputs/outputs reference existing nodes
    ///
    /// # Errors
    /// Returns the first validation error encountered.
    pub fn validate(&self) -> Result<(), CompileError> {
        // Check for duplicate node IDs
        self.check_duplicate_node_ids()?;

        // Build node ID set for edge validation
        let node_ids: HashSet<u32> = self.nodes.iter().map(|n| n.id).collect();

        // Validate all edges reference existing nodes
        self.check_invalid_edges(&node_ids)?;

        // Validate named inputs reference existing nodes
        self.check_invalid_inputs(&node_ids)?;

        // Validate named outputs reference existing nodes
        self.check_invalid_outputs(&node_ids)?;

        // Detect cycles
        self.check_cycles(&node_ids)?;

        // Check for unreachable nodes (only if graph has inputs)
        if !self.inputs.is_empty() {
            self.check_unreachable_nodes(&node_ids)?;
        }

        Ok(())
    }

    /// Check for duplicate node IDs.
    fn check_duplicate_node_ids(&self) -> Result<(), CompileError> {
        let mut seen: HashSet<u32> = HashSet::new();
        for node in &self.nodes {
            if !seen.insert(node.id) {
                return Err(CompileError::DuplicateNodeId(node.id));
            }
        }
        Ok(())
    }

    /// Check that all edges reference existing nodes.
    fn check_invalid_edges(&self, node_ids: &HashSet<u32>) -> Result<(), CompileError> {
        for &(src, dst) in &self.edges {
            if !node_ids.contains(&src) || !node_ids.contains(&dst) {
                return Err(CompileError::InvalidEdge { src, dst });
            }
        }
        Ok(())
    }

    /// Check that named inputs reference existing nodes.
    fn check_invalid_inputs(&self, node_ids: &HashSet<u32>) -> Result<(), CompileError> {
        for (name, node_id) in &self.inputs {
            if !node_ids.contains(node_id) {
                return Err(CompileError::InvalidInput {
                    name: name.clone(),
                    node_id: *node_id,
                });
            }
        }
        Ok(())
    }

    /// Check that named outputs reference existing nodes.
    fn check_invalid_outputs(&self, node_ids: &HashSet<u32>) -> Result<(), CompileError> {
        for (name, node_id) in &self.outputs {
            if !node_ids.contains(node_id) {
                return Err(CompileError::InvalidOutput {
                    name: name.clone(),
                    node_id: *node_id,
                });
            }
        }
        Ok(())
    }

    /// Detect cycles in the graph using DFS.
    fn check_cycles(&self, node_ids: &HashSet<u32>) -> Result<(), CompileError> {
        // Build adjacency list
        let mut successors: HashMap<u32, Vec<u32>> = HashMap::new();
        for &id in node_ids {
            successors.insert(id, Vec::new());
        }
        for &(src, dst) in &self.edges {
            if let Some(v) = successors.get_mut(&src) {
                v.push(dst);
            }
        }

        // DFS cycle detection
        let mut visited = HashSet::new();
        let mut in_stack = HashSet::new();

        for &id in node_ids {
            if !visited.contains(&id)
                && Self::dfs_has_cycle(id, &successors, &mut visited, &mut in_stack)
            {
                return Err(CompileError::CycleDetected);
            }
        }

        Ok(())
    }

    /// DFS helper for cycle detection.
    fn dfs_has_cycle(
        node: u32,
        successors: &HashMap<u32, Vec<u32>>,
        visited: &mut HashSet<u32>,
        in_stack: &mut HashSet<u32>,
    ) -> bool {
        visited.insert(node);
        in_stack.insert(node);

        if let Some(neighbors) = successors.get(&node) {
            for &neighbor in neighbors {
                if !visited.contains(&neighbor) {
                    if Self::dfs_has_cycle(neighbor, successors, visited, in_stack) {
                        return true;
                    }
                } else if in_stack.contains(&neighbor) {
                    return true;
                }
            }
        }

        in_stack.remove(&node);
        false
    }

    /// Check for unreachable nodes (nodes not reachable from any input).
    fn check_unreachable_nodes(&self, node_ids: &HashSet<u32>) -> Result<(), CompileError> {
        // Build successors map (forward edges)
        let mut successors: HashMap<u32, Vec<u32>> = HashMap::new();
        for &id in node_ids {
            successors.insert(id, Vec::new());
        }
        for &(src, dst) in &self.edges {
            if let Some(v) = successors.get_mut(&src) {
                v.push(dst);
            }
        }

        // BFS from all input nodes
        let mut reachable = HashSet::new();
        let mut queue: Vec<u32> = self.inputs.iter().map(|(_, id)| *id).collect();

        while let Some(node_id) = queue.pop() {
            if reachable.insert(node_id) {
                if let Some(neighbors) = successors.get(&node_id) {
                    for &neighbor in neighbors {
                        if !reachable.contains(&neighbor) {
                            queue.push(neighbor);
                        }
                    }
                }
            }
        }

        // Check for unreachable nodes (excluding input nodes with no edges)
        for node in &self.nodes {
            if !reachable.contains(&node.id) {
                // Check if this node has any incoming edges (if not, it might be an isolated constant)
                let has_incoming = self.edges.iter().any(|(_, dst)| *dst == node.id);
                let is_input = self.inputs.iter().any(|(_, id)| *id == node.id);
                let is_constant = matches!(node.op, OpKind::Constant);

                // Only report as unreachable if the node has incoming edges or is not an input/constant
                // Constants are data sources that don't need to be reachable from inputs
                if has_incoming || (!is_input && !is_constant) {
                    return Err(CompileError::UnreachableFromInputs {
                        node_id: node.id,
                        op_name: format!("{:?}", node.op)
                            .split('{')
                            .next()
                            .unwrap_or("Unknown")
                            .trim()
                            .to_string(),
                    });
                }
            }
        }

        Ok(())
    }

    /// Get a node by ID.
    #[must_use]
    pub fn get_node(&self, id: u32) -> Option<&OpNode> {
        self.nodes.iter().find(|n| n.id == id)
    }

    /// Get predecessors (nodes that feed into) of a node.
    #[must_use]
    pub fn predecessors(&self, node_id: u32) -> Vec<u32> {
        self.edges
            .iter()
            .filter(|(_, dst)| *dst == node_id)
            .map(|(src, _)| *src)
            .collect()
    }

    /// Get successors (nodes that consume output of) a node.
    #[must_use]
    pub fn successors(&self, node_id: u32) -> Vec<u32> {
        self.edges
            .iter()
            .filter(|(src, _)| *src == node_id)
            .map(|(_, dst)| *dst)
            .collect()
    }

    /// Add a SHA-256 hash node. Output is always 32 bytes (U8).
    pub fn sha256(&mut self, id: u32, input: u32, src_len: usize) -> u32 {
        let node = OpNode::new(id, OpKind::Sha256 { src_len }, vec![32], DType::U8);
        self.add_node(node);
        self.add_edge(input, id);
        id
    }

    /// Add a double SHA-256 hash node. Output is always 32 bytes (U8).
    pub fn double_sha256(&mut self, id: u32, input: u32, src_len: usize) -> u32 {
        let node = OpNode::new(id, OpKind::DoubleSha256 { src_len }, vec![32], DType::U8);
        self.add_node(node);
        self.add_edge(input, id);
        id
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_empty_graph() {
        let graph = OperationGraph::new();
        assert!(graph.is_empty());
        assert_eq!(graph.node_count(), 0);
        assert_eq!(graph.edge_count(), 0);
    }

    #[test]
    fn test_empty_graph_validates() {
        let graph = OperationGraph::new();
        assert!(graph.validate().is_ok());
    }

    #[test]
    fn test_add_node() {
        let mut graph = OperationGraph::new();
        let node = OpNode::new(0, OpKind::Add, vec![1, 2, 3], DType::F32);
        graph.add_node(node);
        assert_eq!(graph.node_count(), 1);
    }

    #[test]
    fn test_add_edge() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 2], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 2], DType::F32));
        graph.add_edge(0, 1);
        assert_eq!(graph.edge_count(), 1);
    }

    #[test]
    fn test_named_io() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Output, vec![1], DType::F32));
        graph.add_input("x", 0);
        graph.add_output("y", 1);
        assert_eq!(graph.inputs.len(), 1);
        assert_eq!(graph.outputs.len(), 1);
    }

    #[test]
    fn test_node_with_name() {
        let node = OpNode::new(
            0,
            OpKind::MatMul { m: 4, k: 8, n: 16 },
            vec![4, 16],
            DType::F32,
        )
        .with_name("dense_layer");
        assert_eq!(node.name, Some("dense_layer".to_string()));
    }

    #[test]
    fn test_conv2d_node() {
        let node = OpNode::new(
            0,
            OpKind::Conv2d {
                kernel: (3, 3),
                stride: (1, 1),
                padding: (1, 1),
                dilation: (1, 1),
                groups: 1,
            },
            vec![1, 64, 32, 32],
            DType::F32,
        );
        assert_eq!(node.shape, vec![1, 64, 32, 32]);
        if let OpKind::Conv2d {
            kernel,
            stride,
            padding,
            dilation,
            groups,
        } = node.op
        {
            assert_eq!(kernel, (3, 3));
            assert_eq!(stride, (1, 1));
            assert_eq!(padding, (1, 1));
            assert_eq!(dilation, (1, 1));
            assert_eq!(groups, 1);
        } else {
            panic!("Expected Conv2d");
        }
    }

    #[test]
    fn test_batch_normalization_node() {
        let node = OpNode::new(
            0,
            OpKind::BatchNormalization { epsilon: 1e-5 },
            vec![1, 64, 32, 32],
            DType::F32,
        );
        if let OpKind::BatchNormalization { epsilon } = node.op {
            assert!((epsilon - 1e-5).abs() < 1e-10);
        } else {
            panic!("Expected BatchNormalization");
        }
    }

    #[test]
    fn test_maxpool_node() {
        let node = OpNode::new(
            0,
            OpKind::MaxPool {
                kernel: (2, 2),
                stride: (2, 2),
                padding: (0, 0),
            },
            vec![1, 64, 16, 16],
            DType::F32,
        );
        assert_eq!(node.shape, vec![1, 64, 16, 16]);
        if let OpKind::MaxPool {
            kernel,
            stride,
            padding,
        } = node.op
        {
            assert_eq!(kernel, (2, 2));
            assert_eq!(stride, (2, 2));
            assert_eq!(padding, (0, 0));
        } else {
            panic!("Expected MaxPool");
        }
    }

    #[test]
    fn test_avgpool_node() {
        let node = OpNode::new(
            0,
            OpKind::AvgPool {
                kernel: (2, 2),
                stride: (2, 2),
                padding: (0, 0),
            },
            vec![1, 64, 16, 16],
            DType::F32,
        );
        assert_eq!(node.shape, vec![1, 64, 16, 16]);
        if let OpKind::AvgPool {
            kernel,
            stride,
            padding,
        } = node.op
        {
            assert_eq!(kernel, (2, 2));
            assert_eq!(stride, (2, 2));
            assert_eq!(padding, (0, 0));
        } else {
            panic!("Expected AvgPool");
        }
    }

    #[test]
    fn test_global_average_pool_node() {
        let node = OpNode::new(0, OpKind::GlobalAveragePool, vec![1, 512, 1, 1], DType::F32);
        assert_eq!(node.shape, vec![1, 512, 1, 1]);
        assert!(matches!(node.op, OpKind::GlobalAveragePool));
    }

    #[test]
    fn test_flatten_node() {
        let node = OpNode::new(
            0,
            OpKind::Flatten { start_dim: 1 },
            vec![1, 512],
            DType::F32,
        );
        assert_eq!(node.shape, vec![1, 512]);
        if let OpKind::Flatten { start_dim } = node.op {
            assert_eq!(start_dim, 1);
        } else {
            panic!("Expected Flatten");
        }
    }

    // ========================================================================
    // Validation Tests (TASK-181)
    // ========================================================================

    fn create_valid_linear_graph() -> OperationGraph {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![1, 4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_input("input", 0);
        graph.add_output("output", 2);
        graph
    }

    #[test]
    fn test_valid_graph_validates() {
        let graph = create_valid_linear_graph();
        assert!(graph.validate().is_ok());
    }

    #[test]
    fn test_duplicate_node_id() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(0, OpKind::Relu, vec![1, 4], DType::F32)); // Duplicate ID

        let result = graph.validate();
        assert!(matches!(result, Err(CompileError::DuplicateNodeId(0))));
    }

    #[test]
    fn test_invalid_edge_source() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_edge(99, 1); // Source doesn't exist

        let result = graph.validate();
        assert!(matches!(
            result,
            Err(CompileError::InvalidEdge { src: 99, dst: 1 })
        ));
    }

    #[test]
    fn test_invalid_edge_target() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_edge(0, 99); // Target doesn't exist

        let result = graph.validate();
        assert!(matches!(
            result,
            Err(CompileError::InvalidEdge { src: 0, dst: 99 })
        ));
    }

    #[test]
    fn test_invalid_edge_both() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_edge(98, 99); // Neither exists

        let result = graph.validate();
        assert!(matches!(result, Err(CompileError::InvalidEdge { .. })));
    }

    #[test]
    fn test_cycle_detection_simple() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 0); // Creates cycle

        let result = graph.validate();
        assert!(matches!(result, Err(CompileError::CycleDetected)));
    }

    #[test]
    fn test_cycle_detection_self_loop() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_edge(0, 0); // Self-loop

        let result = graph.validate();
        assert!(matches!(result, Err(CompileError::CycleDetected)));
    }

    #[test]
    fn test_cycle_detection_longer() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Tanh, vec![1, 4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        graph.add_edge(3, 1); // Creates cycle: 1 -> 2 -> 3 -> 1

        let result = graph.validate();
        assert!(matches!(result, Err(CompileError::CycleDetected)));
    }

    #[test]
    fn test_no_cycle_diamond() {
        // Diamond graph: 0 -> 1, 0 -> 2, 1 -> 3, 2 -> 3
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![1, 4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(0, 2);
        graph.add_edge(1, 3);
        graph.add_edge(2, 3);
        graph.add_input("input", 0);
        graph.add_output("output", 3);

        assert!(graph.validate().is_ok());
    }

    #[test]
    fn test_invalid_input_reference() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_input("x", 99); // Node 99 doesn't exist

        let result = graph.validate();
        assert!(
            matches!(result, Err(CompileError::InvalidInput { name, node_id }) if name == "x" && node_id == 99)
        );
    }

    #[test]
    fn test_invalid_output_reference() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Output, vec![1, 4], DType::F32));
        graph.add_output("y", 99); // Node 99 doesn't exist

        let result = graph.validate();
        assert!(
            matches!(result, Err(CompileError::InvalidOutput { name, node_id }) if name == "y" && node_id == 99)
        );
    }

    #[test]
    fn test_unreachable_node() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![1, 4], DType::F32)); // Unreachable
        graph.add_node(OpNode::new(3, OpKind::Output, vec![1, 4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 3);
        // Node 2 has no incoming edges from the graph flow
        graph.add_edge(99, 2); // This edge is invalid, but let's use a valid approach
        graph.add_input("input", 0);
        graph.add_output("output", 3);

        // Remove the invalid edge and use a proper isolated node
        let mut graph2 = OperationGraph::new();
        graph2.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph2.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph2.add_node(OpNode::new(2, OpKind::Sigmoid, vec![1, 4], DType::F32)); // Isolated node
        graph2.add_node(OpNode::new(3, OpKind::Output, vec![1, 4], DType::F32));
        graph2.add_edge(0, 1);
        graph2.add_edge(1, 3);
        graph2.add_edge(4, 2); // Create incoming edge to node 2 from nonexistent node
        graph2.add_input("input", 0);
        graph2.add_output("output", 3);

        // This should fail on invalid edge first
        let result = graph2.validate();
        assert!(result.is_err());
    }

    #[test]
    fn test_unreachable_node_with_incoming_edge() {
        // Create a valid graph where node 2 is isolated but has an incoming edge
        // from a reachable node that just doesn't go through inputs
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![1, 4], DType::F32)); // Has incoming but unreachable
        graph.add_node(OpNode::new(3, OpKind::Tanh, vec![1, 4], DType::F32)); // Not connected to input
        graph.add_node(OpNode::new(4, OpKind::Output, vec![1, 4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(1, 4);
        graph.add_edge(3, 2); // 3 feeds 2, but 3 is not reachable from input
        graph.add_input("input", 0);
        graph.add_output("output", 4);

        let result = graph.validate();
        // Should find unreachable node 3 first (since it has outgoing edges)
        assert!(matches!(
            result,
            Err(CompileError::UnreachableFromInputs { .. })
        ));
    }

    #[test]
    fn test_get_node() {
        let graph = create_valid_linear_graph();

        let node = graph.get_node(1);
        assert!(node.is_some());
        assert_eq!(node.unwrap().id, 1);
        assert!(matches!(node.unwrap().op, OpKind::Relu));

        let missing = graph.get_node(99);
        assert!(missing.is_none());
    }

    #[test]
    fn test_predecessors() {
        let graph = create_valid_linear_graph();

        let preds_0 = graph.predecessors(0);
        assert!(preds_0.is_empty());

        let preds_1 = graph.predecessors(1);
        assert_eq!(preds_1, vec![0]);

        let preds_2 = graph.predecessors(2);
        assert_eq!(preds_2, vec![1]);
    }

    #[test]
    fn test_successors() {
        let graph = create_valid_linear_graph();

        let succs_0 = graph.successors(0);
        assert_eq!(succs_0, vec![1]);

        let succs_1 = graph.successors(1);
        assert_eq!(succs_1, vec![2]);

        let succs_2 = graph.successors(2);
        assert!(succs_2.is_empty());
    }

    #[test]
    fn test_predecessors_multiple() {
        // Diamond graph: multiple predecessors for node 3
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Add, vec![1, 4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(0, 2);
        graph.add_edge(1, 3);
        graph.add_edge(2, 3);

        let preds_3 = graph.predecessors(3);
        assert_eq!(preds_3.len(), 2);
        assert!(preds_3.contains(&1));
        assert!(preds_3.contains(&2));
    }

    #[test]
    fn test_successors_multiple() {
        // Node 0 has multiple successors
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![1, 4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(0, 2);

        let succs_0 = graph.successors(0);
        assert_eq!(succs_0.len(), 2);
        assert!(succs_0.contains(&1));
        assert!(succs_0.contains(&2));
    }

    #[test]
    fn test_validate_single_node() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_input("input", 0);

        assert!(graph.validate().is_ok());
    }

    #[test]
    fn test_validate_multiple_inputs() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Add, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![1, 4], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        graph.add_input("a", 0);
        graph.add_input("b", 1);
        graph.add_output("output", 3);

        assert!(graph.validate().is_ok());
    }

    #[test]
    fn test_validate_multiple_outputs() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Relu, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(2, OpKind::Sigmoid, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![1, 4], DType::F32));
        graph.add_node(OpNode::new(4, OpKind::Output, vec![1, 4], DType::F32));
        graph.add_edge(0, 1);
        graph.add_edge(0, 2);
        graph.add_edge(1, 3);
        graph.add_edge(2, 4);
        graph.add_input("input", 0);
        graph.add_output("out1", 3);
        graph.add_output("out2", 4);

        assert!(graph.validate().is_ok());
    }

    #[test]
    fn test_validate_complex_graph() {
        // ResNet-style skip connection
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(
            0,
            OpKind::Input,
            vec![1, 64, 32, 32],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            1,
            OpKind::Conv2d {
                kernel: (3, 3),
                stride: (1, 1),
                padding: (1, 1),
                dilation: (1, 1),
                groups: 1,
            },
            vec![1, 64, 32, 32],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            2,
            OpKind::Relu,
            vec![1, 64, 32, 32],
            DType::F32,
        ));
        graph.add_node(OpNode::new(
            3,
            OpKind::Conv2d {
                kernel: (3, 3),
                stride: (1, 1),
                padding: (1, 1),
                dilation: (1, 1),
                groups: 1,
            },
            vec![1, 64, 32, 32],
            DType::F32,
        ));
        graph.add_node(OpNode::new(4, OpKind::Add, vec![1, 64, 32, 32], DType::F32)); // Skip connection
        graph.add_node(OpNode::new(
            5,
            OpKind::Output,
            vec![1, 64, 32, 32],
            DType::F32,
        ));

        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);
        graph.add_edge(0, 4); // Skip connection from input
        graph.add_edge(3, 4);
        graph.add_edge(4, 5);

        graph.add_input("input", 0);
        graph.add_output("output", 5);

        assert!(graph.validate().is_ok());
    }

    // ========================================================================
    // Tokenization OpKind Tests
    // ========================================================================

    #[test]
    #[allow(clippy::float_cmp)]
    fn test_viterbi_tokenize_node() {
        let node = OpNode::new(
            0,
            OpKind::ViterbiTokenize {
                max_tokens: 512,
                normalize_flags: 0b1100_0010, // SentencePiece default
                unk_token_id: 2,
                unk_score: -100.0,
            },
            vec![512], // Output: up to 512 token IDs
            DType::U32,
        );

        assert_eq!(node.id, 0);
        assert_eq!(node.shape, vec![512]);
        assert_eq!(node.dtype, DType::U32);

        if let OpKind::ViterbiTokenize {
            max_tokens,
            normalize_flags,
            unk_token_id,
            unk_score,
        } = node.op
        {
            assert_eq!(max_tokens, 512);
            assert_eq!(normalize_flags, 0b1100_0010);
            assert_eq!(unk_token_id, 2);
            assert_eq!(unk_score, -100.0);
        } else {
            panic!("Expected ViterbiTokenize");
        }
    }

    #[test]
    fn test_viterbi_tokenize_graph() {
        let mut graph = OperationGraph::new();

        // Input: UTF-8 text bytes
        graph.add_node(OpNode::new(0, OpKind::Input, vec![256], DType::U8));

        // Vocabulary constant (serialized trie + scores)
        graph.add_node(OpNode::new(1, OpKind::Constant, vec![1_000_000], DType::U8));

        // Tokenization node
        graph.add_node(OpNode::new(
            2,
            OpKind::ViterbiTokenize {
                max_tokens: 512,
                normalize_flags: 0b1100_0010,
                unk_token_id: 2,
                unk_score: -100.0,
            },
            vec![512],
            DType::U32,
        ));

        // Output
        graph.add_node(OpNode::new(3, OpKind::Output, vec![512], DType::U32));

        graph.add_edge(0, 2); // text -> tokenize
        graph.add_edge(1, 2); // vocab -> tokenize
        graph.add_edge(2, 3); // tokenize -> output

        graph.add_input("text", 0);
        graph.add_output("tokens", 3);

        assert!(graph.validate().is_ok());
        assert_eq!(graph.node_count(), 4);
        assert_eq!(graph.edge_count(), 3);
    }

    #[test]
    fn test_viterbi_tokenize_normalize_flags_values() {
        // Test that normalize flags match the ISA definition
        let flags_lowercase = 1 << 0;
        let flags_nfkc = 1 << 1;
        let flags_space_to_underscore = 1 << 6;
        let flags_prepend_underscore = 1 << 7;

        let sentencepiece_flags = flags_nfkc | flags_space_to_underscore | flags_prepend_underscore;

        let node = OpNode::new(
            0,
            OpKind::ViterbiTokenize {
                max_tokens: 512,
                normalize_flags: sentencepiece_flags,
                unk_token_id: 2,
                unk_score: -100.0,
            },
            vec![512],
            DType::U32,
        );

        if let OpKind::ViterbiTokenize {
            normalize_flags, ..
        } = node.op
        {
            // Check individual flags
            assert_eq!(normalize_flags & flags_lowercase, 0); // Lowercase not set
            assert_ne!(normalize_flags & flags_nfkc, 0); // NFKC is set
            assert_ne!(normalize_flags & flags_space_to_underscore, 0);
            assert_ne!(normalize_flags & flags_prepend_underscore, 0);
        }
    }

    #[test]
    fn test_sha256_builder() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![80], DType::U8));
        graph.sha256(1, 0, 80);
        graph.add_node(OpNode::new(2, OpKind::Output, vec![32], DType::U8));
        graph.add_edge(1, 2);

        assert_eq!(graph.node_count(), 3);
        assert_eq!(graph.edge_count(), 2);

        let sha_node = graph.get_node(1).unwrap();
        assert_eq!(sha_node.op, OpKind::Sha256 { src_len: 80 });
        assert_eq!(sha_node.shape, vec![32]);
        assert_eq!(sha_node.dtype, DType::U8);
    }

    #[test]
    fn test_double_sha256_builder() {
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![80], DType::U8));
        graph.double_sha256(1, 0, 80);
        graph.add_node(OpNode::new(2, OpKind::Output, vec![32], DType::U8));
        graph.add_edge(1, 2);

        assert_eq!(graph.node_count(), 3);

        let sha_node = graph.get_node(1).unwrap();
        assert_eq!(sha_node.op, OpKind::DoubleSha256 { src_len: 80 });
        assert_eq!(sha_node.shape, vec![32]);
    }

    #[test]
    fn test_sha256_opkind_equality() {
        let a = OpKind::Sha256 { src_len: 80 };
        let b = OpKind::Sha256 { src_len: 80 };
        let c = OpKind::Sha256 { src_len: 32 };
        assert_eq!(a, b);
        assert_ne!(a, c);
    }

    #[test]
    fn test_double_sha256_opkind_equality() {
        let a = OpKind::DoubleSha256 { src_len: 80 };
        let b = OpKind::DoubleSha256 { src_len: 80 };
        assert_eq!(a, b);
        // Sha256 != DoubleSha256 even with same src_len
        assert_ne!(
            OpKind::Sha256 { src_len: 80 },
            OpKind::DoubleSha256 { src_len: 80 }
        );
    }
}
