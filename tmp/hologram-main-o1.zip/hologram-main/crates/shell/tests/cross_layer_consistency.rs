//! Cross-layer consistency tests: verify the same shell DSL files drive
//! both the query layer (DTOs + resolvers) and the ISA layer (instructions + dispatch).

use hologram_shell::ast::ShellItem;

fn load_shell(name: &str) -> hologram_shell::ast::Shell {
    let path = format!("../../descriptors/shells/{name}.shell");
    let input =
        std::fs::read_to_string(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join(path))
            .unwrap();
    hologram_shell::parse_shell(&input).unwrap()
}

/// Every activation function in activation.shell should have a corresponding
/// *LUT ISA variant in isa.shell's lut_activation group.
#[test]
fn activation_names_in_both_layers() {
    let activation = load_shell("activation");
    let isa = load_shell("isa");

    // Extract activation field names from query shell
    let query_names: Vec<&str> = activation
        .items
        .iter()
        .filter_map(|item| match item {
            ShellItem::Type(td) => Some(td),
            _ => None,
        })
        .flat_map(|td| td.fields.iter())
        .map(|f| f.name.as_str())
        .collect();

    // Extract ISA lut_activation group member names
    let isa_lut_names: Vec<&str> = isa
        .items
        .iter()
        .filter_map(|item| match item {
            ShellItem::Group(g) => Some(g),
            _ => None,
        })
        .filter(|g| g.name == "lut_activation")
        .flat_map(|g| g.members.iter())
        .map(|m| m.name.as_str())
        .collect();

    // Every query activation should have a matching ISA activation
    for name in &query_names {
        assert!(
            isa_lut_names.contains(name),
            "activation.shell field '{name}' has no matching ISA lut_activation member"
        );
    }
}

/// ISA lut_activation group should be a superset of query activation fields.
#[test]
fn isa_shell_superset_of_query_activations() {
    let activation = load_shell("activation");
    let isa = load_shell("isa");

    let query_count = activation
        .items
        .iter()
        .filter_map(|item| match item {
            ShellItem::Type(td) => Some(td),
            _ => None,
        })
        .flat_map(|td| td.fields.iter())
        .count();

    let isa_lut_count: usize = isa
        .items
        .iter()
        .filter_map(|item| match item {
            ShellItem::Group(g) => Some(g),
            _ => None,
        })
        .filter(|g| g.name == "lut_activation")
        .map(|g| g.members.len())
        .sum();

    assert!(
        isa_lut_count >= query_count,
        "ISA lut_activation ({isa_lut_count} members) should be >= query activations ({query_count})"
    );
}

/// Ring operations should appear in both the query layer (as param fields)
/// and the ISA layer (as ring_ops group members with ring_ prefix).
#[test]
fn ring_ops_in_both_layers() {
    let ring = load_shell("ring");
    let isa = load_shell("isa");

    let query_ops: Vec<&str> = ring
        .items
        .iter()
        .filter_map(|item| match item {
            ShellItem::Type(td) => Some(td),
            _ => None,
        })
        .flat_map(|td| td.fields.iter())
        .filter(|f| !f.args.is_empty())
        .map(|f| f.name.as_str())
        .collect();

    // ISA ring ops are in ring_ops group (with ring_ prefix)
    let isa_ring_names: Vec<&str> = isa
        .items
        .iter()
        .filter_map(|item| match item {
            ShellItem::Group(g) => Some(g),
            _ => None,
        })
        .filter(|g| g.name == "ring_ops")
        .flat_map(|g| g.members.iter())
        .map(|m| m.name.as_str())
        .collect();

    assert!(!isa_ring_names.is_empty(), "ISA should have ring_ops group");

    // ISA uses ring_add, ring_mul naming; query uses add, sub, mul.
    // Verify add and mul have ISA counterparts (sub is query-only).
    for op in ["add", "mul"] {
        let isa_name = format!("ring_{op}");
        assert!(
            isa_ring_names.contains(&isa_name.as_str()),
            "ring.shell operation '{op}' has no matching ISA ring_ops member 'ring_{op}'"
        );
    }

    // Query has 3 ops (add, sub, mul)
    assert_eq!(query_ops.len(), 3, "ring.shell should have 3 param fields");
}

/// All 5 shell files should parse without error.
#[test]
fn all_five_shells_parse_cleanly() {
    for name in ["datum", "ring", "activation", "observable", "isa"] {
        let shell = load_shell(name);
        assert!(
            !shell.items.is_empty(),
            "{name}.shell parsed but has no items"
        );
    }
}

/// All shell files should have unique names.
#[test]
fn shell_names_unique() {
    let names: Vec<String> = ["datum", "ring", "activation", "observable", "isa"]
        .iter()
        .map(|f| load_shell(f).name)
        .collect();

    let unique: std::collections::HashSet<&str> = names.iter().map(|s| s.as_str()).collect();
    assert_eq!(
        names.len(),
        unique.len(),
        "shell names are not unique: {names:?}"
    );
}
