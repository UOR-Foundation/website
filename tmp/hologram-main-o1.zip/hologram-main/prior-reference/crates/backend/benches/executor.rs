//! Benchmarks for the plan executor and zero-overhead execution.
//!
//! # Overview
//!
//! These benchmarks verify the zero-overhead execution model where all expensive
//! decisions (kernel selection, layout planning, workspace sizing) happen at
//! compile time, leaving only O(1) dispatch at runtime.
//!
//! # Benchmark Groups
//!
//! ## `executor_creation`
//! Measures the one-time setup cost of creating a `PlanExecutor`:
//! - `without_workspace`: Baseline without workspace allocation
//! - `with_workspace_kb/N`: With N KB workspace allocation
//! - `builder_*`: Using the builder pattern
//!
//! ## `plan_execution`
//! Measures the per-execution overhead:
//! - `empty_plan`: Pure dispatch overhead baseline
//! - `ops/N`: Scaling behavior with N operations (should be O(n))
//!
//! ## `profiling_overhead`
//! Compares execution with and without profiling enabled.
//! Profiling should add minimal overhead (~10-15%).
//!
//! ## `batch_executor`
//! Measures the BatchExecutor for running multiple plans:
//! - `create_batch/N`: Setup cost for N plans
//! - `execute_all/N`: Execution of N plans
//!
//! ## `zero_allocation`
//! Verifies that steady-state execution performs no allocations:
//! - `steady_state_execution`: Repeated executions
//! - `reset_and_execute`: Reset + execute cycle
//!
//! ## `plan_access`
//! Verifies O(1) access to plan components regardless of plan size:
//! - `access_first_op/N`: Access first op in N-op plan
//! - `access_last_op/N`: Access last op (should be same as first)
//!
//! ## `dispatch_patterns`
//! Compares pre-optimization vs post-optimization execution patterns:
//! - `dynamic_dispatch_simulation`: Runtime decisions (old pattern)
//! - `static_table_lookup`: Pre-computed table (new pattern)
//! - `allocate_per_execute`: Allocate workspace each call (old pattern)
//! - `reuse_preallocated`: Reuse workspace (new pattern)
//!
//! # Expected Results
//!
//! - Empty plan execution: ~3ns (pure dispatch overhead)
//! - Per-op overhead: ~3-4ns per operation
//! - Workspace reuse: ~100x faster than per-call allocation
//! - Plan access should be O(1) regardless of plan size
//! - Profiling overhead should be under 20%

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use hologram_backend::cpu::CpuBackend;
use hologram_backend::executor::{BatchExecutor, ExecutorBuilder, PlanExecutor};
use hologram_backend::plan::{
    BackendPlan, BufferRef, EpilogueChain, KernelId, KernelParams, LookupTables, PlanOp,
    ThreadPartition, TileParams, WorkspaceLayout,
};
use hologram_backend::BackendType;

// ============================================================================
// TEST PLAN FACTORIES
// ============================================================================

/// Create an empty plan (baseline for overhead measurement).
fn create_empty_plan() -> BackendPlan {
    BackendPlan {
        backend_type: BackendType::Cpu,
        ops: Vec::new(),
        kernel_table: Default::default(),
        tile_params: TileParams::default(),
        layout_metadata: Default::default(),
        workspace_layout: WorkspaceLayout {
            total_size: 0,
            alignment: 64,
            regions: vec![],
        },
        epilogue_chain: EpilogueChain::new(),
        thread_partition: ThreadPartition::sequential(),
        constant_data: Vec::new(),
        lookup_tables: LookupTables::default(),
    }
}

/// Create a plan with N operations (for scaling tests).
fn create_plan_with_ops(num_ops: usize) -> BackendPlan {
    let ops: Vec<PlanOp> = (0..num_ops)
        .map(|i| PlanOp {
            kernel_id: KernelId(i as u32),
            kernel_idx: i,
            params: KernelParams {
                dims: [64, 64, 64, 0],
                ..KernelParams::default()
            },
            epilogue: EpilogueChain::new(),
            partition: ThreadPartition::sequential(),
            input_refs: vec![BufferRef::Input(0), BufferRef::Input(1)],
            output_refs: vec![BufferRef::Output(0)],
        })
        .collect();

    BackendPlan {
        backend_type: BackendType::Cpu,
        ops,
        kernel_table: Default::default(),
        tile_params: TileParams::default(),
        layout_metadata: Default::default(),
        workspace_layout: WorkspaceLayout {
            total_size: 4096,
            alignment: 64,
            regions: vec![],
        },
        epilogue_chain: EpilogueChain::new(),
        thread_partition: ThreadPartition::sequential(),
        constant_data: Vec::new(),
        lookup_tables: LookupTables::default(),
    }
}

/// Create a plan with specified workspace size.
fn create_plan_with_workspace(workspace_kb: usize) -> BackendPlan {
    BackendPlan {
        backend_type: BackendType::Cpu,
        ops: vec![PlanOp {
            kernel_id: KernelId(0),
            kernel_idx: 0,
            params: KernelParams::default(),
            epilogue: EpilogueChain::new(),
            partition: ThreadPartition::sequential(),
            input_refs: vec![BufferRef::Input(0)],
            output_refs: vec![BufferRef::Output(0)],
        }],
        kernel_table: Default::default(),
        tile_params: TileParams::default(),
        layout_metadata: Default::default(),
        workspace_layout: WorkspaceLayout {
            total_size: (workspace_kb * 1024) as u64,
            alignment: 64,
            regions: vec![],
        },
        epilogue_chain: EpilogueChain::new(),
        thread_partition: ThreadPartition::sequential(),
        constant_data: Vec::new(),
        lookup_tables: LookupTables::default(),
    }
}

// ============================================================================
// EXECUTOR CREATION BENCHMARKS
// ============================================================================

fn bench_executor_creation(c: &mut Criterion) {
    let mut group = c.benchmark_group("executor_creation");

    // Baseline: create executor without workspace allocation
    group.bench_function("without_workspace", |b| {
        b.iter(|| {
            let plan = create_empty_plan();
            PlanExecutor::without_workspace(black_box(plan))
        })
    });

    // With workspace: measure allocation overhead
    let backend = CpuBackend::new();
    for workspace_kb in [1, 4, 16, 64, 256] {
        group.bench_with_input(
            BenchmarkId::new("with_workspace_kb", workspace_kb),
            &workspace_kb,
            |b, &size| {
                b.iter(|| {
                    let plan = create_plan_with_workspace(size);
                    PlanExecutor::new(black_box(plan), &backend)
                })
            },
        );
    }

    // Using builder pattern
    group.bench_function("builder_default", |b| {
        b.iter(|| {
            let plan = create_empty_plan();
            ExecutorBuilder::new().build(black_box(plan), &backend)
        })
    });

    group.bench_function("builder_with_profiling", |b| {
        b.iter(|| {
            let plan = create_empty_plan();
            ExecutorBuilder::new()
                .with_profiling()
                .build(black_box(plan), &backend)
        })
    });

    group.finish();
}

// ============================================================================
// PLAN EXECUTION BENCHMARKS
// ============================================================================

fn bench_plan_execution(c: &mut Criterion) {
    let mut group = c.benchmark_group("plan_execution");

    let backend = CpuBackend::new();
    let inputs = vec![];
    let outputs = vec![];

    // Baseline: empty plan (measures pure dispatch overhead)
    group.bench_function("empty_plan", |b| {
        let plan = create_empty_plan();
        let mut executor = PlanExecutor::without_workspace(plan);

        b.iter(|| executor.execute(black_box(&inputs), black_box(&outputs), &backend))
    });

    // Scaling with number of operations
    for num_ops in [1, 4, 16, 64, 256] {
        group.throughput(Throughput::Elements(num_ops as u64));
        group.bench_with_input(BenchmarkId::new("ops", num_ops), &num_ops, |b, &num_ops| {
            let plan = create_plan_with_ops(num_ops);
            let mut executor = PlanExecutor::without_workspace(plan);

            b.iter(|| executor.execute(black_box(&inputs), black_box(&outputs), &backend))
        });
    }

    group.finish();
}

// ============================================================================
// PROFILING OVERHEAD BENCHMARKS
// ============================================================================

fn bench_profiling_overhead(c: &mut Criterion) {
    let mut group = c.benchmark_group("profiling_overhead");

    let backend = CpuBackend::new();
    let inputs = vec![];
    let outputs = vec![];

    for num_ops in [1, 16, 64] {
        // Without profiling
        group.bench_with_input(
            BenchmarkId::new("no_profiling", num_ops),
            &num_ops,
            |b, &num_ops| {
                let plan = create_plan_with_ops(num_ops);
                let mut executor = PlanExecutor::without_workspace(plan);
                executor.set_profiling(false);

                b.iter(|| executor.execute(black_box(&inputs), black_box(&outputs), &backend))
            },
        );

        // With profiling enabled
        group.bench_with_input(
            BenchmarkId::new("with_profiling", num_ops),
            &num_ops,
            |b, &num_ops| {
                let plan = create_plan_with_ops(num_ops);
                let mut executor = PlanExecutor::without_workspace(plan);
                executor.set_profiling(true);

                b.iter(|| executor.execute(black_box(&inputs), black_box(&outputs), &backend))
            },
        );
    }

    group.finish();
}

// ============================================================================
// BATCH EXECUTOR BENCHMARKS
// ============================================================================

fn bench_batch_executor(c: &mut Criterion) {
    let mut group = c.benchmark_group("batch_executor");

    let backend = CpuBackend::new();

    // Batch creation
    for num_plans in [1, 4, 16] {
        group.bench_with_input(
            BenchmarkId::new("create_batch", num_plans),
            &num_plans,
            |b, &num_plans| {
                b.iter(|| {
                    let mut batch = BatchExecutor::new();
                    for _ in 0..num_plans {
                        let plan = create_plan_with_ops(4);
                        let _ = batch.add_plan(black_box(plan), &backend);
                    }
                    batch
                })
            },
        );
    }

    // Sequential execution through batch
    for num_plans in [1, 4, 16] {
        group.throughput(Throughput::Elements(num_plans as u64));
        group.bench_with_input(
            BenchmarkId::new("execute_all", num_plans),
            &num_plans,
            |b, &num_plans| {
                let mut batch = BatchExecutor::new();
                for _ in 0..num_plans {
                    let plan = create_plan_with_ops(4);
                    let _ = batch.add_plan(plan, &backend);
                }
                let backend = CpuBackend::new();
                let inputs = vec![];
                let outputs = vec![];

                b.iter(|| {
                    batch.reset();
                    while batch
                        .execute_next(black_box(&inputs), black_box(&outputs), &backend)
                        .unwrap_or(false)
                    {}
                })
            },
        );
    }

    group.finish();
}

// ============================================================================
// ZERO-ALLOCATION VERIFICATION
// ============================================================================

fn bench_zero_allocation_path(c: &mut Criterion) {
    let mut group = c.benchmark_group("zero_allocation");

    let backend = CpuBackend::new();
    let inputs = vec![];
    let outputs = vec![];

    // Pre-create executor (one-time setup cost)
    let plan = create_plan_with_ops(16);
    let mut executor = PlanExecutor::without_workspace(plan);

    // Measure steady-state execution (should have no allocations)
    group.bench_function("steady_state_execution", |b| {
        b.iter(|| executor.execute(black_box(&inputs), black_box(&outputs), &backend))
    });

    // Measure reset + re-execute (should also have no allocations)
    group.bench_function("reset_and_execute", |b| {
        b.iter(|| {
            executor.reset();
            executor.execute(black_box(&inputs), black_box(&outputs), &backend)
        })
    });

    group.finish();
}

// ============================================================================
// PLAN ACCESS BENCHMARKS (verify O(1) access)
// ============================================================================

fn bench_plan_access(c: &mut Criterion) {
    let mut group = c.benchmark_group("plan_access");

    // Create plans of different sizes
    for num_ops in [1, 16, 256, 1024] {
        let plan = create_plan_with_ops(num_ops);

        group.bench_with_input(
            BenchmarkId::new("access_first_op", num_ops),
            &plan,
            |b, plan| {
                b.iter(|| {
                    let _ = black_box(&plan.ops[0]);
                })
            },
        );

        if num_ops > 1 {
            let last_idx = num_ops - 1;
            group.bench_with_input(
                BenchmarkId::new("access_last_op", num_ops),
                &plan,
                |b, plan| {
                    b.iter(|| {
                        let _ = black_box(&plan.ops[last_idx]);
                    })
                },
            );
        }

        group.bench_with_input(
            BenchmarkId::new("access_tile_params", num_ops),
            &plan,
            |b, plan| {
                b.iter(|| {
                    let _ = black_box(&plan.tile_params);
                })
            },
        );

        group.bench_with_input(
            BenchmarkId::new("access_kernel_table", num_ops),
            &plan,
            |b, plan| {
                b.iter(|| {
                    let _ = black_box(&plan.kernel_table);
                })
            },
        );
    }

    group.finish();
}

// ============================================================================
// COMPARATIVE BENCHMARKS (pre-optimization vs post-optimization patterns)
// ============================================================================

fn bench_dispatch_patterns(c: &mut Criterion) {
    let mut group = c.benchmark_group("dispatch_patterns");

    // Simulate pre-optimization: dynamic dispatch with runtime decisions
    group.bench_function("dynamic_dispatch_simulation", |b| {
        let ops = create_plan_with_ops(16).ops;
        let kernel_ids: Vec<u32> = ops.iter().map(|op| op.kernel_id.0).collect();

        b.iter(|| {
            let mut sum = 0u64;
            for &id in &kernel_ids {
                // Simulate runtime decision based on kernel_id
                sum += match id % 4 {
                    0 => 100,
                    1 => 200,
                    2 => 300,
                    _ => 400,
                };
            }
            black_box(sum)
        })
    });

    // Post-optimization: direct table lookup (O(1) per op)
    group.bench_function("static_table_lookup", |b| {
        let ops = create_plan_with_ops(16).ops;
        // Pre-computed lookup table (simulates static kernel table)
        let lookup_table: Vec<u64> = (0..16).map(|i| (i as u64 + 1) * 100).collect();

        b.iter(|| {
            let mut sum = 0u64;
            for op in &ops {
                // Direct index lookup - O(1), no branching
                sum += lookup_table[op.kernel_idx];
            }
            black_box(sum)
        })
    });

    // Pre-optimization: allocate per execution
    group.bench_function("allocate_per_execute", |b| {
        b.iter(|| {
            // Simulate allocating workspace each time
            let workspace: Vec<u8> = vec![0u8; 4096];
            black_box(workspace.as_ptr())
        })
    });

    // Post-optimization: reuse pre-allocated workspace
    group.bench_function("reuse_preallocated", |b| {
        // Pre-allocate workspace once
        let workspace: Vec<u8> = vec![0u8; 4096];

        b.iter(|| {
            // Zero-cost: just use existing buffer
            // Real kernels overwrite data, no need to zero first
            black_box(workspace.as_ptr())
        })
    });

    group.finish();
}

criterion_group!(
    benches,
    bench_executor_creation,
    bench_plan_execution,
    bench_profiling_overhead,
    bench_batch_executor,
    bench_zero_allocation_path,
    bench_plan_access,
    bench_dispatch_patterns,
);

criterion_main!(benches);
