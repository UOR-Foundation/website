//! Codec registry for FFI layer.
//!
//! Provides runtime codec discovery and instantiation by ID.
//! Bridges between FFI callers and generated codec implementations.

use categorical_codec::{Codec, CodecError};
use std::collections::HashMap;

#[cfg(feature = "wasm")]
use wasm_bindgen::prelude::*;

/// A codec wrapper that can be used across FFI boundaries.
///
/// Wraps a `Box<dyn Codec>` and provides encode/decode methods.
pub struct FfiCodec {
    inner: Box<dyn Codec>,
}

impl FfiCodec {
    /// Create a new FfiCodec wrapping a Codec implementation.
    pub fn new(codec: Box<dyn Codec>) -> Self {
        Self { inner: codec }
    }

    /// Get the codec ID.
    pub fn id(&self) -> &str {
        self.inner.id()
    }

    /// Get the codec name.
    pub fn name(&self) -> &str {
        self.inner.name()
    }

    /// Get the codec radix.
    pub fn radix(&self) -> u32 {
        self.inner.scale_factor().radix
    }

    /// Encode data using this codec.
    pub fn encode(&self, data: &[u8]) -> Result<Vec<u8>, CodecError> {
        self.inner.encode(data)
    }

    /// Decode data using this codec.
    pub fn decode(&self, data: &[u8]) -> Result<Vec<u8>, CodecError> {
        self.inner.decode(data)
    }
}

/// Registry of available codecs.
///
/// Discovers codecs at construction time and provides lookup by ID or name.
pub struct CodecRegistry {
    /// Codecs indexed by ID
    by_id: HashMap<String, Box<dyn Codec>>,
    /// Codec IDs indexed by name (for name-based lookup)
    name_to_id: HashMap<String, String>,
}

impl CodecRegistry {
    /// Create a new codec registry with all available codecs.
    #[must_use]
    pub fn new() -> Self {
        let codecs = categorical_codec::all_codecs();
        let mut by_id = HashMap::with_capacity(codecs.len());
        let mut name_to_id = HashMap::with_capacity(codecs.len());

        for codec in codecs {
            let id = codec.id().to_string();
            let name = codec.name().to_string();
            name_to_id.insert(name, id.clone());
            by_id.insert(id, codec);
        }

        Self { by_id, name_to_id }
    }

    /// Get the number of registered codecs.
    #[must_use]
    pub fn len(&self) -> usize {
        self.by_id.len()
    }

    /// Check if the registry is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.by_id.is_empty()
    }

    /// List all codec IDs.
    #[must_use]
    pub fn codec_ids(&self) -> Vec<&str> {
        self.by_id.keys().map(String::as_str).collect()
    }

    /// List all codec names.
    #[must_use]
    pub fn codec_names(&self) -> Vec<&str> {
        self.name_to_id.keys().map(String::as_str).collect()
    }

    /// Get a codec by its ID.
    #[must_use]
    pub fn get_by_id(&self, id: &str) -> Option<FfiCodec> {
        // Check if ID exists, then get a fresh instance from all_codecs
        // (we can't clone Box<dyn Codec> so we fetch a new one)
        if self.by_id.contains_key(id) {
            categorical_codec::all_codecs()
                .into_iter()
                .find(|codec| codec.id() == id)
                .map(FfiCodec::new)
        } else {
            None
        }
    }

    /// Get a codec by its name.
    #[must_use]
    pub fn get_by_name(&self, name: &str) -> Option<FfiCodec> {
        self.name_to_id.get(name).and_then(|id| self.get_by_id(id))
    }

    /// Get a codec by ID or name (tries both).
    #[must_use]
    pub fn get(&self, id_or_name: &str) -> Option<FfiCodec> {
        self.get_by_id(id_or_name)
            .or_else(|| self.get_by_name(id_or_name))
    }

    /// Check if a codec exists by ID.
    #[must_use]
    pub fn has_id(&self, id: &str) -> bool {
        self.by_id.contains_key(id)
    }

    /// Check if a codec exists by name.
    #[must_use]
    pub fn has_name(&self, name: &str) -> bool {
        self.name_to_id.contains_key(name)
    }
}

impl Default for CodecRegistry {
    fn default() -> Self {
        Self::new()
    }
}

// ============================================================================
// WASM bindings (optional)
// ============================================================================

#[cfg(feature = "wasm")]
mod wasm_bindings {
    use super::*;

    /// WASM-bindable codec wrapper.
    #[wasm_bindgen]
    pub struct WasmCodec {
        inner: FfiCodec,
    }

    #[wasm_bindgen]
    impl WasmCodec {
        /// Get the codec ID.
        #[wasm_bindgen(getter)]
        pub fn id(&self) -> String {
            self.inner.id().to_string()
        }

        /// Get the codec name.
        #[wasm_bindgen(getter)]
        pub fn name(&self) -> String {
            self.inner.name().to_string()
        }

        /// Get the codec radix.
        #[wasm_bindgen(getter)]
        pub fn radix(&self) -> u32 {
            self.inner.radix()
        }

        /// Encode data using this codec.
        ///
        /// Returns the encoded bytes, or throws an error on failure.
        pub fn encode(&self, data: &[u8]) -> Result<Vec<u8>, JsValue> {
            self.inner
                .encode(data)
                .map_err(|e| JsValue::from_str(&e.to_string()))
        }

        /// Decode data using this codec.
        ///
        /// Returns the decoded bytes, or throws an error on failure.
        pub fn decode(&self, data: &[u8]) -> Result<Vec<u8>, JsValue> {
            self.inner
                .decode(data)
                .map_err(|e| JsValue::from_str(&e.to_string()))
        }
    }

    /// WASM-bindable codec registry.
    #[wasm_bindgen]
    pub struct WasmCodecRegistry {
        inner: CodecRegistry,
    }

    #[wasm_bindgen]
    impl WasmCodecRegistry {
        /// Create a new codec registry.
        #[wasm_bindgen(constructor)]
        pub fn new() -> Self {
            Self {
                inner: CodecRegistry::new(),
            }
        }

        /// Get the number of registered codecs.
        #[wasm_bindgen(getter)]
        pub fn len(&self) -> usize {
            self.inner.len()
        }

        /// Check if the registry is empty.
        #[wasm_bindgen(getter)]
        pub fn is_empty(&self) -> bool {
            self.inner.is_empty()
        }

        /// List all codec IDs.
        #[wasm_bindgen(js_name = listIds)]
        pub fn list_ids(&self) -> Vec<JsValue> {
            self.inner
                .codec_ids()
                .into_iter()
                .map(JsValue::from_str)
                .collect()
        }

        /// List all codec names.
        #[wasm_bindgen(js_name = listNames)]
        pub fn list_names(&self) -> Vec<JsValue> {
            self.inner
                .codec_names()
                .into_iter()
                .map(JsValue::from_str)
                .collect()
        }

        /// Get a codec by ID.
        #[wasm_bindgen(js_name = getById)]
        pub fn get_by_id(&self, id: &str) -> Option<WasmCodec> {
            self.inner.get_by_id(id).map(|c| WasmCodec { inner: c })
        }

        /// Get a codec by name.
        #[wasm_bindgen(js_name = getByName)]
        pub fn get_by_name(&self, name: &str) -> Option<WasmCodec> {
            self.inner.get_by_name(name).map(|c| WasmCodec { inner: c })
        }

        /// Get a codec by ID or name (tries both).
        pub fn get(&self, id_or_name: &str) -> Option<WasmCodec> {
            self.inner.get(id_or_name).map(|c| WasmCodec { inner: c })
        }

        /// Check if a codec exists by ID.
        #[wasm_bindgen(js_name = hasId)]
        pub fn has_id(&self, id: &str) -> bool {
            self.inner.has_id(id)
        }

        /// Check if a codec exists by name.
        #[wasm_bindgen(js_name = hasName)]
        pub fn has_name(&self, name: &str) -> bool {
            self.inner.has_name(name)
        }
    }

    impl Default for WasmCodecRegistry {
        fn default() -> Self {
            Self::new()
        }
    }
}

#[cfg(feature = "wasm")]
pub use wasm_bindings::{WasmCodec, WasmCodecRegistry};

#[cfg(test)]
mod tests {
    use super::*;

    // ========================================================================
    // CodecRegistry tests
    // ========================================================================

    #[test]
    fn test_codec_registry_new() {
        let registry = CodecRegistry::new();
        assert!(!registry.is_empty(), "Should have codecs");
        assert!(registry.len() >= 5, "Should have at least 5 codecs");
    }

    #[test]
    fn test_codec_registry_default() {
        let registry = CodecRegistry::default();
        assert_eq!(registry.len(), CodecRegistry::new().len());
    }

    #[test]
    fn test_codec_registry_list_ids() {
        let registry = CodecRegistry::new();
        let ids = registry.codec_ids();
        assert!(!ids.is_empty());
        // All IDs should be unique
        let unique: std::collections::HashSet<_> = ids.iter().collect();
        assert_eq!(unique.len(), ids.len());
    }

    #[test]
    fn test_codec_registry_list_names() {
        let registry = CodecRegistry::new();
        let names = registry.codec_names();
        assert!(!names.is_empty());
        // Check for expected codec names
        assert!(names
            .iter()
            .any(|n| n.contains("Binary") || n.contains("Decimal")));
    }

    #[test]
    fn test_codec_registry_get_by_id() {
        let registry = CodecRegistry::new();
        // Get a known codec by ID
        let ids = registry.codec_ids();
        if let Some(id) = ids.first() {
            let codec = registry.get_by_id(id);
            assert!(codec.is_some(), "Should find codec by ID");
            let codec = codec.unwrap();
            assert_eq!(codec.id(), *id);
        }
    }

    #[test]
    fn test_codec_registry_get_by_name() {
        let registry = CodecRegistry::new();
        // Get a known codec by name
        let names = registry.codec_names();
        if let Some(name) = names.first() {
            let codec = registry.get_by_name(name);
            assert!(codec.is_some(), "Should find codec by name");
            let codec = codec.unwrap();
            assert_eq!(codec.name(), *name);
        }
    }

    #[test]
    fn test_codec_registry_get_nonexistent() {
        let registry = CodecRegistry::new();
        assert!(registry.get_by_id("nonexistent-id").is_none());
        assert!(registry.get_by_name("NonexistentCodec").is_none());
        assert!(registry.get("nonexistent").is_none());
    }

    #[test]
    fn test_codec_registry_has_id() {
        let registry = CodecRegistry::new();
        let ids = registry.codec_ids();
        if let Some(id) = ids.first() {
            assert!(registry.has_id(id));
        }
        assert!(!registry.has_id("nonexistent-id"));
    }

    #[test]
    fn test_codec_registry_has_name() {
        let registry = CodecRegistry::new();
        let names = registry.codec_names();
        if let Some(name) = names.first() {
            assert!(registry.has_name(name));
        }
        assert!(!registry.has_name("NonexistentCodec"));
    }

    // ========================================================================
    // FfiCodec tests
    // ========================================================================

    #[test]
    fn test_ffi_codec_encode_decode_roundtrip() {
        let registry = CodecRegistry::new();
        // Test with all available codecs
        // Use input that starts with non-zero to avoid leading-zero issues in base-N codecs
        for id in registry.codec_ids() {
            let codec = registry.get_by_id(id).expect("Should find codec");
            // Braille codecs have fixed precision and may pad/truncate
            // Skip them here; they're tested separately in test_braille_codec_utf8_output
            if id.contains("braille") {
                continue;
            }
            let original = vec![42, 127, 200, 255, 1];
            let encoded = codec.encode(&original).expect("Encode should succeed");
            let decoded = codec.decode(&encoded).expect("Decode should succeed");
            assert_eq!(decoded, original, "Roundtrip failed for codec {}", id);
        }
    }

    #[test]
    fn test_ffi_codec_empty_input() {
        let registry = CodecRegistry::new();
        // Find a non-Braille codec (Braille codecs pad empty input)
        let non_braille_id = registry
            .codec_ids()
            .into_iter()
            .find(|id| !id.contains("braille"));
        if let Some(id) = non_braille_id {
            let codec = registry.get_by_id(id).expect("Should find codec");
            let empty: Vec<u8> = vec![];
            let encoded = codec.encode(&empty).expect("Encode empty should succeed");
            let decoded = codec.decode(&encoded).expect("Decode should succeed");
            assert!(decoded.is_empty());
        }
    }

    #[test]
    fn test_ffi_codec_properties() {
        let registry = CodecRegistry::new();
        for id in registry.codec_ids() {
            let codec = registry.get_by_id(id).expect("Should find codec");
            assert!(!codec.id().is_empty(), "ID should not be empty");
            assert!(!codec.name().is_empty(), "Name should not be empty");
            assert!(codec.radix() >= 2, "Radix should be at least 2");
        }
    }

    #[test]
    fn test_braille_codec_utf8_output() {
        let registry = CodecRegistry::new();
        // Find a Braille codec
        let braille_codec = registry
            .codec_names()
            .into_iter()
            .find(|n| n.contains("Braille"))
            .and_then(|name| registry.get_by_name(name));

        if let Some(codec) = braille_codec {
            let input = vec![0, 1, 255];
            let encoded = codec.encode(&input).expect("Encode should succeed");
            // Braille output should be valid UTF-8
            assert!(
                std::str::from_utf8(&encoded).is_ok(),
                "Braille output should be valid UTF-8"
            );
        }
    }

    #[test]
    fn test_get_codec_flexible() {
        let registry = CodecRegistry::new();
        // get() should work with both ID and name
        let ids = registry.codec_ids();
        let names = registry.codec_names();

        if let Some(id) = ids.first() {
            assert!(registry.get(id).is_some(), "get() should work with ID");
        }
        if let Some(name) = names.first() {
            assert!(registry.get(name).is_some(), "get() should work with name");
        }
    }
}
