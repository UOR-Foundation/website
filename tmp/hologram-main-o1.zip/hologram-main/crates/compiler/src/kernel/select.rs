//! Kernel selection per node.

use hologram_backend::BackendCapabilities;

use super::cost::estimate_cost;
use super::registry::{KernelId, KernelRegistry};
use crate::graph::CompileGraph;

/// Calculate adjusted cycle count applying cost multiplier.
#[allow(
    clippy::cast_possible_truncation,
    clippy::cast_sign_loss,
    clippy::cast_precision_loss
)]
fn adjusted_cycles(base_cycles: u64, multiplier: f32) -> u64 {
    let base = base_cycles as f64;
    let mult = f64::from(multiplier);
    (base * mult) as u64
}

/// Select optimal kernels for each node based on backend capabilities.
///
/// This function assigns a kernel ID to each node in the graph by:
/// 1. Looking up the operation category
/// 2. Finding compatible kernels from the registry
/// 3. Selecting the best kernel based on cost model
/// 4. Assigning the kernel ID to the node
pub fn select_kernels(graph: &mut CompileGraph, caps: &BackendCapabilities) {
    let registry = KernelRegistry::new();
    select_kernels_with_registry(graph, caps, &registry);
}

/// Select kernels using a provided registry.
///
/// This allows custom registries for testing or specialized backends.
pub fn select_kernels_with_registry(
    graph: &mut CompileGraph,
    caps: &BackendCapabilities,
    registry: &KernelRegistry,
) {
    // Collect node IDs and their operations to avoid borrow conflicts
    let selections: Vec<(u32, KernelId)> = graph
        .nodes()
        .filter_map(|(id, node)| {
            let category = node.op.category();
            let best = registry.select_best(category, caps)?;
            Some((id, best.id))
        })
        .collect();

    // Apply kernel assignments
    for (id, kernel_id) in selections {
        if let Some(node) = graph.get_node_mut(id) {
            node.kernel = Some(kernel_id.0);
        }
    }
}

/// Select kernel with detailed cost estimation.
///
/// Returns the selected kernel ID along with estimated cost for each node.
pub fn select_kernels_with_cost(
    graph: &mut CompileGraph,
    caps: &BackendCapabilities,
) -> Vec<(u32, KernelId, u64)> {
    let registry = KernelRegistry::new();

    let selections: Vec<(u32, KernelId, u64)> = graph
        .nodes()
        .filter_map(|(id, node)| {
            let category = node.op.category();
            let best = registry.select_best(category, caps)?;

            // Estimate cost for this operation
            let base_cost = estimate_cost(&node.op, &node.shape, caps);
            let cycles = adjusted_cycles(base_cost.cycles, best.cost_multiplier);

            Some((id, best.id, cycles))
        })
        .collect();

    // Apply kernel assignments
    for &(id, kernel_id, _) in &selections {
        if let Some(node) = graph.get_node_mut(id) {
            node.kernel = Some(kernel_id.0);
        }
    }

    selections
}

/// Get total estimated cost for the entire graph after kernel selection.
#[must_use]
pub fn total_graph_cost(graph: &CompileGraph, caps: &BackendCapabilities) -> u64 {
    let registry = KernelRegistry::new();

    graph
        .nodes()
        .filter_map(|(_, node)| {
            let category = node.op.category();
            let best = registry.select_best(category, caps)?;
            let base_cost = estimate_cost(&node.op, &node.shape, caps);
            Some(adjusted_cycles(base_cost.cycles, best.cost_multiplier))
        })
        .sum()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpCategory, OpKind, OpNode, OperationGraph};
    use hologram_backend::BackendType;

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    fn test_caps() -> BackendCapabilities {
        BackendCapabilities {
            backend_type: BackendType::Cpu,
            vector_width: 8,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: true,
            has_sha: false,
            has_aes: false,
        }
    }

    #[test]
    fn test_select_kernels_empty_graph() {
        let mut graph = make_graph(vec![], vec![]);
        let caps = test_caps();
        select_kernels(&mut graph, &caps);
        assert_eq!(graph.node_count(), 0);
    }

    #[test]
    fn test_select_kernels_assigns_to_all_nodes() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (0, 2), (1, 2), (2, 3)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        // All nodes should have kernels assigned
        for (_, node) in graph.nodes() {
            assert!(node.kernel.is_some(), "Node should have kernel assigned");
        }
    }

    #[test]
    fn test_select_kernels_selects_avx2_for_cpu() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        // Add should get AVX2 kernel (ID 2)
        let add_node = graph.get_node(1).unwrap();
        assert_eq!(add_node.kernel, Some(2)); // binary_avx2
    }

    #[test]
    fn test_select_kernels_selects_scalar_for_wasm() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = BackendCapabilities {
            backend_type: BackendType::Wasm,
            vector_width: 4,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: false,
            has_sha: false,
            has_aes: false,
        };

        select_kernels(&mut graph, &caps);

        // Add should get scalar kernel (ID 1)
        let add_node = graph.get_node(1).unwrap();
        assert_eq!(add_node.kernel, Some(1)); // binary_scalar
    }

    #[test]
    fn test_select_kernels_matmul_with_fma() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        // MatMul should get AVX2+FMA kernel (ID 22)
        let matmul_node = graph.get_node(2).unwrap();
        assert_eq!(matmul_node.kernel, Some(22)); // matmul_avx2_fma
    }

    #[test]
    fn test_select_kernels_matmul_without_fma() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 64,
                        k: 64,
                        n: 64,
                    },
                    vec![64, 64],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        let mut caps = test_caps();
        caps.has_fma = false;
        select_kernels(&mut graph, &caps);

        // MatMul should get blocked kernel (ID 21) without FMA
        let matmul_node = graph.get_node(2).unwrap();
        assert_eq!(matmul_node.kernel, Some(21)); // matmul_blocked
    }

    #[test]
    fn test_select_kernels_with_cost() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        let costs = select_kernels_with_cost(&mut graph, &caps);

        // Should have cost for each node
        assert_eq!(costs.len(), 3);

        // All costs should have valid values
        for (id, kernel, _) in &costs {
            assert!(graph.get_node(*id).is_some());
            assert!(kernel.0 > 0 || *id == 0 || *id == 2); // I/O nodes get kernel 80
        }
    }

    #[test]
    fn test_total_graph_cost() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64, 64], DType::F32),
                OpNode::new(3, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3)],
        );

        let caps = test_caps();
        let total = total_graph_cost(&graph, &caps);

        assert!(total > 0);
    }

    #[test]
    fn test_total_graph_cost_simd_cheaper() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![1024, 1024], DType::F32),
                OpNode::new(1, OpKind::Add, vec![1024, 1024], DType::F32),
                OpNode::new(2, OpKind::Output, vec![1024, 1024], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps_avx2 = test_caps();
        let cost_avx2 = total_graph_cost(&graph, &caps_avx2);

        let caps_scalar = BackendCapabilities {
            backend_type: BackendType::Wasm,
            vector_width: 1,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: false,
            has_sha: false,
            has_aes: false,
        };
        let cost_scalar = total_graph_cost(&graph, &caps_scalar);

        // SIMD should be cheaper
        assert!(cost_avx2 < cost_scalar);
    }

    #[test]
    fn test_select_kernels_reduction() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![1024], DType::F32),
                OpNode::new(1, OpKind::Sum, vec![1], DType::F32),
                OpNode::new(2, OpKind::Output, vec![1], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        // Sum should get SIMD kernel (ID 31)
        let sum_node = graph.get_node(1).unwrap();
        assert_eq!(sum_node.kernel, Some(31)); // reduce_simd
    }

    #[test]
    fn test_select_kernels_activation() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Sigmoid, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        // Sigmoid should get AVX2 activation kernel (ID 12)
        let sigmoid_node = graph.get_node(1).unwrap();
        assert_eq!(sigmoid_node.kernel, Some(12)); // activation_avx2
    }

    #[test]
    fn test_select_kernels_categorical() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Lift, vec![256], DType::U8),
                OpNode::new(2, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        // Lift should get LUT kernel (ID 50)
        let lift_node = graph.get_node(1).unwrap();
        assert_eq!(lift_node.kernel, Some(50)); // categorical_lut
    }

    #[test]
    fn test_select_kernels_custom_registry() {
        use super::super::registry::KernelInfo;

        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let mut registry = KernelRegistry::new();
        registry.register(
            OpCategory::BinaryElementwise,
            KernelInfo::new(
                KernelId(999),
                "custom_add",
                &[BackendType::Cpu],
                super::super::registry::KernelRequirements::default(),
                0.001, // Very fast
            ),
        );

        let caps = test_caps();
        select_kernels_with_registry(&mut graph, &caps, &registry);

        // Add should get custom kernel
        let add_node = graph.get_node(1).unwrap();
        assert_eq!(add_node.kernel, Some(999));
    }

    // ========================================================================
    // Edge Case Tests (TASK-184)
    // ========================================================================

    #[test]
    fn test_select_kernels_single_input_node() {
        let mut graph = make_graph(
            vec![OpNode::new(0, OpKind::Input, vec![64], DType::F32)],
            vec![],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        let input_node = graph.get_node(0).unwrap();
        assert!(input_node.kernel.is_some());
    }

    #[test]
    fn test_select_kernels_single_output_node() {
        let mut graph = make_graph(
            vec![OpNode::new(0, OpKind::Output, vec![64], DType::F32)],
            vec![],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        let output_node = graph.get_node(0).unwrap();
        assert!(output_node.kernel.is_some());
    }

    #[test]
    fn test_select_kernels_input_output_only() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        // Both nodes should have kernels
        assert!(graph.get_node(0).unwrap().kernel.is_some());
        assert!(graph.get_node(1).unwrap().kernel.is_some());
    }

    #[test]
    fn test_select_kernels_large_dag() {
        // Create a large DAG with 100 nodes in a chain
        let mut nodes: Vec<OpNode> = Vec::new();
        let mut edges: Vec<(u32, u32)> = Vec::new();

        nodes.push(OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32));

        for i in 1..99 {
            let op = if i % 3 == 0 {
                OpKind::Relu
            } else if i % 3 == 1 {
                OpKind::Sigmoid
            } else {
                OpKind::Tanh
            };
            nodes.push(OpNode::new(i, op, vec![64, 64], DType::F32));
            edges.push((i - 1, i));
        }

        nodes.push(OpNode::new(99, OpKind::Output, vec![64, 64], DType::F32));
        edges.push((98, 99));

        let mut graph = make_graph(nodes, edges);
        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        // All 100 nodes should have kernels
        assert_eq!(graph.node_count(), 100);
        for (_, node) in graph.nodes() {
            assert!(node.kernel.is_some());
        }
    }

    #[test]
    fn test_select_kernels_wide_dag() {
        // Create a wide DAG: 1 input -> 50 parallel ops -> 1 output
        let mut nodes: Vec<OpNode> = Vec::new();
        let mut edges: Vec<(u32, u32)> = Vec::new();

        nodes.push(OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32));

        for i in 1..=50 {
            nodes.push(OpNode::new(i, OpKind::Relu, vec![64, 64], DType::F32));
            edges.push((0, i)); // Input -> each parallel node
        }

        // All parallel nodes go to output
        nodes.push(OpNode::new(51, OpKind::Output, vec![64, 64], DType::F32));
        for i in 1..=50 {
            edges.push((i, 51));
        }

        let mut graph = make_graph(nodes, edges);
        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        assert_eq!(graph.node_count(), 52);
        for (_, node) in graph.nodes() {
            assert!(node.kernel.is_some());
        }
    }

    #[test]
    fn test_select_kernels_diamond_pattern() {
        // Diamond: Input -> A,B -> Merge -> Output
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64, 64], DType::F32),
                OpNode::new(3, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(4, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (0, 2), (1, 3), (2, 3), (3, 4)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        for (_, node) in graph.nodes() {
            assert!(node.kernel.is_some());
        }
    }

    #[test]
    fn test_select_kernels_with_cost_empty_graph() {
        let mut graph = make_graph(vec![], vec![]);
        let caps = test_caps();
        let costs = select_kernels_with_cost(&mut graph, &caps);

        assert!(costs.is_empty());
    }

    #[test]
    fn test_select_kernels_with_cost_single_node() {
        let mut graph = make_graph(
            vec![OpNode::new(0, OpKind::Input, vec![64], DType::F32)],
            vec![],
        );

        let caps = test_caps();
        let costs = select_kernels_with_cost(&mut graph, &caps);

        assert_eq!(costs.len(), 1);
        let (id, kernel_id, _cost) = costs[0];
        assert_eq!(id, 0);
        assert!(kernel_id.0 > 0);
    }

    #[test]
    fn test_total_graph_cost_empty_graph() {
        let graph = make_graph(vec![], vec![]);
        let caps = test_caps();
        let total = total_graph_cost(&graph, &caps);

        assert_eq!(total, 0);
    }

    #[test]
    fn test_total_graph_cost_single_node() {
        let graph = make_graph(
            vec![OpNode::new(0, OpKind::Relu, vec![64], DType::F32)],
            vec![],
        );

        let caps = test_caps();
        let total = total_graph_cost(&graph, &caps);

        assert!(total > 0);
    }

    #[test]
    fn test_select_kernels_large_tensor_shapes() {
        // Test with very large tensor shapes
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![4096, 4096], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![4096, 4096], DType::F32),
                OpNode::new(2, OpKind::Output, vec![4096, 4096], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        for (_, node) in graph.nodes() {
            assert!(node.kernel.is_some());
        }
    }

    #[test]
    fn test_select_kernels_zero_size_tensor() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![0], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![0], DType::F32),
                OpNode::new(2, OpKind::Output, vec![0], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        // Should still assign kernels even for zero-size tensors
        for (_, node) in graph.nodes() {
            assert!(node.kernel.is_some());
        }
    }

    #[test]
    fn test_select_kernels_high_dimensional_tensor() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![2, 3, 4, 5, 6, 7], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![2, 3, 4, 5, 6, 7], DType::F32),
                OpNode::new(2, OpKind::Output, vec![2, 3, 4, 5, 6, 7], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        for (_, node) in graph.nodes() {
            assert!(node.kernel.is_some());
        }
    }

    #[test]
    fn test_total_graph_cost_large_shapes() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![8192, 8192], DType::F32),
                OpNode::new(
                    1,
                    OpKind::MatMul {
                        m: 8192,
                        k: 8192,
                        n: 8192,
                    },
                    vec![8192, 8192],
                    DType::F32,
                ),
                OpNode::new(2, OpKind::Output, vec![8192, 8192], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        let total = total_graph_cost(&graph, &caps);

        // Cost should be very large for 8k x 8k matmul
        assert!(total > 1_000_000);
    }

    #[test]
    fn test_select_kernels_conv2d() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![1, 3, 224, 224], DType::F32),
                OpNode::new(
                    1,
                    OpKind::Conv2d {
                        kernel: (3, 3),
                        stride: (1, 1),
                        padding: (1, 1),
                        dilation: (1, 1),
                        groups: 1,
                    },
                    vec![1, 64, 224, 224],
                    DType::F32,
                ),
                OpNode::new(2, OpKind::Output, vec![1, 64, 224, 224], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        let conv_node = graph.get_node(1).unwrap();
        assert!(conv_node.kernel.is_some());
    }

    #[test]
    fn test_select_kernels_pooling() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![1, 64, 224, 224], DType::F32),
                OpNode::new(
                    1,
                    OpKind::MaxPool {
                        kernel: (2, 2),
                        stride: (2, 2),
                        padding: (0, 0),
                    },
                    vec![1, 64, 112, 112],
                    DType::F32,
                ),
                OpNode::new(2, OpKind::Output, vec![1, 64, 112, 112], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        let pool_node = graph.get_node(1).unwrap();
        assert!(pool_node.kernel.is_some());
    }

    #[test]
    fn test_select_kernels_batch_norm() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![1, 64, 32, 32], DType::F32),
                OpNode::new(
                    1,
                    OpKind::BatchNormalization { epsilon: 1e-5 },
                    vec![1, 64, 32, 32],
                    DType::F32,
                ),
                OpNode::new(2, OpKind::Output, vec![1, 64, 32, 32], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        let bn_node = graph.get_node(1).unwrap();
        assert!(bn_node.kernel.is_some());
    }

    #[test]
    fn test_select_kernels_softmax() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![1, 1000], DType::F32),
                OpNode::new(1, OpKind::Softmax { axis: -1 }, vec![1, 1000], DType::F32),
                OpNode::new(2, OpKind::Output, vec![1, 1000], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        let softmax_node = graph.get_node(1).unwrap();
        assert!(softmax_node.kernel.is_some());
    }

    #[test]
    fn test_adjusted_cycles_zero_base() {
        let result = adjusted_cycles(0, 1.5);
        assert_eq!(result, 0);
    }

    #[test]
    fn test_adjusted_cycles_one_multiplier() {
        let result = adjusted_cycles(1000, 1.0);
        assert_eq!(result, 1000);
    }

    #[test]
    fn test_adjusted_cycles_fractional_multiplier() {
        let result = adjusted_cycles(1000, 0.5);
        assert_eq!(result, 500);
    }

    #[test]
    fn test_adjusted_cycles_large_values() {
        // Test with large values that could overflow if not handled properly
        let result = adjusted_cycles(u64::MAX / 2, 1.0);
        assert!(result > 0);
    }

    #[test]
    fn test_select_kernels_different_dtypes() {
        // Test various data types
        for dtype in [DType::F32, DType::F64, DType::I32, DType::I8, DType::U8] {
            let mut graph = make_graph(
                vec![
                    OpNode::new(0, OpKind::Input, vec![64], dtype),
                    OpNode::new(1, OpKind::Relu, vec![64], dtype),
                    OpNode::new(2, OpKind::Output, vec![64], dtype),
                ],
                vec![(0, 1), (1, 2)],
            );

            let caps = test_caps();
            select_kernels(&mut graph, &caps);

            for (_, node) in graph.nodes() {
                assert!(node.kernel.is_some());
            }
        }
    }

    #[test]
    fn test_select_kernels_gpu_backend() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Add, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = BackendCapabilities {
            backend_type: BackendType::Cuda,
            vector_width: 32,
            l1_cache_size: 128 * 1024,
            l2_cache_size: 6 * 1024 * 1024,
            has_fma: true,
            has_sha: false,
            has_aes: false,
        };

        // Should not panic - GPU backends may or may not have kernels registered
        select_kernels(&mut graph, &caps);

        // Just verify the function completed and graph is still valid
        assert_eq!(graph.node_count(), 3);
    }

    #[test]
    fn test_select_kernels_metal_backend() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = BackendCapabilities {
            backend_type: BackendType::Metal,
            vector_width: 16,
            l1_cache_size: 64 * 1024,
            l2_cache_size: 4 * 1024 * 1024,
            has_fma: true,
            has_sha: false,
            has_aes: false,
        };

        // Should not panic - Metal backend may or may not have kernels registered
        select_kernels(&mut graph, &caps);

        // Just verify the function completed and graph is still valid
        assert_eq!(graph.node_count(), 3);
    }

    #[test]
    fn test_cost_comparison_simd_vs_scalar() {
        let graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![10000], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![10000], DType::F32),
                OpNode::new(2, OpKind::Output, vec![10000], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps_simd = BackendCapabilities {
            backend_type: BackendType::Cpu,
            vector_width: 8,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: true,
            has_sha: false,
            has_aes: false,
        };

        let caps_scalar = BackendCapabilities {
            backend_type: BackendType::Cpu,
            vector_width: 1,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: false,
            has_sha: false,
            has_aes: false,
        };

        let cost_simd = total_graph_cost(&graph, &caps_simd);
        let cost_scalar = total_graph_cost(&graph, &caps_scalar);

        // SIMD should be significantly faster
        assert!(cost_simd < cost_scalar);
    }

    #[test]
    fn test_select_kernels_reshape() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![1, 784], DType::F32),
                OpNode::new(
                    1,
                    OpKind::Reshape {
                        shape: vec![1, 1, 28, 28],
                    },
                    vec![1, 1, 28, 28],
                    DType::F32,
                ),
                OpNode::new(2, OpKind::Output, vec![1, 1, 28, 28], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        let reshape_node = graph.get_node(1).unwrap();
        assert!(reshape_node.kernel.is_some());
    }

    #[test]
    fn test_select_kernels_flatten() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![1, 64, 7, 7], DType::F32),
                OpNode::new(
                    1,
                    OpKind::Flatten { start_dim: 1 },
                    vec![1, 3136],
                    DType::F32,
                ),
                OpNode::new(2, OpKind::Output, vec![1, 3136], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        let flatten_node = graph.get_node(1).unwrap();
        assert!(flatten_node.kernel.is_some());
    }

    #[test]
    fn test_select_kernels_constant_node() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Constant, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1)],
        );

        let caps = test_caps();
        select_kernels(&mut graph, &caps);

        let const_node = graph.get_node(0).unwrap();
        assert!(const_node.kernel.is_some());
    }
}
