/**
 * CeremonyHistory — Timeline of trust ceremonies.
 */

import type { CeremonyRecord } from "../types";
import { ScrollText, Shield, Users, RefreshCw } from "lucide-react";

interface Props {
  readonly ceremonies: readonly CeremonyRecord[];
}

const TYPE_CONFIG = {
  founding: { icon: Shield, label: "Identity Created", color: "text-primary" },
  peer: { icon: Users, label: "Peer Verified", color: "text-accent-foreground" },
  renewal: { icon: RefreshCw, label: "Key Renewed", color: "text-muted-foreground" },
} as const;

function truncate(str: string, len = 12): string {
  return str.length > len ? `${str.slice(0, len)}…` : str;
}

export default function CeremonyHistory({ ceremonies }: Props) {
  const sorted = [...ceremonies].sort((a, b) => b.timestamp - a.timestamp);

  return (
    <div className="rounded-lg border border-border bg-card p-6 animate-fade-in" style={{ animationDelay: "0.2s" }}>
      <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-5 flex items-center gap-2">
        <ScrollText className="h-3.5 w-3.5" />
        Verification History
      </h3>

      {sorted.length === 0 ? (
        <p className="text-sm text-muted-foreground">No verification events recorded yet.</p>
      ) : (
        <div className="relative space-y-0">
          {/* Timeline line */}
          <div className="absolute left-[11px] top-2 bottom-2 w-px bg-border" />

          {sorted.map((c, i) => {
            const cfg = TYPE_CONFIG[c.type];
            const Icon = cfg.icon;
            const date = new Date(c.timestamp);

            return (
              <div key={c.id} className="relative flex gap-4 pb-5 last:pb-0">
                {/* Dot */}
                <div className={`relative z-10 mt-1 flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-full border border-border bg-card ${cfg.color}`}>
                  <Icon className="h-3 w-3" />
                </div>

                {/* Content */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline gap-2 flex-wrap">
                    <span className={`text-sm font-semibold ${cfg.color}`}>{cfg.label}</span>
                    <span className="text-[10px] text-muted-foreground">
                      {date.toLocaleDateString()} · {date.toLocaleTimeString()}
                    </span>
                  </div>

                  <div className="mt-1.5 space-y-1 text-xs text-muted-foreground">
                    <div className="flex gap-1.5">
                      <span className="shrink-0 text-foreground/60">Proof ID:</span>
                      <span className="font-mono break-all">{truncate(c.derivationId, 24)}</span>
                    </div>
                    <div className="flex gap-1.5">
                      <span className="shrink-0 text-foreground/60">Recovery key:</span>
                      <span className="font-mono">{truncate(c.guardianFingerprint, 16)}</span>
                    </div>
                    <div className="flex gap-1.5">
                      <span className="shrink-0 text-foreground/60">Interaction key:</span>
                      <span className="font-mono">{truncate(c.delegateFingerprint, 16)}</span>
                    </div>
                    {c.participants.length > 1 && (
                      <div className="flex gap-1.5">
                        <span className="shrink-0 text-foreground/60">Participants:</span>
                        <span>{c.participants.length} identities</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
