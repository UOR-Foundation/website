//! Structural tests: verify generated query code from shell files has correct
//! field counts, DTO names, resolver traits, and FIELDS constants.
//!
//! Mirrors `crates/holo/tests/generated_isa_equivalence.rs` for the query layer.
//! Uses shell parsing + emit to inspect generated code structurally rather than
//! importing compiled types (the `generated` module is private to hologram-query).

// ============================================================================
// Helpers
// ============================================================================

fn count_type_fields(shell: &hologram_shell::ast::Shell) -> usize {
    shell
        .items
        .iter()
        .filter_map(|item| match item {
            hologram_shell::ast::ShellItem::Type(td) => Some(td),
            _ => None,
        })
        .flat_map(|td| flat_field_count(&td.fields))
        .count()
}

fn flat_field_count(
    fields: &[hologram_shell::ast::FieldDef],
) -> Box<dyn Iterator<Item = &hologram_shell::ast::FieldDef> + '_> {
    Box::new(fields.iter().flat_map(|f| {
        if f.children.is_empty() {
            Box::new(std::iter::once(f)) as Box<dyn Iterator<Item = _>>
        } else {
            flat_field_count(&f.children)
        }
    }))
}

fn count_param_fields(shell: &hologram_shell::ast::Shell) -> usize {
    shell
        .items
        .iter()
        .filter_map(|item| match item {
            hologram_shell::ast::ShellItem::Type(td) => Some(td),
            _ => None,
        })
        .flat_map(|td| td.fields.iter())
        .filter(|f| !f.args.is_empty())
        .count()
}

fn field_names(shell: &hologram_shell::ast::Shell) -> Vec<String> {
    shell
        .items
        .iter()
        .filter_map(|item| match item {
            hologram_shell::ast::ShellItem::Type(td) => Some(td),
            _ => None,
        })
        .flat_map(|td| collect_field_names(&td.fields, ""))
        .collect()
}

fn collect_field_names(fields: &[hologram_shell::ast::FieldDef], prefix: &str) -> Vec<String> {
    let mut names = Vec::new();
    for f in fields {
        if f.children.is_empty() {
            let name = if prefix.is_empty() {
                f.name.clone()
            } else {
                format!("{prefix}.{}", f.name)
            };
            names.push(name);
        } else {
            names.extend(collect_field_names(&f.children, &f.name));
        }
    }
    names
}

// ============================================================================
// datum.shell equivalence
// ============================================================================

#[test]
fn datum_field_count_matches() {
    let input = include_str!("../../../descriptors/shells/datum.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ast_count = count_type_fields(&shell);
    let code = hologram_shell::emit_query::emit_all(&shell).to_string();

    // FIELDS array should contain exactly ast_count entries
    let fields_count = code.matches("\"stratum\"").count()
        + code.matches("\"curvature\"").count()
        + code.matches("\"domain\"").count()
        + code.matches("\"rank\"").count()
        + code.matches("\"orbit_class\"").count()
        + code.matches("\"torus.page\"").count()
        + code.matches("\"torus.offset\"").count();
    // Verify AST has the expected number of leaf fields
    assert_eq!(ast_count, 7, "datum.shell should have 7 leaf fields");
    assert!(
        fields_count >= ast_count,
        "generated code should reference all {ast_count} field names, found {fields_count}"
    );
}

#[test]
fn datum_dto_field_names_match() {
    let input = include_str!("../../../descriptors/shells/datum.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ast_names = field_names(&shell);
    let code = hologram_shell::emit_query::emit_all(&shell).to_string();

    for name in &ast_names {
        // The field name should appear in the generated FIELDS constant
        let quoted = format!("\"{name}\"");
        assert!(
            code.contains(&quoted),
            "AST field '{name}' missing from generated code"
        );
    }
}

// ============================================================================
// ring.shell equivalence
// ============================================================================

#[test]
fn ring_param_field_count() {
    let input = include_str!("../../../descriptors/shells/ring.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ast_count = count_param_fields(&shell);
    assert_eq!(
        ast_count, 3,
        "ring.shell should have 3 param fields (add, sub, mul)"
    );
}

#[test]
fn ring_param_field_names_match() {
    let input = include_str!("../../../descriptors/shells/ring.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let code = hologram_shell::emit_query::emit_all(&shell).to_string();

    for name in ["add", "sub", "mul"] {
        let quoted = format!("\"{name}\"");
        assert!(
            code.contains(&quoted),
            "ring param field '{name}' missing from generated code"
        );
    }
}

// ============================================================================
// activation.shell equivalence
// ============================================================================

#[test]
fn activation_field_count() {
    let input = include_str!("../../../descriptors/shells/activation.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ast_count = count_type_fields(&shell);
    assert_eq!(ast_count, 9, "activation.shell should have 9 fields");
}

#[test]
fn activation_field_names_match() {
    let input = include_str!("../../../descriptors/shells/activation.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ast_names = field_names(&shell);
    let code = hologram_shell::emit_query::emit_all(&shell).to_string();

    for name in &ast_names {
        let quoted = format!("\"{name}\"");
        assert!(
            code.contains(&quoted),
            "AST field '{name}' missing from generated code"
        );
    }
}

// ============================================================================
// observable.shell equivalence
// ============================================================================

#[test]
fn observable_field_count() {
    let input = include_str!("../../../descriptors/shells/observable.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    let ast_count = count_type_fields(&shell);
    assert_eq!(ast_count, 3, "observable.shell should have 3 fields");
}

#[test]
fn observable_module_path_preserved() {
    let input = include_str!("../../../descriptors/shells/observable.shell");
    let shell = hologram_shell::parse_shell(input).unwrap();
    assert_eq!(
        shell.module_path.as_deref(),
        Some("uor::observable"),
        "observable.shell should have @module(\"uor::observable\")"
    );
}

// ============================================================================
// Generated code structural validation
// ============================================================================

#[test]
fn resolver_trait_names_in_generated_code() {
    let shells = [
        ("datum", "ByteResolver"),
        ("ring", "ElementResolver"),
        ("activation", "ActivationResolver"),
        ("observable", "PathResolver"),
    ];

    for (name, expected_trait) in &shells {
        let path = format!("../../descriptors/shells/{name}.shell");
        let input =
            std::fs::read_to_string(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join(path))
                .unwrap();
        let shell = hologram_shell::parse_shell(&input).unwrap();
        let code = hologram_shell::emit_query::emit_all(&shell).to_string();

        assert!(
            code.contains(expected_trait),
            "generated code for {name}.shell should contain trait '{expected_trait}'"
        );

        let lut_name = format!("Lut{expected_trait}");
        assert!(
            code.contains(&lut_name),
            "generated code for {name}.shell should contain struct '{lut_name}'"
        );
    }
}

#[test]
fn all_four_shells_parse_and_generate() {
    for name in ["datum", "ring", "activation", "observable"] {
        let path = format!("../../descriptors/shells/{name}.shell");
        let input =
            std::fs::read_to_string(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join(path))
                .unwrap();
        let shell = hologram_shell::parse_shell(&input).unwrap();
        let code = hologram_shell::emit_query::emit_all(&shell).to_string();
        assert!(
            !code.is_empty(),
            "generated code for {name}.shell should be non-empty"
        );
    }
}
