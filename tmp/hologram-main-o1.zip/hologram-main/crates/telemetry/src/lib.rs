//! Hologram Telemetry - Observability infrastructure for Hologram
//!
//! This crate provides:
//! - **Tracing**: Structured logging with spans and events
//! - **Metrics**: Performance counters and histograms
//! - **Profiling**: CPU and memory profiling integration
//!
//! # Quick Start
//!
//! ```rust,no_run
//! use hologram_telemetry::{init_from_env, timed, count, info};
//!
//! // Initialize telemetry from environment variables
//! init_from_env().ok();
//!
//! // Use tracing macros
//! info!("Application started");
//!
//! // Time a block of code
//! let result = timed!("my_operation_ms", {
//!     // ... expensive operation ...
//!     42
//! });
//!
//! // Increment a counter
//! count!("operations_total");
//! ```

#![deny(missing_docs)]

#[cfg(feature = "alloc-tracking")]
pub mod alloc;
pub mod config;
pub mod exporters;
pub mod metrics;
pub mod middleware;
pub mod profiling;
pub mod tracing;

// Re-export tracing macros and types for convenience
pub use ::tracing::{debug, error, info, instrument, span, trace, warn, Level};

// Re-export our tracing initialization functions
pub use crate::tracing::{init_from_env, init_tracing, TracingConfig, TracingError};

// Re-export metrics types
pub use crate::metrics::{Histogram, HistogramSummary, MetricsRegistry};

// Re-export config types
pub use crate::config::{ExportFormat, LogLevel, TelemetryConfig};

// ============================================================================
// ZERO-OVERHEAD INSTRUMENTATION MACROS
// ============================================================================
// When the `instrumentation` feature is disabled, these macros compile to no-ops.
// This ensures zero performance overhead in production builds.

/// Time a block of code and record the duration as a metric.
///
/// When the `instrumentation` feature is disabled, this macro compiles to a no-op
/// that simply executes the block and returns its result.
///
/// # Example
///
/// ```rust
/// use hologram_telemetry::timed;
///
/// let result = timed!("my_operation_ms", {
///     // expensive operation
///     42
/// });
/// assert_eq!(result, 42);
/// ```
#[cfg(feature = "instrumentation")]
#[macro_export]
macro_rules! timed {
    ($name:expr, $block:expr) => {{
        let _start = std::time::Instant::now();
        let result = $block;
        $crate::metrics::MetricsRegistry::global().record_duration($name, _start.elapsed());
        result
    }};
}

/// Time a block of code (no-op when instrumentation is disabled).
#[cfg(not(feature = "instrumentation"))]
#[macro_export]
macro_rules! timed {
    ($name:expr, $block:expr) => {
        $block
    };
}

/// Increment a counter metric.
///
/// When the `instrumentation` feature is disabled, this macro compiles to a no-op.
///
/// # Example
///
/// ```rust
/// use hologram_telemetry::count;
///
/// // Increment by 1
/// count!("requests_total");
///
/// // Increment by a specific value
/// count!("bytes_processed", 1024);
/// ```
#[cfg(feature = "instrumentation")]
#[macro_export]
macro_rules! count {
    ($name:expr) => {
        $crate::metrics::MetricsRegistry::global().increment($name, 1)
    };
    ($name:expr, $value:expr) => {
        $crate::metrics::MetricsRegistry::global().increment($name, $value)
    };
}

/// Increment a counter metric (no-op when instrumentation is disabled).
#[cfg(not(feature = "instrumentation"))]
#[macro_export]
macro_rules! count {
    ($name:expr) => {};
    ($name:expr, $value:expr) => {};
}

/// Record throughput in bytes per second.
///
/// This macro times a block of code and records the throughput based on the
/// number of bytes processed. When the `instrumentation` feature is disabled,
/// this macro compiles to a no-op that simply executes the block.
///
/// # Example
///
/// ```rust
/// use hologram_telemetry::throughput;
///
/// let data = vec![0u8; 1024];
/// let result = throughput!("process_throughput", data.len(), {
///     // process data...
///     42
/// });
/// ```
#[cfg(feature = "instrumentation")]
#[macro_export]
macro_rules! throughput {
    ($name:expr, $bytes:expr, $block:expr) => {{
        let _start = std::time::Instant::now();
        let result = $block;
        let _elapsed = _start.elapsed();
        let _bytes_per_sec = ($bytes as f64) / _elapsed.as_secs_f64();
        $crate::metrics::MetricsRegistry::global()
            .record(concat!($name, "_bytes_per_sec"), _bytes_per_sec);
        $crate::metrics::MetricsRegistry::global()
            .record_duration(concat!($name, "_duration_ms"), _elapsed);
        result
    }};
}

/// Record throughput (no-op when instrumentation is disabled).
#[cfg(not(feature = "instrumentation"))]
#[macro_export]
macro_rules! throughput {
    ($name:expr, $bytes:expr, $block:expr) => {
        $block
    };
}

/// Track which SIMD code path was taken.
///
/// This macro records which SIMD implementation (AVX-512, AVX2, NEON, scalar)
/// was selected at runtime. Useful for understanding SIMD utilization.
///
/// When the `instrumentation` feature is disabled, this macro compiles to a no-op.
///
/// # Example
///
/// ```rust
/// use hologram_telemetry::simd_path;
///
/// // Record that AVX2 path was taken
/// simd_path!("avx2");
/// ```
#[cfg(feature = "instrumentation")]
#[macro_export]
macro_rules! simd_path {
    ($level:expr) => {
        $crate::metrics::MetricsRegistry::global().increment(concat!("simd_dispatch_", $level), 1)
    };
}

/// Track SIMD code path (no-op when instrumentation is disabled).
#[cfg(not(feature = "instrumentation"))]
#[macro_export]
macro_rules! simd_path {
    ($level:expr) => {};
}

/// Mark a code region as an allocation-free zone for zero-copy validation.
///
/// When the `alloc-tracking` feature is enabled, this macro tracks allocations
/// within the block and logs a warning if any allocations occur (indicating a
/// potential zero-copy violation).
///
/// When `alloc-tracking` is disabled, this macro compiles to a no-op that
/// simply executes the block.
///
/// # Example
///
/// ```rust
/// use hologram_telemetry::no_alloc_zone;
///
/// let result = no_alloc_zone!("hot_path", {
///     // This code should not allocate
///     42
/// });
/// ```
#[cfg(feature = "alloc-tracking")]
#[macro_export]
macro_rules! no_alloc_zone {
    ($context:expr, $block:expr) => {{
        let _guard = $crate::alloc::AllocationZoneGuard::new($context);
        $block
    }};
}

/// Allocation-free zone (no-op when alloc-tracking is disabled).
#[cfg(not(feature = "alloc-tracking"))]
#[macro_export]
macro_rules! no_alloc_zone {
    ($context:expr, $block:expr) => {
        $block
    };
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_timed_macro_returns_value() {
        // This test works with or without instrumentation feature
        // because timed! always returns the block's result
        let result = timed!("test_operation", { 42 });
        assert_eq!(result, 42);
    }

    #[test]
    #[cfg(feature = "instrumentation")]
    fn test_timed_macro_records_duration() {
        let registry = MetricsRegistry::global();

        // Clear any previous state by recording a known operation
        timed!("test_timed_duration", {
            std::thread::sleep(std::time::Duration::from_millis(1));
        });

        let histograms = registry.histograms();
        let found = histograms
            .iter()
            .any(|(name, _)| *name == "test_timed_duration");
        assert!(found, "Histogram should be recorded");
    }

    #[test]
    #[cfg(feature = "instrumentation")]
    fn test_count_macro_increments_by_one() {
        let registry = MetricsRegistry::global();
        let initial = registry
            .counters()
            .into_iter()
            .find(|(name, _)| *name == "test_count_one")
            .map(|(_, v)| v)
            .unwrap_or(0);

        count!("test_count_one");

        let after = registry
            .counters()
            .into_iter()
            .find(|(name, _)| *name == "test_count_one")
            .map(|(_, v)| v)
            .unwrap_or(0);

        assert_eq!(after, initial + 1);
    }

    #[test]
    #[cfg(feature = "instrumentation")]
    fn test_count_macro_increments_by_value() {
        let registry = MetricsRegistry::global();
        let initial = registry
            .counters()
            .into_iter()
            .find(|(name, _)| *name == "test_count_value")
            .map(|(_, v)| v)
            .unwrap_or(0);

        count!("test_count_value", 10);

        let after = registry
            .counters()
            .into_iter()
            .find(|(name, _)| *name == "test_count_value")
            .map(|(_, v)| v)
            .unwrap_or(0);

        assert_eq!(after, initial + 10);
    }

    #[test]
    fn test_tracing_config_default() {
        let config = TracingConfig::default();
        assert!(config.ansi);
        assert!(!config.file_line);
        assert!(config.target);
        assert!(!config.json);
    }

    #[test]
    fn test_tracing_macros_compile() {
        // Just verify that the re-exported macros compile
        trace!("trace message");
        debug!("debug message");
        info!("info message");
        warn!("warn message");
        error!("error message");
    }

    #[test]
    fn test_throughput_macro_returns_value() {
        // This test works with or without instrumentation feature
        let result = throughput!("test_throughput", 1024, { 42 });
        assert_eq!(result, 42);
    }

    #[test]
    fn test_simd_path_macro_compiles() {
        // Just verify the macro compiles (no-op when instrumentation disabled)
        simd_path!("avx2");
        simd_path!("scalar");
    }

    #[test]
    fn test_no_alloc_zone_macro_returns_value() {
        // This test works with or without alloc-tracking feature
        let result = no_alloc_zone!("test_zone", 42);
        assert_eq!(result, 42);
    }
}
