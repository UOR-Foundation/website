//! Low-level SIMD function benchmarks.
//!
//! Compares scalar vs SIMD implementations for:
//! - Arithmetic operations (add, sub, mul)
//! - Activation functions (sigmoid, tanh, relu)
//! - Reduction operations (sum, max, min)
//! - Transformer operations (sqrt, log, exp, abs, pow, elem_min, elem_max, greater, less, where)
//! - Parallel vs sequential execution crossover

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};

use hologram_backend::backends::cpu::{
    // Transformer operations
    abs_scalar,
    abs_simd,
    // Core arithmetic
    add_inplace_simd,
    add_parallel,
    add_scalar,
    add_simd,
    elem_max_scalar,
    elem_max_simd,
    elem_min_scalar,
    elem_min_simd,
    exp_scalar,
    exp_simd,
    greater_scalar,
    greater_simd,
    less_scalar,
    less_simd,
    log_scalar,
    log_simd,
    // Reductions
    max_scalar,
    max_simd,
    min_scalar,
    min_simd,
    mul_inplace_simd,
    mul_parallel,
    mul_scalar,
    mul_simd,
    pow_scalar,
    pow_simd,
    // Activations
    relu_parallel,
    relu_scalar,
    relu_simd,
    sigmoid_parallel,
    sigmoid_scalar,
    sigmoid_simd,
    sqrt_scalar,
    sqrt_simd,
    sub_scalar,
    sub_simd,
    sum_scalar,
    sum_simd,
    tanh_parallel,
    tanh_scalar,
    tanh_simd,
    where_scalar,
    where_simd,
};

/// Generate test data with specified size.
fn make_data(size: usize, seed: f32) -> Vec<f32> {
    (0..size).map(|i| seed + i as f32 * 0.001).collect()
}

// ============================================================================
// Reduction Benchmarks: Scalar vs SIMD
// ============================================================================

fn bench_reductions_simd_vs_scalar(c: &mut Criterion) {
    let mut group = c.benchmark_group("reductions/simd_vs_scalar");

    for size in [256, 1024, 4096, 16384, 65536] {
        group.throughput(Throughput::Elements(size as u64));

        let data = make_data(size, 1.0);

        // Sum
        group.bench_with_input(BenchmarkId::new("sum_scalar", size), &size, |b, _| {
            b.iter(|| sum_scalar(black_box(&data)))
        });

        group.bench_with_input(BenchmarkId::new("sum_simd", size), &size, |b, _| {
            b.iter(|| sum_simd(black_box(&data)))
        });

        // Max
        group.bench_with_input(BenchmarkId::new("max_scalar", size), &size, |b, _| {
            b.iter(|| max_scalar(black_box(&data)))
        });

        group.bench_with_input(BenchmarkId::new("max_simd", size), &size, |b, _| {
            b.iter(|| max_simd(black_box(&data)))
        });

        // Min
        group.bench_with_input(BenchmarkId::new("min_scalar", size), &size, |b, _| {
            b.iter(|| min_scalar(black_box(&data)))
        });

        group.bench_with_input(BenchmarkId::new("min_simd", size), &size, |b, _| {
            b.iter(|| min_simd(black_box(&data)))
        });
    }

    group.finish();
}

// ============================================================================
// Arithmetic Benchmarks: Scalar vs SIMD
// ============================================================================

fn bench_arithmetic_simd_vs_scalar(c: &mut Criterion) {
    let mut group = c.benchmark_group("arithmetic/simd_vs_scalar");

    for size in [256, 1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        let a = make_data(size, 1.0);
        let b = make_data(size, 2.0);
        let mut result = vec![0.0f32; size];

        // Add
        group.bench_with_input(BenchmarkId::new("add_scalar", size), &size, |bench, _| {
            bench.iter(|| add_scalar(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("add_simd", size), &size, |bench, _| {
            bench.iter(|| add_simd(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        // Sub
        group.bench_with_input(BenchmarkId::new("sub_scalar", size), &size, |bench, _| {
            bench.iter(|| sub_scalar(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("sub_simd", size), &size, |bench, _| {
            bench.iter(|| sub_simd(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        // Mul
        group.bench_with_input(BenchmarkId::new("mul_scalar", size), &size, |bench, _| {
            bench.iter(|| mul_scalar(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("mul_simd", size), &size, |bench, _| {
            bench.iter(|| mul_simd(black_box(&a), black_box(&b), black_box(&mut result)))
        });
    }

    group.finish();
}

// ============================================================================
// In-Place vs Scratch: Commutative Operations (TASK-324)
// ============================================================================

fn bench_inplace_vs_scratch(c: &mut Criterion) {
    let mut group = c.benchmark_group("arithmetic/inplace_vs_scratch");

    for size in [256, 1024, 4096, 16384, 65536] {
        group.throughput(Throughput::Elements(size as u64));

        let b = make_data(size, 2.0);

        // Add: 3-operand (out-of-place, separate result buffer)
        group.bench_with_input(BenchmarkId::new("add_3op", size), &size, |bench, _| {
            let a = make_data(size, 1.0);
            let mut result = vec![0.0f32; size];
            bench.iter(|| add_simd(black_box(&a), black_box(&b), black_box(&mut result)));
        });

        // Add: in-place (dst_a += b, no scratch buffer)
        group.bench_with_input(BenchmarkId::new("add_inplace", size), &size, |bench, _| {
            let mut dst_a = make_data(size, 1.0);
            bench.iter(|| {
                add_inplace_simd(black_box(&mut dst_a), black_box(&b));
            });
        });

        // Mul: 3-operand
        group.bench_with_input(BenchmarkId::new("mul_3op", size), &size, |bench, _| {
            let a = make_data(size, 1.0);
            let mut result = vec![0.0f32; size];
            bench.iter(|| mul_simd(black_box(&a), black_box(&b), black_box(&mut result)));
        });

        // Mul: in-place
        group.bench_with_input(BenchmarkId::new("mul_inplace", size), &size, |bench, _| {
            let mut dst_a = make_data(size, 1.0);
            bench.iter(|| {
                mul_inplace_simd(black_box(&mut dst_a), black_box(&b));
            });
        });
    }

    group.finish();
}

// ============================================================================
// Activation Benchmarks: Scalar vs SIMD
// ============================================================================

fn bench_activations_simd_vs_scalar(c: &mut Criterion) {
    let mut group = c.benchmark_group("activations/simd_vs_scalar");

    for size in [256, 1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        // Use inputs in the range where activations are well-behaved
        let data = make_data(size, -2.0);
        let mut result = vec![0.0f32; size];

        // ReLU
        group.bench_with_input(BenchmarkId::new("relu_scalar", size), &size, |bench, _| {
            bench.iter(|| relu_scalar(black_box(&data), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("relu_simd", size), &size, |bench, _| {
            bench.iter(|| relu_simd(black_box(&data), black_box(&mut result)))
        });

        // Sigmoid
        group.bench_with_input(
            BenchmarkId::new("sigmoid_scalar", size),
            &size,
            |bench, _| bench.iter(|| sigmoid_scalar(black_box(&data), black_box(&mut result))),
        );

        group.bench_with_input(BenchmarkId::new("sigmoid_simd", size), &size, |bench, _| {
            bench.iter(|| sigmoid_simd(black_box(&data), black_box(&mut result)))
        });

        // Tanh
        group.bench_with_input(BenchmarkId::new("tanh_scalar", size), &size, |bench, _| {
            bench.iter(|| tanh_scalar(black_box(&data), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("tanh_simd", size), &size, |bench, _| {
            bench.iter(|| tanh_simd(black_box(&data), black_box(&mut result)))
        });
    }

    group.finish();
}

// ============================================================================
// Parallel Threshold Benchmarks
// ============================================================================

fn bench_parallel_crossover(c: &mut Criterion) {
    let mut group = c.benchmark_group("parallel/crossover");

    // Test sizes around the parallel threshold (base 4096, scaled by threads)
    for size in [2048, 4096, 8192, 16384, 32768, 65536, 131072] {
        group.throughput(Throughput::Elements(size as u64));

        let a = make_data(size, 1.0);
        let b = make_data(size, 2.0);
        let mut result = vec![0.0f32; size];

        // Add: sequential vs parallel
        group.bench_with_input(BenchmarkId::new("add_simd", size), &size, |bench, _| {
            bench.iter(|| add_simd(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("add_parallel", size), &size, |bench, _| {
            bench.iter(|| add_parallel(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        // Mul: sequential vs parallel
        group.bench_with_input(BenchmarkId::new("mul_simd", size), &size, |bench, _| {
            bench.iter(|| mul_simd(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("mul_parallel", size), &size, |bench, _| {
            bench.iter(|| mul_parallel(black_box(&a), black_box(&b), black_box(&mut result)))
        });
    }

    group.finish();
}

fn bench_activation_parallel_crossover(c: &mut Criterion) {
    let mut group = c.benchmark_group("activations/parallel_crossover");

    for size in [2048, 4096, 8192, 16384, 32768, 65536] {
        group.throughput(Throughput::Elements(size as u64));

        let data = make_data(size, -2.0);
        let mut result = vec![0.0f32; size];

        // ReLU: sequential vs parallel
        group.bench_with_input(BenchmarkId::new("relu_simd", size), &size, |bench, _| {
            bench.iter(|| relu_simd(black_box(&data), black_box(&mut result)))
        });

        group.bench_with_input(
            BenchmarkId::new("relu_parallel", size),
            &size,
            |bench, _| bench.iter(|| relu_parallel(black_box(&data), black_box(&mut result))),
        );

        // Sigmoid: sequential vs parallel (more compute-intensive)
        group.bench_with_input(BenchmarkId::new("sigmoid_simd", size), &size, |bench, _| {
            bench.iter(|| sigmoid_simd(black_box(&data), black_box(&mut result)))
        });

        group.bench_with_input(
            BenchmarkId::new("sigmoid_parallel", size),
            &size,
            |bench, _| bench.iter(|| sigmoid_parallel(black_box(&data), black_box(&mut result))),
        );

        // Tanh: sequential vs parallel
        group.bench_with_input(BenchmarkId::new("tanh_simd", size), &size, |bench, _| {
            bench.iter(|| tanh_simd(black_box(&data), black_box(&mut result)))
        });

        group.bench_with_input(
            BenchmarkId::new("tanh_parallel", size),
            &size,
            |bench, _| bench.iter(|| tanh_parallel(black_box(&data), black_box(&mut result))),
        );
    }

    group.finish();
}

// ============================================================================
// Memory Bandwidth Benchmarks
// ============================================================================

fn bench_memory_bandwidth(c: &mut Criterion) {
    let mut group = c.benchmark_group("memory/bandwidth");

    // Test larger sizes to highlight memory bandwidth limits
    for size in [65536, 262144, 1048576] {
        let bytes = size * 4 * 3; // 3 arrays: a, b, result
        group.throughput(Throughput::Bytes(bytes as u64));

        let a = make_data(size, 1.0);
        let b = make_data(size, 2.0);
        let mut result = vec![0.0f32; size];

        // Simple add (memory-bound)
        group.bench_with_input(BenchmarkId::new("add_simd", size), &size, |bench, _| {
            bench.iter(|| add_simd(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        // With parallel execution
        group.bench_with_input(BenchmarkId::new("add_parallel", size), &size, |bench, _| {
            bench.iter(|| add_parallel(black_box(&a), black_box(&b), black_box(&mut result)))
        });
    }

    group.finish();
}

// ============================================================================
// Reduction Throughput (Large Arrays)
// ============================================================================

fn bench_reduction_large(c: &mut Criterion) {
    let mut group = c.benchmark_group("reductions/large");

    for size in [65536, 262144, 1048576] {
        group.throughput(Throughput::Elements(size as u64));

        let data = make_data(size, 1.0);

        group.bench_with_input(BenchmarkId::new("sum_simd", size), &size, |b, _| {
            b.iter(|| sum_simd(black_box(&data)))
        });

        group.bench_with_input(BenchmarkId::new("max_simd", size), &size, |b, _| {
            b.iter(|| max_simd(black_box(&data)))
        });

        group.bench_with_input(BenchmarkId::new("min_simd", size), &size, |b, _| {
            b.iter(|| min_simd(black_box(&data)))
        });
    }

    group.finish();
}

// ============================================================================
// Cache Behavior Benchmarks: Stride Patterns (TASK-164)
// ============================================================================

fn bench_cache_stride_patterns(c: &mut Criterion) {
    let mut group = c.benchmark_group("cache/stride_patterns");

    let size = 65536; // Large enough to exceed L1 cache
    let data = make_data(size, 1.0);
    let b_data = make_data(size, 2.0);

    // Sequential access (stride 1) - optimal cache usage
    group.bench_function("stride_1_add", |bench| {
        let mut result = vec![0.0f32; size];
        bench.iter(|| {
            add_simd(black_box(&data), black_box(&b_data), black_box(&mut result));
            black_box(result[0])
        })
    });

    // Stride 2 - every other element
    group.bench_function("stride_2_add", |bench| {
        let len = data.len() / 2;
        let mut result = vec![0.0f32; len];
        bench.iter(|| {
            for i in 0..len {
                result[i] = data[i * 2] + b_data[i * 2];
            }
            black_box(result[0])
        })
    });

    // Stride 4 - every 4th element (typical SIMD width)
    group.bench_function("stride_4_add", |bench| {
        let len = data.len() / 4;
        let mut result = vec![0.0f32; len];
        bench.iter(|| {
            for i in 0..len {
                result[i] = data[i * 4] + b_data[i * 4];
            }
            black_box(result[0])
        })
    });

    // Stride 8 - every 8th element (AVX2 width)
    group.bench_function("stride_8_add", |bench| {
        let len = data.len() / 8;
        let mut result = vec![0.0f32; len];
        bench.iter(|| {
            for i in 0..len {
                result[i] = data[i * 8] + b_data[i * 8];
            }
            black_box(result[0])
        })
    });

    // Stride 16 - cache line stride (64 bytes / 4 bytes = 16 floats)
    group.bench_function("stride_16_cache_line", |bench| {
        let len = data.len() / 16;
        let mut result = vec![0.0f32; len];
        bench.iter(|| {
            for i in 0..len {
                result[i] = data[i * 16] + b_data[i * 16];
            }
            black_box(result[0])
        })
    });

    // Stride 64 - 4 cache lines apart (256 bytes)
    group.bench_function("stride_64_multi_line", |bench| {
        let len = data.len() / 64;
        let mut result = vec![0.0f32; len];
        bench.iter(|| {
            for i in 0..len {
                result[i] = data[i * 64] + b_data[i * 64];
            }
            black_box(result[0])
        })
    });

    group.finish();
}

// ============================================================================
// Cache Behavior Benchmarks: Alignment Effects (TASK-164)
// ============================================================================

fn bench_cache_alignment_effects(c: &mut Criterion) {
    let mut group = c.benchmark_group("cache/alignment_effects");

    let size = 65536 + 64; // Extra for misaligned access
    let data: Vec<f32> = (0..size).map(|i| i as f32 * 0.001).collect();
    let b: Vec<f32> = (0..size).map(|i| (i as f32 + 1.0) * 0.001).collect();

    // Test different alignments relative to cache line
    // Cache lines are 64 bytes = 16 floats

    // Aligned start (offset 0)
    group.bench_function("aligned_0", |bench| {
        let mut result = vec![0.0f32; 4096];
        let slice_a = &data[0..4096];
        let slice_b = &b[0..4096];
        bench.iter(|| {
            add_simd(
                black_box(slice_a),
                black_box(slice_b),
                black_box(&mut result),
            )
        })
    });

    // Offset 1 float (4 bytes misaligned)
    group.bench_function("misaligned_1", |bench| {
        let mut result = vec![0.0f32; 4096];
        let slice_a = &data[1..4097];
        let slice_b = &b[1..4097];
        bench.iter(|| {
            add_simd(
                black_box(slice_a),
                black_box(slice_b),
                black_box(&mut result),
            )
        })
    });

    // Offset 4 floats (16 bytes = SIMD boundary for SSE)
    group.bench_function("aligned_4_sse", |bench| {
        let mut result = vec![0.0f32; 4096];
        let slice_a = &data[4..4100];
        let slice_b = &b[4..4100];
        bench.iter(|| {
            add_simd(
                black_box(slice_a),
                black_box(slice_b),
                black_box(&mut result),
            )
        })
    });

    // Offset 7 floats (28 bytes - neither SSE nor AVX aligned)
    group.bench_function("misaligned_7", |bench| {
        let mut result = vec![0.0f32; 4096];
        let slice_a = &data[7..4103];
        let slice_b = &b[7..4103];
        bench.iter(|| {
            add_simd(
                black_box(slice_a),
                black_box(slice_b),
                black_box(&mut result),
            )
        })
    });

    // Offset 8 floats (32 bytes = AVX2 boundary)
    group.bench_function("aligned_8_avx2", |bench| {
        let mut result = vec![0.0f32; 4096];
        let slice_a = &data[8..4104];
        let slice_b = &b[8..4104];
        bench.iter(|| {
            add_simd(
                black_box(slice_a),
                black_box(slice_b),
                black_box(&mut result),
            )
        })
    });

    // Offset 16 floats (64 bytes = cache line boundary)
    group.bench_function("aligned_16_cache_line", |bench| {
        let mut result = vec![0.0f32; 4096];
        let slice_a = &data[16..4112];
        let slice_b = &b[16..4112];
        bench.iter(|| {
            add_simd(
                black_box(slice_a),
                black_box(slice_b),
                black_box(&mut result),
            )
        })
    });

    group.finish();
}

// ============================================================================
// Cache Working Set Size Benchmarks (TASK-164)
// ============================================================================

fn bench_cache_working_set(c: &mut Criterion) {
    let mut group = c.benchmark_group("cache/working_set");

    // Different sizes to test L1, L2, L3 cache and main memory
    // L1: ~32 KB, L2: ~256 KB, L3: varies (8-32 MB typically)
    let sizes = [
        1024,    // 4 KB - fits in L1
        8192,    // 32 KB - fills L1
        16384,   // 64 KB - exceeds L1, fits in L2
        65536,   // 256 KB - fills L2
        262144,  // 1 MB - exceeds L2, fits in L3
        1048576, // 4 MB - fills portion of L3
        4194304, // 16 MB - may exceed L3
    ];

    for &size in &sizes {
        let data = make_data(size, 1.0);
        let b = make_data(size, 2.0);
        let mut result = vec![0.0f32; size];

        // Report both elements and bytes for memory analysis
        group.throughput(Throughput::Elements(size as u64));

        group.bench_with_input(BenchmarkId::new("add_simd", size), &size, |bench, _| {
            bench.iter(|| add_simd(black_box(&data), black_box(&b), black_box(&mut result)))
        });

        // Also test reduction (single output, tests read bandwidth only)
        group.bench_with_input(BenchmarkId::new("sum_simd", size), &size, |bench, _| {
            bench.iter(|| sum_simd(black_box(&data)))
        });
    }

    group.finish();
}

// ============================================================================
// Prefetch Distance Effects (TASK-164)
// ============================================================================

fn bench_prefetch_effects(c: &mut Criterion) {
    let mut group = c.benchmark_group("cache/prefetch_effects");

    let size = 262144; // 1 MB - larger than L2
    let data = make_data(size, 1.0);

    // Sequential forward scan (hardware prefetcher optimal)
    group.bench_function("forward_scan", |bench| {
        bench.iter(|| {
            let mut acc = 0.0f32;
            for &v in data.iter() {
                acc += v;
            }
            black_box(acc)
        })
    });

    // Reverse scan (may confuse some prefetchers)
    group.bench_function("reverse_scan", |bench| {
        bench.iter(|| {
            let mut acc = 0.0f32;
            for &v in data.iter().rev() {
                acc += v;
            }
            black_box(acc)
        })
    });

    // Random-ish access pattern (defeats prefetching)
    // Uses a deterministic but non-sequential pattern
    group.bench_function("scattered_access", |bench| {
        // Generate indices with a stride that causes scattered access
        let indices: Vec<usize> = (0..size / 16)
            .map(|i| (i * 7919) % size) // Prime number stride
            .collect();

        bench.iter(|| {
            let mut acc = 0.0f32;
            for &idx in &indices {
                acc += data[idx];
            }
            black_box(acc)
        })
    });

    group.finish();
}

// ============================================================================
// Transformer Operations: Scalar vs SIMD
// ============================================================================

/// Generate positive test data for operations like sqrt, log that require positive inputs.
fn make_positive_data(size: usize, seed: f32) -> Vec<f32> {
    (0..size)
        .map(|i| (seed + i as f32 * 0.001).abs() + 0.1)
        .collect()
}

fn bench_transformer_unary_simd_vs_scalar(c: &mut Criterion) {
    let mut group = c.benchmark_group("transformer/unary_simd_vs_scalar");

    for size in [256, 1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        // Positive data for sqrt/log (they require positive inputs)
        let positive_data = make_positive_data(size, 1.0);
        // General data for exp/abs (works with any input)
        let data = make_data(size, -2.0);
        let mut result = vec![0.0f32; size];

        // Sqrt
        group.bench_with_input(BenchmarkId::new("sqrt_scalar", size), &size, |bench, _| {
            bench.iter(|| sqrt_scalar(black_box(&positive_data), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("sqrt_simd", size), &size, |bench, _| {
            bench.iter(|| sqrt_simd(black_box(&positive_data), black_box(&mut result)))
        });

        // Log
        group.bench_with_input(BenchmarkId::new("log_scalar", size), &size, |bench, _| {
            bench.iter(|| log_scalar(black_box(&positive_data), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("log_simd", size), &size, |bench, _| {
            bench.iter(|| log_simd(black_box(&positive_data), black_box(&mut result)))
        });

        // Exp
        group.bench_with_input(BenchmarkId::new("exp_scalar", size), &size, |bench, _| {
            bench.iter(|| exp_scalar(black_box(&data), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("exp_simd", size), &size, |bench, _| {
            bench.iter(|| exp_simd(black_box(&data), black_box(&mut result)))
        });

        // Abs
        group.bench_with_input(BenchmarkId::new("abs_scalar", size), &size, |bench, _| {
            bench.iter(|| abs_scalar(black_box(&data), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("abs_simd", size), &size, |bench, _| {
            bench.iter(|| abs_simd(black_box(&data), black_box(&mut result)))
        });
    }

    group.finish();
}

fn bench_transformer_binary_simd_vs_scalar(c: &mut Criterion) {
    let mut group = c.benchmark_group("transformer/binary_simd_vs_scalar");

    for size in [256, 1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        let a = make_positive_data(size, 1.0);
        let b = make_positive_data(size, 0.5);
        let mut result = vec![0.0f32; size];

        // Pow
        group.bench_with_input(BenchmarkId::new("pow_scalar", size), &size, |bench, _| {
            bench.iter(|| pow_scalar(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("pow_simd", size), &size, |bench, _| {
            bench.iter(|| pow_simd(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        // ElemMin
        group.bench_with_input(
            BenchmarkId::new("elem_min_scalar", size),
            &size,
            |bench, _| {
                bench.iter(|| elem_min_scalar(black_box(&a), black_box(&b), black_box(&mut result)))
            },
        );

        group.bench_with_input(
            BenchmarkId::new("elem_min_simd", size),
            &size,
            |bench, _| {
                bench.iter(|| elem_min_simd(black_box(&a), black_box(&b), black_box(&mut result)))
            },
        );

        // ElemMax
        group.bench_with_input(
            BenchmarkId::new("elem_max_scalar", size),
            &size,
            |bench, _| {
                bench.iter(|| elem_max_scalar(black_box(&a), black_box(&b), black_box(&mut result)))
            },
        );

        group.bench_with_input(
            BenchmarkId::new("elem_max_simd", size),
            &size,
            |bench, _| {
                bench.iter(|| elem_max_simd(black_box(&a), black_box(&b), black_box(&mut result)))
            },
        );
    }

    group.finish();
}

fn bench_transformer_comparison_simd_vs_scalar(c: &mut Criterion) {
    let mut group = c.benchmark_group("transformer/comparison_simd_vs_scalar");

    for size in [256, 1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        let a = make_data(size, 1.0);
        let b = make_data(size, 2.0);
        let mut result = vec![0.0f32; size];

        // Greater
        group.bench_with_input(
            BenchmarkId::new("greater_scalar", size),
            &size,
            |bench, _| {
                bench.iter(|| greater_scalar(black_box(&a), black_box(&b), black_box(&mut result)))
            },
        );

        group.bench_with_input(BenchmarkId::new("greater_simd", size), &size, |bench, _| {
            bench.iter(|| greater_simd(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        // Less
        group.bench_with_input(BenchmarkId::new("less_scalar", size), &size, |bench, _| {
            bench.iter(|| less_scalar(black_box(&a), black_box(&b), black_box(&mut result)))
        });

        group.bench_with_input(BenchmarkId::new("less_simd", size), &size, |bench, _| {
            bench.iter(|| less_simd(black_box(&a), black_box(&b), black_box(&mut result)))
        });
    }

    group.finish();
}

fn bench_transformer_where_simd_vs_scalar(c: &mut Criterion) {
    let mut group = c.benchmark_group("transformer/where_simd_vs_scalar");

    for size in [256, 1024, 4096, 16384] {
        group.throughput(Throughput::Elements(size as u64));

        // Condition: alternating 1.0 and 0.0
        let cond: Vec<f32> = (0..size)
            .map(|i| if i % 2 == 0 { 1.0 } else { 0.0 })
            .collect();
        let x = make_data(size, 1.0);
        let y = make_data(size, 2.0);
        let mut result = vec![0.0f32; size];

        group.bench_with_input(BenchmarkId::new("where_scalar", size), &size, |bench, _| {
            bench.iter(|| {
                where_scalar(
                    black_box(&cond),
                    black_box(&x),
                    black_box(&y),
                    black_box(&mut result),
                )
            })
        });

        group.bench_with_input(BenchmarkId::new("where_simd", size), &size, |bench, _| {
            bench.iter(|| {
                where_simd(
                    black_box(&cond),
                    black_box(&x),
                    black_box(&y),
                    black_box(&mut result),
                )
            })
        });
    }

    group.finish();
}

criterion_group!(
    benches,
    bench_reductions_simd_vs_scalar,
    bench_arithmetic_simd_vs_scalar,
    bench_inplace_vs_scratch,
    bench_activations_simd_vs_scalar,
    bench_parallel_crossover,
    bench_activation_parallel_crossover,
    bench_memory_bandwidth,
    bench_reduction_large,
    // TASK-164: Cache behavior analysis
    bench_cache_stride_patterns,
    bench_cache_alignment_effects,
    bench_cache_working_set,
    bench_prefetch_effects,
    // Transformer operations benchmarks
    bench_transformer_unary_simd_vs_scalar,
    bench_transformer_binary_simd_vs_scalar,
    bench_transformer_comparison_simd_vs_scalar,
    bench_transformer_where_simd_vs_scalar,
);
criterion_main!(benches);
