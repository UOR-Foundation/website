//! HTML rendering for server-side views.

pub mod render;
pub mod templates;

pub use render::*;
