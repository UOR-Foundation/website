//! Elementwise operations: xor, and, or, not, add, sub, shl, shr, rotl, rotr.
//!
//! Each operation uses portable byte-level code. Future `x86_64` wavefront
//! acceleration will be added via `UorStepBinary` (TASK-012).
//!
//! # Binary operations
//!
//! ```
//! use prism::state::State;
//! use prism::ops::elementwise;
//!
//! let a = State::ones();
//! let b = State::zeros();
//! let result = elementwise::xor(a, b);
//! assert_eq!(result, a);
//! ```
//!
//! # Shift/rotate operations
//!
//! ```
//! use prism::state::State;
//! use prism::ops::elementwise;
//!
//! let s = State::zeros();
//! let result = elementwise::shl(s, 1);
//! assert_eq!(result, s); // shifting zeros gives zeros
//! ```

use crate::ops::{BinaryOperation, ConformanceTargets, Operation};
use crate::state::State;

const ALU_TARGETS: ConformanceTargets = ConformanceTargets {
    minimum: 3,
    optimal: 2,
    theoretical: 1,
};

const SHIFT_TARGETS: ConformanceTargets = ConformanceTargets {
    minimum: 5,
    optimal: 3,
    theoretical: 1,
};

/// Number of 32-bit lanes in a state (624 / 4 = 156).
const LANES: usize = State::LEN / 4;

// ---------------------------------------------------------------------------
// Binary operations
// ---------------------------------------------------------------------------

/// Bitwise XOR of two states.
///
/// ```
/// use prism::state::State;
/// use prism::ops::elementwise::xor;
///
/// let a = State::ones();
/// let b = State::ones();
/// assert_eq!(xor(a, b), State::zeros());
/// ```
#[inline]
#[must_use]
pub fn xor(a: State, b: State) -> State {
    binary_byte_op(&a, &b, |x, y| x ^ y)
}

/// Bitwise AND of two states.
///
/// ```
/// use prism::state::State;
/// use prism::ops::elementwise::and;
///
/// let a = State::ones();
/// let b = State::zeros();
/// assert_eq!(and(a, b), State::zeros());
/// ```
#[inline]
#[must_use]
pub fn and(a: State, b: State) -> State {
    binary_byte_op(&a, &b, |x, y| x & y)
}

/// Bitwise OR of two states.
///
/// ```
/// use prism::state::State;
/// use prism::ops::elementwise::or;
///
/// let a = State::zeros();
/// let b = State::ones();
/// assert_eq!(or(a, b), State::ones());
/// ```
#[inline]
#[must_use]
pub fn or(a: State, b: State) -> State {
    binary_byte_op(&a, &b, |x, y| x | y)
}

/// Wrapping byte-level addition of two states.
///
/// ```
/// use prism::state::State;
/// use prism::ops::elementwise::add;
///
/// let a = State::from_bytes(&[200]);
/// let b = State::from_bytes(&[100]);
/// let r = add(a, b);
/// assert_eq!(r.as_bytes()[0], 44); // 200 + 100 = 300 -> 44 (mod 256)
/// ```
#[inline]
#[must_use]
pub fn add(a: State, b: State) -> State {
    binary_byte_op(&a, &b, u8::wrapping_add)
}

/// Wrapping byte-level subtraction of two states.
///
/// ```
/// use prism::state::State;
/// use prism::ops::elementwise::sub;
///
/// let a = State::from_bytes(&[10]);
/// let b = State::from_bytes(&[20]);
/// let r = sub(a, b);
/// assert_eq!(r.as_bytes()[0], 246); // 10 - 20 = -10 -> 246 (mod 256)
/// ```
#[inline]
#[must_use]
pub fn sub(a: State, b: State) -> State {
    binary_byte_op(&a, &b, u8::wrapping_sub)
}

/// Bitwise NOT (complement) of a state.
///
/// ```
/// use prism::state::State;
/// use prism::ops::elementwise::not;
///
/// let s = State::zeros();
/// assert_eq!(not(s), State::ones());
/// assert_eq!(not(not(s)), s);
/// ```
#[inline]
#[must_use]
pub fn not(state: State) -> State {
    unary_byte_op(&state, |b| !b)
}

// ---------------------------------------------------------------------------
// Shift/rotate on 32-bit lanes
// ---------------------------------------------------------------------------

/// Shift left each 32-bit lane by `n` bits.
///
/// ```
/// use prism::state::State;
/// use prism::ops::elementwise::shl;
///
/// let s = State::from_bytes(&[0x01, 0x00, 0x00, 0x00]);
/// let r = shl(s, 4);
/// assert_eq!(r.as_bytes()[0], 0x10);
/// ```
#[inline]
#[must_use]
pub fn shl(state: State, n: u32) -> State {
    lane_op(&state, |lane| lane << (n & 31))
}

/// Shift right each 32-bit lane by `n` bits.
///
/// ```
/// use prism::state::State;
/// use prism::ops::elementwise::shr;
///
/// let s = State::from_bytes(&[0x10, 0x00, 0x00, 0x00]);
/// let r = shr(s, 4);
/// assert_eq!(r.as_bytes()[0], 0x01);
/// ```
#[inline]
#[must_use]
pub fn shr(state: State, n: u32) -> State {
    lane_op(&state, |lane| lane >> (n & 31))
}

/// Rotate left each 32-bit lane by `n` bits.
///
/// ```
/// use prism::state::State;
/// use prism::ops::elementwise::rotl;
///
/// // 0x00000080 in little-endian, rotated left 1 = 0x00000100
/// let s = State::from_bytes(&[0x80, 0x00, 0x00, 0x00]);
/// let r = rotl(s, 1);
/// assert_eq!(r.as_bytes()[0], 0x00);
/// assert_eq!(r.as_bytes()[1], 0x01);
/// ```
#[inline]
#[must_use]
pub fn rotl(state: State, n: u32) -> State {
    lane_op(&state, |lane| lane.rotate_left(n & 31))
}

/// Rotate right each 32-bit lane by `n` bits.
///
/// ```
/// use prism::state::State;
/// use prism::ops::elementwise::rotr;
///
/// // 0x00000001 rotated right 1 = 0x80000000
/// let s = State::from_bytes(&[0x01, 0x00, 0x00, 0x00]);
/// let r = rotr(s, 1);
/// assert_eq!(r.as_bytes()[3], 0x80);
/// assert_eq!(r.as_bytes()[0], 0x00);
/// ```
#[inline]
#[must_use]
pub fn rotr(state: State, n: u32) -> State {
    lane_op(&state, |lane| lane.rotate_right(n & 31))
}

// ---------------------------------------------------------------------------
// Struct wrappers implementing Operation / BinaryOperation
// ---------------------------------------------------------------------------

/// XOR operation type (implements [`BinaryOperation`]).
pub struct XorOp;

impl BinaryOperation for XorOp {
    const NAME: &'static str = "xor";
    const TARGETS: ConformanceTargets = ALU_TARGETS;
    fn apply(&self, a: State, b: State) -> State {
        xor(a, b)
    }
}

/// AND operation type (implements [`BinaryOperation`]).
pub struct AndOp;

impl BinaryOperation for AndOp {
    const NAME: &'static str = "and";
    const TARGETS: ConformanceTargets = ALU_TARGETS;
    fn apply(&self, a: State, b: State) -> State {
        and(a, b)
    }
}

/// OR operation type (implements [`BinaryOperation`]).
pub struct OrOp;

impl BinaryOperation for OrOp {
    const NAME: &'static str = "or";
    const TARGETS: ConformanceTargets = ALU_TARGETS;
    fn apply(&self, a: State, b: State) -> State {
        or(a, b)
    }
}

/// ADD operation type (implements [`BinaryOperation`]).
pub struct AddOp;

impl BinaryOperation for AddOp {
    const NAME: &'static str = "add";
    const TARGETS: ConformanceTargets = ALU_TARGETS;
    fn apply(&self, a: State, b: State) -> State {
        add(a, b)
    }
}

/// SUB operation type (implements [`BinaryOperation`]).
pub struct SubOp;

impl BinaryOperation for SubOp {
    const NAME: &'static str = "sub";
    const TARGETS: ConformanceTargets = ALU_TARGETS;
    fn apply(&self, a: State, b: State) -> State {
        sub(a, b)
    }
}

/// NOT operation type (implements [`Operation`]).
pub struct NotOp;

impl Operation for NotOp {
    const NAME: &'static str = "not";
    const TARGETS: ConformanceTargets = ALU_TARGETS;
    fn apply(&self, state: State) -> State {
        not(state)
    }
}

/// Shift-left operation type (implements [`Operation`]).
///
/// Wraps a fixed shift amount.
pub struct ShlOp(pub u32);

impl Operation for ShlOp {
    const NAME: &'static str = "shl";
    const TARGETS: ConformanceTargets = SHIFT_TARGETS;
    fn apply(&self, state: State) -> State {
        shl(state, self.0)
    }
}

/// Shift-right operation type (implements [`Operation`]).
pub struct ShrOp(pub u32);

impl Operation for ShrOp {
    const NAME: &'static str = "shr";
    const TARGETS: ConformanceTargets = SHIFT_TARGETS;
    fn apply(&self, state: State) -> State {
        shr(state, self.0)
    }
}

/// Rotate-left operation type (implements [`Operation`]).
pub struct RotlOp(pub u32);

impl Operation for RotlOp {
    const NAME: &'static str = "rotl";
    const TARGETS: ConformanceTargets = SHIFT_TARGETS;
    fn apply(&self, state: State) -> State {
        rotl(state, self.0)
    }
}

/// Rotate-right operation type (implements [`Operation`]).
pub struct RotrOp(pub u32);

impl Operation for RotrOp {
    const NAME: &'static str = "rotr";
    const TARGETS: ConformanceTargets = SHIFT_TARGETS;
    fn apply(&self, state: State) -> State {
        rotr(state, self.0)
    }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

#[inline]
fn binary_byte_op(a: &State, b: &State, f: fn(u8, u8) -> u8) -> State {
    let mut result = State::zeros();
    let ra = a.as_bytes();
    let rb = b.as_bytes();
    let out = result.as_bytes_mut();
    for i in 0..State::LEN {
        out[i] = f(ra[i], rb[i]);
    }
    result
}

#[inline]
fn unary_byte_op(state: &State, f: fn(u8) -> u8) -> State {
    let mut result = State::zeros();
    let src = state.as_bytes();
    let out = result.as_bytes_mut();
    for i in 0..State::LEN {
        out[i] = f(src[i]);
    }
    result
}

#[inline]
fn lane_op(state: &State, f: impl Fn(u32) -> u32) -> State {
    let mut result = State::zeros();
    let src = state.as_bytes();
    let out = result.as_bytes_mut();
    for i in 0..LANES {
        let base = i * 4;
        let lane = u32::from_le_bytes([src[base], src[base + 1], src[base + 2], src[base + 3]]);
        let val = f(lane);
        let bytes = val.to_le_bytes();
        out[base] = bytes[0];
        out[base + 1] = bytes[1];
        out[base + 2] = bytes[2];
        out[base + 3] = bytes[3];
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_xor_zeros() {
        let a = State::zeros();
        let b = State::zeros();
        assert_eq!(xor(a, b), State::zeros());
    }

    #[test]
    fn test_xor_identity() {
        let a = State::ones();
        let b = State::zeros();
        assert_eq!(xor(a, b), a);
    }

    #[test]
    fn test_xor_self_inverse() {
        let a = State::from_bytes(&[0xAB; 624]);
        assert_eq!(xor(a, a), State::zeros());
    }

    #[test]
    fn test_and_with_zeros() {
        let a = State::ones();
        let b = State::zeros();
        assert_eq!(and(a, b), State::zeros());
    }

    #[test]
    fn test_and_with_ones() {
        let a = State::from_bytes(&[0x55; 624]);
        let b = State::ones();
        assert_eq!(and(a, b), a);
    }

    #[test]
    fn test_or_with_zeros() {
        let a = State::from_bytes(&[0xAA; 624]);
        assert_eq!(or(a, State::zeros()), a);
    }

    #[test]
    fn test_or_with_ones() {
        let a = State::from_bytes(&[0x55; 624]);
        assert_eq!(or(a, State::ones()), State::ones());
    }

    #[test]
    fn test_not_involution() {
        let s = State::from_bytes(&[0xDE; 624]);
        assert_eq!(not(not(s)), s);
    }

    #[test]
    fn test_not_zeros_gives_ones() {
        assert_eq!(not(State::zeros()), State::ones());
    }

    #[test]
    fn test_add_wrapping() {
        let a = State::from_bytes(&[200]);
        let b = State::from_bytes(&[100]);
        assert_eq!(add(a, b).as_bytes()[0], 44);
    }

    #[test]
    fn test_add_zero_identity() {
        let a = State::from_bytes(&[42; 624]);
        assert_eq!(add(a, State::zeros()), a);
    }

    #[test]
    fn test_sub_inverse_add() {
        let a = State::from_bytes(&[50; 624]);
        let b = State::from_bytes(&[30; 624]);
        assert_eq!(sub(add(a, b), b), a);
    }

    #[test]
    fn test_shl_basic() {
        let s = State::from_bytes(&[0x01, 0x00, 0x00, 0x00]);
        let r = shl(s, 8);
        assert_eq!(r.as_bytes()[0], 0x00);
        assert_eq!(r.as_bytes()[1], 0x01);
    }

    #[test]
    fn test_shr_basic() {
        let s = State::from_bytes(&[0x00, 0x01, 0x00, 0x00]);
        let r = shr(s, 8);
        assert_eq!(r.as_bytes()[0], 0x01);
    }

    #[test]
    fn test_shl_zero_shift() {
        let s = State::from_bytes(&[0xAB; 624]);
        assert_eq!(shl(s, 0), s);
    }

    #[test]
    fn test_shr_zero_shift() {
        let s = State::from_bytes(&[0xAB; 624]);
        assert_eq!(shr(s, 0), s);
    }

    #[test]
    fn test_rotl_rotr_inverse() {
        let s = State::from_bytes(&[0xDE, 0xAD, 0xBE, 0xEF]);
        assert_eq!(rotr(rotl(s, 7), 7), s);
    }

    #[test]
    fn test_rotl_zero_rotation() {
        let s = State::from_bytes(&[0x12, 0x34, 0x56, 0x78]);
        assert_eq!(rotl(s, 0), s);
    }

    #[test]
    fn test_rotr_full_rotation() {
        let s = State::from_bytes(&[0xAB, 0xCD, 0xEF, 0x01]);
        assert_eq!(rotr(s, 32), s);
    }

    #[test]
    fn test_rotl_bit_pattern() {
        // 0x80000000 rotated left 1 = 0x00000001
        let s = State::from_bytes(&[0x00, 0x00, 0x00, 0x80]);
        let r = rotl(s, 1);
        assert_eq!(r.as_bytes()[0], 0x01);
        assert_eq!(r.as_bytes()[1], 0x00);
        assert_eq!(r.as_bytes()[2], 0x00);
        assert_eq!(r.as_bytes()[3], 0x00);
    }

    // Op struct tests

    #[test]
    fn test_xor_op_trait() {
        let op = XorOp;
        let a = State::ones();
        let b = State::ones();
        assert_eq!(op.apply(a, b), State::zeros());
        assert_eq!(XorOp::NAME, "xor");
    }

    #[test]
    fn test_not_op_trait() {
        let op = NotOp;
        assert_eq!(op.apply(State::zeros()), State::ones());
        assert_eq!(NotOp::NAME, "not");
    }

    #[test]
    fn test_shl_op_trait() {
        let op = ShlOp(4);
        let s = State::from_bytes(&[0x01, 0x00, 0x00, 0x00]);
        let r = op.apply(s);
        assert_eq!(r.as_bytes()[0], 0x10);
        assert_eq!(ShlOp::NAME, "shl");
    }

    #[test]
    fn test_rotl_op_trait() {
        let op = RotlOp(1);
        assert_eq!(RotlOp::NAME, "rotl");
        let s = State::from_bytes(&[0x00, 0x00, 0x00, 0x80]);
        let r = op.apply(s);
        assert_eq!(r.as_bytes()[0], 0x01);
    }
}
