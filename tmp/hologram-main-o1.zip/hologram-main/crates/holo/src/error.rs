//! Error types for holo operations.

use thiserror::Error;

/// Errors that can occur when building instructions.
#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum BuilderError {
    /// A required field was not set.
    #[error("missing required field: {0}")]
    MissingField(&'static str),

    /// A field value is invalid.
    #[error("invalid {field}: {reason}")]
    InvalidValue {
        /// Field name.
        field: &'static str,
        /// Reason the value is invalid.
        reason: &'static str,
    },
}

impl BuilderError {
    /// Create a missing field error.
    #[must_use]
    pub const fn missing_field(field: &'static str) -> Self {
        Self::MissingField(field)
    }

    /// Create an invalid value error.
    #[must_use]
    pub const fn invalid_value(field: &'static str, reason: &'static str) -> Self {
        Self::InvalidValue { field, reason }
    }
}

/// Errors that can occur during `.holo` file operations.
#[derive(Debug, Error)]
pub enum HoloError {
    /// Invalid file format (magic bytes don't match)
    #[error("Invalid file format: expected {expected}, found {found}")]
    InvalidFormat {
        /// Expected magic bytes
        expected: String,
        /// Found magic bytes
        found: String,
    },

    /// Checksum mismatch
    #[error("Checksum mismatch: expected {expected:08x}, computed {computed:08x}")]
    ChecksumMismatch {
        /// Expected checksum
        expected: u32,
        /// Computed checksum
        computed: u32,
    },

    /// Section checksum mismatch
    #[error("Section '{section_id}' checksum mismatch: expected {expected:08x}, computed {computed:08x}")]
    SectionChecksumMismatch {
        /// Section identifier
        section_id: String,
        /// Expected checksum
        expected: u32,
        /// Computed checksum
        computed: u32,
    },

    /// Invalid offset or size
    #[error("Invalid offset/size: offset={offset}, size={size}, file_size={file_size}")]
    InvalidOffsetOrSize {
        /// Requested offset
        offset: usize,
        /// Requested size
        size: usize,
        /// Actual file size
        file_size: usize,
    },

    /// Layer not found
    #[error("Layer not found: {layer_id}")]
    LayerNotFound {
        /// Layer ID (hex-encoded SHA-256)
        layer_id: String,
    },

    /// Section not found
    #[error("Section not found: {id}")]
    SectionNotFound {
        /// Section identifier
        id: String,
    },

    /// Model not found in pipeline
    #[error("Model not found: {name}")]
    ModelNotFound {
        /// Model name
        name: String,
    },

    /// Duplicate model in pipeline
    #[error("Duplicate model: {name}")]
    DuplicateModel {
        /// Model name
        name: String,
    },

    /// Table truncated
    #[error("Table truncated: expected {expected} bytes, got {actual}")]
    TableTruncated {
        /// Expected size
        expected: usize,
        /// Actual size
        actual: usize,
    },

    /// Unsupported version
    #[error("Unsupported version: {version}")]
    UnsupportedVersion {
        /// Version number
        version: u32,
    },

    /// Empty bundle (no data)
    #[error("Empty bundle: no models or data")]
    EmptyBundle,

    /// File too small for expected structure
    #[error("File too small: expected at least {expected} bytes, got {actual}")]
    FileTooSmall {
        /// Minimum expected size
        expected: usize,
        /// Actual file size
        actual: usize,
    },

    /// Arithmetic overflow in offset calculation
    #[error("Arithmetic overflow: {operation}")]
    ArithmeticOverflow {
        /// Description of the operation that overflowed
        operation: String,
    },

    /// Invalid model magic in pipeline entry (by index)
    #[error("Invalid model magic at index {index}: expected HOLB, found {found:?}")]
    InvalidModelMagicByIndex {
        /// Index in pipeline
        index: usize,
        /// Found magic bytes
        found: [u8; 4],
    },

    /// Invalid model magic in pipeline entry (by name)
    #[error("Invalid model magic for '{name}': expected HOLB, found {found:?}")]
    InvalidModelMagicByName {
        /// Model name
        name: String,
        /// Found magic bytes
        found: [u8; 4],
    },

    /// I/O error
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),

    /// Serialization error
    #[error("Serialization error: {0}")]
    Serialization(String),

    /// Deserialization error
    #[error("Deserialization error: {0}")]
    Deserialization(String),

    /// Memory mapping error
    #[error("Memory mapping error: {0}")]
    Mmap(String),

    /// Async runtime error
    #[cfg(feature = "async")]
    #[error("Async runtime error: {0}")]
    AsyncRuntime(#[from] tokio::task::JoinError),

    /// Generic error
    #[error("{0}")]
    Other(String),

    /// Weight tensor not found
    #[error("Weight tensor not found: {name}")]
    WeightTensorNotFound {
        /// Tensor name
        name: String,
    },

    /// Tensor bounds invalid
    #[error(
        "Tensor '{name}' bounds invalid: offset={offset}, size={size}, weights_size={weights_size}"
    )]
    TensorBoundsInvalid {
        /// Tensor name
        name: String,
        /// Tensor offset
        offset: usize,
        /// Tensor size
        size: usize,
        /// Total weights size
        weights_size: usize,
    },

    /// Overlapping tensors in weight index
    #[error("Overlapping tensors: '{a}' and '{b}'")]
    OverlappingTensors {
        /// First tensor name
        a: String,
        /// Second tensor name
        b: String,
    },

    /// Compression error
    #[error("Compression error: {0}")]
    Compression(String),

    /// Decompression error
    #[error("Decompression error: {0}")]
    Decompression(String),

    /// Compression not available (feature not enabled)
    #[error("Compression not available: enable the 'compression' feature")]
    CompressionNotAvailable,

    /// Compressed weights require decompression
    #[error("Cannot access tensor zero-copy: weights are compressed; use decompress methods")]
    CompressedWeightsRequireDecompression,
}

impl HoloError {
    /// Create an invalid format error from magic bytes.
    #[must_use]
    pub fn invalid_magic(expected: &[u8], found: &[u8]) -> Self {
        Self::InvalidFormat {
            expected: String::from_utf8_lossy(expected).to_string(),
            found: String::from_utf8_lossy(found).to_string(),
        }
    }

    /// Create a checksum mismatch error.
    #[must_use]
    pub const fn checksum_mismatch(expected: u32, computed: u32) -> Self {
        Self::ChecksumMismatch { expected, computed }
    }

    /// Create a section checksum mismatch error.
    #[must_use]
    pub fn section_checksum_mismatch(
        section_id: impl Into<String>,
        expected: u32,
        computed: u32,
    ) -> Self {
        Self::SectionChecksumMismatch {
            section_id: section_id.into(),
            expected,
            computed,
        }
    }

    /// Create an invalid offset/size error.
    #[must_use]
    pub const fn invalid_bounds(offset: usize, size: usize, file_size: usize) -> Self {
        Self::InvalidOffsetOrSize {
            offset,
            size,
            file_size,
        }
    }

    /// Create a layer not found error.
    #[must_use]
    pub fn layer_not_found(layer_id: [u8; 32]) -> Self {
        Self::LayerNotFound {
            layer_id: hex::encode(layer_id),
        }
    }

    /// Create a section not found error.
    #[must_use]
    pub fn section_not_found(id: impl Into<String>) -> Self {
        Self::SectionNotFound { id: id.into() }
    }

    /// Create a model not found error.
    #[must_use]
    pub fn model_not_found(name: impl Into<String>) -> Self {
        Self::ModelNotFound { name: name.into() }
    }

    /// Create a duplicate model error.
    #[must_use]
    pub fn duplicate_model(name: impl Into<String>) -> Self {
        Self::DuplicateModel { name: name.into() }
    }

    /// Create a table truncated error.
    #[must_use]
    pub const fn table_truncated(expected: usize, actual: usize) -> Self {
        Self::TableTruncated { expected, actual }
    }

    /// Create an unsupported version error.
    #[must_use]
    pub const fn unsupported_version(version: u32) -> Self {
        Self::UnsupportedVersion { version }
    }

    /// Create a file too small error.
    #[must_use]
    pub const fn file_too_small(expected: usize, actual: usize) -> Self {
        Self::FileTooSmall { expected, actual }
    }

    /// Create an arithmetic overflow error.
    #[must_use]
    pub fn arithmetic_overflow(operation: impl Into<String>) -> Self {
        Self::ArithmeticOverflow {
            operation: operation.into(),
        }
    }

    /// Create an invalid model magic error (by index).
    #[must_use]
    pub const fn invalid_model_magic_by_index(index: usize, found: [u8; 4]) -> Self {
        Self::InvalidModelMagicByIndex { index, found }
    }

    /// Create an invalid model magic error (by name).
    #[must_use]
    pub fn invalid_model_magic_by_name(name: impl Into<String>, found: [u8; 4]) -> Self {
        Self::InvalidModelMagicByName {
            name: name.into(),
            found,
        }
    }

    /// Create a weight tensor not found error.
    #[must_use]
    pub fn weight_tensor_not_found(name: impl Into<String>) -> Self {
        Self::WeightTensorNotFound { name: name.into() }
    }

    /// Create a tensor bounds invalid error.
    #[must_use]
    pub fn tensor_bounds_invalid(
        name: impl Into<String>,
        offset: usize,
        size: usize,
        weights_size: usize,
    ) -> Self {
        Self::TensorBoundsInvalid {
            name: name.into(),
            offset,
            size,
            weights_size,
        }
    }

    /// Create an overlapping tensors error.
    #[must_use]
    pub fn overlapping_tensors(a: impl Into<String>, b: impl Into<String>) -> Self {
        Self::OverlappingTensors {
            a: a.into(),
            b: b.into(),
        }
    }

    /// Create a compression error.
    #[must_use]
    pub fn compression(msg: impl Into<String>) -> Self {
        Self::Compression(msg.into())
    }

    /// Create a decompression error.
    #[must_use]
    pub fn decompression(msg: impl Into<String>) -> Self {
        Self::Decompression(msg.into())
    }

    /// Create a compression not available error.
    #[must_use]
    pub const fn compression_not_available() -> Self {
        Self::CompressionNotAvailable
    }

    /// Create a compressed weights require decompression error.
    #[must_use]
    pub const fn compressed_weights_require_decompression() -> Self {
        Self::CompressedWeightsRequireDecompression
    }

    /// Get actionable help text for this error.
    ///
    /// Returns guidance on how to resolve or investigate the error.
    #[must_use]
    pub fn help(&self) -> Option<&'static str> {
        match self {
            Self::InvalidFormat { .. } => Some(
                "Ensure the file was created with a compatible hologram version. \
                 The file may be corrupted or from an incompatible source.",
            ),
            Self::ChecksumMismatch { .. } | Self::SectionChecksumMismatch { .. } => Some(
                "The file appears to be corrupted. Try re-downloading or re-compiling the model.",
            ),
            Self::InvalidOffsetOrSize { .. } => Some(
                "The file may be truncated or corrupted. Verify the file was fully downloaded.",
            ),
            Self::LayerNotFound { .. } => Some(
                "Check that the layer exists in your registry. Use `hologram registry list` to see available layers.",
            ),
            Self::SectionNotFound { .. } => Some(
                "This section is missing from the bundle. The file may be incomplete or incompatible.",
            ),
            Self::ModelNotFound { .. } => Some(
                "The model name was not found in the bundle. Use `hologram info` to list available models.",
            ),
            Self::DuplicateModel { .. } => Some(
                "A model with this name already exists. Use a unique name for each model in the pipeline.",
            ),
            Self::UnsupportedVersion { .. } => Some(
                "This file was created with a newer hologram version. Update your tools to load it.",
            ),
            Self::EmptyBundle => Some(
                "The bundle contains no data. Ensure at least one model is added before saving.",
            ),
            Self::FileTooSmall { .. } => Some(
                "The file appears truncated. Verify it was fully written or downloaded.",
            ),
            Self::ArithmeticOverflow { .. } => Some(
                "Internal calculation error. This may indicate a malformed file or very large model.",
            ),
            Self::InvalidModelMagicByIndex { .. } | Self::InvalidModelMagicByName { .. } => Some(
                "The model data doesn't have the expected format. The bundle may be corrupted.",
            ),
            Self::Mmap(_) => Some(
                "Memory mapping failed. Ensure you have sufficient memory and file permissions.",
            ),
            Self::WeightTensorNotFound { .. } => Some(
                "The tensor name was not found in the weight index. Use `weight_index()` to list available tensors.",
            ),
            Self::TensorBoundsInvalid { .. } => Some(
                "The tensor's offset and size extend beyond the weights blob. The file may be corrupted.",
            ),
            Self::OverlappingTensors { .. } => Some(
                "Two tensors in the weight index overlap. This indicates a malformed index.",
            ),
            Self::Compression(_) | Self::Decompression(_) => Some(
                "Compression operation failed. The data may be corrupted or in an unsupported format.",
            ),
            Self::CompressionNotAvailable => Some(
                "Enable the 'compression' feature in Cargo.toml to use compression.",
            ),
            Self::CompressedWeightsRequireDecompression => Some(
                "Use `decompress_tensor()` or `decompress_weights()` to access compressed tensor data.",
            ),
            _ => None,
        }
    }

    /// Check if this error indicates file corruption.
    #[must_use]
    pub fn is_corruption(&self) -> bool {
        matches!(
            self,
            Self::ChecksumMismatch { .. }
                | Self::SectionChecksumMismatch { .. }
                | Self::InvalidFormat { .. }
                | Self::InvalidModelMagicByIndex { .. }
                | Self::InvalidModelMagicByName { .. }
                | Self::FileTooSmall { .. }
                | Self::TableTruncated { .. }
        )
    }

    /// Check if this error indicates a missing resource.
    #[must_use]
    pub fn is_not_found(&self) -> bool {
        matches!(
            self,
            Self::LayerNotFound { .. }
                | Self::SectionNotFound { .. }
                | Self::ModelNotFound { .. }
                | Self::WeightTensorNotFound { .. }
        )
    }
}

/// Hex encoding helper (simple implementation)
mod hex {
    use std::fmt::Write;

    pub fn encode(bytes: [u8; 32]) -> String {
        bytes.iter().fold(String::with_capacity(64), |mut acc, b| {
            let _ = write!(acc, "{b:02x}");
            acc
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_invalid_magic_error() {
        let err = HoloError::invalid_magic(b"HOLB", b"JUNK");
        assert!(err.to_string().contains("HOLB"));
        assert!(err.to_string().contains("JUNK"));
    }

    #[test]
    fn test_checksum_error() {
        let err = HoloError::checksum_mismatch(0xDEAD_BEEF, 0xCAFE_BABE);
        assert!(err.to_string().contains("deadbeef"));
        assert!(err.to_string().contains("cafebabe"));
    }

    #[test]
    fn test_section_checksum_error() {
        let err = HoloError::section_checksum_mismatch("vocabulary", 0xDEAD_BEEF, 0xCAFE_BABE);
        let msg = err.to_string();
        assert!(msg.contains("vocabulary"));
        assert!(msg.contains("deadbeef"));
        assert!(msg.contains("cafebabe"));
    }

    #[test]
    fn test_invalid_bounds_error() {
        let err = HoloError::invalid_bounds(1000, 500, 1200);
        assert!(err.to_string().contains("1000"));
        assert!(err.to_string().contains("500"));
        assert!(err.to_string().contains("1200"));
    }

    #[test]
    fn test_section_not_found_error() {
        let err = HoloError::section_not_found("vocabulary");
        assert!(err.to_string().contains("vocabulary"));
    }

    #[test]
    fn test_model_not_found_error() {
        let err = HoloError::model_not_found("encoder");
        assert!(err.to_string().contains("encoder"));
    }

    #[test]
    fn test_duplicate_model_error() {
        let err = HoloError::duplicate_model("decoder");
        assert!(err.to_string().contains("decoder"));
    }

    #[test]
    fn test_table_truncated_error() {
        let err = HoloError::table_truncated(100, 50);
        let msg = err.to_string();
        assert!(msg.contains("100"));
        assert!(msg.contains("50"));
    }

    #[test]
    fn test_unsupported_version_error() {
        let err = HoloError::unsupported_version(99);
        assert!(err.to_string().contains("99"));
    }

    #[test]
    fn test_empty_bundle_error() {
        let err = HoloError::EmptyBundle;
        assert!(err.to_string().contains("Empty bundle"));
    }

    #[test]
    fn test_file_too_small_error() {
        let err = HoloError::file_too_small(1024, 512);
        let msg = err.to_string();
        assert!(msg.contains("too small"));
        assert!(msg.contains("1024"));
        assert!(msg.contains("512"));
    }

    #[test]
    fn test_arithmetic_overflow_error() {
        let err = HoloError::arithmetic_overflow("graph offset + size");
        let msg = err.to_string();
        assert!(msg.contains("overflow"));
        assert!(msg.contains("graph offset + size"));
    }

    #[test]
    fn test_invalid_model_magic_by_index_error() {
        let err = HoloError::invalid_model_magic_by_index(2, *b"JUNK");
        let msg = err.to_string();
        assert!(msg.contains("index 2"));
        assert!(msg.contains("HOLB"));
    }

    #[test]
    fn test_invalid_model_magic_by_name_error() {
        let err = HoloError::invalid_model_magic_by_name("encoder", *b"JUNK");
        let msg = err.to_string();
        assert!(msg.contains("encoder"));
        assert!(msg.contains("HOLB"));
    }

    // ========================================================================
    // Help and Classification Tests (TASK-166)
    // ========================================================================

    #[test]
    fn test_error_help_text() {
        let err = HoloError::ChecksumMismatch {
            expected: 0,
            computed: 1,
        };
        let help = err.help();
        assert!(help.is_some());
        assert!(help.unwrap().contains("corrupted"));
    }

    #[test]
    fn test_error_help_layer_not_found() {
        let err = HoloError::layer_not_found([0; 32]);
        let help = err.help();
        assert!(help.is_some());
        assert!(help.unwrap().contains("registry"));
    }

    #[test]
    fn test_error_is_corruption() {
        assert!(HoloError::ChecksumMismatch {
            expected: 0,
            computed: 1
        }
        .is_corruption());
        assert!(HoloError::invalid_magic(b"HOLB", b"JUNK").is_corruption());
        assert!(HoloError::file_too_small(100, 50).is_corruption());

        // Not corruption
        assert!(!HoloError::layer_not_found([0; 32]).is_corruption());
        assert!(!HoloError::EmptyBundle.is_corruption());
    }

    #[test]
    fn test_error_is_not_found() {
        assert!(HoloError::layer_not_found([0; 32]).is_not_found());
        assert!(HoloError::section_not_found("test").is_not_found());
        assert!(HoloError::model_not_found("encoder").is_not_found());

        // Not "not found"
        assert!(!HoloError::EmptyBundle.is_not_found());
        assert!(!HoloError::checksum_mismatch(0, 1).is_not_found());
    }

    #[test]
    fn test_error_help_none_for_io() {
        let err = HoloError::Io(std::io::Error::other("test"));
        assert!(err.help().is_none());
    }
}
