/**
 * PermissionsPanel — Who can do what with your data.
 * 
 * Beautiful toggles: green = on (private/protected), red = off (exposed).
 * Critical changes (Full access, Anyone scope) require confirmation.
 */

import { useState } from "react";
import { Shield, ShieldOff, AlertTriangle } from "lucide-react";
import type { Permission } from "../types";

/* Human-readable labels */
const ACTION_LABELS: Record<string, { label: string; description: string }> = {
  read: { label: "View your info", description: "Can see your profile and data" },
  write: { label: "Make changes", description: "Can update or add information" },
  admin: { label: "Full access", description: "Can manage settings on your behalf" },
  attest: { label: "Verify you", description: "Can confirm your identity to others" },
};

const SCOPE_LABELS: Record<string, string> = {
  self: "Only you",
  namespace: "Your apps",
  trusted: "Trusted people",
  public: "Anyone",
};

/* Scopes that are considered critical — toggling OFF requires confirmation */
const CRITICAL_SCOPES = new Set(["trusted", "public"]);
const CRITICAL_ACTIONS = new Set(["admin"]);

interface Props {
  readonly permissions: readonly Permission[];
  readonly onToggle: (id: string) => void;
}

export default function PermissionsPanel({ permissions, onToggle }: Props) {
  const [confirmingId, setConfirmingId] = useState<string | null>(null);

  const handleToggle = (perm: Permission) => {
    const isCritical = CRITICAL_SCOPES.has(perm.scope) || CRITICAL_ACTIONS.has(perm.action);
    
    // If turning OFF a critical permission, ask for confirmation
    if (isCritical && perm.active) {
      setConfirmingId(perm.id);
      return;
    }
    
    onToggle(perm.id);
  };

  const confirmToggle = () => {
    if (confirmingId) {
      onToggle(confirmingId);
      setConfirmingId(null);
    }
  };

  const confirmingPerm = confirmingId ? permissions.find(p => p.id === confirmingId) : null;

  return (
    <div className="rounded-2xl border border-border/15 bg-card/30 p-6 animate-fade-in">
      <p className="text-sm text-muted-foreground/50 mb-5">
        These are the rules for who can access your information. Everything is protected by default.
      </p>

      <div className="space-y-2">
        {permissions.map((perm) => {
          const actionInfo = ACTION_LABELS[perm.action] || { label: perm.action, description: "" };
          const scopeLabel = SCOPE_LABELS[perm.scope] || perm.scope;
          const isCritical = CRITICAL_SCOPES.has(perm.scope) || CRITICAL_ACTIONS.has(perm.action);

          return (
            <div
              key={perm.id}
              className="flex items-center gap-4 rounded-xl p-4 bg-muted/30 transition-all duration-500"
            >
              <div className={`shrink-0 transition-colors duration-500 ${perm.active ? "text-primary/60" : "text-muted-foreground/20"}`}>
                {perm.active ? <Shield className="h-4 w-4" /> : <ShieldOff className="h-4 w-4" />}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2.5 mb-0.5">
                  <span className="text-sm font-medium text-foreground">{actionInfo.label}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary/70 border border-primary/10">
                    {scopeLabel}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground/50">{actionInfo.description}</p>
              </div>

              {/* Toggle */}
              <button
                onClick={() => handleToggle(perm)}
                className="shrink-0 relative"
                aria-label={perm.active ? "Turn off" : "Turn on"}
              >
                <div
                  className={`w-11 h-6 rounded-full transition-colors duration-500 ${
                    perm.active
                      ? "bg-[hsl(142,60%,40%)]"
                      : "bg-[hsl(0,50%,45%)]"
                  }`}
                >
                  <div
                    className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-transform duration-300 ${
                      perm.active ? "translate-x-[22px]" : "translate-x-0.5"
                    }`}
                  />
                </div>
              </button>
            </div>
          );
        })}
      </div>

      {/* Confirmation dialog for critical changes */}
      {confirmingPerm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-background/80 backdrop-blur-sm animate-fade-in" onClick={() => setConfirmingId(null)} />
          <div className="relative w-full max-w-sm mx-4 rounded-2xl border border-border/20 bg-card shadow-2xl animate-fade-in p-7">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-destructive/10 flex items-center justify-center">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
              <h3 className="text-lg font-display text-foreground">Are you sure?</h3>
            </div>
            
            <p className="text-sm text-muted-foreground/60 leading-relaxed mb-6">
              Turning off <strong className="text-foreground">{ACTION_LABELS[confirmingPerm.action]?.label}</strong> for{" "}
              <strong className="text-foreground">{SCOPE_LABELS[confirmingPerm.scope]}</strong>{" "}
              will reduce your privacy protection. You can always turn it back on.
            </p>

            <div className="flex items-center gap-3 justify-end">
              <button
                onClick={() => setConfirmingId(null)}
                className="px-5 py-2.5 rounded-full text-sm text-muted-foreground/60 hover:text-foreground transition-colors duration-300"
              >
                Keep it on
              </button>
              <button
                onClick={confirmToggle}
                className="px-5 py-2.5 rounded-full bg-destructive text-destructive-foreground text-sm font-medium transition-all duration-300"
              >
                Turn off
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
