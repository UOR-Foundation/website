//! Mutation translation engine.
//!
//! Handles `mutation { translate(domain: byte, value: 42, op: add, by: 10) { ... } }`
//! by resolving before/after state and computing deltas.

use serde_json::{json, Map, Value};

use crate::ast::*;
use crate::generated::{ActivationDto, ByteDto, FieldValue};

/// Translation error.
#[derive(Debug, thiserror::Error)]
pub enum TranslateError {
    #[error("unknown domain: {0}")]
    UnknownDomain(String),
    #[error("unknown transform op: {0}")]
    UnknownOp(String),
    #[error("missing argument: {0}")]
    MissingArg(String),
}

/// Execute a translate mutation selection.
pub fn execute_translate(sel: &Selection) -> Result<Value, TranslateError> {
    let domain = get_ident_arg(&sel.arguments, "domain")?;
    let value = get_int_arg(&sel.arguments, "value")? as u8;
    let op = get_ident_arg(&sel.arguments, "op")?;
    let by = get_int_arg(&sel.arguments, "by")? as u8;

    let new_value = apply_transform(&domain, value, &op, by)?;

    let from_fields = resolve_state(&domain, value, &sel.children);
    let to_fields = resolve_state(&domain, new_value, &sel.children);
    let delta = compute_delta(&from_fields, &to_fields);

    Ok(json!({
        "from": { "value": value, "fields": from_fields },
        "to": { "value": new_value, "fields": to_fields },
        "delta": delta,
    }))
}

fn get_ident_arg(args: &[(String, QueryValue)], name: &str) -> Result<String, TranslateError> {
    args.iter()
        .find(|(n, _)| n == name)
        .and_then(|(_, v)| v.as_str().map(String::from))
        .ok_or_else(|| TranslateError::MissingArg(name.into()))
}

fn get_int_arg(args: &[(String, QueryValue)], name: &str) -> Result<i64, TranslateError> {
    args.iter()
        .find(|(n, _)| n == name)
        .and_then(|(_, v)| v.as_int())
        .ok_or_else(|| TranslateError::MissingArg(name.into()))
}

/// Apply a single transform operation to a value.
pub fn apply_transform(domain: &str, value: u8, op: &str, by: u8) -> Result<u8, TranslateError> {
    match domain {
        "byte" => match op {
            "add" => Ok(value.wrapping_add(by)),
            "sub" => Ok(value.wrapping_sub(by)),
            "mul" => Ok(value.wrapping_mul(by)),
            _ => Err(TranslateError::UnknownOp(op.into())),
        },
        "activation" => match op {
            "sigmoid" => Ok(uor::lut::sigmoid_lut(value)),
            "tanh" => Ok(uor::lut::tanh_lut(value)),
            "relu" => Ok(uor::lut::relu_lut(value)),
            "exp" => Ok(uor::lut::exp_lut(value)),
            "log" => Ok(uor::lut::log_lut(value)),
            "sqrt" => Ok(uor::lut::sqrt_lut(value)),
            "abs" => Ok(uor::lut::abs_lut(value)),
            "gelu" => Ok(uor::lut::gelu_lut(value)),
            "silu" => Ok(uor::lut::silu_lut(value)),
            _ => Err(TranslateError::UnknownOp(op.into())),
        },
        _ => Err(TranslateError::UnknownDomain(domain.into())),
    }
}

fn resolve_state(domain: &str, value: u8, children: &[Selection]) -> Value {
    let mut obj = Map::new();
    for child in children {
        let fv = match domain {
            "byte" => ByteDto::resolve_field(value, &child.field),
            "activation" => ActivationDto::resolve_field(value, &child.field),
            _ => None,
        };
        if let Some(fv) = fv {
            obj.insert(child.field.clone(), field_value_to_json(&fv));
        }
    }
    Value::Object(obj)
}

fn compute_delta(from: &Value, to: &Value) -> Value {
    let from_obj = from.as_object();
    let to_obj = to.as_object();
    match (from_obj, to_obj) {
        (Some(f), Some(t)) => {
            let mut delta = Map::new();
            for (key, from_val) in f {
                if let Some(to_val) = t.get(key) {
                    let d = numeric_diff(from_val, to_val);
                    delta.insert(key.clone(), d);
                }
            }
            Value::Object(delta)
        }
        _ => Value::Null,
    }
}

fn numeric_diff(from: &Value, to: &Value) -> Value {
    match (from.as_i64(), to.as_i64()) {
        (Some(f), Some(t)) => json!(t - f),
        _ => json!(null),
    }
}

fn field_value_to_json(fv: &FieldValue) -> Value {
    match fv {
        FieldValue::U8(v) => json!(*v),
        FieldValue::U16(v) => json!(*v),
        FieldValue::U32(v) => json!(*v),
        FieldValue::U64(v) => json!(*v),
        FieldValue::Usize(v) => json!(*v),
        FieldValue::I32(v) => json!(*v),
        FieldValue::I64(v) => json!(*v),
        FieldValue::F32(v) => json!(*v),
        FieldValue::Str(v) => json!(v),
        FieldValue::Json(v) => v.clone(),
    }
}

/// Evaluate a predicate against a byte value.
///
/// Supported predicates: `field == value` or `field != value`.
/// Fields: stratum, curvature, domain, orbit_class, rank.
fn evaluate_predicate(value: u8, predicate: &str) -> bool {
    let parts: Vec<&str> = predicate.split_whitespace().collect();
    if parts.len() != 3 {
        return true; // No valid predicate → accept all
    }
    let (field, op, expected) = (parts[0], parts[1], parts[2]);
    let expected_val: i64 = match expected.parse() {
        Ok(v) => v,
        Err(_) => return true,
    };
    let actual = match field {
        "stratum" => uor::lut::stratum_q0(value) as i64,
        "curvature" => uor::lut::curvature_q0(value) as i64,
        "domain" => uor::lut::domain_q0(value) as i64,
        "orbit_class" => uor::lut::orbit_class_q0(value) as i64,
        "rank" => uor::lut::rank_q0(value) as i64,
        _ => return true,
    };
    match op {
        "==" => actual == expected_val,
        "!=" => actual != expected_val,
        "<" => actual < expected_val,
        ">" => actual > expected_val,
        "<=" => actual <= expected_val,
        ">=" => actual >= expected_val,
        _ => true,
    }
}

/// Execute a translateWhere bulk mutation with predicate filtering.
pub fn execute_translate_where(sel: &Selection) -> Result<Value, TranslateError> {
    let from = get_int_arg(&sel.arguments, "from")? as u8;
    let to = get_int_arg(&sel.arguments, "to")? as u8;
    let op = get_ident_arg(&sel.arguments, "op")?;
    let by = get_int_arg(&sel.arguments, "by")? as u8;

    let domain = sel
        .arguments
        .iter()
        .find(|(n, _)| n == "domain")
        .and_then(|(_, v)| v.as_str().map(String::from))
        .unwrap_or_else(|| "byte".to_string());

    let predicate = sel
        .arguments
        .iter()
        .find(|(n, _)| n == "where")
        .and_then(|(_, v)| v.as_str().map(String::from))
        .unwrap_or_default();

    let mut translations = Vec::new();
    let range = if from <= to { from..=to } else { to..=from };
    for v in range {
        if !predicate.is_empty() && !evaluate_predicate(v, &predicate) {
            continue;
        }
        let new_value = apply_transform(&domain, v, &op, by)?;
        let from_fields = resolve_state(&domain, v, &sel.children);
        let to_fields = resolve_state(&domain, new_value, &sel.children);

        translations.push(json!({
            "from": { "value": v, "fields": from_fields },
            "to": { "value": new_value, "fields": to_fields },
        }));
    }

    Ok(json!({
        "count": translations.len(),
        "translations": translations,
    }))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parse::parse;
    use crate::resolve::execute;

    #[test]
    fn translate_ring_add() {
        let doc =
            parse("mutation { translate(domain: byte, value: 42, op: add, by: 10) { value } }")
                .unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["from"]["value"], json!(42));
        assert_eq!(result["to"]["value"], json!(52));
    }

    #[test]
    fn translate_ring_sub() {
        let doc =
            parse("mutation { translate(domain: byte, value: 10, op: sub, by: 30) { value } }")
                .unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["to"]["value"], json!(236));
    }

    #[test]
    fn translate_byte_with_fields() {
        let doc =
            parse("mutation { translate(domain: byte, value: 42, op: add, by: 10) { stratum } }")
                .unwrap();
        let result = execute(&doc).unwrap();
        assert!(result["from"]["fields"]["stratum"].is_number());
        assert!(result["to"]["fields"]["stratum"].is_number());
        assert!(result["delta"]["stratum"].is_number());
    }

    #[test]
    fn translate_ring_mul() {
        let doc = parse("mutation { translate(domain: byte, value: 5, op: mul, by: 7) { value } }")
            .unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["to"]["value"], json!(35));
    }

    #[test]
    fn translate_delta_sign() {
        let doc =
            parse("mutation { translate(domain: byte, value: 100, op: add, by: 10) { stratum } }")
                .unwrap();
        let result = execute(&doc).unwrap();
        // delta should be a signed integer
        assert!(result["delta"]["stratum"].is_number());
    }

    #[test]
    fn translate_activation() {
        let doc = parse(
            "mutation { translate(domain: activation, value: 128, op: sigmoid, by: 0) { sigmoid } }",
        )
        .unwrap();
        let result = execute(&doc).unwrap();
        let new_val = result["to"]["value"].as_u64().unwrap() as u8;
        assert_eq!(new_val, uor::lut::sigmoid_lut(128));
    }

    #[test]
    fn translate_unknown_op() {
        let doc = parse("mutation { translate(domain: byte, value: 1, op: xor, by: 1) { value } }")
            .unwrap();
        let result = execute(&doc);
        assert!(result.is_err());
    }

    #[test]
    fn translate_unknown_domain() {
        let doc = parse("mutation { translate(domain: foo, value: 1, op: add, by: 1) { value } }")
            .unwrap();
        let result = execute(&doc);
        assert!(result.is_err());
    }

    // translateWhere tests

    #[test]
    fn translate_where_no_filter() {
        let doc = parse("mutation { translateWhere(from: 0, to: 3, op: add, by: 1) { stratum } }")
            .unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["count"], json!(4));
        assert_eq!(result["translations"].as_array().unwrap().len(), 4);
    }

    #[test]
    fn translate_where_stratum_filter() {
        let doc = parse(
            "mutation { translateWhere(from: 0, to: 255, op: add, by: 1, where: \"stratum == 0\") { stratum } }",
        )
        .unwrap();
        let result = execute(&doc).unwrap();
        // Only value 0 has stratum 0 (popcount 0)
        assert_eq!(result["count"], json!(1));
        let translations = result["translations"].as_array().unwrap();
        assert_eq!(translations[0]["from"]["value"], json!(0));
    }

    #[test]
    fn translate_where_domain_filter() {
        let doc = parse(
            "mutation { translateWhere(from: 0, to: 10, op: add, by: 5, where: \"domain == 0\") { stratum } }",
        )
        .unwrap();
        let result = execute(&doc).unwrap();
        let count = result["count"].as_u64().unwrap();
        // Only values with domain 0 (Theta) should be included
        let mut expected = 0;
        for v in 0..=10u8 {
            if uor::lut::domain_q0(v) == 0 {
                expected += 1;
            }
        }
        assert_eq!(count, expected);
    }

    #[test]
    fn translate_where_empty_result() {
        let doc = parse(
            "mutation { translateWhere(from: 0, to: 0, op: add, by: 1, where: \"stratum == 8\") { stratum } }",
        )
        .unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["count"], json!(0));
        assert!(result["translations"].as_array().unwrap().is_empty());
    }

    #[test]
    fn translate_where_full_range() {
        let doc =
            parse("mutation { translateWhere(from: 0, to: 255, op: add, by: 0) { stratum } }")
                .unwrap();
        let result = execute(&doc).unwrap();
        assert_eq!(result["count"], json!(256));
    }

    #[test]
    fn translate_where_count_accuracy() {
        let doc = parse(
            "mutation { translateWhere(from: 0, to: 255, op: add, by: 1, where: \"stratum == 4\") { stratum } }",
        )
        .unwrap();
        let result = execute(&doc).unwrap();
        let count = result["count"].as_u64().unwrap();
        // Count of bytes with popcount 4 = C(8,4) = 70
        assert_eq!(count, 70);
    }
}
