//! LUT FFI wrappers — O(1) lookup tables exposed across the FFI boundary.
//!
//! Wraps `uor::lut` functions for Q0 observables, activation functions,
//! torus coordinates, and orbit classification.

use uor::lut;

// ============================================================================
// Q0 Observable Functions
// ============================================================================

/// O(1) stratum (Hamming weight) for a byte value.
#[inline]
pub fn stratum_q0(value: u8) -> u8 {
    lut::stratum_q0(value)
}

/// O(1) curvature (cascade length) for a byte value.
#[inline]
pub fn curvature_q0(value: u8) -> u8 {
    lut::curvature_q0(value)
}

/// O(1) domain (mod 3) for a byte value. 0=Theta, 1=Psi, 2=Delta.
#[inline]
pub fn domain_q0(value: u8) -> u8 {
    lut::domain_q0(value)
}

/// O(1) rank (div 3) for a byte value.
#[inline]
pub fn rank_q0(value: u8) -> u8 {
    lut::rank_q0(value)
}

/// O(1) orbit class (div 8) for a byte value. Returns 0..31.
#[inline]
pub fn orbit_class_q0(value: u8) -> u8 {
    lut::orbit_class_q0(value)
}

/// O(1) torus page index for a byte value. Returns 0..31.
#[inline]
pub fn torus_page_q0(value: u8) -> u8 {
    lut::torus_page_q0(value)
}

/// O(1) torus offset within page. Returns 0..7.
#[inline]
pub fn torus_offset_q0(value: u8) -> u8 {
    lut::torus_offset_q0(value)
}

// ============================================================================
// Activation Function LUTs
// ============================================================================

/// O(1) sigmoid lookup. Input treated as signed (-128..127). Output 0-255.
#[inline]
pub fn sigmoid_lut(value: u8) -> u8 {
    lut::sigmoid_lut(value)
}

/// O(1) tanh lookup. Input treated as signed. Output 0-255 (128 = 0).
#[inline]
pub fn tanh_lut(value: u8) -> u8 {
    lut::tanh_lut(value)
}

/// O(1) ReLU lookup. Input treated as signed. Returns max(0, x).
#[inline]
pub fn relu_lut(value: u8) -> u8 {
    lut::relu_lut(value)
}

/// O(1) exp lookup. Input treated as signed. Output 0-255.
#[inline]
pub fn exp_lut(value: u8) -> u8 {
    lut::exp_lut(value)
}

/// O(1) log lookup. Input unsigned. Output 0-255. log(0) returns 0.
#[inline]
pub fn log_lut(value: u8) -> u8 {
    lut::log_lut(value)
}

/// O(1) sqrt lookup. Input unsigned. Output 0-255.
#[inline]
pub fn sqrt_lut(value: u8) -> u8 {
    lut::sqrt_lut(value)
}

/// O(1) abs lookup. Input treated as signed. Returns |x|.
#[inline]
pub fn abs_lut(value: u8) -> u8 {
    lut::abs_lut(value)
}

/// O(1) GELU lookup. Input treated as signed. Output 0-255.
#[inline]
pub fn gelu_lut(value: u8) -> u8 {
    lut::gelu_lut(value)
}

/// O(1) SiLU (Swish) lookup. Input treated as signed. Output 0-255.
#[inline]
pub fn silu_lut(value: u8) -> u8 {
    lut::silu_lut(value)
}

// ============================================================================
// Q1 (16-bit) Helpers
// ============================================================================

/// O(1) stratum for Q1 (16-bit) via two Q0 lookups.
#[inline]
pub fn stratum_q1(value: u16) -> u8 {
    lut::stratum_q1(value)
}

/// O(1) curvature for Q1 (16-bit).
#[inline]
pub fn curvature_q1(value: u16) -> u8 {
    lut::curvature_q1(value)
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    // Q0 observable tests
    #[test]
    fn test_stratum_q0() {
        assert_eq!(stratum_q0(0), 0);
        assert_eq!(stratum_q0(0xFF), 8);
        assert_eq!(stratum_q0(0xAA), 4);
        for i in 0..=255u8 {
            assert_eq!(stratum_q0(i), i.count_ones() as u8);
        }
    }

    #[test]
    fn test_curvature_q0() {
        assert_eq!(curvature_q0(0), 1);
        assert_eq!(curvature_q0(7), 4); // 0111 -> 1000: 4 bits flip
        assert_eq!(curvature_q0(255), 8); // all flip to 0
    }

    #[test]
    fn test_domain_q0() {
        assert_eq!(domain_q0(0), 0); // Theta
        assert_eq!(domain_q0(1), 1); // Psi
        assert_eq!(domain_q0(2), 2); // Delta
        assert_eq!(domain_q0(3), 0); // Theta again
    }

    #[test]
    fn test_rank_q0() {
        assert_eq!(rank_q0(0), 0);
        assert_eq!(rank_q0(3), 1);
        assert_eq!(rank_q0(255), 85);
    }

    #[test]
    fn test_orbit_class_q0() {
        assert_eq!(orbit_class_q0(0), 0);
        assert_eq!(orbit_class_q0(7), 0);
        assert_eq!(orbit_class_q0(8), 1);
        assert_eq!(orbit_class_q0(255), 31);
    }

    #[test]
    fn test_torus_page_q0() {
        assert_eq!(torus_page_q0(0), 0);
        assert_eq!(torus_page_q0(95), 11);
        assert_eq!(torus_page_q0(96), 12);
    }

    #[test]
    fn test_torus_offset_q0() {
        assert_eq!(torus_offset_q0(0), 0);
        assert_eq!(torus_offset_q0(1), 1);
        assert_eq!(torus_offset_q0(2), 2);
    }

    // Activation function tests
    #[test]
    fn test_sigmoid_lut() {
        assert_eq!(sigmoid_lut(0), 128); // x=0 -> middle
        assert_eq!(sigmoid_lut(64), 255); // saturated high
        assert_eq!(sigmoid_lut(128), 0); // x=-128 -> low
    }

    #[test]
    fn test_tanh_lut() {
        assert_eq!(tanh_lut(0), 128);
        assert_eq!(tanh_lut(64), 255);
        assert_eq!(tanh_lut(128), 0);
    }

    #[test]
    fn test_relu_lut() {
        for i in 0..128u8 {
            assert_eq!(relu_lut(i), i);
        }
        for i in 128..=255u8 {
            assert_eq!(relu_lut(i), 0);
        }
    }

    #[test]
    fn test_exp_lut() {
        assert!(exp_lut(128) < 15); // -128 -> near 0
        assert_eq!(exp_lut(127), 255); // 127 -> saturated
    }

    #[test]
    fn test_log_lut() {
        assert_eq!(log_lut(0), 0);
        assert_eq!(log_lut(1), 0);
        assert!(log_lut(255) > 200);
    }

    #[test]
    fn test_sqrt_lut() {
        assert_eq!(sqrt_lut(0), 0);
        assert!(sqrt_lut(255) > 240);
    }

    #[test]
    fn test_abs_lut() {
        assert_eq!(abs_lut(0), 0);
        assert_eq!(abs_lut(127), 127);
        assert_eq!(abs_lut(255), 1); // |-1| = 1
        assert_eq!(abs_lut(128), 128); // |-128| = 128
    }

    #[test]
    fn test_gelu_lut() {
        let mid = gelu_lut(0);
        assert!((120..=136).contains(&mid));
        assert!(gelu_lut(127) > 200);
    }

    #[test]
    fn test_silu_lut() {
        assert!(silu_lut(128) < 50); // -128 -> small
        assert!(silu_lut(127) > 200); // 127 -> high
    }

    // Q1 tests
    #[test]
    fn test_stratum_q1() {
        assert_eq!(stratum_q1(0), 0);
        assert_eq!(stratum_q1(0xFFFF), 16);
        assert_eq!(stratum_q1(0x00FF), 8);
    }

    #[test]
    fn test_curvature_q1() {
        assert_eq!(curvature_q1(0), 1);
        assert_eq!(curvature_q1(0xFFFF), 16);
    }
}
