//! Dihedral factorization algorithm for semiprimes.
//!
//! This module implements the dihedral factorization oracle, which factors
//! odd semiprimes using the dihedral orbit structure of the multiplicative
//! group modulo 2^k.
//!
//! # Algorithm Overview
//!
//! For a semiprime N = p * q where p, q are odd primes:
//!
//! 1. Select quantum level k (typically 32)
//! 2. Compute base = 2^k - N (the "negation" of N in the ring)
//! 3. Search the dihedral orbit starting from base
//! 4. For each orbit element v, compute gcd(v, N)
//! 5. If gcd > 1 and gcd < N, we found a factor
//!
//! The expected number of steps is O(sqrt(N)) in the worst case,
//! but the orbit structure often yields factors faster.

use crate::chain::{DerivationChain, DerivationStep, StepKind};

/// Result of a successful factorization.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FactorizationResult {
    /// The semiprime that was factored.
    pub n: u64,
    /// The smaller prime factor.
    pub p: u64,
    /// The larger prime factor.
    pub q: u64,
    /// The quantum level used (bit width).
    pub k: u32,
    /// The orbit index where the factor was found.
    pub i: u64,
    /// The orbit value that revealed the factor.
    pub v: u64,
}

/// Compute the greatest common divisor using Euclidean algorithm.
pub fn gcd(mut a: u64, mut b: u64) -> u64 {
    while b != 0 {
        let t = b;
        b = a % b;
        a = t;
    }
    a
}

/// Factorize a semiprime using the dihedral orbit method.
///
/// # Arguments
///
/// * `n` - The semiprime to factor (must be odd, product of two distinct primes)
/// * `k` - The quantum level (bit width, typically 32)
///
/// # Returns
///
/// `Some(FactorizationResult)` if factorization succeeds, `None` if no factor found.
///
/// # Example
///
/// ```
/// use hologram_derivation::factorize_semiprime;
///
/// let result = factorize_semiprime(10403, 32).unwrap();
/// assert_eq!(result.p, 101);
/// assert_eq!(result.q, 103);
/// ```
pub fn factorize_semiprime(n: u64, k: u32) -> Option<FactorizationResult> {
    // N must be odd
    if n.is_multiple_of(2) || n < 9 {
        return None;
    }

    let cycle = if k >= 64 { u64::MAX } else { 1u64 << k };
    let base = cycle.wrapping_sub(n);
    let sqrt_n = (n as f64).sqrt() as u64 + 1;

    // Search the dihedral orbit
    for i in 0..=sqrt_n {
        let v = base.wrapping_add(i);
        let g = gcd(v, n);
        if g > 1 && g < n {
            let (p, q) = if g < n / g { (g, n / g) } else { (n / g, g) };
            return Some(FactorizationResult { n, p, q, k, i, v });
        }
    }
    None
}

/// Generate a complete derivation chain for a factorization.
///
/// This creates a step-by-step proof of the factorization that can be
/// independently verified and serialized to JSON-LD.
///
/// # Arguments
///
/// * `result` - The factorization result to document
/// * `timestamp` - ISO 8601 timestamp for the derivation
///
/// # Returns
///
/// A complete derivation chain documenting the factorization.
pub fn factorization_derivation(result: &FactorizationResult, timestamp: &str) -> DerivationChain {
    let mut chain = DerivationChain::new(
        format!("https://uor.foundation/derivation/factorize/{}", result.n),
        format!("Factorization of {}", result.n),
    )
    .with_description(format!(
        "Complete derivation proving {} = {} * {}",
        result.n, result.p, result.q
    ))
    .with_timestamp(timestamp.to_string());

    // Step 0: Type declaration
    chain.add_step(
        DerivationStep::new(0, "Type Declaration", StepKind::TypeDeclaration)
            .with_input(serde_json::json!({"value": result.n}))
            .with_output(serde_json::json!({
                "type": "semiprime",
                "value": result.n,
                "is_odd": result.n % 2 == 1
            }))
            .with_assertion("N is an odd semiprime")
            .with_justification("Input validation confirms N is odd and composite"),
    );

    // Step 1: Quantum selection
    let cycle = if result.k >= 64 {
        u64::MAX
    } else {
        1u64 << result.k
    };
    chain.add_step(
        DerivationStep::new(1, "Quantum Selection", StepKind::QuantumSelection)
            .with_input(serde_json::json!({"k": result.k}))
            .with_output(serde_json::json!({
                "quantum": result.k,
                "cycle": cycle,
                "ring": format!("Z/(2^{})", result.k)
            }))
            .with_assertion(format!("Working in ring Z/(2^{})", result.k))
            .with_justification("Quantum level selected to exceed sqrt(N)"),
    );

    // Step 2: Base computation
    let base = cycle.wrapping_sub(result.n);
    chain.add_step(
        DerivationStep::new(2, "Base Computation", StepKind::Compute)
            .with_input(serde_json::json!({
                "cycle": cycle,
                "n": result.n
            }))
            .with_output(serde_json::json!({
                "base": base,
                "formula": "base = 2^k - N"
            }))
            .with_assertion("Base is the ring negation of N")
            .with_justification("base = -N mod 2^k"),
    );

    // Step 3: Orbit generation
    chain.add_step(
        DerivationStep::new(3, "Orbit Search", StepKind::OrbitGeneration)
            .with_input(serde_json::json!({
                "base": base,
                "max_steps": (result.n as f64).sqrt() as u64 + 1
            }))
            .with_output(serde_json::json!({
                "index": result.i,
                "value": result.v,
                "formula": format!("v = base + {} = {}", result.i, result.v)
            }))
            .with_assertion(format!(
                "Orbit element {} found at index {}",
                result.v, result.i
            ))
            .with_justification("Sequential search of dihedral orbit"),
    );

    // Step 4: GCD computation
    chain.add_step(
        DerivationStep::new(4, "GCD Computation", StepKind::Gcd)
            .with_input(serde_json::json!({
                "v": result.v,
                "n": result.n
            }))
            .with_output(serde_json::json!({
                "gcd": result.p,
                "is_factor": result.p > 1 && result.p < result.n
            }))
            .with_assertion(format!("gcd({}, {}) = {}", result.v, result.n, result.p))
            .with_justification("Euclidean algorithm"),
    );

    // Step 5: Factor completion
    chain.add_step(
        DerivationStep::new(5, "Factor Completion", StepKind::IntegerDivision)
            .with_input(serde_json::json!({
                "n": result.n,
                "p": result.p
            }))
            .with_output(serde_json::json!({
                "q": result.q,
                "formula": format!("{} / {} = {}", result.n, result.p, result.q)
            }))
            .with_assertion(format!("q = N / p = {}", result.q))
            .with_justification("Integer division"),
    );

    // Step 6: Certificate emission
    chain.add_step(
        DerivationStep::new(6, "Certificate Emission", StepKind::CertificateEmission)
            .with_input(serde_json::json!({
                "n": result.n,
                "p": result.p,
                "q": result.q
            }))
            .with_output(serde_json::json!({
                "certificate": {
                    "claim": format!("{} = {} * {}", result.n, result.p, result.q),
                    "verified": result.p * result.q == result.n,
                    "factors_ordered": result.p < result.q
                }
            }))
            .with_assertion(format!(
                "{} = {} * {} is verified",
                result.n, result.p, result.q
            ))
            .with_justification("Product check confirms factorization"),
    );

    chain
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_gcd() {
        assert_eq!(gcd(48, 18), 6);
        assert_eq!(gcd(101, 103), 1);
        assert_eq!(gcd(10403, 101), 101);
        assert_eq!(gcd(10403, 103), 103);
    }

    #[test]
    fn test_factorize_10403() {
        let result = factorize_semiprime(10403, 32).unwrap();
        assert_eq!(result.n, 10403);
        assert_eq!(result.p, 101);
        assert_eq!(result.q, 103);
        assert_eq!(result.p * result.q, 10403);
    }

    #[test]
    fn test_factorize_15() {
        let result = factorize_semiprime(15, 8).unwrap();
        assert_eq!(result.n, 15);
        assert_eq!(result.p, 3);
        assert_eq!(result.q, 5);
    }

    #[test]
    fn test_factorize_21() {
        let result = factorize_semiprime(21, 8).unwrap();
        assert_eq!(result.n, 21);
        assert_eq!(result.p, 3);
        assert_eq!(result.q, 7);
    }

    #[test]
    fn test_factorize_143() {
        // 143 = 11 * 13
        let result = factorize_semiprime(143, 16).unwrap();
        assert_eq!(result.p * result.q, 143);
    }

    #[test]
    fn test_factorize_even_fails() {
        assert!(factorize_semiprime(100, 32).is_none());
    }

    #[test]
    fn test_factorize_too_small_fails() {
        assert!(factorize_semiprime(4, 32).is_none());
    }

    #[test]
    fn test_factorization_derivation() {
        let result = factorize_semiprime(10403, 32).unwrap();
        let chain = factorization_derivation(&result, "2026-02-05T00:00:00Z");

        assert_eq!(chain.step_count(), 7);
        assert_eq!(chain.steps[0].kind, StepKind::TypeDeclaration);
        assert_eq!(chain.steps[6].kind, StepKind::CertificateEmission);
    }

    #[test]
    fn test_factors_are_ordered() {
        // Verify that p < q in all cases
        for n in [15u64, 21, 35, 77, 143, 221, 10403] {
            if let Some(result) = factorize_semiprime(n, 32) {
                assert!(
                    result.p <= result.q,
                    "Factors should be ordered: {} <= {}",
                    result.p,
                    result.q
                );
            }
        }
    }
}
