import { useState } from "react";
import { Fingerprint, Copy, Check } from "lucide-react";

export function StatCard({
  icon,
  label,
  value,
  sublabel,
  capitalize,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sublabel?: string;
  capitalize?: boolean;
}) {
  return (
    <div className="rounded-2xl border border-border/15 bg-card/30 backdrop-blur-sm p-7">
      <div className="flex items-center gap-2 text-sm tracking-[0.2em] uppercase text-muted-foreground/50 mb-4">
        {icon}
        {label}
      </div>
      <span className={`text-2xl sm:text-3xl font-medium text-foreground ${capitalize ? "capitalize" : ""}`}>
        {value}
      </span>
      {sublabel && (
        <span className="text-base text-muted-foreground/40 ml-2">{sublabel}</span>
      )}
    </div>
  );
}

export function IdentityIdCard({ id }: { id: string }) {
  const [copied, setCopied] = useState(false);
  const isUor = id.startsWith("uor:") || id.startsWith("u:");
  const truncated = id.length > 20
    ? `${id.slice(0, 10)}…${id.slice(-6)}`
    : id;

  const handleCopy = () => {
    navigator.clipboard.writeText(id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-2xl border border-border/15 bg-card/30 backdrop-blur-sm p-7">
      <div className="flex items-center gap-2 text-sm tracking-[0.2em] uppercase text-muted-foreground/50 mb-4">
        <Fingerprint className="h-4 w-4" />
        {isUor ? "Your identity" : "ID"}
      </div>
      <button
        onClick={handleCopy}
        className="flex items-center gap-2 text-lg font-mono text-foreground/80 hover:text-foreground transition-colors duration-500 group"
      >
        <span>{truncated}</span>
        {copied ? (
          <Check className="h-3.5 w-3.5 text-primary" />
        ) : (
          <Copy className="h-3.5 w-3.5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        )}
      </button>
    </div>
  );
}
