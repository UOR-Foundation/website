import React, { useState, useMemo } from 'react';
import { ONTOLOGY_DATA, CANON_CONTENT } from '../constants';
import { generateCanonPDF } from '../services/pdfGenerator';
import { 
  BookOpen, 
  Calculator, 
  ArrowRight, 
  Layers, 
  Variable, 
  Scale,
  Sigma,
  Info,
  MousePointer2,
  Trash2,
  FileText,
  Database,
  Cpu,
  ChevronRight,
  Gem,
  Network,
  Lightbulb,
  ArrowDown,
  Truck,
  HardDrive,
  Brain,
  MessageSquare,
  Box,
  Globe,
  GitMerge,
  Download
} from 'lucide-react';

// Types for our internal usage in this component
interface OntologyItem {
  id: string;
  type: string;
  label: string;
  comment?: string;
  symbol?: string;
  formula?: string;
  yieldsValue?: bigint; // Converted from string/number in JSON
  modulus?: bigint;
  boundary?: bigint;
}

// Icon Map for dynamic rendering from Content Constants
const ICON_MAP: Record<string, any> = {
    "Layers": Layers,
    "Globe": Globe,
    "GitMerge": GitMerge,
    "Brain": Brain,
    "Box": Box,
    "Truck": Truck,
    "Cpu": Cpu,
    "HardDrive": HardDrive,
    "MessageSquare": MessageSquare,
    "Database": Database,
    "Scale": Scale,
    "Gem": Gem,
    "Activity": Network // Fallback/Mapping
};

const GraphExplorer: React.FC = () => {
  // Major Mode Switch: Canon (Reading) vs Workbench (Doing)
  const [mode, setMode] = useState<'CANON' | 'WORKBENCH'>('CANON');
  
  const [selectedA, setSelectedA] = useState<OntologyItem | null>(null);
  const [selectedB, setSelectedB] = useState<OntologyItem | null>(null);
  const [operator, setOperator] = useState<string>('MUL'); // 'MUL' | 'ADD' | 'TENSOR'
  const [detailsItem, setDetailsItem] = useState<OntologyItem | null>(null);

  // Parse and Categorize Ontology Data
  const { axioms, levels, gaugeLevels } = useMemo(() => {
    const raw = ONTOLOGY_DATA["@graph"];
    
    const parseValue = (val: any): bigint | undefined => {
      if (!val) return undefined;
      return BigInt(val["@value"] || val);
    };

    const items: OntologyItem[] = raw.map(n => ({
      id: n["@id"],
      type: Array.isArray(n["@type"]) ? n["@type"][0] : n["@type"],
      label: n.label || n["@id"],
      comment: n.comment,
      symbol: n.symbol,
      formula: n.formula,
      yieldsValue: parseValue(n.yieldsValue),
      modulus: n.modulus ? BigInt(n.modulus) : undefined,
      boundary: n.boundary ? BigInt(n.boundary) : undefined,
    }));

    return {
      axioms: items.filter(i => i.type === 'Axiom' || i.type === 'AddressingAxiom'),
      levels: items.filter(i => i.type === 'TowerLevel'),
      gaugeLevels: items.filter(i => i.type === 'GaugeLevel'),
    };
  }, []);

  // Calculation Logic
  const result = useMemo(() => {
    if (!selectedA?.yieldsValue || !selectedB?.yieldsValue) return null;
    
    const a = selectedA.yieldsValue;
    const b = selectedB.yieldsValue;

    switch(operator) {
      case 'ADD': return a + b;
      case 'MUL': return a * b; 
      case 'TENSOR': return a * b; 
      default: return 0n;
    }
  }, [selectedA, selectedB, operator]);

  const SelectButton = ({ item, slot }: { item: OntologyItem, slot: 'A' | 'B' }) => {
    const isSelected = (slot === 'A' ? selectedA?.id : selectedB?.id) === item.id;
    return (
      <button
        onClick={(e) => {
          e.stopPropagation();
          slot === 'A' ? setSelectedA(item) : setSelectedB(item);
          // Auto-open details on select to be helpful
          setDetailsItem(item);
        }}
        disabled={!item.yieldsValue}
        className={`px-3 py-1.5 text-xs font-bold rounded border transition-colors ${
          isSelected 
            ? 'bg-blue-600 border-blue-400 text-white shadow-[0_0_10px_rgba(59,130,246,0.5)]' 
            : item.yieldsValue 
              ? 'bg-slate-800 border-slate-600 hover:bg-slate-700 text-slate-300' 
              : 'bg-slate-900 border-slate-800 text-slate-600 cursor-not-allowed'
        }`}
      >
        {slot}
      </button>
    );
  };

  const RegistryItem = ({ item }: { item: OntologyItem }) => (
    <div 
        onClick={() => setDetailsItem(item)}
        className={`bg-slate-900 border p-3 rounded-lg flex justify-between items-center group cursor-pointer transition-all hover:bg-slate-800 ${
            detailsItem?.id === item.id ? 'border-blue-500 ring-1 ring-blue-500/50' : 'border-slate-700 hover:border-slate-600'
        }`}
    >
        <div className="flex-1 min-w-0 pr-4">
            <div className="flex items-center gap-2">
                <span className="font-bold text-white truncate text-sm">{item.label}</span>
                {item.symbol && <span className="bg-slate-800 text-blue-400 px-2 py-0.5 rounded text-xs font-mono border border-slate-700">{item.symbol}</span>}
                {item.yieldsValue && <span className="text-xs text-slate-500 font-mono">[{item.yieldsValue.toString()}]</span>}
            </div>
            {item.comment && <div className="text-xs text-slate-400 mt-1 line-clamp-1">{item.comment}</div>}
        </div>
        <div className="flex gap-2 shrink-0">
            <SelectButton item={item} slot="A" />
            <SelectButton item={item} slot="B" />
        </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-200 overflow-hidden relative">
      
      {/* Top Navigation Bar */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900 z-10 shrink-0">
          <div className="flex items-center gap-3">
              <BookOpen className="w-6 h-6 text-blue-500" />
              <div>
                  <h2 className="text-xl font-bold text-white leading-none">The Framework Primer</h2>
                  <p className="text-xs text-slate-400 mt-1">Universal Object Reference (UOR)</p>
              </div>
          </div>
          
          <div className="flex bg-slate-950 rounded-lg p-1 border border-slate-800">
             <button 
                onClick={() => setMode('CANON')}
                className={`flex items-center gap-2 px-4 py-2 rounded text-sm font-medium transition-all ${mode === 'CANON' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}
             >
                <FileText className="w-4 h-4" /> The Canon
             </button>
             <button 
                onClick={() => setMode('WORKBENCH')}
                className={`flex items-center gap-2 px-4 py-2 rounded text-sm font-medium transition-all ${mode === 'WORKBENCH' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}
             >
                <Calculator className="w-4 h-4" /> Workbench
             </button>
          </div>
      </div>

      {/* VIEW: THE CANON (Whitepaper) */}
      {mode === 'CANON' && (
        <div className="flex-1 overflow-y-auto scrollbar-thin">
            <div className="max-w-5xl mx-auto p-8 lg:p-12 space-y-16 animate-in fade-in duration-500 pb-32">
                
                {/* Hero Section */}
                <section className="text-center space-y-6 py-12 relative">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/30 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-widest">
                        <Gem className="w-3 h-3" /> The Golden Vector
                    </div>
                    <h1 className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-br from-white via-slate-200 to-slate-500 tracking-tight leading-tight">
                        {CANON_CONTENT.title}
                    </h1>
                    <p className="text-xl text-slate-400 max-w-3xl mx-auto leading-relaxed">
                        {CANON_CONTENT.hero}
                    </p>
                    
                    <button 
                        onClick={generateCanonPDF}
                        className="absolute right-0 top-0 hidden md:flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 text-sm transition-colors"
                        title="Download Source of Truth PDF"
                    >
                        <Download className="w-4 h-4" />
                        Download PDF
                    </button>
                </section>

                <div className="h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent" />

                {/* Dynamic Content Sections */}
                {CANON_CONTENT.sections.map((section, idx) => {
                    const SectionIcon = section.icon ? ICON_MAP[section.icon] : Layers;
                    
                    return (
                        <section key={section.id} className="space-y-8">
                            <div className="flex items-center gap-4">
                                <div className={`p-3 rounded-lg border bg-opacity-10 border-opacity-20 ${idx % 2 === 0 ? 'bg-blue-500 border-blue-500' : 'bg-emerald-500 border-emerald-500'}`}>
                                    <SectionIcon className={`w-8 h-8 ${idx % 2 === 0 ? 'text-blue-400' : 'text-emerald-400'}`} />
                                </div>
                                <div>
                                    <h2 className="text-3xl font-bold text-white">{section.title}</h2>
                                    {section.subtitle && <p className="text-slate-400">{section.subtitle}</p>}
                                </div>
                            </div>

                            <div className="prose prose-invert prose-lg max-w-none text-slate-300">
                                {section.content.map((p, pIdx) => (
                                    <p key={pIdx}>{p}</p>
                                ))}
                            </div>

                            {section.gridItems && (
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
                                    {section.gridItems.map((item, gIdx) => {
                                        const ItemIcon = item.icon ? ICON_MAP[item.icon] : Box;
                                        // Dynamic Color Classes
                                        let colorClass = "text-slate-400";
                                        let borderClass = "border-slate-800 hover:border-slate-500/50";
                                        
                                        if (item.color === 'blue') { colorClass = "text-blue-500"; borderClass = "border-slate-800 hover:border-blue-500/50"; }
                                        if (item.color === 'emerald') { colorClass = "text-emerald-500"; borderClass = "border-slate-800 hover:border-emerald-500/50"; }
                                        if (item.color === 'purple') { colorClass = "text-purple-500"; borderClass = "border-slate-800 hover:border-purple-500/50"; }
                                        if (item.color === 'yellow') { colorClass = "text-yellow-500"; borderClass = "border-slate-800 hover:border-yellow-500/50"; }
                                        if (item.color === 'pink') { colorClass = "text-pink-500"; borderClass = "border-slate-800 hover:border-pink-500/50"; }
                                        if (item.color === 'slate') { colorClass = "text-slate-400"; borderClass = "border-slate-800 hover:border-slate-500/50"; }

                                        return (
                                            <div key={gIdx} className={`group bg-slate-900 border ${borderClass} p-6 rounded-xl transition-all hover:bg-slate-800/50`}>
                                                <ItemIcon className={`w-8 h-8 mb-4 group-hover:scale-110 transition-transform ${colorClass}`} />
                                                <h3 className="text-lg font-bold text-white mb-2">{item.title}</h3>
                                                <p className="text-sm text-slate-400 mb-4 leading-relaxed">
                                                    {item.desc}
                                                </p>
                                                {item.code && (
                                                    <code className={`text-xs bg-slate-950 px-2 py-1 rounded ${colorClass.replace('500', '300')}`}>
                                                        {item.code}
                                                    </code>
                                                )}
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </section>
                    );
                })}

                {/* CTA */}
                <div className="flex justify-center pt-8">
                    <button 
                        onClick={() => setMode('WORKBENCH')}
                        className="group flex items-center gap-3 bg-blue-600 hover:bg-blue-500 text-white px-8 py-4 rounded-full font-bold text-lg transition-all shadow-[0_0_20px_rgba(37,99,235,0.3)] hover:shadow-[0_0_30px_rgba(37,99,235,0.5)]"
                    >
                        Open the Workbench
                        <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* VIEW: WORKBENCH (Registry + Synthesizer) */}
      {mode === 'WORKBENCH' && (
        <div className="flex-1 flex flex-col lg:flex-row overflow-y-auto lg:overflow-hidden scrollbar-thin">
             {/* LEFT PANE: The Registry */}
            <div className="w-full lg:w-1/2 flex flex-col border-r border-slate-800 bg-slate-900/30 shrink-0">
                <div className="p-4 bg-slate-900/80 border-b border-slate-800 backdrop-blur">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                        <Network className="w-4 h-4" /> The Registry (Constants)
                    </h3>
                </div>
                
                <div className="p-6 space-y-8 pb-24 lg:flex-1 lg:overflow-y-auto scrollbar-thin">
                    {/* Axioms */}
                    <section>
                        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                            <Variable className="w-4 h-4" /> Axioms
                        </h3>
                        <div className="grid gap-2">
                            {axioms.map(item => <RegistryItem key={item.id} item={item} />)}
                        </div>
                    </section>

                    {/* Algebraic Towers */}
                    <section>
                        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                            <Layers className="w-4 h-4" /> Cayley-Dickson Tower
                        </h3>
                        <div className="grid gap-2">
                            {levels.map(item => <RegistryItem key={item.id} item={item} />)}
                        </div>
                    </section>
                    
                    {/* Gauge Fields */}
                     <section>
                        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                            <Scale className="w-4 h-4" /> Gauge Fields
                        </h3>
                        <div className="grid gap-2">
                            {gaugeLevels.map(item => <RegistryItem key={item.id} item={item} />)}
                        </div>
                    </section>
                </div>
            </div>

            {/* RIGHT PANE: The Workbench Tools */}
            <div className="w-full lg:w-1/2 flex flex-col bg-slate-950 border-t lg:border-t-0 lg:border-l border-slate-800 relative shrink-0 lg:overflow-y-auto scrollbar-thin pb-24">
                
                {/* Instructional Banner */}
                <div className="p-6 pb-2">
                   <div className="bg-blue-900/10 border border-blue-500/20 rounded-lg p-4 flex items-start gap-3">
                      <Lightbulb className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                      <div>
                          <h3 className="text-blue-400 font-bold text-sm mb-1">Synthesis Engine</h3>
                          <p className="text-xs text-blue-200 leading-relaxed">
                             Select entities from the registry to simulate <strong>Categorical Composition</strong>. 
                             Observe how the properties (Values/Dimensions) interact via standard operators (Mul/Add/Tensor).
                          </p>
                      </div>
                   </div>
                </div>

                {/* Section 1: Axiom Synthesizer */}
                <div className="p-6 border-b border-slate-800 shrink-0">
                <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-2">
                        <Calculator className="w-5 h-5 text-emerald-500" />
                        <h3 className="text-lg font-bold text-white">Logic Synthesizer</h3>
                    </div>
                    {(selectedA || selectedB) && (
                        <button 
                            onClick={() => { setSelectedA(null); setSelectedB(null); }}
                            className="text-xs flex items-center gap-1 text-slate-500 hover:text-white transition-colors"
                        >
                            <Trash2 className="w-3 h-3" /> Clear
                        </button>
                    )}
                </div>
                
                <div className="bg-slate-900 rounded-xl p-8 border border-slate-800 flex flex-col items-center justify-center space-y-6 shadow-inner relative">
                    
                    {/* Visual Connection Lines (Decoration) */}
                    <div className="absolute top-1/2 left-0 w-full h-px bg-slate-800 -z-0 pointer-events-none" />

                    <div className="flex items-center gap-2 lg:gap-8 w-full justify-center z-10">
                        {/* Input A */}
                        <div className={`w-28 h-28 lg:w-32 lg:h-32 rounded-lg border-2 border-dashed flex flex-col items-center justify-center p-2 text-center transition-all bg-slate-950 ${selectedA ? 'border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.2)]' : 'border-slate-700 hover:border-slate-600'}`}>
                            {selectedA ? (
                            <>
                                <span className="text-2xl font-bold text-white">{selectedA.yieldsValue?.toString()}</span>
                                <span className="text-xs text-blue-300 mt-2 line-clamp-2">{selectedA.label}</span>
                            </>
                            ) : (
                            <div className="text-slate-600 flex flex-col items-center">
                                <MousePointer2 className="w-6 h-6 mb-2 opacity-50" />
                                <span className="text-xs font-medium">Select A</span>
                            </div>
                            )}
                        </div>

                        {/* Operator */}
                        <div className="flex flex-col gap-2 z-10 bg-slate-950 p-2 rounded-lg border border-slate-800 shadow-xl">
                            <button onClick={() => setOperator('MUL')} className={`w-8 h-8 flex items-center justify-center rounded font-bold transition-all ${operator === 'MUL' ? 'bg-emerald-600 text-white shadow-lg scale-110' : 'bg-slate-800 text-slate-500 hover:bg-slate-700'}`}>×</button>
                            <button onClick={() => setOperator('ADD')} className={`w-8 h-8 flex items-center justify-center rounded font-bold transition-all ${operator === 'ADD' ? 'bg-emerald-600 text-white shadow-lg scale-110' : 'bg-slate-800 text-slate-500 hover:bg-slate-700'}`}>+</button>
                            <button onClick={() => setOperator('TENSOR')} className={`w-8 h-8 flex items-center justify-center rounded font-bold transition-all ${operator === 'TENSOR' ? 'bg-emerald-600 text-white shadow-lg scale-110' : 'bg-slate-800 text-slate-500 hover:bg-slate-700'}`} title="Tensor Product">⊗</button>
                        </div>

                        {/* Input B */}
                        <div className={`w-28 h-28 lg:w-32 lg:h-32 rounded-lg border-2 border-dashed flex flex-col items-center justify-center p-2 text-center transition-all bg-slate-950 ${selectedB ? 'border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.2)]' : 'border-slate-700 hover:border-slate-600'}`}>
                            {selectedB ? (
                            <>
                                <span className="text-2xl font-bold text-white">{selectedB.yieldsValue?.toString()}</span>
                                <span className="text-xs text-blue-300 mt-2 line-clamp-2">{selectedB.label}</span>
                            </>
                            ) : (
                            <div className="text-slate-600 flex flex-col items-center">
                                <MousePointer2 className="w-6 h-6 mb-2 opacity-50" />
                                <span className="text-xs font-medium">Select B</span>
                            </div>
                            )}
                        </div>
                    </div>

                    <ArrowDown className="w-6 h-6 text-slate-700" />

                    {/* Result */}
                    <div className="w-full bg-slate-950 border border-emerald-500/30 rounded-lg p-4 flex flex-col lg:flex-row items-center justify-between gap-2 shadow-[0_0_20px_rgba(16,185,129,0.1)] z-10">
                        <div className="flex items-center gap-2">
                            <Sigma className="w-5 h-5 text-emerald-500" />
                            <span className="text-xs text-emerald-500 font-mono uppercase">Projected Value</span>
                        </div>
                        <span className="text-3xl font-mono text-white tracking-widest break-all">
                            {result !== null ? result.toString() : "---"}
                        </span>
                    </div>
                </div>
                </div>

                {/* Section 2: Details / Inspector */}
                <div className="p-6 bg-slate-900/30 min-h-[400px]">
                <div className="flex items-center gap-2 mb-6">
                    {detailsItem ? <Info className="w-5 h-5 text-purple-500" /> : <Scale className="w-5 h-5 text-slate-500" />}
                    <h3 className="text-lg font-bold text-white">
                        {detailsItem ? "Concept Definition" : "Overview"}
                    </h3>
                </div>
                
                {detailsItem ? (
                    <div className="animate-in fade-in slide-in-from-right-4 duration-300">
                            <div className="bg-slate-900 border border-purple-500/30 p-5 rounded-lg shadow-lg">
                                <div className="flex justify-between items-start mb-4">
                                    <h4 className="text-xl font-bold text-white">{detailsItem.label}</h4>
                                    <span className="px-2 py-1 bg-purple-900/40 text-purple-300 text-xs rounded border border-purple-500/30">
                                        {detailsItem.type}
                                    </span>
                                </div>
                                <p className="text-slate-300 text-sm mb-6 leading-relaxed">
                                    {detailsItem.comment || "No detailed commentary available for this concept."}
                                </p>
                                
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-slate-950 p-3 rounded border border-slate-800">
                                        <span className="text-xs text-slate-500 uppercase block mb-1">ID (IRI)</span>
                                        <code className="text-xs text-blue-400 font-mono break-all">{detailsItem.id}</code>
                                    </div>
                                    {detailsItem.yieldsValue && (
                                        <div className="bg-slate-950 p-3 rounded border border-slate-800">
                                            <span className="text-xs text-slate-500 uppercase block mb-1">Base Magnitude</span>
                                            <code className="text-sm text-emerald-400 font-mono">{detailsItem.yieldsValue.toString()}</code>
                                        </div>
                                    )}
                                    {detailsItem.formula && (
                                        <div className="bg-slate-950 p-3 rounded border border-slate-800 col-span-2">
                                            <span className="text-xs text-slate-500 uppercase block mb-1">Construction Formula</span>
                                            <code className="text-sm text-purple-400 font-mono">{detailsItem.formula}</code>
                                        </div>
                                    )}
                                    {detailsItem.modulus && (
                                        <div className="bg-slate-950 p-3 rounded border border-slate-800">
                                            <span className="text-xs text-slate-500 uppercase block mb-1">Modulus (m_k)</span>
                                            <code className="text-sm text-pink-400 font-mono">{detailsItem.modulus.toString()}</code>
                                        </div>
                                    )}
                                </div>

                                <div className="mt-4 p-3 bg-purple-900/10 border border-purple-500/10 rounded flex items-start gap-3">
                                    <Database className="w-4 h-4 text-purple-400 mt-1" />
                                    <p className="text-xs text-purple-200 leading-relaxed">
                                        This definition is enforced by the UOR Codec. 
                                        In any inheriting system, the concept <strong>{detailsItem.label}</strong> will always resolve to the value <code>{detailsItem.yieldsValue?.toString()}</code>, ensuring universal interoperability.
                                    </p>
                                </div>
                            </div>
                            <button 
                                onClick={() => setDetailsItem(null)}
                                className="mt-4 text-xs text-slate-500 hover:text-white underline decoration-slate-700 underline-offset-4"
                            >
                                Clear Selection
                            </button>
                    </div>
                ) : (
                    <>
                        <div className="mt-4 p-3 bg-blue-900/10 border border-blue-500/10 rounded flex items-center gap-3">
                            <Sigma className="w-5 h-5 text-blue-400" />
                            <p className="text-xs text-blue-200">
                                Select an Axiom, Level, or Gauge from the registry on the left to inspect its properties and synthesis rules.
                            </p>
                        </div>
                    </>
                )}
                </div>

            </div>
        </div>
      )}
    </div>
  );
};

export default GraphExplorer;