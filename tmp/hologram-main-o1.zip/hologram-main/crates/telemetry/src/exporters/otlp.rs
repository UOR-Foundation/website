//! OTLP (OpenTelemetry Protocol) exporter.
//!
//! This module provides integration with OpenTelemetry for exporting traces and metrics.
//! Requires the `otlp` feature to be enabled.

use crate::metrics::MetricsRegistry;

/// OTLP exporter configuration.
#[derive(Debug, Clone)]
pub struct OtlpConfig {
    /// OTLP endpoint URL.
    pub endpoint: String,
    /// Service name for identification.
    pub service_name: String,
    /// Request timeout in seconds.
    pub timeout_secs: u64,
}

impl Default for OtlpConfig {
    fn default() -> Self {
        Self {
            endpoint: "http://localhost:4317".to_string(),
            service_name: "hologram".to_string(),
            timeout_secs: 10,
        }
    }
}

impl OtlpConfig {
    /// Create a new OTLP configuration.
    #[must_use]
    pub fn new(endpoint: impl Into<String>, service_name: impl Into<String>) -> Self {
        Self {
            endpoint: endpoint.into(),
            service_name: service_name.into(),
            ..Default::default()
        }
    }

    /// Set the request timeout in seconds.
    #[must_use]
    pub fn with_timeout_secs(mut self, timeout: u64) -> Self {
        self.timeout_secs = timeout;
        self
    }
}

/// OTLP exporter for sending metrics to an OpenTelemetry collector.
///
/// Note: Full OTLP functionality requires async runtime and the
/// opentelemetry crates. This is a minimal implementation that
/// demonstrates the interface.
pub struct OtlpExporter {
    config: OtlpConfig,
}

impl OtlpExporter {
    /// Create a new OTLP exporter with the given configuration.
    #[must_use]
    pub fn new(config: OtlpConfig) -> Self {
        Self { config }
    }

    /// Get the endpoint URL.
    #[must_use]
    pub fn endpoint(&self) -> &str {
        &self.config.endpoint
    }

    /// Get the service name.
    #[must_use]
    pub fn service_name(&self) -> &str {
        &self.config.service_name
    }

    /// Export metrics to the OTLP endpoint.
    ///
    /// Note: This is a placeholder. Full implementation would use
    /// the opentelemetry-otlp crate for actual export.
    pub fn export(&self, _registry: &MetricsRegistry) -> Result<(), OtlpError> {
        // Placeholder: actual implementation would use opentelemetry SDK
        Ok(())
    }
}

/// Errors that can occur during OTLP export.
#[derive(Debug)]
pub enum OtlpError {
    /// Connection to the OTLP endpoint failed.
    ConnectionFailed(String),
    /// Export request timed out.
    Timeout,
    /// Invalid configuration.
    InvalidConfig(String),
}

impl std::fmt::Display for OtlpError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            OtlpError::ConnectionFailed(msg) => {
                write!(f, "OTLP connection failed: {}", msg)
            }
            OtlpError::Timeout => write!(f, "OTLP export timed out"),
            OtlpError::InvalidConfig(msg) => {
                write!(f, "Invalid OTLP configuration: {}", msg)
            }
        }
    }
}

impl std::error::Error for OtlpError {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_otlp_config_default() {
        let config = OtlpConfig::default();
        assert_eq!(config.endpoint, "http://localhost:4317");
        assert_eq!(config.service_name, "hologram");
        assert_eq!(config.timeout_secs, 10);
    }

    #[test]
    fn test_otlp_config_new() {
        let config = OtlpConfig::new("http://custom:4317", "my-service");
        assert_eq!(config.endpoint, "http://custom:4317");
        assert_eq!(config.service_name, "my-service");
    }

    #[test]
    fn test_otlp_config_with_timeout() {
        let config = OtlpConfig::default().with_timeout_secs(30);
        assert_eq!(config.timeout_secs, 30);
    }

    #[test]
    fn test_otlp_exporter_new() {
        let config = OtlpConfig::default();
        let exporter = OtlpExporter::new(config);
        assert_eq!(exporter.endpoint(), "http://localhost:4317");
        assert_eq!(exporter.service_name(), "hologram");
    }

    #[test]
    fn test_otlp_exporter_export() {
        let config = OtlpConfig::default();
        let exporter = OtlpExporter::new(config);
        let registry = MetricsRegistry::new();

        // Should not fail (placeholder implementation)
        let result = exporter.export(&registry);
        assert!(result.is_ok());
    }

    #[test]
    fn test_otlp_error_display() {
        let err = OtlpError::ConnectionFailed("refused".to_string());
        assert!(err.to_string().contains("refused"));

        let err = OtlpError::Timeout;
        assert!(err.to_string().contains("timed out"));

        let err = OtlpError::InvalidConfig("bad endpoint".to_string());
        assert!(err.to_string().contains("bad endpoint"));
    }
}
