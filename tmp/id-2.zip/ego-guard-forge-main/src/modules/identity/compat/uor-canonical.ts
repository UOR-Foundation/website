/**
 * UOR Canonical Proof Stub — standalone compat layer
 * ═══════════════════════════════════════════════════
 *
 * Replicates the singleProofHash output shape using Web Crypto SHA-256.
 * On merge: delete this file, import from @/lib/uor-canonical instead.
 */

/** Braille bijection: byte → U+2800 + byte */
function bytesToGlyph(bytes: Uint8Array): string {
  return Array.from(bytes.slice(0, 8))
    .map((b) => String.fromCodePoint(0x2800 + (b & 0xff)))
    .join("");
}

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function hexToIpv6(hex: string): string {
  const groups: string[] = [];
  for (let i = 0; i < 32; i += 4) {
    groups.push(hex.slice(i, i + 4));
  }
  return groups.join(":");
}

export interface ProofResult {
  derivationId: string;
  cid: string;
  uorAddress: { "u:glyph": string };
  ipv6Address: { "u:ipv6": string };
}

/**
 * Deterministic SHA-256 proof hash — mirrors the real singleProofHash.
 * Same input → same output. Pure. Deterministic.
 */
export async function singleProofHash(
  payload: Record<string, unknown>,
): Promise<ProofResult> {
  const canonical = JSON.stringify(payload, Object.keys(payload).sort());
  const encoded = new TextEncoder().encode(canonical);
  const hashBuffer = await crypto.subtle.digest("SHA-256", encoded);
  const hashBytes = new Uint8Array(hashBuffer);
  const hex = bytesToHex(hashBytes);

  return {
    derivationId: `urn:uor:derivation:sha256:${hex}`,
    cid: `bafkrei${hex.slice(0, 52)}`,
    uorAddress: { "u:glyph": bytesToGlyph(hashBytes) },
    ipv6Address: { "u:ipv6": hexToIpv6(hex) },
  };
}
