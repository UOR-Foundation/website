/**
 * IdentityJourney — A rich, visual exploration of your hologram.
 *
 * Inspired by the Discover page: large cards with warm gradients,
 * immersive hover states, full-width grid, editorial typography.
 */

import { useState, useCallback, useRef, useEffect, useMemo } from "react";
import {
  MessageSquare,
  Heart,
  Users,
  Shield,
  Wallet,
  Cpu,
  ChevronRight,
  X,
  Sparkles,
  Eye,
  Lock,
  History,
} from "lucide-react";
import {
  PermissionsPanel,
  TrustMeter,
  SelectiveDisclosurePanel,
} from "../components";

/* ── Facet definitions ── */

interface IdentityFacet {
  id: string;
  icon: React.ReactNode;
  label: string;
  tagline: string;
  description: string;
  status: "ready" | "coming";
  panelKey?: string;
  gradient: string;
  accentColor: string;
}

const FACETS: IdentityFacet[] = [
  {
    id: "security",
    icon: <Shield className="h-6 w-6" />,
    label: "Security & Privacy",
    tagline: "Control who sees what",
    description: "Decide what's visible and what stays hidden. You're always in charge.",
    status: "ready",
    panelKey: "security",
    gradient: "from-primary/8 via-transparent to-transparent",
    accentColor: "primary",
  },
  {
    id: "prompting",
    icon: <MessageSquare className="h-6 w-6" />,
    label: "AI & Prompting",
    tagline: "Shape how AI talks to you",
    description: "Set the tone, style, and rules for your AI assistants.",
    status: "coming",
    gradient: "from-accent/8 via-transparent to-transparent",
    accentColor: "accent",
  },
  {
    id: "preferences",
    icon: <Heart className="h-6 w-6" />,
    label: "Preferences",
    tagline: "Your tastes, remembered",
    description: "Languages, interests, and style — the details that make this yours.",
    status: "coming",
    gradient: "from-sanctuary-glow/10 via-transparent to-transparent",
    accentColor: "sanctuary-glow",
  },
  {
    id: "network",
    icon: <Users className="h-6 w-6" />,
    label: "People",
    tagline: "Your trusted circle",
    description: "Connect with people you trust. Share selectively.",
    status: "coming",
    gradient: "from-primary/6 via-transparent to-transparent",
    accentColor: "primary",
  },
  {
    id: "finances",
    icon: <Wallet className="h-6 w-6" />,
    label: "Finances",
    tagline: "Your money, your control",
    description: "Track and manage your financial life — private and yours.",
    status: "coming",
    gradient: "from-accent/6 via-transparent to-transparent",
    accentColor: "accent",
  },
  {
    id: "resources",
    icon: <Cpu className="h-6 w-6" />,
    label: "Resources & Agents",
    tagline: "Tools that work for you",
    description: "AI assistants, memory, and computing that act on your behalf.",
    status: "coming",
    gradient: "from-primary/5 via-transparent to-transparent",
    accentColor: "primary",
  },
];

/* ── Sub-panels ── */

type SecurityTab = "permissions" | "verification" | "sharing";

function SecuritySubPanel({
  permissions,
  togglePermission,
  trustScore,
  ceremonies,
  surface,
}: any) {
  const [activeTab, setActiveTab] = useState<SecurityTab>("permissions");

  const tabs: { key: SecurityTab; icon: React.ReactNode; label: string }[] = [
    { key: "permissions", icon: <Eye className="h-4 w-4" />, label: "Who can access" },
    { key: "verification", icon: <History className="h-4 w-4" />, label: "Your reputation" },
    { key: "sharing", icon: <Lock className="h-4 w-4" />, label: "Share selectively" },
  ];

  return (
    <div className="space-y-8">
      <div className="flex gap-2 flex-wrap">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm transition-all duration-500
              ${activeTab === tab.key
                ? "bg-primary/10 text-primary border border-primary/20"
                : "text-muted-foreground/40 hover:text-foreground hover:bg-muted/20 border border-transparent"
              }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>
      <div className="animate-fade-in">
        {activeTab === "permissions" && (
          <PermissionsPanel permissions={permissions} onToggle={togglePermission} />
        )}
        {activeTab === "verification" && (
          <TrustMeter trustScore={trustScore} ceremonies={ceremonies} />
        )}
        {activeTab === "sharing" && (
          <SelectiveDisclosurePanel surface={surface} />
        )}
      </div>
    </div>
  );
}

/* ── Sparkle particles on unlock ── */

function SparkleParticles() {
  const particles = useMemo(() =>
    Array.from({ length: 14 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: 3 + Math.random() * 4,
      delay: Math.random() * 0.6,
      duration: 0.8 + Math.random() * 0.8,
      angle: Math.random() * 360,
      distance: 20 + Math.random() * 40,
    })),
  []);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl z-10">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            animation: `sparkle-float ${p.duration}s ease-out ${p.delay}s both`,
            ["--sparkle-angle" as any]: `${p.angle}deg`,
            ["--sparkle-distance" as any]: `${p.distance}px`,
          }}
        >
          <div
            className="w-full h-full rounded-full"
            style={{
              background: `radial-gradient(circle, hsl(var(--primary)) 0%, hsl(var(--primary) / 0.3) 60%, transparent 100%)`,
              boxShadow: `0 0 ${p.size * 2}px hsl(var(--primary) / 0.4)`,
              animation: `sparkle-twinkle ${p.duration * 0.6}s ease-in-out ${p.delay}s both`,
            }}
          />
        </div>
      ))}
    </div>
  );
}

/* ── Stagger-on-scroll wrapper ── */

function StaggerCard({ index, children, className }: { index: number; children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); observer.disconnect(); } },
      { threshold: 0.15 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(20px)",
        transition: `opacity 0.6s ease-out ${index * 0.1}s, transform 0.6s ease-out ${index * 0.1}s`,
      }}
    >
      {children}
    </div>
  );
}

/* ── Main ── */

export function IdentityJourney({
  permissions,
  togglePermission,
  trustScore,
  ceremonies,
  surface,
  exploredFacets,
  onFacetExplored,
}: {
  permissions: any;
  togglePermission: any;
  trustScore: any;
  ceremonies: any;
  surface: any;
  exploredFacets: Set<string>;
  onFacetExplored: (facetId: string) => void;
}) {
  const [expandedFacet, setExpandedFacet] = useState<string | null>(null);
  const [justUnlocked, setJustUnlocked] = useState<Set<string>>(new Set());
  const prevExploredRef = useRef<Set<string>>(exploredFacets);

  const isFacetUnlocked = useCallback((index: number) => {
    if (index === 0) return true;
    const previousFacet = FACETS[index - 1];
    return exploredFacets.has(previousFacet.id);
  }, [exploredFacets]);

  // Detect newly unlocked facets when exploredFacets changes
  useEffect(() => {
    const prev = prevExploredRef.current;
    if (prev === exploredFacets) return;
    prevExploredRef.current = exploredFacets;

    const newlyUnlocked = new Set<string>();
    FACETS.forEach((facet, index) => {
      if (index === 0) return;
      const wasUnlocked = prev.has(FACETS[index - 1].id);
      const isNowUnlocked = exploredFacets.has(FACETS[index - 1].id);
      if (!wasUnlocked && isNowUnlocked) {
        newlyUnlocked.add(facet.id);
      }
    });

    if (newlyUnlocked.size > 0) {
      setJustUnlocked(newlyUnlocked);
      // Clear the celebration after the animation completes
      const timer = setTimeout(() => setJustUnlocked(new Set()), 2000);
      return () => clearTimeout(timer);
    }
  }, [exploredFacets]);

  const handleExpand = useCallback((facetId: string) => {
    setExpandedFacet((prev) => {
      if (prev === facetId) return null;
      onFacetExplored(facetId);
      return facetId;
    });
  }, [onFacetExplored]);

  const unlockedCount = FACETS.filter((_, i) => isFacetUnlocked(i)).length;

  return (
    <div>
      {/* Section header — editorial style */}
      <div className="mb-6 sm:mb-10">
        <div className="w-8 h-0.5 bg-primary/30 mb-4 sm:mb-6" />
        <h2 className="text-2xl sm:text-4xl lg:text-[2.75rem] font-display text-foreground mb-2 sm:mb-3 leading-tight">
          Your identity, at a glance
        </h2>
        <p className="text-base sm:text-lg text-muted-foreground/40 leading-relaxed max-w-2xl">
          Everything here is yours. Explore at your own pace.
        </p>

        {/* Progress bar */}
        <div className="mt-4 sm:mt-6 flex items-center gap-3 sm:gap-4">
          <div className="flex gap-1">
            {FACETS.map((f, i) => (
              <div
                key={f.id}
                className={`h-1 rounded-full transition-all duration-700 ${
                  isFacetUnlocked(i) ? "w-6 sm:w-10 bg-primary/50" : "w-3 sm:w-5 bg-border/15"
                }`}
              />
            ))}
          </div>
          <span className="text-xs sm:text-sm text-muted-foreground/30">
            {unlockedCount}/{FACETS.length}
          </span>
        </div>
      </div>

      {/* Cards — 3-column grid for immersive feel */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
        {FACETS.map((facet, index) => {
          const isExpanded = expandedFacet === facet.id;
          const unlocked = isFacetUnlocked(index);
          const explored = exploredFacets.has(facet.id);
          const celebrating = justUnlocked.has(facet.id);

          if (isExpanded && unlocked) {
            return (
              <StaggerCard key={facet.id} index={index} className="col-span-2 lg:col-span-3">
                <div className="rounded-2xl border border-primary/20 bg-card/60 backdrop-blur-sm overflow-hidden transition-all duration-500 shadow-lg shadow-primary/5">
                  <button
                    onClick={() => setExpandedFacet(null)}
                    className="w-full flex items-center gap-3 sm:gap-5 px-5 sm:px-8 py-5 sm:py-7 text-left group hover:bg-muted/5 transition-all duration-500"
                  >
                    <div className="shrink-0 w-10 sm:w-12 h-10 sm:h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                      {facet.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-base sm:text-xl font-medium text-foreground">{facet.label}</span>
                      <p className="hidden sm:block text-base text-muted-foreground/45 mt-1">{facet.description}</p>
                    </div>
                    <X className="h-5 w-5 text-muted-foreground/30 hover:text-foreground transition-colors" />
                  </button>
                  <div className="px-4 sm:px-8 pb-6 sm:pb-10 animate-fade-in">
                    {facet.panelKey === "security" && (
                      <SecuritySubPanel
                        permissions={permissions}
                        togglePermission={togglePermission}
                        trustScore={trustScore}
                        ceremonies={ceremonies}
                        surface={surface}
                      />
                    )}
                  </div>
                </div>
              </StaggerCard>
            );
          }

          return (
            <StaggerCard key={facet.id} index={index}>
              <div
                className={`group relative rounded-2xl border overflow-hidden transition-all duration-700 h-full
                  ${celebrating
                    ? "border-primary/40 shadow-xl shadow-primary/15 cursor-pointer ring-2 ring-primary/20 animate-[unlock-glow_2s_ease-out]"
                    : unlocked && !explored
                      ? "border-primary/25 shadow-md shadow-primary/5 cursor-pointer ring-1 ring-primary/10"
                      : unlocked && explored
                        ? "border-border/15 cursor-pointer hover:border-border/30 hover:shadow-lg hover:shadow-primary/5"
                        : "border-border/5 opacity-40 cursor-default"
                  }
                `}
                onClick={() => {
                  if (unlocked) handleExpand(facet.id);
                }}
              >
                {/* Sparkle particles on unlock */}
                {celebrating && <SparkleParticles />}

                {/* Gradient background */}
                {unlocked && (
                  <div className={`absolute inset-0 bg-gradient-to-br ${facet.gradient} ${celebrating ? "opacity-80" : !explored ? "opacity-60" : "opacity-0 group-hover:opacity-100"} transition-opacity duration-700`} />
                )}

                <div className="relative px-4 sm:px-7 py-5 sm:py-7 flex flex-col min-h-[120px] sm:min-h-[160px]">
                  {/* Icon */}
                  <div className={`w-9 sm:w-11 h-9 sm:h-11 rounded-xl flex items-center justify-center mb-3 sm:mb-5 transition-all duration-500
                    ${unlocked && !explored
                      ? "bg-primary/10 text-primary"
                      : unlocked
                        ? "bg-muted/30 text-muted-foreground/40 group-hover:bg-primary/10 group-hover:text-primary"
                        : "bg-muted/10 text-muted-foreground/12"
                    }
                  `}>
                    {unlocked ? facet.icon : <Lock className="h-4 sm:h-5 w-4 sm:w-5" />}
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex items-start sm:items-center gap-2 sm:gap-3 mb-1.5 sm:mb-2 flex-wrap">
                      <span className={`text-sm sm:text-lg font-medium transition-colors duration-500 leading-tight
                        ${unlocked && !explored
                          ? "text-foreground"
                          : unlocked
                            ? "text-foreground/70 group-hover:text-foreground"
                            : "text-foreground/20"
                        }
                      `}>
                        {facet.label}
                      </span>
                      {unlocked && !explored && (
                        <span className="text-[9px] sm:text-[10px] tracking-[0.15em] uppercase text-primary bg-primary/10 px-2 py-0.5 rounded-full font-medium">
                          New
                        </span>
                      )}
                      {explored && (
                        <span className="text-[9px] sm:text-[10px] tracking-[0.15em] uppercase text-muted-foreground/25 bg-muted/15 px-2 py-0.5 rounded-full">
                          ✓
                        </span>
                      )}
                      {!unlocked && (
                        <span className="text-[9px] sm:text-[10px] tracking-[0.2em] uppercase text-muted-foreground/15 bg-muted/10 px-2 py-0.5 rounded-full">
                          Locked
                        </span>
                      )}
                    </div>
                    <p className={`text-xs sm:text-sm leading-relaxed transition-colors duration-500
                      ${unlocked ? "text-muted-foreground/35 group-hover:text-muted-foreground/55" : "text-muted-foreground/12"}
                    `}>
                      {unlocked ? facet.tagline : "Complete previous step"}
                    </p>
                  </div>

                  {/* Action hint */}
                  <div className="mt-3 sm:mt-5 flex items-center justify-end">
                    {unlocked ? (
                      <ChevronRight className={`h-3.5 sm:h-4 w-3.5 sm:w-4 transition-all duration-500
                        ${!explored
                          ? "text-primary/40 animate-pulse"
                          : "text-muted-foreground/10 group-hover:text-primary/40 group-hover:translate-x-1"
                        }`}
                      />
                    ) : (
                      <Lock className="h-3 sm:h-3.5 w-3 sm:w-3.5 text-muted-foreground/8" />
                    )}
                  </div>
                </div>
              </div>
            </StaggerCard>
          );
        })}
      </div>

      {/* Footer */}
      <div className="mt-10 sm:mt-20 pt-6 sm:pt-8 border-t border-border/6">
        <p className="text-base sm:text-lg font-display italic text-muted-foreground/15">
          More is on the way.
        </p>
      </div>
    </div>
  );
}
