//! Graph algorithms for analysis and traversal.
//!
//! All algorithms are generic over the operation type and work with any
//! `ComputeGraph<Op>`.

use std::collections::{HashMap, HashSet, VecDeque};

use crate::graph::ComputeGraph;
use crate::ids::NodeId;

/// Error returned when a cycle is detected in the graph.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CycleError {
    /// Nodes involved in the cycle.
    pub cycle: Vec<NodeId>,
}

impl std::fmt::Display for CycleError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "cycle detected involving {} nodes", self.cycle.len())
    }
}

impl std::error::Error for CycleError {}

/// Compute topological order using Kahn's algorithm.
///
/// Returns nodes in dependency order: if A depends on B, then B appears before A.
///
/// # Errors
///
/// Returns `CycleError` if the graph contains a cycle.
pub fn toposort<Op>(graph: &ComputeGraph<Op>) -> Result<Vec<NodeId>, CycleError> {
    let mut in_degree: HashMap<NodeId, usize> = HashMap::new();
    let mut successors: HashMap<NodeId, Vec<NodeId>> = HashMap::new();

    // Initialize all nodes
    for node in graph.nodes() {
        in_degree.entry(node.id).or_insert(0);
        successors.entry(node.id).or_default();
    }

    // Count in-degrees and build successor lists
    for node in graph.nodes() {
        for dep in node.dependencies() {
            if graph.contains(dep) {
                *in_degree.entry(node.id).or_insert(0) += 1;
                successors.entry(dep).or_default().push(node.id);
            }
        }
    }

    // Start with nodes having no dependencies
    let mut queue: VecDeque<NodeId> = in_degree
        .iter()
        .filter_map(|(&id, &deg)| if deg == 0 { Some(id) } else { None })
        .collect();

    let mut order = Vec::with_capacity(graph.node_count());

    while let Some(id) = queue.pop_front() {
        order.push(id);
        for &succ in successors.get(&id).unwrap_or(&Vec::new()) {
            if let Some(deg) = in_degree.get_mut(&succ) {
                *deg -= 1;
                if *deg == 0 {
                    queue.push_back(succ);
                }
            }
        }
    }

    if order.len() != graph.node_count() {
        // Find cycle
        let cycle = find_cycle(graph).unwrap_or_default();
        return Err(CycleError { cycle });
    }

    Ok(order)
}

/// Find a cycle in the graph using DFS with coloring.
///
/// Returns `Some(cycle)` if a cycle exists, `None` otherwise.
#[must_use]
pub fn find_cycle<Op>(graph: &ComputeGraph<Op>) -> Option<Vec<NodeId>> {
    #[derive(Clone, Copy, PartialEq)]
    enum Color {
        White, // Unvisited
        Gray,  // In progress
        Black, // Done
    }

    let mut colors: HashMap<NodeId, Color> = HashMap::new();
    let mut parent: HashMap<NodeId, NodeId> = HashMap::new();

    for node in graph.nodes() {
        colors.insert(node.id, Color::White);
    }

    fn dfs<Op>(
        id: NodeId,
        graph: &ComputeGraph<Op>,
        colors: &mut HashMap<NodeId, Color>,
        parent: &mut HashMap<NodeId, NodeId>,
    ) -> Option<NodeId> {
        colors.insert(id, Color::Gray);

        if let Some(node) = graph.get(id) {
            for dep in node.dependencies() {
                if !graph.contains(dep) {
                    continue;
                }
                match colors.get(&dep) {
                    Some(Color::Gray) => {
                        parent.insert(id, dep);
                        return Some(dep);
                    }
                    Some(Color::White) => {
                        parent.insert(dep, id);
                        if let Some(cycle_start) = dfs(dep, graph, colors, parent) {
                            return Some(cycle_start);
                        }
                    }
                    _ => {}
                }
            }
        }

        colors.insert(id, Color::Black);
        None
    }

    for &start in colors.clone().keys() {
        if colors[&start] == Color::White {
            if let Some(cycle_start) = dfs(start, graph, &mut colors, &mut parent) {
                // Reconstruct cycle
                let mut cycle = vec![cycle_start];
                let mut current = cycle_start;
                while let Some(&p) = parent.get(&current) {
                    if p == cycle_start {
                        break;
                    }
                    cycle.push(p);
                    current = p;
                }
                return Some(cycle);
            }
        }
    }

    None
}

/// Check if the graph is acyclic.
#[must_use]
pub fn is_acyclic<Op>(graph: &ComputeGraph<Op>) -> bool {
    find_cycle(graph).is_none()
}

/// Compute the depth of each node from sources.
///
/// Depth is the length of the longest path from any source to the node.
#[must_use]
pub fn node_depths<Op>(graph: &ComputeGraph<Op>) -> HashMap<NodeId, usize> {
    let mut depths = HashMap::new();

    // Get topological order (assumes acyclic)
    let Ok(order) = toposort(graph) else {
        return depths;
    };

    for id in order {
        let max_pred_depth = graph
            .predecessors(id)
            .iter()
            .filter_map(|pred| depths.get(pred))
            .max()
            .copied()
            .unwrap_or(0);

        let depth = if graph.predecessors(id).is_empty() {
            0
        } else {
            max_pred_depth + 1
        };
        depths.insert(id, depth);
    }

    depths
}

/// Group nodes into parallel execution levels.
///
/// Nodes at the same level have no dependencies on each other and can
/// execute concurrently. Returns levels in dependency order.
#[must_use]
pub fn levels<Op>(graph: &ComputeGraph<Op>) -> Vec<Vec<NodeId>> {
    let depths = node_depths(graph);

    let Some(max_depth) = depths.values().max().copied() else {
        return Vec::new();
    };

    let mut result = vec![Vec::new(); max_depth + 1];
    for (id, depth) in depths {
        result[depth].push(id);
    }

    result
}

/// Find all nodes reachable from a starting node (forward reachability).
#[must_use]
pub fn reachable_from<Op>(graph: &ComputeGraph<Op>, start: NodeId) -> HashSet<NodeId> {
    let mut visited = HashSet::new();
    let mut queue = VecDeque::new();

    queue.push_back(start);

    while let Some(id) = queue.pop_front() {
        if visited.insert(id) {
            for succ in graph.successors(id) {
                if !visited.contains(&succ) {
                    queue.push_back(succ);
                }
            }
        }
    }

    visited
}

/// Find all nodes that can reach a target node (backward reachability).
#[must_use]
pub fn reaching<Op>(graph: &ComputeGraph<Op>, target: NodeId) -> HashSet<NodeId> {
    let mut visited = HashSet::new();
    let mut queue = VecDeque::new();

    queue.push_back(target);

    while let Some(id) = queue.pop_front() {
        if visited.insert(id) {
            for pred in graph.predecessors(id) {
                if !visited.contains(&pred) {
                    queue.push_back(pred);
                }
            }
        }
    }

    visited
}

/// Check if `ancestor` is an ancestor of `descendant` in the graph.
#[must_use]
pub fn is_ancestor<Op>(graph: &ComputeGraph<Op>, ancestor: NodeId, descendant: NodeId) -> bool {
    reaching(graph, descendant).contains(&ancestor)
}

/// Extract a subgraph containing only the specified nodes.
///
/// Edges are preserved where both endpoints are in the node set.
pub fn extract_subgraph<Op: Clone>(
    graph: &ComputeGraph<Op>,
    nodes: &HashSet<NodeId>,
) -> ComputeGraph<Op> {
    let mut subgraph = ComputeGraph::with_capacity(nodes.len());
    let mut id_map = HashMap::new();

    // Add nodes
    for node in graph.nodes() {
        if nodes.contains(&node.id) {
            let new_id = subgraph.add_node(node.op.clone());
            id_map.insert(node.id, new_id);
        }
    }

    // Add edges
    for node in graph.nodes() {
        if let Some(&new_target) = id_map.get(&node.id) {
            for dep in node.dependencies() {
                if let Some(&new_source) = id_map.get(&dep) {
                    subgraph.add_edge(new_source, new_target);
                }
            }
        }
    }

    subgraph
}

/// Compute immediate dominators using a simple algorithm.
///
/// A node D dominates node N if every path from any source to N passes through D.
/// The immediate dominator is the closest dominator.
#[must_use]
pub fn immediate_dominators<Op>(graph: &ComputeGraph<Op>) -> HashMap<NodeId, NodeId> {
    let Ok(order) = toposort(graph) else {
        return HashMap::new();
    };

    let sources: HashSet<_> = graph.sources().into_iter().collect();
    let mut idom: HashMap<NodeId, NodeId> = HashMap::new();

    // Simple algorithm: for each node, find the common dominator of predecessors
    for id in &order {
        if sources.contains(id) {
            continue; // Sources have no dominator
        }

        let preds = graph.predecessors(*id);
        if preds.is_empty() {
            continue;
        }

        if preds.len() == 1 {
            idom.insert(*id, preds[0]);
        } else {
            // Find common ancestor
            let mut common = reaching(graph, preds[0]);
            for pred in &preds[1..] {
                let pred_reaching = reaching(graph, *pred);
                common = common.intersection(&pred_reaching).copied().collect();
            }

            // Find the closest common ancestor (highest depth)
            let depths = node_depths(graph);
            if let Some(&closest) = common
                .iter()
                .filter(|&&n| n != *id)
                .max_by_key(|n| depths.get(n).unwrap_or(&0))
            {
                idom.insert(*id, closest);
            }
        }
    }

    idom
}

/// Compute dominance frontiers for each node.
///
/// The dominance frontier of node D is the set of nodes where D's dominance ends.
#[must_use]
pub fn dominance_frontiers<Op>(graph: &ComputeGraph<Op>) -> HashMap<NodeId, HashSet<NodeId>> {
    let idom = immediate_dominators(graph);
    let mut frontiers: HashMap<NodeId, HashSet<NodeId>> = HashMap::new();

    for node in graph.nodes() {
        frontiers.insert(node.id, HashSet::new());
    }

    for node in graph.nodes() {
        let preds = graph.predecessors(node.id);
        if preds.len() < 2 {
            continue;
        }

        for pred in &preds {
            let mut runner = *pred;
            while runner != NodeId::null() && Some(&runner) != idom.get(&node.id) {
                frontiers.entry(runner).or_default().insert(node.id);
                runner = idom.get(&runner).copied().unwrap_or(NodeId::null());
            }
        }
    }

    frontiers
}

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Debug, Clone, PartialEq)]
    enum TestOp {
        A,
        B,
        C,
        D,
    }

    fn linear_graph() -> ComputeGraph<TestOp> {
        // A -> B -> C
        let mut g = ComputeGraph::new();
        let a = g.add_node(TestOp::A);
        let b = g.add_node(TestOp::B);
        let c = g.add_node(TestOp::C);
        g.add_edge(a, b);
        g.add_edge(b, c);
        g
    }

    fn diamond_graph() -> ComputeGraph<TestOp> {
        //     A
        //    / \
        //   B   C
        //    \ /
        //     D
        let mut g = ComputeGraph::new();
        let a = g.add_node(TestOp::A);
        let b = g.add_node(TestOp::B);
        let c = g.add_node(TestOp::C);
        let d = g.add_node(TestOp::D);
        g.add_edge(a, b);
        g.add_edge(a, c);
        g.add_edge(b, d);
        g.add_edge(c, d);
        g
    }

    #[test]
    fn test_toposort_linear() {
        let g = linear_graph();
        let order = toposort(&g).unwrap();

        assert_eq!(order.len(), 3);

        // Find positions
        let ids: Vec<_> = g.node_ids();
        let pos: HashMap<_, _> = order.iter().enumerate().map(|(i, &id)| (id, i)).collect();

        // A before B before C
        assert!(pos[&ids[0]] < pos[&ids[1]]);
        assert!(pos[&ids[1]] < pos[&ids[2]]);
    }

    #[test]
    fn test_toposort_diamond() {
        let g = diamond_graph();
        let order = toposort(&g).unwrap();

        assert_eq!(order.len(), 4);

        let ids: Vec<_> = g.node_ids();
        let pos: HashMap<_, _> = order.iter().enumerate().map(|(i, &id)| (id, i)).collect();

        // A before B, A before C, B before D, C before D
        assert!(pos[&ids[0]] < pos[&ids[1]]);
        assert!(pos[&ids[0]] < pos[&ids[2]]);
        assert!(pos[&ids[1]] < pos[&ids[3]]);
        assert!(pos[&ids[2]] < pos[&ids[3]]);
    }

    #[test]
    fn test_toposort_cycle() {
        let mut g = ComputeGraph::new();
        let a = g.add_node(TestOp::A);
        let b = g.add_node(TestOp::B);
        g.add_edge(a, b);
        g.add_edge(b, a);

        let result = toposort(&g);
        assert!(result.is_err());
    }

    #[test]
    fn test_find_cycle_none() {
        let g = linear_graph();
        assert!(find_cycle(&g).is_none());
    }

    #[test]
    fn test_find_cycle_exists() {
        let mut g = ComputeGraph::new();
        let a = g.add_node(TestOp::A);
        let b = g.add_node(TestOp::B);
        let c = g.add_node(TestOp::C);
        g.add_edge(a, b);
        g.add_edge(b, c);
        g.add_edge(c, a);

        let cycle = find_cycle(&g);
        assert!(cycle.is_some());
    }

    #[test]
    fn test_is_acyclic() {
        let g = linear_graph();
        assert!(is_acyclic(&g));

        let mut cyclic = ComputeGraph::new();
        let a = cyclic.add_node(TestOp::A);
        let b = cyclic.add_node(TestOp::B);
        cyclic.add_edge(a, b);
        cyclic.add_edge(b, a);
        assert!(!is_acyclic(&cyclic));
    }

    #[test]
    fn test_node_depths_linear() {
        let g = linear_graph();
        let depths = node_depths(&g);

        let ids: Vec<_> = g.node_ids();
        assert_eq!(depths[&ids[0]], 0);
        assert_eq!(depths[&ids[1]], 1);
        assert_eq!(depths[&ids[2]], 2);
    }

    #[test]
    fn test_node_depths_diamond() {
        let g = diamond_graph();
        let depths = node_depths(&g);

        let ids: Vec<_> = g.node_ids();
        assert_eq!(depths[&ids[0]], 0); // A
        assert_eq!(depths[&ids[1]], 1); // B
        assert_eq!(depths[&ids[2]], 1); // C
        assert_eq!(depths[&ids[3]], 2); // D
    }

    #[test]
    fn test_levels() {
        let g = diamond_graph();
        let lvls = levels(&g);

        assert_eq!(lvls.len(), 3);
        assert_eq!(lvls[0].len(), 1); // A
        assert_eq!(lvls[1].len(), 2); // B, C
        assert_eq!(lvls[2].len(), 1); // D
    }

    #[test]
    fn test_reachable_from() {
        let g = linear_graph();
        let ids: Vec<_> = g.node_ids();

        let reach = reachable_from(&g, ids[0]);
        assert_eq!(reach.len(), 3);
        assert!(reach.contains(&ids[0]));
        assert!(reach.contains(&ids[1]));
        assert!(reach.contains(&ids[2]));

        let reach_mid = reachable_from(&g, ids[1]);
        assert_eq!(reach_mid.len(), 2);
    }

    #[test]
    fn test_reaching() {
        let g = linear_graph();
        let ids: Vec<_> = g.node_ids();

        let reach = reaching(&g, ids[2]);
        assert_eq!(reach.len(), 3);

        let reach_start = reaching(&g, ids[0]);
        assert_eq!(reach_start.len(), 1);
    }

    #[test]
    fn test_is_ancestor() {
        let g = linear_graph();
        let ids: Vec<_> = g.node_ids();

        assert!(is_ancestor(&g, ids[0], ids[2]));
        assert!(is_ancestor(&g, ids[1], ids[2]));
        assert!(!is_ancestor(&g, ids[2], ids[0]));
    }

    #[test]
    fn test_extract_subgraph() {
        let g = diamond_graph();
        let ids: Vec<_> = g.node_ids();

        // Extract just A and B
        let nodes: HashSet<_> = [ids[0], ids[1]].into_iter().collect();
        let sub = extract_subgraph(&g, &nodes);

        assert_eq!(sub.node_count(), 2);
        assert_eq!(sub.edges().len(), 1);
    }

    #[test]
    fn test_immediate_dominators() {
        let g = linear_graph();
        let idom = immediate_dominators(&g);

        let ids: Vec<_> = g.node_ids();
        assert!(!idom.contains_key(&ids[0])); // A is source
        assert_eq!(idom[&ids[1]], ids[0]); // B dominated by A
        assert_eq!(idom[&ids[2]], ids[1]); // C dominated by B
    }

    #[test]
    fn test_empty_graph() {
        let g: ComputeGraph<TestOp> = ComputeGraph::new();

        assert!(toposort(&g).unwrap().is_empty());
        assert!(find_cycle(&g).is_none());
        assert!(node_depths(&g).is_empty());
        assert!(levels(&g).is_empty());
    }

    #[test]
    fn test_single_node() {
        let mut g = ComputeGraph::new();
        let a = g.add_node(TestOp::A);

        let order = toposort(&g).unwrap();
        assert_eq!(order, vec![a]);

        let depths = node_depths(&g);
        assert_eq!(depths[&a], 0);

        let lvls = levels(&g);
        assert_eq!(lvls.len(), 1);
        assert_eq!(lvls[0], vec![a]);
    }

    #[test]
    fn test_disconnected_graph() {
        let mut g = ComputeGraph::new();
        let a = g.add_node(TestOp::A);
        let b = g.add_node(TestOp::B);
        let c = g.add_node(TestOp::C);
        // No edges - three disconnected nodes

        let order = toposort(&g).unwrap();
        assert_eq!(order.len(), 3);

        let depths = node_depths(&g);
        assert_eq!(depths[&a], 0);
        assert_eq!(depths[&b], 0);
        assert_eq!(depths[&c], 0);

        let lvls = levels(&g);
        assert_eq!(lvls.len(), 1);
        assert_eq!(lvls[0].len(), 3);
    }

    #[test]
    fn test_dominance_frontiers() {
        let g = diamond_graph();
        let frontiers = dominance_frontiers(&g);

        // In a diamond, B and C have D in their frontier
        let ids: Vec<_> = g.node_ids();
        assert!(frontiers[&ids[1]].contains(&ids[3])); // B's frontier contains D
        assert!(frontiers[&ids[2]].contains(&ids[3])); // C's frontier contains D
    }

    #[test]
    fn test_cycle_error_display() {
        let err = CycleError {
            cycle: vec![NodeId::new(0, 0), NodeId::new(1, 0)],
        };
        assert_eq!(err.to_string(), "cycle detected involving 2 nodes");
    }
}
