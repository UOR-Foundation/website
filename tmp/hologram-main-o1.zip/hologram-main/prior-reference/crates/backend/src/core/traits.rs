//! Backend trait definitions.
//!
//! This module defines the core traits for backend execution:
//! - [`ProgramBackend`]: Primary interface for ISA program execution
//! - [`ComputeBackend`]: SIMD-accelerated compute operations including matmul/conv2d
//!
//! # Buffer Validation Pattern
//!
//! All backends use a common pattern for validating buffer handles:
//!
//! ```rust,ignore
//! // Look up buffer in storage and return InvalidHandle error if not found
//! let buffer = buffers.get(&handle.id())
//!     .ok_or(BackendError::InvalidHandle(handle))?;
//! ```
//!
//! This pattern is repeated across CPU, CUDA, Metal, and WebGPU backends.
//! Each backend stores buffers in a map (typically `FxHashMap<u64, BufferType>`)
//! keyed by the handle's ID. The pattern intentionally stays inline rather than
//! being abstracted into a helper, as the buffer types and synchronization
//! strategies differ between backends.

use crate::plan::LookupTables;
use crate::{BackendError, BufferHandle, LaunchConfig};
use hologram_isa::{Program, Type};
use rkyv::{Archive, Deserialize as RkyvDeserialize, Serialize as RkyvSerialize};

/// Backend type identifier.
///
/// Note: The `Custom` variant uses `String` internally to support rkyv serialization.
/// Use `BackendType::custom("name")` to create a custom backend type.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Archive, RkyvSerialize, RkyvDeserialize)]
#[rkyv(derive(Debug), attr(allow(missing_docs)))]
pub enum BackendType {
    /// CPU backend (always available).
    Cpu,
    /// WebAssembly backend (deterministic, sandboxed).
    Wasm,
    /// Metal backend (macOS only).
    Metal,
    /// CUDA backend (NVIDIA GPUs).
    Cuda,
    /// WebGPU backend (cross-platform).
    WebGpu,
    /// Custom backend with a name.
    Custom(String),
}

impl BackendType {
    /// Check if this backend type is a GPU backend.
    pub fn is_gpu(&self) -> bool {
        matches!(self, Self::Metal | Self::Cuda | Self::WebGpu)
    }

    /// Check if this backend type is available on the current system.
    pub fn is_available(&self) -> bool {
        match self {
            Self::Cpu => true,
            Self::Wasm => cfg!(feature = "wasm"),
            Self::Metal => cfg!(all(target_os = "macos", feature = "metal")),
            Self::Cuda => cfg!(feature = "cuda"),
            Self::WebGpu => cfg!(feature = "webgpu"),
            Self::Custom(_) => true,
        }
    }
}

impl BackendType {
    /// Create a custom backend type with the given name.
    pub fn custom(name: impl Into<String>) -> Self {
        Self::Custom(name.into())
    }
}

impl std::fmt::Display for BackendType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Cpu => write!(f, "CPU"),
            Self::Wasm => write!(f, "Wasm"),
            Self::Metal => write!(f, "Metal"),
            Self::Cuda => write!(f, "CUDA"),
            Self::WebGpu => write!(f, "WebGPU"),
            Self::Custom(name) => write!(f, "{}", name),
        }
    }
}

#[cfg(any(feature = "serde", feature = "backend-type-serde"))]
mod backend_type_serde {
    use super::BackendType;
    use serde::{de, Deserialize, Deserializer, Serialize, Serializer};

    impl Serialize for BackendType {
        fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
            let s = match self {
                BackendType::Cpu => "cpu".to_string(),
                BackendType::Wasm => "wasm".to_string(),
                BackendType::Metal => "metal".to_string(),
                BackendType::Cuda => "cuda".to_string(),
                BackendType::WebGpu => "webgpu".to_string(),
                BackendType::Custom(name) => format!("custom:{}", name),
            };
            serializer.serialize_str(&s)
        }
    }

    impl<'de> Deserialize<'de> for BackendType {
        fn deserialize<D: Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
            let s = String::deserialize(deserializer)?;
            match s.as_str() {
                "cpu" => Ok(BackendType::Cpu),
                "wasm" => Ok(BackendType::Wasm),
                "metal" => Ok(BackendType::Metal),
                "cuda" => Ok(BackendType::Cuda),
                "webgpu" => Ok(BackendType::WebGpu),
                other => {
                    if let Some(name) = other.strip_prefix("custom:") {
                        Ok(BackendType::Custom(name.to_string()))
                    } else {
                        Err(de::Error::unknown_variant(
                            &s,
                            &["cpu", "wasm", "metal", "cuda", "webgpu", "custom:<name>"],
                        ))
                    }
                }
            }
        }
    }
}

// ============================================================================
// TENSOR LAYOUT AND KERNEL PARAMETERS
// ============================================================================

/// Layout and metadata for tensor buffers.
///
/// Describes how tensor data is arranged in memory, including
/// dimensions, strides, and alignment requirements.
#[derive(Clone, Debug, PartialEq)]
pub struct TensorLayout {
    /// Data type of tensor elements.
    pub dtype: Type,
    /// Tensor dimensions in NCHW format (batch, channels, height, width).
    /// For 2D matrices, use [1, 1, rows, cols].
    pub dims: [u32; 4],
    /// Strides for each dimension in elements.
    pub strides: [u32; 4],
    /// Memory alignment in bytes (32 for AVX2, 64 for AVX-512).
    pub alignment: usize,
}

impl TensorLayout {
    /// Create a new tensor layout with default strides.
    pub fn new(dtype: Type, dims: [u32; 4]) -> Self {
        // Compute row-major strides: strides[i] = product of dims[i+1..]
        let strides = [dims[1] * dims[2] * dims[3], dims[2] * dims[3], dims[3], 1];
        Self {
            dtype,
            dims,
            strides,
            alignment: 32, // Default to AVX2 alignment
        }
    }

    /// Create a layout for a 2D matrix (M x N).
    pub fn matrix(dtype: Type, rows: u32, cols: u32) -> Self {
        Self::new(dtype, [1, 1, rows, cols])
    }

    /// Create a layout for a 4D tensor (NCHW).
    pub fn nchw(dtype: Type, n: u32, c: u32, h: u32, w: u32) -> Self {
        Self::new(dtype, [n, c, h, w])
    }

    /// Set custom alignment.
    pub fn with_alignment(mut self, alignment: usize) -> Self {
        self.alignment = alignment;
        self
    }

    /// Total number of elements.
    pub fn numel(&self) -> usize {
        self.dims.iter().map(|&d| d as usize).product()
    }

    /// Size in bytes.
    pub fn size_bytes(&self) -> usize {
        self.numel() * self.dtype.size_bytes()
    }

    /// Get rows (for 2D matrix view).
    pub fn rows(&self) -> u32 {
        self.dims[2]
    }

    /// Get columns (for 2D matrix view).
    pub fn cols(&self) -> u32 {
        self.dims[3]
    }
}

impl Default for TensorLayout {
    fn default() -> Self {
        Self::new(Type::F32, [1, 1, 1, 1])
    }
}

/// Parameters for 2D convolution operation.
#[derive(Clone, Debug, PartialEq)]
pub struct Conv2DParams {
    /// Input tensor dimensions [N, C_in, H, W].
    pub input_dims: [u32; 4],
    /// Kernel dimensions [C_out, C_in, KH, KW].
    pub kernel_dims: [u32; 4],
    /// Stride [H, W].
    pub stride: [u32; 2],
    /// Padding [H, W].
    pub padding: [u32; 2],
    /// Dilation [H, W].
    pub dilation: [u32; 2],
    /// Data type.
    pub dtype: Type,
}

impl Conv2DParams {
    /// Create new Conv2D parameters.
    pub fn new(input_dims: [u32; 4], kernel_dims: [u32; 4], dtype: Type) -> Self {
        Self {
            input_dims,
            kernel_dims,
            stride: [1, 1],
            padding: [0, 0],
            dilation: [1, 1],
            dtype,
        }
    }

    /// Set stride.
    pub fn with_stride(mut self, h: u32, w: u32) -> Self {
        self.stride = [h, w];
        self
    }

    /// Set padding.
    pub fn with_padding(mut self, h: u32, w: u32) -> Self {
        self.padding = [h, w];
        self
    }

    /// Set dilation.
    pub fn with_dilation(mut self, h: u32, w: u32) -> Self {
        self.dilation = [h, w];
        self
    }

    /// Calculate output height.
    pub fn output_height(&self) -> u32 {
        let h_in = self.input_dims[2];
        let kh = self.kernel_dims[2];
        let pad = self.padding[0];
        let stride = self.stride[0];
        let dilation = self.dilation[0];
        (h_in + 2 * pad - dilation * (kh - 1) - 1) / stride + 1
    }

    /// Calculate output width.
    pub fn output_width(&self) -> u32 {
        let w_in = self.input_dims[3];
        let kw = self.kernel_dims[3];
        let pad = self.padding[1];
        let stride = self.stride[1];
        let dilation = self.dilation[1];
        (w_in + 2 * pad - dilation * (kw - 1) - 1) / stride + 1
    }

    /// Calculate output dimensions [N, C_out, H_out, W_out].
    pub fn output_dims(&self) -> [u32; 4] {
        [
            self.input_dims[0],  // batch
            self.kernel_dims[0], // output channels
            self.output_height(),
            self.output_width(),
        ]
    }
}

impl Default for Conv2DParams {
    fn default() -> Self {
        Self::new([1, 1, 1, 1], [1, 1, 1, 1], Type::F32)
    }
}

/// Matrix multiplication parameters.
#[derive(Clone, Debug, PartialEq)]
pub struct MatMulParams {
    /// M dimension (rows of A and C).
    pub m: u32,
    /// K dimension (columns of A, rows of B).
    pub k: u32,
    /// N dimension (columns of B and C).
    pub n: u32,
    /// Data type.
    pub dtype: Type,
    /// Alpha scaling factor.
    pub alpha: f64,
    /// Beta scaling factor (for C = alpha * A @ B + beta * C).
    pub beta: f64,
    /// Whether A is transposed.
    pub trans_a: bool,
    /// Whether B is transposed.
    pub trans_b: bool,
}

impl MatMulParams {
    /// Create new MatMul parameters.
    pub fn new(m: u32, k: u32, n: u32, dtype: Type) -> Self {
        Self {
            m,
            k,
            n,
            dtype,
            alpha: 1.0,
            beta: 0.0,
            trans_a: false,
            trans_b: false,
        }
    }

    /// Set scaling factors.
    pub fn with_scaling(mut self, alpha: f64, beta: f64) -> Self {
        self.alpha = alpha;
        self.beta = beta;
        self
    }

    /// Set transpose flags.
    pub fn with_transpose(mut self, trans_a: bool, trans_b: bool) -> Self {
        self.trans_a = trans_a;
        self.trans_b = trans_b;
        self
    }
}

impl Default for MatMulParams {
    fn default() -> Self {
        Self::new(1, 1, 1, Type::F32)
    }
}

// ============================================================================
// SPECIALIZED CONVOLUTION PARAMETERS
// ============================================================================

/// Parameters for depthwise 2D convolution.
///
/// Each input channel is convolved with its own filter (no cross-channel mixing).
/// Used in MobileNet, EfficientNet architectures for efficient computation.
/// Complexity is O(K² × C) vs O(K² × C_in × C_out) for standard convolution.
#[derive(Clone, Debug, PartialEq)]
pub struct DepthwiseConv2DParams {
    /// Input tensor dimensions [N, C, H, W].
    pub input_dims: [u32; 4],
    /// Kernel dimensions [C, 1, KH, KW] (one filter per channel).
    pub kernel_dims: [u32; 4],
    /// Stride [H, W].
    pub stride: [u32; 2],
    /// Padding [H, W].
    pub padding: [u32; 2],
    /// Dilation [H, W].
    pub dilation: [u32; 2],
    /// Channel multiplier (output_channels = input_channels × multiplier).
    pub channel_multiplier: u32,
    /// Data type.
    pub dtype: Type,
}

impl DepthwiseConv2DParams {
    /// Create new depthwise Conv2D parameters.
    pub fn new(input_dims: [u32; 4], kernel_h: u32, kernel_w: u32, dtype: Type) -> Self {
        let channels = input_dims[1];
        Self {
            input_dims,
            kernel_dims: [channels, 1, kernel_h, kernel_w],
            stride: [1, 1],
            padding: [0, 0],
            dilation: [1, 1],
            channel_multiplier: 1,
            dtype,
        }
    }

    /// Set stride.
    pub fn with_stride(mut self, h: u32, w: u32) -> Self {
        self.stride = [h, w];
        self
    }

    /// Set padding.
    pub fn with_padding(mut self, h: u32, w: u32) -> Self {
        self.padding = [h, w];
        self
    }

    /// Set dilation.
    pub fn with_dilation(mut self, h: u32, w: u32) -> Self {
        self.dilation = [h, w];
        self
    }

    /// Set channel multiplier.
    pub fn with_multiplier(mut self, multiplier: u32) -> Self {
        self.channel_multiplier = multiplier;
        self
    }

    /// Calculate output height.
    pub fn output_height(&self) -> u32 {
        let h_in = self.input_dims[2];
        let kh = self.kernel_dims[2];
        let pad = self.padding[0];
        let stride = self.stride[0];
        let dilation = self.dilation[0];
        (h_in + 2 * pad - dilation * (kh - 1) - 1) / stride + 1
    }

    /// Calculate output width.
    pub fn output_width(&self) -> u32 {
        let w_in = self.input_dims[3];
        let kw = self.kernel_dims[3];
        let pad = self.padding[1];
        let stride = self.stride[1];
        let dilation = self.dilation[1];
        (w_in + 2 * pad - dilation * (kw - 1) - 1) / stride + 1
    }

    /// Calculate output dimensions [N, C_out, H_out, W_out].
    pub fn output_dims(&self) -> [u32; 4] {
        [
            self.input_dims[0],
            self.input_dims[1] * self.channel_multiplier,
            self.output_height(),
            self.output_width(),
        ]
    }

    /// Get input channels.
    pub fn input_channels(&self) -> u32 {
        self.input_dims[1]
    }

    /// Get output channels.
    pub fn output_channels(&self) -> u32 {
        self.input_dims[1] * self.channel_multiplier
    }
}

impl Default for DepthwiseConv2DParams {
    fn default() -> Self {
        Self::new([1, 1, 1, 1], 3, 3, Type::F32)
    }
}

/// Parameters for pointwise (1×1) convolution.
///
/// Pointwise convolution is a special case where kernel size is 1×1.
/// It performs per-pixel channel mixing and can be efficiently implemented
/// as a batched GEMM: reshape [N,C,H,W] to [N×H×W, C_in] and multiply by [C_in, C_out].
#[derive(Clone, Debug, PartialEq)]
pub struct PointwiseConvParams {
    /// Input tensor dimensions [N, C_in, H, W].
    pub input_dims: [u32; 4],
    /// Number of output channels.
    pub out_channels: u32,
    /// Data type.
    pub dtype: Type,
}

impl PointwiseConvParams {
    /// Create new pointwise convolution parameters.
    pub fn new(input_dims: [u32; 4], out_channels: u32, dtype: Type) -> Self {
        Self {
            input_dims,
            out_channels,
            dtype,
        }
    }

    /// Calculate output dimensions [N, C_out, H, W].
    pub fn output_dims(&self) -> [u32; 4] {
        [
            self.input_dims[0],
            self.out_channels,
            self.input_dims[2],
            self.input_dims[3],
        ]
    }

    /// Get input channels.
    pub fn input_channels(&self) -> u32 {
        self.input_dims[1]
    }

    /// Get spatial size (H × W).
    pub fn spatial_size(&self) -> u32 {
        self.input_dims[2] * self.input_dims[3]
    }

    /// Get batch size.
    pub fn batch_size(&self) -> u32 {
        self.input_dims[0]
    }

    /// Convert to equivalent MatMul parameters for GEMM execution.
    /// Returns (M, K, N) where M=N×H×W, K=C_in, N=C_out.
    pub fn as_matmul_dims(&self) -> (u32, u32, u32) {
        let m = self.input_dims[0] * self.input_dims[2] * self.input_dims[3];
        let k = self.input_dims[1];
        let n = self.out_channels;
        (m, k, n)
    }
}

impl Default for PointwiseConvParams {
    fn default() -> Self {
        Self::new([1, 1, 1, 1], 1, Type::F32)
    }
}

/// Parameters for grouped 2D convolution.
///
/// Channels are divided into G groups, with standard convolution applied
/// within each group. This generalizes both standard and depthwise convolution:
/// - G = 1: Standard convolution
/// - G = C_in: Depthwise convolution (when C_out = C_in × multiplier)
#[derive(Clone, Debug, PartialEq)]
pub struct GroupedConv2DParams {
    /// Input tensor dimensions [N, C_in, H, W].
    pub input_dims: [u32; 4],
    /// Kernel dimensions [C_out, C_in/G, KH, KW].
    pub kernel_dims: [u32; 4],
    /// Number of groups.
    pub groups: u32,
    /// Stride [H, W].
    pub stride: [u32; 2],
    /// Padding [H, W].
    pub padding: [u32; 2],
    /// Dilation [H, W].
    pub dilation: [u32; 2],
    /// Data type.
    pub dtype: Type,
}

impl GroupedConv2DParams {
    /// Create new grouped Conv2D parameters.
    pub fn new(input_dims: [u32; 4], kernel_dims: [u32; 4], groups: u32, dtype: Type) -> Self {
        Self {
            input_dims,
            kernel_dims,
            groups,
            stride: [1, 1],
            padding: [0, 0],
            dilation: [1, 1],
            dtype,
        }
    }

    /// Set stride.
    pub fn with_stride(mut self, h: u32, w: u32) -> Self {
        self.stride = [h, w];
        self
    }

    /// Set padding.
    pub fn with_padding(mut self, h: u32, w: u32) -> Self {
        self.padding = [h, w];
        self
    }

    /// Set dilation.
    pub fn with_dilation(mut self, h: u32, w: u32) -> Self {
        self.dilation = [h, w];
        self
    }

    /// Calculate output height.
    pub fn output_height(&self) -> u32 {
        let h_in = self.input_dims[2];
        let kh = self.kernel_dims[2];
        let pad = self.padding[0];
        let stride = self.stride[0];
        let dilation = self.dilation[0];
        (h_in + 2 * pad - dilation * (kh - 1) - 1) / stride + 1
    }

    /// Calculate output width.
    pub fn output_width(&self) -> u32 {
        let w_in = self.input_dims[3];
        let kw = self.kernel_dims[3];
        let pad = self.padding[1];
        let stride = self.stride[1];
        let dilation = self.dilation[1];
        (w_in + 2 * pad - dilation * (kw - 1) - 1) / stride + 1
    }

    /// Calculate output dimensions [N, C_out, H_out, W_out].
    pub fn output_dims(&self) -> [u32; 4] {
        [
            self.input_dims[0],
            self.kernel_dims[0],
            self.output_height(),
            self.output_width(),
        ]
    }

    /// Check if this is equivalent to depthwise convolution.
    pub fn is_depthwise(&self) -> bool {
        self.groups == self.input_dims[1]
    }

    /// Check if this is equivalent to standard convolution.
    pub fn is_standard(&self) -> bool {
        self.groups == 1
    }

    /// Get channels per group for input.
    pub fn input_channels_per_group(&self) -> u32 {
        self.input_dims[1] / self.groups
    }

    /// Get channels per group for output.
    pub fn output_channels_per_group(&self) -> u32 {
        self.kernel_dims[0] / self.groups
    }
}

impl Default for GroupedConv2DParams {
    fn default() -> Self {
        Self::new([1, 1, 1, 1], [1, 1, 1, 1], 1, Type::F32)
    }
}

// ============================================================================
// ASPECT-AWARE GEMM PARAMETERS
// ============================================================================

/// Aspect ratio hint for GEMM optimization.
///
/// Different matrix shapes benefit from different tiling strategies.
/// This hint guides kernel selection for optimal cache utilization.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Default)]
pub enum GemmAspectHint {
    /// Standard square-ish matrices (default).
    /// Uses balanced tiling across M, N, K dimensions.
    #[default]
    Balanced,
    /// Tall-thin matrices: M >> N (many rows, few columns).
    /// Benefits from column-major storage and narrow panels.
    TallThin,
    /// Wide-short matrices: N >> M (few rows, many columns).
    /// Benefits from row-major storage and wide panels.
    WideShort,
    /// Skinny K dimension: K is small relative to M, N.
    /// Process full K in single pass when possible.
    SkinnyK,
    /// Small matrices batched together.
    /// Fuse across batch dimension for better throughput.
    SmallBatched,
}

impl GemmAspectHint {
    /// Auto-detect aspect ratio from matrix dimensions.
    ///
    /// # Arguments
    /// * `m` - Number of rows in A/C
    /// * `k` - Shared dimension (columns of A, rows of B)
    /// * `n` - Number of columns in B/C
    pub fn detect(m: u32, k: u32, n: u32) -> Self {
        let m = m as f64;
        let k = k as f64;
        let n = n as f64;

        // Small matrices: batch them
        if (m * n) < 256.0 {
            return Self::SmallBatched;
        }

        let ratio_mn = m / n;
        let ratio_mk = m / k;

        // Tall-thin: more rows than columns
        if ratio_mn > 4.0 {
            return Self::TallThin;
        }

        // Wide-short: more columns than rows
        if ratio_mn < 0.25 {
            return Self::WideShort;
        }

        // Skinny K: small shared dimension
        if k < m.min(n) / 4.0 && ratio_mk > 4.0 {
            return Self::SkinnyK;
        }

        Self::Balanced
    }
}

/// Extended matrix multiplication parameters with aspect ratio awareness.
///
/// Wraps standard `MatMulParams` with additional hints for kernel selection.
#[derive(Clone, Debug, PartialEq)]
pub struct AspectAwareMatMulParams {
    /// Base matrix multiplication parameters.
    pub base: MatMulParams,
    /// Aspect ratio hint for optimization.
    pub aspect_hint: GemmAspectHint,
    /// For SmallBatched: number of matrices to process together.
    pub batch_count: Option<u32>,
}

impl AspectAwareMatMulParams {
    /// Create new aspect-aware parameters with auto-detected hint.
    pub fn new(m: u32, k: u32, n: u32, dtype: Type) -> Self {
        let base = MatMulParams::new(m, k, n, dtype);
        let aspect_hint = GemmAspectHint::detect(m, k, n);
        Self {
            base,
            aspect_hint,
            batch_count: None,
        }
    }

    /// Create with explicit aspect hint.
    pub fn with_hint(base: MatMulParams, hint: GemmAspectHint) -> Self {
        Self {
            base,
            aspect_hint: hint,
            batch_count: None,
        }
    }

    /// Set batch count for SmallBatched mode.
    pub fn with_batch_count(mut self, count: u32) -> Self {
        self.batch_count = Some(count);
        self
    }

    /// Set scaling factors.
    pub fn with_scaling(mut self, alpha: f64, beta: f64) -> Self {
        self.base = self.base.with_scaling(alpha, beta);
        self
    }

    /// Set transpose flags.
    pub fn with_transpose(mut self, trans_a: bool, trans_b: bool) -> Self {
        self.base = self.base.with_transpose(trans_a, trans_b);
        self
    }
}

impl Default for AspectAwareMatMulParams {
    fn default() -> Self {
        Self::new(1, 1, 1, Type::F32)
    }
}

impl From<MatMulParams> for AspectAwareMatMulParams {
    fn from(base: MatMulParams) -> Self {
        let hint = GemmAspectHint::detect(base.m, base.k, base.n);
        Self {
            base,
            aspect_hint: hint,
            batch_count: None,
        }
    }
}

// ============================================================================
// BACKEND TRAITS
// ============================================================================

/// Primary interface for ISA program execution and buffer management.
///
/// All methods take `&self` to enable thread-safe parallel execution.
/// Implementations use interior mutability (RwLock, AtomicU64) for state that
/// requires mutation.
pub trait ProgramBackend: Send + Sync {
    /// Get the backend type identifier.
    fn backend_type(&self) -> BackendType;

    /// Execute an ISA program with the given launch configuration.
    fn execute_program(&self, program: &Program, config: &LaunchConfig)
        -> Result<(), BackendError>;

    /// Lookup tables used by this backend (torus + categorical metadata).
    fn lookup_tables(&self) -> LookupTables {
        LookupTables::default()
    }

    /// Allocate a buffer of the specified size in bytes.
    fn allocate_buffer(&self, size: usize) -> Result<BufferHandle, BackendError>;

    /// Free a previously allocated buffer.
    fn free_buffer(&self, handle: BufferHandle) -> Result<(), BackendError>;

    /// Copy data from host memory to a buffer.
    fn copy_to_buffer(&self, handle: BufferHandle, data: &[u8]) -> Result<(), BackendError>;

    /// Copy data from a buffer to host memory.
    fn copy_from_buffer(&self, handle: BufferHandle, data: &mut [u8]) -> Result<(), BackendError>;

    /// Get the size of a buffer in bytes.
    fn buffer_size(&self, handle: BufferHandle) -> Result<usize, BackendError>;

    /// Synchronize all pending operations.
    fn synchronize(&self) -> Result<(), BackendError>;

    /// Get a raw pointer to a buffer's data.
    ///
    /// Returns `None` if the handle is invalid or the buffer doesn't exist.
    /// The pointer is valid until the buffer is freed or reallocated.
    ///
    /// # Safety
    ///
    /// The caller must ensure:
    /// - The returned pointer is not used after the buffer is freed
    /// - Concurrent access follows Rust's aliasing rules
    /// - For mutable access, no other references to the buffer data exist
    fn get_buffer_ptr(&self, handle: BufferHandle) -> Option<*mut u8>;
}

/// SIMD acceleration for compute operations.
///
/// Extends [`ProgramBackend`] with SIMD-accelerated operations for
/// vector operations, matrix multiplication, and convolution.
///
/// All methods take `&self` to enable thread-safe parallel execution.
/// Compute operations read from input buffers and write to designated
/// output buffers with no overlap, enabling lock-free parallel execution.
///
/// A complete CPU fallback for every method lives in
/// [`common_ops`](crate::common_ops). Implementors can rely on the default
/// trait methods for correctness and then override individual operations with
/// hardware-specific kernels to regain performance.
pub trait ComputeBackend: ProgramBackend {
    /// Fused multiply-add for CRT batch operations.
    fn fma_scalar_crt_batch(
        &self,
        target: &mut [u8],
        a: &[u8],
        k: u64,
    ) -> Result<(), BackendError> {
        crate::common_ops::fma_scalar_crt_batch(target, a, k)
    }

    /// Element-wise vector addition.
    fn vector_add(
        &self,
        dst: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        count: usize,
    ) -> Result<(), BackendError> {
        crate::common_ops::vector_add(self, dst, a, b, count)
    }

    /// Element-wise vector multiplication.
    fn vector_mul(
        &self,
        dst: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        count: usize,
    ) -> Result<(), BackendError> {
        crate::common_ops::vector_mul(self, dst, a, b, count)
    }

    // ========================================================================
    // MATRIX MULTIPLICATION
    // ========================================================================

    /// General matrix multiplication: C = alpha * A @ B + beta * C
    ///
    /// Performs GEMM (General Matrix Multiply) with optional scaling.
    /// Uses SIMD and cache-aware tiling for optimal performance.
    ///
    /// # Arguments
    /// * `c` - Output buffer handle for result matrix C
    /// * `a` - Input buffer handle for matrix A
    /// * `b` - Input buffer handle for matrix B
    /// * `params` - Matrix multiplication parameters (dimensions, scaling, transpose)
    fn matmul(
        &self,
        c: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        params: &MatMulParams,
    ) -> Result<(), BackendError> {
        crate::common_ops::matmul(self, c, a, b, params)
    }

    /// Batched matrix multiplication.
    ///
    /// Performs multiple independent matrix multiplications in parallel.
    /// Each batch element computes: C[i] = A[i] @ B[i]
    ///
    /// # Arguments
    /// * `c` - Output buffer for batch of result matrices
    /// * `a` - Input buffer for batch of A matrices
    /// * `b` - Input buffer for batch of B matrices
    /// * `batch` - Number of matrix multiplications
    /// * `params` - Matrix multiplication parameters
    fn batch_matmul(
        &self,
        c: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        batch: u32,
        params: &MatMulParams,
    ) -> Result<(), BackendError> {
        crate::common_ops::batch_matmul(self, c, a, b, batch, params)
    }

    // ========================================================================
    // CONVOLUTION
    // ========================================================================

    /// 2D convolution: output = conv2d(input, kernel) + bias
    ///
    /// Performs 2D convolution using im2col + GEMM for efficiency.
    /// Supports strided convolution, padding, and dilation.
    ///
    /// # Arguments
    /// * `output` - Output buffer for convolution result
    /// * `input` - Input tensor buffer
    /// * `kernel` - Convolution kernel weights
    /// * `bias` - Optional bias buffer (can be null handle for no bias)
    /// * `params` - Convolution parameters
    fn conv2d(
        &self,
        output: BufferHandle,
        input: BufferHandle,
        kernel: BufferHandle,
        bias: BufferHandle,
        params: &Conv2DParams,
    ) -> Result<(), BackendError> {
        crate::common_ops::conv2d(self, output, input, kernel, bias, params)
    }

    // ========================================================================
    // SPECIALIZED CONVOLUTIONS
    // ========================================================================

    /// Depthwise 2D convolution: each input channel is convolved with its own filter.
    ///
    /// Complexity is O(B × C × H × W × K²) vs O(B × C_out × C_in × H × W × K²)
    /// for standard convolution, providing up to C_in × speedup.
    ///
    /// # Arguments
    /// * `output` - Output buffer for result
    /// * `input` - Input tensor buffer [N, C, H, W]
    /// * `kernel` - Kernel weights [C, 1, KH, KW]
    /// * `bias` - Optional bias buffer (can be null handle)
    /// * `params` - Depthwise convolution parameters
    fn depthwise_conv2d(
        &self,
        output: BufferHandle,
        input: BufferHandle,
        kernel: BufferHandle,
        bias: BufferHandle,
        params: &DepthwiseConv2DParams,
    ) -> Result<(), BackendError> {
        crate::common_ops::depthwise_conv2d(self, output, input, kernel, bias, params)
    }

    /// Pointwise (1×1) convolution as optimized GEMM.
    ///
    /// Reshapes input [N, C, H, W] to [N×H×W, C] then performs GEMM
    /// with kernel [C_in, C_out]. This is memory-bandwidth bound.
    ///
    /// # Arguments
    /// * `output` - Output buffer for result
    /// * `input` - Input tensor buffer [N, C_in, H, W]
    /// * `kernel` - Kernel weights [C_in, C_out]
    /// * `bias` - Optional bias buffer (can be null handle)
    /// * `params` - Pointwise convolution parameters
    fn pointwise_conv(
        &self,
        output: BufferHandle,
        input: BufferHandle,
        kernel: BufferHandle,
        bias: BufferHandle,
        params: &PointwiseConvParams,
    ) -> Result<(), BackendError> {
        crate::common_ops::pointwise_conv(self, output, input, kernel, bias, params)
    }

    /// Grouped 2D convolution.
    ///
    /// Channels are divided into G groups. Standard convolution is applied
    /// within each group independently. Special cases:
    /// - G = 1: Equivalent to standard conv2d
    /// - G = C_in: Equivalent to depthwise conv2d
    ///
    /// # Arguments
    /// * `output` - Output buffer for result
    /// * `input` - Input tensor buffer
    /// * `kernel` - Kernel weights [C_out, C_in/G, KH, KW]
    /// * `bias` - Optional bias buffer (can be null handle)
    /// * `params` - Grouped convolution parameters
    fn grouped_conv2d(
        &self,
        output: BufferHandle,
        input: BufferHandle,
        kernel: BufferHandle,
        bias: BufferHandle,
        params: &GroupedConv2DParams,
    ) -> Result<(), BackendError> {
        crate::common_ops::grouped_conv2d(self, output, input, kernel, bias, params)
    }

    // ========================================================================
    // ASPECT-AWARE GEMM
    // ========================================================================

    /// Aspect-ratio-aware matrix multiplication.
    ///
    /// Selects optimal tiling strategy based on matrix shape:
    /// - TallThin: narrow panels, column-major friendly
    /// - WideShort: wide panels, row-major friendly
    /// - SkinnyK: single-pass K dimension
    /// - SmallBatched: fuse across batch dimension
    ///
    /// # Arguments
    /// * `c` - Output buffer handle for result matrix C
    /// * `a` - Input buffer handle for matrix A
    /// * `b` - Input buffer handle for matrix B
    /// * `params` - Aspect-aware matrix multiplication parameters
    fn aspect_aware_matmul(
        &self,
        c: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        params: &AspectAwareMatMulParams,
    ) -> Result<(), BackendError> {
        crate::common_ops::aspect_aware_matmul(self, c, a, b, params)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_backend_type_display() {
        assert_eq!(format!("{}", BackendType::Cpu), "CPU");
        assert_eq!(format!("{}", BackendType::Wasm), "Wasm");
        assert_eq!(format!("{}", BackendType::Metal), "Metal");
        assert_eq!(format!("{}", BackendType::Cuda), "CUDA");
        assert_eq!(format!("{}", BackendType::WebGpu), "WebGPU");
        assert_eq!(format!("{}", BackendType::custom("MyBackend")), "MyBackend");
    }

    #[test]
    fn test_backend_type_is_gpu() {
        assert!(!BackendType::Cpu.is_gpu());
        assert!(!BackendType::Wasm.is_gpu());
        assert!(BackendType::Metal.is_gpu());
        assert!(BackendType::Cuda.is_gpu());
        assert!(BackendType::WebGpu.is_gpu());
        assert!(!BackendType::custom("test").is_gpu());
    }

    #[test]
    fn test_cpu_always_available() {
        assert!(BackendType::Cpu.is_available());
    }

    // ========================================================================
    // TENSOR LAYOUT TESTS
    // ========================================================================

    #[test]
    fn test_tensor_layout_matrix() {
        let layout = TensorLayout::matrix(Type::F32, 64, 128);
        assert_eq!(layout.rows(), 64);
        assert_eq!(layout.cols(), 128);
        assert_eq!(layout.numel(), 64 * 128);
        assert_eq!(layout.size_bytes(), 64 * 128 * 4); // f32 = 4 bytes
    }

    #[test]
    fn test_tensor_layout_nchw() {
        let layout = TensorLayout::nchw(Type::F32, 2, 3, 224, 224);
        assert_eq!(layout.dims, [2, 3, 224, 224]);
        assert_eq!(layout.numel(), 2 * 3 * 224 * 224);
    }

    #[test]
    fn test_tensor_layout_strides() {
        let layout = TensorLayout::new(Type::F32, [2, 3, 4, 5]);
        // Row-major strides: [3*4*5, 4*5, 5, 1]
        assert_eq!(layout.strides, [60, 20, 5, 1]);
    }

    #[test]
    fn test_tensor_layout_alignment() {
        let layout = TensorLayout::matrix(Type::F32, 64, 64).with_alignment(64);
        assert_eq!(layout.alignment, 64);
    }

    // ========================================================================
    // CONV2D PARAMS TESTS
    // ========================================================================

    #[test]
    fn test_conv2d_params_output_dims() {
        // Standard ResNet conv: 224x224 input, 7x7 kernel, stride 2, padding 3
        let params = Conv2DParams::new(
            [1, 3, 224, 224], // input
            [64, 3, 7, 7],    // kernel
            Type::F32,
        )
        .with_stride(2, 2)
        .with_padding(3, 3);

        let out = params.output_dims();
        assert_eq!(out[0], 1); // batch
        assert_eq!(out[1], 64); // output channels
        assert_eq!(out[2], 112); // height: (224 + 2*3 - 7) / 2 + 1 = 112
        assert_eq!(out[3], 112); // width
    }

    #[test]
    fn test_conv2d_params_no_padding() {
        let params = Conv2DParams::new([1, 1, 28, 28], [32, 1, 3, 3], Type::F32);

        let out = params.output_dims();
        assert_eq!(out[2], 26); // (28 - 3) / 1 + 1 = 26
        assert_eq!(out[3], 26);
    }

    #[test]
    fn test_conv2d_params_dilation() {
        let params =
            Conv2DParams::new([1, 1, 28, 28], [32, 1, 3, 3], Type::F32).with_dilation(2, 2);

        let out = params.output_dims();
        // With dilation=2, effective kernel size is 3 + (3-1)*1 = 5
        // Output: (28 - 2*(3-1) - 1) / 1 + 1 = 24
        assert_eq!(out[2], 24);
    }

    // ========================================================================
    // MATMUL PARAMS TESTS
    // ========================================================================

    #[test]
    fn test_matmul_params_basic() {
        let params = MatMulParams::new(64, 128, 256, Type::F32);
        assert_eq!(params.m, 64);
        assert_eq!(params.k, 128);
        assert_eq!(params.n, 256);
        assert_eq!(params.alpha, 1.0);
        assert_eq!(params.beta, 0.0);
    }

    #[test]
    fn test_matmul_params_scaling() {
        let params = MatMulParams::new(64, 64, 64, Type::F32).with_scaling(0.5, 1.0);
        assert_eq!(params.alpha, 0.5);
        assert_eq!(params.beta, 1.0);
    }

    #[test]
    fn test_matmul_params_transpose() {
        let params = MatMulParams::new(64, 64, 64, Type::F32).with_transpose(true, false);
        assert!(params.trans_a);
        assert!(!params.trans_b);
    }

    // ========================================================================
    // DEPTHWISE CONV2D PARAMS TESTS
    // ========================================================================

    #[test]
    fn test_depthwise_conv2d_params_basic() {
        let params = DepthwiseConv2DParams::new([1, 32, 224, 224], 3, 3, Type::F32);
        assert_eq!(params.input_dims, [1, 32, 224, 224]);
        assert_eq!(params.kernel_dims, [32, 1, 3, 3]);
        assert_eq!(params.input_channels(), 32);
        assert_eq!(params.output_channels(), 32);
    }

    #[test]
    fn test_depthwise_conv2d_output_dims() {
        let params =
            DepthwiseConv2DParams::new([2, 64, 56, 56], 3, 3, Type::F32).with_padding(1, 1);

        let out = params.output_dims();
        assert_eq!(out[0], 2); // batch
        assert_eq!(out[1], 64); // output channels = input channels
        assert_eq!(out[2], 56); // same size with padding
        assert_eq!(out[3], 56);
    }

    #[test]
    fn test_depthwise_conv2d_with_multiplier() {
        let params =
            DepthwiseConv2DParams::new([1, 32, 28, 28], 3, 3, Type::F32).with_multiplier(2);

        assert_eq!(params.input_channels(), 32);
        assert_eq!(params.output_channels(), 64); // 32 * 2
    }

    #[test]
    fn test_depthwise_conv2d_with_stride() {
        let params = DepthwiseConv2DParams::new([1, 64, 56, 56], 3, 3, Type::F32)
            .with_stride(2, 2)
            .with_padding(1, 1);

        let out = params.output_dims();
        assert_eq!(out[2], 28); // 56 / 2
        assert_eq!(out[3], 28);
    }

    // ========================================================================
    // POINTWISE CONV PARAMS TESTS
    // ========================================================================

    #[test]
    fn test_pointwise_conv_params_basic() {
        let params = PointwiseConvParams::new([2, 64, 56, 56], 128, Type::F32);
        assert_eq!(params.input_channels(), 64);
        assert_eq!(params.out_channels, 128);
        assert_eq!(params.spatial_size(), 56 * 56);
        assert_eq!(params.batch_size(), 2);
    }

    #[test]
    fn test_pointwise_conv_output_dims() {
        let params = PointwiseConvParams::new([1, 32, 224, 224], 64, Type::F32);

        let out = params.output_dims();
        assert_eq!(out[0], 1);
        assert_eq!(out[1], 64); // output channels
        assert_eq!(out[2], 224); // spatial dims unchanged
        assert_eq!(out[3], 224);
    }

    #[test]
    fn test_pointwise_conv_as_matmul_dims() {
        let params = PointwiseConvParams::new([2, 64, 7, 7], 256, Type::F32);

        let (m, k, n) = params.as_matmul_dims();
        assert_eq!(m, 2 * 7 * 7); // N * H * W = 98
        assert_eq!(k, 64); // C_in
        assert_eq!(n, 256); // C_out
    }

    // ========================================================================
    // GROUPED CONV2D PARAMS TESTS
    // ========================================================================

    #[test]
    fn test_grouped_conv2d_params_basic() {
        let params = GroupedConv2DParams::new(
            [1, 64, 56, 56],
            [128, 32, 3, 3], // C_out=128, C_in/G=32
            2,               // groups
            Type::F32,
        );
        assert_eq!(params.groups, 2);
        assert_eq!(params.input_channels_per_group(), 32); // 64 / 2
        assert_eq!(params.output_channels_per_group(), 64); // 128 / 2
    }

    #[test]
    fn test_grouped_conv2d_is_standard() {
        let params = GroupedConv2DParams::new(
            [1, 64, 56, 56],
            [128, 64, 3, 3],
            1, // groups = 1 is standard conv
            Type::F32,
        );
        assert!(params.is_standard());
        assert!(!params.is_depthwise());
    }

    #[test]
    fn test_grouped_conv2d_is_depthwise() {
        let params = GroupedConv2DParams::new(
            [1, 64, 56, 56],
            [64, 1, 3, 3],
            64, // groups = C_in is depthwise
            Type::F32,
        );
        assert!(params.is_depthwise());
        assert!(!params.is_standard());
    }

    #[test]
    fn test_grouped_conv2d_output_dims() {
        let params = GroupedConv2DParams::new(
            [2, 32, 28, 28],
            [64, 8, 3, 3],
            4, // 4 groups
            Type::F32,
        )
        .with_padding(1, 1);

        let out = params.output_dims();
        assert_eq!(out[0], 2); // batch
        assert_eq!(out[1], 64); // output channels
        assert_eq!(out[2], 28); // same with padding
        assert_eq!(out[3], 28);
    }

    // ========================================================================
    // GEMM ASPECT HINT TESTS
    // ========================================================================

    #[test]
    fn test_gemm_aspect_hint_balanced() {
        let hint = GemmAspectHint::detect(256, 256, 256);
        assert_eq!(hint, GemmAspectHint::Balanced);
    }

    #[test]
    fn test_gemm_aspect_hint_tall_thin() {
        let hint = GemmAspectHint::detect(1024, 256, 64);
        assert_eq!(hint, GemmAspectHint::TallThin);
    }

    #[test]
    fn test_gemm_aspect_hint_wide_short() {
        let hint = GemmAspectHint::detect(64, 256, 1024);
        assert_eq!(hint, GemmAspectHint::WideShort);
    }

    #[test]
    fn test_gemm_aspect_hint_small_batched() {
        let hint = GemmAspectHint::detect(8, 8, 8);
        assert_eq!(hint, GemmAspectHint::SmallBatched);
    }

    #[test]
    fn test_gemm_aspect_hint_default() {
        assert_eq!(GemmAspectHint::default(), GemmAspectHint::Balanced);
    }

    // ========================================================================
    // ASPECT-AWARE MATMUL PARAMS TESTS
    // ========================================================================

    #[test]
    fn test_aspect_aware_matmul_params_auto_detect() {
        let params = AspectAwareMatMulParams::new(1024, 256, 64, Type::F32);
        assert_eq!(params.aspect_hint, GemmAspectHint::TallThin);
        assert_eq!(params.base.m, 1024);
        assert_eq!(params.base.k, 256);
        assert_eq!(params.base.n, 64);
    }

    #[test]
    fn test_aspect_aware_matmul_params_explicit_hint() {
        let base = MatMulParams::new(128, 128, 128, Type::F32);
        let params = AspectAwareMatMulParams::with_hint(base, GemmAspectHint::SmallBatched);
        assert_eq!(params.aspect_hint, GemmAspectHint::SmallBatched);
    }

    #[test]
    fn test_aspect_aware_matmul_params_from_matmul() {
        let base = MatMulParams::new(64, 256, 1024, Type::F32);
        let params: AspectAwareMatMulParams = base.into();
        assert_eq!(params.aspect_hint, GemmAspectHint::WideShort);
    }

    #[test]
    fn test_aspect_aware_matmul_params_with_batch() {
        let params = AspectAwareMatMulParams::new(16, 16, 16, Type::F32).with_batch_count(32);
        assert_eq!(params.batch_count, Some(32));
    }

    #[test]
    fn test_aspect_aware_matmul_params_scaling() {
        let params = AspectAwareMatMulParams::new(64, 64, 64, Type::F32).with_scaling(0.5, 0.1);
        assert_eq!(params.base.alpha, 0.5);
        assert_eq!(params.base.beta, 0.1);
    }
}
