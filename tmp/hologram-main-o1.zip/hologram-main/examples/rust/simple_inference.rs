//! Simple inference example.
//!
//! Demonstrates basic model execution with the CPU backend.
//!
//! Run with: `cargo run --example simple_inference`

use hologram_backend::{cpu::CpuBackend, Backend};
use hologram_holo::types::BufferType;
use hologram_holo::{BackendPlan, BufferMetadata, IsaInstruction, PlanMetadata};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("=== Simple Inference Example ===\n");

    // Create a simple plan that adds two vectors and applies ReLU
    let plan = create_add_relu_plan();

    // Create the CPU backend
    let backend = CpuBackend::new();
    println!("Backend: {:?}", backend.backend_type());
    println!("Capabilities: {:?}\n", backend.capabilities());

    // Prepare input data (4 f32 values each)
    let input_a: Vec<f32> = vec![1.0, -2.0, 3.0, -4.0];
    let input_b: Vec<f32> = vec![0.5, 2.5, -1.0, 5.0];

    println!("Input A: {:?}", input_a);
    println!("Input B: {:?}", input_b);

    // Convert to bytes
    let input_a_bytes: Vec<u8> = bytemuck::cast_slice(&input_a).to_vec();
    let input_b_bytes: Vec<u8> = bytemuck::cast_slice(&input_b).to_vec();

    // Prepare output buffer
    let mut output_bytes: Vec<u8> = vec![0u8; 16]; // 4 * sizeof(f32)

    // Execute the plan
    backend.execute_plan(
        &plan,
        &[&input_a_bytes, &input_b_bytes],
        &mut [&mut output_bytes],
    )?;

    // Interpret result as f32
    let result: &[f32] = bytemuck::cast_slice(&output_bytes);
    println!("\nResult (A + B, then ReLU): {:?}", result);

    // Verify: (1+0.5)=1.5, (-2+2.5)=0.5, (3-1)=2, (-4+5)=1
    // All positive, so ReLU doesn't change them
    println!("\nExpected: [1.5, 0.5, 2.0, 1.0]");

    Ok(())
}

/// Create a plan that computes ReLU(A + B).
fn create_add_relu_plan() -> BackendPlan {
    // Buffer layout:
    // 0: Input A (4 f32 = 16 bytes)
    // 1: Input B (4 f32 = 16 bytes)
    // 2: Workspace (intermediate add result)
    // 3: Output (4 f32 = 16 bytes)

    let buffers = vec![
        BufferMetadata {
            size: 16,
            alignment: 32,
            buffer_type: BufferType::Input,
            fully_written: false,
        },
        BufferMetadata {
            size: 16,
            alignment: 32,
            buffer_type: BufferType::Input,
            fully_written: false,
        },
        BufferMetadata {
            size: 16,
            alignment: 32,
            buffer_type: BufferType::Workspace,
            fully_written: false,
        },
        BufferMetadata {
            size: 16,
            alignment: 32,
            buffer_type: BufferType::Output,
            fully_written: false,
        },
    ];

    let instructions = vec![
        // Add: workspace[2] = input[0] + input[1]
        IsaInstruction::Add {
            dst: 2,
            a: 0,
            b: 1,
            count: 4,
        },
        // ReLU: output[3] = relu(workspace[2])
        IsaInstruction::Relu {
            dst: 3,
            src: 2,
            count: 4,
        },
    ];

    BackendPlan {
        instructions,
        buffers,
        constants: vec![],
        workspace_size: 16,
        dependencies: vec![],
        metadata: PlanMetadata {
            name: "add_relu_example".to_string(),
            version: "1.0.0".to_string(),
            author: Some("Hologram".to_string()),
            description: Some("Computes ReLU(A + B)".to_string()),
        },
        node_buffer_map: vec![],
        observable_metadata: hologram_holo::ObservableMetadata::default(),
        lut_section: hologram_holo::LutSection::new(),
    }
}
