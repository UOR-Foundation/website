//! Worker orchestration for Hologram distributed execution.
//!
//! This crate provides the infrastructure for provisioning and managing
//! distributed worker instances for Hologram computation.
//!
//! # Features
//!
//! - `async`: Enable async orchestrator traits (default)
//! - `security`: Enable Ed25519 identity and token support
//! - `mtls`: Enable mTLS certificate management (requires `security`)
//! - `firecracker`: Enable Firecracker VM backend
//! - `kubernetes`: Enable Kubernetes pod backend
//! - `full`: Enable all features
//!
//! # Core Types
//!
//! - [`WorkerHandle`] - Unique identifier for a provisioned worker
//! - [`WorkerState`] - Current state of a worker (Provisioning, Running, etc.)
//! - [`WorkerInfo`] - Detailed information about a worker
//! - [`ProvisionConfig`] - Configuration for provisioning a new worker
//! - [`WorkerResources`] - Resource allocation (vCPUs, memory, GPU)
//!
//! # Traits
//!
//! - [`Orchestrator`] - Synchronous worker lifecycle management
//! - [`AsyncOrchestrator`] - Asynchronous worker lifecycle management (feature: `async`)
//! - [`HealthCheckOrchestrator`] - Health check extension
//!
//! # Example
//!
//! ```rust,ignore
//! use hologram_orchestrate::{Orchestrator, ProvisionConfig, WorkerResources};
//! use hologram_backend::BackendType;
//!
//! // Create provision config
//! let config = ProvisionConfig::new()
//!     .with_backend(BackendType::Cpu)
//!     .with_resources(WorkerResources::new()
//!         .with_vcpus(4)
//!         .with_memory_mib(8192))
//!     .with_bootstrap_peer("192.168.1.100:9000")
//!     .with_env("RUST_LOG", "info");
//!
//! // Provision a worker
//! let handle = orchestrator.provision(config)?;
//!
//! // Check worker info
//! let info = orchestrator.worker_info(handle)?;
//! println!("Worker state: {}", info.state);
//!
//! // Terminate when done
//! orchestrator.terminate(handle)?;
//! ```

mod error;
pub mod security;
mod traits;
mod types;

pub use error::{OrchestrateError, Result};
pub use traits::{
    HealthCheckConfig, HealthCheckOrchestrator, HealthStatus, Orchestrator,
    OrchestratorCapabilities,
};
pub use types::{
    GpuAllocation, ProvisionConfig, WorkerHandle, WorkerImage, WorkerInfo, WorkerResources,
    WorkerState,
};

#[cfg(feature = "async")]
pub use traits::{AsyncHealthCheckOrchestrator, AsyncOrchestrator};

pub use security::SecurityConfig;

#[cfg(feature = "security")]
pub use security::{ClusterIdentity, TokenVerifyResult, WorkerToken};

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_public_exports() {
        // Verify core types are exported
        let _handle = WorkerHandle::new(1);
        let _state = WorkerState::Running;
        let _resources = WorkerResources::new();
        let _config = ProvisionConfig::new();
        let _caps = OrchestratorCapabilities::new("test");
        let _health = HealthStatus::healthy();
        let _health_config = HealthCheckConfig::new();
        let _security = SecurityConfig::new();
    }

    #[test]
    fn test_error_types() {
        let err = OrchestrateError::provision_failed("test");
        assert!(err.to_string().contains("test"));
    }

    #[test]
    fn test_worker_lifecycle_types() {
        // WorkerHandle
        let handle = WorkerHandle::new(42);
        assert_eq!(handle.id(), 42);
        assert_eq!(format!("{handle}"), "worker-0000002a");

        // WorkerState
        let state = WorkerState::Running;
        assert!(state.is_running());
        assert!(!state.is_terminal());

        // WorkerResources
        let resources = WorkerResources::new().with_vcpus(8).with_memory_mib(16384);
        assert_eq!(resources.vcpus, 8);
        assert_eq!(resources.memory_mib, 16384);
    }

    #[test]
    fn test_provision_config() {
        use hologram_backend::BackendType;

        let config = ProvisionConfig::new()
            .with_backend(BackendType::Cuda)
            .with_resources(WorkerResources::new().with_gpu(GpuAllocation::nvidia_a100(2)))
            .with_bootstrap_peer("peer1:9000")
            .with_env("KEY", "value")
            .with_label("pool", "compute");

        assert_eq!(config.backend_type, BackendType::Cuda);
        assert!(config.resources.has_gpu());
        assert_eq!(config.bootstrap_peers, vec!["peer1:9000".to_string()]);
        assert_eq!(config.env.get("KEY"), Some(&"value".to_string()));
        assert_eq!(config.labels.get("pool"), Some(&"compute".to_string()));
    }

    #[test]
    fn test_worker_info() {
        use hologram_backend::BackendType;

        let info = WorkerInfo::new(WorkerHandle::new(1), "vm-001", BackendType::Cpu)
            .with_state(WorkerState::Running)
            .with_address("192.168.1.100:8080")
            .with_peer_id("peer-abc")
            .with_label("role", "worker");

        assert!(info.is_running());
        assert!(!info.is_terminal());
        assert_eq!(info.address, Some("192.168.1.100:8080".to_string()));
        assert_eq!(info.peer_id, Some("peer-abc".to_string()));
    }

    #[test]
    fn test_orchestrator_capabilities() {
        use hologram_backend::BackendType;
        use std::time::Duration;

        let caps = OrchestratorCapabilities::new("firecracker")
            .with_max_workers(100)
            .with_backend(BackendType::Cuda)
            .with_gpu_support()
            .with_auto_scale_support()
            .with_provision_latency(Duration::from_secs(5));

        assert_eq!(caps.name, "firecracker");
        assert_eq!(caps.max_workers, Some(100));
        assert!(caps.gpu_support);
        assert!(caps.auto_scale_support);
        assert!(caps.supports_backend(&BackendType::Cpu));
        assert!(caps.supports_backend(&BackendType::Cuda));
        assert!(caps.can_provision(50));
        assert!(!caps.can_provision(100));
    }

    #[test]
    fn test_health_status() {
        let healthy = HealthStatus::healthy();
        assert!(healthy.healthy);
        assert_eq!(healthy.consecutive_failures, 0);

        let unhealthy = HealthStatus::unhealthy(3, "connection refused");
        assert!(!unhealthy.healthy);
        assert_eq!(unhealthy.consecutive_failures, 3);
        assert_eq!(unhealthy.details, Some("connection refused".to_string()));
    }

    #[test]
    fn test_health_check_config() {
        use std::time::Duration;

        let config = HealthCheckConfig::new()
            .with_interval(Duration::from_secs(5))
            .with_timeout(Duration::from_secs(2))
            .with_unhealthy_threshold(5)
            .with_healthy_threshold(3);

        assert_eq!(config.interval, Duration::from_secs(5));
        assert_eq!(config.timeout, Duration::from_secs(2));
        assert_eq!(config.unhealthy_threshold, 5);
        assert_eq!(config.healthy_threshold, 3);
    }
}
