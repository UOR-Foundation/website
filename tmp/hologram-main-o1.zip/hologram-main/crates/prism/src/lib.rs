//! Prism -- conformance-driven state transformations.
//!
//! Prism provides a NumPy-style API for operating on 624-byte states
//! backed by UOR wavefront execution. Every operation declares conformance
//! targets and is verified against them.
//!
//! # Architecture
//!
//! ```text
//! State (624 taxons = 4992 bits)
//!   │
//!   ├── ops::elementwise  -- xor, and, or, not, add, sub, shl, shr, rotl, rotr
//!   ├── ops::reduce       -- xor_reduce, sum, max, min
//!   ├── ops::shuffle      -- shuffle, permute, broadcast
//!   ├── programs          -- sha256, aes (pre-built operation sequences)
//!   └── ext               -- define_op! macro for user extensions
//! ```
//!
//! # Conformance
//!
//! Every operation has mandatory conformance targets (minimum, optimal,
//! theoretical cycle counts). Operations that fail to meet the minimum
//! tier are non-conformant and rejected from the stdlib.
//!
//! # Example
//!
//! ```
//! use prism::prelude::*;
//!
//! let a = State::zeros();
//! let b = State::ones();
//! let r = xor(a, b);
//! assert_eq!(r, b);
//! ```

#![deny(missing_docs)]
#![deny(clippy::all)]
#![warn(clippy::pedantic)]
#![allow(clippy::module_name_repetitions)]
#![allow(clippy::missing_errors_doc)]
#![allow(clippy::missing_panics_doc)]

pub mod ext;
pub mod ops;
pub mod programs;
pub mod state;

/// Prelude for convenient imports.
///
/// ```
/// use prism::prelude::*;
///
/// let s = State::zeros();
/// assert_eq!(s.as_bytes().len(), 624);
/// ```
pub mod prelude {
    // Core type
    pub use crate::state::State;

    // Elementwise free functions
    pub use crate::ops::elementwise::{add, and, not, or, rotl, rotr, shl, shr, sub, xor};

    // Reduction free functions
    pub use crate::ops::reduce::{max, min, sum, xor_reduce};

    // Shuffle free functions
    pub use crate::ops::shuffle::{broadcast, permute, shuffle};

    // Operation traits and conformance
    pub use crate::ops::{
        BinaryOperation, ConformanceResult, ConformanceTargets, ConformanceTier, Operation,
    };

    // Verification helpers
    pub use crate::ops::{verify_binary_operation, verify_operation};

    // Program functions
    pub use crate::programs::aes::{aes128_encrypt, aes256_encrypt};
    pub use crate::programs::sha256::sha256_compress;
}
