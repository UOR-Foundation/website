/**
 * HologramLogo — Isometric Dot-Grid Hexagon/Cube with "H"
 * Exact copy from hologram-ui/components/HologramLogo.tsx
 */

interface HologramLogoProps {
  size?: number;
  color?: string;
  className?: string;
}

type Dot = [number, 0 | 1 | 2];

const ROWS: { dots: Dot[] }[] = [
  { dots: [[-1.5, 0], [-0.5, 0], [0.5, 0], [1.5, 1]] },
  { dots: [[-2, 0], [-1, 0], [0, 1], [1, 2], [2, 1]] },
  { dots: [[-2.5, 0], [-1.5, 0], [-0.5, 2], [0.5, 0], [1.5, 2], [2.5, 2]] },
  { dots: [[-3, 0], [-2, 2], [-1, 0], [0, 0], [1, 2], [2, 2], [3, 0]] },
  { dots: [[-3, 0], [-2, 2], [-1, 2], [0, 2], [1, 2], [2, 2], [3, 0]] },
  { dots: [[-3.5, 0], [-2.5, 2], [-1.5, 2], [-0.5, 2], [0.5, 2], [1.5, 2], [2.5, 2], [3.5, 0]] },
  { dots: [[-3, 0], [-2, 2], [-1, 0], [0, 0], [1, 0], [2, 2], [3, 0]] },
  { dots: [[-2.5, 0], [-1.5, 2], [-0.5, 0], [0.5, 0], [1.5, 0], [2.5, 2]] },
  { dots: [[-2, 0], [-1, 0], [0, 0], [1, 0], [2, 0]] },
  { dots: [[-1.5, 0], [-0.5, 0], [0.5, 0], [1.5, 0]] },
];

const RADII = [1.2, 2.4, 4.2] as const;
const OPACITIES = [0.35, 0.65, 1.0] as const;
const COL_SPACING = 10;
const ROW_HEIGHT = COL_SPACING * 0.866;

export default function HologramLogo({ size = 32, color = "currentColor", className }: HologramLogoProps) {
  const pad = 6;
  const w = 8 * COL_SPACING + pad * 2;
  const h = (ROWS.length - 1) * ROW_HEIGHT + pad * 2;

  return (
    <svg
      width={size}
      height={size}
      viewBox={`${-w / 2} ${-pad} ${w} ${h}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Hologram logo"
    >
      {ROWS.map((row, ri) =>
        row.dots.map(([col, sz], di) => (
          <circle
            key={`${ri}-${di}`}
            cx={col * COL_SPACING}
            cy={ri * ROW_HEIGHT}
            r={RADII[sz]}
            fill={color}
            opacity={OPACITIES[sz]}
          />
        ))
      )}
    </svg>
  );
}
