//! Prefix trie for vocabulary lookup.
//!
//! The prefix trie enables efficient longest-match tokenization by finding
//! all vocabulary tokens that match at a given position in the input text.

use std::collections::HashMap;

/// A prefix trie for efficient vocabulary lookup.
///
/// Each node in the trie represents a character position, with edges labeled
/// by Unicode codepoints. Nodes may optionally contain a token ID and score
/// if the path to that node forms a complete vocabulary token.
#[derive(Debug, Clone, Default)]
pub struct PrefixTrie {
    /// Child nodes indexed by codepoint.
    children: HashMap<u32, PrefixTrie>,
    /// Token ID if this node represents a complete token.
    token_id: Option<u32>,
    /// Token score (log probability) if this is a complete token.
    score: Option<f32>,
}

/// A match found in the trie at a given position.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TrieMatch {
    /// Token ID of the matched token.
    pub token_id: u32,
    /// Length of the match in codepoints.
    pub length: usize,
    /// Score (log probability) of the token.
    pub score: f32,
}

impl PrefixTrie {
    /// Create a new empty trie.
    pub fn new() -> Self {
        Self::default()
    }

    /// Insert a token into the trie.
    ///
    /// # Arguments
    /// * `codepoints` - The token as a sequence of Unicode codepoints
    /// * `token_id` - The token's ID in the vocabulary
    /// * `score` - The token's log probability score
    pub fn insert(&mut self, codepoints: &[u32], token_id: u32, score: f32) {
        let mut node = self;
        for &cp in codepoints {
            node = node.children.entry(cp).or_default();
        }
        node.token_id = Some(token_id);
        node.score = Some(score);
    }

    /// Insert a token given as a string.
    pub fn insert_str(&mut self, token: &str, token_id: u32, score: f32) {
        let codepoints: Vec<u32> = token.chars().map(|c| c as u32).collect();
        self.insert(&codepoints, token_id, score);
    }

    /// Find all matching tokens starting at the beginning of the input.
    ///
    /// Returns all tokens that match a prefix of the input, not just the longest.
    /// This is needed for Viterbi tokenization which considers all possible paths.
    ///
    /// # Arguments
    /// * `codepoints` - The input text as codepoints
    ///
    /// # Returns
    /// A vector of all matching tokens, sorted by length (shortest first).
    pub fn find_matches(&self, codepoints: &[u32]) -> Vec<TrieMatch> {
        let mut matches = Vec::new();
        let mut node = self;
        let mut depth = 0usize;

        for &cp in codepoints.iter() {
            // Try to extend the match first
            match node.children.get(&cp) {
                Some(child) => {
                    node = child;
                    depth += 1;

                    // Check if new node is a complete token
                    if let (Some(token_id), Some(score)) = (node.token_id, node.score) {
                        matches.push(TrieMatch {
                            token_id,
                            length: depth,
                            score,
                        });
                    }
                }
                None => break,
            }
        }

        matches
    }

    /// Find the longest matching token at the start of the input.
    pub fn find_longest(&self, codepoints: &[u32]) -> Option<TrieMatch> {
        let mut best: Option<TrieMatch> = None;
        let mut node = self;
        let mut depth = 0usize;

        for &cp in codepoints.iter() {
            // Try to extend the match
            match node.children.get(&cp) {
                Some(child) => {
                    node = child;
                    depth += 1;

                    // Check if new node is a complete token
                    if let (Some(token_id), Some(score)) = (node.token_id, node.score) {
                        best = Some(TrieMatch {
                            token_id,
                            length: depth,
                            score,
                        });
                    }
                }
                None => return best,
            }
        }

        best
    }

    /// Check if the trie contains a specific token.
    pub fn contains(&self, codepoints: &[u32]) -> bool {
        let mut node = self;
        for &cp in codepoints {
            match node.children.get(&cp) {
                Some(child) => node = child,
                None => return false,
            }
        }
        node.token_id.is_some()
    }

    /// Get the number of tokens in the trie.
    pub fn len(&self) -> usize {
        let mut count = if self.token_id.is_some() { 1 } else { 0 };
        for child in self.children.values() {
            count += child.len();
        }
        count
    }

    /// Check if the trie is empty.
    pub fn is_empty(&self) -> bool {
        self.children.is_empty() && self.token_id.is_none()
    }

    /// Build a trie from a vocabulary.
    ///
    /// # Arguments
    /// * `vocab` - Iterator of (token_string, token_id, score) tuples
    pub fn from_vocab<'a>(vocab: impl Iterator<Item = (&'a str, u32, f32)>) -> Self {
        let mut trie = Self::new();
        for (token, id, score) in vocab {
            trie.insert_str(token, id, score);
        }
        trie
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_trie_new() {
        let trie = PrefixTrie::new();
        assert!(trie.is_empty());
        assert_eq!(trie.len(), 0);
    }

    #[test]
    fn test_trie_insert_and_contains() {
        let mut trie = PrefixTrie::new();
        trie.insert_str("hello", 1, -1.0);

        let hello: Vec<u32> = "hello".chars().map(|c| c as u32).collect();
        assert!(trie.contains(&hello));

        let world: Vec<u32> = "world".chars().map(|c| c as u32).collect();
        assert!(!trie.contains(&world));
    }

    #[test]
    fn test_trie_exact_match() {
        let mut trie = PrefixTrie::new();
        trie.insert_str("hello", 1, -1.0);

        let hello: Vec<u32> = "hello".chars().map(|c| c as u32).collect();
        let result = trie.find_longest(&hello);

        assert!(result.is_some());
        let m = result.unwrap();
        assert_eq!(m.token_id, 1);
        assert_eq!(m.length, 5);
        assert_eq!(m.score, -1.0);
    }

    #[test]
    fn test_trie_prefix_matches() {
        let mut trie = PrefixTrie::new();
        trie.insert_str("h", 1, -0.5);
        trie.insert_str("he", 2, -1.0);
        trie.insert_str("hel", 3, -1.5);
        trie.insert_str("hello", 4, -2.0);

        let hello: Vec<u32> = "hello".chars().map(|c| c as u32).collect();
        let matches = trie.find_matches(&hello);

        // Should find all prefix matches
        assert_eq!(matches.len(), 4);
        assert_eq!(matches[0].token_id, 1); // "h"
        assert_eq!(matches[1].token_id, 2); // "he"
        assert_eq!(matches[2].token_id, 3); // "hel"
        assert_eq!(matches[3].token_id, 4); // "hello"
    }

    #[test]
    fn test_trie_no_match() {
        let mut trie = PrefixTrie::new();
        trie.insert_str("hello", 1, -1.0);

        let world: Vec<u32> = "world".chars().map(|c| c as u32).collect();
        let matches = trie.find_matches(&world);

        assert!(matches.is_empty());
    }

    #[test]
    fn test_trie_single_char() {
        let mut trie = PrefixTrie::new();
        trie.insert_str("a", 1, -0.1);
        trie.insert_str("b", 2, -0.2);

        let a: Vec<u32> = "a".chars().map(|c| c as u32).collect();
        let result = trie.find_longest(&a);

        assert!(result.is_some());
        assert_eq!(result.unwrap().token_id, 1);
    }

    #[test]
    fn test_trie_long_token() {
        let mut trie = PrefixTrie::new();
        let long_token = "supercalifragilisticexpialidocious";
        trie.insert_str(long_token, 1, -10.0);

        let cps: Vec<u32> = long_token.chars().map(|c| c as u32).collect();
        let result = trie.find_longest(&cps);

        assert!(result.is_some());
        assert_eq!(result.unwrap().length, long_token.len());
    }

    #[test]
    fn test_trie_unicode() {
        let mut trie = PrefixTrie::new();
        // SentencePiece underscore: ▁ (U+2581)
        trie.insert_str("\u{2581}hello", 1, -1.0);
        trie.insert_str("\u{2581}", 2, -0.5);

        let input: Vec<u32> = "\u{2581}hello".chars().map(|c| c as u32).collect();
        let matches = trie.find_matches(&input);

        assert_eq!(matches.len(), 2);
    }

    #[test]
    fn test_trie_len() {
        let mut trie = PrefixTrie::new();
        assert_eq!(trie.len(), 0);

        trie.insert_str("a", 1, -0.1);
        assert_eq!(trie.len(), 1);

        trie.insert_str("ab", 2, -0.2);
        assert_eq!(trie.len(), 2);

        trie.insert_str("abc", 3, -0.3);
        assert_eq!(trie.len(), 3);

        // "b" shares no prefix with existing
        trie.insert_str("b", 4, -0.4);
        assert_eq!(trie.len(), 4);
    }

    #[test]
    fn test_trie_from_vocab() {
        let vocab = [("hello", 1, -1.0), ("world", 2, -1.5), ("hi", 3, -0.5)];

        let trie = PrefixTrie::from_vocab(vocab.iter().map(|(s, id, score)| (*s, *id, *score)));

        assert_eq!(trie.len(), 3);

        let hello: Vec<u32> = "hello".chars().map(|c| c as u32).collect();
        assert!(trie.contains(&hello));
    }

    #[test]
    fn test_trie_empty_input() {
        let mut trie = PrefixTrie::new();
        trie.insert_str("a", 1, -0.1);

        let empty: Vec<u32> = vec![];
        let matches = trie.find_matches(&empty);

        assert!(matches.is_empty());
    }

    #[test]
    fn test_trie_partial_match() {
        let mut trie = PrefixTrie::new();
        trie.insert_str("hello", 1, -1.0);

        // Input is longer than any token
        let input: Vec<u32> = "helloworld".chars().map(|c| c as u32).collect();
        let result = trie.find_longest(&input);

        assert!(result.is_some());
        assert_eq!(result.unwrap().token_id, 1);
        assert_eq!(result.unwrap().length, 5); // "hello"
    }
}
