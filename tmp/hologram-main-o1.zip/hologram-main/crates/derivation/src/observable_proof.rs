//! Observable-based proof verification and certification.
//!
//! This module provides integration between derivation chains and monodromy
//! observables, enabling computation verification based on topological invariants.
//!
//! # Certification Workflow
//!
//! 1. Execute a derivation chain, recording intermediate values
//! 2. Compute monodromy observables over the execution path
//! 3. Generate a certificate including the monodromy signature
//! 4. Verify by recomputing observables and comparing signatures
//!
//! # Example
//!
//! ```
//! use hologram_derivation::{DerivationChain, DerivationStep, StepKind};
//! use hologram_derivation::observable_proof::{ObservableProof, TracedDerivation};
//!
//! // Create a derivation chain
//! let mut chain = DerivationChain::new("test", "Test Derivation");
//! chain.add_step(DerivationStep::new(0, "Init", StepKind::TypeDeclaration)
//!     .with_input(serde_json::json!({"value": 42}))
//!     .with_output(serde_json::json!({"value": 42})));
//!
//! // Create a traced derivation with path values
//! let path = vec![42u64, 43, 44, 45];
//! let traced = TracedDerivation::new(chain, path, 8);
//!
//! // Generate an observable proof
//! let proof = ObservableProof::from_traced(&traced);
//! assert!(proof.signature.is_some());
//! ```

use crate::{DerivationChain, DerivationStep, StepKind};
use serde::{Deserialize, Serialize};
use uor::observable::{cascade_spectrum, total_variation, winding_number, MonodromySignature};

/// Serializable monodromy signature for proof storage.
///
/// This mirrors `uor::observable::MonodromySignature` but with serde support.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SerializableSignature {
    /// Winding number: net cycles around the ring.
    pub winding: i64,

    /// Total variation: cumulative stratum change.
    pub total_variation: u64,

    /// Cascade spectrum: histogram of cascade lengths.
    pub cascade_spectrum: Vec<u32>,
}

impl From<MonodromySignature> for SerializableSignature {
    fn from(sig: MonodromySignature) -> Self {
        Self {
            winding: sig.winding,
            total_variation: sig.total_variation,
            cascade_spectrum: sig.cascade_spectrum,
        }
    }
}

impl SerializableSignature {
    /// Compute the serializable signature for a path.
    pub fn from_path(path: &[u64], quantum: u32) -> Self {
        MonodromySignature::from_path(path, quantum).into()
    }

    /// Compute normalized total variation.
    pub fn normalized_total_variation(&self) -> Option<f64> {
        let total_transitions: u32 = self.cascade_spectrum.iter().sum();
        if total_transitions == 0 {
            return None;
        }
        Some(self.total_variation as f64 / total_transitions as f64)
    }
}

/// A derivation with observable measurements.
///
/// Combines a derivation chain with the monodromy signature computed
/// over its execution path.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObservableProof {
    /// The underlying derivation chain.
    pub derivation: DerivationChain,

    /// The monodromy signature (if computed).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub signature: Option<SerializableSignature>,

    /// The quantum level used for observable computation.
    pub quantum: u32,

    /// Individual observable values.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub observables: Option<ObservableValues>,
}

/// Individual observable values for a computation path.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObservableValues {
    /// Winding number (net ring traversals).
    pub winding: i64,

    /// Total variation (cumulative stratum change).
    pub variation: u64,

    /// Cascade spectrum (carry-cascade histogram).
    pub cascade: Vec<u32>,
}

impl ObservableValues {
    /// Compute all observables for a path at the given quantum level.
    pub fn compute(path: &[u64], quantum: u32) -> Self {
        Self {
            winding: winding_number(path, quantum),
            variation: total_variation(path, quantum),
            cascade: cascade_spectrum(path, quantum),
        }
    }
}

impl ObservableProof {
    /// Create an observable proof from a derivation chain without path data.
    ///
    /// The signature will be None since no execution path is provided.
    pub fn new(derivation: DerivationChain, quantum: u32) -> Self {
        Self {
            derivation,
            signature: None,
            quantum,
            observables: None,
        }
    }

    /// Create an observable proof from a traced derivation.
    pub fn from_traced(traced: &TracedDerivation) -> Self {
        let observables = ObservableValues::compute(&traced.path, traced.quantum);
        let signature = SerializableSignature::from_path(&traced.path, traced.quantum);

        Self {
            derivation: traced.derivation.clone(),
            signature: Some(signature),
            quantum: traced.quantum,
            observables: Some(observables),
        }
    }

    /// Create an observable proof with explicit path data.
    pub fn with_path(derivation: DerivationChain, path: &[u64], quantum: u32) -> Self {
        let observables = ObservableValues::compute(path, quantum);
        let signature = SerializableSignature::from_path(path, quantum);

        Self {
            derivation,
            signature: Some(signature),
            quantum,
            observables: Some(observables),
        }
    }

    /// Check if this proof has observable measurements.
    pub fn has_observables(&self) -> bool {
        self.observables.is_some()
    }

    /// Get the monodromy signature if available.
    pub fn monodromy_signature(&self) -> Option<&SerializableSignature> {
        self.signature.as_ref()
    }
}

/// A derivation chain with traced execution path.
///
/// Records the sequence of values visited during derivation execution,
/// enabling observable computation.
#[derive(Debug, Clone)]
pub struct TracedDerivation {
    /// The derivation chain.
    pub derivation: DerivationChain,

    /// The execution path (sequence of values visited).
    pub path: Vec<u64>,

    /// The quantum level for observable computation.
    pub quantum: u32,

    /// Per-step observable snapshots.
    pub step_observables: Vec<StepObservable>,
}

/// Observable snapshot at a derivation step.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StepObservable {
    /// Step index.
    pub step_index: usize,

    /// Value at this step.
    pub value: u64,

    /// Cumulative winding number up to this step.
    pub cumulative_winding: i64,

    /// Cumulative total variation up to this step.
    pub cumulative_variation: u64,
}

impl TracedDerivation {
    /// Create a new traced derivation.
    pub fn new(derivation: DerivationChain, path: Vec<u64>, quantum: u32) -> Self {
        let step_observables = Self::compute_step_observables(&path, quantum);
        Self {
            derivation,
            path,
            quantum,
            step_observables,
        }
    }

    /// Compute per-step observable snapshots.
    fn compute_step_observables(path: &[u64], quantum: u32) -> Vec<StepObservable> {
        let mut observables = Vec::with_capacity(path.len());

        for (i, &value) in path.iter().enumerate() {
            let subpath = &path[..=i];
            observables.push(StepObservable {
                step_index: i,
                value,
                cumulative_winding: winding_number(subpath, quantum),
                cumulative_variation: total_variation(subpath, quantum),
            });
        }

        observables
    }

    /// Get the final monodromy signature.
    pub fn signature(&self) -> SerializableSignature {
        SerializableSignature::from_path(&self.path, self.quantum)
    }

    /// Get the observable values at a specific step.
    pub fn observable_at(&self, step: usize) -> Option<&StepObservable> {
        self.step_observables.get(step)
    }

    /// Check if observables are monotonically increasing (for variation).
    ///
    /// Total variation should never decrease along a path.
    pub fn variation_is_monotonic(&self) -> bool {
        self.step_observables
            .windows(2)
            .all(|w| w[1].cumulative_variation >= w[0].cumulative_variation)
    }
}

/// Verification result for observable proofs.
#[derive(Debug, Clone)]
pub struct ObservableVerification {
    /// Whether the signature matches.
    pub signature_valid: bool,

    /// Whether the variation is monotonic.
    pub variation_monotonic: bool,

    /// The computed signature (for comparison).
    pub computed_signature: Option<SerializableSignature>,

    /// Detailed error message if verification failed.
    pub error: Option<String>,
}

impl ObservableVerification {
    /// Check if verification passed.
    pub fn is_valid(&self) -> bool {
        self.signature_valid && self.variation_monotonic && self.error.is_none()
    }
}

/// Verify an observable proof by recomputing observables.
///
/// Recomputes the monodromy signature from the provided path and compares
/// it to the signature in the proof.
pub fn verify_observable_proof(proof: &ObservableProof, path: &[u64]) -> ObservableVerification {
    let computed_signature = SerializableSignature::from_path(path, proof.quantum);

    let signature_valid = proof
        .signature
        .as_ref()
        .map(|s| *s == computed_signature)
        .unwrap_or(false);

    // Check variation monotonicity
    let mut prev_variation = 0u64;
    let mut variation_monotonic = true;
    for i in 0..path.len() {
        let subpath = &path[..=i];
        let variation = total_variation(subpath, proof.quantum);
        if variation < prev_variation {
            variation_monotonic = false;
            break;
        }
        prev_variation = variation;
    }

    let error = if !signature_valid {
        Some(format!(
            "Signature mismatch: expected {:?}, computed {:?}",
            proof.signature, computed_signature
        ))
    } else if !variation_monotonic {
        Some("Total variation is not monotonic".to_string())
    } else {
        None
    };

    ObservableVerification {
        signature_valid,
        variation_monotonic,
        computed_signature: Some(computed_signature),
        error,
    }
}

/// Generate a certification step for observable measurements.
///
/// Creates a derivation step documenting the monodromy signature.
pub fn certification_step(
    index: usize,
    signature: &SerializableSignature,
    quantum: u32,
) -> DerivationStep {
    let ntv = signature.normalized_total_variation().unwrap_or(0.0);

    DerivationStep::new(
        index,
        "Observable Certification",
        StepKind::CertificateEmission,
    )
    .with_input(serde_json::json!({
        "quantum": quantum,
    }))
    .with_output(serde_json::json!({
        "winding": signature.winding,
        "total_variation": signature.total_variation,
        "cascade_length": signature.cascade_spectrum.len(),
        "normalized_variation": ntv,
    }))
    .with_assertion(format!(
        "Monodromy signature: W={}, TV={}, NTV={:.4}",
        signature.winding, signature.total_variation, ntv
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_chain() -> DerivationChain {
        let mut chain =
            DerivationChain::new("https://uor.foundation/derivation/test", "Test Derivation")
                .with_description("A test derivation for observable proof")
                .with_timestamp("2026-02-05T00:00:00Z");

        chain.add_step(
            DerivationStep::new(0, "Initialize", StepKind::TypeDeclaration)
                .with_input(serde_json::json!({"n": 10403}))
                .with_output(serde_json::json!({"type": "semiprime"})),
        );

        chain
    }

    #[test]
    fn test_observable_proof_new() {
        let chain = sample_chain();
        let proof = ObservableProof::new(chain, 8);

        assert!(!proof.has_observables());
        assert!(proof.signature.is_none());
        assert_eq!(proof.quantum, 8);
    }

    #[test]
    fn test_observable_proof_with_path() {
        let chain = sample_chain();
        let path = vec![0u64, 1, 2, 3, 4, 5];
        let proof = ObservableProof::with_path(chain, &path, 8);

        assert!(proof.has_observables());
        assert!(proof.signature.is_some());

        let obs = proof.observables.as_ref().unwrap();
        assert_eq!(obs.winding, 0); // No complete ring traversal
        assert!(obs.variation > 0); // Some variation from 0 to 5
    }

    #[test]
    fn test_traced_derivation() {
        let chain = sample_chain();
        let path = vec![10u64, 20, 30, 40];
        let traced = TracedDerivation::new(chain, path, 8);

        assert_eq!(traced.step_observables.len(), 4);
        assert!(traced.variation_is_monotonic());

        // Check first step
        let step0 = traced.observable_at(0).unwrap();
        assert_eq!(step0.value, 10);
        assert_eq!(step0.cumulative_winding, 0);
    }

    #[test]
    fn test_observable_from_traced() {
        let chain = sample_chain();
        let path = vec![0u64, 128, 255, 0]; // Crosses ring boundary
        let traced = TracedDerivation::new(chain, path, 8);

        let proof = ObservableProof::from_traced(&traced);
        assert!(proof.has_observables());

        let sig = proof.signature.unwrap();
        // Path wraps around, so winding should be non-zero
        // Actually 0->128->255->0 goes forward, then back, might be 0
        // Let's just check it computed
        assert!(sig.total_variation > 0);
    }

    #[test]
    fn test_verify_observable_proof() {
        let chain = sample_chain();
        let path = vec![1u64, 2, 3, 4, 5];
        let proof = ObservableProof::with_path(chain, &path, 8);

        // Verify with same path - should pass
        let result = verify_observable_proof(&proof, &path);
        assert!(result.is_valid());
        assert!(result.signature_valid);
        assert!(result.variation_monotonic);

        // Verify with different path that has different signature
        // Use a path with very different structure (jumps vs increments)
        let wrong_path = vec![0u64, 255, 128, 64, 32];
        let result = verify_observable_proof(&proof, &wrong_path);
        assert!(!result.is_valid());
        assert!(!result.signature_valid);
    }

    #[test]
    fn test_certification_step() {
        let path = vec![0u64, 1, 2, 3];
        let signature = SerializableSignature::from_path(&path, 8);
        let step = certification_step(5, &signature, 8);

        assert_eq!(step.index, 5);
        assert_eq!(step.kind, StepKind::CertificateEmission);
        assert!(step.assertion.is_some());
        assert!(step.assertion.unwrap().contains("Monodromy signature"));
    }

    #[test]
    fn test_observable_values_compute() {
        let path = vec![0u64, 1, 255, 0]; // Full cycle-ish
        let obs = ObservableValues::compute(&path, 8);

        // Variation should be positive
        assert!(obs.variation > 0);
        // Cascade should have entries
        assert!(!obs.cascade.is_empty());
    }

    #[test]
    fn test_step_observables_monotonic() {
        // Monotonically increasing path
        let path: Vec<u64> = (0..10).collect();
        let traced = TracedDerivation::new(sample_chain(), path, 8);
        assert!(traced.variation_is_monotonic());
    }

    #[test]
    fn test_observable_proof_serialization() {
        let chain = sample_chain();
        let path = vec![1u64, 2, 3];
        let proof = ObservableProof::with_path(chain, &path, 8);

        // Should serialize without error
        let json = serde_json::to_string(&proof).unwrap();
        assert!(json.contains("signature"));
        assert!(json.contains("observables"));

        // Should deserialize back
        let deserialized: ObservableProof = serde_json::from_str(&json).unwrap();
        assert_eq!(deserialized.quantum, proof.quantum);
        assert!(deserialized.has_observables());
    }

    #[test]
    fn test_serializable_signature() {
        let path = vec![0u64, 1, 2, 3, 4, 5, 6, 7];
        let sig = SerializableSignature::from_path(&path, 8);

        // Should be serializable
        let json = serde_json::to_string(&sig).unwrap();
        assert!(json.contains("winding"));
        assert!(json.contains("total_variation"));

        // Round-trip
        let deserialized: SerializableSignature = serde_json::from_str(&json).unwrap();
        assert_eq!(deserialized, sig);
    }
}
