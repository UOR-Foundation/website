//! Core Codec trait and related types.

use crate::error::CodecError;

/// A lossless codec that can encode/decode values with arbitrary address scaling.
///
/// Codecs transform byte sequences between different representations while
/// preserving all information (lossless). The `scale_factor` describes the
/// numeric base and precision constraints of the codec.
///
/// # Example
///
/// ```ignore
/// use categorical_codec::{Codec, ScaleFactor};
///
/// let codec = MyCodec::default();
/// let encoded = codec.encode(&[1, 2, 3])?;
/// let decoded = codec.decode(&encoded)?;
/// assert_eq!(&[1, 2, 3], &decoded[..]);
/// ```
pub trait Codec: Send + Sync {
    /// Unique identifier for this codec (from JSON-LD @id).
    ///
    /// This should match the `@id` field from the JSON-LD descriptor
    /// that defined this codec.
    fn id(&self) -> &'static str;

    /// Human-readable name for this codec.
    fn name(&self) -> &'static str;

    /// Address space scaling factor.
    ///
    /// Describes the numeric base (radix) and precision constraints
    /// of this codec's representation.
    fn scale_factor(&self) -> ScaleFactor;

    /// Encode bytes to this codec's representation.
    ///
    /// # Errors
    ///
    /// Returns `CodecError` if encoding fails, for example if the input
    /// exceeds precision limits.
    fn encode(&self, input: &[u8]) -> Result<Vec<u8>, CodecError>;

    /// Decode from this codec's representation to bytes.
    ///
    /// # Errors
    ///
    /// Returns `CodecError` if decoding fails, for example if the input
    /// contains invalid data for this codec.
    fn decode(&self, input: &[u8]) -> Result<Vec<u8>, CodecError>;
}

/// Address space scaling configuration.
///
/// Describes the numeric representation characteristics of a codec:
/// - `radix`: The numeric base (2 for binary, 10 for decimal, etc.)
/// - `arbitrary`: Whether precision is unbounded
/// - `max_precision_bits`: Maximum precision if bounded
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ScaleFactor {
    /// Base radix for the representation.
    pub radix: u32,

    /// Whether scaling is arbitrary (unbounded precision).
    pub arbitrary: bool,

    /// Maximum precision in bits (if bounded).
    pub max_precision_bits: Option<u64>,
}

impl ScaleFactor {
    /// Create a scale factor for arbitrary precision with the given radix.
    #[must_use]
    pub const fn arbitrary(radix: u32) -> Self {
        Self {
            radix,
            arbitrary: true,
            max_precision_bits: None,
        }
    }

    /// Create a scale factor with fixed precision.
    #[must_use]
    pub const fn fixed(radix: u32, max_bits: u64) -> Self {
        Self {
            radix,
            arbitrary: false,
            max_precision_bits: Some(max_bits),
        }
    }

    /// Create a binary (base-2) scale factor with arbitrary precision.
    #[must_use]
    pub const fn binary() -> Self {
        Self::arbitrary(2)
    }

    /// Create a decimal (base-10) scale factor with arbitrary precision.
    #[must_use]
    pub const fn decimal() -> Self {
        Self::arbitrary(10)
    }
}

impl Default for ScaleFactor {
    fn default() -> Self {
        Self::binary()
    }
}
