//! Backend implementations collected under a single module tree.
//!
//! Each backend lives in its own submodule directory to keep platform-specific
//! code isolated. Modules expose the same interfaces as before via crate-level
//! re-exports in `lib.rs`.
//!
//! Feature flags are consolidated here for cleaner code in individual backends.

// Always available (no feature gates)
pub mod cpu;
pub mod gpu_constants;
pub mod wasm;

// Metal: macOS only with metal feature
#[cfg(all(target_os = "macos", feature = "metal"))]
pub mod metal;

// CUDA: Linux/Windows only with cuda feature
#[cfg(all(any(target_os = "linux", target_os = "windows"), feature = "cuda"))]
pub mod cuda;

// WebGPU: cross-platform with webgpu feature
#[cfg(feature = "webgpu")]
pub mod webgpu;
