//! Layout planning (Stage 4).
//!
//! This module determines memory layouts for tensor buffers:
//! - Memory ordering (row-major, column-major, blocked)
//! - Alignment requirements (32-byte AVX2, 64-byte AVX-512)
//! - Packing stages for optimized matrix operations
//! - Tile sizes for SIMD micro-kernels

mod tiling;

use crate::graph::{CompileGraph, OpKind};
use hologram_backend::BackendCapabilities;

pub use tiling::{compute_tile_sizes, TileSize};

/// Memory ordering for tensor data.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum MemoryOrder {
    /// Row-major (C-style): last dimension is contiguous.
    #[default]
    RowMajor,
    /// Column-major (Fortran-style): first dimension is contiguous.
    ColumnMajor,
    /// Blocked/tiled layout for cache efficiency.
    Blocked {
        /// Block size in rows.
        block_rows: usize,
        /// Block size in columns.
        block_cols: usize,
    },
}

/// Alignment requirement for buffer allocation.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum Alignment {
    /// No alignment requirement.
    None,
    /// 16-byte alignment (SSE, NEON).
    Align16,
    /// 32-byte alignment (AVX, AVX2).
    #[default]
    Align32,
    /// 64-byte alignment (AVX-512, cache line).
    Align64,
}

impl Alignment {
    /// Create alignment from SIMD vector width.
    #[must_use]
    pub fn from_vector_width(width: usize) -> Self {
        match width {
            0..=4 => Self::Align16,
            5..=8 => Self::Align32,
            _ => Self::Align64,
        }
    }

    /// Get alignment value in bytes.
    #[must_use]
    pub const fn bytes(self) -> usize {
        match self {
            Self::None => 1,
            Self::Align16 => 16,
            Self::Align32 => 32,
            Self::Align64 => 64,
        }
    }

    /// Round up a size to the next aligned boundary.
    #[must_use]
    pub const fn align_up(self, size: usize) -> usize {
        let align = self.bytes();
        (size + align - 1) & !(align - 1)
    }
}

/// Packing stage for matrix operations.
///
/// Some kernels require input matrices to be repacked into a cache-friendly
/// layout before computation. This enum describes the packing strategy.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum PackingStage {
    /// No packing required.
    #[default]
    None,
    /// Pack matrix A (left operand) into blocked layout.
    PackA,
    /// Pack matrix B (right operand) into blocked layout.
    PackB,
    /// Pack both matrices.
    PackBoth,
}

/// Complete layout information for a buffer.
#[derive(Debug, Clone, Default)]
pub struct LayoutInfo {
    /// Unique layout ID.
    pub id: u32,
    /// Memory ordering.
    pub order: MemoryOrder,
    /// Alignment requirement.
    pub alignment: Alignment,
    /// Packing stage (for matrix operations).
    pub packing: PackingStage,
    /// Tile size (for SIMD operations).
    pub tile_size: Option<TileSize>,
    /// Stride for each dimension (in elements).
    pub strides: Vec<usize>,
    /// Total buffer size in bytes.
    pub buffer_size: usize,
}

impl LayoutInfo {
    /// Create layout info with default row-major ordering.
    #[must_use]
    pub fn row_major(shape: &[usize], dtype_size: usize, alignment: Alignment) -> Self {
        let strides = compute_row_major_strides(shape);
        let element_count: usize = shape.iter().product();
        let raw_size = element_count * dtype_size;
        let buffer_size = alignment.align_up(raw_size);

        Self {
            id: 0,
            order: MemoryOrder::RowMajor,
            alignment,
            packing: PackingStage::None,
            tile_size: None,
            strides,
            buffer_size,
        }
    }

    /// Create layout info with column-major ordering.
    #[must_use]
    pub fn column_major(shape: &[usize], dtype_size: usize, alignment: Alignment) -> Self {
        let strides = compute_column_major_strides(shape);
        let element_count: usize = shape.iter().product();
        let raw_size = element_count * dtype_size;
        let buffer_size = alignment.align_up(raw_size);

        Self {
            id: 0,
            order: MemoryOrder::ColumnMajor,
            alignment,
            packing: PackingStage::None,
            tile_size: None,
            strides,
            buffer_size,
        }
    }

    /// Create layout info with blocked ordering for matrix operations.
    #[must_use]
    pub fn blocked(
        shape: &[usize],
        dtype_size: usize,
        alignment: Alignment,
        block_rows: usize,
        block_cols: usize,
    ) -> Self {
        // For blocked layout, strides are computed differently
        let strides = compute_blocked_strides(shape, block_rows, block_cols);
        let element_count: usize = shape.iter().product();
        // Blocked layouts may have padding
        let raw_size = element_count * dtype_size;
        let buffer_size = alignment.align_up(raw_size);

        Self {
            id: 0,
            order: MemoryOrder::Blocked {
                block_rows,
                block_cols,
            },
            alignment,
            packing: PackingStage::None,
            tile_size: None,
            strides,
            buffer_size,
        }
    }
}

/// Compute row-major strides for a shape.
fn compute_row_major_strides(shape: &[usize]) -> Vec<usize> {
    if shape.is_empty() {
        return Vec::new();
    }

    let mut strides = vec![1; shape.len()];
    for i in (0..shape.len() - 1).rev() {
        strides[i] = strides[i + 1] * shape[i + 1];
    }
    strides
}

/// Compute column-major strides for a shape.
fn compute_column_major_strides(shape: &[usize]) -> Vec<usize> {
    if shape.is_empty() {
        return Vec::new();
    }

    let mut strides = vec![1; shape.len()];
    for i in 1..shape.len() {
        strides[i] = strides[i - 1] * shape[i - 1];
    }
    strides
}

/// Compute strides for blocked layout.
fn compute_blocked_strides(shape: &[usize], block_rows: usize, block_cols: usize) -> Vec<usize> {
    // For 2D blocked layout: block strides plus inner strides
    if shape.len() >= 2 {
        let cols = shape[1];
        let num_block_cols = cols.div_ceil(block_cols);

        // Stride to next block row, stride to next block col, inner row, inner col
        vec![
            num_block_cols * block_rows * block_cols, // stride between block rows
            block_rows * block_cols,                  // stride between block cols
        ]
    } else {
        compute_row_major_strides(shape)
    }
}

/// Registry of computed layouts.
#[derive(Debug, Default)]
pub struct LayoutRegistry {
    layouts: Vec<LayoutInfo>,
    next_id: u32,
}

impl LayoutRegistry {
    /// Create a new empty registry.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Register a layout and return its ID.
    pub fn register(&mut self, mut layout: LayoutInfo) -> u32 {
        let id = self.next_id;
        layout.id = id;
        self.layouts.push(layout);
        self.next_id += 1;
        id
    }

    /// Get a layout by ID.
    #[must_use]
    pub fn get(&self, id: u32) -> Option<&LayoutInfo> {
        self.layouts.get(id as usize)
    }

    /// Get all layouts.
    #[must_use]
    pub fn layouts(&self) -> &[LayoutInfo] {
        &self.layouts
    }
}

/// Determine the dtype size in bytes.
fn dtype_size(dtype: crate::graph::DType) -> usize {
    use crate::graph::DType;
    match dtype {
        DType::F32 | DType::I32 | DType::U32 => 4,
        DType::F64 | DType::I64 | DType::U64 => 8,
        DType::I8 | DType::U8 | DType::Bool => 1,
        DType::I16 | DType::U16 => 2,
    }
}

/// Plan memory layouts for each buffer.
///
/// This function assigns a layout ID to each node in the graph by:
/// 1. Determining appropriate memory ordering based on operation type
/// 2. Setting alignment based on backend SIMD capabilities
/// 3. Computing packing requirements for matrix operations
/// 4. Calculating buffer strides and sizes
pub fn plan_layouts(graph: &mut CompileGraph, caps: &BackendCapabilities) -> LayoutRegistry {
    let mut registry = LayoutRegistry::new();
    let alignment = Alignment::from_vector_width(caps.vector_width);
    let tile_size = compute_tile_sizes(caps);

    // Collect layout assignments to avoid borrow conflicts
    let assignments: Vec<(u32, u32, Option<PackingStage>)> = graph
        .nodes()
        .map(|(id, node)| {
            let ds = dtype_size(node.dtype);
            let (layout, packing) = determine_layout(
                &node.op,
                &node.shape,
                ds,
                alignment,
                tile_size,
                caps.l1_cache_size,
            );

            let layout_id = registry.register(layout);
            (id, layout_id, packing)
        })
        .collect();

    // Apply layout assignments
    for (node_id, layout_id, packing) in assignments {
        if let Some(node) = graph.get_node_mut(node_id) {
            node.layout = Some(layout_id);
            // Store packing info in node name annotation if needed
            if let Some(packing) = packing {
                let packing_str = match packing {
                    PackingStage::None => "",
                    PackingStage::PackA => "pack:A",
                    PackingStage::PackB => "pack:B",
                    PackingStage::PackBoth => "pack:AB",
                };
                if !packing_str.is_empty() {
                    node.name = Some(match &node.name {
                        Some(existing) => format!("{existing}|{packing_str}"),
                        None => packing_str.to_string(),
                    });
                }
            }
        }
    }

    registry
}

/// Determine layout and packing for an operation.
fn determine_layout(
    op: &OpKind,
    shape: &[usize],
    dtype_size: usize,
    alignment: Alignment,
    tile_size: TileSize,
    l1_cache_size: usize,
) -> (LayoutInfo, Option<PackingStage>) {
    match op {
        OpKind::MatMul { m, k, n } | OpKind::MatMulRelu { m, k, n } => {
            let (block_rows, block_cols) = tile_size.macro_tile;

            if *m >= block_rows && *n >= block_cols {
                let mut layout =
                    LayoutInfo::blocked(shape, dtype_size, alignment, block_rows, block_cols);
                layout.tile_size = Some(tile_size);

                let a_size = m * k * dtype_size;
                let b_size = k * n * dtype_size;
                let packing = if a_size + b_size > l1_cache_size {
                    Some(PackingStage::PackBoth)
                } else if a_size > l1_cache_size / 2 {
                    Some(PackingStage::PackA)
                } else if b_size > l1_cache_size / 2 {
                    Some(PackingStage::PackB)
                } else {
                    None
                };

                (layout, packing)
            } else {
                (LayoutInfo::row_major(shape, dtype_size, alignment), None)
            }
        }

        // All other ops use row-major layout
        OpKind::BatchMatMul { .. }
        | OpKind::Add
        | OpKind::Sub
        | OpKind::Mul
        | OpKind::Div
        | OpKind::Sqrt
        | OpKind::Log
        | OpKind::Pow
        | OpKind::Exp
        | OpKind::Abs
        | OpKind::ElemMin
        | OpKind::ElemMax
        | OpKind::Greater
        | OpKind::GreaterOrEqual
        | OpKind::Less
        | OpKind::LessOrEqual
        | OpKind::Where
        | OpKind::Sigmoid
        | OpKind::Tanh
        | OpKind::Relu
        | OpKind::Gelu
        | OpKind::Silu
        | OpKind::Softmax { .. }
        | OpKind::Sum
        | OpKind::Max
        | OpKind::Min
        | OpKind::Mean
        | OpKind::Load
        | OpKind::Store
        | OpKind::Copy
        | OpKind::Lift
        | OpKind::OrbitClassify
        | OpKind::Encode { .. }
        | OpKind::Decode { .. }
        | OpKind::Sha256 { .. }
        | OpKind::DoubleSha256 { .. }
        | OpKind::CallLayer { .. }
        | OpKind::Input
        | OpKind::Output
        | OpKind::Constant
        | OpKind::Reshape { .. }
        | OpKind::Transpose { .. }
        | OpKind::Gather { .. }
        | OpKind::Concat { .. }
        | OpKind::Unsqueeze { .. }
        | OpKind::Squeeze { .. }
        | OpKind::Slice { .. }
        | OpKind::Split { .. }
        | OpKind::Pad { .. }
        | OpKind::Cast { .. }
        | OpKind::Tile { .. }
        | OpKind::Expand { .. }
        | OpKind::Conv2d { .. }
        | OpKind::BatchNormalization { .. }
        | OpKind::LayerNorm { .. }
        | OpKind::MaxPool { .. }
        | OpKind::AvgPool { .. }
        | OpKind::GlobalAveragePool
        | OpKind::Flatten { .. }
        | OpKind::ViterbiTokenize { .. }
        | OpKind::AddSigmoid => (LayoutInfo::row_major(shape, dtype_size, alignment), None),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{DType, OpNode, OperationGraph};
    use hologram_backend::BackendType;

    fn test_caps() -> BackendCapabilities {
        BackendCapabilities {
            backend_type: BackendType::Cpu,
            vector_width: 8,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: true,
            has_sha: false,
            has_aes: false,
        }
    }

    fn make_graph(nodes: Vec<OpNode>, edges: Vec<(u32, u32)>) -> CompileGraph {
        let mut graph = OperationGraph::new();
        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        CompileGraph::from_operation_graph(&graph).unwrap()
    }

    // --- Alignment Tests ---

    #[test]
    fn test_alignment_from_vector_width() {
        assert_eq!(Alignment::from_vector_width(4), Alignment::Align16);
        assert_eq!(Alignment::from_vector_width(8), Alignment::Align32);
        assert_eq!(Alignment::from_vector_width(16), Alignment::Align64);
    }

    #[test]
    fn test_alignment_bytes() {
        assert_eq!(Alignment::None.bytes(), 1);
        assert_eq!(Alignment::Align16.bytes(), 16);
        assert_eq!(Alignment::Align32.bytes(), 32);
        assert_eq!(Alignment::Align64.bytes(), 64);
    }

    #[test]
    fn test_alignment_align_up() {
        assert_eq!(Alignment::Align32.align_up(100), 128);
        assert_eq!(Alignment::Align32.align_up(32), 32);
        assert_eq!(Alignment::Align32.align_up(0), 0);
        assert_eq!(Alignment::Align64.align_up(65), 128);
    }

    // --- MemoryOrder Tests ---

    #[test]
    fn test_memory_order_default() {
        assert_eq!(MemoryOrder::default(), MemoryOrder::RowMajor);
    }

    // --- Stride Computation Tests ---

    #[test]
    fn test_row_major_strides() {
        let strides = compute_row_major_strides(&[2, 3, 4]);
        assert_eq!(strides, vec![12, 4, 1]);
    }

    #[test]
    fn test_row_major_strides_2d() {
        let strides = compute_row_major_strides(&[64, 64]);
        assert_eq!(strides, vec![64, 1]);
    }

    #[test]
    fn test_row_major_strides_1d() {
        let strides = compute_row_major_strides(&[100]);
        assert_eq!(strides, vec![1]);
    }

    #[test]
    fn test_row_major_strides_empty() {
        let strides = compute_row_major_strides(&[]);
        assert!(strides.is_empty());
    }

    #[test]
    fn test_column_major_strides() {
        let strides = compute_column_major_strides(&[2, 3, 4]);
        assert_eq!(strides, vec![1, 2, 6]);
    }

    #[test]
    fn test_column_major_strides_2d() {
        let strides = compute_column_major_strides(&[64, 64]);
        assert_eq!(strides, vec![1, 64]);
    }

    // --- LayoutInfo Tests ---

    #[test]
    fn test_layout_info_row_major() {
        let layout = LayoutInfo::row_major(&[64, 64], 4, Alignment::Align32);
        assert_eq!(layout.order, MemoryOrder::RowMajor);
        assert_eq!(layout.alignment, Alignment::Align32);
        assert_eq!(layout.strides, vec![64, 1]);
        assert_eq!(layout.buffer_size, 64 * 64 * 4); // Already aligned
    }

    #[test]
    fn test_layout_info_column_major() {
        let layout = LayoutInfo::column_major(&[64, 64], 4, Alignment::Align32);
        assert_eq!(layout.order, MemoryOrder::ColumnMajor);
        assert_eq!(layout.strides, vec![1, 64]);
    }

    #[test]
    fn test_layout_info_blocked() {
        let layout = LayoutInfo::blocked(&[256, 256], 4, Alignment::Align64, 64, 64);
        assert!(matches!(layout.order, MemoryOrder::Blocked { .. }));
        assert_eq!(layout.alignment, Alignment::Align64);
    }

    #[test]
    fn test_layout_buffer_size_aligned() {
        // 100 * 4 = 400 bytes, aligned to 32 = 416
        let layout = LayoutInfo::row_major(&[100], 4, Alignment::Align32);
        assert_eq!(layout.buffer_size, 416);
    }

    // --- LayoutRegistry Tests ---

    #[test]
    fn test_layout_registry_register() {
        let mut registry = LayoutRegistry::new();
        let layout = LayoutInfo::row_major(&[64, 64], 4, Alignment::Align32);
        let id = registry.register(layout);
        assert_eq!(id, 0);

        let layout2 = LayoutInfo::column_major(&[32, 32], 4, Alignment::Align16);
        let id2 = registry.register(layout2);
        assert_eq!(id2, 1);
    }

    #[test]
    fn test_layout_registry_get() {
        let mut registry = LayoutRegistry::new();
        let layout = LayoutInfo::row_major(&[64, 64], 4, Alignment::Align32);
        let id = registry.register(layout);

        let retrieved = registry.get(id).unwrap();
        assert_eq!(retrieved.id, 0);
        assert_eq!(retrieved.order, MemoryOrder::RowMajor);
    }

    #[test]
    fn test_layout_registry_get_nonexistent() {
        let registry = LayoutRegistry::new();
        assert!(registry.get(999).is_none());
    }

    // --- plan_layouts Tests ---

    #[test]
    fn test_plan_layouts_empty_graph() {
        let mut graph = make_graph(vec![], vec![]);
        let caps = test_caps();
        let registry = plan_layouts(&mut graph, &caps);
        assert!(registry.layouts().is_empty());
    }

    #[test]
    fn test_plan_layouts_assigns_to_all_nodes() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64, 64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64, 64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64, 64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        plan_layouts(&mut graph, &caps);

        // All nodes should have layouts assigned
        for (_, node) in graph.nodes() {
            assert!(node.layout.is_some(), "Node should have layout assigned");
        }
    }

    #[test]
    fn test_plan_layouts_uses_correct_alignment() {
        let mut graph = make_graph(
            vec![OpNode::new(0, OpKind::Add, vec![1024], DType::F32)],
            vec![],
        );

        let caps = BackendCapabilities {
            vector_width: 16, // AVX-512
            ..test_caps()
        };
        let registry = plan_layouts(&mut graph, &caps);

        let layout = registry.get(0).unwrap();
        assert_eq!(layout.alignment, Alignment::Align64);
    }

    #[test]
    fn test_plan_layouts_matmul_blocked() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256, 256], DType::F32),
                OpNode::new(1, OpKind::Input, vec![256, 256], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 256,
                        k: 256,
                        n: 256,
                    },
                    vec![256, 256],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Output, vec![256, 256], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        let caps = test_caps();
        let registry = plan_layouts(&mut graph, &caps);

        // MatMul node should have blocked layout
        let matmul_node = graph.get_node(2).unwrap();
        let layout_id = matmul_node.layout.unwrap();
        let layout = registry.get(layout_id).unwrap();
        assert!(matches!(layout.order, MemoryOrder::Blocked { .. }));
    }

    #[test]
    fn test_plan_layouts_small_matmul_row_major() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![16, 16], DType::F32),
                OpNode::new(1, OpKind::Input, vec![16, 16], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 16,
                        k: 16,
                        n: 16,
                    },
                    vec![16, 16],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Output, vec![16, 16], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        let caps = test_caps();
        let registry = plan_layouts(&mut graph, &caps);

        // Small matmul should use row-major
        let matmul_node = graph.get_node(2).unwrap();
        let layout_id = matmul_node.layout.unwrap();
        let layout = registry.get(layout_id).unwrap();
        assert_eq!(layout.order, MemoryOrder::RowMajor);
    }

    #[test]
    fn test_plan_layouts_elementwise_row_major() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![1024], DType::F32),
                OpNode::new(1, OpKind::Sigmoid, vec![1024], DType::F32),
                OpNode::new(2, OpKind::Output, vec![1024], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let caps = test_caps();
        let registry = plan_layouts(&mut graph, &caps);

        // Sigmoid should use row-major
        let sigmoid_node = graph.get_node(1).unwrap();
        let layout_id = sigmoid_node.layout.unwrap();
        let layout = registry.get(layout_id).unwrap();
        assert_eq!(layout.order, MemoryOrder::RowMajor);
    }

    #[test]
    fn test_plan_layouts_packing_annotation() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![512, 512], DType::F32),
                OpNode::new(1, OpKind::Input, vec![512, 512], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul {
                        m: 512,
                        k: 512,
                        n: 512,
                    },
                    vec![512, 512],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Output, vec![512, 512], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        let caps = test_caps();
        plan_layouts(&mut graph, &caps);

        // Large matmul should have packing annotation
        let matmul_node = graph.get_node(2).unwrap();
        assert!(matmul_node
            .name
            .as_ref()
            .is_some_and(|n| n.contains("pack:")));
    }

    #[test]
    fn test_plan_layouts_different_dtypes() {
        let mut graph = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![100], DType::F32),
                OpNode::new(1, OpKind::Input, vec![100], DType::F64),
                OpNode::new(2, OpKind::Input, vec![100], DType::U8),
            ],
            vec![],
        );

        let caps = test_caps();
        let registry = plan_layouts(&mut graph, &caps);

        // Check buffer sizes reflect dtype
        let layout_f32 = registry.get(0).unwrap();
        let layout_f64 = registry.get(1).unwrap();
        let layout_u8 = registry.get(2).unwrap();

        assert!(layout_f64.buffer_size > layout_f32.buffer_size);
        assert!(layout_f32.buffer_size > layout_u8.buffer_size);
    }

    #[test]
    fn test_dtype_size() {
        assert_eq!(dtype_size(DType::F32), 4);
        assert_eq!(dtype_size(DType::F64), 8);
        assert_eq!(dtype_size(DType::I8), 1);
        assert_eq!(dtype_size(DType::U16), 2);
    }

    #[test]
    fn test_layout_preserves_existing_name() {
        let mut graph = make_graph(
            vec![OpNode::new(
                0,
                OpKind::MatMul {
                    m: 512,
                    k: 512,
                    n: 512,
                },
                vec![512, 512],
                DType::F32,
            )
            .with_name("my_matmul")],
            vec![],
        );

        let caps = test_caps();
        plan_layouts(&mut graph, &caps);

        let node = graph.get_node(0).unwrap();
        let name = node.name.as_ref().unwrap();
        assert!(name.starts_with("my_matmul"));
        assert!(name.contains("pack:"));
    }
}
