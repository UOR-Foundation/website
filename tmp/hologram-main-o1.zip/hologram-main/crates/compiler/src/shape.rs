//! Shape inference and broadcasting utilities.
//!
//! This module provides centralized shape handling for the compiler,
//! similar to how `ExecutionContext` centralizes runtime buffer access.
//!
//! # Broadcasting Rules (NumPy-style)
//!
//! 1. Compare shapes from right to left (trailing dimensions first)
//! 2. Dimensions match if they are equal OR one of them is 1
//! 3. Missing dimensions are treated as 1 (prepended)
//! 4. The result shape is the element-wise maximum

/// Compute broadcast-compatible output shape from two input shapes.
///
/// Returns `None` if shapes are incompatible for broadcasting.
///
/// # Examples
///
/// ```
/// use hologram_compiler::shape::broadcast_shapes;
///
/// // Bias addition: [1, 1000] + [1000] -> [1, 1000]
/// assert_eq!(broadcast_shapes(&[1, 1000], &[1000]), Some(vec![1, 1000]));
///
/// // Batch broadcast: [32, 512] + [512] -> [32, 512]
/// assert_eq!(broadcast_shapes(&[32, 512], &[512]), Some(vec![32, 512]));
///
/// // Incompatible: [1, 1000] + [999] -> None
/// assert_eq!(broadcast_shapes(&[1, 1000], &[999]), None);
/// ```
#[must_use]
pub fn broadcast_shapes(a: &[usize], b: &[usize]) -> Option<Vec<usize>> {
    let max_dims = a.len().max(b.len());
    let mut result = Vec::with_capacity(max_dims);

    for i in 0..max_dims {
        let dim_a = a.len().checked_sub(max_dims - i).map_or(1, |idx| a[idx]);
        let dim_b = b.len().checked_sub(max_dims - i).map_or(1, |idx| b[idx]);

        if dim_a == dim_b {
            result.push(dim_a);
        } else if dim_a == 1 {
            result.push(dim_b);
        } else if dim_b == 1 {
            result.push(dim_a);
        } else {
            return None; // Incompatible dimensions
        }
    }
    Some(result)
}

/// Check if two shapes are broadcast-compatible.
///
/// # Examples
///
/// ```
/// use hologram_compiler::shape::shapes_broadcast_compatible;
///
/// assert!(shapes_broadcast_compatible(&[1, 1000], &[1000]));
/// assert!(shapes_broadcast_compatible(&[32, 512], &[512]));
/// assert!(!shapes_broadcast_compatible(&[1, 1000], &[999]));
/// ```
#[must_use]
pub fn shapes_broadcast_compatible(a: &[usize], b: &[usize]) -> bool {
    broadcast_shapes(a, b).is_some()
}

/// Infer `GlobalAveragePool` output shape.
///
/// `GlobalAveragePool` reduces spatial dimensions to 1:
/// `[N, C, H, W]` -> `[N, C, 1, 1]`
///
/// Returns `None` if input is not 4D.
///
/// # Examples
///
/// ```
/// use hologram_compiler::shape::infer_global_avg_pool;
///
/// assert_eq!(infer_global_avg_pool(&[1, 512, 7, 7]), Some(vec![1, 512, 1, 1]));
/// assert_eq!(infer_global_avg_pool(&[1, 512]), None); // Not 4D
/// ```
#[must_use]
pub fn infer_global_avg_pool(input: &[usize]) -> Option<Vec<usize>> {
    if input.len() != 4 {
        return None;
    }
    Some(vec![input[0], input[1], 1, 1])
}

/// Infer `Flatten` output shape with `start_dim`.
///
/// Flattens dimensions from `start_dim` onwards into a single dimension:
/// - `start_dim=0`: Flattens everything -> `[total_elements]`
/// - `start_dim=1`: Preserves batch -> `[N, C*H*W]`
///
/// Returns `None` if `start_dim >= input.len()`.
///
/// # Examples
///
/// ```
/// use hologram_compiler::shape::infer_flatten;
///
/// // Preserve batch dimension
/// assert_eq!(infer_flatten(&[1, 512, 1, 1], 1), Some(vec![1, 512]));
/// assert_eq!(infer_flatten(&[32, 64, 4, 4], 1), Some(vec![32, 1024]));
///
/// // Flatten everything
/// assert_eq!(infer_flatten(&[2, 3, 4], 0), Some(vec![24]));
///
/// // Invalid start_dim
/// assert_eq!(infer_flatten(&[1, 512], 5), None);
/// ```
#[must_use]
pub fn infer_flatten(input: &[usize], start_dim: usize) -> Option<Vec<usize>> {
    if start_dim >= input.len() {
        return None;
    }
    let mut result = input[..start_dim].to_vec();
    let suffix: usize = input[start_dim..].iter().product();
    result.push(suffix);
    Some(result)
}

/// Infer `MatMul` output shape.
///
/// `MatMul` always produces `[m, n]`, preserving batch dimension even when `m=1`.
///
/// # Examples
///
/// ```
/// use hologram_compiler::shape::infer_matmul;
///
/// // Standard case
/// assert_eq!(infer_matmul(64, 256), vec![64, 256]);
///
/// // m=1 case (preserves batch dimension)
/// assert_eq!(infer_matmul(1, 1000), vec![1, 1000]);
/// ```
#[must_use]
pub fn infer_matmul(m: usize, n: usize) -> Vec<usize> {
    vec![m, n]
}

/// Infer `BatchMatMul` output shape.
///
/// `BatchMatMul` produces `[...batch, m, n]` from `[...batch, m, k] × [...batch, k, n]`.
///
/// # Examples
///
/// ```
/// use hologram_compiler::shape::infer_batch_matmul;
///
/// // Attention: [batch, heads, seq, head_dim] × [batch, heads, head_dim, seq]
/// assert_eq!(infer_batch_matmul(&[2, 8], 64, 64), vec![2, 8, 64, 64]);
///
/// // 3D batch matmul
/// assert_eq!(infer_batch_matmul(&[32], 128, 256), vec![32, 128, 256]);
/// ```
#[must_use]
pub fn infer_batch_matmul(batch: &[usize], m: usize, n: usize) -> Vec<usize> {
    let mut result = batch.to_vec();
    result.push(m);
    result.push(n);
    result
}

/// Infer `Tile` output shape: `output[i] = input[i] * multiples[i]`
///
/// Tiles (repeats) a tensor along each dimension by the specified multiples.
/// Output shape: `output[i] = input[i] * multiples[i]`
///
/// Returns `None` if `multiples.len() != input.len()`.
///
/// # Examples
/// ```
/// use hologram_compiler::shape::infer_tile;
/// assert_eq!(infer_tile(&[2, 3], &[2, 3]), Some(vec![4, 9]));
/// assert_eq!(infer_tile(&[4], &[3]), Some(vec![12]));
/// assert_eq!(infer_tile(&[4], &[1, 2]), None); // Dimension mismatch
/// ```
#[must_use]
pub fn infer_tile(input: &[usize], multiples: &[usize]) -> Option<Vec<usize>> {
    if input.len() != multiples.len() {
        return None;
    }
    Some(input.iter().zip(multiples).map(|(d, m)| d * m).collect())
}

/// Infer `Expand` output shape via `NumPy` broadcasting.
///
/// Expands a tensor to a target shape using `NumPy` broadcasting rules.
/// The target shape must be broadcast-compatible with the input.
///
/// Returns `None` if shapes are incompatible.
///
/// # Examples
/// ```
/// use hologram_compiler::shape::infer_expand;
/// assert_eq!(infer_expand(&[1, 64], &[32, 64]), Some(vec![32, 64]));
/// assert_eq!(infer_expand(&[64], &[32, 64]), Some(vec![32, 64]));
/// assert_eq!(infer_expand(&[32], &[64]), None); // Incompatible
/// ```
#[must_use]
pub fn infer_expand(input: &[usize], target: &[usize]) -> Option<Vec<usize>> {
    let result = broadcast_shapes(input, target)?;
    if result == target {
        Some(result)
    } else {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // Broadcasting tests

    #[test]
    fn test_broadcast_same_shape() {
        assert_eq!(
            broadcast_shapes(&[1, 1000], &[1, 1000]),
            Some(vec![1, 1000])
        );
    }

    #[test]
    fn test_broadcast_bias() {
        // ResNet classifier: [1, 1000] + [1000] -> [1, 1000]
        assert_eq!(broadcast_shapes(&[1, 1000], &[1000]), Some(vec![1, 1000]));
    }

    #[test]
    fn test_broadcast_batch() {
        // Batch-wise bias: [32, 512] + [512] -> [32, 512]
        assert_eq!(broadcast_shapes(&[32, 512], &[512]), Some(vec![32, 512]));
    }

    #[test]
    fn test_broadcast_scalar() {
        // Scalar broadcast: [1, 64, 64] + [1] -> [1, 64, 64]
        assert_eq!(broadcast_shapes(&[1, 64, 64], &[1]), Some(vec![1, 64, 64]));
    }

    #[test]
    fn test_broadcast_incompatible() {
        // Dimension mismatch: [1, 1000] + [999] -> None
        assert_eq!(broadcast_shapes(&[1, 1000], &[999]), None);
    }

    #[test]
    fn test_broadcast_higher_rank() {
        // Higher rank: [2, 3, 4] + [4] -> [2, 3, 4]
        assert_eq!(broadcast_shapes(&[2, 3, 4], &[4]), Some(vec![2, 3, 4]));
    }

    #[test]
    fn test_broadcast_empty_shapes() {
        // Empty shapes
        assert_eq!(broadcast_shapes(&[], &[]), Some(vec![]));
        assert_eq!(broadcast_shapes(&[5], &[]), Some(vec![5]));
        assert_eq!(broadcast_shapes(&[], &[5]), Some(vec![5]));
    }

    #[test]
    fn test_shapes_broadcast_compatible() {
        assert!(shapes_broadcast_compatible(&[1, 1000], &[1000]));
        assert!(shapes_broadcast_compatible(&[32, 512], &[512]));
        assert!(!shapes_broadcast_compatible(&[1, 1000], &[999]));
    }

    // GlobalAveragePool tests

    #[test]
    fn test_infer_global_avg_pool() {
        assert_eq!(
            infer_global_avg_pool(&[1, 512, 7, 7]),
            Some(vec![1, 512, 1, 1])
        );
        assert_eq!(
            infer_global_avg_pool(&[32, 256, 14, 14]),
            Some(vec![32, 256, 1, 1])
        );
    }

    #[test]
    fn test_infer_global_avg_pool_non_4d() {
        assert_eq!(infer_global_avg_pool(&[1, 512]), None);
        assert_eq!(infer_global_avg_pool(&[1, 512, 7]), None);
        assert_eq!(infer_global_avg_pool(&[1, 512, 7, 7, 1]), None);
    }

    // Flatten tests

    #[test]
    fn test_infer_flatten_start_dim_1() {
        // Standard ResNet: [1, 512, 1, 1] -> [1, 512]
        assert_eq!(infer_flatten(&[1, 512, 1, 1], 1), Some(vec![1, 512]));
    }

    #[test]
    fn test_infer_flatten_batch() {
        // Batch case: [32, 64, 4, 4] -> [32, 1024]
        assert_eq!(infer_flatten(&[32, 64, 4, 4], 1), Some(vec![32, 1024]));
    }

    #[test]
    fn test_infer_flatten_start_dim_0() {
        // Flatten everything: [2, 3, 4] -> [24]
        assert_eq!(infer_flatten(&[2, 3, 4], 0), Some(vec![24]));
    }

    #[test]
    fn test_infer_flatten_invalid_start_dim() {
        assert_eq!(infer_flatten(&[1, 512], 5), None);
        assert_eq!(infer_flatten(&[1, 512], 2), None);
    }

    // MatMul tests

    #[test]
    fn test_infer_matmul() {
        assert_eq!(infer_matmul(64, 256), vec![64, 256]);
    }

    #[test]
    fn test_infer_matmul_m1() {
        // m=1 case: output is [1, n], not [n]
        assert_eq!(infer_matmul(1, 1000), vec![1, 1000]);
    }

    // Tile tests

    #[test]
    fn test_infer_tile() {
        assert_eq!(infer_tile(&[2, 3], &[2, 3]), Some(vec![4, 9]));
        assert_eq!(infer_tile(&[4], &[3]), Some(vec![12]));
        assert_eq!(infer_tile(&[1], &[10]), Some(vec![10]));
        assert_eq!(infer_tile(&[2, 3, 4], &[1, 2, 3]), Some(vec![2, 6, 12]));
    }

    #[test]
    fn test_infer_tile_dimension_mismatch() {
        // Dimension mismatch: multiples length != input length
        assert_eq!(infer_tile(&[4], &[1, 2]), None);
        assert_eq!(infer_tile(&[2, 3], &[1]), None);
        assert_eq!(infer_tile(&[], &[1]), None);
    }

    // Expand tests

    #[test]
    fn test_infer_expand() {
        // Broadcast single dimension
        assert_eq!(infer_expand(&[1, 64], &[32, 64]), Some(vec![32, 64]));
        // Broadcast multiple dimensions
        assert_eq!(infer_expand(&[1, 1], &[3, 4]), Some(vec![3, 4]));
        // Right-alignment broadcasting
        assert_eq!(infer_expand(&[64], &[32, 64]), Some(vec![32, 64]));
        // Identity (no expansion needed)
        assert_eq!(infer_expand(&[32, 64], &[32, 64]), Some(vec![32, 64]));
    }

    #[test]
    fn test_infer_expand_incompatible() {
        // Incompatible: dimensions don't match
        assert_eq!(infer_expand(&[32], &[64]), None);
        // Incompatible: shape can't broadcast to target
        assert_eq!(infer_expand(&[32, 64], &[64, 32]), None);
    }
}
