//! Operation traits and stdlib implementations.
//!
//! Defines the [`Operation`] and [`BinaryOperation`] traits with mandatory
//! conformance targets. Stdlib modules provide elementwise, reduction,
//! and shuffle operations.
//!
//! # Conformance
//!
//! Every operation declares [`ConformanceTargets`] (minimum, optimal,
//! theoretical cycle counts). The [`ConformanceResult`] returned by
//! verification indicates the achieved tier.
//!
//! ```
//! use prism::ops::{ConformanceTargets, ConformanceResult};
//! use uor::conformance::ConformanceTier;
//!
//! let targets = ConformanceTargets { minimum: 5, optimal: 3, theoretical: 1 };
//! let result = ConformanceResult::from_cycles(2, targets);
//! assert_eq!(result.tier, ConformanceTier::Optimal);
//! ```

pub mod elementwise;
pub mod reduce;
pub mod shuffle;

pub use uor::conformance::ConformanceTier;

use crate::state::State;

/// Cycle-count targets for conformance validation.
///
/// Every operation must declare three tiers:
/// - `minimum`: hard requirement (non-conformant if exceeded)
/// - `optimal`: soft target
/// - `theoretical`: physical limit
///
/// ```
/// use prism::ops::ConformanceTargets;
///
/// let t = ConformanceTargets { minimum: 5, optimal: 3, theoretical: 1 };
/// assert_eq!(t.minimum, 5);
/// ```
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ConformanceTargets {
    /// Maximum acceptable cycles (hard requirement).
    pub minimum: u64,
    /// Target cycles for well-optimized implementation.
    pub optimal: u64,
    /// Physical limit (perfect hardware utilization).
    pub theoretical: u64,
}

/// Result of conformance verification.
///
/// ```
/// use prism::ops::{ConformanceTargets, ConformanceResult};
/// use uor::conformance::ConformanceTier;
///
/// let targets = ConformanceTargets { minimum: 5, optimal: 3, theoretical: 1 };
/// let result = ConformanceResult::from_cycles(4, targets);
/// assert_eq!(result.tier, ConformanceTier::Minimum);
/// ```
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ConformanceResult {
    /// Achieved conformance tier.
    pub tier: ConformanceTier,
    /// Measured cycle count.
    pub measured_cycles: u64,
    /// Targets used for evaluation.
    pub targets: ConformanceTargets,
}

impl ConformanceResult {
    /// Compute a conformance result from measured cycles and targets.
    ///
    /// ```
    /// use prism::ops::{ConformanceTargets, ConformanceResult};
    /// use uor::conformance::ConformanceTier;
    ///
    /// let targets = ConformanceTargets { minimum: 5, optimal: 3, theoretical: 1 };
    /// assert_eq!(ConformanceResult::from_cycles(1, targets).tier, ConformanceTier::Theoretical);
    /// assert_eq!(ConformanceResult::from_cycles(2, targets).tier, ConformanceTier::Optimal);
    /// assert_eq!(ConformanceResult::from_cycles(4, targets).tier, ConformanceTier::Minimum);
    /// assert_eq!(ConformanceResult::from_cycles(6, targets).tier, ConformanceTier::NonConformant);
    /// ```
    #[must_use]
    pub fn from_cycles(measured_cycles: u64, targets: ConformanceTargets) -> Self {
        let tier = if measured_cycles > targets.minimum {
            ConformanceTier::NonConformant
        } else if measured_cycles > targets.optimal {
            ConformanceTier::Minimum
        } else if measured_cycles > targets.theoretical {
            ConformanceTier::Optimal
        } else {
            ConformanceTier::Theoretical
        };
        Self {
            tier,
            measured_cycles,
            targets,
        }
    }
}

/// A unary state transformation with conformance targets.
///
/// Every operation declares its name, conformance targets, and an `apply`
/// method that transforms a [`State`].
pub trait Operation {
    /// Human-readable operation name.
    const NAME: &'static str;

    /// Conformance targets for this operation.
    const TARGETS: ConformanceTargets;

    /// Apply the operation to a state.
    fn apply(&self, state: State) -> State;

    /// Apply the operation `n` times.
    fn apply_n(&self, mut state: State, n: usize) -> State {
        for _ in 0..n {
            state = self.apply(state);
        }
        state
    }

    /// Verify conformance against measured cycle count.
    fn verify_conformance(&self, measured_cycles: u64) -> ConformanceResult {
        ConformanceResult::from_cycles(measured_cycles, Self::TARGETS)
    }
}

/// A binary state transformation with conformance targets.
///
/// Takes two states and produces one output state.
pub trait BinaryOperation {
    /// Human-readable operation name.
    const NAME: &'static str;

    /// Conformance targets for this operation.
    const TARGETS: ConformanceTargets;

    /// Apply the operation to two states.
    fn apply(&self, a: State, b: State) -> State;

    /// Apply the operation `n` times (feeding result back as `a`).
    fn apply_n(&self, mut a: State, b: State, n: usize) -> State {
        for _ in 0..n {
            a = self.apply(a, b);
        }
        a
    }

    /// Verify conformance against measured cycle count.
    fn verify_conformance(&self, measured_cycles: u64) -> ConformanceResult {
        ConformanceResult::from_cycles(measured_cycles, Self::TARGETS)
    }
}

/// Verify a unary operation and return a conformance result.
///
/// ```
/// use prism::ops::{verify_operation, ConformanceTargets, Operation};
/// use prism::state::State;
///
/// struct IdentityOp;
/// impl Operation for IdentityOp {
///     const NAME: &'static str = "identity";
///     const TARGETS: ConformanceTargets = ConformanceTargets {
///         minimum: 5, optimal: 3, theoretical: 1,
///     };
///     fn apply(&self, state: State) -> State { state }
/// }
///
/// let result = verify_operation(&IdentityOp, 2);
/// assert!(result.tier.is_conformant());
/// ```
#[must_use]
pub fn verify_operation<O: Operation>(op: &O, measured_cycles: u64) -> ConformanceResult {
    op.verify_conformance(measured_cycles)
}

/// Verify a binary operation and return a conformance result.
///
/// ```
/// use prism::ops::{verify_binary_operation, ConformanceTargets, BinaryOperation};
/// use prism::state::State;
///
/// struct SelectFirst;
/// impl BinaryOperation for SelectFirst {
///     const NAME: &'static str = "select_first";
///     const TARGETS: ConformanceTargets = ConformanceTargets {
///         minimum: 5, optimal: 3, theoretical: 1,
///     };
///     fn apply(&self, a: State, _b: State) -> State { a }
/// }
///
/// let result = verify_binary_operation(&SelectFirst, 2);
/// assert!(result.tier.is_conformant());
/// ```
#[must_use]
pub fn verify_binary_operation<O: BinaryOperation>(
    op: &O,
    measured_cycles: u64,
) -> ConformanceResult {
    op.verify_conformance(measured_cycles)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_conformance_targets() {
        let t = ConformanceTargets {
            minimum: 5,
            optimal: 3,
            theoretical: 1,
        };
        assert_eq!(t.minimum, 5);
        assert_eq!(t.optimal, 3);
        assert_eq!(t.theoretical, 1);
    }

    #[test]
    fn test_conformance_result_tiers() {
        let t = ConformanceTargets {
            minimum: 5,
            optimal: 3,
            theoretical: 1,
        };

        assert_eq!(
            ConformanceResult::from_cycles(10, t).tier,
            ConformanceTier::NonConformant
        );
        assert_eq!(
            ConformanceResult::from_cycles(6, t).tier,
            ConformanceTier::NonConformant
        );
        assert_eq!(
            ConformanceResult::from_cycles(5, t).tier,
            ConformanceTier::Minimum
        );
        assert_eq!(
            ConformanceResult::from_cycles(4, t).tier,
            ConformanceTier::Minimum
        );
        assert_eq!(
            ConformanceResult::from_cycles(3, t).tier,
            ConformanceTier::Optimal
        );
        assert_eq!(
            ConformanceResult::from_cycles(2, t).tier,
            ConformanceTier::Optimal
        );
        assert_eq!(
            ConformanceResult::from_cycles(1, t).tier,
            ConformanceTier::Theoretical
        );
        assert_eq!(
            ConformanceResult::from_cycles(0, t).tier,
            ConformanceTier::Theoretical
        );
    }

    struct TestUnaryOp;

    impl Operation for TestUnaryOp {
        const NAME: &'static str = "test_unary";
        const TARGETS: ConformanceTargets = ConformanceTargets {
            minimum: 5,
            optimal: 3,
            theoretical: 1,
        };

        fn apply(&self, state: State) -> State {
            state
        }
    }

    #[test]
    fn test_operation_apply() {
        let op = TestUnaryOp;
        let s = State::zeros();
        assert_eq!(op.apply(s), s);
    }

    #[test]
    fn test_operation_apply_n() {
        let op = TestUnaryOp;
        let s = State::zeros();
        assert_eq!(op.apply_n(s, 10), s);
    }

    #[test]
    fn test_verify_operation() {
        let op = TestUnaryOp;
        let result = verify_operation(&op, 3);
        assert_eq!(result.tier, ConformanceTier::Optimal);
    }

    struct TestBinaryOp;

    impl BinaryOperation for TestBinaryOp {
        const NAME: &'static str = "test_binary";
        const TARGETS: ConformanceTargets = ConformanceTargets {
            minimum: 5,
            optimal: 3,
            theoretical: 1,
        };

        fn apply(&self, a: State, _b: State) -> State {
            a
        }
    }

    #[test]
    fn test_binary_operation_apply() {
        let op = TestBinaryOp;
        let a = State::zeros();
        let b = State::ones();
        assert_eq!(op.apply(a, b), a);
    }

    #[test]
    fn test_binary_operation_apply_n() {
        let op = TestBinaryOp;
        let a = State::zeros();
        let b = State::ones();
        assert_eq!(op.apply_n(a, b, 10), a);
    }

    #[test]
    fn test_verify_binary_operation() {
        let op = TestBinaryOp;
        let result = verify_binary_operation(&op, 2);
        assert_eq!(result.tier, ConformanceTier::Optimal);
    }
}
