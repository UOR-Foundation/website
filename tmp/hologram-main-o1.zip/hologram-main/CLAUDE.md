# Hologram

## Project Overview

Hologram is a compute acceleration framework that replaces algorithmic iteration with pre-computed lookup tables. Traditional computation scales with input size (O(n), O(n^3)). This framework pre-computes all possible transformations at build time so runtime becomes pure memory access -- O(1) constant time.

The project is a reimplementation. Prior crates from the original hologram project live under `prior-reference/crates/` for context and are **not** part of the active workspace. The active workspace starts with a single crate: `uor`.

**Repository:** https://github.com/UOR-Foundation/hologram
**License:** MIT OR Apache-2.0

## Vision

The framework targets low-resource, memory-constrained environments. Every byte (0-255) maps to a cell on a torus via pre-computed tables. Runtime operations are pure memory lookups with zero computation. Multiple backends will implement a shared ISA contract, and a compiler crate will enable parallelized layer execution.

See `specs/project.md` for the full conceptual definition including the compilation pipeline, .holo format, view system, and execution model.

## Architecture

### Workspace Layout

```
hologram/
├── crates/uor/          # Core UOR crate (zero external deps)
│   ├── src/             # taxon, word, domain, ring, isa, state, wavefront, channel, arch/
│   ├── tests/           # Conformance, wavefront, x86_64 tests
│   ├── benches/         # Criterion benchmarks (wavefront, conformance)
│   ├── schema/          # JSON-LD, JSON Schema, taxon catalog
│   └── docs/            # Architecture, cellular automata, framework, performance
├── crates/ffi/          # FFI crate (planned) -- exposes uor to Python, TypeScript, WASM, C
├── src/lib.rs           # Root workspace crate (minimal)
├── prior-reference/     # Prior hologram crates (read-only reference, not in workspace)
├── specs/               # project.md (conceptual definition), FUTURE_PLANS.md
├── .githooks/           # Git hooks (pre-commit: fmt, clippy, test)
├── .github/workflows/   # CI, benchmarks, deploy-pages
└── Justfile             # Task runner
```

### Mathematical Foundation

Three axioms generate the entire algebraic structure:

| Axiom        | Symbol | Value        | Meaning                              |
|-------------|--------|-------------|--------------------------------------|
| Triality     | T      | 3            | Three-fold symmetry                  |
| Octave       | O      | 8            | Bott periodicity                     |
| Binary Depth | B      | 2^(O-T) = 32 | Powers of 2 from octave-triality gap |

**Resonance Modulus R = T x B = 96** -- the algebraic workspace.

### UOR Core Concepts

- **Taxon**: Fundamental identity unit (bijective byte 0-255 <-> Braille U+2800-U+28FF)
- **Word**: Compound types (Word2, Word4, Word8, Word32)
- **Domain**: Triadic partition (T=3): Theta, Psi, Delta
- **Ring**: Arithmetic over Z_96 resonance ring
- **ISA**: Instruction set targeting x86_64 AMD Zen 3 execution ports (0, 1, 5)
- **Wavefront**: All execution ports fire simultaneously in one cycle
- **State**: 624 Taxons = 4992 bits across 30 registers (16 YMM + 14 GPR)
- **Channel**: Communication between execution domains
- **Torus**: Values live on 48 pages x 256 bytes = 12,288 cells

### Execution Model (pi-F-lambda)

```
Input -> [pi: Embedding] -> [F: Operation] -> [lambda: Lifting] -> Output
```

All computation follows this three-phase pipeline. Pi maps input to torus coordinates, F performs O(1) table lookups, lambda reconstructs output values.

### FFI Crate (`crates/ffi/`)

A dedicated FFI crate will expose core `uor` functionality to other languages. The FFI crate depends on `uor` but `uor` never depends on the FFI crate -- the dependency is strictly one-way.

**Binding targets** (from `specs/project.md`):

| Language      | Strategy                |
|--------------|------------------------|
| Python        | UniFFI (auto-generated) |
| TypeScript/JS | WASM (wasm-bindgen)     |
| C             | cbindgen                |
| C++           | CXX bridge              |

**Design rules:**
- The FFI crate is a thin translation layer. All logic lives in `uor`. The FFI crate converts types across the boundary and nothing else.
- FFI call overhead target: < 10 ns (see `specs/project.md` Performance Targets)
- Zero-copy where the FFI boundary permits (e.g., returning slices to WASM memory)
- Every exposed function must have integration tests in the target language
- The prior FFI implementation is in `prior-reference/crates/categorical-ffi/` for reference

## Prior Reference

The `prior-reference/crates/` directory contains the original hologram implementation. These crates are **not** in the workspace and must never be added to it.

**When to consult prior-reference:**
- To understand the intent behind an algorithm or data structure before reimplementing it
- To identify edge cases and invariants that the original handled
- To review test cases that should be preserved or improved upon

**When NOT to copy from prior-reference:**
- Do not copy code verbatim. The original codebase was not optimized for the constraints of this project (zero-copy, cache-bound, minimal dependencies).
- Do not carry over abstractions, trait hierarchies, or module structures without evaluating whether they serve the current architecture.
- Do not assume prior code is correct. Validate against the mathematical definitions in `specs/project.md`.

**The standard for reuse:** code from `prior-reference/` may be adopted only when it already meets all Hard Rules (zero-copy, cache-conscious, no external deps, fully tested, benchmarked). In practice, this means reimplementing from spec with the prior code as a conceptual guide.

## Commands

```bash
just build          # Build entire workspace
just build-release  # Release mode build
just check          # Fast workspace check
just test           # Run all workspace tests
just test-crate uor # Run tests for specific crate
just lint           # Clippy with -D warnings
just fmt            # Format all code
just fmt-check      # Check formatting only
just ci             # fmt-check + lint + test (run before committing)
just doc            # Generate docs
just doc-open       # Generate and open in browser
```

## Hard Rules

These rules are non-negotiable and apply to every change:

1. **All tests must pass.** No exceptions. Run `just ci` before any commit.
2. **Zero clippy warnings.** Enforced via `-D warnings`.
3. **100% test coverage.** Every public function, every branch, every error path must have a test. Unit tests in-module (`#[cfg(test)]`), integration tests in `tests/`, doc tests on all public items. No feature is complete without full coverage.
4. **Zero-copy contracts.** All memory is mapped on the torus within L1/L2 cache. No heap allocation on hot paths.
5. **No TODOs, no unimplemented!(), no placeholders, no stubs.** Ever. Always implement full functionality.
6. **Write as little code as possible.** Every function should be as short as it can be. If a function grows beyond ~15 lines, decompose it using traits or helper functions. Prefer expression-oriented style. Eliminate redundancy ruthlessly.
7. **Prefer internal implementation over external crates.** Keep dependencies minimal. The `uor` crate has zero external dependencies.
8. **No feature flags or backwards-compatibility shims** when you can just change the code.
9. **Every new operation must have a Criterion benchmark.** No functionality ships without a measured baseline. Optimizations are meaningless without a before/after number.
10. **Single execution path: Backends ONLY in `hologram-backend`.** There is exactly ONE place where backends are implemented: `crates/backends/`. The `uor::microcode` module provides primitives (`bnot`, `neg`, `xor`, `and`, `or`) that backends use for ISA operations. The `uor::arch` module provides wavefront executors for direct `UorState` manipulation (a different abstraction level). Backends orchestrate ISA execution (`execute_plan()`) and live in `hologram-backend`. Never implement backend functionality in `uor` - that violates the separation of concerns.

## Architectural Separation: uor vs hologram-backend

**CRITICAL**: The `uor` crate and `hologram-backend` crate have distinct, non-overlapping responsibilities. These are **complementary layers**, not a call hierarchy.

### uor Crate: Core Types and Wavefront Primitives

**Responsibility**: Core mathematical types and low-level wavefront execution on `UorState`.

**What lives here**:
- Core types (`UorState`, `Wavefront`, `Taxon`, `Word`, `Domain`, `Ring`)
- Wavefront execution traits (`UorStep`, `UorStepLossless`, `UorStepFused`)
- Hardware-specific wavefront executors in `uor::arch/`:
  - `Zen3Executor` / `Zen3AsmExecutor` (x86_64 with AVX2/SHA-NI/AES-NI)
  - `NeonExecutor` (aarch64 with NEON SIMD) - stub
  - `ScalarExecutor` (portable fallback) - stub
- Microcode primitives (`uor::microcode`): `bnot`, `neg`, `xor`, `and`, `or`

**What it does**:
- Provides core types for the torus algebra (624 taxons on 48 pages)
- Provides ONE WAVEFRONT execution for direct `UorState` manipulation
- Defines microcode primitives that all backends use

**Dependencies**: Zero external dependencies (pure Rust).

### hologram-backend Crate: ISA Orchestration

**Responsibility**: Execute compiled ISA plans across multiple operations on byte buffers.

**What lives here**:
- Backend trait definition (`Backend::execute_plan()`)
- Backend implementations in `backends/`:
  - `cpu/` - SIMD-accelerated execution via microcode primitives
  - `wasm/` - WebAssembly scalar execution
  - `cuda/` - NVIDIA GPU execution (skeleton)
  - `metal/` - Apple GPU execution (skeleton)
- Microcode backend unification (`microcode.rs`): `BackendVariant`, `BackendImpl`, `define_all_backends!`

**What it does**: Executes ENTIRE BACKENDPLANS with 50+ ISA operations. Takes compiled plans from `hologram-holo`, orchestrates execution across operations (Add, MatMul, Sigmoid, etc.), manages buffers and workspace.

**Dependencies**: Depends on `uor` (uses microcode primitives and types), `hologram-holo` (loads plans), `rayon` (parallelization).

### The Two Abstraction Levels

| Layer | Operates On | Purpose |
|-------|-------------|---------|
| `uor::arch` executors | `UorState` (624 taxons) | Wavefront execution for direct torus manipulation |
| `hologram-backend` | Byte buffers | ISA operations via microcode primitives |

**These are complementary, not a call chain.** The backend operates on buffers via ISA operations. Wavefront executors operate on torus state. They serve different use cases.

### Execution Flow

```
User Code
    ↓
hologram-compiler (future)
    ↓
BackendPlan (.holo file)
    ↓
hologram-backend::Backend::execute_plan()
    ↓
Microcode primitives (bnot, neg, xor, and, or)
    ↓
Hardware (AVX2, NEON, scalar)
```

For direct torus/state manipulation (not ISA execution):
```
User Code
    ↓
uor::arch::Zen3Executor::step()
    ↓
UorState modified
```

### Why This Separation Exists

1. **Dependency Direction**: `uor` has zero dependencies. `hologram-backend` depends on `uor`. This keeps the core math library portable and dependency-free.

2. **Different Abstractions**: Backends execute ISA operations on byte buffers. Wavefront executors manipulate `UorState` (624 taxons). Different data models, different use cases.

3. **GPU Backends**: CUDA and Metal backends implement ISA operations directly as GPU kernels. They use microcode primitives, not wavefront execution.

4. **Testing Isolation**: `uor` can be tested independently of the ISA backend system. Wavefront execution tests don't need to understand BackendPlans.

### Rule Violation Examples

❌ **WRONG**: Implementing `execute_plan()` or ISA operation handlers in `uor::arch`
- This belongs in `hologram-backend::backends::cpu`

❌ **WRONG**: Adding a `CudaExecutor` to `uor::arch`
- GPU backends implement ISA ops as kernels, not wavefronts
- This belongs in `hologram-backend::backends::cuda`

❌ **WRONG**: Calling `uor::arch` executors for buffer-based ISA operations
- Backends use microcode primitives for ISA execution
- `uor::arch` executors are for direct `UorState` wavefront manipulation

✅ **CORRECT**: Backend uses microcode primitives from `uor::microcode` for ISA operations
- Unified across all backends (CPU, WASM, GPU)
- Native SIMD overrides for performance-critical paths

## Code Style

- **Functions must be short.** If a function does more than one thing, split it. Use traits to define contracts and keep implementations focused on a single responsibility.
- **Use traits to shrink code.** Shared behavior across types goes into a trait. Default methods reduce per-type boilerplate. Generic functions over trait bounds replace type-specific duplication.
- **Decompose with traits, not comments.** If you need a comment to explain a section of a function, that section should be its own function or trait method.
- **Expression-oriented.** Prefer `match`, `if let`, and expression returns over mutable variables and early assignments.

### Builder Pattern

Use the Builder pattern for types with multiple optional fields or complex construction logic. Builders provide a fluent API, avoid "constructor explosion", and make construction intent explicit.

**When to use Builders:**
- Types with 3+ optional fields
- Construction requires validation or default computation
- API clarity matters (chained methods document intent)
- Partial construction is useful (build incrementally, reuse partial configs)

**Implementation:**

```rust
/// The target type
pub struct Config {
    size: usize,
    name: String,
    verbose: bool,
}

/// The builder (separate type)
#[derive(Default)]
pub struct ConfigBuilder {
    size: Option<usize>,
    name: Option<String>,
    verbose: bool,
}

impl ConfigBuilder {
    pub fn new() -> Self {
        Self::default()
    }

    /// Chainable setter - takes ownership and returns Self
    pub fn size(mut self, size: usize) -> Self {
        self.size = Some(size);
        self
    }

    pub fn name(mut self, name: impl Into<String>) -> Self {
        self.name = Some(name.into());
        self
    }

    pub fn verbose(mut self, verbose: bool) -> Self {
        self.verbose = verbose;
        self
    }

    /// Terminal method - consumes builder, returns target or error
    pub fn build(self) -> Result<Config, &'static str> {
        Ok(Config {
            size: self.size.ok_or("size is required")?,
            name: self.name.unwrap_or_else(|| "default".to_string()),
            verbose: self.verbose,
        })
    }
}

// Usage:
let config = ConfigBuilder::new()
    .size(1024)
    .name("example")
    .verbose(true)
    .build()?;
```

**Conventions:**
- Builder is a separate struct named `<Type>Builder`
- `new()` returns a default builder
- Setters take `self` by value and return `Self` for chaining
- Use `impl Into<String>` for string setters (accepts `&str` and `String`)
- `build()` consumes the builder and returns `Result<T, E>` if validation can fail
- Derive `Default` on the builder if all fields have sensible defaults
- Add a convenience constructor on the target: `Config::builder() -> ConfigBuilder`

## Parallelization

- **Rayon** for data-parallel iteration. Use `par_iter()`, `par_chunks()`, and parallel collect where element count exceeds the parallelism threshold. Add `rayon` as a workspace dependency for crates that need parallel execution.
- **SIMD** for vectorized hot paths. Use `core::arch::x86_64` intrinsics (AVX2, SHA-NI, AES-NI) behind `#[cfg(target_arch = "x86_64")]` guards. The `uor` crate already uses inline assembly for wavefront execution -- follow the same pattern in `crates/uor/src/arch/`.
- **Rayon for coarse-grained, SIMD for fine-grained.** Rayon parallelizes across independent work units (orbits, partitions, batches). SIMD parallelizes within a single operation (32 bytes at once with AVX2).
- **Always benchmark both paths.** Every parallelized operation must have benchmarks for the scalar baseline, the SIMD path, and the rayon path so the crossover point is known.

## Conventions

- **Rust edition:** 2021
- **UOR crate:** zero external dependencies, pure Rust, Copy types only
- **Triadic invariant (T=3):** preserved across all domain operations
- **Bijection guarantee:** every byte maps to exactly one Braille codepoint and vice versa
- **Cache-conscious:** data structures sized for L1 (512B-4KB), working sets for L2 (256KB)
- **Static dispatch:** kernel selection, threading, buffer allocation determined at compile time
- Use `#[inline]` for small hot-path functions
- Use `const` and `const fn` wherever possible for compile-time evaluation
- Prefer arrays over Vec, stack over heap

## Benchmarking

Every new public operation or hot-path function must have a Criterion benchmark before it is considered complete. Benchmarks are the project's source of truth for performance -- without a measured baseline, future optimizations cannot be validated.

### Structure

Benchmarks live in `crates/<crate>/benches/`. Each benchmark file is registered in the crate's `Cargo.toml`:

```toml
[[bench]]
name = "my_bench"
harness = false
```

### Writing a Benchmark

```rust
use criterion::{black_box, criterion_group, criterion_main, Criterion, Throughput};

fn bench_my_operation(c: &mut Criterion) {
    let mut group = c.benchmark_group("my_operation");
    group.throughput(Throughput::Elements(1));

    group.bench_function("baseline", |b| {
        b.iter(|| {
            black_box(my_operation(black_box(input)));
        });
    });

    group.finish();
}

criterion_group!(benches, bench_my_operation);
criterion_main!(benches);
```

### Conventions

- **Group by module**: one benchmark file per logical module (e.g., `wavefront.rs`, `conformance.rs`)
- **Use `Throughput`**: always set throughput so Criterion reports ops/sec or bytes/sec
- **Use `black_box`**: wrap inputs and outputs to prevent compiler elimination
- **Define conformance tiers** where applicable: MINIMUM (acceptable), OPTIMAL (target), THEORETICAL (physical limit). Declare these as constants so tests and benchmarks share the same thresholds.
- **Name benchmarks descriptively**: `bench_single_wavefront_3port`, not `bench_1`

### Running

```bash
cargo bench -p uor                          # All benchmarks in uor crate
cargo bench -p uor -- wavefront             # Filter by name
cargo bench -p uor -- --save-baseline main  # Save baseline for comparison
cargo bench -p uor -- --baseline main       # Compare against saved baseline
```

CI runs benchmarks on every push to main and uploads results as artifacts (`benchmarks.yml`). Compare locally against the CI baseline to validate optimizations.

## Sprint Tracking

`SPRINT.md` is the single source of truth for task status. It must always reflect reality:

- **Before starting a task:** move it from "Backlog" to "In Progress" in `SPRINT.md`.
- **After completing a task:** move it from "In Progress" to "Completed This Sprint" in `SPRINT.md`.
- **If a task becomes blocked:** move it to the "Blocked" section with a brief reason.
- **Never leave stale status.** If a task is in progress, it must be listed under "In Progress". If it is done, it must be under "Completed This Sprint". No task should sit in the wrong section.
- **Update `SPRINT.md` in the same commit** as the code change for the task. Task status and code must stay in sync.

## Planning Documents

`SPRINT.md` is the primary authority for what to work on and current status. Plan documents in `specs/plans/` supplement it with design detail when needed.

- **When to create a plan:** when a task or group of tasks requires architectural decisions, interface definitions, multi-step implementation sequences, or design rationale that does not fit in a `SPRINT.md` task description. If the detail fits in a few bullet points, keep it in `SPRINT.md` instead.
- **Where plans live:** `specs/plans/<number>-<name>.md` (e.g., `specs/plans/1-prism.md`). Number sequentially.
- **Link from `SPRINT.md`:** reference the plan file in the relevant task description (e.g., "See `specs/plans/1-prism.md` for full specification"). `SPRINT.md` tasks should be self-contained enough to understand what to do; the plan provides the why and how.
- **Plans are living documents.** Update them as decisions change. If a plan becomes obsolete, note it at the top rather than deleting it.
- **Do not duplicate `SPRINT.md` content.** Plans describe design and rationale. Task status, priority, and assignment belong exclusively in `SPRINT.md`.

## Sprint History

Completed sprints are archived in `specs/sprints/` for long-term reference. `SPRINT.md` keeps a one-line summary per sprint in its "Sprint History" section; the archive holds the full record.

- **When to archive:** when all tasks in a sprint are completed (or moved to the next sprint) and a new sprint begins.
- **Where archives live:** `specs/sprints/<number>-<name>.md` (e.g., `specs/sprints/1-clean-workspace.md`). Number matches the sprint number in `SPRINT.md`.
- **What to include:**
  - Sprint number, name, and date range
  - All tasks completed (task ID, title, one-line summary of what was done)
  - Tasks that were moved to the next sprint or dropped, with reasons
  - Key decisions made during the sprint
  - Notable metrics (benchmark numbers, test counts, lines changed) where relevant
- **Keep `SPRINT.md` focused on the current sprint.** Once a sprint is archived, remove its completed tasks from `SPRINT.md`'s "Completed This Sprint" section. The "Sprint History" section in `SPRINT.md` retains only the one-line summary linking to the archive.
- **Archive in the same commit** that starts the new sprint. This keeps `SPRINT.md` clean and the archive complete in a single atomic change.

## Commit Rules

- Write atomic, descriptive commit messages in imperative mood
- Ensure `just ci` passes before every commit
- Before completing any task, run `/commit`

## Pre-commit Hook

A pre-commit hook at `.githooks/pre-commit` runs automatically on every commit:

1. Auto-formats code with `cargo fmt` and stages changes
2. Runs `cargo clippy --workspace --all-targets -- -D warnings`
3. Runs unit tests (`cargo test --workspace --lib --bins`)

Git is configured to use `.githooks/` via `core.hooksPath`. To set this up on a fresh clone:

```bash
git config core.hooksPath .githooks
```

## CI/CD

GitHub Actions workflows in `.github/workflows/`:

| Workflow | Trigger | Jobs |
|----------|---------|------|
| `ci.yml` | Push to main/uor, PRs to main | Format check, Clippy, Tests (ubuntu + macos), Doc build |
| `benchmarks.yml` | Push to main, PRs to main, manual | Criterion benchmarks, artifact upload |
| `deploy-pages.yml` | Push to main, manual | Build and deploy website to GitHub Pages |
