//! Shell DSL parser built on nom combinators.
//!
//! Parses `.shell` files into the AST defined in [`crate::ast`].

use nom::{
    branch::alt,
    bytes::complete::{tag, take_while, take_while1},
    character::complete::{char, digit1, multispace0, multispace1},
    combinator::{map, opt, recognize, value},
    multi::{many0, separated_list0, separated_list1},
    sequence::{delimited, pair, preceded, tuple},
    IResult,
};

use crate::ast::*;

// ============================================================================
// Whitespace and comments
// ============================================================================

/// Consume whitespace and `# ...` line comments.
fn ws(input: &str) -> IResult<&str, ()> {
    let (input, _) = multispace0(input)?;
    // Consume any line comments
    let mut remaining = input;
    loop {
        let (r, _) = multispace0(remaining)?;
        if r.starts_with('#') {
            // Skip to end of line
            let newline_pos = r.find('\n').unwrap_or(r.len());
            remaining = &r[newline_pos..];
        } else {
            remaining = r;
            break;
        }
    }
    Ok((remaining, ()))
}

/// Wrap a parser to consume leading whitespace/comments.
fn wsp<'a, O, F>(f: F) -> impl FnMut(&'a str) -> IResult<&'a str, O>
where
    F: FnMut(&'a str) -> IResult<&'a str, O>,
{
    preceded(ws, f)
}

// ============================================================================
// Identifiers and literals
// ============================================================================

/// Parse an identifier: `[a-zA-Z_][a-zA-Z0-9_]*`
fn ident(input: &str) -> IResult<&str, &str> {
    recognize(pair(
        take_while1(|c: char| c.is_ascii_alphabetic() || c == '_'),
        take_while(|c: char| c.is_ascii_alphanumeric() || c == '_'),
    ))(input)
}

/// Parse an integer literal.
fn int_literal(input: &str) -> IResult<&str, u64> {
    let (input, s) = recognize(pair(opt(char('-')), digit1))(input)?;
    let val = s.parse::<i64>().map_err(|_| {
        nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Digit))
    })?;
    Ok((input, val as u64))
}

/// Parse a hex literal: `0xFF`
fn hex_literal(input: &str) -> IResult<&str, u64> {
    let (input, _) = tag("0x")(input)?;
    let (input, hex_str) = take_while1(|c: char| c.is_ascii_hexdigit())(input)?;
    let val = u64::from_str_radix(hex_str, 16).map_err(|_| {
        nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Digit))
    })?;
    Ok((input, val))
}

/// Parse a numeric literal (hex or decimal).
fn numeric_literal(input: &str) -> IResult<&str, u64> {
    alt((hex_literal, int_literal))(input)
}

/// Parse a float literal: `1e-5`, `0.001`
fn float_literal(input: &str) -> IResult<&str, f64> {
    let (input, s) = recognize(tuple((
        opt(char('-')),
        digit1,
        alt((
            recognize(pair(char('.'), digit1)),
            recognize(pair(
                alt((char('e'), char('E'))),
                recognize(pair(opt(alt((char('+'), char('-')))), digit1)),
            )),
        )),
    )))(input)?;
    let val = s.parse::<f64>().map_err(|_| {
        nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Float))
    })?;
    Ok((input, val))
}

/// Parse a quoted string: `"LUT"`
fn quoted_string(input: &str) -> IResult<&str, &str> {
    delimited(char('"'), take_while(|c: char| c != '"'), char('"'))(input)
}

// ============================================================================
// Type parsing
// ============================================================================

/// Parse a field type.
fn field_type(input: &str) -> IResult<&str, FieldType> {
    alt((
        // buf? (must come before buf)
        value(FieldType::OptBuf, tag("buf?")),
        // buf
        value(FieldType::Buf, tag("buf")),
        // vec<T>
        map(
            delimited(tag("vec<"), wsp(field_type), wsp(char('>'))),
            |inner| FieldType::Vec(Box::new(inner)),
        ),
        // [T; N]
        map(
            delimited(
                char('['),
                pair(wsp(field_type), preceded(wsp(char(';')), wsp(int_literal))),
                wsp(char(']')),
            ),
            |(inner, size)| FieldType::Array(Box::new(inner), size as usize),
        ),
        // list<T> (query-layer list type, e.g., list<u64>)
        map(
            delimited(tag("list<"), wsp(field_type), wsp(char('>'))),
            |inner| FieldType::List(Box::new(inner)),
        ),
        // [T] (list type for query layer, bracket syntax)
        map(
            delimited(char('['), wsp(field_type), wsp(char(']'))),
            |inner| FieldType::List(Box::new(inner)),
        ),
        // Primitives
        value(FieldType::Usize, tag("usize")),
        value(FieldType::U64, tag("u64")),
        value(FieldType::U32, tag("u32")),
        value(FieldType::U16, tag("u16")),
        value(FieldType::U8, tag("u8")),
        value(FieldType::I64, tag("i64")),
        value(FieldType::I32, tag("i32")),
        value(FieldType::F32, tag("f32")),
        value(FieldType::Domain, tag("Domain")),
        value(FieldType::String, tag("String")),
        // Named type (must be last)
        map(ident, |s: &str| FieldType::Named(s.to_string())),
    ))(input)
}

// ============================================================================
// Constraint and default value
// ============================================================================

/// Parse `mod N` constraint.
fn constraint(input: &str) -> IResult<&str, Constraint> {
    alt((
        map(
            preceded(pair(tag("mod"), multispace1), int_literal),
            Constraint::Mod,
        ),
        map(
            tuple((int_literal, wsp(tag("..")), wsp(int_literal))),
            |(lo, _, hi)| Constraint::Range(lo, hi),
        ),
    ))(input)
}

/// Parse `= value` default.
fn default_value(input: &str) -> IResult<&str, DefaultValue> {
    preceded(
        wsp(char('=')),
        wsp(alt((
            value(DefaultValue::None, tag("none")),
            map(float_literal, DefaultValue::Float),
            map(numeric_literal, DefaultValue::Int),
            map(ident, |s: &str| DefaultValue::Ident(s.to_string())),
        ))),
    )(input)
}

// ============================================================================
// Parameters
// ============================================================================

/// Parse a parameter: `name: type [mod N] [= default]`
fn param(input: &str) -> IResult<&str, Param> {
    let (input, name) = ident(input)?;
    let (input, _) = wsp(char(':'))(input)?;
    let (input, ty) = wsp(field_type)(input)?;
    let (input, con) = opt(preceded(multispace1, constraint))(input)?;
    let (input, def) = opt(default_value)(input)?;
    Ok((
        input,
        Param {
            name: name.to_string(),
            ty,
            constraint: con,
            default: def,
        },
    ))
}

/// Parse a comma-separated parameter list in parens: `(a: u8, b: u8)`
fn param_list(input: &str) -> IResult<&str, Vec<Param>> {
    delimited(
        wsp(char('(')),
        separated_list0(wsp(char(',')), wsp(param)),
        wsp(char(')')),
    )(input)
}

// ============================================================================
// Annotations
// ============================================================================

/// Parse a single annotation.
fn annotation(input: &str) -> IResult<&str, Annotation> {
    preceded(
        char('@'),
        alt((
            value(Annotation::Builder, tag("builder")),
            map(
                preceded(
                    tag("suffix"),
                    delimited(char('('), wsp(quoted_string), wsp(char(')'))),
                ),
                |s: &str| Annotation::Suffix(s.to_string()),
            ),
            map(
                preceded(
                    tag("variant"),
                    delimited(char('('), wsp(quoted_string), wsp(char(')'))),
                ),
                |s: &str| Annotation::Variant(s.to_string()),
            ),
            map(
                preceded(
                    tag("feature"),
                    delimited(char('('), wsp(quoted_string), wsp(char(')'))),
                ),
                |s: &str| Annotation::Feature(s.to_string()),
            ),
            map(
                preceded(
                    tag("kernel"),
                    delimited(char('('), wsp(quoted_string), wsp(char(')'))),
                ),
                |s: &str| Annotation::Kernel(s.to_string()),
            ),
        )),
    )(input)
}

/// Parse zero or more annotations.
fn annotations(input: &str) -> IResult<&str, Vec<Annotation>> {
    many0(wsp(annotation))(input)
}

// ============================================================================
// ISA constructs: group, op, compose
// ============================================================================

/// Parse a group member: `sigmoid = SIGMOID_256` or `add`
fn group_member(input: &str) -> IResult<&str, GroupMember> {
    let (input, name) = ident(input)?;
    let (input, table) = opt(preceded(wsp(char('=')), wsp(ident)))(input)?;
    Ok((
        input,
        GroupMember {
            name: name.to_string(),
            table_ref: table.map(String::from),
            doc: None,
        },
    ))
}

/// Parse a group definition.
///
/// ```text
/// group lut_activation(dst: buf, src: buf, count: usize) @suffix("LUT") {
///     sigmoid = SIGMOID_256
///     tanh    = TANH_256
/// }
/// ```
fn group_def(input: &str) -> IResult<&str, GroupDef> {
    let (input, _) = tag("group")(input)?;
    let (input, name) = wsp(ident)(input)?;
    let (input, params) = param_list(input)?;
    let (input, anns) = annotations(input)?;
    let (input, members) = delimited(
        wsp(char('{')),
        separated_list0(
            alt((wsp(char(',')), map(wsp(char('\n')), |_| ','))),
            wsp(group_member),
        ),
        wsp(char('}')),
    )(input)?;
    // Filter empty entries from trailing separators
    let members: Vec<_> = members.into_iter().filter(|m| !m.name.is_empty()).collect();
    Ok((
        input,
        GroupDef {
            name: name.to_string(),
            params,
            members,
            annotations: anns,
        },
    ))
}

/// Parse an op parameter (simple, @pair, or @group).
fn op_param(input: &str) -> IResult<&str, OpParam> {
    alt((
        // @pair kernel(kernel_h: usize = 3, kernel_w: usize = 3)
        map(
            preceded(tag("@pair"), pair(wsp(ident), param_list)),
            |(name, params)| OpParam::Pair {
                group_name: name.to_string(),
                params,
            },
        ),
        // @group input_shape(batch: usize, in_channels: usize, ...)
        map(
            preceded(tag("@group"), pair(wsp(ident), param_list)),
            |(name, params)| OpParam::Group {
                group_name: name.to_string(),
                params,
            },
        ),
        // Simple param: name: type [= default]
        map(param, OpParam::Simple),
    ))(input)
}

/// Parse an op definition.
///
/// ```text
/// op matmul(c: buf, a: buf, b: buf, m: usize, k: usize, n: usize)
/// op conv2d(...) @builder @feature("conv")
/// ```
fn op_def(input: &str) -> IResult<&str, OpDef> {
    let (input, _) = tag("op")(input)?;
    let (input, name) = wsp(ident)(input)?;
    let (input, params) = delimited(
        wsp(char('(')),
        separated_list0(wsp(char(',')), wsp(op_param)),
        wsp(char(')')),
    )(input)?;
    let (input, anns) = annotations(input)?;
    Ok((
        input,
        OpDef {
            name: name.to_string(),
            params,
            annotations: anns,
            doc: None,
        },
    ))
}

/// Parse a compose definition.
///
/// ```text
/// compose standard_normalize = [sigmoid, tanh, relu]
/// ```
fn compose_def(input: &str) -> IResult<&str, ComposeDef> {
    let (input, _) = tag("compose")(input)?;
    let (input, name) = wsp(ident)(input)?;
    let (input, _) = wsp(char('='))(input)?;
    let (input, chain) = delimited(
        wsp(char('[')),
        separated_list1(wsp(char(',')), wsp(map(ident, String::from))),
        wsp(char(']')),
    )(input)?;
    Ok((
        input,
        ComposeDef {
            name: name.to_string(),
            chain,
        },
    ))
}

// ============================================================================
// Query-layer constructs: type, enum, transform
// ============================================================================

/// Parse a resolver expression: `stratum_q0(value)` or `ring_add_96(value, other)`
fn resolver_expr(input: &str) -> IResult<&str, ResolverExpr> {
    let (input, function) = ident(input)?;
    let (input, args) = delimited(
        wsp(char('(')),
        separated_list0(wsp(char(',')), wsp(expr_arg)),
        wsp(char(')')),
    )(input)?;
    Ok((
        input,
        ResolverExpr {
            function: function.to_string(),
            args,
        },
    ))
}

/// Parse an expression argument.
fn expr_arg(input: &str) -> IResult<&str, ExprArg> {
    alt((
        map(expr, |e| ExprArg::Expr(Box::new(e))),
        map(ident, |s: &str| ExprArg::Param(s.to_string())),
    ))(input)
}

/// Parse a simple expression.
fn expr(input: &str) -> IResult<&str, Expr> {
    let (input, left) = expr_atom(input)?;
    // Try to parse a binary operator
    if let Ok((input, (op, right))) = pair(wsp(bin_op), wsp(expr_atom))(input) {
        Ok((input, Expr::BinOp(Box::new(left), op, Box::new(right))))
    } else {
        Ok((input, left))
    }
}

/// Parse an atomic expression.
fn expr_atom(input: &str) -> IResult<&str, Expr> {
    alt((
        map(numeric_literal, Expr::Literal),
        // Try function call first: name(args)
        map(
            pair(
                ident,
                delimited(
                    char('('),
                    separated_list0(wsp(char(',')), wsp(expr)),
                    wsp(char(')')),
                ),
            ),
            |(name, args)| Expr::Call(name.to_string(), args),
        ),
        map(ident, |s: &str| Expr::Param(s.to_string())),
    ))(input)
}

/// Parse a binary operator.
fn bin_op(input: &str) -> IResult<&str, BinOp> {
    alt((
        value(BinOp::Shr, tag(">>")),
        value(BinOp::Shl, tag("<<")),
        value(BinOp::BitAnd, char('&')),
        value(BinOp::BitOr, char('|')),
        value(BinOp::Add, char('+')),
        value(BinOp::Sub, char('-')),
        value(BinOp::Mul, char('*')),
        value(BinOp::Mod, char('%')),
    ))(input)
}

/// Parse a field definition within a type.
///
/// ```text
/// stratum: u8 = stratum_q0(value)
/// add(other: u8 mod 96): u8 = ring_add_96(value, other)
/// torus { page: u8 = torus_page_q0(value) }
/// ```
fn field_def(input: &str) -> IResult<&str, FieldDef> {
    let (input, name) = ident(input)?;

    // Optional arguments for parameterized fields
    let (input, args) = opt(param_list)(input)?;

    // Optional `: type = resolver` or just nested `{ ... }`
    let (input, (return_type, resolver, children)) = alt((
        // Nested sub-object: `name { fields... }`
        map(
            delimited(wsp(char('{')), many0(wsp(field_def)), wsp(char('}'))),
            |children| {
                (
                    FieldType::Named(name.to_string()),
                    ResolverExpr {
                        function: String::new(),
                        args: vec![],
                    },
                    children,
                )
            },
        ),
        // Field with type and resolver: `name: type = resolver(args)`
        map(
            tuple((
                preceded(wsp(char(':')), wsp(field_type)),
                preceded(wsp(char('=')), wsp(resolver_expr)),
            )),
            |(ty, res)| (ty, res, vec![]),
        ),
    ))(input)?;

    Ok((
        input,
        FieldDef {
            name: name.to_string(),
            args: args.unwrap_or_default(),
            return_type,
            resolver,
            children,
        },
    ))
}

/// Parse a type definition (supports single or multiple params).
///
/// ```text
/// type Byte(value: u8) { ... }
/// type Path(path: list<u64>, quantum: u32) { ... }
/// ```
fn type_def(input: &str) -> IResult<&str, TypeDef> {
    let (input, _) = tag("type")(input)?;
    let (input, name) = wsp(ident)(input)?;
    let (input, _) = wsp(char('('))(input)?;
    let (input, first) = wsp(param)(input)?;
    let (input, rest) = many0(preceded(wsp(char(',')), wsp(param)))(input)?;
    let (input, _) = wsp(char(')'))(input)?;
    let (input, fields) = delimited(wsp(char('{')), many0(wsp(field_def)), wsp(char('}')))(input)?;
    let mut params = vec![first];
    params.extend(rest);
    Ok((
        input,
        TypeDef {
            name: name.to_string(),
            params,
            fields,
        },
    ))
}

/// Parse an enum variant: `Theta = 0` or `Theta`
fn enum_variant(input: &str) -> IResult<&str, EnumVariant> {
    let (input, name) = ident(input)?;
    let (input, val) = opt(preceded(wsp(char('=')), wsp(numeric_literal)))(input)?;
    Ok((
        input,
        EnumVariant {
            name: name.to_string(),
            value: val,
        },
    ))
}

/// Parse an enum definition.
///
/// ```text
/// enum Domain { Theta = 0, Psi = 1, Delta = 2 }
/// ```
fn enum_def(input: &str) -> IResult<&str, EnumDef> {
    let (input, _) = tag("enum")(input)?;
    let (input, name) = wsp(ident)(input)?;
    let (input, variants) = delimited(
        wsp(char('{')),
        separated_list0(wsp(char(',')), wsp(enum_variant)),
        wsp(char('}')),
    )(input)?;
    let variants: Vec<_> = variants
        .into_iter()
        .filter(|v| !v.name.is_empty())
        .collect();
    Ok((
        input,
        EnumDef {
            name: name.to_string(),
            variants,
        },
    ))
}

/// Parse a transform operation: `add = ring_add_96(input, by)`
fn transform_op(input: &str) -> IResult<&str, TransformOp> {
    let (input, name) = ident(input)?;
    let (input, _) = wsp(char('='))(input)?;
    let (input, resolver) = wsp(resolver_expr)(input)?;
    Ok((
        input,
        TransformOp {
            name: name.to_string(),
            resolver,
        },
    ))
}

/// Parse a transform definition.
///
/// ```text
/// transform Translate(by: u8 mod 96) -> u8 {
///     add = ring_add_96(input, by)
///     sub = ring_sub_96(input, by)
/// }
/// ```
fn transform_def(input: &str) -> IResult<&str, TransformDef> {
    let (input, _) = tag("transform")(input)?;
    let (input, name) = wsp(ident)(input)?;
    let (input, params) = param_list(input)?;
    let (input, _) = wsp(tag("->"))(input)?;
    let (input, ret) = wsp(field_type)(input)?;
    let (input, ops) = delimited(wsp(char('{')), many0(wsp(transform_op)), wsp(char('}')))(input)?;
    Ok((
        input,
        TransformDef {
            name: name.to_string(),
            params,
            return_type: ret,
            operations: ops,
        },
    ))
}

// ============================================================================
// Top-level shell parsing
// ============================================================================

/// Parse a shell item (one of the top-level constructs).
fn shell_item(input: &str) -> IResult<&str, ShellItem> {
    alt((
        map(group_def, ShellItem::Group),
        map(op_def, ShellItem::Op),
        map(compose_def, ShellItem::Compose),
        map(type_def, ShellItem::Type),
        map(enum_def, ShellItem::Enum),
        map(transform_def, ShellItem::Transform),
    ))(input)
}

/// Parse `@module("uor::observable")` annotation on shell header.
fn module_annotation(input: &str) -> IResult<&str, String> {
    preceded(
        tag("@module"),
        delimited(
            wsp(char('(')),
            delimited(char('"'), take_while1(|c: char| c != '"'), char('"')),
            wsp(char(')')),
        ),
    )(input)
    .map(|(rest, s)| (rest, s.to_string()))
}

/// Parse a complete shell file.
///
/// ```text
/// shell datum {
///     type Byte(value: u8) { ... }
///     enum Domain { ... }
/// }
/// ```
fn shell_file(input: &str) -> IResult<&str, Shell> {
    let (input, _) = ws(input)?;
    let (input, _) = tag("shell")(input)?;
    let (input, name) = wsp(ident)(input)?;
    // Optional @module("path") annotation
    let (input, module_path) = opt(wsp(module_annotation))(input)?;
    let (input, items) = delimited(wsp(char('{')), many0(wsp(shell_item)), wsp(char('}')))(input)?;
    let (input, _) = ws(input)?;
    Ok((
        input,
        Shell {
            name: name.to_string(),
            module_path,
            items,
        },
    ))
}

/// Parse a `.shell` file into a [`Shell`] AST.
///
/// # Errors
///
/// Returns [`ParseError`] if the input is not valid shell syntax.
pub fn parse_shell(input: &str) -> Result<Shell, crate::error::ParseError> {
    match shell_file(input) {
        Ok((remaining, shell)) => {
            let trimmed = remaining.trim();
            if trimmed.is_empty() {
                Ok(shell)
            } else {
                Err(crate::error::ParseError::from_nom(
                    remaining,
                    input,
                    "unexpected trailing content",
                ))
            }
        }
        Err(e) => Err(crate::error::ParseError {
            message: format!("parse failed: {e}"),
            offset: 0,
            remaining: if input.len() > 60 {
                format!("{}...", &input[..60])
            } else {
                input.to_string()
            },
        }),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_ident_basic() {
        assert_eq!(ident("foo"), Ok(("", "foo")));
        assert_eq!(ident("_bar_baz"), Ok(("", "_bar_baz")));
        assert_eq!(ident("sigmoid256 rest"), Ok((" rest", "sigmoid256")));
    }

    #[test]
    fn parse_field_type_primitives() {
        assert_eq!(field_type("u8"), Ok(("", FieldType::U8)));
        assert_eq!(field_type("usize"), Ok(("", FieldType::Usize)));
        assert_eq!(field_type("f32"), Ok(("", FieldType::F32)));
        assert_eq!(field_type("buf"), Ok(("", FieldType::Buf)));
        assert_eq!(field_type("buf?"), Ok(("", FieldType::OptBuf)));
    }

    #[test]
    fn parse_field_type_array() {
        assert_eq!(
            field_type("[usize; 8]"),
            Ok(("", FieldType::Array(Box::new(FieldType::Usize), 8)))
        );
        assert_eq!(
            field_type("[u8; 4]"),
            Ok(("", FieldType::Array(Box::new(FieldType::U8), 4)))
        );
    }

    #[test]
    fn parse_field_type_vec() {
        assert_eq!(
            field_type("vec<buf>"),
            Ok(("", FieldType::Vec(Box::new(FieldType::Buf))))
        );
    }

    #[test]
    fn parse_param_simple() {
        let (_, p) = param("dst: buf").unwrap();
        assert_eq!(p.name, "dst");
        assert_eq!(p.ty, FieldType::Buf);
        assert!(p.constraint.is_none());
        assert!(p.default.is_none());
    }

    #[test]
    fn parse_param_with_constraint() {
        let (_, p) = param("value: u8 mod 96").unwrap();
        assert_eq!(p.name, "value");
        assert_eq!(p.ty, FieldType::U8);
        assert_eq!(p.constraint, Some(Constraint::Mod(96)));
    }

    #[test]
    fn parse_param_with_default() {
        let (_, p) = param("kernel_h: usize = 3").unwrap();
        assert_eq!(p.name, "kernel_h");
        assert_eq!(p.ty, FieldType::Usize);
        assert_eq!(p.default, Some(DefaultValue::Int(3)));
    }

    #[test]
    fn parse_param_optional_buf() {
        let (_, p) = param("bias: buf? = none").unwrap();
        assert_eq!(p.name, "bias");
        assert_eq!(p.ty, FieldType::OptBuf);
        assert_eq!(p.default, Some(DefaultValue::None));
    }

    #[test]
    fn parse_annotation_builder() {
        let (_, a) = annotation("@builder").unwrap();
        assert_eq!(a, Annotation::Builder);
    }

    #[test]
    fn parse_annotation_suffix() {
        let (_, a) = annotation("@suffix(\"LUT\")").unwrap();
        assert_eq!(a, Annotation::Suffix("LUT".into()));
    }

    #[test]
    fn parse_annotation_feature() {
        let (_, a) = annotation("@feature(\"tokenization\")").unwrap();
        assert_eq!(a, Annotation::Feature("tokenization".into()));
    }

    #[test]
    fn parse_group_member_with_table() {
        let (_, m) = group_member("sigmoid = SIGMOID_256").unwrap();
        assert_eq!(m.name, "sigmoid");
        assert_eq!(m.table_ref, Some("SIGMOID_256".into()));
    }

    #[test]
    fn parse_group_member_without_table() {
        let (_, m) = group_member("add").unwrap();
        assert_eq!(m.name, "add");
        assert!(m.table_ref.is_none());
    }

    #[test]
    fn parse_group_definition() {
        let input = r#"group lut_activation(dst: buf, src: buf, count: usize) @suffix("LUT") {
            sigmoid = SIGMOID_256,
            tanh    = TANH_256,
            relu    = RELU_256
        }"#;
        let (_, g) = group_def(input).unwrap();
        assert_eq!(g.name, "lut_activation");
        assert_eq!(g.params.len(), 3);
        assert_eq!(g.members.len(), 3);
        assert_eq!(g.members[0].name, "sigmoid");
        assert_eq!(g.members[0].table_ref, Some("SIGMOID_256".into()));
        assert_eq!(g.annotations, vec![Annotation::Suffix("LUT".into())]);
    }

    #[test]
    fn parse_op_simple() {
        let input = "op matmul(c: buf, a: buf, b: buf, m: usize, k: usize, n: usize)";
        let (_, o) = op_def(input).unwrap();
        assert_eq!(o.name, "matmul");
        assert_eq!(o.all_params().len(), 6);
        assert!(o.annotations.is_empty());
    }

    #[test]
    fn parse_op_with_builder_and_pairs() {
        let input = r#"op conv2d(
            dst: buf, input: buf, weight: buf, bias: buf? = none,
            @pair kernel(kernel_h: usize = 3, kernel_w: usize = 3),
            @pair stride(stride_h: usize = 1, stride_w: usize = 1),
            groups: usize = 1,
            @group input_shape(batch: usize, in_channels: usize, in_h: usize, in_w: usize),
            @group output_shape(out_channels: usize, out_h: usize, out_w: usize)
        ) @builder"#;
        let (_, o) = op_def(input).unwrap();
        assert_eq!(o.name, "conv2d");
        assert!(o.has_builder());

        let all = o.all_params();
        // 4 simple + 2 pair(2 each) + 1 simple + 2 groups(4+3) = 4+4+1+7 = 16
        assert_eq!(all.len(), 16);
        assert_eq!(all[0].name, "dst");
        assert_eq!(all[3].name, "bias");
        assert_eq!(all[3].ty, FieldType::OptBuf);
        assert_eq!(all[4].name, "kernel_h");
        assert_eq!(all[4].default, Some(DefaultValue::Int(3)));
    }

    #[test]
    fn parse_op_with_feature() {
        let input = r#"op viterbi_tokenize(
            dst: buf, src: buf, src_len: usize
        ) @feature("tokenization")"#;
        let (_, o) = op_def(input).unwrap();
        assert_eq!(o.feature_gate(), Some("tokenization"));
    }

    #[test]
    fn parse_op_with_arrays() {
        let input = "op transpose(dst: buf, src: buf, count: usize, ndim: u8, shape: [usize; 8], perm: [u8; 8])";
        let (_, o) = op_def(input).unwrap();
        assert_eq!(o.name, "transpose");
        let all = o.all_params();
        assert_eq!(all[4].ty, FieldType::Array(Box::new(FieldType::Usize), 8));
        assert_eq!(all[5].ty, FieldType::Array(Box::new(FieldType::U8), 8));
    }

    #[test]
    fn parse_op_with_vec() {
        let input = "op call_layer(layer_id: u64, inputs: vec<buf>, outputs: vec<buf>)";
        let (_, o) = op_def(input).unwrap();
        assert_eq!(
            o.all_params()[1].ty,
            FieldType::Vec(Box::new(FieldType::Buf))
        );
    }

    #[test]
    fn parse_compose() {
        let input = "compose standard_normalize = [sigmoid, tanh, relu]";
        let (_, c) = compose_def(input).unwrap();
        assert_eq!(c.name, "standard_normalize");
        assert_eq!(c.chain, vec!["sigmoid", "tanh", "relu"]);
    }

    #[test]
    fn parse_enum_definition() {
        let input = "enum Domain { Theta = 0, Psi = 1, Delta = 2 }";
        let (_, e) = enum_def(input).unwrap();
        assert_eq!(e.name, "Domain");
        assert_eq!(e.variants.len(), 3);
        assert_eq!(e.variants[0].name, "Theta");
        assert_eq!(e.variants[0].value, Some(0));
    }

    #[test]
    fn parse_type_definition() {
        let input = r#"type Byte(value: u8) {
            stratum: u8 = stratum_q0(value)
            curvature: u8 = curvature_q0(value)
        }"#;
        let (_, t) = type_def(input).unwrap();
        assert_eq!(t.name, "Byte");
        assert_eq!(t.params[0].name, "value");
        assert_eq!(t.params[0].ty, FieldType::U8);
        assert_eq!(t.fields.len(), 2);
        assert_eq!(t.fields[0].name, "stratum");
        assert_eq!(t.fields[0].resolver.function, "stratum_q0");
    }

    #[test]
    fn parse_transform_definition() {
        let input = r#"transform Translate(by: u8 mod 96) -> u8 {
            add = ring_add_96(input, by)
            sub = ring_sub_96(input, by)
        }"#;
        let (_, t) = transform_def(input).unwrap();
        assert_eq!(t.name, "Translate");
        assert_eq!(t.params[0].constraint, Some(Constraint::Mod(96)));
        assert_eq!(t.return_type, FieldType::U8);
        assert_eq!(t.operations.len(), 2);
        assert_eq!(t.operations[0].name, "add");
    }

    #[test]
    fn parse_full_isa_shell() {
        let input = r#"
        shell isa {
            # LUT-based unary activations
            group lut_activation(dst: buf, src: buf, count: usize) @suffix("LUT") {
                sigmoid = SIGMOID_256,
                tanh    = TANH_256,
                relu    = RELU_256
            }

            # Binary elementwise
            group binary_elementwise(dst: buf, a: buf, b: buf, count: usize) {
                add,
                sub,
                mul
            }

            # Complex ops
            op matmul(c: buf, a: buf, b: buf, m: usize, k: usize, n: usize)

            op softmax(dst: buf, src: buf, outer_size: usize, axis_size: usize, inner_size: usize)

            # Composed tables
            compose standard_normalize = [sigmoid, tanh, relu]
        }
        "#;
        let shell = parse_shell(input).unwrap();
        assert_eq!(shell.name, "isa");
        assert_eq!(shell.items.len(), 5);

        // Verify group
        match &shell.items[0] {
            ShellItem::Group(g) => {
                assert_eq!(g.name, "lut_activation");
                assert_eq!(g.members.len(), 3);
            }
            other => panic!("expected Group, got {other:?}"),
        }

        // Verify op
        match &shell.items[2] {
            ShellItem::Op(o) => {
                assert_eq!(o.name, "matmul");
                assert_eq!(o.all_params().len(), 6);
            }
            other => panic!("expected Op, got {other:?}"),
        }

        // Verify compose
        match &shell.items[4] {
            ShellItem::Compose(c) => {
                assert_eq!(c.name, "standard_normalize");
                assert_eq!(c.chain.len(), 3);
            }
            other => panic!("expected Compose, got {other:?}"),
        }
    }

    #[test]
    fn parse_full_datum_shell() {
        let input = r#"
        shell datum {
            type Byte(value: u8) {
                stratum:   u8     = stratum_q0(value)
                curvature: u8     = curvature_q0(value)
                domain:    Domain = domain_q0(value)
                rank:      u8     = rank_q0(value)
            }

            enum Domain {
                Theta = 0,
                Psi   = 1,
                Delta = 2
            }
        }
        "#;
        let shell = parse_shell(input).unwrap();
        assert_eq!(shell.name, "datum");
        assert_eq!(shell.items.len(), 2);

        match &shell.items[0] {
            ShellItem::Type(t) => {
                assert_eq!(t.name, "Byte");
                assert_eq!(t.fields.len(), 4);
                assert_eq!(t.fields[2].return_type, FieldType::Domain);
            }
            other => panic!("expected Type, got {other:?}"),
        }
    }

    #[test]
    fn parse_full_ring_shell() {
        let input = r#"
        shell ring {
            type Element(value: u8 mod 96) {
                domain: Domain = domain_q0(value)
                add(other: u8 mod 96): u8 = ring_add_96(value, other)
                sub(other: u8 mod 96): u8 = ring_sub_96(value, other)
                mul(other: u8 mod 96): u8 = ring_mul_96(value, other)
            }

            transform Translate(by: u8 mod 96) -> u8 {
                add = ring_add_96(input, by)
                sub = ring_sub_96(input, by)
                mul = ring_mul_96(input, by)
            }
        }
        "#;
        let shell = parse_shell(input).unwrap();
        assert_eq!(shell.name, "ring");

        match &shell.items[0] {
            ShellItem::Type(t) => {
                assert_eq!(t.name, "Element");
                assert_eq!(t.params[0].constraint, Some(Constraint::Mod(96)));
                assert_eq!(t.fields.len(), 4);
                // Parameterized field
                assert_eq!(t.fields[1].name, "add");
                assert_eq!(t.fields[1].args.len(), 1);
                assert_eq!(t.fields[1].args[0].name, "other");
            }
            other => panic!("expected Type, got {other:?}"),
        }
    }

    #[test]
    fn parse_comments_ignored() {
        let input = r#"
        # This is a comment
        shell test {
            # Another comment
            op noop(dst: buf)
            # Trailing comment
        }
        "#;
        let shell = parse_shell(input).unwrap();
        assert_eq!(shell.name, "test");
        assert_eq!(shell.items.len(), 1);
    }

    #[test]
    fn parse_observable_shell_multi_param() {
        let input = r#"
        shell observable @module("uor::observable") {
            type Path(path: list<u64>, quantum: u32) {
                winding:         i64       = winding_number(path, quantum)
                total_variation: u64       = total_variation(path, quantum)
                cascade_spectrum: list<u32> = cascade_spectrum(path, quantum)
            }
        }
        "#;
        let shell = parse_shell(input).unwrap();
        assert_eq!(shell.name, "observable");
        assert_eq!(shell.module_path.as_deref(), Some("uor::observable"));

        match &shell.items[0] {
            ShellItem::Type(t) => {
                assert_eq!(t.name, "Path");
                assert_eq!(t.params.len(), 2);
                assert_eq!(t.params[0].name, "path");
                assert_eq!(t.params[0].ty, FieldType::List(Box::new(FieldType::U64)));
                assert_eq!(t.params[1].name, "quantum");
                assert_eq!(t.params[1].ty, FieldType::U32);
                assert_eq!(t.fields.len(), 3);
                assert_eq!(t.fields[0].name, "winding");
                assert_eq!(t.fields[0].return_type, FieldType::I64);
                assert_eq!(
                    t.fields[2].return_type,
                    FieldType::List(Box::new(FieldType::U32))
                );
            }
            other => panic!("expected Type, got {other:?}"),
        }
    }
}
