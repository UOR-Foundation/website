//! Full-stack integration tests: query string → parse → validate → resolve → JSON.
//!
//! Verifies generated resolvers produce mathematically correct output by
//! comparing against direct LUT/observable function calls for all input values.

use hologram_query::{execute, parse};

// ============================================================================
// Byte domain: exhaustive LUT verification
// ============================================================================

/// All 256 byte values produce correct stratum, curvature, domain, rank, orbit_class.
#[test]
fn byte_all_256_values_match_lut() {
    for v in 0..=255u8 {
        let q = format!(
            "query {{ byte(value: {v}) {{ stratum, curvature, domain, rank, orbit_class }} }}"
        );
        let doc = parse(&q).unwrap();
        let result = execute(&doc).unwrap();

        assert_eq!(
            result["stratum"].as_u64().unwrap() as u8,
            uor::lut::stratum_q0(v),
            "stratum mismatch for value {v}"
        );
        assert_eq!(
            result["curvature"].as_u64().unwrap() as u8,
            uor::lut::curvature_q0(v),
            "curvature mismatch for value {v}"
        );
        assert_eq!(
            result["domain"].as_u64().unwrap() as u8,
            uor::lut::domain_q0(v),
            "domain mismatch for value {v}"
        );
        assert_eq!(
            result["rank"].as_u64().unwrap() as u8,
            uor::lut::rank_q0(v),
            "rank mismatch for value {v}"
        );
        assert_eq!(
            result["orbit_class"].as_u64().unwrap() as u8,
            uor::lut::orbit_class_q0(v),
            "orbit_class mismatch for value {v}"
        );
    }
}

// ============================================================================
// Element domain: exhaustive byte arithmetic verification
// ============================================================================

/// All byte elements with add/sub/mul match direct LUT calls.
#[test]
fn element_arithmetic_all_values() {
    for a in 0..=255u8 {
        let b = a.wrapping_add(13); // Arbitrary second operand
        let q = format!(
            "query {{ ring(value: {a}) {{ add(other: {b}), sub(other: {b}), mul(other: {b}) }} }}"
        );
        let doc = parse(&q).unwrap();
        let result = execute(&doc).unwrap();

        assert_eq!(
            result["add"].as_u64().unwrap() as u8,
            uor::lut::byte_add(a, b),
            "add mismatch for {a} + {b}"
        );
        assert_eq!(
            result["sub"].as_u64().unwrap() as u8,
            uor::lut::byte_sub(a, b),
            "sub mismatch for {a} - {b}"
        );
        assert_eq!(
            result["mul"].as_u64().unwrap() as u8,
            uor::lut::byte_mul(a, b),
            "mul mismatch for {a} * {b}"
        );
    }
}

// ============================================================================
// Activation domain: exhaustive verification of all 9 functions
// ============================================================================

/// All 9 activation functions for all 256 inputs match direct LUT calls.
#[test]
fn activation_all_256_values_match_lut() {
    #[allow(clippy::type_complexity)]
    let activations: &[(&str, fn(u8) -> u8)] = &[
        ("sigmoid", uor::lut::sigmoid_lut),
        ("tanh", uor::lut::tanh_lut),
        ("relu", uor::lut::relu_lut),
        ("exp", uor::lut::exp_lut),
        ("log", uor::lut::log_lut),
        ("sqrt", uor::lut::sqrt_lut),
        ("abs", uor::lut::abs_lut),
        ("gelu", uor::lut::gelu_lut),
        ("silu", uor::lut::silu_lut),
    ];

    for v in 0..=255u8 {
        let fields = activations
            .iter()
            .map(|(name, _)| *name)
            .collect::<Vec<_>>()
            .join(", ");
        let q = format!("query {{ activation(value: {v}) {{ {fields} }} }}");
        let doc = parse(&q).unwrap();
        let result = execute(&doc).unwrap();

        for (name, func) in activations {
            assert_eq!(
                result[name].as_u64().unwrap() as u8,
                func(v),
                "{name} mismatch for value {v}"
            );
        }
    }
}

// ============================================================================
// Observable domain
// ============================================================================

/// PathDto results match direct uor::observable function calls.
#[test]
fn observable_winding_matches_direct() {
    let paths: &[&[u64]] = &[
        &[0, 10, 20, 30, 40],
        &[0, 1, 2, 3],
        &[100, 200, 50, 25, 75],
        &[0],
    ];

    for path in paths {
        let path_str = path
            .iter()
            .map(|v| v.to_string())
            .collect::<Vec<_>>()
            .join(", ");
        let q = format!(
            "query {{ observable(path: [{path_str}], quantum: 8) {{ winding, total_variation }} }}"
        );
        let doc = parse(&q).unwrap();
        let result = execute(&doc).unwrap();

        assert_eq!(
            result["winding"].as_i64().unwrap(),
            uor::observable::winding_number(path, 8),
            "winding mismatch for path {path:?}"
        );
        assert_eq!(
            result["total_variation"].as_u64().unwrap(),
            uor::observable::total_variation(path, 8),
            "total_variation mismatch for path {path:?}"
        );
    }
}

// ============================================================================
// End-to-end pipeline: string → JSON
// ============================================================================

/// Full parse-to-JSON pipeline for a byte query.
#[test]
fn full_pipeline_byte_parse_to_json() {
    let q = "query { byte(value: 42) { stratum } }";
    let doc = parse(q).unwrap();
    let result = execute(&doc).unwrap();
    assert_eq!(
        result["stratum"].as_u64().unwrap() as u8,
        uor::lut::stratum_q0(42)
    );
}

/// Full parse-to-JSON pipeline for an element param query.
#[test]
fn full_pipeline_element_param_parse_to_json() {
    let q = "query { ring(value: 50) { add(other: 10) } }";
    let doc = parse(q).unwrap();
    let result = execute(&doc).unwrap();
    assert_eq!(
        result["add"].as_u64().unwrap() as u8,
        uor::lut::byte_add(50, 10)
    );
}

/// Full parse-to-JSON pipeline for an observable query.
#[test]
fn full_pipeline_observable_parse_to_json() {
    let q = "query { observable(path: [0, 1, 2, 3], quantum: 8) { winding } }";
    let doc = parse(q).unwrap();
    let result = execute(&doc).unwrap();
    assert_eq!(
        result["winding"].as_i64().unwrap(),
        uor::observable::winding_number(&[0, 1, 2, 3], 8)
    );
}

/// Range query returns correct count and consistent results.
#[test]
fn range_query_consistency() {
    let q = "query { byteRange(from: 0, to: 255) { stratum, curvature } }";
    let doc = parse(q).unwrap();
    let rows = hologram_query::execute_rows(&doc).unwrap();
    assert_eq!(rows.len(), 256, "byteRange(0, 255) should return 256 rows");

    // Each row should match individual byte query
    for (i, row) in rows.iter().enumerate() {
        let v = i as u8;
        assert_eq!(
            row["stratum"].as_u64().unwrap() as u8,
            uor::lut::stratum_q0(v),
            "range row {i} stratum mismatch"
        );
        assert_eq!(
            row["curvature"].as_u64().unwrap() as u8,
            uor::lut::curvature_q0(v),
            "range row {i} curvature mismatch"
        );
    }
}
