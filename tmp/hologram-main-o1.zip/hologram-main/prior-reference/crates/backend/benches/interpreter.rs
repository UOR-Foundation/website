//! CPU interpreter benchmarks.
//!
//! Benchmarks for ISA instruction execution on the CPU backend.

use criterion::{black_box, criterion_group, criterion_main, Criterion, Throughput};
use hologram_backend::cpu::Interpreter;
use hologram_isa::{BinaryOp, Instruction, Program, ProgramBuilder, Register, Type, UnaryOp};
use rustc_hash::FxHashMap;

/// Benchmark arithmetic instruction execution.
fn bench_arithmetic(c: &mut Criterion) {
    let mut group = c.benchmark_group("arithmetic");

    // Create a program that performs many arithmetic operations
    let mut program = Program::new();
    // Initialize registers with immediate values
    program.push(Instruction::MovImm {
        ty: Type::I64,
        dst: Register::R11,
        value: 5,
    });
    program.push(Instruction::MovImm {
        ty: Type::I64,
        dst: Register::R12,
        value: 3,
    });
    for _ in 0..1000 {
        program.push(Instruction::Add {
            ty: Type::I64,
            dst: Register::R10,
            lhs: Register::R11,
            rhs: Register::R12,
        });
        program.push(Instruction::Mul {
            ty: Type::I64,
            dst: Register::R13,
            lhs: Register::R10,
            rhs: Register::R11,
        });
        program.push(Instruction::Sub {
            ty: Type::I64,
            dst: Register::R14,
            lhs: Register::R13,
            rhs: Register::R12,
        });
    }
    program.push(Instruction::Exit);

    group.throughput(Throughput::Elements(3000));
    group.bench_function("add_mul_sub_1000", |b| {
        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        b.iter(|| {
            interpreter
                .execute(black_box(&program), &mut buffers)
                .unwrap()
        })
    });

    group.finish();
}

/// Benchmark float arithmetic operations.
fn bench_float_arithmetic(c: &mut Criterion) {
    let mut group = c.benchmark_group("float_arithmetic");

    let mut program = Program::new();
    // Initialize float registers - using i128 representation
    program.push(Instruction::MovImm {
        ty: Type::I64,
        dst: Register::R11,
        value: 3_i128, // Will be treated as raw bits
    });
    program.push(Instruction::MovImm {
        ty: Type::I64,
        dst: Register::R12,
        value: 2_i128,
    });
    for _ in 0..1000 {
        program.push(Instruction::Add {
            ty: Type::F64,
            dst: Register::R10,
            lhs: Register::R11,
            rhs: Register::R12,
        });
        program.push(Instruction::Mul {
            ty: Type::F64,
            dst: Register::R13,
            lhs: Register::R10,
            rhs: Register::R11,
        });
    }
    program.push(Instruction::Exit);

    group.throughput(Throughput::Elements(2000));
    group.bench_function("f64_add_mul_1000", |b| {
        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        b.iter(|| {
            interpreter
                .execute(black_box(&program), &mut buffers)
                .unwrap()
        })
    });

    group.finish();
}

/// Benchmark transcendental functions.
fn bench_transcendental(c: &mut Criterion) {
    let mut group = c.benchmark_group("transcendental");

    let operations = [
        (
            "exp",
            Instruction::Exp {
                ty: Type::F64,
                dst: Register::R10,
                src: Register::R11,
            },
        ),
        (
            "log",
            Instruction::Log {
                ty: Type::F64,
                dst: Register::R10,
                src: Register::R11,
            },
        ),
        (
            "sin",
            Instruction::Sin {
                ty: Type::F64,
                dst: Register::R10,
                src: Register::R11,
            },
        ),
        (
            "cos",
            Instruction::Cos {
                ty: Type::F64,
                dst: Register::R10,
                src: Register::R11,
            },
        ),
        (
            "sqrt",
            Instruction::Sqrt {
                ty: Type::F64,
                dst: Register::R10,
                src: Register::R11,
            },
        ),
    ];

    for (name, op) in operations {
        let mut program = Program::new();
        // Set up initial value
        program.push(Instruction::MovImm {
            ty: Type::I64,
            dst: Register::R11,
            value: 1_i128, // Will use raw bits
        });
        for _ in 0..1000 {
            program.push(op.clone());
        }
        program.push(Instruction::Exit);

        group.throughput(Throughput::Elements(1000));
        group.bench_function(format!("{}_1000", name), |b| {
            let mut interpreter = Interpreter::new();
            let mut buffers = FxHashMap::default();
            b.iter(|| {
                interpreter
                    .execute(black_box(&program), &mut buffers)
                    .unwrap()
            })
        });
    }

    group.finish();
}

/// Benchmark activation functions.
fn bench_activations(c: &mut Criterion) {
    let mut group = c.benchmark_group("activations");

    let operations = [
        (
            "sigmoid",
            Instruction::Sigmoid {
                ty: Type::F64,
                dst: Register::R10,
                src: Register::R11,
            },
        ),
        (
            "relu",
            Instruction::Relu {
                ty: Type::F64,
                dst: Register::R10,
                src: Register::R11,
            },
        ),
        (
            "tanh",
            Instruction::Tanh {
                ty: Type::F64,
                dst: Register::R10,
                src: Register::R11,
            },
        ),
        (
            "gelu",
            Instruction::Gelu {
                ty: Type::F64,
                dst: Register::R10,
                src: Register::R11,
            },
        ),
    ];

    for (name, op) in operations {
        let mut program = Program::new();
        program.push(Instruction::MovImm {
            ty: Type::I64,
            dst: Register::R11,
            value: 0_i128,
        });
        for _ in 0..1000 {
            program.push(op.clone());
        }
        program.push(Instruction::Exit);

        group.throughput(Throughput::Elements(1000));
        group.bench_function(format!("{}_1000", name), |b| {
            let mut interpreter = Interpreter::new();
            let mut buffers = FxHashMap::default();
            b.iter(|| {
                interpreter
                    .execute(black_box(&program), &mut buffers)
                    .unwrap()
            })
        });
    }

    group.finish();
}

/// Benchmark Atlas-specific operations using lookup crate.
fn bench_atlas_ops(c: &mut Criterion) {
    let mut group = c.benchmark_group("atlas");

    // TorusMap
    let mut torus_program = Program::new();
    for i in 0..256 {
        torus_program.push(Instruction::MovImm {
            ty: Type::U8,
            dst: Register::R11,
            value: i as i128,
        });
        torus_program.push(Instruction::TorusMap {
            dst: Register::R10,
            byte: Register::R11,
        });
    }
    torus_program.push(Instruction::Exit);

    group.throughput(Throughput::Elements(256));
    group.bench_function("torus_map_256", |b| {
        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        b.iter(|| {
            interpreter
                .execute(black_box(&torus_program), &mut buffers)
                .unwrap()
        })
    });

    // PageIndex + ByteIndex
    let mut page_byte_program = Program::new();
    page_byte_program.push(Instruction::MovImm {
        ty: Type::U8,
        dst: Register::R11,
        value: 97, // 'a'
    });
    for _ in 0..1000 {
        page_byte_program.push(Instruction::PageIndex {
            dst: Register::R10,
            byte: Register::R11,
        });
        page_byte_program.push(Instruction::ByteIndex {
            dst: Register::R12,
            byte: Register::R11,
        });
    }
    page_byte_program.push(Instruction::Exit);

    group.throughput(Throughput::Elements(2000));
    group.bench_function("page_byte_index_1000", |b| {
        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        b.iter(|| {
            interpreter
                .execute(black_box(&page_byte_program), &mut buffers)
                .unwrap()
        })
    });

    // CellPack + CellUnpack
    let mut pack_program = Program::new();
    pack_program.push(Instruction::MovImm {
        ty: Type::U16,
        dst: Register::R11,
        value: 0x0561, // page=5, byte=97
    });
    for _ in 0..1000 {
        pack_program.push(Instruction::CellPack {
            dst: Register::R10,
            cell: Register::R11,
        });
        pack_program.push(Instruction::CellUnpack {
            dst: Register::R12,
            packed: Register::R10,
        });
    }
    pack_program.push(Instruction::Exit);

    group.throughput(Throughput::Elements(2000));
    group.bench_function("cell_pack_unpack_1000", |b| {
        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        b.iter(|| {
            interpreter
                .execute(black_box(&pack_program), &mut buffers)
                .unwrap()
        })
    });

    group.finish();
}

/// Benchmark control flow instructions.
fn bench_control_flow(c: &mut Criterion) {
    let mut group = c.benchmark_group("control_flow");

    // Loop benchmark
    let mut loop_program = Program::new();
    loop_program.push(Instruction::MovImm {
        ty: Type::U32,
        dst: Register::R0, // Loop counter must be r0
        value: 100,
    });
    loop_program.push(Instruction::MovImm {
        ty: Type::I64,
        dst: Register::R10,
        value: 0,
    });
    loop_program.push(Instruction::MovImm {
        ty: Type::I64,
        dst: Register::R11,
        value: 1,
    });
    loop_program.push(Instruction::Label {
        name: "loop_start".to_string(),
    });
    loop_program.push(Instruction::Add {
        ty: Type::I64,
        dst: Register::R10,
        lhs: Register::R10,
        rhs: Register::R11,
    });
    loop_program.push(Instruction::Loop {
        counter: Register::R0,
        label: "loop_start".to_string(),
    });
    loop_program.push(Instruction::Exit);

    group.bench_function("loop_100_iterations", |b| {
        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        b.iter(|| {
            interpreter
                .execute(black_box(&loop_program), &mut buffers)
                .unwrap()
        })
    });

    // Select/conditional benchmark
    let mut select_program = Program::new();
    select_program.push(Instruction::MovImm {
        ty: Type::I64,
        dst: Register::R10,
        value: 5,
    });
    select_program.push(Instruction::MovImm {
        ty: Type::I64,
        dst: Register::R11,
        value: 10,
    });
    for _ in 0..1000 {
        select_program.push(Instruction::Less {
            ty: Type::I64,
            dst: Register::R15,
            lhs: Register::R10,
            rhs: Register::R11,
        });
        select_program.push(Instruction::Select {
            ty: Type::I64,
            dst: Register::R12,
            cond: Register::R15,
            true_val: Register::R10,
            false_val: Register::R11,
        });
    }
    select_program.push(Instruction::Exit);

    group.throughput(Throughput::Elements(2000));
    group.bench_function("select_1000", |b| {
        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        b.iter(|| {
            interpreter
                .execute(black_box(&select_program), &mut buffers)
                .unwrap()
        })
    });

    group.finish();
}

/// Benchmark bitwise operations.
fn bench_bitwise(c: &mut Criterion) {
    let mut group = c.benchmark_group("bitwise");

    let mut program = Program::new();
    program.push(Instruction::MovImm {
        ty: Type::I64,
        dst: Register::R11,
        value: 0xAAAA_AAAAi128,
    });
    program.push(Instruction::MovImm {
        ty: Type::I64,
        dst: Register::R12,
        value: 0x5555_5555i128,
    });
    for _ in 0..1000 {
        program.push(Instruction::BitAnd {
            ty: Type::I64,
            dst: Register::R10,
            lhs: Register::R11,
            rhs: Register::R12,
        });
        program.push(Instruction::BitOr {
            ty: Type::I64,
            dst: Register::R13,
            lhs: Register::R10,
            rhs: Register::R11,
        });
        program.push(Instruction::BitXor {
            ty: Type::I64,
            dst: Register::R14,
            lhs: Register::R13,
            rhs: Register::R12,
        });
    }
    program.push(Instruction::Exit);

    group.throughput(Throughput::Elements(3000));
    group.bench_function("and_or_xor_1000", |b| {
        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        b.iter(|| {
            interpreter
                .execute(black_box(&program), &mut buffers)
                .unwrap()
        })
    });

    group.finish();
}

/// Benchmark memory load/store operations.
fn bench_memory(c: &mut Criterion) {
    let mut group = c.benchmark_group("memory");

    // Create a buffer with data
    let buffer_data: Vec<u8> = (0..4096).map(|i| (i % 256) as u8).collect();

    // Load benchmark
    let mut load_program = Program::new();
    load_program.push(Instruction::MovImm {
        ty: Type::U64,
        dst: Register::R1, // Buffer handle
        value: 1,
    });
    for i in 0..1000 {
        load_program.push(Instruction::MovImm {
            ty: Type::U64,
            dst: Register::R2,
            value: (i * 4) % 4092,
        });
        load_program.push(Instruction::Ldg {
            ty: Type::U32,
            dst: Register::R10,
            src: hologram_isa::Address::buffer(1, 0),
        });
    }
    load_program.push(Instruction::Exit);

    group.throughput(Throughput::Elements(1000));
    group.bench_function("ldg_1000", |b| {
        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        buffers.insert(1u64, buffer_data.clone());
        b.iter(|| {
            interpreter
                .execute(black_box(&load_program), &mut buffers)
                .unwrap()
        })
    });

    group.finish();
}

/// Benchmark ProgramBuilder-generated code.
fn bench_program_builder(c: &mut Criterion) {
    let mut group = c.benchmark_group("program_builder");

    // Elementwise binary operation
    let program = ProgramBuilder::new()
        .elementwise_binary(BinaryOp::Add, 0, 1, 2, 100, Type::F32)
        .build();

    group.bench_function("elementwise_add_100", |b| {
        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        // Create input buffers
        buffers.insert(0u64, vec![0u8; 400]);
        buffers.insert(1u64, vec![0u8; 400]);
        buffers.insert(2u64, vec![0u8; 400]);
        b.iter(|| {
            interpreter
                .execute(black_box(&program), &mut buffers)
                .unwrap()
        })
    });

    // Elementwise unary operation
    let program = ProgramBuilder::new()
        .elementwise_unary(UnaryOp::Relu, 0, 1, 100, Type::F32)
        .build();

    group.bench_function("elementwise_relu_100", |b| {
        let mut interpreter = Interpreter::new();
        let mut buffers = FxHashMap::default();
        buffers.insert(0u64, vec![0u8; 400]);
        buffers.insert(1u64, vec![0u8; 400]);
        b.iter(|| {
            interpreter
                .execute(black_box(&program), &mut buffers)
                .unwrap()
        })
    });

    group.finish();
}

criterion_group!(
    benches,
    bench_arithmetic,
    bench_float_arithmetic,
    bench_transcendental,
    bench_activations,
    bench_atlas_ops,
    bench_control_flow,
    bench_bitwise,
    bench_memory,
    bench_program_builder,
);
criterion_main!(benches);
