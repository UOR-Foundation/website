//! Core traits for the codec system.
//!
//! This module provides the fundamental traits that codecs implement:
//!
//! - [`Codec`]: The main trait for encoding/decoding operations
//! - [`ScaleFactor`]: Configuration for numeric representation
//! - [`StreamingCodec`]: Extension trait for streaming encode/decode
//! - [`ChunkEncoder`] / [`ChunkDecoder`]: Incremental processing

mod codec;
mod streaming;

pub use codec::{Codec, ScaleFactor};
pub use streaming::{
    BatchDecoder, BatchEncoder, BrailleStreamDecoder, BrailleStreamEncoder, ChunkDecoder,
    ChunkEncoder, StreamingCodec,
};
