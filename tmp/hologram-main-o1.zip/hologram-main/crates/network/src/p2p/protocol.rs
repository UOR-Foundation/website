//! P2P protocol message types.

use hologram_sha256::Sha256;
use serde::{Deserialize, Serialize};

/// 32-byte peer identifier.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct PeerId(pub [u8; 32]);

impl PeerId {
    /// Create a peer ID from bytes.
    #[must_use]
    pub const fn from_bytes(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }

    /// Generate a random peer ID.
    #[must_use]
    pub fn random() -> Self {
        use std::time::{SystemTime, UNIX_EPOCH};

        // Simple deterministic generation from time and counter
        // In production, this would use a proper RNG
        static COUNTER: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| u64::try_from(d.as_nanos()).unwrap_or(u64::MAX))
            .unwrap_or(0);
        let count = COUNTER.fetch_add(1, std::sync::atomic::Ordering::SeqCst);

        let mut hasher = Sha256::new();
        hasher.update(&now.to_le_bytes());
        hasher.update(&count.to_le_bytes());
        hasher.update(&std::process::id().to_le_bytes());
        Self(hasher.finalize().into())
    }

    /// Get the peer ID as bytes.
    #[must_use]
    pub const fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }

    /// Convert to hex string.
    #[must_use]
    pub fn to_hex(&self) -> String {
        hex_encode(&self.0)
    }

    /// Parse from hex string.
    #[must_use]
    pub fn from_hex(s: &str) -> Option<Self> {
        if s.len() != 64 {
            return None;
        }

        let mut bytes = [0u8; 32];
        for (i, chunk) in s.as_bytes().chunks(2).enumerate() {
            if i >= 32 {
                return None;
            }
            let hex_str = std::str::from_utf8(chunk).ok()?;
            bytes[i] = u8::from_str_radix(hex_str, 16).ok()?;
        }
        Some(Self(bytes))
    }
}

impl std::fmt::Display for PeerId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        // Display first 8 chars of hex
        write!(f, "peer-{}", &self.to_hex()[..8])
    }
}

/// Protocol message types.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum MessageType {
    /// Ping request.
    Ping,
    /// Pong response.
    Pong,
    /// Layer announcement.
    LayerAnnounce,
    /// Request for layer.
    LayerRequest,
    /// Layer data.
    LayerData,
    /// Find layer providers.
    FindLayer,
    /// List of peers.
    PeerList,
    /// Hello handshake.
    Hello,
    /// Hello acknowledgment.
    HelloAck,
    /// Content request.
    ContentRequest,
    /// Content data.
    ContentData,
    /// Content not found.
    ContentNotFound,
}

/// Content request payload.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContentRequest {
    /// Request ID for correlation.
    pub request_id: u64,
    /// Content ID to fetch.
    pub content_id: [u8; 32],
}

/// Content response payload.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContentResponse {
    /// Request ID for correlation.
    pub request_id: u64,
    /// Content data if found.
    pub data: Option<Vec<u8>>,
    /// Error message if not found.
    pub error: Option<String>,
}

/// Layer announcement payload.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerAnnouncement {
    /// Layer reference (namespace/name:tag).
    pub layer_ref: String,
    /// Content ID of the layer.
    pub content_id: Option<[u8; 32]>,
    /// Layer size in bytes.
    pub size: Option<u64>,
}

/// P2P message.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Message {
    /// Message type.
    pub msg_type: MessageType,
    /// Source peer ID.
    pub source: PeerId,
    /// Sequence number.
    pub seq: u64,
    /// Payload (serialized).
    pub payload: Vec<u8>,
}

impl Message {
    /// Create a new message.
    #[must_use]
    pub fn new(msg_type: MessageType, source: PeerId, seq: u64, payload: Vec<u8>) -> Self {
        Self {
            msg_type,
            source,
            seq,
            payload,
        }
    }

    /// Create a ping message.
    #[must_use]
    pub fn ping(source: PeerId, seq: u64) -> Self {
        Self::new(MessageType::Ping, source, seq, Vec::new())
    }

    /// Create a pong message.
    #[must_use]
    pub fn pong(source: PeerId, seq: u64) -> Self {
        Self::new(MessageType::Pong, source, seq, Vec::new())
    }

    /// Create a hello message.
    #[must_use]
    pub fn hello(source: PeerId, seq: u64) -> Self {
        Self::new(MessageType::Hello, source, seq, Vec::new())
    }

    /// Create a hello ack message.
    #[must_use]
    pub fn hello_ack(source: PeerId, seq: u64) -> Self {
        Self::new(MessageType::HelloAck, source, seq, Vec::new())
    }

    /// Create a content request message.
    #[must_use]
    pub fn content_request(
        source: PeerId,
        seq: u64,
        request_id: u64,
        content_id: [u8; 32],
    ) -> Self {
        let request = ContentRequest {
            request_id,
            content_id,
        };
        let payload = serde_json::to_vec(&request).unwrap_or_default();
        Self::new(MessageType::ContentRequest, source, seq, payload)
    }

    /// Create a content data message.
    #[must_use]
    pub fn content_data(source: PeerId, seq: u64, request_id: u64, data: Vec<u8>) -> Self {
        let response = ContentResponse {
            request_id,
            data: Some(data),
            error: None,
        };
        let payload = serde_json::to_vec(&response).unwrap_or_default();
        Self::new(MessageType::ContentData, source, seq, payload)
    }

    /// Create a content not found message.
    #[must_use]
    pub fn content_not_found(source: PeerId, seq: u64, request_id: u64, error: &str) -> Self {
        let response = ContentResponse {
            request_id,
            data: None,
            error: Some(error.to_string()),
        };
        let payload = serde_json::to_vec(&response).unwrap_or_default();
        Self::new(MessageType::ContentNotFound, source, seq, payload)
    }

    /// Create a layer announcement message.
    #[must_use]
    pub fn layer_announce(
        source: PeerId,
        seq: u64,
        layer_ref: &str,
        content_id: Option<[u8; 32]>,
        size: Option<u64>,
    ) -> Self {
        let announcement = LayerAnnouncement {
            layer_ref: layer_ref.to_string(),
            content_id,
            size,
        };
        let payload = serde_json::to_vec(&announcement).unwrap_or_default();
        Self::new(MessageType::LayerAnnounce, source, seq, payload)
    }

    /// Parse content request from payload.
    #[must_use]
    pub fn parse_content_request(&self) -> Option<ContentRequest> {
        if self.msg_type != MessageType::ContentRequest {
            return None;
        }
        serde_json::from_slice(&self.payload).ok()
    }

    /// Parse content response from payload.
    #[must_use]
    pub fn parse_content_response(&self) -> Option<ContentResponse> {
        if !matches!(
            self.msg_type,
            MessageType::ContentData | MessageType::ContentNotFound
        ) {
            return None;
        }
        serde_json::from_slice(&self.payload).ok()
    }

    /// Parse layer announcement from payload.
    #[must_use]
    pub fn parse_layer_announcement(&self) -> Option<LayerAnnouncement> {
        if self.msg_type != MessageType::LayerAnnounce {
            return None;
        }
        serde_json::from_slice(&self.payload).ok()
    }
}

/// Encode bytes as hexadecimal string.
fn hex_encode(data: &[u8]) -> String {
    const HEX_CHARS: &[u8; 16] = b"0123456789abcdef";
    let mut result = String::with_capacity(data.len() * 2);
    for byte in data {
        result.push(HEX_CHARS[(byte >> 4) as usize] as char);
        result.push(HEX_CHARS[(byte & 0x0f) as usize] as char);
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_peer_id_random() {
        let id1 = PeerId::random();
        let id2 = PeerId::random();
        assert_ne!(id1, id2);
    }

    #[test]
    fn test_peer_id_hex() {
        let id = PeerId::from_bytes([0xab; 32]);
        let hex = id.to_hex();
        assert_eq!(hex.len(), 64);
        assert!(hex.chars().all(|c| c == 'a' || c == 'b'));

        let parsed = PeerId::from_hex(&hex).unwrap();
        assert_eq!(id, parsed);
    }

    #[test]
    fn test_peer_id_display() {
        let id = PeerId::from_bytes([0xde; 32]);
        let display = format!("{id}");
        assert!(display.starts_with("peer-"));
        assert_eq!(display.len(), 5 + 8); // "peer-" + 8 hex chars
    }

    #[test]
    #[allow(clippy::similar_names)]
    fn test_message_ping_pong() {
        let peer = PeerId::random();
        let ping = Message::ping(peer, 1);
        assert_eq!(ping.msg_type, MessageType::Ping);
        assert_eq!(ping.source, peer);
        assert_eq!(ping.seq, 1);

        let pong = Message::pong(peer, 2);
        assert_eq!(pong.msg_type, MessageType::Pong);
    }

    #[test]
    fn test_message_content_request() {
        let peer = PeerId::random();
        let content_id = [0x12; 32];
        let msg = Message::content_request(peer, 1, 42, content_id);

        assert_eq!(msg.msg_type, MessageType::ContentRequest);
        let request = msg.parse_content_request().unwrap();
        assert_eq!(request.request_id, 42);
        assert_eq!(request.content_id, content_id);
    }

    #[test]
    fn test_message_content_response() {
        let peer = PeerId::random();
        let data = vec![1, 2, 3, 4];
        let msg = Message::content_data(peer, 1, 42, data.clone());

        assert_eq!(msg.msg_type, MessageType::ContentData);
        let response = msg.parse_content_response().unwrap();
        assert_eq!(response.request_id, 42);
        assert_eq!(response.data, Some(data));
        assert!(response.error.is_none());
    }

    #[test]
    fn test_message_content_not_found() {
        let peer = PeerId::random();
        let msg = Message::content_not_found(peer, 1, 42, "not found");

        assert_eq!(msg.msg_type, MessageType::ContentNotFound);
        let response = msg.parse_content_response().unwrap();
        assert_eq!(response.request_id, 42);
        assert!(response.data.is_none());
        assert_eq!(response.error, Some("not found".to_string()));
    }

    #[test]
    fn test_message_layer_announce() {
        let peer = PeerId::random();
        let content_id = [0x34; 32];
        let msg = Message::layer_announce(peer, 1, "mymodel:v1", Some(content_id), Some(1024));

        assert_eq!(msg.msg_type, MessageType::LayerAnnounce);
        let announcement = msg.parse_layer_announcement().unwrap();
        assert_eq!(announcement.layer_ref, "mymodel:v1");
        assert_eq!(announcement.content_id, Some(content_id));
        assert_eq!(announcement.size, Some(1024));
    }

    #[test]
    fn test_message_serialization() {
        let peer = PeerId::random();
        let msg = Message::ping(peer, 123);

        let json = serde_json::to_string(&msg).unwrap();
        let parsed: Message = serde_json::from_str(&json).unwrap();

        assert_eq!(parsed.msg_type, msg.msg_type);
        assert_eq!(parsed.source, msg.source);
        assert_eq!(parsed.seq, msg.seq);
    }
}
