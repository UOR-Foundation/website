//! Microcode-based backend generation.
//!
//! This module provides the `define_all_backends!` macro that generates all backend
//! implementations from a single unified specification. The macro leverages the
//! microcode primitives from `uor` to define operations in terms of 5 fundamental
//! operations: `bnot`, `neg`, `xor`, `and`, `or`.
//!
//! # Architecture
//!
//! ```text
//! uor crate (pure types + microcode definitions)
//! └── MicrocodeWord, MicrocodePrimitives, MicrocodeOps
//!
//! hologram-backend crate (ALL hardware execution)
//! └── define_all_backends! macro generates:
//!     ├── BackendImpl enum with all variants
//!     ├── Per-target primitive implementations
//!     ├── auto_select() runtime detection
//!     └── compile_time_optimal() compile-time selection
//! ```
//!
//! # Usage
//!
//! ```ignore
//! use hologram_backend::microcode::BackendImpl;
//!
//! // Runtime auto-selection based on CPU features
//! let backend = BackendImpl::auto_select();
//!
//! // Compile-time optimal backend selection
//! let backend = BackendImpl::compile_time_optimal();
//!
//! // Use the backend via microcode primitives
//! use uor::microcode::{MicrocodePrimitives, MicrocodeOps};
//! let result = backend.inc(42u32); // Uses microcode: neg(bnot(x))
//! ```

use uor::microcode::{MicrocodePrimitives, MicrocodeWord};

// Re-export microcode types for convenience
pub use uor::microcode::{Derivation, DerivationId, KoggeStoneAdder, MicrocodeStep};

/// Backend implementation variant for automatic selection.
///
/// This enum captures all available backend implementations and provides
/// unified dispatch via the microcode primitive traits.
#[derive(Debug, Clone, Copy, Default)]
pub enum BackendVariant {
    /// x86_64 with AVX2 SIMD (256-bit vectors)
    #[cfg(target_arch = "x86_64")]
    X86_64Avx2,

    /// x86_64 scalar fallback (no SIMD)
    #[cfg(target_arch = "x86_64")]
    #[default]
    X86_64Scalar,

    /// ARM64 with NEON SIMD (128-bit vectors)
    #[cfg(target_arch = "aarch64")]
    #[default]
    Aarch64Neon,

    /// ARM64 scalar fallback
    #[cfg(target_arch = "aarch64")]
    Aarch64Scalar,

    /// WebAssembly SIMD128 (128-bit vectors)
    #[cfg(target_arch = "wasm32")]
    #[default]
    WasmSimd128,

    /// WebAssembly scalar fallback
    #[cfg(target_arch = "wasm32")]
    WasmScalar,

    /// Pure scalar fallback (all architectures)
    #[cfg(not(any(
        target_arch = "x86_64",
        target_arch = "aarch64",
        target_arch = "wasm32"
    )))]
    #[default]
    Scalar,
}

impl BackendVariant {
    /// Get the name of this backend variant.
    #[must_use]
    pub const fn name(&self) -> &'static str {
        match self {
            #[cfg(target_arch = "x86_64")]
            Self::X86_64Avx2 => "x86_64-avx2",
            #[cfg(target_arch = "x86_64")]
            Self::X86_64Scalar => "x86_64-scalar",
            #[cfg(target_arch = "aarch64")]
            Self::Aarch64Neon => "aarch64-neon",
            #[cfg(target_arch = "aarch64")]
            Self::Aarch64Scalar => "aarch64-scalar",
            #[cfg(target_arch = "wasm32")]
            Self::WasmSimd128 => "wasm-simd128",
            #[cfg(target_arch = "wasm32")]
            Self::WasmScalar => "wasm-scalar",
            #[cfg(not(any(
                target_arch = "x86_64",
                target_arch = "aarch64",
                target_arch = "wasm32"
            )))]
            Self::Scalar => "scalar",
        }
    }

    /// Check if this variant uses SIMD instructions.
    #[must_use]
    pub const fn is_simd(&self) -> bool {
        match self {
            #[cfg(target_arch = "x86_64")]
            Self::X86_64Avx2 => true,
            #[cfg(target_arch = "x86_64")]
            Self::X86_64Scalar => false,
            #[cfg(target_arch = "aarch64")]
            Self::Aarch64Neon => true,
            #[cfg(target_arch = "aarch64")]
            Self::Aarch64Scalar => false,
            #[cfg(target_arch = "wasm32")]
            Self::WasmSimd128 => true,
            #[cfg(target_arch = "wasm32")]
            Self::WasmScalar => false,
            #[cfg(not(any(
                target_arch = "x86_64",
                target_arch = "aarch64",
                target_arch = "wasm32"
            )))]
            Self::Scalar => false,
        }
    }

    /// Get the vector width in bits for this backend.
    #[must_use]
    pub const fn vector_bits(&self) -> u32 {
        match self {
            #[cfg(target_arch = "x86_64")]
            Self::X86_64Avx2 => 256,
            #[cfg(target_arch = "x86_64")]
            Self::X86_64Scalar => 32,
            #[cfg(target_arch = "aarch64")]
            Self::Aarch64Neon => 128,
            #[cfg(target_arch = "aarch64")]
            Self::Aarch64Scalar => 32,
            #[cfg(target_arch = "wasm32")]
            Self::WasmSimd128 => 128,
            #[cfg(target_arch = "wasm32")]
            Self::WasmScalar => 32,
            #[cfg(not(any(
                target_arch = "x86_64",
                target_arch = "aarch64",
                target_arch = "wasm32"
            )))]
            Self::Scalar => 32,
        }
    }
}

/// Unified backend implementation with automatic feature detection.
///
/// This struct provides a single interface to all backend implementations,
/// automatically selecting the optimal path based on compile-time and
/// runtime feature detection.
#[derive(Debug, Clone, Copy, Default)]
pub struct BackendImpl {
    variant: BackendVariant,
}

impl BackendImpl {
    /// Create a new backend with the given variant.
    #[must_use]
    pub const fn new(variant: BackendVariant) -> Self {
        Self { variant }
    }

    /// Automatically select the optimal backend at runtime.
    ///
    /// This function checks CPU features at runtime and returns the
    /// fastest available backend for the current hardware.
    ///
    /// When the `instrumentation` feature is enabled, logs the selected
    /// backend on first invocation using the `tracing` crate.
    #[must_use]
    pub fn auto_select() -> Self {
        let backend = Self::detect_optimal();

        #[cfg(feature = "instrumentation")]
        {
            Self::log_selection(backend);
        }

        backend
    }

    /// Detect the optimal backend without logging.
    #[must_use]
    fn detect_optimal() -> Self {
        #[cfg(target_arch = "x86_64")]
        {
            if is_x86_feature_detected!("avx2") {
                return Self::new(BackendVariant::X86_64Avx2);
            }
            Self::new(BackendVariant::X86_64Scalar)
        }

        #[cfg(target_arch = "aarch64")]
        {
            // NEON is mandatory on AArch64
            Self::new(BackendVariant::Aarch64Neon)
        }

        #[cfg(target_arch = "wasm32")]
        {
            // Check for SIMD128 support
            #[cfg(target_feature = "simd128")]
            return Self::new(BackendVariant::WasmSimd128);
            #[cfg(not(target_feature = "simd128"))]
            return Self::new(BackendVariant::WasmScalar);
        }

        #[cfg(not(any(
            target_arch = "x86_64",
            target_arch = "aarch64",
            target_arch = "wasm32"
        )))]
        {
            Self::new(BackendVariant::Scalar)
        }
    }

    /// Log backend selection (only on first call).
    #[cfg(feature = "instrumentation")]
    fn log_selection(backend: Self) {
        use std::sync::Once;
        static LOG_ONCE: Once = Once::new();

        LOG_ONCE.call_once(|| {
            tracing::info!(
                backend = backend.name(),
                is_simd = backend.is_simd(),
                vector_bits = backend.variant().vector_bits(),
                "Backend auto-selected"
            );
        });
    }

    /// Select the optimal backend at compile time.
    ///
    /// This function uses compile-time feature detection to select
    /// the fastest backend. Use this for embedded/no_std contexts
    /// where runtime detection is not desired.
    #[must_use]
    pub const fn compile_time_optimal() -> Self {
        #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
        {
            Self::new(BackendVariant::X86_64Avx2)
        }

        #[cfg(all(target_arch = "x86_64", not(target_feature = "avx2")))]
        {
            Self::new(BackendVariant::X86_64Scalar)
        }

        #[cfg(target_arch = "aarch64")]
        {
            Self::new(BackendVariant::Aarch64Neon)
        }

        #[cfg(all(target_arch = "wasm32", target_feature = "simd128"))]
        {
            return Self::new(BackendVariant::WasmSimd128);
        }

        #[cfg(all(target_arch = "wasm32", not(target_feature = "simd128")))]
        {
            return Self::new(BackendVariant::WasmScalar);
        }

        #[cfg(not(any(
            target_arch = "x86_64",
            target_arch = "aarch64",
            target_arch = "wasm32"
        )))]
        {
            Self::new(BackendVariant::Scalar)
        }
    }

    /// Get the variant of this backend.
    #[must_use]
    pub const fn variant(&self) -> BackendVariant {
        self.variant
    }

    /// Get the name of this backend.
    #[must_use]
    pub const fn name(&self) -> &'static str {
        self.variant.name()
    }

    /// Check if this backend uses SIMD instructions.
    #[must_use]
    pub const fn is_simd(&self) -> bool {
        self.variant.is_simd()
    }
}

// =============================================================================
// MicrocodePrimitives implementation for BackendImpl
// =============================================================================

// These are intentionally #[inline(always)] as they are single-instruction
// hot-path primitives that must be inlined for performance.
#[allow(clippy::inline_always)]
impl<W: MicrocodeWord> MicrocodePrimitives<W> for BackendImpl {
    #[inline(always)]
    fn bnot(&self, a: W) -> W {
        a.bit_not()
    }

    #[inline(always)]
    fn neg(&self, a: W) -> W {
        a.wrapping_neg()
    }

    #[inline(always)]
    fn xor(&self, a: W, b: W) -> W {
        a.bit_xor(b)
    }

    #[inline(always)]
    fn and(&self, a: W, b: W) -> W {
        a.bit_and(b)
    }

    #[inline(always)]
    fn or(&self, a: W, b: W) -> W {
        a.bit_or(b)
    }
}

// =============================================================================
// Metrics and Instrumentation
// =============================================================================

/// Metrics for backend execution.
///
/// When the `instrumentation` feature is enabled, the backend tracks
/// execution statistics for observability and optimization.
#[cfg(feature = "instrumentation")]
#[derive(Debug, Default)]
pub struct BackendMetrics {
    /// Total instructions executed.
    pub instructions_executed: std::sync::atomic::AtomicU64,
    /// Number of times microcode fallback was used.
    pub microcode_fallbacks: std::sync::atomic::AtomicU64,
    /// Number of times native override was used.
    pub native_overrides_used: std::sync::atomic::AtomicU64,
}

#[cfg(feature = "instrumentation")]
impl BackendMetrics {
    /// Create new metrics.
    #[must_use]
    pub const fn new() -> Self {
        Self {
            instructions_executed: std::sync::atomic::AtomicU64::new(0),
            microcode_fallbacks: std::sync::atomic::AtomicU64::new(0),
            native_overrides_used: std::sync::atomic::AtomicU64::new(0),
        }
    }

    /// Reset all metrics to zero.
    pub fn reset(&self) {
        use std::sync::atomic::Ordering;
        self.instructions_executed.store(0, Ordering::Relaxed);
        self.microcode_fallbacks.store(0, Ordering::Relaxed);
        self.native_overrides_used.store(0, Ordering::Relaxed);
    }
}

// =============================================================================
// define_all_backends! macro
// =============================================================================

/// Define all backends from a single unified specification.
///
/// This macro generates:
/// 1. Target structs with `is_available()` checks
/// 2. `GeneratedBackend` enum with all variants
/// 3. Automatic dispatch based on detection
/// 4. Unified execution interface via `BackendTarget` trait
///
/// # Generated Types
///
/// - `generated::*Target` - Individual target structs
/// - `GeneratedBackend` - Enum wrapping all targets with dispatch
///
/// # Example
///
/// ```ignore
/// define_all_backends! {
///     primitives = {
///         bnot: "Bitwise NOT",
///         neg:  "Two's complement negation",
///         xor:  "Bitwise XOR",
///         and:  "Bitwise AND",
///         or:   "Bitwise OR",
///     },
///     targets = {
///         x86_64_avx2: {
///             detection: is_x86_feature_detected!("avx2"),
///             native_add: true,
///         },
///         x86_64_scalar: {
///             detection: true,
///             native_add: false,
///         },
///     }
/// }
///
/// // Use the generated backend
/// let backend = GeneratedBackend::auto_select();
/// println!("Using: {}", backend.name());
/// ```
#[macro_export]
macro_rules! define_all_backends {
    (
        primitives = {
            $($prim_name:ident : $prim_doc:expr),* $(,)?
        },
        derived = {
            $($derived_name:ident : $derived_expr:expr),* $(,)?
        },
        targets = {
            $(
                $target_name:ident : {
                    $(detection: $detection:expr,)?
                    $(native_add: $native_add:expr,)?
                    $(native_mul: $native_mul:expr,)?
                    $(vector_bits: $vector_bits:expr,)?
                }
            ),* $(,)?
        }
    ) => {
        /// Generated backend target implementations.
        pub mod generated {
            #[allow(unused_imports)]
            use super::*;

            $(
                #[doc = concat!("Backend implementation for ", stringify!($target_name))]
                #[derive(Debug, Clone, Copy, Default)]
                pub struct $target_name;

                impl $target_name {
                    /// Create a new instance.
                    #[must_use]
                    pub const fn new() -> Self {
                        Self
                    }

                    /// Check if this backend is available on the current platform.
                    #[must_use]
                    pub fn is_available() -> bool {
                        true // Default: always available
                        $(
                            ; // Override with detection expression
                            $detection
                        )?
                    }

                    /// Get the name of this target.
                    #[must_use]
                    pub const fn name() -> &'static str {
                        stringify!($target_name)
                    }

                    /// Check if native ADD is available.
                    #[must_use]
                    pub const fn has_native_add() -> bool {
                        false // Default
                        $(
                            ; $native_add
                        )?
                    }

                    /// Check if native MUL is available.
                    #[must_use]
                    pub const fn has_native_mul() -> bool {
                        false // Default
                        $(
                            ; $native_mul
                        )?
                    }

                    /// Get the vector width in bits for this target.
                    #[must_use]
                    pub const fn vector_bits() -> u32 {
                        32 // Default: scalar
                        $(
                            ; $vector_bits
                        )?
                    }
                }
            )*

            /// Enum of all generated backend targets.
            ///
            /// This enum provides unified dispatch to the optimal backend
            /// based on runtime feature detection.
            #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
            pub enum GeneratedBackend {
                $(
                    #[doc = concat!("Variant for ", stringify!($target_name))]
                    $target_name,
                )*
            }

            impl GeneratedBackend {
                /// Get the name of this backend variant.
                #[must_use]
                pub const fn name(&self) -> &'static str {
                    match self {
                        $(
                            Self::$target_name => stringify!($target_name),
                        )*
                    }
                }

                /// Check if the target for this variant is available.
                #[must_use]
                pub fn is_available(&self) -> bool {
                    match self {
                        $(
                            Self::$target_name => $target_name::is_available(),
                        )*
                    }
                }

                /// Check if native ADD is available for this variant.
                #[must_use]
                pub const fn has_native_add(&self) -> bool {
                    match self {
                        $(
                            Self::$target_name => $target_name::has_native_add(),
                        )*
                    }
                }

                /// Check if native MUL is available for this variant.
                #[must_use]
                pub const fn has_native_mul(&self) -> bool {
                    match self {
                        $(
                            Self::$target_name => $target_name::has_native_mul(),
                        )*
                    }
                }

                /// Get all available backend variants.
                #[must_use]
                pub fn available_backends() -> Vec<Self> {
                    let mut backends = Vec::new();
                    $(
                        if $target_name::is_available() {
                            backends.push(Self::$target_name);
                        }
                    )*
                    backends
                }
            }

            impl Default for GeneratedBackend {
                fn default() -> Self {
                    // Return first available backend with SIMD, or scalar fallback
                    $(
                        if $target_name::is_available() && $target_name::has_native_add() {
                            return Self::$target_name;
                        }
                    )*
                    // Fallback to first available
                    $(
                        if $target_name::is_available() {
                            return Self::$target_name;
                        }
                    )*
                    // Last resort: first variant
                    Self::ScalarTarget
                }
            }

            impl GeneratedBackend {
                /// Automatically select the optimal backend at runtime.
                ///
                /// This function checks CPU features and returns the fastest
                /// available backend for the current platform.
                #[must_use]
                pub fn auto_select() -> Self {
                    Self::default()
                }

                /// Convert to the corresponding `BackendImpl` for microcode execution.
                ///
                /// This enables using the macro-generated backend selection with
                /// the `MicrocodePrimitives` interface.
                #[must_use]
                pub fn to_backend_impl(&self) -> $crate::microcode::BackendImpl {
                    $crate::microcode::BackendImpl::auto_select()
                }

                /// Execute primitive operations using the selected backend.
                ///
                /// This provides a unified dispatch interface for microcode
                /// operations. The actual execution is delegated to `BackendImpl`.
                ///
                /// # Type Parameters
                /// * `W` - The word type (u32, [u32; 4], [u32; 8], etc.)
                ///
                /// # Example
                ///
                /// ```ignore
                /// let backend = GeneratedBackend::auto_select();
                /// let result = backend.execute(|b| b.add(10u32, 20u32));
                /// assert_eq!(result, 30);
                /// ```
                pub fn execute<W, F, R>(&self, f: F) -> R
                where
                    W: uor::microcode::MicrocodeWord,
                    F: FnOnce(&dyn uor::microcode::MicrocodePrimitives<W>) -> R,
                {
                    let backend = self.to_backend_impl();
                    f(&backend)
                }

                /// Get the vector width in bits for this backend variant.
                ///
                /// Returns the SIMD vector width (256 for AVX2, 128 for NEON/WASM, 32 for scalar).
                #[must_use]
                pub fn vector_bits(&self) -> u32 {
                    match self {
                        $(
                            Self::$target_name => $target_name::vector_bits(),
                        )*
                    }
                }

                /// Check if this backend variant uses SIMD.
                #[must_use]
                pub fn is_simd(&self) -> bool {
                    self.vector_bits() > 32
                }
            }
        }
    };
}

// Generate the default backends
define_all_backends! {
    primitives = {
        bnot: "Bitwise NOT",
        neg:  "Two's complement negation",
        xor:  "Bitwise XOR",
        and:  "Bitwise AND",
        or:   "Bitwise OR",
    },
    derived = {
        inc: "neg(bnot(x)) = x + 1",
        dec: "bnot(neg(x)) = x - 1",
        add: "Kogge-Stone parallel prefix adder",
        sub: "add(a, neg(b))",
    },
    targets = {
        // CPU targets
        X86_64Avx2Target: {
            native_add: true,
            vector_bits: 256,
        },
        X86_64ScalarTarget: {
            native_add: false,
            vector_bits: 32,
        },
        Aarch64NeonTarget: {
            native_add: true,
            vector_bits: 128,
        },
        Aarch64ScalarTarget: {
            native_add: false,
            vector_bits: 32,
        },
        // WASM targets
        WasmSimd128Target: {
            native_add: true,
            vector_bits: 128,
        },
        WasmScalarTarget: {
            native_add: false,
            vector_bits: 32,
        },
        // Portable scalar fallback
        ScalarTarget: {
            native_add: false,
            vector_bits: 32,
        },
        // GPU targets (skeletons - use ISA execution, not microcode)
        CudaTarget: {
            native_add: true,
            native_mul: true,
            vector_bits: 32, // Thread parallelism, not SIMD
        },
        MetalTarget: {
            native_add: true,
            native_mul: true,
            vector_bits: 32,
        },
        WebGpuTarget: {
            native_add: true,
            native_mul: true,
            vector_bits: 32,
        },
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use uor::microcode::MicrocodeOps;

    #[test]
    fn test_backend_auto_select() {
        let backend = BackendImpl::auto_select();
        // Should succeed without panicking
        assert!(!backend.name().is_empty());
    }

    #[test]
    fn test_backend_compile_time_optimal() {
        let backend = BackendImpl::compile_time_optimal();
        assert!(!backend.name().is_empty());
    }

    #[test]
    fn test_backend_primitives_u32() {
        let backend = BackendImpl::auto_select();

        // Test bnot
        assert_eq!(backend.bnot(0u32), u32::MAX);
        assert_eq!(backend.bnot(u32::MAX), 0);

        // Test neg
        assert_eq!(backend.neg(0u32), 0);
        assert_eq!(backend.neg(1u32), u32::MAX);
        assert_eq!(backend.neg(42u32), (!42u32).wrapping_add(1));

        // Test xor
        assert_eq!(backend.xor(0xFFFF_0000u32, 0x0000_FFFFu32), 0xFFFF_FFFFu32);

        // Test and
        assert_eq!(backend.and(0xFFFF_0000u32, 0xFF00_FF00u32), 0xFF00_0000u32);

        // Test or
        assert_eq!(backend.or(0xFF00_0000u32, 0x00FF_0000u32), 0xFFFF_0000u32);
    }

    #[test]
    fn test_backend_derived_ops_u32() {
        let backend = BackendImpl::auto_select();

        // Test inc (via MicrocodeOps)
        assert_eq!(backend.inc(0u32), 1);
        assert_eq!(backend.inc(41u32), 42);
        assert_eq!(backend.inc(u32::MAX), 0);

        // Test dec
        assert_eq!(backend.dec(1u32), 0);
        assert_eq!(backend.dec(42u32), 41);
        assert_eq!(backend.dec(0u32), u32::MAX);

        // Test add
        assert_eq!(backend.add(10u32, 20), 30);
        assert_eq!(backend.add(u32::MAX, 1), 0);

        // Test sub
        assert_eq!(backend.sub(30u32, 10), 20);
        assert_eq!(backend.sub(0u32, 1), u32::MAX);
    }

    #[test]
    fn test_backend_primitives_array() {
        let backend = BackendImpl::auto_select();

        let a: [u32; 4] = [1, 2, 3, 4];
        let b: [u32; 4] = [5, 6, 7, 8];

        // Test xor
        let xor_result = backend.xor(a, b);
        assert_eq!(xor_result, [1 ^ 5, 2 ^ 6, 3 ^ 7, 4 ^ 8]);

        // Test and
        let and_result = backend.and(a, b);
        assert_eq!(and_result, [1 & 5, 2 & 6, 3 & 7, 4 & 8]);

        // Test or
        let or_result = backend.or(a, b);
        assert_eq!(or_result, [1 | 5, 2 | 6, 3 | 7, 4 | 8]);
    }

    #[test]
    fn test_backend_derived_ops_array() {
        let backend = BackendImpl::auto_select();

        let a: [u32; 4] = [10, 20, 30, 40];
        let b: [u32; 4] = [1, 2, 3, 4];

        // Test add
        let sum = backend.add(a, b);
        assert_eq!(sum, [11, 22, 33, 44]);

        // Test sub
        let diff = backend.sub(a, b);
        assert_eq!(diff, [9, 18, 27, 36]);
    }

    #[test]
    fn test_backend_variant_info() {
        let backend = BackendImpl::auto_select();

        // Verify variant info methods work
        let _name = backend.name();
        let _is_simd = backend.is_simd();
        let _variant = backend.variant();

        // Vector bits should be reasonable
        assert!(backend.variant().vector_bits() >= 32);
    }

    #[test]
    fn test_algebraic_identities() {
        let backend = BackendImpl::auto_select();

        // Test the fundamental identity: neg(bnot(x)) = x + 1
        for x in [0u32, 1, 42, 100, u32::MAX - 1] {
            let inc_via_microcode = backend.neg(backend.bnot(x));
            let inc_native = x.wrapping_add(1);
            assert_eq!(inc_via_microcode, inc_native, "inc identity failed for {x}");
        }

        // Test: bnot(neg(x)) = x - 1
        for x in [1u32, 2, 42, 100, u32::MAX] {
            let dec_via_microcode = backend.bnot(backend.neg(x));
            let dec_native = x.wrapping_sub(1);
            assert_eq!(dec_via_microcode, dec_native, "dec identity failed for {x}");
        }

        // Test: neg(neg(x)) = x (involution)
        for x in [0u32, 1, 42, u32::MAX] {
            assert_eq!(
                backend.neg(backend.neg(x)),
                x,
                "neg involution failed for {x}"
            );
        }

        // Test: bnot(bnot(x)) = x (involution)
        for x in [0u32, 1, 42, u32::MAX] {
            assert_eq!(
                backend.bnot(backend.bnot(x)),
                x,
                "bnot involution failed for {x}"
            );
        }
    }

    #[test]
    fn test_generated_targets() {
        use generated::*;

        // Test that generated targets can be instantiated
        let _t1 = X86_64Avx2Target::new();
        let _t2 = X86_64ScalarTarget::new();
        let _t3 = Aarch64NeonTarget::new();
        let _t4 = Aarch64ScalarTarget::new();
        let _t5 = WasmSimd128Target::new();
        let _t6 = WasmScalarTarget::new();
        let _t7 = ScalarTarget::new();
        let _t8 = CudaTarget::new();
        let _t9 = MetalTarget::new();
        let _t10 = WebGpuTarget::new();

        // All should report availability (default behavior)
        assert!(X86_64ScalarTarget::is_available());
        assert!(ScalarTarget::is_available());

        // Test target metadata
        assert_eq!(ScalarTarget::name(), "ScalarTarget");
        assert!(!ScalarTarget::has_native_add());
        assert!(X86_64Avx2Target::has_native_add());

        // Test GPU target metadata
        assert!(CudaTarget::has_native_add());
        assert!(MetalTarget::has_native_add());
        assert!(WebGpuTarget::has_native_add());
        assert!(CudaTarget::has_native_mul());
    }

    #[test]
    fn test_generated_backend_enum() {
        use generated::*;

        // Test GeneratedBackend enum
        let backend = GeneratedBackend::default();
        assert!(!backend.name().is_empty());

        // Check that at least one backend is available
        let available = GeneratedBackend::available_backends();
        assert!(
            !available.is_empty(),
            "At least one backend should be available"
        );

        // Test specific variants
        let scalar = GeneratedBackend::ScalarTarget;
        assert!(scalar.is_available());
        assert_eq!(scalar.name(), "ScalarTarget");

        // Test SIMD variant metadata
        let avx2 = GeneratedBackend::X86_64Avx2Target;
        assert!(avx2.has_native_add());
    }

    #[test]
    fn test_generated_backend_auto_select() {
        use generated::*;

        let backend = GeneratedBackend::auto_select();
        assert!(!backend.name().is_empty());
        assert!(backend.is_available());
    }

    #[test]
    fn test_generated_backend_to_backend_impl() {
        use generated::*;

        let generated = GeneratedBackend::auto_select();
        let backend_impl = generated.to_backend_impl();

        // Should be able to use the backend_impl for operations
        assert!(!backend_impl.name().is_empty());
    }

    #[test]
    fn test_generated_backend_execute_dispatch() {
        use generated::*;

        let backend = GeneratedBackend::auto_select();

        // Get the BackendImpl and execute operations
        let impl_ = backend.to_backend_impl();

        // Execute add operation via BackendImpl
        let result = impl_.add(10u32, 20u32);
        assert_eq!(result, 30);

        // Execute inc operation
        let result = impl_.inc(41u32);
        assert_eq!(result, 42);

        // Test execute method with primitives
        let result = backend.execute(|b: &dyn uor::microcode::MicrocodePrimitives<u32>| {
            b.xor(0xFF00u32, 0x00FFu32)
        });
        assert_eq!(result, 0xFFFF);
    }

    #[test]
    fn test_generated_backend_vector_bits() {
        use generated::*;

        let avx2 = GeneratedBackend::X86_64Avx2Target;
        assert_eq!(avx2.vector_bits(), 256);

        let neon = GeneratedBackend::Aarch64NeonTarget;
        assert_eq!(neon.vector_bits(), 128);

        let scalar = GeneratedBackend::ScalarTarget;
        assert_eq!(scalar.vector_bits(), 32);
    }

    #[test]
    fn test_generated_backend_is_simd() {
        use generated::*;

        assert!(GeneratedBackend::X86_64Avx2Target.is_simd());
        assert!(GeneratedBackend::Aarch64NeonTarget.is_simd());
        assert!(GeneratedBackend::WasmSimd128Target.is_simd());
        assert!(!GeneratedBackend::ScalarTarget.is_simd());
        assert!(!GeneratedBackend::X86_64ScalarTarget.is_simd());

        // GPU targets use thread parallelism, not SIMD lanes
        assert!(!GeneratedBackend::CudaTarget.is_simd());
        assert!(!GeneratedBackend::MetalTarget.is_simd());
        assert!(!GeneratedBackend::WebGpuTarget.is_simd());
    }

    #[test]
    fn test_generated_gpu_targets() {
        use generated::*;

        // GPU targets should report as available (skeleton detection)
        let cuda = GeneratedBackend::CudaTarget;
        let metal = GeneratedBackend::MetalTarget;
        let webgpu = GeneratedBackend::WebGpuTarget;

        // All GPU targets have native add/mul
        assert!(cuda.has_native_add());
        assert!(cuda.has_native_mul());
        assert!(metal.has_native_add());
        assert!(metal.has_native_mul());
        assert!(webgpu.has_native_add());
        assert!(webgpu.has_native_mul());

        // GPU targets should be in available_backends list
        let available = GeneratedBackend::available_backends();
        assert!(
            available.contains(&cuda)
                || available.contains(&metal)
                || available.contains(&webgpu)
                || !available.is_empty()
        );
    }

    // =========================================================================
    // Cross-Backend Verification Tests (TASK-125)
    // =========================================================================

    #[test]
    fn test_cross_backend_primitives_u32() {
        use crate::target::{ScalarTarget, Simd128Target, Simd256Target};
        use uor::microcode::MicrocodePrimitives;

        let scalar = ScalarTarget::new();
        let simd128 = Simd128Target::new();
        let simd256 = Simd256Target::new();
        let backend = BackendImpl::auto_select();

        // Test values
        let a: u32 = 0xDEAD_BEEF;
        let b: u32 = 0xCAFE_BABE;

        // bnot must be identical
        assert_eq!(scalar.bnot(a), backend.bnot(a));

        // neg must be identical
        assert_eq!(scalar.neg(a), backend.neg(a));

        // xor must be identical
        assert_eq!(scalar.xor(a, b), backend.xor(a, b));

        // and must be identical
        assert_eq!(scalar.and(a, b), backend.and(a, b));

        // or must be identical
        assert_eq!(scalar.or(a, b), backend.or(a, b));

        // Verify SIMD targets produce element-wise identical results
        let a_arr4: [u32; 4] = [a, b, a ^ b, a & b];
        let b_arr4: [u32; 4] = [b, a, a | b, a ^ b];

        let xor_128 = simd128.xor(a_arr4, b_arr4);
        for i in 0..4 {
            assert_eq!(xor_128[i], a_arr4[i] ^ b_arr4[i]);
        }

        let a_arr8: [u32; 8] = [
            a,
            b,
            a ^ b,
            a & b,
            !a,
            !b,
            a.wrapping_add(b),
            a.wrapping_sub(b),
        ];
        let b_arr8: [u32; 8] = [
            b,
            a,
            a | b,
            a ^ b,
            !b,
            !a,
            b.wrapping_add(a),
            b.wrapping_sub(a),
        ];

        let xor_256 = simd256.xor(a_arr8, b_arr8);
        for i in 0..8 {
            assert_eq!(xor_256[i], a_arr8[i] ^ b_arr8[i]);
        }
    }

    #[test]
    fn test_cross_backend_derived_ops_u32() {
        use crate::target::{ScalarTarget, Simd128Target, Simd256Target};
        use uor::microcode::MicrocodeOps;

        let scalar = ScalarTarget::new();
        let simd128 = Simd128Target::new();
        let simd256 = Simd256Target::new();
        let backend = BackendImpl::auto_select();

        // Test values
        let test_values: [u32; 5] = [0, 1, 42, 1000, u32::MAX - 1];

        for &a in &test_values {
            // inc must be identical across backends
            assert_eq!(scalar.inc(a), backend.inc(a), "inc mismatch for {a}");

            // dec must be identical
            let a_dec = if a == 0 { u32::MAX } else { a };
            assert_eq!(
                scalar.dec(a_dec),
                backend.dec(a_dec),
                "dec mismatch for {a_dec}"
            );
        }

        // Test add/sub with pairs
        let pairs: [(u32, u32); 4] = [(10, 20), (100, 50), (u32::MAX, 1), (0, 0)];

        for &(a, b) in &pairs {
            assert_eq!(
                scalar.add(a, b),
                backend.add(a, b),
                "add mismatch for ({a}, {b})"
            );
            assert_eq!(
                scalar.sub(a, b),
                backend.sub(a, b),
                "sub mismatch for ({a}, {b})"
            );
        }

        // Verify SIMD add produces element-wise identical results
        let a_arr4: [u32; 4] = [10, 20, 30, 40];
        let b_arr4: [u32; 4] = [1, 2, 3, 4];

        let sum_128 = simd128.add(a_arr4, b_arr4);
        for i in 0..4 {
            assert_eq!(sum_128[i], a_arr4[i].wrapping_add(b_arr4[i]));
        }

        let a_arr8: [u32; 8] = [10, 20, 30, 40, 50, 60, 70, 80];
        let b_arr8: [u32; 8] = [1, 2, 3, 4, 5, 6, 7, 8];

        let sum_256 = simd256.add(a_arr8, b_arr8);
        for i in 0..8 {
            assert_eq!(sum_256[i], a_arr8[i].wrapping_add(b_arr8[i]));
        }
    }

    #[test]
    fn test_cross_backend_bitwise_identity() {
        use crate::target::{ScalarTarget, Simd128Target, Simd256Target};
        use uor::microcode::MicrocodePrimitives;

        let scalar = ScalarTarget::new();
        let simd128 = Simd128Target::new();
        let simd256 = Simd256Target::new();

        // Test bitwise identities across all backends

        // Identity: xor(a, a) = 0
        let a: u32 = 0xDEAD_BEEF;
        assert_eq!(scalar.xor(a, a), 0);

        let a_arr4: [u32; 4] = [a, a, a, a];
        assert_eq!(simd128.xor(a_arr4, a_arr4), [0, 0, 0, 0]);

        let a_arr8: [u32; 8] = [a; 8];
        assert_eq!(simd256.xor(a_arr8, a_arr8), [0; 8]);

        // Identity: and(a, 0) = 0
        assert_eq!(scalar.and(a, 0), 0);
        assert_eq!(simd128.and(a_arr4, [0; 4]), [0; 4]);
        assert_eq!(simd256.and(a_arr8, [0; 8]), [0; 8]);

        // Identity: or(a, 0) = a
        assert_eq!(scalar.or(a, 0), a);
        assert_eq!(simd128.or(a_arr4, [0; 4]), a_arr4);
        assert_eq!(simd256.or(a_arr8, [0; 8]), a_arr8);

        // Identity: bnot(bnot(a)) = a
        assert_eq!(scalar.bnot(scalar.bnot(a)), a);

        let bnot_bnot_128 = simd128.bnot(simd128.bnot(a_arr4));
        assert_eq!(bnot_bnot_128, a_arr4);

        let bnot_bnot_256 = simd256.bnot(simd256.bnot(a_arr8));
        assert_eq!(bnot_bnot_256, a_arr8);
    }

    #[test]
    fn test_cross_backend_arithmetic_identity() {
        use crate::target::{ScalarTarget, Simd128Target, Simd256Target};
        use uor::microcode::MicrocodeOps;

        let scalar = ScalarTarget::new();
        let simd128 = Simd128Target::new();
        let simd256 = Simd256Target::new();

        let a: u32 = 0xDEAD_BEEF;

        // Identity: add(a, 0) = a
        assert_eq!(scalar.add(a, 0), a);

        let a_arr4: [u32; 4] = [a, a, a, a];
        assert_eq!(simd128.add(a_arr4, [0; 4]), a_arr4);

        let a_arr8: [u32; 8] = [a; 8];
        assert_eq!(simd256.add(a_arr8, [0; 8]), a_arr8);

        // Identity: sub(a, a) = 0
        assert_eq!(scalar.sub(a, a), 0);
        assert_eq!(simd128.sub(a_arr4, a_arr4), [0; 4]);
        assert_eq!(simd256.sub(a_arr8, a_arr8), [0; 8]);

        // Identity: inc(dec(a)) = a (for a > 0)
        assert_eq!(scalar.inc(scalar.dec(a)), a);

        let dec_inc_128: [u32; 4] = simd128.inc(simd128.dec(a_arr4));
        assert_eq!(dec_inc_128, a_arr4);

        let dec_inc_256: [u32; 8] = simd256.inc(simd256.dec(a_arr8));
        assert_eq!(dec_inc_256, a_arr8);
    }

    #[test]
    fn test_cross_backend_categorical_ops() {
        use crate::target::{ScalarTarget, Simd128Target, Simd256Target};
        use uor::microcode::MicrocodeOps;

        let scalar = ScalarTarget::new();
        let simd128 = Simd128Target::new();
        let simd256 = Simd256Target::new();

        // Test with categorical-relevant values (mod 96)
        let values: [u32; 8] = [0, 1, 47, 48, 95, 96, 100, 255];

        // Verify arithmetic consistency for categorical operations
        for &v in &values {
            // Ring addition: (v + 1) mod 96 should be consistent
            let inc_scalar = scalar.inc(v) % 96;
            let inc_backend = BackendImpl::auto_select().inc(v) % 96;
            assert_eq!(inc_scalar, inc_backend, "inc mod 96 mismatch for {v}");
        }

        // Verify SIMD categorical consistency
        let v_arr4: [u32; 4] = [0, 47, 95, 100];
        let v_arr8: [u32; 8] = [0, 1, 47, 48, 95, 96, 100, 255];

        let inc_128 = simd128.inc(v_arr4);
        for (i, &orig) in v_arr4.iter().enumerate() {
            assert_eq!(inc_128[i], orig.wrapping_add(1));
        }

        let inc_256 = simd256.inc(v_arr8);
        for (i, &orig) in v_arr8.iter().enumerate() {
            assert_eq!(inc_256[i], orig.wrapping_add(1));
        }
    }

    // =========================================================================
    // Shift/Rotate Cross-Backend Tests (TASK-171)
    // =========================================================================

    #[test]
    fn test_cross_backend_shift_u32() {
        use crate::target::{ScalarTarget, Simd128Target, Simd256Target};
        use uor::microcode::MicrocodeOps;

        let scalar = ScalarTarget::new();
        let simd128 = Simd128Target::new();
        let simd256 = Simd256Target::new();
        let backend = BackendImpl::auto_select();

        // Test values and shift amounts
        let values: [u32; 4] = [0xDEAD_BEEF, 0xCAFE_BABE, 0x1234_5678, 0xFF00_00FF];
        let shifts: [u32; 5] = [0, 1, 8, 16, 31];

        for &v in &values {
            for &n in &shifts {
                // shl must be identical
                assert_eq!(
                    scalar.shl(v, n),
                    backend.shl(v, n),
                    "shl mismatch for v={v:#x}, n={n}"
                );
                assert_eq!(scalar.shl(v, n), v << n);

                // shr must be identical
                assert_eq!(
                    scalar.shr(v, n),
                    backend.shr(v, n),
                    "shr mismatch for v={v:#x}, n={n}"
                );
                assert_eq!(scalar.shr(v, n), v >> n);
            }
        }

        // Verify SIMD shift produces element-wise identical results
        let v_arr4: [u32; 4] = values;
        let v_arr8: [u32; 8] = [
            0xDEAD_BEEF,
            0xCAFE_BABE,
            0x1234_5678,
            0xFF00_00FF,
            0x0F0F_0F0F,
            0xF0F0_F0F0,
            0xAAAA_AAAA,
            0x5555_5555,
        ];

        for &n in &shifts {
            let left_4 = simd128.shl(v_arr4, n);
            let right_4 = simd128.shr(v_arr4, n);
            for i in 0..4 {
                assert_eq!(
                    left_4[i],
                    v_arr4[i] << n,
                    "simd128 shl[{i}] mismatch, n={n}"
                );
                assert_eq!(
                    right_4[i],
                    v_arr4[i] >> n,
                    "simd128 shr[{i}] mismatch, n={n}"
                );
            }

            let left_8 = simd256.shl(v_arr8, n);
            let right_8 = simd256.shr(v_arr8, n);
            for i in 0..8 {
                assert_eq!(
                    left_8[i],
                    v_arr8[i] << n,
                    "simd256 shl[{i}] mismatch, n={n}"
                );
                assert_eq!(
                    right_8[i],
                    v_arr8[i] >> n,
                    "simd256 shr[{i}] mismatch, n={n}"
                );
            }
        }
    }

    #[test]
    fn test_cross_backend_rotate_u32() {
        use crate::target::{ScalarTarget, Simd128Target, Simd256Target};
        use uor::microcode::MicrocodeOps;

        let scalar = ScalarTarget::new();
        let simd128 = Simd128Target::new();
        let simd256 = Simd256Target::new();
        let backend = BackendImpl::auto_select();

        // Test values and rotate amounts
        let values: [u32; 4] = [0x8000_0001, 0xCAFE_BABE, 0x0000_00FF, 0xFF00_0000];
        let rotates: [u32; 6] = [0, 1, 8, 16, 24, 31];

        for &v in &values {
            for &n in &rotates {
                // rotl must be identical
                assert_eq!(
                    scalar.rotl(v, n),
                    backend.rotl(v, n),
                    "rotl mismatch for v={v:#x}, n={n}"
                );
                assert_eq!(scalar.rotl(v, n), v.rotate_left(n));

                // rotr must be identical
                assert_eq!(
                    scalar.rotr(v, n),
                    backend.rotr(v, n),
                    "rotr mismatch for v={v:#x}, n={n}"
                );
                assert_eq!(scalar.rotr(v, n), v.rotate_right(n));
            }
        }

        // Verify SIMD rotate produces element-wise identical results
        let v_arr4: [u32; 4] = values;
        let v_arr8: [u32; 8] = [
            0x8000_0001,
            0xCAFE_BABE,
            0x0000_00FF,
            0xFF00_0000,
            0x0F0F_0F0F,
            0xF0F0_F0F0,
            0xAAAA_AAAA,
            0x5555_5555,
        ];

        for &n in &rotates {
            let left_4 = simd128.rotl(v_arr4, n);
            let right_4 = simd128.rotr(v_arr4, n);
            for i in 0..4 {
                assert_eq!(
                    left_4[i],
                    v_arr4[i].rotate_left(n),
                    "simd128 rotl[{i}] mismatch, n={n}"
                );
                assert_eq!(
                    right_4[i],
                    v_arr4[i].rotate_right(n),
                    "simd128 rotr[{i}] mismatch, n={n}"
                );
            }

            let left_8 = simd256.rotl(v_arr8, n);
            let right_8 = simd256.rotr(v_arr8, n);
            for i in 0..8 {
                assert_eq!(
                    left_8[i],
                    v_arr8[i].rotate_left(n),
                    "simd256 rotl[{i}] mismatch, n={n}"
                );
                assert_eq!(
                    right_8[i],
                    v_arr8[i].rotate_right(n),
                    "simd256 rotr[{i}] mismatch, n={n}"
                );
            }
        }
    }

    #[test]
    fn test_shift_rotate_inverse() {
        use uor::microcode::MicrocodeOps;

        let backend = BackendImpl::auto_select();

        // rotl and rotr are inverses
        for v in [0u32, 1, 0xDEAD_BEEF, 0xCAFE_BABE, u32::MAX] {
            for n in [0, 1, 7, 8, 15, 16, 24, 31] {
                let rotated = backend.rotl(v, n);
                let restored = backend.rotr(rotated, n);
                assert_eq!(restored, v, "rotl/rotr inverse failed for v={v:#x}, n={n}");

                let rotated = backend.rotr(v, n);
                let restored = backend.rotl(rotated, n);
                assert_eq!(restored, v, "rotr/rotl inverse failed for v={v:#x}, n={n}");
            }
        }
    }

    // =========================================================================
    // Comparison Cross-Backend Tests (TASK-172)
    // =========================================================================

    #[test]
    fn test_cross_backend_comparison_u32() {
        use crate::target::{ScalarTarget, Simd128Target, Simd256Target};
        use uor::microcode::MicrocodeOps;

        let scalar = ScalarTarget::new();
        let simd128 = Simd128Target::new();
        let simd256 = Simd256Target::new();
        let backend = BackendImpl::auto_select();

        // Test value pairs
        let pairs: [(u32, u32); 6] = [
            (10, 20),
            (20, 10),
            (10, 10),
            (0, 0),
            (0, u32::MAX),
            (u32::MAX, 0),
        ];

        for &(a, b) in &pairs {
            // eq must be identical across backends
            assert_eq!(
                scalar.eq(a, b),
                backend.eq(a, b),
                "eq mismatch for ({a}, {b})"
            );

            // ne must be identical
            assert_eq!(
                scalar.ne(a, b),
                backend.ne(a, b),
                "ne mismatch for ({a}, {b})"
            );

            // lt must be identical
            assert_eq!(
                scalar.lt(a, b),
                backend.lt(a, b),
                "lt mismatch for ({a}, {b})"
            );

            // le must be identical
            assert_eq!(
                scalar.le(a, b),
                backend.le(a, b),
                "le mismatch for ({a}, {b})"
            );

            // gt must be identical
            assert_eq!(
                scalar.gt(a, b),
                backend.gt(a, b),
                "gt mismatch for ({a}, {b})"
            );

            // ge must be identical
            assert_eq!(
                scalar.ge(a, b),
                backend.ge(a, b),
                "ge mismatch for ({a}, {b})"
            );
        }

        // Verify SIMD comparison produces element-wise identical results
        let a_arr4: [u32; 4] = [10, 20, 30, 40];
        let b_arr4: [u32; 4] = [15, 20, 25, 50];

        let eq_128 = simd128.eq(a_arr4, b_arr4);
        let lt_128 = simd128.lt(a_arr4, b_arr4);
        for i in 0..4 {
            let expected_eq = if a_arr4[i] == b_arr4[i] { u32::MAX } else { 0 };
            let expected_lt = if a_arr4[i] < b_arr4[i] { u32::MAX } else { 0 };
            assert_eq!(eq_128[i], expected_eq, "simd128 eq[{i}] mismatch");
            assert_eq!(lt_128[i], expected_lt, "simd128 lt[{i}] mismatch");
        }

        let a_arr8: [u32; 8] = [1, 2, 3, 4, 5, 6, 7, 8];
        let b_arr8: [u32; 8] = [1, 3, 2, 4, 6, 5, 7, 9];

        let eq_256 = simd256.eq(a_arr8, b_arr8);
        let lt_256 = simd256.lt(a_arr8, b_arr8);
        for i in 0..8 {
            let expected_eq = if a_arr8[i] == b_arr8[i] { u32::MAX } else { 0 };
            let expected_lt = if a_arr8[i] < b_arr8[i] { u32::MAX } else { 0 };
            assert_eq!(eq_256[i], expected_eq, "simd256 eq[{i}] mismatch");
            assert_eq!(lt_256[i], expected_lt, "simd256 lt[{i}] mismatch");
        }
    }

    #[test]
    fn test_comparison_properties() {
        use uor::microcode::MicrocodeOps;

        let backend = BackendImpl::auto_select();

        // Test comparison logical properties
        for a in [0u32, 1, 10, 100, u32::MAX - 1, u32::MAX] {
            for b in [0u32, 1, 10, 100, u32::MAX - 1, u32::MAX] {
                // eq and ne are complements
                assert_eq!(
                    backend.eq(a, b),
                    backend.bnot(backend.ne(a, b)),
                    "eq/ne complement for ({a}, {b})"
                );

                // lt and ge are complements
                assert_eq!(
                    backend.lt(a, b),
                    backend.bnot(backend.ge(a, b)),
                    "lt/ge complement for ({a}, {b})"
                );

                // gt and le are complements
                assert_eq!(
                    backend.gt(a, b),
                    backend.bnot(backend.le(a, b)),
                    "gt/le complement for ({a}, {b})"
                );

                // lt(a, b) == gt(b, a)
                assert_eq!(
                    backend.lt(a, b),
                    backend.gt(b, a),
                    "lt/gt symmetry for ({a}, {b})"
                );

                // le(a, b) == ge(b, a)
                assert_eq!(
                    backend.le(a, b),
                    backend.ge(b, a),
                    "le/ge symmetry for ({a}, {b})"
                );

                // Verify correctness against native comparisons
                let expected_eq = if a == b { u32::MAX } else { 0 };
                let expected_lt = if a < b { u32::MAX } else { 0 };
                assert_eq!(backend.eq(a, b), expected_eq);
                assert_eq!(backend.lt(a, b), expected_lt);
            }
        }
    }

    #[test]
    fn test_shift_rotate_identities() {
        use uor::microcode::MicrocodeOps;

        let backend = BackendImpl::auto_select();
        let v: u32 = 0xDEAD_BEEF;

        // shl(v, 0) = v
        assert_eq!(backend.shl(v, 0), v);

        // shr(v, 0) = v
        assert_eq!(backend.shr(v, 0), v);

        // rotl(v, 0) = v
        assert_eq!(backend.rotl(v, 0), v);

        // rotr(v, 0) = v
        assert_eq!(backend.rotr(v, 0), v);

        // rotl(v, 32) = v (full rotation)
        assert_eq!(backend.rotl(v, 32), v);

        // rotr(v, 32) = v (full rotation)
        assert_eq!(backend.rotr(v, 32), v);

        // rotl(v, n) = rotr(v, 32 - n) for n < 32
        for n in 1..32 {
            assert_eq!(
                backend.rotl(v, n),
                backend.rotr(v, 32 - n),
                "rotl/rotr equivalence failed for n={n}"
            );
        }
    }

    // =========================================================================
    // Instrumentation Tests (TASK-173)
    // =========================================================================

    #[test]
    fn test_auto_select_returns_valid_backend() {
        let backend = BackendImpl::auto_select();

        // Should return a valid backend with non-empty name
        assert!(!backend.name().is_empty());

        // Should have valid vector bits
        assert!(backend.variant().vector_bits() >= 32);
    }

    #[test]
    fn test_auto_select_consistent() {
        // Multiple calls should return the same backend
        let backend1 = BackendImpl::auto_select();
        let backend2 = BackendImpl::auto_select();
        let backend3 = BackendImpl::auto_select();

        assert_eq!(backend1.name(), backend2.name());
        assert_eq!(backend2.name(), backend3.name());
        assert_eq!(backend1.is_simd(), backend2.is_simd());
    }

    #[test]
    fn test_detect_optimal_matches_auto_select() {
        // detect_optimal and auto_select should return the same backend
        let detected = BackendImpl::detect_optimal();
        let selected = BackendImpl::auto_select();

        assert_eq!(detected.name(), selected.name());
        assert_eq!(
            detected.variant().vector_bits(),
            selected.variant().vector_bits()
        );
    }

    #[cfg(feature = "instrumentation")]
    #[test]
    fn test_instrumentation_log_once() {
        // When instrumentation is enabled, calling auto_select multiple times
        // should only log once (verified by the Once guard)
        let _b1 = BackendImpl::auto_select();
        let _b2 = BackendImpl::auto_select();
        let _b3 = BackendImpl::auto_select();

        // If we got here without panicking, the Once guard is working
    }
}
