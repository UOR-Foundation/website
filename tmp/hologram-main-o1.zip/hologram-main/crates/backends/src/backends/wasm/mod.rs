//! WebAssembly backend implementation.
//!
//! This module provides a WASM backend for executing ISA plans in browser
//! and edge environments. Unlike GPU backends which are skeletons, the WASM
//! backend is fully functional since Rust compiles directly to WASM.
//!
//! # Architecture
//!
//! The WASM backend:
//! - Executes ISA instructions using pure Rust (no SIMD)
//! - Uses WASM linear memory for buffer management
//! - Supports all ISA operations except CallLayer (which requires file I/O)
//!
//! # WASM Memory Model
//!
//! WebAssembly uses a linear memory model with specific constraints:
//!
//! - **Memory Pages**: WASM memory grows in 64KB pages
//! - **Initial Size**: Default initial memory is typically 16MB (256 pages)
//! - **Maximum Size**: Can be configured up to 4GB (65536 pages)
//! - **Single Address Space**: All allocations share one linear address space
//! - **No GC**: Memory must be manually managed (handled by Rust allocator)
//!
//! ## Memory Estimation
//!
//! Use [`WasmMemory::estimate_plan_memory`] to check if a plan fits within
//! available WASM memory before execution:
//!
//! ```rust,ignore
//! use hologram_backend::wasm::{WasmBackend, WasmMemory};
//!
//! let required = WasmMemory::estimate_plan_memory(&plan);
//! let available = WasmMemory::available_memory();
//!
//! if required > available {
//!     // Plan is too large for available memory
//!     return Err("Plan exceeds WASM memory limits");
//! }
//! ```
//!
//! ## Browser Considerations
//!
//! Different browsers have different WASM memory limits:
//! - Chrome: ~4GB (with Memory64 proposal)
//! - Firefox: ~4GB
//! - Safari: ~4GB (may be lower on iOS)
//! - Edge: ~4GB
//!
//! For maximum compatibility, keep plans under 1GB total memory.
//!
//! # Usage
//!
//! ```rust,ignore
//! use hologram_backend::{Backend, wasm::WasmBackend};
//!
//! let backend = WasmBackend::new();
//! backend.execute_plan(&plan, &[&input], &mut [&mut output])?;
//! ```
//!
//! # Limitations
//!
//! - No SIMD optimizations (WASM SIMD support varies by browser)
//! - Single-threaded (WASM threads are not universally supported)
//! - CallLayer requires external layer loading mechanism
//! - Maximum memory of ~4GB (WASM32 linear memory limit)

use hologram_holo::BackendPlan;

use super::dispatch_unified::{ExecuteOn, InstructionDispatcher};
use super::Backend;
use crate::backends::cpu::BufferManager;
use crate::types::{BackendCapabilities, BackendError, BackendType, Result};

// O(1) LUT-based operations from uor crate
use uor::lut::{
    abs_lut, byte_add, byte_mul, exp_lut, gelu_lut, log_lut, orbit_class_q0, relu_lut, sigmoid_lut,
    silu_lut, sqrt_lut, tanh_lut, torus_page_q0,
};

/// WASM backend for browser/edge execution.
///
/// Executes ISA plans using pure Rust compiled to WebAssembly.
/// All standard ISA operations are supported.
pub struct WasmBackend {
    capabilities: BackendCapabilities,
}

impl WasmBackend {
    /// Create a new WASM backend.
    #[must_use]
    pub fn new() -> Self {
        Self {
            capabilities: BackendCapabilities {
                backend_type: BackendType::Wasm,
                vector_width: 1,          // No SIMD by default
                l1_cache_size: 32 * 1024, // Typical browser cache
                l2_cache_size: 256 * 1024,
                has_fma: false,
                has_sha: false,
                has_aes: false,
            },
        }
    }

    /// Check if WASM execution is available.
    ///
    /// Always returns `true` since this code compiles to WASM.
    #[must_use]
    pub const fn is_available() -> bool {
        true
    }
}

impl Default for WasmBackend {
    fn default() -> Self {
        Self::new()
    }
}

impl Backend for WasmBackend {
    fn backend_type(&self) -> BackendType {
        BackendType::Wasm
    }

    fn execute_plan(
        &self,
        plan: &BackendPlan,
        inputs: &[&[u8]],
        outputs: &mut [&mut [u8]],
    ) -> Result<()> {
        // Create buffer manager (same as CPU backend)
        let mut buffers = BufferManager::new(&plan.buffers, inputs, &plan.constants)?;

        // Create WASM dispatcher without layer executor
        let mut dispatcher = WasmDispatcher::new(&mut buffers, None);

        // Execute instructions sequentially (no parallelism in WASM)
        for instruction in &plan.instructions {
            instruction.execute(&mut dispatcher)?;
        }

        // Extract outputs
        buffers.extract_outputs(outputs)?;

        Ok(())
    }

    fn execute_plan_with_layers(
        &self,
        plan: &BackendPlan,
        inputs: &[&[u8]],
        outputs: &mut [&mut [u8]],
        layer_executor: crate::backends::LayerExecutorFn<'_>,
    ) -> Result<()> {
        // Create buffer manager
        let mut buffers = BufferManager::new(&plan.buffers, inputs, &plan.constants)?;

        // Create WASM dispatcher with layer executor
        let mut dispatcher = WasmDispatcher::new(&mut buffers, Some(layer_executor));

        // Execute instructions sequentially with layer support
        for instruction in &plan.instructions {
            instruction.execute(&mut dispatcher)?;
        }

        // Extract outputs
        buffers.extract_outputs(outputs)?;

        Ok(())
    }

    fn capabilities(&self) -> &BackendCapabilities {
        &self.capabilities
    }
}

// ============================================================================
// WASM Memory Model Helpers
// ============================================================================

/// WASM memory page size (64KB).
pub const WASM_PAGE_SIZE: usize = 65536;

/// Default maximum WASM memory (1GB - conservative for browser compatibility).
pub const WASM_DEFAULT_MAX_MEMORY: usize = 1024 * 1024 * 1024;

/// WASM memory management utilities.
///
/// Provides helpers for estimating memory requirements and checking
/// against WASM linear memory constraints.
pub struct WasmMemory;

impl WasmMemory {
    /// Estimate total memory required to execute a plan.
    ///
    /// Includes buffers, constants, and workspace. Does not include
    /// instruction storage or execution overhead.
    ///
    /// # Arguments
    ///
    /// * `plan` - The backend plan to estimate
    ///
    /// # Returns
    ///
    /// Total estimated memory in bytes.
    #[must_use]
    pub fn estimate_plan_memory(plan: &BackendPlan) -> usize {
        let buffer_mem: usize = plan.buffers.iter().map(|b| b.size).sum();
        let constant_mem = plan.constants.len();
        let workspace_mem = plan.workspace_size;

        buffer_mem + constant_mem + workspace_mem
    }

    /// Calculate the number of WASM pages needed for a given byte count.
    ///
    /// Pages are 64KB each. Result is rounded up.
    #[must_use]
    pub fn pages_needed(bytes: usize) -> usize {
        bytes.div_ceil(WASM_PAGE_SIZE)
    }

    /// Check if a plan fits within a given memory limit.
    ///
    /// # Arguments
    ///
    /// * `plan` - The backend plan to check
    /// * `max_memory` - Maximum available memory in bytes
    ///
    /// # Returns
    ///
    /// `true` if the plan fits, `false` otherwise.
    #[must_use]
    pub fn plan_fits(plan: &BackendPlan, max_memory: usize) -> bool {
        Self::estimate_plan_memory(plan) <= max_memory
    }

    /// Check if a plan fits within the default WASM memory limit (1GB).
    ///
    /// Use this for conservative browser compatibility.
    #[must_use]
    pub fn plan_fits_default(plan: &BackendPlan) -> bool {
        Self::plan_fits(plan, WASM_DEFAULT_MAX_MEMORY)
    }

    /// Validate that all buffers in a plan have reasonable sizes for WASM.
    ///
    /// Returns an error if any single buffer exceeds half the default limit,
    /// which would make it difficult to execute operations.
    pub fn validate_buffer_sizes(plan: &BackendPlan) -> Result<()> {
        let max_single_buffer = WASM_DEFAULT_MAX_MEMORY / 2;

        for (idx, buffer) in plan.buffers.iter().enumerate() {
            if buffer.size > max_single_buffer {
                return Err(BackendError::Other(format!(
                    "Buffer {idx} size ({} bytes) exceeds WASM safe limit ({max_single_buffer} bytes)",
                    buffer.size
                )));
            }
        }

        Ok(())
    }
}

// ============================================================================
// WASM Dispatcher Implementation
// ============================================================================

/// WASM instruction dispatcher implementing the unified `InstructionDispatcher` trait.
///
/// Uses scalar implementations without SIMD optimizations. Optionally supports
/// layer execution for `CallLayer` instructions.
struct WasmDispatcher<'a, 'b> {
    buffers: &'a mut BufferManager,
    layer_executor: Option<crate::backends::LayerExecutorFn<'b>>,
}

impl<'a, 'b> WasmDispatcher<'a, 'b> {
    fn new(
        buffers: &'a mut BufferManager,
        layer_executor: Option<crate::backends::LayerExecutorFn<'b>>,
    ) -> Self {
        Self {
            buffers,
            layer_executor,
        }
    }
}

/// Forward a trait method to a free function, passing `self.buffers` as first arg.
macro_rules! wasm_forward {
    ($($method:ident($($arg:ident : $ty:ty),*) -> $target:ident);+ $(;)?) => {
        $(
            fn $method(&mut self, $($arg: $ty),*) -> Result<()> {
                $target(self.buffers, $($arg),*)
            }
        )+
    };
}

#[allow(clippy::many_single_char_names)]
impl InstructionDispatcher for WasmDispatcher<'_, '_> {
    wasm_forward!(
        // Arithmetic
        exec_add(dst: u32, a: u32, b: u32, count: usize) -> exec_add_scalar;
        exec_sub(dst: u32, a: u32, b: u32, count: usize) -> exec_sub_scalar;
        exec_mul(dst: u32, a: u32, b: u32, count: usize) -> exec_mul_scalar;
        exec_div(dst: u32, a: u32, b: u32, count: usize) -> exec_div_scalar;
        exec_pow(dst: u32, a: u32, b: u32, count: usize) -> exec_pow_scalar;
        exec_elem_min(dst: u32, a: u32, b: u32, count: usize) -> exec_elem_min_scalar;
        exec_elem_max(dst: u32, a: u32, b: u32, count: usize) -> exec_elem_max_scalar;
        // Unary
        exec_sqrt(dst: u32, src: u32, count: usize) -> exec_sqrt_scalar;
        exec_log(dst: u32, src: u32, count: usize) -> exec_log_scalar;
        exec_exp(dst: u32, src: u32, count: usize) -> exec_exp_scalar;
        exec_abs(dst: u32, src: u32, count: usize) -> exec_abs_scalar;
        // Comparison
        exec_greater(dst: u32, a: u32, b: u32, count: usize) -> exec_greater_scalar;
        exec_less(dst: u32, a: u32, b: u32, count: usize) -> exec_less_scalar;
        exec_less_or_equal(dst: u32, a: u32, b: u32, count: usize) -> exec_less_or_equal_scalar;
        exec_greater_or_equal(dst: u32, a: u32, b: u32, count: usize) -> exec_greater_or_equal_scalar;
        exec_where(dst: u32, cond: u32, x: u32, y: u32, count: usize) -> exec_where_scalar;
        // Activation
        exec_sigmoid(dst: u32, src: u32, count: usize) -> exec_sigmoid_scalar;
        exec_tanh(dst: u32, src: u32, count: usize) -> exec_tanh_scalar;
        exec_relu(dst: u32, src: u32, count: usize) -> exec_relu_scalar;
        exec_softmax(dst: u32, src: u32, outer_size: usize, axis_size: usize, inner_size: usize) -> exec_softmax_scalar;
        // Matrix
        exec_matmul(c: u32, a: u32, b: u32, m: usize, k: usize, n: usize) -> exec_matmul_scalar;
        exec_batch_matmul(c: u32, a: u32, b: u32, batch_count: usize, m: usize, k: usize, n: usize) -> exec_batch_matmul_scalar;
        // Reduction
        exec_sum(dst: u32, src: u32, count: usize) -> exec_sum_scalar;
        exec_max(dst: u32, src: u32, count: usize) -> exec_max_scalar;
        exec_min(dst: u32, src: u32, count: usize) -> exec_min_scalar;
        exec_reduce_mean(dst: u32, src: u32, outer_size: usize, axis_size: usize, inner_size: usize) -> exec_reduce_mean_scalar;
        // Categorical
        exec_lift(dst: u32, src: u32, count: usize) -> exec_lift_scalar;
        exec_orbit_classify(dst: u32, src: u32, count: usize) -> exec_orbit_classify_scalar;
        exec_ring_add(dst: u32, a: u32, b: u32, count: usize) -> exec_ring_add_scalar;
        exec_ring_mul(dst: u32, a: u32, b: u32, count: usize) -> exec_ring_mul_scalar;
        // LUT activations
        exec_sigmoid_lut(dst: u32, src: u32, count: usize) -> exec_sigmoid_lut;
        exec_tanh_lut(dst: u32, src: u32, count: usize) -> exec_tanh_lut;
        exec_exp_lut(dst: u32, src: u32, count: usize) -> exec_exp_lut;
        exec_log_lut(dst: u32, src: u32, count: usize) -> exec_log_lut;
        exec_relu_lut(dst: u32, src: u32, count: usize) -> exec_relu_lut;
        exec_sqrt_lut(dst: u32, src: u32, count: usize) -> exec_sqrt_lut;
        exec_abs_lut(dst: u32, src: u32, count: usize) -> exec_abs_lut;
        exec_gelu_lut(dst: u32, src: u32, count: usize) -> exec_gelu_lut;
        exec_silu_lut(dst: u32, src: u32, count: usize) -> exec_silu_lut;
        // Fused operations (TASK-327)
        exec_matmul_relu(c: u32, a: u32, b: u32, m: usize, k: usize, n: usize) -> exec_matmul_relu_scalar;
        exec_add_sigmoid(dst: u32, a: u32, b: u32, count: usize) -> exec_add_sigmoid_scalar;
    );

    fn exec_matmul_lut(
        &mut self,
        _c: u32,
        _a: u32,
        _indices: u32,
        _centroids: u32,
        _m: usize,
        _k: usize,
        _n: usize,
        _quant_bits: u8,
    ) -> Result<()> {
        Err(BackendError::UnsupportedInstruction(
            "MatMulLUT is not supported in WASM backend; use standard MatMul".into(),
        ))
    }

    fn exec_load(&mut self, _buffer: u32, _offset: usize, _size: usize) -> Result<()> {
        Ok(())
    }

    fn exec_store(&mut self, _buffer: u32, _offset: usize, _size: usize) -> Result<()> {
        Ok(())
    }

    fn exec_copy(&mut self, dst: u32, src: u32, size: usize) -> Result<()> {
        exec_copy(self.buffers, dst, src, size)
    }

    fn exec_call_layer(&mut self, layer_id: u64, inputs: &[u32], outputs: &[u32]) -> Result<()> {
        if let Some(ref mut executor) = self.layer_executor {
            exec_call_layer(self.buffers, layer_id, inputs, outputs, executor)
        } else {
            Err(BackendError::UnsupportedInstruction(
                "CallLayer requires layer executor (use execute_plan_with_layers)".into(),
            ))
        }
    }

    fn exec_encode(&mut self, dst: u32, src: u32, codec_id: u32, count: usize) -> Result<()> {
        exec_encode_scalar(self.buffers, dst, src, codec_id, count)
    }

    fn exec_decode(&mut self, dst: u32, src: u32, codec_id: u32, count: usize) -> Result<()> {
        exec_decode_scalar(self.buffers, dst, src, codec_id, count)
    }

    fn exec_reshape(&mut self, dst: u32, src: u32, count: usize) -> Result<()> {
        exec_reshape_scalar(self.buffers, dst, src, count)
    }

    fn exec_transpose(
        &mut self,
        dst: u32,
        src: u32,
        count: usize,
        ndim: u8,
        shape: &[usize; 8],
        perm: [u8; 8],
    ) -> Result<()> {
        exec_transpose_scalar(self.buffers, dst, src, count, ndim, shape, perm)
    }

    fn exec_gather(
        &mut self,
        dst: u32,
        data: u32,
        indices: u32,
        axis: u8,
        num_indices: usize,
        slice_size: usize,
        data_size: usize,
    ) -> Result<()> {
        exec_gather_scalar(
            self.buffers,
            dst,
            data,
            indices,
            axis,
            num_indices,
            slice_size,
            data_size,
        )
    }

    fn exec_concat(
        &mut self,
        dst: u32,
        srcs: &[u32; 8],
        num_srcs: u8,
        sizes: &[usize; 8],
    ) -> Result<()> {
        exec_concat_scalar(self.buffers, dst, srcs, num_srcs, sizes)
    }

    fn exec_unsqueeze(&mut self, dst: u32, src: u32, size: usize) -> Result<()> {
        exec_unsqueeze_scalar(self.buffers, dst, src, size)
    }

    fn exec_squeeze(&mut self, dst: u32, src: u32, size: usize) -> Result<()> {
        exec_squeeze_scalar(self.buffers, dst, src, size)
    }

    fn exec_slice(
        &mut self,
        dst: u32,
        src: u32,
        ndim: u8,
        src_shape: &[u32; 4],
        dst_shape: &[u32; 4],
        starts: &[u32; 4],
        steps: &[i32; 4],
        elem_size: u8,
    ) -> Result<()> {
        exec_slice_scalar(
            self.buffers,
            dst,
            src,
            ndim,
            src_shape,
            dst_shape,
            starts,
            steps,
            elem_size,
        )
    }

    fn exec_pad(
        &mut self,
        dst: u32,
        src: u32,
        ndim: u8,
        src_shape: &[u32; 4],
        pad_before: &[u32; 4],
        pad_after: &[u32; 4],
        constant_value: f32,
        elem_size: u8,
    ) -> Result<()> {
        exec_pad_scalar(
            self.buffers,
            dst,
            src,
            ndim,
            src_shape,
            pad_before,
            pad_after,
            constant_value,
            elem_size,
        )
    }

    fn exec_cast(
        &mut self,
        dst: u32,
        src: u32,
        count: usize,
        src_dtype: u8,
        dst_dtype: u8,
    ) -> Result<()> {
        exec_cast_scalar(self.buffers, dst, src, count, src_dtype, dst_dtype)
    }

    fn exec_tile(
        &mut self,
        dst: u32,
        src: u32,
        ndim: u8,
        input_shape: &[usize; 8],
        multiples: &[usize; 8],
        count: usize,
    ) -> Result<()> {
        exec_tile_scalar(self.buffers, dst, src, ndim, input_shape, multiples, count)
    }

    fn exec_expand(
        &mut self,
        dst: u32,
        src: u32,
        ndim: u8,
        input_shape: &[usize; 8],
        target_shape: &[usize; 8],
        count: usize,
    ) -> Result<()> {
        exec_expand_scalar(
            self.buffers,
            dst,
            src,
            ndim,
            input_shape,
            target_shape,
            count,
        )
    }

    fn exec_conv2d(
        &mut self,
        dst: u32,
        input: u32,
        weight: u32,
        bias: Option<u32>,
        kernel_h: usize,
        kernel_w: usize,
        stride_h: usize,
        stride_w: usize,
        pad_h: usize,
        pad_w: usize,
        dilation_h: usize,
        dilation_w: usize,
        groups: usize,
        batch: usize,
        in_channels: usize,
        in_h: usize,
        in_w: usize,
        out_channels: usize,
        out_h: usize,
        out_w: usize,
    ) -> Result<()> {
        exec_conv2d_scalar(
            self.buffers,
            dst,
            input,
            weight,
            bias,
            kernel_h,
            kernel_w,
            stride_h,
            stride_w,
            pad_h,
            pad_w,
            dilation_h,
            dilation_w,
            groups,
            batch,
            in_channels,
            in_h,
            in_w,
            out_channels,
            out_h,
            out_w,
        )
    }

    fn exec_batch_norm(
        &mut self,
        dst: u32,
        input: u32,
        scale: u32,
        bias: u32,
        mean: u32,
        var: u32,
        epsilon: f32,
        batch: usize,
        channels: usize,
        spatial: usize,
    ) -> Result<()> {
        exec_batch_norm_scalar(
            self.buffers,
            dst,
            input,
            scale,
            bias,
            mean,
            var,
            epsilon,
            batch,
            channels,
            spatial,
        )
    }

    fn exec_layer_norm(
        &mut self,
        dst: u32,
        input: u32,
        scale: u32,
        bias: u32,
        epsilon: f32,
        num_instances: usize,
        normalized_count: usize,
    ) -> Result<()> {
        exec_layer_norm_scalar(
            self.buffers,
            dst,
            input,
            scale,
            bias,
            epsilon,
            num_instances,
            normalized_count,
        )
    }

    fn exec_max_pool2d(
        &mut self,
        dst: u32,
        src: u32,
        kernel_h: usize,
        kernel_w: usize,
        stride_h: usize,
        stride_w: usize,
        pad_h: usize,
        pad_w: usize,
        batch: usize,
        channels: usize,
        in_h: usize,
        in_w: usize,
        out_h: usize,
        out_w: usize,
    ) -> Result<()> {
        exec_max_pool2d_scalar(
            self.buffers,
            dst,
            src,
            kernel_h,
            kernel_w,
            stride_h,
            stride_w,
            pad_h,
            pad_w,
            batch,
            channels,
            in_h,
            in_w,
            out_h,
            out_w,
        )
    }

    fn exec_avg_pool2d(
        &mut self,
        dst: u32,
        src: u32,
        kernel_h: usize,
        kernel_w: usize,
        stride_h: usize,
        stride_w: usize,
        pad_h: usize,
        pad_w: usize,
        batch: usize,
        channels: usize,
        in_h: usize,
        in_w: usize,
        out_h: usize,
        out_w: usize,
    ) -> Result<()> {
        exec_avg_pool2d_scalar(
            self.buffers,
            dst,
            src,
            kernel_h,
            kernel_w,
            stride_h,
            stride_w,
            pad_h,
            pad_w,
            batch,
            channels,
            in_h,
            in_w,
            out_h,
            out_w,
        )
    }

    fn exec_global_avg_pool(
        &mut self,
        dst: u32,
        src: u32,
        batch: usize,
        channels: usize,
        spatial: usize,
    ) -> Result<()> {
        exec_global_avg_pool_scalar(self.buffers, dst, src, batch, channels, spatial)
    }

    fn exec_sha256(&mut self, dst: u32, src: u32, src_len: usize) -> Result<()> {
        let src_data = self.buffers.read(src)?;
        if src_data.len() < src_len {
            return Err(BackendError::SizeMismatch {
                expected: src_len,
                actual: src_data.len(),
            });
        }
        let hash = hologram_sha256::sha256(&src_data[..src_len]);
        self.buffers.write(dst, hash.as_ref())
    }

    fn exec_double_sha256(&mut self, dst: u32, src: u32, src_len: usize) -> Result<()> {
        let src_data = self.buffers.read(src)?;
        if src_data.len() < src_len {
            return Err(BackendError::SizeMismatch {
                expected: src_len,
                actual: src_data.len(),
            });
        }
        let hash = hologram_sha256::double_sha256(&src_data[..src_len]);
        self.buffers.write(dst, hash.as_ref())
    }

    fn exec_viterbi_tokenize(
        &mut self,
        _dst: u32,
        _dst_len: u32,
        _src: u32,
        _src_len: usize,
        _vocab_data: u32,
        _vocab_size: usize,
        _max_tokens: usize,
        _normalize_flags: u32,
        _unk_token_id: u32,
        _unk_score: f32,
    ) -> Result<()> {
        // WASM backend does not support tokenization
        Err(BackendError::UnsupportedInstruction(
            "ViterbiTokenize is not supported in WASM backend".into(),
        ))
    }
}

// ============================================================================
// WASM simd128 Element-Wise Kernels (TASK-326)
//
// When targeting `wasm32` with simd128 enabled, these use `v128`/`f32x4`
// intrinsics for 4x throughput on element-wise operations. Falls back to
// the scalar macros below when simd128 is not available.
// ============================================================================

#[cfg(target_arch = "wasm32")]
mod simd128 {
    use super::BufferManager;
    use crate::types::Result;

    #[cfg(target_arch = "wasm32")]
    use std::arch::wasm32::*;

    /// Number of f32 lanes per v128 register.
    const WASM_F32_LANES: usize = 4;

    /// simd128 binary operation on f32 buffers.
    macro_rules! wasm_simd_binary {
        ($name:ident, $op:ident) => {
            #[target_feature(enable = "simd128")]
            pub unsafe fn $name(
                buffers: &mut BufferManager,
                dst: u32,
                a: u32,
                b: u32,
                count: usize,
            ) -> Result<()> {
                let a_data = buffers.read_f32_slice(a, count)?;
                let b_data = buffers.read_f32_slice(b, count)?;
                let mut result = vec![0.0f32; count];

                let chunks = count / WASM_F32_LANES;
                let remainder = count % WASM_F32_LANES;

                for i in 0..chunks {
                    let offset = i * WASM_F32_LANES;
                    let va = v128_load(a_data.as_ptr().add(offset).cast());
                    let vb = v128_load(b_data.as_ptr().add(offset).cast());
                    let vr = $op(va, vb);
                    v128_store(result.as_mut_ptr().add(offset).cast(), vr);
                }

                let base = chunks * WASM_F32_LANES;
                for i in 0..remainder {
                    result[base + i] = a_data[base + i].$op(b_data[base + i]);
                }

                buffers.write_f32_slice(dst, &result)
            }
        };
    }

    /// simd128 element-wise add: dst[i] = a[i] + b[i]
    #[target_feature(enable = "simd128")]
    pub unsafe fn exec_add_simd128(
        buffers: &mut BufferManager,
        dst: u32,
        a: u32,
        b: u32,
        count: usize,
    ) -> Result<()> {
        let a_data = buffers.read_f32_slice(a, count)?;
        let b_data = buffers.read_f32_slice(b, count)?;
        let mut result = vec![0.0f32; count];

        let chunks = count / WASM_F32_LANES;
        let remainder = count % WASM_F32_LANES;

        for i in 0..chunks {
            let offset = i * WASM_F32_LANES;
            let va = v128_load(a_data.as_ptr().add(offset).cast());
            let vb = v128_load(b_data.as_ptr().add(offset).cast());
            v128_store(result.as_mut_ptr().add(offset).cast(), f32x4_add(va, vb));
        }

        let base = chunks * WASM_F32_LANES;
        for i in 0..remainder {
            result[base + i] = a_data[base + i] + b_data[base + i];
        }

        buffers.write_f32_slice(dst, &result)
    }

    /// simd128 element-wise sub: dst[i] = a[i] - b[i]
    #[target_feature(enable = "simd128")]
    pub unsafe fn exec_sub_simd128(
        buffers: &mut BufferManager,
        dst: u32,
        a: u32,
        b: u32,
        count: usize,
    ) -> Result<()> {
        let a_data = buffers.read_f32_slice(a, count)?;
        let b_data = buffers.read_f32_slice(b, count)?;
        let mut result = vec![0.0f32; count];

        let chunks = count / WASM_F32_LANES;
        let remainder = count % WASM_F32_LANES;

        for i in 0..chunks {
            let offset = i * WASM_F32_LANES;
            let va = v128_load(a_data.as_ptr().add(offset).cast());
            let vb = v128_load(b_data.as_ptr().add(offset).cast());
            v128_store(result.as_mut_ptr().add(offset).cast(), f32x4_sub(va, vb));
        }

        let base = chunks * WASM_F32_LANES;
        for i in 0..remainder {
            result[base + i] = a_data[base + i] - b_data[base + i];
        }

        buffers.write_f32_slice(dst, &result)
    }

    /// simd128 element-wise mul: dst[i] = a[i] * b[i]
    #[target_feature(enable = "simd128")]
    pub unsafe fn exec_mul_simd128(
        buffers: &mut BufferManager,
        dst: u32,
        a: u32,
        b: u32,
        count: usize,
    ) -> Result<()> {
        let a_data = buffers.read_f32_slice(a, count)?;
        let b_data = buffers.read_f32_slice(b, count)?;
        let mut result = vec![0.0f32; count];

        let chunks = count / WASM_F32_LANES;
        let remainder = count % WASM_F32_LANES;

        for i in 0..chunks {
            let offset = i * WASM_F32_LANES;
            let va = v128_load(a_data.as_ptr().add(offset).cast());
            let vb = v128_load(b_data.as_ptr().add(offset).cast());
            v128_store(result.as_mut_ptr().add(offset).cast(), f32x4_mul(va, vb));
        }

        let base = chunks * WASM_F32_LANES;
        for i in 0..remainder {
            result[base + i] = a_data[base + i] * b_data[base + i];
        }

        buffers.write_f32_slice(dst, &result)
    }

    /// simd128 ReLU: dst[i] = max(0, src[i])
    #[target_feature(enable = "simd128")]
    pub unsafe fn exec_relu_simd128(
        buffers: &mut BufferManager,
        dst: u32,
        src: u32,
        count: usize,
    ) -> Result<()> {
        let src_data = buffers.read_f32_slice(src, count)?;
        let mut result = vec![0.0f32; count];

        let chunks = count / WASM_F32_LANES;
        let remainder = count % WASM_F32_LANES;
        let zeros = f32x4_splat(0.0);

        for i in 0..chunks {
            let offset = i * WASM_F32_LANES;
            let v = v128_load(src_data.as_ptr().add(offset).cast());
            v128_store(result.as_mut_ptr().add(offset).cast(), f32x4_max(v, zeros));
        }

        let base = chunks * WASM_F32_LANES;
        for i in 0..remainder {
            result[base + i] = src_data[base + i].max(0.0);
        }

        buffers.write_f32_slice(dst, &result)
    }

    /// simd128 sigmoid: dst[i] = 1 / (1 + exp(-src[i]))
    ///
    /// Uses scalar fallback since exp() has no direct simd128 intrinsic.
    /// The loop structure is simd128-ready for when fast_exp approximation
    /// is ported to v128.
    pub fn exec_sigmoid_simd128(
        buffers: &mut BufferManager,
        dst: u32,
        src: u32,
        count: usize,
    ) -> Result<()> {
        let src_data = buffers.read_f32_slice(src, count)?;
        let result: Vec<f32> = src_data.iter().map(|&x| 1.0 / (1.0 + (-x).exp())).collect();
        buffers.write_f32_slice(dst, &result)
    }
}

/// Dispatch binary op to simd128 when available, scalar otherwise.
#[cfg(target_arch = "wasm32")]
macro_rules! wasm_dispatch_binary {
    ($buffers:expr, $dst:expr, $a:expr, $b:expr, $count:expr, $simd_fn:path, $scalar_fn:ident) => {{
        #[cfg(target_feature = "simd128")]
        {
            unsafe { $simd_fn($buffers, $dst, $a, $b, $count) }
        }
        #[cfg(not(target_feature = "simd128"))]
        {
            $scalar_fn($buffers, $dst, $a, $b, $count)
        }
    }};
}

/// Dispatch unary op to simd128 when available, scalar otherwise.
#[cfg(target_arch = "wasm32")]
macro_rules! wasm_dispatch_unary {
    ($buffers:expr, $dst:expr, $src:expr, $count:expr, $simd_fn:path, $scalar_fn:ident) => {{
        #[cfg(target_feature = "simd128")]
        {
            unsafe { $simd_fn($buffers, $dst, $src, $count) }
        }
        #[cfg(not(target_feature = "simd128"))]
        {
            $scalar_fn($buffers, $dst, $src, $count)
        }
    }};
}

// ============================================================================
// Scalar Arithmetic Operations
// ============================================================================

/// Binary f32 scalar kernel: read two inputs, zip-map with operator, write output.
macro_rules! wasm_binary_f32 {
    ($($fn_name:ident($op:expr)),+ $(,)?) => {
        $(
            fn $fn_name(
                buffers: &mut BufferManager,
                dst: u32,
                a: u32,
                b: u32,
                count: usize,
            ) -> Result<()> {
                let a_data = buffers.read_f32_slice(a, count)?;
                let b_data = buffers.read_f32_slice(b, count)?;
                let result: Vec<f32> = a_data
                    .iter()
                    .zip(b_data.iter())
                    .map(|(&x, &y)| ($op)(x, y))
                    .collect();
                buffers.write_f32_slice(dst, &result)
            }
        )+
    };
}

wasm_binary_f32!(
    exec_add_scalar(|x: f32, y: f32| x + y),
    exec_sub_scalar(|x: f32, y: f32| x - y),
    exec_mul_scalar(|x: f32, y: f32| x * y),
    exec_div_scalar(|x: f32, y: f32| x / y),
    exec_pow_scalar(|x: f32, y: f32| x.powf(y)),
    exec_elem_min_scalar(|x: f32, y: f32| x.min(y)),
    exec_elem_max_scalar(|x: f32, y: f32| x.max(y)),
);

// ============================================================================
// Scalar Activation Functions
// ============================================================================

/// Unary f32 scalar kernel: read input, map with function, write output.
macro_rules! wasm_unary_f32 {
    ($($fn_name:ident($op:expr)),+ $(,)?) => {
        $(
            fn $fn_name(
                buffers: &mut BufferManager,
                dst: u32,
                src: u32,
                count: usize,
            ) -> Result<()> {
                let src_data = buffers.read_f32_slice(src, count)?;
                let result: Vec<f32> = src_data.iter().map(|&x| ($op)(x)).collect();
                buffers.write_f32_slice(dst, &result)
            }
        )+
    };
}

wasm_unary_f32!(
    exec_sigmoid_scalar(|x: f32| 1.0 / (1.0 + (-x).exp())),
    exec_tanh_scalar(|x: f32| x.tanh()),
    exec_relu_scalar(|x: f32| x.max(0.0)),
);

fn exec_softmax_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    outer_size: usize,
    axis_size: usize,
    inner_size: usize,
) -> Result<()> {
    let count = outer_size * axis_size * inner_size;
    let src_data = buffers.read_f32_slice(src, count)?;
    let mut result = vec![0.0f32; count];

    // Use the SIMD implementation (works as scalar fallback)
    crate::backends::cpu::softmax_scalar(src_data, &mut result, outer_size, axis_size, inner_size);

    buffers.write_f32_slice(dst, &result)
}

// ============================================================================
// Scalar Transformer Operations (via wasm_unary_f32! / wasm_binary_f32! above)
// ============================================================================

wasm_unary_f32!(
    exec_sqrt_scalar(|x: f32| x.sqrt()),
    exec_log_scalar(|x: f32| x.ln()),
    exec_exp_scalar(|x: f32| x.exp()),
    exec_abs_scalar(|x: f32| x.abs()),
);

/// Comparison f32 scalar kernel: binary op returning 1.0/0.0.
macro_rules! wasm_comparison_f32 {
    ($($fn_name:ident($cmp:expr)),+ $(,)?) => {
        $(
            fn $fn_name(
                buffers: &mut BufferManager,
                dst: u32,
                a: u32,
                b: u32,
                count: usize,
            ) -> Result<()> {
                let a_data = buffers.read_f32_slice(a, count)?;
                let b_data = buffers.read_f32_slice(b, count)?;
                let result: Vec<f32> = a_data
                    .iter()
                    .zip(b_data.iter())
                    .map(|(&x, &y)| if ($cmp)(x, y) { 1.0 } else { 0.0 })
                    .collect();
                buffers.write_f32_slice(dst, &result)
            }
        )+
    };
}

wasm_comparison_f32!(
    exec_greater_scalar(|x: f32, y: f32| x > y),
    exec_less_scalar(|x: f32, y: f32| x < y),
    exec_less_or_equal_scalar(|x: f32, y: f32| x <= y),
    exec_greater_or_equal_scalar(|x: f32, y: f32| x >= y),
);

fn exec_where_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    cond: u32,
    x: u32,
    y: u32,
    count: usize,
) -> Result<()> {
    let cond_data = buffers.read_f32_slice(cond, count)?;
    let x_data = buffers.read_f32_slice(x, count)?;
    let y_data = buffers.read_f32_slice(y, count)?;
    let result: Vec<f32> = cond_data
        .iter()
        .zip(x_data.iter().zip(y_data.iter()))
        .map(|(&c, (&xv, &yv))| if c == 0.0 { yv } else { xv })
        .collect();
    buffers.write_f32_slice(dst, &result)
}

// ============================================================================
// Shape Operations
// ============================================================================

fn exec_tile_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    ndim: u8,
    input_shape: &[usize; 8],
    multiples: &[usize; 8],
    count: usize,
) -> Result<()> {
    let in_count: usize = input_shape[..ndim as usize].iter().product();
    let src_data = buffers.read_f32_slice(src, in_count)?;

    let mut result = vec![0.0f32; count];
    let in_shape = &input_shape[..ndim as usize];
    let mult = &multiples[..ndim as usize];

    // Use CPU scalar implementation
    crate::cpu::tile_scalar(src_data, &mut result, in_shape, mult);

    buffers.write_f32_slice(dst, &result)
}

fn exec_expand_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    ndim: u8,
    input_shape: &[usize; 8],
    target_shape: &[usize; 8],
    count: usize,
) -> Result<()> {
    let in_count: usize = input_shape[..ndim as usize].iter().product();
    let src_data = buffers.read_f32_slice(src, in_count)?;

    let mut result = vec![0.0f32; count];
    let in_shape = &input_shape[..ndim as usize];
    let tgt_shape = &target_shape[..ndim as usize];

    // Use CPU scalar implementation
    crate::cpu::expand_scalar(src_data, &mut result, in_shape, tgt_shape);

    buffers.write_f32_slice(dst, &result)
}

// ============================================================================
// Scalar Matrix Operations
// ============================================================================

#[allow(clippy::many_single_char_names)]
fn exec_matmul_scalar(
    buffers: &mut BufferManager,
    out_buf: u32,
    left_buf: u32,
    right_buf: u32,
    rows: usize,
    inner: usize,
    cols: usize,
) -> Result<()> {
    let left_data = buffers.read_f32_slice(left_buf, rows * inner)?;
    let right_data = buffers.read_f32_slice(right_buf, inner * cols)?;

    let mut result = vec![0.0f32; rows * cols];

    // Simple triple-loop matmul (no tiling for WASM simplicity)
    for row in 0..rows {
        for col in 0..cols {
            let mut sum = 0.0f32;
            for idx in 0..inner {
                sum += left_data[row * inner + idx] * right_data[idx * cols + col];
            }
            result[row * cols + col] = sum;
        }
    }

    buffers.write_f32_slice(out_buf, &result)
}

/// Batched matrix multiplication (scalar): C[b] = A[b] @ B[b] for each batch b.
fn exec_batch_matmul_scalar(
    buffers: &mut BufferManager,
    out_buf: u32,
    left_buf: u32,
    right_buf: u32,
    batch_count: usize,
    rows: usize,
    inner: usize,
    cols: usize,
) -> Result<()> {
    let a_matrix_size = rows * inner;
    let b_matrix_size = inner * cols;
    let c_matrix_size = rows * cols;

    let left_data = buffers.read_f32_slice(left_buf, batch_count * a_matrix_size)?;
    let right_data = buffers.read_f32_slice(right_buf, batch_count * b_matrix_size)?;

    let mut result = vec![0.0f32; batch_count * c_matrix_size];

    // Process each batch
    for batch_idx in 0..batch_count {
        let a_offset = batch_idx * a_matrix_size;
        let b_offset = batch_idx * b_matrix_size;
        let c_offset = batch_idx * c_matrix_size;

        // Simple triple-loop matmul for this batch
        for row in 0..rows {
            for col in 0..cols {
                let mut sum = 0.0f32;
                for idx in 0..inner {
                    sum += left_data[a_offset + row * inner + idx]
                        * right_data[b_offset + idx * cols + col];
                }
                result[c_offset + row * cols + col] = sum;
            }
        }
    }

    buffers.write_f32_slice(out_buf, &result)
}

/// Fused MatMul + ReLU (scalar): C = max(0, A @ B).
#[allow(clippy::many_single_char_names)]
fn exec_matmul_relu_scalar(
    buffers: &mut BufferManager,
    out_buf: u32,
    left_buf: u32,
    right_buf: u32,
    rows: usize,
    inner: usize,
    cols: usize,
) -> Result<()> {
    let left_data = buffers.read_f32_slice(left_buf, rows * inner)?;
    let right_data = buffers.read_f32_slice(right_buf, inner * cols)?;

    let mut result = vec![0.0f32; rows * cols];

    for row in 0..rows {
        for col in 0..cols {
            let mut sum = 0.0f32;
            for idx in 0..inner {
                sum += left_data[row * inner + idx] * right_data[idx * cols + col];
            }
            result[row * cols + col] = sum.max(0.0);
        }
    }

    buffers.write_f32_slice(out_buf, &result)
}

/// Fused Add + Sigmoid (scalar): dst[i] = sigmoid(a[i] + b[i]).
fn exec_add_sigmoid_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    a: u32,
    b: u32,
    count: usize,
) -> Result<()> {
    let a_data = buffers.read_f32_slice(a, count)?;
    let b_data = buffers.read_f32_slice(b, count)?;

    let result: Vec<f32> = a_data
        .iter()
        .zip(b_data.iter())
        .map(|(&x, &y)| {
            let s = x + y;
            1.0 / (1.0 + (-s).exp())
        })
        .collect();

    buffers.write_f32_slice(dst, &result)
}

// ============================================================================
// Scalar Reduction Operations
// ============================================================================

fn exec_sum_scalar(buffers: &mut BufferManager, dst: u32, src: u32, count: usize) -> Result<()> {
    let src_data = buffers.read_f32_slice(src, count)?;

    let sum: f32 = src_data.iter().sum();

    buffers.write_f32_slice(dst, &[sum])
}

fn exec_max_scalar(buffers: &mut BufferManager, dst: u32, src: u32, count: usize) -> Result<()> {
    let src_data = buffers.read_f32_slice(src, count)?;

    let max = src_data.iter().copied().fold(f32::NEG_INFINITY, f32::max);

    buffers.write_f32_slice(dst, &[max])
}

fn exec_min_scalar(buffers: &mut BufferManager, dst: u32, src: u32, count: usize) -> Result<()> {
    let src_data = buffers.read_f32_slice(src, count)?;

    let min = src_data.iter().copied().fold(f32::INFINITY, f32::min);

    buffers.write_f32_slice(dst, &[min])
}

#[allow(clippy::cast_precision_loss)]
fn exec_reduce_mean_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    outer_size: usize,
    axis_size: usize,
    inner_size: usize,
) -> Result<()> {
    let total_input = outer_size * axis_size * inner_size;
    let src_data = buffers.read_f32_slice(src, total_input)?;

    let total_output = outer_size * inner_size;
    let mut output = vec![0.0f32; total_output];

    let axis_size_f32 = axis_size as f32;

    for o in 0..outer_size {
        for i in 0..inner_size {
            let mut sum = 0.0f32;
            for j in 0..axis_size {
                let src_idx = o * axis_size * inner_size + j * inner_size + i;
                sum += src_data[src_idx];
            }
            let dst_idx = o * inner_size + i;
            output[dst_idx] = sum / axis_size_f32;
        }
    }

    buffers.write_f32_slice(dst, &output)
}

// ============================================================================
// Scalar Categorical Operations
// ============================================================================

fn exec_lift_scalar(buffers: &mut BufferManager, dst: u32, src: u32, count: usize) -> Result<()> {
    let src_data = buffers.read(src)?;

    // Output is 2 bytes per input byte (PackedCell format)
    let mut result = vec![0u8; count * 2];

    for (i, &byte) in src_data.iter().take(count).enumerate() {
        // O(1) LUT lookup for torus page
        let page = torus_page_q0(byte);
        // offset = byte (raw value for lookup)
        let offset = byte;

        // PackedCell: page in high byte, offset in low byte
        result[i * 2] = offset;
        result[i * 2 + 1] = page;
    }

    buffers.write(dst, &result)
}

fn exec_orbit_classify_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    let src_data = buffers.read(src)?;

    // O(1) LUT lookup for orbit class (0..31, B=32 orbit classes)
    let result: Vec<u8> = src_data
        .iter()
        .take(count)
        .map(|&b| orbit_class_q0(b))
        .collect();

    buffers.write(dst, &result)
}

fn exec_ring_add_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    a: u32,
    b: u32,
    count: usize,
) -> Result<()> {
    let a_data = buffers.read(a)?;
    let b_data = buffers.read(b)?;

    // O(1) LUT lookup for ring addition (handles full 0..255 range)
    let result: Vec<u8> = a_data
        .iter()
        .zip(b_data.iter())
        .take(count)
        .map(|(&x, &y)| byte_add(x, y))
        .collect();

    buffers.write(dst, &result)
}

fn exec_ring_mul_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    a: u32,
    b: u32,
    count: usize,
) -> Result<()> {
    let a_data = buffers.read(a)?;
    let b_data = buffers.read(b)?;

    // O(1) LUT lookup for ring multiplication (handles full 0..255 range)
    let result: Vec<u8> = a_data
        .iter()
        .zip(b_data.iter())
        .take(count)
        .map(|(&x, &y)| byte_mul(x, y))
        .collect();

    buffers.write(dst, &result)
}

/// O(1) LUT-based unary kernel for quantized u8 data.
macro_rules! wasm_lut_u8 {
    ($($fn_name:ident -> $lut_fn:ident),+ $(,)?) => {
        $(
            fn $fn_name(
                buffers: &mut BufferManager,
                dst: u32,
                src: u32,
                count: usize,
            ) -> Result<()> {
                let src_data = buffers.read(src)?;
                let result: Vec<u8> = src_data
                    .iter()
                    .take(count)
                    .map(|&v| $lut_fn(v))
                    .collect();
                buffers.write(dst, &result)
            }
        )+
    };
}

wasm_lut_u8!(
    exec_sigmoid_lut -> sigmoid_lut,
    exec_tanh_lut -> tanh_lut,
    exec_exp_lut -> exp_lut,
    exec_log_lut -> log_lut,
    exec_relu_lut -> relu_lut,
    exec_sqrt_lut -> sqrt_lut,
    exec_abs_lut -> abs_lut,
    exec_gelu_lut -> gelu_lut,
    exec_silu_lut -> silu_lut,
);

// ============================================================================
// Memory Operations
// ============================================================================

fn exec_copy(buffers: &mut BufferManager, dst: u32, src: u32, size: usize) -> Result<()> {
    let src_data = buffers.read(src)?;
    let data = src_data[..size].to_vec();
    buffers.write(dst, &data)
}

// ============================================================================
// Control Flow Operations
// ============================================================================

/// Execute a CallLayer instruction by delegating to the layer executor.
fn exec_call_layer(
    buffers: &mut BufferManager,
    layer_id: u64,
    input_indices: &[u32],
    output_indices: &[u32],
    executor: &mut crate::backends::LayerExecutorFn<'_>,
) -> Result<()> {
    // Gather input buffers
    let inputs: Vec<Vec<u8>> = input_indices
        .iter()
        .map(|&idx| buffers.read(idx).map(<[u8]>::to_vec))
        .collect::<Result<Vec<_>>>()?;
    let input_refs: Vec<&[u8]> = inputs.iter().map(Vec::as_slice).collect();

    // Prepare output buffers
    let mut outputs: Vec<Vec<u8>> = output_indices
        .iter()
        .map(|&idx| {
            buffers
                .read(idx)
                .map_or_else(|_| vec![0u8; 1024], |s| vec![0u8; s.len()])
        })
        .collect();
    let mut output_refs: Vec<&mut [u8]> = outputs.iter_mut().map(Vec::as_mut_slice).collect();

    // Execute the sub-layer
    executor(layer_id, &input_refs, &mut output_refs)?;

    // Write outputs back to buffers
    for (&idx, data) in output_indices.iter().zip(outputs.iter()) {
        buffers.write(idx, data)?;
    }

    Ok(())
}

// ============================================================================
// Codec Operations
// ============================================================================

fn exec_encode_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    codec_id: u32,
    count: usize,
) -> Result<()> {
    let codec = crate::codec::get_codec(codec_id).ok_or_else(|| {
        BackendError::UnsupportedInstruction(format!("unknown codec ID: {codec_id}"))
    })?;

    let src_data = buffers.read(src)?;
    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    let encoded = codec
        .encode(&src_data[..count])
        .map_err(|e| BackendError::ExecutionError(format!("codec encode failed: {e}")))?;

    buffers.write(dst, &encoded)
}

fn exec_decode_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    codec_id: u32,
    count: usize,
) -> Result<()> {
    let codec = crate::codec::get_codec(codec_id).ok_or_else(|| {
        BackendError::UnsupportedInstruction(format!("unknown codec ID: {codec_id}"))
    })?;

    let src_data = buffers.read(src)?;
    if src_data.len() < count {
        return Err(BackendError::SizeMismatch {
            expected: count,
            actual: src_data.len(),
        });
    }

    let decoded = codec
        .decode(&src_data[..count])
        .map_err(|e| BackendError::ExecutionError(format!("codec decode failed: {e}")))?;

    buffers.write(dst, &decoded)
}

// ============================================================================
// Shape Operations
// ============================================================================

fn exec_reshape_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    count: usize,
) -> Result<()> {
    // Reshape is just a copy - the shape change is metadata only
    let size = count * 4; // f32
    let src_data = buffers.read(src)?;
    if src_data.len() < size {
        return Err(BackendError::SizeMismatch {
            expected: size,
            actual: src_data.len(),
        });
    }
    let data = src_data[..size].to_vec();
    buffers.write(dst, &data)
}

#[allow(clippy::too_many_arguments)]
fn exec_transpose_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    count: usize,
    ndim: u8,
    shape: &[usize; 8],
    perm: [u8; 8],
) -> Result<()> {
    let src_data = buffers.read_f32_slice(src, count)?;
    let mut result = vec![0.0f32; count];

    let ndim = ndim as usize;
    let shape = &shape[..ndim];
    let perm: Vec<usize> = perm[..ndim].iter().map(|&p| p as usize).collect();

    // Compute strides for source
    let mut src_strides = vec![1usize; ndim];
    for i in (0..ndim.saturating_sub(1)).rev() {
        src_strides[i] = src_strides[i + 1] * shape[i + 1];
    }

    // Compute transposed shape and strides
    let transposed_shape: Vec<usize> = perm.iter().map(|&p| shape[p]).collect();
    let mut dst_strides = vec![1usize; ndim];
    for i in (0..ndim.saturating_sub(1)).rev() {
        dst_strides[i] = dst_strides[i + 1] * transposed_shape[i + 1];
    }

    // Perform transpose
    for (dst_idx, dest) in result.iter_mut().enumerate().take(count) {
        let mut coords = vec![0usize; ndim];
        let mut remaining = dst_idx;
        for i in 0..ndim {
            coords[i] = remaining / dst_strides[i];
            remaining %= dst_strides[i];
        }

        let mut src_coords = vec![0usize; ndim];
        for (i, &p) in perm.iter().enumerate() {
            src_coords[p] = coords[i];
        }

        let src_idx: usize = src_coords
            .iter()
            .zip(src_strides.iter())
            .map(|(&c, &s)| c * s)
            .sum();

        *dest = src_data[src_idx];
    }

    buffers.write_f32_slice(dst, &result)
}

#[allow(clippy::too_many_arguments)]
fn exec_gather_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    data: u32,
    indices: u32,
    _axis: u8,
    num_indices: usize,
    slice_size: usize,
    data_size: usize,
) -> Result<()> {
    let data_buf = buffers.read_f32_slice(data, data_size)?;
    let indices_buf = buffers.read(indices)?;

    let mut result = Vec::with_capacity(num_indices * slice_size);
    for idx_bytes in indices_buf.chunks(4).take(num_indices) {
        if idx_bytes.len() < 4 {
            break;
        }
        let i = u32::from_le_bytes(idx_bytes.try_into().unwrap()) as usize;
        let start = i * slice_size;
        let end = start + slice_size;
        if end <= data_buf.len() {
            result.extend_from_slice(&data_buf[start..end]);
        } else {
            result.extend(std::iter::repeat_n(0.0f32, slice_size));
        }
    }

    buffers.write_f32_slice(dst, &result)
}

fn exec_concat_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    srcs: &[u32; 8],
    num_srcs: u8,
    sizes: &[usize; 8],
) -> Result<()> {
    let mut result = Vec::new();

    for i in 0..num_srcs as usize {
        let src_data = buffers.read(srcs[i])?;
        let size = sizes[i];
        if src_data.len() >= size {
            result.extend_from_slice(&src_data[..size]);
        }
    }

    buffers.write(dst, &result)
}

fn exec_unsqueeze_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    size: usize,
) -> Result<()> {
    let src_data = buffers.read(src)?;
    if src_data.len() < size {
        return Err(BackendError::SizeMismatch {
            expected: size,
            actual: src_data.len(),
        });
    }
    let data = src_data[..size].to_vec();
    buffers.write(dst, &data)
}

fn exec_squeeze_scalar(buffers: &mut BufferManager, dst: u32, src: u32, size: usize) -> Result<()> {
    let src_data = buffers.read(src)?;
    if src_data.len() < size {
        return Err(BackendError::SizeMismatch {
            expected: size,
            actual: src_data.len(),
        });
    }
    let data = src_data[..size].to_vec();
    buffers.write(dst, &data)
}

#[allow(clippy::too_many_arguments, clippy::cast_sign_loss)]
fn exec_slice_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    ndim: u8,
    src_shape: &[u32; 4],
    dst_shape: &[u32; 4],
    starts: &[u32; 4],
    steps: &[i32; 4],
    elem_size: u8,
) -> Result<()> {
    let ndim = ndim as usize;
    let elem_size = elem_size as usize;

    // Compute destination element count from dst_shape
    let dst_count: usize = dst_shape[..ndim].iter().map(|&d| d as usize).product();

    let src_data = buffers.read(src)?;
    let mut result = vec![0u8; dst_count * elem_size];

    if ndim == 0 || dst_count == 0 {
        // Scalar case or empty: just return
        if ndim == 0 && elem_size <= src_data.len() && elem_size <= result.len() {
            result[..elem_size].copy_from_slice(&src_data[..elem_size]);
        }
        return buffers.write(dst, &result);
    }

    // Compute source strides (row-major order)
    let mut src_strides = [0usize; 4];
    let mut stride = 1usize;
    for i in (0..ndim).rev() {
        src_strides[i] = stride;
        stride *= src_shape[i] as usize;
    }

    // Compute destination strides (row-major order)
    let mut dst_strides = [0usize; 4];
    let mut dst_stride = 1usize;
    for i in (0..ndim).rev() {
        dst_strides[i] = dst_stride;
        dst_stride *= dst_shape[i] as usize;
    }

    // Copy elements one by one
    for dst_idx in 0..dst_count {
        // Decompose dst_idx into output coordinates
        let mut out_coords = [0usize; 4];
        let mut idx = dst_idx;
        for i in 0..ndim {
            out_coords[i] = idx / dst_strides[i];
            idx %= dst_strides[i];
        }

        // Map output coords to source coords using starts and steps
        let mut src_linear = 0;
        for i in 0..ndim {
            let step = steps[i];
            let src_coord = if step >= 0 {
                starts[i] as usize + out_coords[i] * (step as usize)
            } else {
                (starts[i] as usize).wrapping_sub(out_coords[i] * ((-step) as usize))
            };
            src_linear += src_coord * src_strides[i];
        }

        // Copy element
        let src_start = src_linear * elem_size;
        let dst_start = dst_idx * elem_size;
        if src_start + elem_size <= src_data.len() && dst_start + elem_size <= result.len() {
            result[dst_start..dst_start + elem_size]
                .copy_from_slice(&src_data[src_start..src_start + elem_size]);
        }
    }

    buffers.write(dst, &result)
}

/// Pad tensor with constant values (scalar implementation).
#[allow(clippy::too_many_arguments)]
fn exec_pad_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    ndim: u8,
    src_shape: &[u32; 4],
    pad_before: &[u32; 4],
    pad_after: &[u32; 4],
    constant_value: f32,
    elem_size: u8,
) -> Result<()> {
    let ndim = ndim as usize;
    let elem_size = elem_size as usize;

    // Compute destination shape
    let mut dst_shape = [0usize; 4];
    for i in 0..ndim {
        dst_shape[i] = src_shape[i] as usize + pad_before[i] as usize + pad_after[i] as usize;
    }

    // Compute destination element count
    let dst_count: usize = dst_shape[..ndim].iter().product();

    let src_data = buffers.read(src)?;
    let mut result = vec![0u8; dst_count * elem_size];

    // Fill with constant value
    let const_bytes = constant_value.to_ne_bytes();
    let copy_len = elem_size.min(4);
    for i in 0..dst_count {
        let start = i * elem_size;
        result[start..(start + copy_len)].copy_from_slice(&const_bytes[..copy_len]);
    }

    if ndim == 0 || dst_count == 0 {
        return buffers.write(dst, &result);
    }

    // Compute source strides (row-major order)
    let mut src_strides = [0usize; 4];
    let mut stride = 1usize;
    for i in (0..ndim).rev() {
        src_strides[i] = stride;
        stride *= src_shape[i] as usize;
    }

    // Compute destination strides (row-major order)
    let mut dst_strides = [0usize; 4];
    let mut dst_stride = 1usize;
    for i in (0..ndim).rev() {
        dst_strides[i] = dst_stride;
        dst_stride *= dst_shape[i];
    }

    // Copy source data into padded region
    let src_count: usize = (0..ndim).map(|i| src_shape[i] as usize).product();
    for src_idx in 0..src_count {
        // Decompose src_idx into source coordinates
        let mut src_coords = [0usize; 4];
        let mut idx = src_idx;
        for i in 0..ndim {
            src_coords[i] = idx / src_strides[i];
            idx %= src_strides[i];
        }

        // Map to destination coordinates (add padding offset)
        let mut dst_linear = 0;
        for i in 0..ndim {
            let dst_coord = src_coords[i] + pad_before[i] as usize;
            dst_linear += dst_coord * dst_strides[i];
        }

        // Copy element from source to destination
        let src_start = src_idx * elem_size;
        let dst_start = dst_linear * elem_size;
        if src_start + elem_size <= src_data.len() && dst_start + elem_size <= result.len() {
            result[dst_start..dst_start + elem_size]
                .copy_from_slice(&src_data[src_start..src_start + elem_size]);
        }
    }

    buffers.write(dst, &result)
}

fn exec_cast_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    count: usize,
    src_dtype: u8,
    dst_dtype: u8,
) -> Result<()> {
    // DType encoding: 0=F32, 1=F64, 2=I8, 3=I16, 4=I32, 5=I64, 6=U8, 7=U16, 8=U32, 9=U64, 10=Bool
    match (src_dtype, dst_dtype) {
        (0, 0) => {
            // F32 -> F32 (identity)
            let data = buffers.read_f32_slice(src, count)?.to_vec();
            buffers.write_f32_slice(dst, &data)
        }
        (0, 4) => {
            // F32 -> I32
            let data = buffers.read_f32_slice(src, count)?;
            #[allow(clippy::cast_possible_truncation)]
            let result: Vec<i32> = data.iter().map(|&f| f as i32).collect();
            let bytes: Vec<u8> = result.iter().flat_map(|&i| i.to_ne_bytes()).collect();
            buffers.write(dst, &bytes)
        }
        (4, 0) => {
            // I32 -> F32
            let src_data = buffers.read(src)?;
            #[allow(clippy::cast_precision_loss)]
            let result: Vec<f32> = src_data
                .chunks_exact(4)
                .take(count)
                .map(|chunk| {
                    let i = i32::from_ne_bytes(chunk.try_into().unwrap());
                    i as f32
                })
                .collect();
            buffers.write_f32_slice(dst, &result)
        }
        (0, 1) => {
            // F32 -> F64
            let data = buffers.read_f32_slice(src, count)?;
            let result: Vec<f64> = data.iter().map(|&f| f64::from(f)).collect();
            let bytes: Vec<u8> = result.iter().flat_map(|&f| f.to_ne_bytes()).collect();
            buffers.write(dst, &bytes)
        }
        (1, 0) => {
            // F64 -> F32
            let src_data = buffers.read(src)?;
            #[allow(clippy::cast_possible_truncation)]
            let result: Vec<f32> = src_data
                .chunks_exact(8)
                .take(count)
                .map(|chunk| {
                    let f = f64::from_ne_bytes(chunk.try_into().unwrap());
                    f as f32
                })
                .collect();
            buffers.write_f32_slice(dst, &result)
        }
        _ => {
            // For unsupported combinations, just copy bytes
            let src_data = buffers.read(src)?;
            let data = src_data.to_vec();
            buffers.write(dst, &data)
        }
    }
}

// ============================================================================
// CNN Operations (Scalar fallback)
// ============================================================================

/// 2D Convolution (NCHW format) - scalar fallback for WASM.
#[allow(clippy::too_many_arguments)]
fn exec_conv2d_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    input: u32,
    weight: u32,
    bias: Option<u32>,
    kernel_h: usize,
    kernel_w: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
    dilation_h: usize,
    dilation_w: usize,
    groups: usize,
    batch: usize,
    in_channels: usize,
    in_h: usize,
    in_w: usize,
    out_channels: usize,
    out_h: usize,
    out_w: usize,
) -> Result<()> {
    let input_data = buffers.read_f32_slice(input, batch * in_channels * in_h * in_w)?;
    let weight_data = buffers.read_f32_slice(
        weight,
        out_channels * (in_channels / groups) * kernel_h * kernel_w,
    )?;
    let bias_data = if let Some(bias_idx) = bias {
        Some(buffers.read_f32_slice(bias_idx, out_channels)?.to_vec())
    } else {
        None
    };

    let mut output = vec![0.0f32; batch * out_channels * out_h * out_w];

    super::cpu::conv2d_nchw(
        &mut output,
        input_data,
        weight_data,
        bias_data.as_deref(),
        batch,
        in_channels,
        out_channels,
        in_h,
        in_w,
        out_h,
        out_w,
        kernel_h,
        kernel_w,
        stride_h,
        stride_w,
        pad_h,
        pad_w,
        dilation_h,
        dilation_w,
        groups,
    );

    buffers.write_f32_slice(dst, &output)
}

/// Batch Normalization (inference mode) - scalar fallback for WASM.
#[allow(clippy::too_many_arguments)]
fn exec_batch_norm_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    input: u32,
    scale: u32,
    bias: u32,
    mean: u32,
    var: u32,
    epsilon: f32,
    batch: usize,
    channels: usize,
    spatial: usize,
) -> Result<()> {
    let input_data = buffers.read_f32_slice(input, batch * channels * spatial)?;
    let scale_data = buffers.read_f32_slice(scale, channels)?;
    let bias_data = buffers.read_f32_slice(bias, channels)?;
    let mean_data = buffers.read_f32_slice(mean, channels)?;
    let var_data = buffers.read_f32_slice(var, channels)?;

    let mut output = vec![0.0f32; batch * channels * spatial];

    super::cpu::batch_norm_inference(
        &mut output,
        input_data,
        scale_data,
        bias_data,
        mean_data,
        var_data,
        epsilon,
        batch,
        channels,
        spatial,
    );

    buffers.write_f32_slice(dst, &output)
}

/// Layer Normalization - scalar implementation for WASM.
///
/// Uses Welford's algorithm for numerically stable mean/variance.
#[allow(clippy::too_many_arguments)]
fn exec_layer_norm_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    input: u32,
    scale: u32,
    bias: u32,
    epsilon: f32,
    num_instances: usize,
    normalized_count: usize,
) -> Result<()> {
    let total_count = num_instances * normalized_count;
    let input_data = buffers.read_f32_slice(input, total_count)?;
    let scale_data = buffers.read_f32_slice(scale, normalized_count)?;
    let bias_data = buffers.read_f32_slice(bias, normalized_count)?;

    let mut output = vec![0.0f32; total_count];

    // Use the CPU implementation (scalar path)
    super::cpu::layer_norm_simd(
        input_data,
        scale_data,
        bias_data,
        &mut output,
        num_instances,
        normalized_count,
        epsilon,
    );

    buffers.write_f32_slice(dst, &output)
}

/// 2D Max Pooling - scalar fallback for WASM.
#[allow(clippy::too_many_arguments)]
fn exec_max_pool2d_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    kernel_h: usize,
    kernel_w: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
    batch: usize,
    channels: usize,
    in_h: usize,
    in_w: usize,
    out_h: usize,
    out_w: usize,
) -> Result<()> {
    let input_data = buffers.read_f32_slice(src, batch * channels * in_h * in_w)?;
    let mut output = vec![0.0f32; batch * channels * out_h * out_w];

    super::cpu::max_pool2d(
        &mut output,
        input_data,
        batch,
        channels,
        in_h,
        in_w,
        out_h,
        out_w,
        kernel_h,
        kernel_w,
        stride_h,
        stride_w,
        pad_h,
        pad_w,
    );

    buffers.write_f32_slice(dst, &output)
}

/// 2D Average Pooling - scalar fallback for WASM.
#[allow(clippy::too_many_arguments)]
fn exec_avg_pool2d_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    kernel_h: usize,
    kernel_w: usize,
    stride_h: usize,
    stride_w: usize,
    pad_h: usize,
    pad_w: usize,
    batch: usize,
    channels: usize,
    in_h: usize,
    in_w: usize,
    out_h: usize,
    out_w: usize,
) -> Result<()> {
    let input_data = buffers.read_f32_slice(src, batch * channels * in_h * in_w)?;
    let mut output = vec![0.0f32; batch * channels * out_h * out_w];

    super::cpu::avg_pool2d(
        &mut output,
        input_data,
        batch,
        channels,
        in_h,
        in_w,
        out_h,
        out_w,
        kernel_h,
        kernel_w,
        stride_h,
        stride_w,
        pad_h,
        pad_w,
    );

    buffers.write_f32_slice(dst, &output)
}

/// Global Average Pooling - scalar fallback for WASM.
fn exec_global_avg_pool_scalar(
    buffers: &mut BufferManager,
    dst: u32,
    src: u32,
    batch: usize,
    channels: usize,
    spatial: usize,
) -> Result<()> {
    let input_data = buffers.read_f32_slice(src, batch * channels * spatial)?;
    let mut output = vec![0.0f32; batch * channels];

    super::cpu::global_avg_pool(&mut output, input_data, batch, channels, spatial);

    buffers.write_f32_slice(dst, &output)
}

#[cfg(test)]
mod tests {
    use super::*;
    use hologram_holo::types::BufferType;
    use hologram_holo::{IsaInstruction, PlanMetadata};

    fn make_plan(
        instructions: Vec<IsaInstruction>,
        buffers: Vec<hologram_holo::types::BufferMetadata>,
    ) -> BackendPlan {
        BackendPlan {
            instructions,
            buffers,
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        }
    }

    fn make_buffer(buffer_type: BufferType, size: usize) -> hologram_holo::types::BufferMetadata {
        hologram_holo::types::BufferMetadata {
            buffer_type,
            size,
            alignment: 4,
            fully_written: false,
        }
    }

    #[test]
    fn test_wasm_backend_creation() {
        let backend = WasmBackend::new();
        assert_eq!(backend.backend_type(), BackendType::Wasm);
    }

    #[test]
    fn test_wasm_backend_default() {
        let backend = WasmBackend::default();
        assert_eq!(backend.backend_type(), BackendType::Wasm);
    }

    #[test]
    fn test_wasm_is_available() {
        assert!(WasmBackend::is_available());
    }

    #[test]
    fn test_wasm_capabilities() {
        let backend = WasmBackend::new();
        let caps = backend.capabilities();
        assert_eq!(caps.backend_type, BackendType::Wasm);
        assert_eq!(caps.vector_width, 1); // No SIMD
    }

    #[test]
    fn test_wasm_execute_empty_plan() {
        let backend = WasmBackend::new();
        let plan = make_plan(vec![], vec![]);

        let result = backend.execute_plan(&plan, &[], &mut []);
        assert!(result.is_ok());
    }

    #[test]
    fn test_wasm_add() {
        let backend = WasmBackend::new();

        let buffers = vec![
            make_buffer(BufferType::Input, 16),
            make_buffer(BufferType::Input, 16),
            make_buffer(BufferType::Output, 16),
        ];

        let plan = make_plan(
            vec![IsaInstruction::Add {
                dst: 2,
                a: 0,
                b: 1,
                count: 4,
            }],
            buffers,
        );

        let input_a: Vec<u8> = [1.0f32, 2.0, 3.0, 4.0]
            .iter()
            .flat_map(|f| f.to_le_bytes())
            .collect();
        let input_b: Vec<u8> = [10.0f32, 20.0, 30.0, 40.0]
            .iter()
            .flat_map(|f| f.to_le_bytes())
            .collect();
        let mut output = vec![0u8; 16];

        backend
            .execute_plan(&plan, &[&input_a, &input_b], &mut [&mut output])
            .unwrap();

        let result: Vec<f32> = output
            .chunks(4)
            .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
            .collect();

        assert_eq!(result, vec![11.0, 22.0, 33.0, 44.0]);
    }

    #[test]
    fn test_wasm_sigmoid() {
        let backend = WasmBackend::new();

        let buffers = vec![
            make_buffer(BufferType::Input, 8),
            make_buffer(BufferType::Output, 8),
        ];

        let plan = make_plan(
            vec![IsaInstruction::Sigmoid {
                dst: 1,
                src: 0,
                count: 2,
            }],
            buffers,
        );

        let input: Vec<u8> = [0.0f32, 1000.0]
            .iter()
            .flat_map(|f| f.to_le_bytes())
            .collect();
        let mut output = vec![0u8; 8];

        backend
            .execute_plan(&plan, &[&input], &mut [&mut output])
            .unwrap();

        let result: Vec<f32> = output
            .chunks(4)
            .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
            .collect();

        // sigmoid(0) = 0.5, sigmoid(large) ≈ 1.0
        assert!((result[0] - 0.5).abs() < 0.001);
        assert!((result[1] - 1.0).abs() < 0.001);
    }

    #[test]
    fn test_wasm_relu() {
        let backend = WasmBackend::new();

        let buffers = vec![
            make_buffer(BufferType::Input, 16),
            make_buffer(BufferType::Output, 16),
        ];

        let plan = make_plan(
            vec![IsaInstruction::Relu {
                dst: 1,
                src: 0,
                count: 4,
            }],
            buffers,
        );

        let input: Vec<u8> = [-2.0f32, -1.0, 0.0, 3.0]
            .iter()
            .flat_map(|f| f.to_le_bytes())
            .collect();
        let mut output = vec![0u8; 16];

        backend
            .execute_plan(&plan, &[&input], &mut [&mut output])
            .unwrap();

        let result: Vec<f32> = output
            .chunks(4)
            .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
            .collect();

        assert_eq!(result, vec![0.0, 0.0, 0.0, 3.0]);
    }

    #[test]
    fn test_wasm_sum() {
        let backend = WasmBackend::new();

        let buffers = vec![
            make_buffer(BufferType::Input, 16),
            make_buffer(BufferType::Output, 4),
        ];

        let plan = make_plan(
            vec![IsaInstruction::Sum {
                dst: 1,
                src: 0,
                count: 4,
            }],
            buffers,
        );

        let input: Vec<u8> = [1.0f32, 2.0, 3.0, 4.0]
            .iter()
            .flat_map(|f| f.to_le_bytes())
            .collect();
        let mut output = vec![0u8; 4];

        backend
            .execute_plan(&plan, &[&input], &mut [&mut output])
            .unwrap();

        let result = f32::from_le_bytes([output[0], output[1], output[2], output[3]]);
        assert!((result - 10.0).abs() < 0.001);
    }

    #[test]
    fn test_wasm_matmul() {
        let backend = WasmBackend::new();

        // 2x2 matrices
        let buffers = vec![
            make_buffer(BufferType::Input, 16),  // A: 2x2
            make_buffer(BufferType::Input, 16),  // B: 2x2
            make_buffer(BufferType::Output, 16), // C: 2x2
        ];

        let plan = make_plan(
            vec![IsaInstruction::MatMul {
                c: 2,
                a: 0,
                b: 1,
                m: 2,
                k: 2,
                n: 2,
            }],
            buffers,
        );

        // A = [[1, 2], [3, 4]]
        let input_a: Vec<u8> = [1.0f32, 2.0, 3.0, 4.0]
            .iter()
            .flat_map(|f| f.to_le_bytes())
            .collect();
        // B = [[5, 6], [7, 8]]
        let input_b: Vec<u8> = [5.0f32, 6.0, 7.0, 8.0]
            .iter()
            .flat_map(|f| f.to_le_bytes())
            .collect();
        let mut output = vec![0u8; 16];

        backend
            .execute_plan(&plan, &[&input_a, &input_b], &mut [&mut output])
            .unwrap();

        let result: Vec<f32> = output
            .chunks(4)
            .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
            .collect();

        // C = [[1*5+2*7, 1*6+2*8], [3*5+4*7, 3*6+4*8]] = [[19, 22], [43, 50]]
        assert_eq!(result, vec![19.0, 22.0, 43.0, 50.0]);
    }

    #[test]
    fn test_wasm_lift() {
        let backend = WasmBackend::new();

        let buffers = vec![
            make_buffer(BufferType::Input, 4),
            make_buffer(BufferType::Output, 8), // 2 bytes per input
        ];

        let plan = make_plan(
            vec![IsaInstruction::Lift {
                dst: 1,
                src: 0,
                count: 4,
            }],
            buffers,
        );

        let input = vec![0u8, 96, 192, 255];
        let mut output = vec![0u8; 8];

        backend
            .execute_plan(&plan, &[&input], &mut [&mut output])
            .unwrap();

        // Verify PackedCell format: [offset, page]
        // byte 0: page = 0 / 8 = 0, offset = 0
        assert_eq!(output[0], 0); // offset
        assert_eq!(output[1], 0); // page

        // byte 96: page = 96 / 8 = 12, offset = 96
        assert_eq!(output[2], 96);
        assert_eq!(output[3], 12);
    }

    #[test]
    fn test_wasm_orbit_classify() {
        let backend = WasmBackend::new();

        let buffers = vec![
            make_buffer(BufferType::Input, 4),
            make_buffer(BufferType::Output, 4),
        ];

        let plan = make_plan(
            vec![IsaInstruction::OrbitClassify {
                dst: 1,
                src: 0,
                count: 4,
            }],
            buffers,
        );

        let input = vec![0u8, 7, 8, 255];
        let mut output = vec![0u8; 4];

        backend
            .execute_plan(&plan, &[&input], &mut [&mut output])
            .unwrap();

        // orbit_class = byte / 8
        assert_eq!(output[0], 0); // 0 / 8 = 0
        assert_eq!(output[1], 0); // 7 / 8 = 0
        assert_eq!(output[2], 1); // 8 / 8 = 1
        assert_eq!(output[3], 31); // 255 / 8 = 31
    }

    #[test]
    fn test_wasm_ring_add() {
        let backend = WasmBackend::new();

        let buffers = vec![
            make_buffer(BufferType::Input, 4),
            make_buffer(BufferType::Input, 4),
            make_buffer(BufferType::Output, 4),
        ];

        let plan = make_plan(
            vec![IsaInstruction::RingAdd {
                dst: 2,
                a: 0,
                b: 1,
                count: 4,
            }],
            buffers,
        );

        let input_a = vec![0u8, 50, 90, 95];
        let input_b = vec![10u8, 50, 10, 5];
        let mut output = vec![0u8; 4];

        backend
            .execute_plan(&plan, &[&input_a, &input_b], &mut [&mut output])
            .unwrap();

        // wrapping byte add
        assert_eq!(output[0], 10); // (0 + 10) % 96 = 10
        assert_eq!(output[1], 100);
        assert_eq!(output[2], 100);
        assert_eq!(output[3], 100);
    }

    #[test]
    fn test_wasm_ring_mul() {
        let backend = WasmBackend::new();

        let buffers = vec![
            make_buffer(BufferType::Input, 4),
            make_buffer(BufferType::Input, 4),
            make_buffer(BufferType::Output, 4),
        ];

        let plan = make_plan(
            vec![IsaInstruction::RingMul {
                dst: 2,
                a: 0,
                b: 1,
                count: 4,
            }],
            buffers,
        );

        let input_a = vec![1u8, 10, 12, 48];
        let input_b = vec![1u8, 10, 8, 2];
        let mut output = vec![0u8; 4];

        backend
            .execute_plan(&plan, &[&input_a, &input_b], &mut [&mut output])
            .unwrap();

        // wrapping byte mul
        assert_eq!(output[0], 1); // (1 * 1) % 96 = 1
        assert_eq!(output[1], 100);
        assert_eq!(output[2], 96);
        assert_eq!(output[3], 96);
    }

    #[test]
    fn test_wasm_call_layer_requires_executor() {
        let backend = WasmBackend::new();

        let buffers = vec![
            make_buffer(BufferType::Input, 4),
            make_buffer(BufferType::Output, 4),
        ];

        let plan = make_plan(
            vec![IsaInstruction::CallLayer {
                layer_id: 123,
                inputs: vec![0],
                outputs: vec![1],
            }],
            buffers,
        );

        let input = vec![0u8; 4];
        let mut output = vec![0u8; 4];

        // Without layer executor, CallLayer should fail with UnsupportedInstruction
        let result = backend.execute_plan(&plan, &[&input], &mut [&mut output]);
        assert!(matches!(
            result,
            Err(BackendError::UnsupportedInstruction(_))
        ));
    }

    #[test]
    fn test_wasm_copy() {
        let backend = WasmBackend::new();

        let buffers = vec![
            make_buffer(BufferType::Input, 8),
            make_buffer(BufferType::Output, 8),
        ];

        let plan = make_plan(
            vec![IsaInstruction::Copy {
                dst: 1,
                src: 0,
                size: 8,
            }],
            buffers,
        );

        let input = vec![1u8, 2, 3, 4, 5, 6, 7, 8];
        let mut output = vec![0u8; 8];

        backend
            .execute_plan(&plan, &[&input], &mut [&mut output])
            .unwrap();

        assert_eq!(output, input);
    }

    // ========================================================================
    // WasmMemory Tests
    // ========================================================================

    #[test]
    fn test_wasm_page_size() {
        assert_eq!(WASM_PAGE_SIZE, 65536);
    }

    #[test]
    fn test_wasm_pages_needed() {
        // Exact page boundary
        assert_eq!(WasmMemory::pages_needed(65536), 1);
        assert_eq!(WasmMemory::pages_needed(131_072), 2);

        // Below boundary
        assert_eq!(WasmMemory::pages_needed(1), 1);
        assert_eq!(WasmMemory::pages_needed(65535), 1);

        // Above boundary
        assert_eq!(WasmMemory::pages_needed(65537), 2);
    }

    #[test]
    fn test_wasm_estimate_plan_memory() {
        let buffers = vec![
            make_buffer(BufferType::Input, 1024),
            make_buffer(BufferType::Output, 2048),
        ];

        let plan = BackendPlan {
            instructions: vec![],
            buffers,
            constants: vec![0u8; 512],
            workspace_size: 256,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        let estimate = WasmMemory::estimate_plan_memory(&plan);
        // 1024 + 2048 (buffers) + 512 (constants) + 256 (workspace) = 3840
        assert_eq!(estimate, 3840);
    }

    #[test]
    fn test_wasm_plan_fits() {
        let buffers = vec![make_buffer(BufferType::Input, 1024)];

        let plan = BackendPlan {
            instructions: vec![],
            buffers,
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        // Plan with 1KB buffer should fit in 1GB limit
        assert!(WasmMemory::plan_fits(&plan, WASM_DEFAULT_MAX_MEMORY));
        assert!(WasmMemory::plan_fits_default(&plan));

        // Plan should not fit in tiny limit
        assert!(!WasmMemory::plan_fits(&plan, 512));
    }

    #[test]
    fn test_wasm_validate_buffer_sizes_ok() {
        let buffers = vec![
            make_buffer(BufferType::Input, 1024 * 1024),      // 1MB
            make_buffer(BufferType::Output, 2 * 1024 * 1024), // 2MB
        ];

        let plan = BackendPlan {
            instructions: vec![],
            buffers,
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        assert!(WasmMemory::validate_buffer_sizes(&plan).is_ok());
    }

    #[test]
    fn test_wasm_validate_buffer_sizes_too_large() {
        let buffers = vec![
            make_buffer(BufferType::Input, WASM_DEFAULT_MAX_MEMORY), // 1GB - too large
        ];

        let plan = BackendPlan {
            instructions: vec![],
            buffers,
            constants: vec![],
            workspace_size: 0,
            dependencies: vec![],
            metadata: PlanMetadata::default(),
            node_buffer_map: vec![],
            observable_metadata: hologram_holo::ObservableMetadata::default(),
            lut_section: hologram_holo::LutSection::new(),
        };

        assert!(WasmMemory::validate_buffer_sizes(&plan).is_err());
    }
}
