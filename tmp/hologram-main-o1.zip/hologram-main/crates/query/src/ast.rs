//! Query AST types.

/// Top-level operation type.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OpType {
    Query,
    Mutation,
}

/// A parsed query document.
#[derive(Debug, Clone)]
pub struct Document {
    pub op: OpType,
    pub selections: Vec<Selection>,
}

/// A single field selection with optional arguments and nested children.
#[derive(Debug, Clone)]
pub struct Selection {
    pub field: String,
    pub arguments: Vec<(String, QueryValue)>,
    pub children: Vec<Selection>,
}

/// A literal value in a query argument.
#[derive(Debug, Clone, PartialEq)]
pub enum QueryValue {
    Int(i64),
    Str(String),
    Ident(String),
    List(Vec<QueryValue>),
}

impl QueryValue {
    /// Extract as i64 if this is an `Int`.
    pub fn as_int(&self) -> Option<i64> {
        match self {
            Self::Int(v) => Some(*v),
            _ => None,
        }
    }

    /// Extract as &str if this is a `Str` or `Ident`.
    pub fn as_str(&self) -> Option<&str> {
        match self {
            Self::Str(s) | Self::Ident(s) => Some(s),
            _ => None,
        }
    }
}
