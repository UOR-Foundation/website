//! Benchmarks for .holo file loading and bundle operations.

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use hologram_holo::{crc32, HolbReader, HolbWriter, HolmReader, HolmWriter};

// ============================================================================
// Helper Functions
// ============================================================================

/// Create a HOLB bundle of specified graph size.
fn create_holb_bundle(graph_size: usize) -> Vec<u8> {
    let graph_data: Vec<u8> = (0..graph_size).map(|i| (i % 256) as u8).collect();
    let mut writer = HolbWriter::new();
    writer.set_graph(&graph_data);
    writer.build().unwrap()
}

/// Create a HOLB bundle with sections.
fn create_holb_with_sections(graph_size: usize, section_count: usize) -> Vec<u8> {
    let graph_data: Vec<u8> = (0..graph_size).map(|i| (i % 256) as u8).collect();
    let mut writer = HolbWriter::new();
    writer.set_graph(&graph_data);

    for i in 0..section_count {
        let name = format!("section_{i}");
        let data = format!("data for section {i}");
        writer.add_raw_section(&name, "text/plain", data.as_bytes());
    }

    writer.build().unwrap()
}

/// Create a HOLM pipeline with specified model count.
fn create_holm_pipeline(model_count: usize) -> Vec<u8> {
    let mut writer = HolmWriter::new();

    for i in 0..model_count {
        let name = format!("model_{i}");
        let bundle = create_holb_bundle(1024); // 1KB models
        writer.add_model(&name, &bundle).unwrap();
    }

    writer.build().unwrap()
}

// ============================================================================
// CRC32 Benchmarks
// ============================================================================

fn bench_crc32(c: &mut Criterion) {
    let mut group = c.benchmark_group("crc32");

    for size in [64, 256, 1024, 4096, 16384, 65536] {
        let data: Vec<u8> = (0..size).map(|i| (i % 256) as u8).collect();
        group.throughput(Throughput::Bytes(size as u64));

        group.bench_with_input(BenchmarkId::from_parameter(size), &data, |b, data| {
            b.iter(|| crc32(black_box(data)));
        });
    }

    group.finish();
}

// ============================================================================
// HOLB Read Benchmarks
// ============================================================================

fn bench_holb_read(c: &mut Criterion) {
    let mut group = c.benchmark_group("holb_read");

    for size in [1024, 4096, 16384, 65536] {
        let bundle = create_holb_bundle(size);
        group.throughput(Throughput::Bytes(bundle.len() as u64));

        group.bench_with_input(
            BenchmarkId::from_parameter(format!("{size}B")),
            &bundle,
            |b, bundle| {
                b.iter(|| {
                    let reader = HolbReader::from_bytes(black_box(bundle)).unwrap();
                    black_box(reader.graph());
                });
            },
        );
    }

    group.finish();
}

// ============================================================================
// HOLB Write Benchmarks
// ============================================================================

fn bench_holb_write(c: &mut Criterion) {
    let mut group = c.benchmark_group("holb_write");

    for size in [1024, 4096, 16384, 65536] {
        let graph_data: Vec<u8> = (0..size).map(|i| (i % 256) as u8).collect();
        group.throughput(Throughput::Bytes(size as u64));

        group.bench_with_input(
            BenchmarkId::from_parameter(format!("{size}B")),
            &graph_data,
            |b, data| {
                b.iter(|| {
                    let mut writer = HolbWriter::new();
                    writer.set_graph(black_box(data));
                    black_box(writer.build().unwrap());
                });
            },
        );
    }

    group.finish();
}

// ============================================================================
// Section Access Benchmarks
// ============================================================================

fn bench_section_access(c: &mut Criterion) {
    let mut group = c.benchmark_group("section_access");

    for section_count in [0, 5, 20] {
        let bundle = create_holb_with_sections(1024, section_count);
        group.throughput(Throughput::Elements(1));

        // Benchmark sections_count
        group.bench_with_input(
            BenchmarkId::new("sections_count", section_count),
            &bundle,
            |b, bundle| {
                let reader = HolbReader::from_bytes(bundle).unwrap();
                b.iter(|| {
                    black_box(reader.sections_count());
                });
            },
        );

        // Benchmark get_section lookup
        if section_count > 0 {
            let target_section = format!("section_{}", section_count / 2);
            group.bench_with_input(
                BenchmarkId::new("get_section", section_count),
                &(bundle, target_section),
                |b, (bundle, target)| {
                    let reader = HolbReader::from_bytes(bundle).unwrap();
                    b.iter(|| {
                        black_box(reader.get_section(black_box(target)));
                    });
                },
            );
        }
    }

    group.finish();
}

// ============================================================================
// HOLM Read Benchmarks
// ============================================================================

fn bench_holm_read(c: &mut Criterion) {
    let mut group = c.benchmark_group("holm_read");

    for model_count in [1, 5, 10] {
        let pipeline = create_holm_pipeline(model_count);
        group.throughput(Throughput::Elements(model_count as u64));

        group.bench_with_input(
            BenchmarkId::new("parse", model_count),
            &pipeline,
            |b, pipeline| {
                b.iter(|| {
                    let reader = HolmReader::from_bytes(black_box(pipeline)).unwrap();
                    black_box(reader.model_count());
                });
            },
        );

        // Benchmark get_model
        let target_model = format!("model_{}", model_count / 2);
        group.bench_with_input(
            BenchmarkId::new("get_model", model_count),
            &(pipeline, target_model),
            |b, (pipeline, target)| {
                let reader = HolmReader::from_bytes(pipeline).unwrap();
                b.iter(|| {
                    black_box(reader.get_model(black_box(target)).unwrap());
                });
            },
        );
    }

    group.finish();
}

// ============================================================================
// HOLM Write Benchmarks
// ============================================================================

fn bench_holm_write(c: &mut Criterion) {
    let mut group = c.benchmark_group("holm_write");

    for model_count in [1, 5, 10] {
        // Pre-create model bundles
        let models: Vec<(String, Vec<u8>)> = (0..model_count)
            .map(|i| (format!("model_{i}"), create_holb_bundle(1024)))
            .collect();

        group.throughput(Throughput::Elements(model_count as u64));

        group.bench_with_input(
            BenchmarkId::from_parameter(model_count),
            &models,
            |b, models| {
                b.iter(|| {
                    let mut writer = HolmWriter::new();
                    for (name, data) in models {
                        writer.add_model(black_box(name), black_box(data)).unwrap();
                    }
                    black_box(writer.build().unwrap());
                });
            },
        );
    }

    group.finish();
}

// ============================================================================
// Checksum Verification Benchmarks
// ============================================================================

fn bench_checksum_verification(c: &mut Criterion) {
    let mut group = c.benchmark_group("checksum_verification");

    for size in [1024, 16384, 65536] {
        let bundle = create_holb_bundle(size);
        group.throughput(Throughput::Bytes(bundle.len() as u64));

        group.bench_with_input(
            BenchmarkId::from_parameter(format!("{size}B")),
            &bundle,
            |b, bundle| {
                let reader = HolbReader::from_bytes(bundle).unwrap();
                b.iter(|| {
                    black_box(reader.verify_all_checksums());
                });
            },
        );
    }

    group.finish();
}

criterion_group!(
    benches,
    bench_crc32,
    bench_holb_read,
    bench_holb_write,
    bench_section_access,
    bench_holm_read,
    bench_holm_write,
    bench_checksum_verification,
);
criterion_main!(benches);
