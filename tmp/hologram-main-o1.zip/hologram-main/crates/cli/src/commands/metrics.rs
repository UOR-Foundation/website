//! Metrics command: performance reporting and profiling.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::time::Duration;

use clap::{Args, Subcommand};
use owo_colors::OwoColorize;
use serde::{Deserialize, Serialize};

use crate::error::{CliError, CliResult};

/// Arguments for the metrics command.
#[derive(Args, Debug)]
pub struct MetricsArgs {
    #[command(subcommand)]
    pub command: MetricsCommand,
}

/// Metrics subcommands.
#[derive(Subcommand, Debug)]
pub enum MetricsCommand {
    /// Show execution profile from a previous run
    Profile {
        /// Profile data file
        #[arg(value_name = "FILE")]
        file: PathBuf,

        /// Output format (text, json, flamegraph)
        #[arg(short, long, default_value = "text")]
        format: String,
    },

    /// Show memory usage statistics
    Memory {
        /// Model file to analyze
        #[arg(value_name = "MODEL")]
        model: PathBuf,
    },

    /// Compare two profile runs
    Compare {
        /// Baseline profile
        #[arg(value_name = "BASELINE")]
        baseline: PathBuf,

        /// Current profile to compare
        #[arg(value_name = "CURRENT")]
        current: PathBuf,

        /// Threshold for highlighting regressions (percentage)
        #[arg(short, long, default_value = "5")]
        threshold: f64,
    },

    /// Export metrics in various formats
    Export {
        /// Input profile data
        #[arg(value_name = "FILE")]
        file: PathBuf,

        /// Output file
        #[arg(short, long)]
        output: PathBuf,

        /// Output format (json, csv, prometheus)
        #[arg(short, long, default_value = "json")]
        format: String,
    },
}

/// Profile data format for storing execution metrics.
///
/// This format captures timing information from model benchmarks
/// and execution runs for later analysis and comparison.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProfileData {
    /// Profile format version
    pub version: u32,

    /// Name of the profiled model
    pub model_name: String,

    /// Timestamp when profile was created (Unix epoch seconds)
    pub timestamp: u64,

    /// Number of iterations used for this profile
    pub iterations: u32,

    /// Batch size used during profiling
    pub batch_size: u32,

    /// Overall timing statistics (in nanoseconds)
    pub timing: TimingStats,

    /// Per-operation breakdown (if available)
    #[serde(default)]
    pub operations: BTreeMap<String, TimingStats>,

    /// Memory statistics (if available)
    #[serde(default)]
    pub memory: Option<MemoryStats>,

    /// Additional metadata
    #[serde(default)]
    pub metadata: BTreeMap<String, String>,
}

/// Timing statistics for a profiled section.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TimingStats {
    /// Mean duration in nanoseconds
    pub mean_ns: u64,

    /// Median duration in nanoseconds
    pub median_ns: u64,

    /// Minimum duration in nanoseconds
    pub min_ns: u64,

    /// Maximum duration in nanoseconds
    pub max_ns: u64,

    /// Standard deviation in nanoseconds
    pub std_dev_ns: u64,

    /// Number of samples
    pub samples: u32,
}

/// Memory usage statistics.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct MemoryStats {
    /// Total model size in bytes
    pub model_size: u64,

    /// Graph/plan size in bytes
    pub graph_size: u64,

    /// Weights/constants size in bytes
    pub weights_size: u64,

    /// Workspace buffer size in bytes
    pub workspace_size: u64,

    /// Input buffer size in bytes
    pub input_size: u64,

    /// Output buffer size in bytes
    pub output_size: u64,
}

impl ProfileData {
    /// Current profile format version.
    pub const CURRENT_VERSION: u32 = 1;

    /// Create a new profile with basic information.
    #[must_use]
    pub fn new(model_name: impl Into<String>, iterations: u32, batch_size: u32) -> Self {
        Self {
            version: Self::CURRENT_VERSION,
            model_name: model_name.into(),
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
            iterations,
            batch_size,
            timing: TimingStats::default(),
            operations: BTreeMap::new(),
            memory: None,
            metadata: BTreeMap::new(),
        }
    }

    /// Load profile from a JSON file.
    ///
    /// # Errors
    /// Returns error if file cannot be read or parsed.
    pub fn load(path: &Path) -> CliResult<Self> {
        let contents = std::fs::read_to_string(path)?;
        serde_json::from_str(&contents)
            .map_err(|e| CliError::InvalidInput(format!("invalid profile data: {e}")))
    }

    /// Save profile to a JSON file.
    ///
    /// # Errors
    /// Returns error if file cannot be written.
    pub fn save(&self, path: &Path) -> CliResult<()> {
        let json = serde_json::to_string_pretty(self)?;
        std::fs::write(path, json)?;
        Ok(())
    }
}

impl TimingStats {
    /// Create timing stats from a slice of durations.
    #[must_use]
    pub fn from_durations(durations: &[Duration]) -> Self {
        if durations.is_empty() {
            return Self::default();
        }

        let mut sorted: Vec<_> = durations.iter().map(|d| d.as_nanos() as u64).collect();
        sorted.sort_unstable();

        let samples = sorted.len() as u32;
        let sum: u64 = sorted.iter().sum();
        let mean_ns = sum / samples as u64;
        let median_ns = sorted[sorted.len() / 2];
        let min_ns = sorted[0];
        let max_ns = sorted[sorted.len() - 1];

        // Calculate standard deviation
        let variance: f64 = sorted
            .iter()
            .map(|&t| {
                let diff = t as f64 - mean_ns as f64;
                diff * diff
            })
            .sum::<f64>()
            / samples as f64;
        let std_dev_ns = variance.sqrt() as u64;

        Self {
            mean_ns,
            median_ns,
            min_ns,
            max_ns,
            std_dev_ns,
            samples,
        }
    }

    /// Get mean as Duration.
    #[must_use]
    pub fn mean(&self) -> Duration {
        Duration::from_nanos(self.mean_ns)
    }

    /// Get median as Duration.
    #[must_use]
    pub fn median(&self) -> Duration {
        Duration::from_nanos(self.median_ns)
    }
}

/// Execute the metrics command.
pub fn execute(args: MetricsArgs, verbose: bool) -> CliResult<()> {
    match args.command {
        MetricsCommand::Profile { file, format } => profile(&file, &format, verbose),
        MetricsCommand::Memory { model } => memory(&model, verbose),
        MetricsCommand::Compare {
            baseline,
            current,
            threshold,
        } => compare(&baseline, &current, threshold, verbose),
        MetricsCommand::Export {
            file,
            output,
            format,
        } => export(&file, &output, &format, verbose),
    }
}

/// Show execution profile.
fn profile(file: &Path, format: &str, verbose: bool) -> CliResult<()> {
    if !file.exists() {
        return Err(CliError::FileNotFound(file.to_path_buf()));
    }

    if verbose {
        println!("Loading profile from {} (format: {format})", file.display());
    }

    let profile = ProfileData::load(file)?;

    match format {
        "text" => display_profile_text(&profile),
        "json" => display_profile_json(&profile)?,
        "flamegraph" => {
            println!("Flamegraph output requires the `inferno` tool.");
            println!("Install with: cargo install inferno");
            println!();
            println!("To generate a flamegraph from this profile:");
            println!(
                "  hologram metrics export {} -o folded.txt -f folded",
                file.display()
            );
            println!("  cat folded.txt | inferno-flamegraph > profile.svg");
            return Err(CliError::NotImplemented(
                "flamegraph format (use 'text' or 'json')".to_string(),
            ));
        }
        _ => {
            return Err(CliError::InvalidInput(format!(
                "unknown format: {format} (supported: text, json)"
            )));
        }
    }

    Ok(())
}

/// Display profile in text format.
fn display_profile_text(profile: &ProfileData) {
    println!();
    println!("{} {}", "Profile:".bold(), profile.model_name.cyan().bold());
    println!(
        "  {} {}",
        "Created:".dimmed(),
        format_timestamp(profile.timestamp)
    );
    println!(
        "  {} {}",
        "Iterations:".dimmed(),
        profile.iterations.to_string().cyan()
    );
    println!(
        "  {} {}",
        "Batch size:".dimmed(),
        profile.batch_size.to_string().cyan()
    );

    println!();
    println!("{}", "Timing (overall):".bold());
    display_timing_stats(&profile.timing, "  ");

    if !profile.operations.is_empty() {
        println!();
        println!("{}", "Per-operation breakdown:".bold());

        // Calculate max operation name length for alignment
        let max_name_len = profile
            .operations
            .keys()
            .map(|s| s.len())
            .max()
            .unwrap_or(10);

        // Sort operations by mean time (descending) for useful output
        let mut ops: Vec<_> = profile.operations.iter().collect();
        ops.sort_by(|a, b| b.1.mean_ns.cmp(&a.1.mean_ns));

        for (op, stats) in ops {
            let pct = if profile.timing.mean_ns > 0 {
                stats.mean_ns as f64 / profile.timing.mean_ns as f64 * 100.0
            } else {
                0.0
            };

            println!(
                "  {:width$}  {:>10.3?}  {:>5.1}%  {}",
                op.cyan(),
                stats.mean(),
                pct,
                render_bar(pct, 20),
                width = max_name_len
            );
        }
    }

    if let Some(mem) = &profile.memory {
        println!();
        println!("{}", "Memory:".bold());
        println!(
            "  {} {:>12} bytes  ({})",
            "Model size:".dimmed(),
            mem.model_size.to_string().cyan(),
            format_bytes(mem.model_size)
        );
        println!(
            "  {} {:>12} bytes",
            "Graph size:".dimmed(),
            mem.graph_size.to_string().cyan()
        );
        println!(
            "  {} {:>12} bytes  ({})",
            "Weights:".dimmed(),
            mem.weights_size.to_string().cyan(),
            format_bytes(mem.weights_size)
        );
        println!(
            "  {} {:>12} bytes",
            "Workspace:".dimmed(),
            mem.workspace_size.to_string().cyan()
        );
        println!(
            "  {} {:>12} bytes",
            "Input:".dimmed(),
            mem.input_size.to_string().cyan()
        );
        println!(
            "  {} {:>12} bytes",
            "Output:".dimmed(),
            mem.output_size.to_string().cyan()
        );
    }

    if !profile.metadata.is_empty() {
        println!();
        println!("{}", "Metadata:".bold());
        for (key, value) in &profile.metadata {
            println!("  {}: {}", key.dimmed(), value);
        }
    }
    println!();
}

/// Render a simple ASCII progress bar.
fn render_bar(pct: f64, width: usize) -> String {
    let filled = ((pct / 100.0) * width as f64).round() as usize;
    let empty = width.saturating_sub(filled);
    format!(
        "{}{}",
        "█".repeat(filled).green(),
        "░".repeat(empty).dimmed()
    )
}

/// Format bytes as human-readable.
fn format_bytes(bytes: u64) -> String {
    if bytes >= 1024 * 1024 * 1024 {
        format!("{:.2} GB", bytes as f64 / 1024.0 / 1024.0 / 1024.0)
    } else if bytes >= 1024 * 1024 {
        format!("{:.2} MB", bytes as f64 / 1024.0 / 1024.0)
    } else if bytes >= 1024 {
        format!("{:.2} KB", bytes as f64 / 1024.0)
    } else {
        format!("{bytes} B")
    }
}

/// Display timing statistics.
fn display_timing_stats(stats: &TimingStats, indent: &str) {
    println!("{indent}Mean:     {:>12.3?}", stats.mean());
    println!("{indent}Median:   {:>12.3?}", stats.median());
    println!(
        "{indent}Std dev:  {:>12.3?}",
        Duration::from_nanos(stats.std_dev_ns)
    );
    println!(
        "{indent}Min:      {:>12.3?}",
        Duration::from_nanos(stats.min_ns)
    );
    println!(
        "{indent}Max:      {:>12.3?}",
        Duration::from_nanos(stats.max_ns)
    );
    println!("{indent}Samples:  {}", stats.samples);
}

/// Display profile in JSON format.
fn display_profile_json(profile: &ProfileData) -> CliResult<()> {
    let json = serde_json::to_string_pretty(profile)?;
    println!("{json}");
    Ok(())
}

/// Format Unix timestamp as human-readable string.
fn format_timestamp(timestamp: u64) -> String {
    use std::time::{Duration, UNIX_EPOCH};

    let time = UNIX_EPOCH + Duration::from_secs(timestamp);
    if let Ok(duration) = time.duration_since(UNIX_EPOCH) {
        let secs = duration.as_secs();
        let days = secs / 86400;
        let years = days / 365 + 1970;
        let day_of_year = days % 365;
        let month = (day_of_year / 30).min(11) + 1;
        let day = (day_of_year % 30) + 1;
        let hour = (secs % 86400) / 3600;
        let minute = (secs % 3600) / 60;
        let second = secs % 60;
        format!("{years:04}-{month:02}-{day:02} {hour:02}:{minute:02}:{second:02} UTC")
    } else {
        format!("epoch + {timestamp}s")
    }
}

/// Show memory usage statistics.
fn memory(model: &Path, verbose: bool) -> CliResult<()> {
    if !model.exists() {
        return Err(CliError::FileNotFound(model.to_path_buf()));
    }

    if verbose {
        println!("Analyzing memory usage for {}", model.display());
    }

    let bytes = std::fs::read(model)?;

    println!("Model: {}", model.display());
    println!(
        "File size: {} bytes ({:.2} KB)",
        bytes.len(),
        bytes.len() as f64 / 1024.0
    );

    if bytes.len() < 4 {
        println!("\n[File too small for format detection]");
        return Ok(());
    }

    let magic = &bytes[0..4];
    match magic {
        b"HOLB" => memory_holb(&bytes, model)?,
        b"HOLM" => memory_holm(&bytes)?,
        _ => {
            println!("\n[Unknown format - cannot analyze structure]");
        }
    }

    Ok(())
}

/// Analyze HOLB memory usage.
fn memory_holb(bytes: &[u8], path: &Path) -> CliResult<()> {
    use hologram_holo::types::BufferType;
    use hologram_holo::{HolbHeader, HOLB_HEADER_SIZE_V1};

    if bytes.len() < HOLB_HEADER_SIZE_V1 {
        println!("\n[File too small for HOLB header]");
        return Ok(());
    }

    let header = HolbHeader::from_bytes(bytes)
        .map_err(|e| CliError::InvalidInput(format!("invalid HOLB header: {e}")))?;

    println!();
    println!("Structure breakdown:");
    println!("  Header:       {} bytes", HOLB_HEADER_SIZE_V1);
    println!(
        "  Graph/Plan:   {} bytes ({:.1}%)",
        header.graph_size,
        header.graph_size as f64 / bytes.len() as f64 * 100.0
    );
    println!(
        "  Weights:      {} bytes ({:.1}%)",
        header.weights_size,
        header.weights_size as f64 / bytes.len() as f64 * 100.0
    );

    // Try to load the plan for more details
    if let Ok(plan) = crate::reader::read_holb(path) {
        println!();
        println!("Plan details:");
        println!("  Instructions: {}", plan.instructions.len());
        println!("  Buffers:      {}", plan.buffers.len());
        println!("  Constants:    {} bytes", plan.constants.len());
        println!("  Workspace:    {} bytes", plan.workspace_size);

        // Buffer breakdown
        let input_size: usize = plan
            .buffers
            .iter()
            .filter(|b| matches!(b.buffer_type, BufferType::Input))
            .map(|b| b.size)
            .sum();
        let output_size: usize = plan
            .buffers
            .iter()
            .filter(|b| matches!(b.buffer_type, BufferType::Output))
            .map(|b| b.size)
            .sum();
        let workspace_buffer_size: usize = plan
            .buffers
            .iter()
            .filter(|b| matches!(b.buffer_type, BufferType::Workspace))
            .map(|b| b.size)
            .sum();

        println!();
        println!("Runtime memory requirements:");
        println!("  Input buffers:        {} bytes", input_size);
        println!("  Output buffers:       {} bytes", output_size);
        println!("  Workspace buffers:    {} bytes", workspace_buffer_size);
        println!("  Plan workspace:       {} bytes", plan.workspace_size);
        println!("  ------------------------------------");
        println!(
            "  Total runtime:        {} bytes ({:.2} KB)",
            input_size + output_size + workspace_buffer_size + plan.workspace_size,
            (input_size + output_size + workspace_buffer_size + plan.workspace_size) as f64
                / 1024.0
        );
    }

    Ok(())
}

/// Analyze HOLM memory usage.
fn memory_holm(bytes: &[u8]) -> CliResult<()> {
    use hologram_holo::{HolmHeader, HOLM_HEADER_SIZE};

    if bytes.len() < HOLM_HEADER_SIZE {
        println!("\n[File too small for HOLM header]");
        return Ok(());
    }

    let header = HolmHeader::from_bytes(bytes)
        .map_err(|e| CliError::InvalidInput(format!("invalid HOLM header: {e}")))?;

    println!();
    println!("Pipeline structure:");
    println!("  Header:       {} bytes", HOLM_HEADER_SIZE);
    println!("  Index:        {} bytes", header.index_size);
    println!("  Models:       {} bytes", header.models_total_size);
    println!("  Model count:  {}", header.model_count);

    Ok(())
}

/// Compare two profile runs.
fn compare(baseline: &Path, current: &Path, threshold: f64, verbose: bool) -> CliResult<()> {
    if !baseline.exists() {
        return Err(CliError::FileNotFound(baseline.to_path_buf()));
    }
    if !current.exists() {
        return Err(CliError::FileNotFound(current.to_path_buf()));
    }

    if verbose {
        println!(
            "Comparing {} vs {} (threshold: {:.1}%)",
            baseline.display(),
            current.display(),
            threshold
        );
    }

    let baseline_profile = ProfileData::load(baseline)?;
    let current_profile = ProfileData::load(current)?;

    println!(
        "Comparison: {} vs {}",
        baseline_profile.model_name, current_profile.model_name
    );
    println!();

    // Compare overall timing
    println!("Overall timing:");
    compare_timing(
        &baseline_profile.timing,
        &current_profile.timing,
        threshold,
        "  ",
    );

    // Compare operations if both have them
    if !baseline_profile.operations.is_empty() || !current_profile.operations.is_empty() {
        println!();
        println!("Per-operation comparison:");

        let mut all_ops: std::collections::BTreeSet<&str> = std::collections::BTreeSet::new();
        all_ops.extend(baseline_profile.operations.keys().map(String::as_str));
        all_ops.extend(current_profile.operations.keys().map(String::as_str));

        for op in all_ops {
            let baseline_stats = baseline_profile.operations.get(op);
            let current_stats = current_profile.operations.get(op);

            match (baseline_stats, current_stats) {
                (Some(b), Some(c)) => {
                    println!("  {op}:");
                    compare_timing(b, c, threshold, "    ");
                }
                (Some(_), None) => {
                    println!("  {op}: [removed in current]");
                }
                (None, Some(_)) => {
                    println!("  {op}: [new in current]");
                }
                (None, None) => {}
            }
        }
    }

    // Summary
    let baseline_mean = baseline_profile.timing.mean_ns as f64;
    let current_mean = current_profile.timing.mean_ns as f64;
    let diff_pct = if baseline_mean > 0.0 {
        (current_mean - baseline_mean) / baseline_mean * 100.0
    } else {
        0.0
    };

    println!();
    if diff_pct.abs() < threshold {
        println!(
            "✓ No significant change ({:.1}% within threshold)",
            diff_pct
        );
    } else if diff_pct > 0.0 {
        println!("⚠ REGRESSION: {:.1}% slower", diff_pct);
    } else {
        println!("✓ IMPROVEMENT: {:.1}% faster", -diff_pct);
    }

    Ok(())
}

/// Compare two timing stats and display the difference.
fn compare_timing(baseline: &TimingStats, current: &TimingStats, threshold: f64, indent: &str) {
    let format_diff = |baseline_ns: u64, current_ns: u64| -> String {
        let baseline = baseline_ns as f64;
        let current = current_ns as f64;
        if baseline == 0.0 {
            return format!("{:>12.3?} (new)", Duration::from_nanos(current_ns));
        }
        let diff_pct = (current - baseline) / baseline * 100.0;
        let marker = if diff_pct.abs() < threshold {
            " "
        } else if diff_pct > 0.0 {
            "+"
        } else {
            ""
        };
        let color = if diff_pct.abs() < threshold {
            ""
        } else if diff_pct > 0.0 {
            "⚠ "
        } else {
            "✓ "
        };
        format!(
            "{}{:>12.3?} ({}{:.1}%)",
            color,
            Duration::from_nanos(current_ns),
            marker,
            diff_pct
        )
    };

    println!(
        "{indent}Mean:     {:>12.3?} -> {}",
        Duration::from_nanos(baseline.mean_ns),
        format_diff(baseline.mean_ns, current.mean_ns)
    );
    println!(
        "{indent}Median:   {:>12.3?} -> {}",
        Duration::from_nanos(baseline.median_ns),
        format_diff(baseline.median_ns, current.median_ns)
    );
    println!(
        "{indent}Min:      {:>12.3?} -> {}",
        Duration::from_nanos(baseline.min_ns),
        format_diff(baseline.min_ns, current.min_ns)
    );
    println!(
        "{indent}Max:      {:>12.3?} -> {}",
        Duration::from_nanos(baseline.max_ns),
        format_diff(baseline.max_ns, current.max_ns)
    );
}

/// Export metrics to file.
fn export(file: &Path, output: &Path, format: &str, verbose: bool) -> CliResult<()> {
    if !file.exists() {
        return Err(CliError::FileNotFound(file.to_path_buf()));
    }

    if verbose {
        println!(
            "Exporting {} to {} (format: {format})",
            file.display(),
            output.display()
        );
    }

    let profile = ProfileData::load(file)?;

    match format {
        "json" => export_json(&profile, output)?,
        "csv" => export_csv(&profile, output)?,
        "prometheus" => export_prometheus(&profile, output)?,
        "folded" => export_folded(&profile, output)?,
        _ => {
            return Err(CliError::InvalidInput(format!(
                "unknown export format: {format} (supported: json, csv, prometheus, folded)"
            )));
        }
    }

    println!("Exported to {}", output.display());
    Ok(())
}

/// Export profile as JSON.
fn export_json(profile: &ProfileData, output: &Path) -> CliResult<()> {
    profile.save(output)
}

/// Export profile as CSV.
fn export_csv(profile: &ProfileData, output: &Path) -> CliResult<()> {
    let mut csv = String::new();

    // Header
    csv.push_str("metric,operation,mean_ns,median_ns,min_ns,max_ns,std_dev_ns,samples\n");

    // Overall timing
    csv.push_str(&format!(
        "timing,overall,{},{},{},{},{},{}\n",
        profile.timing.mean_ns,
        profile.timing.median_ns,
        profile.timing.min_ns,
        profile.timing.max_ns,
        profile.timing.std_dev_ns,
        profile.timing.samples
    ));

    // Per-operation timing
    for (op, stats) in &profile.operations {
        csv.push_str(&format!(
            "timing,{},{},{},{},{},{},{}\n",
            op,
            stats.mean_ns,
            stats.median_ns,
            stats.min_ns,
            stats.max_ns,
            stats.std_dev_ns,
            stats.samples
        ));
    }

    std::fs::write(output, csv)?;
    Ok(())
}

/// Export profile as Prometheus metrics.
fn export_prometheus(profile: &ProfileData, output: &Path) -> CliResult<()> {
    let mut prom = String::new();
    let model = &profile.model_name;

    // Timing metrics
    prom.push_str(
        "# HELP hologram_inference_duration_nanoseconds Inference duration in nanoseconds\n",
    );
    prom.push_str("# TYPE hologram_inference_duration_nanoseconds summary\n");
    prom.push_str(&format!(
        "hologram_inference_duration_nanoseconds{{model=\"{model}\",quantile=\"0.5\"}} {}\n",
        profile.timing.median_ns
    ));
    prom.push_str(&format!(
        "hologram_inference_duration_nanoseconds{{model=\"{model}\",quantile=\"0.0\"}} {}\n",
        profile.timing.min_ns
    ));
    prom.push_str(&format!(
        "hologram_inference_duration_nanoseconds{{model=\"{model}\",quantile=\"1.0\"}} {}\n",
        profile.timing.max_ns
    ));
    prom.push_str(&format!(
        "hologram_inference_duration_nanoseconds_sum{{model=\"{model}\"}} {}\n",
        profile.timing.mean_ns * profile.timing.samples as u64
    ));
    prom.push_str(&format!(
        "hologram_inference_duration_nanoseconds_count{{model=\"{model}\"}} {}\n",
        profile.timing.samples
    ));

    // Memory metrics if available
    if let Some(mem) = &profile.memory {
        prom.push_str("\n# HELP hologram_model_size_bytes Model file size in bytes\n");
        prom.push_str("# TYPE hologram_model_size_bytes gauge\n");
        prom.push_str(&format!(
            "hologram_model_size_bytes{{model=\"{model}\"}} {}\n",
            mem.model_size
        ));
    }

    std::fs::write(output, prom)?;
    Ok(())
}

/// Export profile as folded stacks (for flamegraph generation).
fn export_folded(profile: &ProfileData, output: &Path) -> CliResult<()> {
    let mut folded = String::new();

    // Create folded stack format: path;path;... count
    if profile.operations.is_empty() {
        // Single entry for overall timing
        folded.push_str(&format!(
            "{} {}\n",
            profile.model_name, profile.timing.mean_ns
        ));
    } else {
        // Entry for each operation
        for (op, stats) in &profile.operations {
            folded.push_str(&format!(
                "{};{} {}\n",
                profile.model_name, op, stats.mean_ns
            ));
        }
    }

    std::fs::write(output, folded)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    // --- ProfileData tests ---

    #[test]
    fn test_profile_data_new() {
        let profile = ProfileData::new("test-model", 100, 1);
        assert_eq!(profile.model_name, "test-model");
        assert_eq!(profile.iterations, 100);
        assert_eq!(profile.batch_size, 1);
        assert_eq!(profile.version, ProfileData::CURRENT_VERSION);
    }

    #[test]
    fn test_profile_data_save_load_roundtrip() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("profile.json");

        let mut profile = ProfileData::new("test-model", 50, 2);
        profile.timing = TimingStats {
            mean_ns: 1000,
            median_ns: 950,
            min_ns: 800,
            max_ns: 1200,
            std_dev_ns: 100,
            samples: 50,
        };

        profile.save(&path).unwrap();
        let loaded = ProfileData::load(&path).unwrap();

        assert_eq!(loaded.model_name, "test-model");
        assert_eq!(loaded.timing.mean_ns, 1000);
        assert_eq!(loaded.timing.samples, 50);
    }

    #[test]
    fn test_profile_data_load_invalid() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("invalid.json");
        std::fs::write(&path, "not valid json").unwrap();

        let result = ProfileData::load(&path);
        assert!(result.is_err());
    }

    // --- TimingStats tests ---

    #[test]
    fn test_timing_stats_from_durations_empty() {
        let stats = TimingStats::from_durations(&[]);
        assert_eq!(stats.samples, 0);
        assert_eq!(stats.mean_ns, 0);
    }

    #[test]
    fn test_timing_stats_from_durations_single() {
        let durations = vec![Duration::from_nanos(1000)];
        let stats = TimingStats::from_durations(&durations);

        assert_eq!(stats.samples, 1);
        assert_eq!(stats.mean_ns, 1000);
        assert_eq!(stats.median_ns, 1000);
        assert_eq!(stats.min_ns, 1000);
        assert_eq!(stats.max_ns, 1000);
    }

    #[test]
    fn test_timing_stats_from_durations_multiple() {
        let durations = vec![
            Duration::from_nanos(100),
            Duration::from_nanos(200),
            Duration::from_nanos(300),
            Duration::from_nanos(400),
            Duration::from_nanos(500),
        ];
        let stats = TimingStats::from_durations(&durations);

        assert_eq!(stats.samples, 5);
        assert_eq!(stats.mean_ns, 300);
        assert_eq!(stats.median_ns, 300);
        assert_eq!(stats.min_ns, 100);
        assert_eq!(stats.max_ns, 500);
    }

    #[test]
    fn test_timing_stats_mean_median_accessors() {
        let stats = TimingStats {
            mean_ns: 1000,
            median_ns: 950,
            min_ns: 800,
            max_ns: 1200,
            std_dev_ns: 100,
            samples: 10,
        };

        assert_eq!(stats.mean(), Duration::from_nanos(1000));
        assert_eq!(stats.median(), Duration::from_nanos(950));
    }

    // --- profile() tests ---

    #[test]
    fn test_profile_file_not_found() {
        let result = profile(Path::new("/nonexistent/profile.json"), "text", false);
        assert!(result.is_err());
    }

    #[test]
    fn test_profile_text_format() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("profile.json");
        let profile = ProfileData::new("test", 10, 1);
        profile.save(&path).unwrap();

        let result = super::profile(&path, "text", false);
        assert!(result.is_ok());
    }

    #[test]
    fn test_profile_json_format() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("profile.json");
        let profile = ProfileData::new("test", 10, 1);
        profile.save(&path).unwrap();

        let result = super::profile(&path, "json", false);
        assert!(result.is_ok());
    }

    #[test]
    fn test_profile_flamegraph_not_implemented() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("profile.json");
        let profile = ProfileData::new("test", 10, 1);
        profile.save(&path).unwrap();

        let result = super::profile(&path, "flamegraph", false);
        assert!(result.is_err());
    }

    #[test]
    fn test_profile_invalid_format() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("profile.json");
        let profile = ProfileData::new("test", 10, 1);
        profile.save(&path).unwrap();

        let result = super::profile(&path, "invalid", false);
        assert!(result.is_err());
    }

    // --- memory() tests ---

    #[test]
    fn test_memory_file_not_found() {
        let result = memory(Path::new("/nonexistent/model.holb"), false);
        assert!(result.is_err());
    }

    #[test]
    fn test_memory_small_file() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("tiny.holb");
        std::fs::write(&path, [0u8; 2]).unwrap();

        let result = memory(&path, false);
        assert!(result.is_ok());
    }

    #[test]
    fn test_memory_unknown_format() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("unknown.bin");
        std::fs::write(&path, b"JUNK1234567890").unwrap();

        let result = memory(&path, false);
        assert!(result.is_ok());
    }

    // --- compare() tests ---

    #[test]
    fn test_compare_baseline_not_found() {
        let dir = tempdir().unwrap();
        let current = dir.path().join("current.json");
        let profile = ProfileData::new("test", 10, 1);
        profile.save(&current).unwrap();

        let result = compare(Path::new("/nonexistent.json"), &current, 5.0, false);
        assert!(result.is_err());
    }

    #[test]
    fn test_compare_current_not_found() {
        let dir = tempdir().unwrap();
        let baseline = dir.path().join("baseline.json");
        let profile = ProfileData::new("test", 10, 1);
        profile.save(&baseline).unwrap();

        let result = compare(&baseline, Path::new("/nonexistent.json"), 5.0, false);
        assert!(result.is_err());
    }

    #[test]
    fn test_compare_valid_profiles() {
        let dir = tempdir().unwrap();

        let mut baseline = ProfileData::new("test", 10, 1);
        baseline.timing = TimingStats {
            mean_ns: 1000,
            median_ns: 950,
            min_ns: 800,
            max_ns: 1200,
            std_dev_ns: 100,
            samples: 10,
        };
        let baseline_path = dir.path().join("baseline.json");
        baseline.save(&baseline_path).unwrap();

        let mut current = ProfileData::new("test", 10, 1);
        current.timing = TimingStats {
            mean_ns: 1050,
            median_ns: 1000,
            min_ns: 850,
            max_ns: 1250,
            std_dev_ns: 100,
            samples: 10,
        };
        let current_path = dir.path().join("current.json");
        current.save(&current_path).unwrap();

        let result = compare(&baseline_path, &current_path, 5.0, false);
        assert!(result.is_ok());
    }

    // --- export() tests ---

    #[test]
    fn test_export_file_not_found() {
        let dir = tempdir().unwrap();
        let output = dir.path().join("output.json");

        let result = export(Path::new("/nonexistent.json"), &output, "json", false);
        assert!(result.is_err());
    }

    #[test]
    fn test_export_json() {
        let dir = tempdir().unwrap();
        let input = dir.path().join("profile.json");
        let output = dir.path().join("output.json");

        let profile = ProfileData::new("test", 10, 1);
        profile.save(&input).unwrap();

        let result = export(&input, &output, "json", false);
        assert!(result.is_ok());
        assert!(output.exists());
    }

    #[test]
    fn test_export_csv() {
        let dir = tempdir().unwrap();
        let input = dir.path().join("profile.json");
        let output = dir.path().join("output.csv");

        let mut profile = ProfileData::new("test", 10, 1);
        profile.timing = TimingStats {
            mean_ns: 1000,
            median_ns: 950,
            min_ns: 800,
            max_ns: 1200,
            std_dev_ns: 100,
            samples: 10,
        };
        profile.save(&input).unwrap();

        let result = export(&input, &output, "csv", false);
        assert!(result.is_ok());

        let csv = std::fs::read_to_string(&output).unwrap();
        assert!(csv.contains("metric,operation,mean_ns"));
        assert!(csv.contains("timing,overall,1000"));
    }

    #[test]
    fn test_export_prometheus() {
        let dir = tempdir().unwrap();
        let input = dir.path().join("profile.json");
        let output = dir.path().join("metrics.prom");

        let profile = ProfileData::new("test-model", 10, 1);
        profile.save(&input).unwrap();

        let result = export(&input, &output, "prometheus", false);
        assert!(result.is_ok());

        let prom = std::fs::read_to_string(&output).unwrap();
        assert!(prom.contains("hologram_inference_duration_nanoseconds"));
        assert!(prom.contains("test-model"));
    }

    #[test]
    fn test_export_folded() {
        let dir = tempdir().unwrap();
        let input = dir.path().join("profile.json");
        let output = dir.path().join("folded.txt");

        let mut profile = ProfileData::new("test-model", 10, 1);
        profile.operations.insert(
            "MatMul".to_string(),
            TimingStats {
                mean_ns: 500,
                median_ns: 480,
                min_ns: 400,
                max_ns: 600,
                std_dev_ns: 50,
                samples: 10,
            },
        );
        profile.save(&input).unwrap();

        let result = export(&input, &output, "folded", false);
        assert!(result.is_ok());

        let folded = std::fs::read_to_string(&output).unwrap();
        assert!(folded.contains("test-model;MatMul 500"));
    }

    #[test]
    fn test_export_invalid_format() {
        let dir = tempdir().unwrap();
        let input = dir.path().join("profile.json");
        let output = dir.path().join("output.xyz");

        let profile = ProfileData::new("test", 10, 1);
        profile.save(&input).unwrap();

        let result = export(&input, &output, "invalid", false);
        assert!(result.is_err());
    }

    // --- format_timestamp tests ---

    #[test]
    fn test_format_timestamp() {
        let ts = format_timestamp(0);
        assert!(ts.contains("1970"));

        let ts = format_timestamp(1704067200); // 2024-01-01 00:00:00 UTC approx
        assert!(ts.contains("UTC"));
    }

    // --- MemoryStats tests ---

    #[test]
    fn test_memory_stats_default() {
        let stats = MemoryStats::default();
        assert_eq!(stats.model_size, 0);
        assert_eq!(stats.graph_size, 0);
        assert_eq!(stats.weights_size, 0);
    }
}
