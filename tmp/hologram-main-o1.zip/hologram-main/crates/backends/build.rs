use std::env;
use std::fs;
use std::path::Path;

fn main() {
    let shell_path =
        Path::new(env!("CARGO_MANIFEST_DIR")).join("../../descriptors/shells/isa.shell");

    println!("cargo:rerun-if-changed={}", shell_path.display());

    let input = fs::read_to_string(&shell_path)
        .unwrap_or_else(|e| panic!("failed to read {}: {e}", shell_path.display()));

    let shell = hologram_shell::parse_shell(&input)
        .unwrap_or_else(|e| panic!("failed to parse isa.shell: {e}"));

    let out_dir = env::var_os("OUT_DIR").unwrap();

    // Generate the InstructionDispatcher trait
    let trait_code = hologram_shell::emit_isa::emit_dispatcher_trait(&shell);
    fs::write(
        Path::new(&out_dir).join("generated_dispatcher_trait.rs"),
        format!("// Auto-generated from isa.shell — do not edit.\n\n{trait_code}"),
    )
    .unwrap();

    // Generate the ExecuteOn match block
    let match_code = hologram_shell::emit_isa::emit_execute_on(&shell);
    fs::write(
        Path::new(&out_dir).join("generated_execute_on.rs"),
        format!("// Auto-generated from isa.shell — do not edit.\n\n{match_code}"),
    )
    .unwrap();

    // Generate the CPU dispatcher impl (build.rs wraps with correct impl header)
    let impl_code = hologram_shell::emit_isa::emit_dispatcher_impl(&shell);
    fs::write(
        Path::new(&out_dir).join("generated_dispatcher_impl.rs"),
        format!(
            "// Auto-generated from isa.shell — do not edit.\n\n\
             impl InstructionDispatcher for ExecutionContext<'_> {{\n\
             {impl_code}\n\
             }}"
        ),
    )
    .unwrap();

    // Generate the kernel classification function
    let kernel_code = hologram_shell::emit_isa::emit_kernel_classify(&shell);
    fs::write(
        Path::new(&out_dir).join("generated_kernel_classify.rs"),
        format!("// Auto-generated from isa.shell — do not edit.\n\n{kernel_code}"),
    )
    .unwrap();
}
