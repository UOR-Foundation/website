//! Actual CUDA-based GPU implementation for NVIDIA GPUs.
//!
//! This module uses cudarc for GPU acceleration. It requires:
//! - Linux or Windows operating system
//! - NVIDIA GPU with CUDA support
//! - CUDA SDK installed

use crate::{
    BackendError, BackendType, BufferHandle, ComputeBackend, LaunchConfig, ProgramBackend,
};
use cudarc::driver::{
    CudaDevice, CudaSlice, DevicePtr, LaunchAsync, LaunchConfig as CudaLaunchConfig,
};
use cudarc::nvrtc::Ptx;
use hologram_isa::{Program, Type};
use rustc_hash::FxHashMap;
use std::sync::Arc;

/// CUDA kernel source for matrix multiplication (naive).
const MATMUL_KERNEL: &str = r#"
extern "C" __global__ void matmul(
    const float* __restrict__ a,
    const float* __restrict__ b,
    float* __restrict__ c,
    unsigned int m,
    unsigned int n,
    unsigned int k,
    unsigned int lda,
    unsigned int ldb,
    unsigned int ldc
) {
    unsigned int row = blockIdx.x * blockDim.x + threadIdx.x;
    unsigned int col = blockIdx.y * blockDim.y + threadIdx.y;

    if (row < m && col < n) {
        float sum = 0.0f;
        for (unsigned int i = 0; i < k; i++) {
            sum += a[row * lda + i] * b[i * ldb + col];
        }
        c[row * ldc + col] = sum;
    }
}
"#;

/// CUDA kernel source for tiled matrix multiplication.
const MATMUL_TILED_KERNEL: &str = r#"
#define TILE_SIZE 16

extern "C" __global__ void matmul_tiled(
    const float* __restrict__ a,
    const float* __restrict__ b,
    float* __restrict__ c,
    unsigned int m,
    unsigned int n,
    unsigned int k,
    unsigned int lda,
    unsigned int ldb,
    unsigned int ldc
) {
    __shared__ float tile_a[TILE_SIZE][TILE_SIZE];
    __shared__ float tile_b[TILE_SIZE][TILE_SIZE];

    unsigned int row = blockIdx.x * blockDim.x + threadIdx.x;
    unsigned int col = blockIdx.y * blockDim.y + threadIdx.y;
    unsigned int local_row = threadIdx.x;
    unsigned int local_col = threadIdx.y;

    float sum = 0.0f;
    unsigned int num_tiles = (k + TILE_SIZE - 1) / TILE_SIZE;

    for (unsigned int t = 0; t < num_tiles; t++) {
        // Load tile of A
        unsigned int a_col = t * TILE_SIZE + local_col;
        if (row < m && a_col < k) {
            tile_a[local_row][local_col] = a[row * lda + a_col];
        } else {
            tile_a[local_row][local_col] = 0.0f;
        }

        // Load tile of B
        unsigned int b_row = t * TILE_SIZE + local_row;
        if (b_row < k && col < n) {
            tile_b[local_row][local_col] = b[b_row * ldb + col];
        } else {
            tile_b[local_row][local_col] = 0.0f;
        }

        __syncthreads();

        // Compute partial dot product
        for (unsigned int i = 0; i < TILE_SIZE; i++) {
            sum += tile_a[local_row][i] * tile_b[i][local_col];
        }

        __syncthreads();
    }

    if (row < m && col < n) {
        c[row * ldc + col] = sum;
    }
}
"#;

/// CUDA kernel for vector addition.
const VECTOR_ADD_KERNEL: &str = r#"
extern "C" __global__ void vector_add(
    const unsigned char* __restrict__ a,
    const unsigned char* __restrict__ b,
    unsigned char* __restrict__ dst,
    unsigned int count
) {
    unsigned int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < count) {
        dst[idx] = a[idx] + b[idx];
    }
}
"#;

/// CUDA kernel for vector multiplication.
const VECTOR_MUL_KERNEL: &str = r#"
extern "C" __global__ void vector_mul(
    const unsigned char* __restrict__ a,
    const unsigned char* __restrict__ b,
    unsigned char* __restrict__ dst,
    unsigned int count
) {
    unsigned int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < count) {
        dst[idx] = a[idx] * b[idx];
    }
}
"#;

use super::gpu_constants::{GPU_TILE_SIZE, TILED_MATMUL_THRESHOLD};

/// GPU buffer wrapper.
struct GpuBuffer {
    buffer: CudaSlice<u8>,
    size: usize,
}

/// CUDA GPU backend for NVIDIA GPUs.
///
/// Uses cudarc for GPU acceleration.
pub struct CudaBackend {
    device: Arc<CudaDevice>,
    device_id: u32,
    device_name: String,
    buffers: FxHashMap<u64, GpuBuffer>,
    next_handle: u64,
    matmul_ptx: Ptx,
    matmul_tiled_ptx: Ptx,
    vector_add_ptx: Ptx,
    vector_mul_ptx: Ptx,
}

impl CudaBackend {
    /// Create a new CUDA backend using the default device (device 0).
    #[must_use]
    pub fn new() -> Self {
        Self::with_device(0)
    }

    /// Create a new CUDA backend for a specific device.
    #[must_use]
    pub fn with_device(device_id: u32) -> Self {
        let device = CudaDevice::new(device_id as usize).expect("Failed to create CUDA device");
        let device_name = device
            .name()
            .unwrap_or_else(|_| "Unknown CUDA Device".to_string());

        // Compile kernels
        let matmul_ptx =
            cudarc::nvrtc::compile_ptx(MATMUL_KERNEL).expect("Failed to compile matmul kernel");
        let matmul_tiled_ptx = cudarc::nvrtc::compile_ptx(MATMUL_TILED_KERNEL)
            .expect("Failed to compile tiled matmul kernel");
        let vector_add_ptx = cudarc::nvrtc::compile_ptx(VECTOR_ADD_KERNEL)
            .expect("Failed to compile vector_add kernel");
        let vector_mul_ptx = cudarc::nvrtc::compile_ptx(VECTOR_MUL_KERNEL)
            .expect("Failed to compile vector_mul kernel");

        // Load modules
        device
            .load_ptx(matmul_ptx.clone(), "matmul", &["matmul"])
            .expect("Failed to load matmul module");
        device
            .load_ptx(matmul_tiled_ptx.clone(), "matmul_tiled", &["matmul_tiled"])
            .expect("Failed to load tiled matmul module");
        device
            .load_ptx(vector_add_ptx.clone(), "vector_add", &["vector_add"])
            .expect("Failed to load vector_add module");
        device
            .load_ptx(vector_mul_ptx.clone(), "vector_mul", &["vector_mul"])
            .expect("Failed to load vector_mul module");

        Self {
            device,
            device_id,
            device_name,
            buffers: FxHashMap::default(),
            next_handle: 0,
            matmul_ptx,
            matmul_tiled_ptx,
            vector_add_ptx,
            vector_mul_ptx,
        }
    }

    /// Check if CUDA is available on this system.
    #[must_use]
    pub fn is_available() -> bool {
        CudaDevice::new(0).is_ok()
    }

    /// Get the number of available CUDA devices.
    #[must_use]
    pub fn device_count() -> u32 {
        cudarc::driver::result::device::get_count().unwrap_or(0) as u32
    }

    /// Get the device ID this backend is using.
    #[must_use]
    pub const fn device_id(&self) -> u32 {
        self.device_id
    }

    /// Get the device name.
    #[must_use]
    pub fn device_name(&self) -> &str {
        &self.device_name
    }

    fn next_buffer_handle(&mut self) -> BufferHandle {
        let handle = BufferHandle::new(self.next_handle);
        self.next_handle += 1;
        handle
    }

    /// Read buffer data from GPU to CPU.
    fn read_buffer(&self, handle: BufferHandle) -> Result<Vec<u8>, BackendError> {
        let gpu_buf = self
            .buffers
            .get(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;

        let mut host_data = vec![0u8; gpu_buf.size];
        self.device
            .dtoh_sync_copy_into(&gpu_buf.buffer, &mut host_data)
            .map_err(|e| BackendError::execution(format!("Failed to copy from device: {}", e)))?;
        Ok(host_data)
    }

    /// Get buffer data as f32 slice.
    #[cfg(test)]
    fn get_buffer_f32(&self, handle: BufferHandle) -> Result<Vec<f32>, BackendError> {
        let data = self.read_buffer(handle)?;
        if data.len() % 4 != 0 {
            return Err(BackendError::buffer("Buffer size not aligned to f32"));
        }
        let floats: Vec<f32> = data
            .chunks_exact(4)
            .map(|chunk| f32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]))
            .collect();
        Ok(floats)
    }
}

impl Default for CudaBackend {
    fn default() -> Self {
        Self::new()
    }
}

impl ProgramBackend for CudaBackend {
    fn backend_type(&self) -> BackendType {
        BackendType::Cuda
    }

    fn execute_program(
        &mut self,
        program: &Program,
        _config: &LaunchConfig,
    ) -> Result<(), BackendError> {
        if program.instructions().is_empty() {
            return Ok(());
        }
        // Full program execution would require compiling instructions to PTX
        // For now, individual operations use dedicated kernels
        Ok(())
    }

    fn allocate_buffer(&mut self, size: usize) -> Result<BufferHandle, BackendError> {
        let handle = self.next_buffer_handle();

        let buffer = self
            .device
            .alloc_zeros::<u8>(size)
            .map_err(|e| BackendError::buffer(format!("Failed to allocate CUDA buffer: {}", e)))?;

        self.buffers.insert(handle.id(), GpuBuffer { buffer, size });
        Ok(handle)
    }

    fn free_buffer(&mut self, handle: BufferHandle) -> Result<(), BackendError> {
        self.buffers
            .remove(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;
        Ok(())
    }

    fn copy_to_buffer(&mut self, handle: BufferHandle, data: &[u8]) -> Result<(), BackendError> {
        let gpu_buf = self
            .buffers
            .get_mut(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;

        if data.len() > gpu_buf.size {
            return Err(BackendError::buffer("Data exceeds buffer size"));
        }

        self.device
            .htod_sync_copy_into(data, &mut gpu_buf.buffer)
            .map_err(|e| BackendError::execution(format!("Failed to copy to device: {}", e)))?;
        Ok(())
    }

    fn copy_from_buffer(&self, handle: BufferHandle, data: &mut [u8]) -> Result<(), BackendError> {
        let read_data = self.read_buffer(handle)?;
        if data.len() > read_data.len() {
            return Err(BackendError::buffer("Request exceeds buffer size"));
        }
        data.copy_from_slice(&read_data[..data.len()]);
        Ok(())
    }

    fn buffer_size(&self, handle: BufferHandle) -> Result<usize, BackendError> {
        self.buffers
            .get(&handle.id())
            .map(|b| b.size)
            .ok_or(BackendError::InvalidHandle(handle))
    }

    fn synchronize(&mut self) -> Result<(), BackendError> {
        self.device
            .synchronize()
            .map_err(|e| BackendError::sync(format!("CUDA synchronize failed: {}", e)))?;
        Ok(())
    }

    fn get_buffer_ptr(&self, _handle: BufferHandle) -> Option<*mut u8> {
        // GPU memory is not directly accessible from CPU
        None
    }
}

impl ComputeBackend for CudaBackend {
    fn fma_scalar_crt_batch(
        &self,
        target: &mut [u8],
        a: &[u8],
        k: u64,
    ) -> Result<(), BackendError> {
        // CPU implementation for this simple operation
        for i in 0..target.len().min(a.len()) {
            target[i] = ((a[i] as u64).wrapping_mul(k) % 256) as u8;
        }
        Ok(())
    }

    fn matmul(
        &mut self,
        c: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        params: &crate::MatMulParams,
    ) -> Result<(), BackendError> {
        if params.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "matmul only supports F32, got {:?}",
                params.dtype
            )));
        }

        let a_buf = &self
            .buffers
            .get(&a.id())
            .ok_or(BackendError::InvalidHandle(a))?
            .buffer;
        let b_buf = &self
            .buffers
            .get(&b.id())
            .ok_or(BackendError::InvalidHandle(b))?
            .buffer;
        let c_buf = &self
            .buffers
            .get(&c.id())
            .ok_or(BackendError::InvalidHandle(c))?
            .buffer;

        let m = params.m;
        let n = params.n;
        let k = params.k;
        let lda = if params.trans_a { m } else { k };
        let ldb = if params.trans_b { k } else { n };
        let ldc = n;

        // Choose kernel based on matrix size
        let work_size = m.saturating_mul(n).saturating_mul(k);
        let use_tiled = work_size >= TILED_MATMUL_THRESHOLD && !params.trans_a && !params.trans_b;

        let kernel_name = if use_tiled { "matmul_tiled" } else { "matmul" };
        let func = self
            .device
            .get_func(kernel_name, kernel_name)
            .ok_or_else(|| BackendError::execution(format!("Kernel {} not found", kernel_name)))?;

        let block_size = (GPU_TILE_SIZE, GPU_TILE_SIZE, 1);
        let grid_size = (m.div_ceil(GPU_TILE_SIZE), n.div_ceil(GPU_TILE_SIZE), 1);

        let cfg = CudaLaunchConfig {
            grid_dim: grid_size,
            block_dim: block_size,
            shared_mem_bytes: 0,
        };

        // Reinterpret buffers as f32
        let a_ptr = a_buf.device_ptr();
        let b_ptr = b_buf.device_ptr();
        let c_ptr = c_buf.device_ptr();

        unsafe {
            func.launch(cfg, (a_ptr, b_ptr, c_ptr, m, n, k, lda, ldb, ldc))
                .map_err(|e| BackendError::execution(format!("Kernel launch failed: {}", e)))?;
        }

        self.device
            .synchronize()
            .map_err(|e| BackendError::sync(format!("Synchronize failed: {}", e)))?;

        Ok(())
    }

    fn batch_matmul(
        &mut self,
        c: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        batch: u32,
        params: &crate::MatMulParams,
    ) -> Result<(), BackendError> {
        // For simplicity, use CPU fallback for batch matmul
        // A proper implementation would use cuBLAS batched GEMM
        if params.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "batch_matmul only supports F32, got {:?}",
                params.dtype
            )));
        }

        let a_data = self.read_buffer(a)?;
        let b_data = self.read_buffer(b)?;
        let mut c_data = self.read_buffer(c)?;

        let m = params.m as usize;
        let k = params.k as usize;
        let n = params.n as usize;

        let a_f32: Vec<f32> = a_data
            .chunks_exact(4)
            .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
            .collect();
        let b_f32: Vec<f32> = b_data
            .chunks_exact(4)
            .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
            .collect();
        let mut c_f32: Vec<f32> = c_data
            .chunks_exact(4)
            .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
            .collect();

        crate::backends::cpu::compute::cpu_batch_matmul_f32(
            &mut c_f32,
            &a_f32,
            &b_f32,
            batch as usize,
            params,
        );

        // Write back
        let c_bytes: Vec<u8> = c_f32.iter().flat_map(|f| f.to_le_bytes()).collect();
        let gpu_buf = self
            .buffers
            .get_mut(&c.id())
            .ok_or(BackendError::InvalidHandle(c))?;
        self.device
            .htod_sync_copy_into(&c_bytes, &mut gpu_buf.buffer)
            .map_err(|e| BackendError::execution(format!("Failed to copy to device: {}", e)))?;

        Ok(())
    }

    fn conv2d(
        &mut self,
        output: BufferHandle,
        input: BufferHandle,
        kernel: BufferHandle,
        bias: BufferHandle,
        params: &crate::Conv2DParams,
    ) -> Result<(), BackendError> {
        // Use CPU fallback for conv2d
        if params.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "conv2d only supports F32, got {:?}",
                params.dtype
            )));
        }

        let input_data = self.read_buffer(input)?;
        let kernel_data = self.read_buffer(kernel)?;
        let bias_data = if !bias.is_null() {
            Some(self.read_buffer(bias)?)
        } else {
            None
        };

        let input_f32: Vec<f32> = input_data
            .chunks_exact(4)
            .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
            .collect();
        let kernel_f32: Vec<f32> = kernel_data
            .chunks_exact(4)
            .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
            .collect();
        let bias_f32: Option<Vec<f32>> = bias_data.map(|b| {
            b.chunks_exact(4)
                .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
                .collect()
        });

        let out_dims = params.output_dims();
        let out_size = out_dims.iter().map(|&d| d as usize).product::<usize>();
        let mut output_f32 = vec![0.0f32; out_size];

        crate::backends::cpu::compute::cpu_conv2d_f32(
            &mut output_f32,
            &input_f32,
            &kernel_f32,
            bias_f32.as_deref(),
            params,
        );

        // Write result back
        let output_bytes: Vec<u8> = output_f32.iter().flat_map(|f| f.to_le_bytes()).collect();
        let gpu_buf = self
            .buffers
            .get_mut(&output.id())
            .ok_or(BackendError::InvalidHandle(output))?;
        self.device
            .htod_sync_copy_into(&output_bytes, &mut gpu_buf.buffer)
            .map_err(|e| BackendError::execution(format!("Failed to copy to device: {}", e)))?;

        Ok(())
    }

    fn vector_add(
        &mut self,
        dst: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        count: usize,
    ) -> Result<(), BackendError> {
        let a_buf = &self
            .buffers
            .get(&a.id())
            .ok_or(BackendError::InvalidHandle(a))?
            .buffer;
        let b_buf = &self
            .buffers
            .get(&b.id())
            .ok_or(BackendError::InvalidHandle(b))?
            .buffer;
        let dst_buf = &self
            .buffers
            .get(&dst.id())
            .ok_or(BackendError::InvalidHandle(dst))?
            .buffer;

        let func = self
            .device
            .get_func("vector_add", "vector_add")
            .ok_or_else(|| BackendError::execution("vector_add kernel not found".to_string()))?;

        let block_size = (256, 1, 1);
        let grid_size = (count.div_ceil(256) as u32, 1, 1);

        let cfg = CudaLaunchConfig {
            grid_dim: grid_size,
            block_dim: block_size,
            shared_mem_bytes: 0,
        };

        unsafe {
            func.launch(
                cfg,
                (
                    a_buf.device_ptr(),
                    b_buf.device_ptr(),
                    dst_buf.device_ptr(),
                    count as u32,
                ),
            )
            .map_err(|e| BackendError::execution(format!("Kernel launch failed: {}", e)))?;
        }

        self.device
            .synchronize()
            .map_err(|e| BackendError::sync(format!("Synchronize failed: {}", e)))?;

        Ok(())
    }

    fn vector_mul(
        &mut self,
        dst: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        count: usize,
    ) -> Result<(), BackendError> {
        let a_buf = &self
            .buffers
            .get(&a.id())
            .ok_or(BackendError::InvalidHandle(a))?
            .buffer;
        let b_buf = &self
            .buffers
            .get(&b.id())
            .ok_or(BackendError::InvalidHandle(b))?
            .buffer;
        let dst_buf = &self
            .buffers
            .get(&dst.id())
            .ok_or(BackendError::InvalidHandle(dst))?
            .buffer;

        let func = self
            .device
            .get_func("vector_mul", "vector_mul")
            .ok_or_else(|| BackendError::execution("vector_mul kernel not found".to_string()))?;

        let block_size = (256, 1, 1);
        let grid_size = (count.div_ceil(256) as u32, 1, 1);

        let cfg = CudaLaunchConfig {
            grid_dim: grid_size,
            block_dim: block_size,
            shared_mem_bytes: 0,
        };

        unsafe {
            func.launch(
                cfg,
                (
                    a_buf.device_ptr(),
                    b_buf.device_ptr(),
                    dst_buf.device_ptr(),
                    count as u32,
                ),
            )
            .map_err(|e| BackendError::execution(format!("Kernel launch failed: {}", e)))?;
        }

        self.device
            .synchronize()
            .map_err(|e| BackendError::sync(format!("Synchronize failed: {}", e)))?;

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cuda_backend_new() {
        if !CudaBackend::is_available() {
            eprintln!("Skipping test: CUDA not available");
            return;
        }
        let backend = CudaBackend::new();
        assert_eq!(backend.backend_type(), BackendType::Cuda);
    }

    #[test]
    fn test_cuda_is_gpu() {
        assert!(BackendType::Cuda.is_gpu());
    }

    #[test]
    fn test_cuda_allocate_buffer() {
        if !CudaBackend::is_available() {
            eprintln!("Skipping test: CUDA not available");
            return;
        }
        let mut backend = CudaBackend::new();
        let handle = backend.allocate_buffer(1024).unwrap();
        assert_eq!(backend.buffer_size(handle).unwrap(), 1024);
    }

    #[test]
    fn test_cuda_copy_roundtrip() {
        if !CudaBackend::is_available() {
            eprintln!("Skipping test: CUDA not available");
            return;
        }
        let mut backend = CudaBackend::new();
        let handle = backend.allocate_buffer(1024).unwrap();

        let data = vec![10u8, 20, 30, 40, 50];
        backend.copy_to_buffer(handle, &data).unwrap();

        let mut read_data = vec![0u8; 5];
        backend.copy_from_buffer(handle, &mut read_data).unwrap();
        assert_eq!(read_data, data);
    }

    #[test]
    fn test_cuda_matmul() {
        if !CudaBackend::is_available() {
            eprintln!("Skipping test: CUDA not available");
            return;
        }
        let mut backend = CudaBackend::new();

        // 2x3 * 3x2 = 2x2
        let a: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0];
        let b: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0];

        let a_bytes: Vec<u8> = a.iter().flat_map(|f| f.to_le_bytes()).collect();
        let b_bytes: Vec<u8> = b.iter().flat_map(|f| f.to_le_bytes()).collect();

        let a_handle = backend.allocate_buffer(a_bytes.len()).unwrap();
        let b_handle = backend.allocate_buffer(b_bytes.len()).unwrap();
        let c_handle = backend.allocate_buffer(4 * 4).unwrap();

        backend.copy_to_buffer(a_handle, &a_bytes).unwrap();
        backend.copy_to_buffer(b_handle, &b_bytes).unwrap();

        let params = crate::MatMulParams {
            m: 2,
            n: 2,
            k: 3,
            dtype: Type::F32,
            alpha: 1.0,
            beta: 0.0,
            trans_a: false,
            trans_b: false,
        };

        backend
            .matmul(c_handle, a_handle, b_handle, &params)
            .unwrap();

        let c_data = backend.get_buffer_f32(c_handle).unwrap();
        assert!((c_data[0] - 22.0).abs() < 0.01);
        assert!((c_data[1] - 28.0).abs() < 0.01);
        assert!((c_data[2] - 49.0).abs() < 0.01);
        assert!((c_data[3] - 64.0).abs() < 0.01);
    }
}
