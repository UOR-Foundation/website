# Agents

This document defines the agent roles and workflows for developing hologram.

## Context Chain

Agents working on this project must read files in this order before starting work:

1. `CLAUDE.md` -- project rules, architecture, commands, conventions
2. `SPRINT.md` -- current tasks and priorities
3. `specs/FUTURE_PLANS.md` -- development direction and constraints
4. `specs/project.md` -- full conceptual definition (hologram framework)
5. `prior-reference/crates/` -- prior implementations (read-only reference, consult per task)

## Agent Roles

### Implementer

**Purpose:** Write new features and extend existing crates.

**Rules:**
- Read the target module and its tests before writing any code
- Implement full functionality -- no stubs, no TODOs, no placeholders
- Keep functions short (~15 lines max). If a function grows, decompose it using traits or helper functions.
- Use traits to define shared behavior. Default methods reduce boilerplate. Generic functions over trait bounds replace type-specific duplication.
- **Use the Builder pattern** for types with 3+ optional fields or complex construction. Builders provide fluent APIs and make construction intent explicit. See CLAUDE.md "Builder Pattern" section for implementation details.
- Use rayon (`par_iter`, `par_chunks`) for coarse-grained parallelism across independent work units
- Use SIMD intrinsics (`core::arch::x86_64`) for fine-grained vectorized hot paths behind `#[cfg(target_arch)]` guards
- 100% test coverage: unit tests (`#[cfg(test)]`), integration tests (`tests/`), doc tests on all public items. Every public function, every branch, every error path.
- Write Criterion benchmarks for every new public operation or hot-path function
- Run `just ci` before declaring any task complete
- Zero external dependencies in the `uor` crate
- All data structures must fit L1/L2 cache constraints
- **Single execution path: Backends ONLY in `hologram-backend`.** Never implement backend functionality (`execute_plan()`, ISA operation handlers) in `uor`. Hardware executors (`UorStep` implementations) live in `uor::arch` and are used BY backends, but are not themselves backends. See CLAUDE.md "Architectural Separation" section for full details.

**Workflow:**
1. Read `SPRINT.md` to identify the current task
2. **Move the task to "In Progress" in `SPRINT.md` before writing any code**
3. Read relevant source files to understand existing patterns
4. Check `prior-reference/crates/` for prior implementations of the same concept -- understand intent and edge cases, but do not copy code unless it already meets all Hard Rules
5. Read existing benchmarks in `crates/<crate>/benches/` to understand baseline performance
6. Implement the feature with minimal code
7. Write comprehensive tests (unit + end-to-end)
8. Write Criterion benchmarks -- measure the new operation and record the baseline
9. Run `cargo bench -p <crate>` to capture initial numbers
10. Run `just ci` -- fix until green
11. **Move the task to "Completed This Sprint" in `SPRINT.md`** (include in the same commit as the code)
12. Run `/commit`

### Reviewer

**Purpose:** Validate code quality, correctness, and adherence to project rules.

**Checklist:**
- [ ] All tests pass (`just ci`)
- [ ] No clippy warnings
- [ ] No TODOs, unimplemented!(), or placeholder code
- [ ] 100% test coverage -- every public function, branch, and error path has a test
- [ ] Doc tests on all public items
- [ ] Zero-copy contracts maintained (no heap allocation on hot paths)
- [ ] Data structures fit cache constraints
- [ ] Triadic invariant (T=3) preserved where applicable
- [ ] Bijection guarantee maintained where applicable
- [ ] Functions are short (~15 lines max). Large functions decomposed via traits or helpers.
- [ ] Shared behavior expressed as traits with default methods, not duplicated code
- [ ] Builder pattern used for types with 3+ optional fields or complex construction
- [ ] Parallelizable operations use rayon (coarse) or SIMD (fine-grained) with benchmarks for both paths
- [ ] No new external dependencies in `uor`
- [ ] Criterion benchmarks exist for every new public operation and hot-path function
- [ ] Benchmarks use `Throughput` and `black_box` correctly
- [ ] Conformance tiers defined where applicable (MINIMUM / OPTIMAL / THEORETICAL)
- [ ] `cargo bench` runs without errors
- [ ] No code copied verbatim from `prior-reference/` without meeting all Hard Rules
- [ ] `SPRINT.md` accurately reflects task status -- completed tasks moved to "Completed This Sprint", no stale "In Progress" entries

### Architect

**Purpose:** Plan new crates, define interfaces, and make structural decisions.

**Constraints:**
- Every backend must implement the ISA contract
- The compiler crate will enable parallelized layer execution
- All hot-path operations follow the zero-copy contract (see `specs/project.md` section "Zero-Copy Contract")
- Prefer the pi-F-lambda pipeline pattern for new computation paths
- Design for O(1) runtime -- pre-compute at build time
- Define conformance tiers (MINIMUM / OPTIMAL / THEORETICAL) for every performance-critical interface
- **Architectural boundary: `uor` contains hardware primitives, `hologram-backend` contains backends.** There is exactly ONE execution path. Backends live in `hologram-backend::backends/` and MAY use `uor::arch` executors internally, but `uor::arch` is NOT a backend. Never blur this boundary -- it prevents architectural confusion and maintains dependency direction.

**Outputs:**
- Updated `SPRINT.md` with new tasks -- every new task goes into "Backlog" with a task ID, description, and sprint grouping. Never add tasks without updating `SPRINT.md`.
- Sprint archive in `specs/sprints/<number>-<name>.md` when closing a sprint (see "Sprint Transitions" below)
- Interface definitions (traits) before implementation
- Architecture notes in `crates/<name>/docs/` for new crates
- Conformance tier constants for new performance-critical modules

## Task Lifecycle

```
SPRINT.md Backlog -> In Progress -> Implementation -> Benchmark -> just ci -> /commit -> Completed
```

1. Pick the highest-priority unblocked task from `SPRINT.md`
2. **Update `SPRINT.md`**: move the task from "Backlog" to "In Progress"
3. Follow the Implementer workflow (includes writing benchmarks)
4. Run `cargo bench -p <crate>` to record baseline numbers
5. **Update `SPRINT.md`**: move the task from "In Progress" to "Completed This Sprint"
6. Commit code and `SPRINT.md` together -- task status and code must stay in sync
7. Pick the next task

**`SPRINT.md` is the single source of truth.** Every task must be in exactly one section at all times: Backlog, In Progress, Completed This Sprint, or Blocked. If a task cannot proceed, move it to "Blocked" with a reason. Never leave a task in a stale section.

### Sprint Transitions

When all tasks in a sprint are completed (or remaining tasks are moved forward):

1. Create `specs/sprints/<number>-<name>.md` with the full sprint record:
   - Sprint number, name, and date range
   - All completed tasks (ID, title, summary)
   - Tasks moved to the next sprint or dropped, with reasons
   - Key decisions and notable metrics
2. Update `SPRINT.md`:
   - Clear the "Completed This Sprint" section
   - Add a one-line summary to "Sprint History" (e.g., `- **Sprint 1**: Clean Workspace -- 4 tasks completed.`)
   - Set up the new sprint's backlog under "Backlog"
3. Commit the archive and updated `SPRINT.md` together as a single atomic change

### Optimization Tasks

When optimizing an existing operation:

1. Run `cargo bench -p <crate> -- --save-baseline before` to capture current performance
2. Implement the optimization
3. Run `cargo bench -p <crate> -- --baseline before` to measure the delta
4. Include the before/after numbers in the commit message
