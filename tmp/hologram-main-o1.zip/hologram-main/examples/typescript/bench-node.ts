#!/usr/bin/env node
/**
 * Node.js WASM FFI Benchmarks (TypeScript)
 *
 * Measures FFI call overhead and throughput
 *
 * Build:
 *   just ffi-wasm-node
 *
 * Compile and run:
 *   npx tsc --outDir dist examples/javascript/bench-node.ts
 *   node dist/examples/javascript/bench-node.js
 */

import * as uor from '../../bindings/wasm/nodejs/uor_ffi.js';

const ITERATIONS: number = 1_000_000;
const WARMUP_ITERATIONS: number = 100_000;

function benchFunction(fn: () => void, name: string, iterations: number = ITERATIONS): number {
    // Warmup
    for (let i = 0; i < WARMUP_ITERATIONS; i++) {
        fn();
    }

    // Benchmark
    const start: bigint = process.hrtime.bigint();
    for (let i = 0; i < iterations; i++) {
        fn();
    }
    const end: bigint = process.hrtime.bigint();

    const totalNs: number = Number(end - start);
    const perCallNs: number = totalNs / iterations;
    const callsPerSecM: number = 1000.0 / perCallNs;

    console.log(`  ${name.padEnd(30)}: ${perCallNs.toFixed(2).padStart(8)} ns/call  (${callsPerSecM.toFixed(2).padStart(7)} M calls/sec)`);
    return perCallNs;
}

function main(): void {
    console.log('=== UOR Node.js WASM FFI Benchmarks ===\n');
    console.log('Target: < 10 ns per call');
    console.log(`Iterations: ${ITERATIONS.toLocaleString()} (after ${WARMUP_ITERATIONS.toLocaleString()} warmup)\n`);

    // Taxon Operations
    console.log('Taxon Operations:');
    benchFunction(() => uor.wasm_byte_to_braille(42), 'wasm_byte_to_braille');
    benchFunction(() => uor.wasm_byte_to_codepoint(42), 'wasm_byte_to_codepoint');
    benchFunction(() => uor.wasm_byte_to_domain(42), 'wasm_byte_to_domain');
    benchFunction(() => uor.wasm_byte_rank(42), 'wasm_byte_rank');

    // Ring Operations
    console.log('\nRing Operations:');
    benchFunction(() => uor.wasm_byte_succ(42), 'wasm_byte_succ');
    benchFunction(() => uor.wasm_byte_pred(42), 'wasm_byte_pred');
    benchFunction(() => uor.wasm_byte_not(42), 'wasm_byte_not');

    // View Operations
    console.log('\nView Operations:');
    const identity = new uor.WasmView();
    benchFunction(() => identity.apply(42), 'view_apply');

    // Batch Operations
    console.log('\nBatch Operations:');
    const data = new Uint8Array(1024);
    for (let i = 0; i < 1024; i++) {
        data[i] = i & 0xFF;
    }

    const batchIterations: number = ITERATIONS / 100;
    const batchNs: number = benchFunction(() => {
        identity.applySlice(data);
    }, 'view_applySlice (1KB)', batchIterations);

    const throughputMb: number = (1024.0 / batchNs) * 1000.0;
    console.log(`  Throughput: ${throughputMb.toFixed(2)} MB/sec`);

    // Cleanup
    identity.free();

    console.log('\n=== Benchmarks Complete ===');
}

main();
