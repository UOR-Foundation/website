//! CPU kernel implementations matching KernelFn signature.
//!
//! These kernels receive actual data pointers (pre-resolved by the executor)
//! and dispatch to SimdDispatcher methods for SIMD-accelerated execution.

use super::simd_dispatch::SimdDispatcher;
#[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
use super::simd_dispatch::{cpu_capability, SimdCapability};
use crate::plan::{KernelParams, LookupTables};
use crate::BackendError;
use hologram_lookup::fusion::activation::{
    FUSED_SIGMOID_RELU_U8, FUSED_SIGMOID_TANH_RELU_U8, FUSED_SIGMOID_TANH_U8, GELU_U8, RELU_U8,
    SIGMOID_U8, SILU_U8, TANH_U8,
};

#[cfg(all(
    feature = "instrumentation",
    target_arch = "x86_64",
    target_feature = "avx2"
))]
use hologram_telemetry::simd_path;
#[cfg(feature = "instrumentation")]
use hologram_telemetry::timed;

#[cfg(not(feature = "instrumentation"))]
#[allow(unused_macros)]
macro_rules! simd_path {
    ($level:expr) => {};
}

#[cfg(not(feature = "instrumentation"))]
#[allow(unused_macros)]
macro_rules! timed {
    ($name:expr, $block:expr) => {
        $block
    };
}

#[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
use core::arch::x86_64::{
    __m128i, __m256i, _mm256_cvtepu8_epi32, _mm256_i32gather_epi32, _mm256_storeu_si256,
    _mm_loadl_epi64,
};

// =============================================================================
// GEMM KERNELS
// =============================================================================

/// Standard GEMM kernel: C = alpha * A @ B + beta * C
///
/// # Arguments
/// * `inputs` - [A, B] actual data pointers (f32)
/// * `outputs` - [C] actual data pointer (f32)
/// * `params` - dims[0]=M, dims[1]=K, dims[2]=N, extra[0]=alpha bits, extra[1]=beta bits
pub fn gemm_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "GEMM kernel requires 2 inputs and 1 output",
        ));
    }

    let m = params.dims[0];
    let k = params.dims[1];
    let n = params.dims[2];

    // Validate dimensions - zero dimensions indicate a compiler bug
    if m == 0 || k == 0 || n == 0 {
        return Err(BackendError::invalid_config(format!(
            "GEMM kernel: invalid dimensions M={}, K={}, N={}. \
             Zero dimension indicates shape inference failed or symbolic dimension not resolved. \
             Check that MatMul input shapes are static or properly resolved at runtime.",
            m, k, n
        )));
    }

    // Validate dimensions are reasonable (prevent massive allocations from bogus dims)
    // 512K allows for seq_len=512 * hidden=512 = 262144 and larger models
    const MAX_GEMM_DIM: usize = 512 * 1024; // 512K - reasonable for large transformers
    if m > MAX_GEMM_DIM || k > MAX_GEMM_DIM || n > MAX_GEMM_DIM {
        return Err(BackendError::invalid_config(format!(
            "GEMM kernel: dimensions M={}, K={}, N={} exceed maximum {}. \
             This likely indicates a compiler bug with incorrect shape inference.",
            m, k, n, MAX_GEMM_DIM
        )));
    }

    // Extract alpha/beta from extra params (stored as f32 bits in usize)
    let alpha = f32::from_bits(params.extra[0] as u32);
    let beta = f32::from_bits(params.extra[1] as u32);

    // Create slices from actual pointers (zero-copy)
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, m * k) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, k * n) };
    let c = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, m * n) };

    // Debug logging for attention computation
    let a_nonzero = a.iter().filter(|&&x| x != 0.0).count();
    let b_nonzero = b.iter().filter(|&&x| x != 0.0).count();
    let a_range = (
        a.iter().copied().fold(f32::INFINITY, f32::min),
        a.iter().copied().fold(f32::NEG_INFINITY, f32::max),
    );
    let b_range = (
        b.iter().copied().fold(f32::INFINITY, f32::min),
        b.iter().copied().fold(f32::NEG_INFINITY, f32::max),
    );
    tracing::info!(
        "gemm_kernel_f32: M={}, K={}, N={}, alpha={:.4}, beta={:.4}, a_nonzero={}/{}, b_nonzero={}/{}, a_range=[{:.4e}, {:.4e}], b_range=[{:.4e}, {:.4e}]",
        m, k, n, alpha, beta, a_nonzero, m * k, b_nonzero, k * n, a_range.0, a_range.1, b_range.0, b_range.1
    );

    // Dispatch to SIMD kernel - no debug logging in hot path
    let dispatcher = SimdDispatcher::new();
    dispatcher.matmul_f32(c, a, b, m, k, n, alpha, beta)?;

    // Check output
    let c_nonzero = c.iter().filter(|&&x| x != 0.0).count();
    let c_range = (
        c.iter().copied().fold(f32::INFINITY, f32::min),
        c.iter().copied().fold(f32::NEG_INFINITY, f32::max),
    );
    tracing::info!(
        "gemm_kernel_f32 output: c_nonzero={}/{}, c_range=[{:.4e}, {:.4e}]",
        c_nonzero,
        m * n,
        c_range.0,
        c_range.1
    );

    Ok(())
}

// =============================================================================
// CONVOLUTION KERNELS
// =============================================================================

/// Direct 2D convolution kernel.
///
/// # Arguments
/// * `inputs` - [input, kernel, bias (optional)] actual data pointers
/// * `outputs` - [output] actual data pointer
/// * `params` - Conv parameters in dims and extra fields
pub fn conv_direct_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Conv2D kernel requires at least 2 inputs and 1 output",
        ));
    }

    // Extract dimensions from params
    let batch = params.dims[0];
    let in_channels = params.dims[1];
    let out_channels = params.dims[2];
    let in_height = params.extra[0];
    let in_width = params.extra[1];
    let kernel_h = params.extra[2];
    let kernel_w = params.extra[3];
    let stride_h = params.extra[4];
    let stride_w = params.extra[5];
    let pad_h = params.extra[6];
    let pad_w = params.extra[7];

    // Calculate output dimensions
    let out_height = (in_height + 2 * pad_h - kernel_h) / stride_h + 1;
    let out_width = (in_width + 2 * pad_w - kernel_w) / stride_w + 1;

    let input_size = batch * in_channels * in_height * in_width;
    let kernel_size = out_channels * in_channels * kernel_h * kernel_w;
    let output_size = batch * out_channels * out_height * out_width;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, input_size) };
    let kernel = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, kernel_size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, output_size) };

    // Optional bias
    let bias = if inputs.len() > 2 && !inputs[2].is_null() {
        Some(unsafe { std::slice::from_raw_parts(inputs[2] as *const f32, out_channels) })
    } else {
        None
    };

    let dispatcher = SimdDispatcher::new();
    dispatcher.conv2d_f32(
        output,
        input,
        kernel,
        bias,
        batch,
        in_channels,
        in_height,
        in_width,
        out_channels,
        kernel_h,
        kernel_w,
        out_height,
        out_width,
        stride_h,
        stride_w,
        pad_h,
        pad_w,
    )
}

/// Im2Col + GEMM convolution kernel.
pub fn conv_im2col_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    tables: &LookupTables,
) -> Result<(), BackendError> {
    // Im2Col uses the same implementation as direct for now
    conv_direct_kernel_f32(inputs, outputs, params, tables)
}

/// Winograd F(2,3) convolution kernel.
pub fn conv_winograd_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    tables: &LookupTables,
) -> Result<(), BackendError> {
    // Winograd uses the same SimdDispatcher::conv2d_f32 which auto-selects algorithm
    conv_direct_kernel_f32(inputs, outputs, params, tables)
}

// =============================================================================
// ELEMENTWISE KERNELS
// =============================================================================

/// Validate binary kernel sizes to prevent memory corruption from bogus params.dims.
#[inline]
fn validate_binary_sizes(
    output_size: usize,
    a_size: usize,
    b_size: usize,
    kernel_name: &str,
) -> Result<(), BackendError> {
    if output_size > MAX_UNARY_ELEMENTS {
        return Err(BackendError::invalid_config(format!(
            "{} kernel: output size {} exceeds maximum {} elements. \
             This likely indicates a compiler bug with incorrect shape inference.",
            kernel_name, output_size, MAX_UNARY_ELEMENTS
        )));
    }
    // a_size and b_size can be 1 (scalar), but shouldn't exceed output_size for valid broadcast
    if a_size > MAX_UNARY_ELEMENTS || b_size > MAX_UNARY_ELEMENTS {
        return Err(BackendError::invalid_config(format!(
            "{} kernel: input sizes (a={}, b={}) exceed maximum {} elements. \
             This likely indicates a compiler bug.",
            kernel_name, a_size, b_size, MAX_UNARY_ELEMENTS
        )));
    }
    Ok(())
}

/// Element-wise addition: output = a + b
///
/// Supports broadcasting with dims encoding:
/// - dims[0] = output size (total elements)
/// - dims[1] = B input size (for broadcast detection)
/// - dims[2] = A input size (for broadcast detection)
pub fn add_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Add kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }

    // Validate pointers
    if inputs[0].is_null() || inputs[1].is_null() || outputs[0].is_null() {
        return Err(BackendError::invalid_config(format!(
            "Add kernel has null pointers: inputs=[{:?}, {:?}], output={:?}",
            inputs[0], inputs[1], outputs[0]
        )));
    }

    // Validate sizes before creating slices
    // dims[0] = output size (total elements)
    // dims[1] = actual B input size (for broadcast detection)
    // dims[2] = actual A input size (for broadcast detection)
    let b_size = if params.dims[1] == 0 {
        1
    } else {
        params.dims[1]
    };
    let a_size = if params.dims[2] == 0 {
        size
    } else {
        params.dims[2]
    };
    validate_binary_sizes(size, a_size, b_size, "Add")?;

    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    if a_size == 1 && b_size == 1 {
        // Both scalars
        let a_scalar = unsafe { *(inputs[0] as *const f32) };
        let b_scalar = unsafe { *(inputs[1] as *const f32) };
        out[0] = a_scalar + b_scalar;
    } else if a_size == 1 {
        // A is scalar, B is tensor: result = scalar + B
        let a_scalar = unsafe { *(inputs[0] as *const f32) };
        let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };

        tracing::info!("add_kernel_f32: scalar={:.6e} + B[{}]", a_scalar, size);

        for i in 0..size {
            out[i] = a_scalar + b[i];
        }
    } else if b_size == 1 {
        // A is tensor, B is scalar: result = A + scalar
        let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
        let b_scalar = unsafe { *(inputs[1] as *const f32) };

        let sample = size.min(100);
        let a_min = a[..sample].iter().copied().fold(f32::INFINITY, f32::min);
        let a_max = a[..sample]
            .iter()
            .copied()
            .fold(f32::NEG_INFINITY, f32::max);
        tracing::info!(
            "add_kernel_f32: scalar={:.6e}, A_range=[{:.6e}, {:.6e}], result_range=[{:.6e}, {:.6e}]",
            b_scalar, a_min, a_max, a_min + b_scalar, a_max + b_scalar
        );

        for i in 0..size {
            out[i] = a[i] + b_scalar;
        }
    } else if b_size < size {
        // A is tensor, B is smaller tensor: broadcast B
        let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
        let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, b_size) };

        let sample = size.min(100);
        let a_min = a[..sample].iter().copied().fold(f32::INFINITY, f32::min);
        let a_max = a[..sample]
            .iter()
            .copied()
            .fold(f32::NEG_INFINITY, f32::max);
        let b_min = b.iter().copied().fold(f32::INFINITY, f32::min);
        let b_max = b.iter().copied().fold(f32::NEG_INFINITY, f32::max);
        tracing::info!(
            "add_kernel_f32: A_range=[{:.6e}, {:.6e}], B_range=[{:.6e}, {:.6e}] (broadcast from {})",
            a_min, a_max, b_min, b_max, b_size
        );

        for i in 0..size {
            out[i] = a[i] + b[i % b_size];
        }
    } else {
        // Element-wise: both same size
        let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
        let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };

        let sample = size.min(100);
        let a_min = a[..sample].iter().copied().fold(f32::INFINITY, f32::min);
        let a_max = a[..sample]
            .iter()
            .copied()
            .fold(f32::NEG_INFINITY, f32::max);
        let b_min = b[..sample].iter().copied().fold(f32::INFINITY, f32::min);
        let b_max = b[..sample]
            .iter()
            .copied()
            .fold(f32::NEG_INFINITY, f32::max);
        tracing::info!(
            "add_kernel_f32: A_range=[{:.6e}, {:.6e}], B_range=[{:.6e}, {:.6e}]",
            a_min,
            a_max,
            b_min,
            b_max
        );

        for i in 0..size {
            out[i] = a[i] + b[i];
        }
    }
    Ok(())
}

/// Element-wise multiplication: output = a * b
pub fn mul_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Mul kernel requires 2 inputs and 1 output",
        ));
    }

    // Validate pointers are not null
    if inputs[0].is_null() || inputs[1].is_null() || outputs[0].is_null() {
        return Err(BackendError::invalid_config(format!(
            "Mul kernel has null pointers: inputs=[{:?}, {:?}], output={:?}",
            inputs[0], inputs[1], outputs[0]
        )));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }

    // Validate sizes before creating slices
    let b_size = if params.dims[1] == 0 {
        1
    } else {
        params.dims[1]
    };
    let a_size = if params.dims[2] == 0 {
        size
    } else {
        params.dims[2]
    };
    validate_binary_sizes(size, a_size, b_size, "Mul")?;

    tracing::trace!("mul_kernel_f32: size={}, creating slices", size);

    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    tracing::trace!("mul_kernel_f32: slices created, processing");
    if b_size == 1 {
        // Scalar - broadcast to all elements
        let scalar = unsafe { *(inputs[1] as *const f32) };
        for i in 0..size {
            out[i] = a[i] * scalar;
        }
    } else if b_size < size {
        // B is smaller than A - broadcast B with modulo indexing
        let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, b_size) };
        for i in 0..size {
            out[i] = a[i] * b[i % b_size];
        }
    } else {
        // Element-wise: both same size
        let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
        for i in 0..size {
            out[i] = a[i] * b[i];
        }
    }
    Ok(())
}

/// Maximum reasonable element count for unary/elementwise kernels.
/// 256M elements = 1GB of f32 data, which should be plenty for any real tensor.
const MAX_UNARY_ELEMENTS: usize = 256 * 1024 * 1024;

/// Validate unary kernel size to prevent memory corruption from bogus params.dims.
#[inline]
fn validate_unary_size(size: usize, kernel_name: &str) -> Result<(), BackendError> {
    if size > MAX_UNARY_ELEMENTS {
        return Err(BackendError::invalid_config(format!(
            "{} kernel: size {} exceeds maximum {} elements. \
             This likely indicates a compiler bug with incorrect shape inference.",
            kernel_name, size, MAX_UNARY_ELEMENTS
        )));
    }
    Ok(())
}

/// ReLU activation: output = max(0, input)
pub fn relu_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ReLU kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }

    // Validate size to prevent memory corruption from bogus dimensions
    validate_unary_size(size, "ReLU")?;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = input[i].max(0.0);
    }

    Ok(())
}

/// Sigmoid activation: output = 1 / (1 + exp(-input))
pub fn sigmoid_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Sigmoid kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }
    validate_unary_size(size, "Sigmoid")?;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = 1.0 / (1.0 + (-input[i]).exp());
    }
    Ok(())
}

/// Tanh activation: output = tanh(input)
pub fn tanh_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Tanh kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }
    validate_unary_size(size, "Tanh")?;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = input[i].tanh();
    }
    Ok(())
}

/// GELU activation: output = 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
pub fn gelu_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "GELU kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }
    validate_unary_size(size, "GELU")?;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    const SQRT_2_OVER_PI: f32 = 0.797_884_6; // sqrt(2/pi)
    const COEFF: f32 = 0.044715;

    for i in 0..size {
        let x = input[i];
        let inner = SQRT_2_OVER_PI * (x + COEFF * x * x * x);
        output[i] = 0.5 * x * (1.0 + inner.tanh());
    }
    Ok(())
}

#[inline(always)]
fn apply_table_u8(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    table: &[u8; 256],
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "u8 activation kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }
    validate_unary_size(size, "u8 table lookup")?;

    let input = unsafe { std::slice::from_raw_parts(inputs[0], size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0], size) };

    timed!("cpu_u8_table_ms", {
        if try_apply_table_u8_simd(input, output, table) {
            return Ok(());
        }

        apply_table_u8_scalar(output, input, table);
        Ok(())
    })
}

fn apply_table_u8_scalar(output: &mut [u8], input: &[u8], table: &[u8; 256]) {
    let mut i = 0;
    while i + 8 <= input.len() {
        output[i] = table[input[i] as usize];
        output[i + 1] = table[input[i + 1] as usize];
        output[i + 2] = table[input[i + 2] as usize];
        output[i + 3] = table[input[i + 3] as usize];
        output[i + 4] = table[input[i + 4] as usize];
        output[i + 5] = table[input[i + 5] as usize];
        output[i + 6] = table[input[i + 6] as usize];
        output[i + 7] = table[input[i + 7] as usize];
        i += 8;
    }

    while i < input.len() {
        output[i] = table[input[i] as usize];
        i += 1;
    }
}

#[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
fn try_apply_table_u8_simd(input: &[u8], output: &mut [u8], table: &[u8; 256]) -> bool {
    match cpu_capability() {
        SimdCapability::Avx512 | SimdCapability::Avx2 => {
            simd_path!("avx2");
            unsafe { apply_table_u8_avx2(input, output, table) };
            true
        }
        _ => false,
    }
}

#[cfg(not(all(target_arch = "x86_64", target_feature = "avx2")))]
fn try_apply_table_u8_simd(_input: &[u8], _output: &mut [u8], _table: &[u8; 256]) -> bool {
    false
}

#[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
#[target_feature(enable = "avx2")]
unsafe fn apply_table_u8_avx2(input: &[u8], output: &mut [u8], table: &[u8; 256]) {
    let mut expanded = [0i32; 256];
    let mut idx = 0;
    while idx < 256 {
        expanded[idx] = table[idx] as i32;
        idx += 1;
    }

    let len = input.len();
    let table_ptr = expanded.as_ptr();
    let mut i = 0;
    while i + 8 <= len {
        let indices =
            _mm256_cvtepu8_epi32(_mm_loadl_epi64(input.as_ptr().add(i) as *const __m128i));
        let gathered = _mm256_i32gather_epi32(table_ptr, indices, 4);

        let mut lane = [0i32; 8];
        _mm256_storeu_si256(lane.as_mut_ptr() as *mut __m256i, gathered);
        *output.get_unchecked_mut(i) = lane[0] as u8;
        *output.get_unchecked_mut(i + 1) = lane[1] as u8;
        *output.get_unchecked_mut(i + 2) = lane[2] as u8;
        *output.get_unchecked_mut(i + 3) = lane[3] as u8;
        *output.get_unchecked_mut(i + 4) = lane[4] as u8;
        *output.get_unchecked_mut(i + 5) = lane[5] as u8;
        *output.get_unchecked_mut(i + 6) = lane[6] as u8;
        *output.get_unchecked_mut(i + 7) = lane[7] as u8;
        i += 8;
    }

    while i < len {
        *output.get_unchecked_mut(i) = *table.get_unchecked(input[i] as usize);
        i += 1;
    }
}

/// Quantized ReLU activation: table lookup over full u8 domain.
pub fn relu_kernel_u8(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    apply_table_u8(inputs, outputs, params, &RELU_U8)
}

/// Quantized Sigmoid activation: table lookup over full u8 domain.
pub fn sigmoid_kernel_u8(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    apply_table_u8(inputs, outputs, params, &SIGMOID_U8)
}

/// Quantized Tanh activation: table lookup over full u8 domain.
pub fn tanh_kernel_u8(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    apply_table_u8(inputs, outputs, params, &TANH_U8)
}

/// Quantized GELU activation: table lookup over full u8 domain.
pub fn gelu_kernel_u8(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    apply_table_u8(inputs, outputs, params, &GELU_U8)
}

/// Quantized SiLU activation: table lookup over full u8 domain.
pub fn silu_kernel_u8(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    apply_table_u8(inputs, outputs, params, &SILU_U8)
}

/// Quantized fused Sigmoid→ReLU activation: single-pass table.
pub fn fused_sigmoid_relu_u8(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    apply_table_u8(inputs, outputs, params, &FUSED_SIGMOID_RELU_U8)
}

/// Quantized fused Sigmoid→Tanh activation: single-pass table.
pub fn fused_sigmoid_tanh_u8(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    apply_table_u8(inputs, outputs, params, &FUSED_SIGMOID_TANH_U8)
}

/// Quantized fused Sigmoid→Tanh→ReLU activation: single-pass table.
pub fn fused_sigmoid_tanh_relu_u8(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    apply_table_u8(inputs, outputs, params, &FUSED_SIGMOID_TANH_RELU_U8)
}

// =============================================================================
// REDUCTION KERNELS
// =============================================================================

/// Reduce sum: output = sum(input)
pub fn reduce_sum_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ReduceSum kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, 1) };

    output[0] = input.iter().sum();
    Ok(())
}

/// Reduce max: output = max(input)
pub fn reduce_max_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ReduceMax kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, 1) };

    output[0] = input.iter().copied().fold(f32::NEG_INFINITY, f32::max);
    Ok(())
}

/// Reduce min: output = min(input)
pub fn reduce_min_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ReduceMin kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, 1) };

    output[0] = input.iter().copied().fold(f32::INFINITY, f32::min);
    Ok(())
}

/// Reduce mean: output = mean(input) along axis
///
/// Supports per-axis reduction using params:
///   dims[0] = outer_size (product of dims before axis)
///   dims[1] = reduce_size (size of the axis being reduced)
///   dims[2] = inner_size (product of dims after axis)
///
/// For input shape [outer, reduce, inner], computes mean over 'reduce' dimension
/// producing output shape [outer, inner].
///
/// If dims[2] (inner_size) is 0 or 1 with dims[0] > 1 and dims[1] == dims[0],
/// falls back to global reduction (single output value).
pub fn reduce_mean_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ReduceMean kernel requires 1 input and 1 output",
        ));
    }

    let outer_size = params.dims[0].max(1);
    let reduce_size = params.dims[1].max(1);
    let inner_size = params.dims[2].max(1);

    // Validate dimensions to prevent bogus values from crashing
    // Max reasonable tensor size: 1GB of f32 = 256M elements
    const MAX_REASONABLE_ELEMENTS: usize = 256 * 1024 * 1024;

    // Use checked multiplication to detect overflow and bogus values
    let total_input = outer_size
        .checked_mul(reduce_size)
        .and_then(|x| x.checked_mul(inner_size));

    let total_input = match total_input {
        Some(n) if n <= MAX_REASONABLE_ELEMENTS => n,
        Some(n) => {
            return Err(BackendError::invalid_config(format!(
                "ReduceMean dimensions too large: outer={} * reduce={} * inner={} = {} elements \
                 (max {}). This likely indicates a compiler bug with incorrect shape inference.",
                outer_size, reduce_size, inner_size, n, MAX_REASONABLE_ELEMENTS
            )));
        }
        None => {
            return Err(BackendError::invalid_config(format!(
                "ReduceMean dimension overflow: outer={} * reduce={} * inner={} overflows. \
                 This likely indicates a compiler bug with incorrect shape inference.",
                outer_size, reduce_size, inner_size
            )));
        }
    };

    tracing::trace!(
        "reduce_mean_kernel_f32: dims={:?}, outer={}, reduce={}, inner={}, total={}",
        params.dims,
        outer_size,
        reduce_size,
        inner_size,
        total_input
    );

    // Total output elements (outer * inner)
    let total_output = outer_size * inner_size;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, total_input) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, total_output) };

    // Check if this is global reduction (dims[1] contains the total size, dims[2] is 1)
    // This happens when input_shape was empty or axis=-1 with single trailing dim
    if inner_size == 1 && reduce_size == outer_size && total_output == 1 {
        // Global reduction: single output value
        let sum: f32 = input.iter().sum();
        output[0] = sum / total_input as f32;
        return Ok(());
    }

    // Per-axis reduction:
    // Input layout: [outer, reduce, inner]
    // For each (outer_idx, inner_idx), compute mean over reduce dimension
    for outer_idx in 0..outer_size {
        for inner_idx in 0..inner_size {
            let mut sum = 0.0f32;

            // Sum over reduce dimension
            for reduce_idx in 0..reduce_size {
                let input_idx = (outer_idx * reduce_size + reduce_idx) * inner_size + inner_idx;
                sum += input[input_idx];
            }

            let output_idx = outer_idx * inner_size + inner_idx;
            output[output_idx] = sum / reduce_size as f32;
        }
    }

    Ok(())
}

/// Reduce variance: output = var(input)
pub fn reduce_variance_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ReduceVariance kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, 1) };

    let mean: f32 = input.iter().sum::<f32>() / size as f32;
    let variance: f32 = input.iter().map(|x| (x - mean).powi(2)).sum::<f32>() / size as f32;
    output[0] = variance;
    Ok(())
}

/// Reduce argmax: output = index of max(input)
pub fn reduce_argmax_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ReduceArgmax kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut i64, 1) };

    let (idx, _) =
        input
            .iter()
            .enumerate()
            .fold((0, f32::NEG_INFINITY), |(max_idx, max_val), (i, &val)| {
                if val > max_val {
                    (i, val)
                } else {
                    (max_idx, max_val)
                }
            });
    output[0] = idx as i64;
    Ok(())
}

/// Reduce argmax over last token position: output[batch] = argmax(input[batch, last, :])
pub fn reduce_argmax_last_token_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ArgMaxLastToken kernel requires 1 input and 1 output",
        ));
    }

    let vocab = params.dims[0];
    let seq_len = params.dims[1];
    let batch = params.dims[2];

    if vocab == 0 || seq_len == 0 || batch == 0 {
        return Err(BackendError::invalid_config(
            "ArgMaxLastToken kernel received zero-sized dimensions",
        ));
    }

    let total_elems = batch
        .checked_mul(seq_len)
        .and_then(|v| v.checked_mul(vocab))
        .ok_or_else(|| BackendError::invalid_config("ArgMaxLastToken size overflow"))?;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, total_elems) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut i64, batch) };

    let last_offset = (seq_len - 1) * vocab;
    for (b, out) in output.iter_mut().enumerate() {
        let base = b * seq_len * vocab + last_offset;
        let slice = &input[base..base + vocab];
        let (idx, _) = slice.iter().enumerate().fold(
            (0, f32::NEG_INFINITY),
            |(max_idx, max_val), (i, &val)| {
                if val > max_val {
                    (i, val)
                } else {
                    (max_idx, max_val)
                }
            },
        );
        *out = idx as i64;
    }

    Ok(())
}

/// Reduce argmin: output = index of min(input)
pub fn reduce_argmin_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ReduceArgmin kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut i64, 1) };

    let (idx, _) =
        input
            .iter()
            .enumerate()
            .fold((0, f32::INFINITY), |(min_idx, min_val), (i, &val)| {
                if val < min_val {
                    (i, val)
                } else {
                    (min_idx, min_val)
                }
            });
    output[0] = idx as i64;
    Ok(())
}

/// Reduce product: output = prod(input)
pub fn reduce_prod_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ReduceProd kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, 1) };

    output[0] = input.iter().product();
    Ok(())
}

// =============================================================================
// ADDITIONAL BINARY ELEMENTWISE KERNELS
// =============================================================================

/// Element-wise subtraction: output = a - b
pub fn sub_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Sub kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }

    // dims[0] = output size (total elements)
    // dims[1] = actual B input size (for broadcast detection)
    // dims[2] = actual A input size (for broadcast detection)
    let b_size = if params.dims[1] == 0 {
        1
    } else {
        params.dims[1]
    };
    let a_size = if params.dims[2] == 0 {
        size
    } else {
        params.dims[2]
    };
    validate_binary_sizes(size, a_size, b_size, "Sub")?;

    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    if a_size == 1 && b_size == 1 {
        // Both scalars
        let a_scalar = unsafe { *(inputs[0] as *const f32) };
        let b_scalar = unsafe { *(inputs[1] as *const f32) };
        out[0] = a_scalar - b_scalar;
    } else if a_size == 1 {
        // A is scalar, B is tensor: result = scalar - B
        let a_scalar = unsafe { *(inputs[0] as *const f32) };
        let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
        for i in 0..size {
            out[i] = a_scalar - b[i];
        }
    } else if b_size == 1 {
        // A is tensor, B is scalar: result = A - scalar
        let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
        let b_scalar = unsafe { *(inputs[1] as *const f32) };
        for i in 0..size {
            out[i] = a[i] - b_scalar;
        }
    } else if b_size < size {
        // A is tensor, B is smaller tensor: broadcast B
        let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
        let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, b_size) };
        for i in 0..size {
            out[i] = a[i] - b[i % b_size];
        }
    } else {
        // Element-wise: both same size
        let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
        let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
        for i in 0..size {
            out[i] = a[i] - b[i];
        }
    }
    Ok(())
}

/// Element-wise division: output = a / b
///
/// Supports broadcasting:
/// - dims[0] = first input size (1 for scalar, total_size for tensor)
/// - dims[1] = second input size (1 for scalar, total_size for tensor)
/// - dims[2] = total output size (for broadcasting)
pub fn div_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Div kernel requires 2 inputs and 1 output",
        ));
    }

    // Get input sizes and output size
    let a_size = if params.dims[0] == 0 {
        1
    } else {
        params.dims[0]
    };
    let b_size = if params.dims[1] == 0 {
        1
    } else {
        params.dims[1]
    };
    let out_size = if params.dims[2] > 0 {
        params.dims[2]
    } else {
        a_size.max(b_size)
    };

    if out_size == 0 {
        return Ok(());
    }

    // Validate sizes before creating slices
    validate_binary_sizes(out_size, a_size, b_size, "Div")?;

    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, a_size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, b_size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, out_size) };

    // Debug logging
    let sample_size = a_size.min(1000);
    let a_min = a[..sample_size]
        .iter()
        .copied()
        .fold(f32::INFINITY, f32::min);
    let a_max = a[..sample_size]
        .iter()
        .copied()
        .fold(f32::NEG_INFINITY, f32::max);
    let a_has_nan = a[..sample_size].iter().any(|x| x.is_nan());

    tracing::info!(
        "div_kernel_f32: a_size={}, b_size={}, out_size={}, dims={:?}, a_range=[{:.6e}, {:.6e}], nan={}",
        a_size, b_size, out_size, params.dims, a_min, a_max, a_has_nan
    );

    // Dispatch based on input sizes
    match (a_size == 1, b_size == 1) {
        (true, true) => {
            // Scalar / Scalar
            let result = a[0] / b[0].max(1e-12);
            for out_val in out.iter_mut().take(out_size) {
                *out_val = result;
            }
            tracing::info!(
                "div_kernel_f32: scalar/scalar = {:.6e} / {:.6e} = {:.6e}",
                a[0],
                b[0],
                result
            );
        }
        (true, false) => {
            // Scalar / Tensor: broadcast a[0] to all elements
            let scalar_a = a[0];
            tracing::info!(
                "div_kernel_f32: scalar_numerator={:.6e} / tensor[{}]",
                scalar_a,
                b_size
            );
            for i in 0..out_size {
                let divisor = b[i % b_size];
                out[i] = scalar_a / divisor.max(1e-12).copysign(divisor);
            }
        }
        (false, true) => {
            // Tensor / Scalar: broadcast b[0] to all elements
            let scalar_b = b[0];
            tracing::info!(
                "div_kernel_f32: tensor[{}] / scalar_divisor={:.6e}",
                a_size,
                scalar_b
            );
            let safe_scalar = if scalar_b.abs() < 1e-12 {
                1e-12f32.copysign(scalar_b.max(1e-12))
            } else {
                scalar_b
            };
            for i in 0..out_size {
                out[i] = a[i % a_size] / safe_scalar;
            }
        }
        (false, false) => {
            // Tensor / Tensor: element-wise
            let b_sample_size = b_size.min(1000);
            let b_min = b[..b_sample_size]
                .iter()
                .copied()
                .fold(f32::INFINITY, f32::min);
            let b_max = b[..b_sample_size]
                .iter()
                .copied()
                .fold(f32::NEG_INFINITY, f32::max);
            let b_zeros = b[..b_sample_size]
                .iter()
                .filter(|&&x| x.abs() < 1e-10)
                .count();

            tracing::info!(
                "div_kernel_f32: tensor/tensor, divisor_range=[{:.6e}, {:.6e}], near_zero_count={}",
                b_min,
                b_max,
                b_zeros
            );

            // Safe element-wise division - clamp divisor to prevent NaN
            const MIN_DIVISOR: f32 = 1e-12;
            for i in 0..out_size {
                let divisor = b[i % b_size];
                let safe_divisor = if divisor.abs() < MIN_DIVISOR {
                    MIN_DIVISOR.copysign(divisor.max(MIN_DIVISOR))
                } else {
                    divisor
                };
                out[i] = a[i % a_size] / safe_divisor;
            }
        }
    }
    Ok(())
}

/// Element-wise maximum: output = max(a, b)
pub fn max_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Max kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    // Check if second input is a scalar (params.dims[1] == 0 or 1 means broadcast)
    let b_size = if params.dims[1] == 0 {
        1
    } else {
        params.dims[1]
    };
    if b_size == 1 {
        // Scalar - broadcast to all elements
        let scalar = unsafe { *(inputs[1] as *const f32) };
        for i in 0..size {
            out[i] = a[i].max(scalar);
        }
    } else {
        let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
        for i in 0..size {
            out[i] = a[i].max(b[i]);
        }
    }
    Ok(())
}

/// Element-wise minimum: output = min(a, b)
pub fn min_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Min kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    // Check if second input is a scalar (params.dims[1] == 0 or 1 means broadcast)
    let b_size = if params.dims[1] == 0 {
        1
    } else {
        params.dims[1]
    };
    if b_size == 1 {
        // Scalar - broadcast to all elements
        let scalar = unsafe { *(inputs[1] as *const f32) };
        for i in 0..size {
            out[i] = a[i].min(scalar);
        }
    } else {
        let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
        for i in 0..size {
            out[i] = a[i].min(b[i]);
        }
    }
    Ok(())
}

/// Element-wise power: output = a ^ b
pub fn pow_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    tracing::trace!("pow_kernel_f32: ENTER, dims={:?}", params.dims);

    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Pow kernel requires 2 inputs and 1 output",
        ));
    }

    // Validate pointers are not null
    if inputs[0].is_null() || inputs[1].is_null() || outputs[0].is_null() {
        return Err(BackendError::invalid_config(format!(
            "Pow kernel has null pointers: inputs=[{:?}, {:?}], output={:?}",
            inputs[0], inputs[1], outputs[0]
        )));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }

    // Check if second input is a scalar (params.dims[1] == 0 or 1 means broadcast)
    let b_size = if params.dims[1] == 0 {
        1
    } else {
        params.dims[1]
    };
    let a_size = if params.dims[2] == 0 {
        size
    } else {
        params.dims[2]
    };

    // Validate sizes before creating slices
    validate_binary_sizes(size, a_size, b_size, "Pow")?;

    tracing::trace!(
        "pow_kernel_f32: size={}, input_ptrs=[{:?}, {:?}], output_ptr={:?}",
        size,
        inputs[0],
        inputs[1],
        outputs[0]
    );

    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    tracing::trace!("pow_kernel_f32: slices created, b_size={}", b_size);

    if b_size == 1 {
        // Scalar exponent - broadcast to all elements
        let exp = unsafe { *(inputs[1] as *const f32) };
        tracing::trace!(
            "pow_kernel_f32: scalar mode, exp={}, first 5 a=[{:?}]",
            exp,
            &a[..a.len().min(5)]
        );
        for i in 0..size {
            out[i] = a[i].powf(exp);
        }
        tracing::trace!("pow_kernel_f32: scalar mode completed");
    } else {
        // Element-wise power
        let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
        tracing::trace!(
            "pow_kernel_f32: element-wise mode, first 5 a=[{:?}], first 5 b=[{:?}]",
            &a[..a.len().min(5)],
            &b[..b.len().min(5)]
        );
        for i in 0..size {
            out[i] = a[i].powf(b[i]);
        }
        tracing::trace!("pow_kernel_f32: element-wise mode completed");
    }
    tracing::trace!("pow_kernel_f32: DONE");
    Ok(())
}

/// Element-wise modulo: output = a % b
pub fn mod_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Mod kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        out[i] = a[i] % b[i];
    }
    Ok(())
}

// =============================================================================
// ADDITIONAL ACTIVATION KERNELS
// =============================================================================

/// SiLU (Swish) activation: output = x * sigmoid(x)
pub fn silu_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "SiLU kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }
    validate_unary_size(size, "SiLU")?;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        let x = input[i];
        output[i] = x / (1.0 + (-x).exp());
    }
    Ok(())
}

/// Mish activation: output = x * tanh(softplus(x)) = x * tanh(ln(1 + e^x))
pub fn mish_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Mish kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }
    validate_unary_size(size, "Mish")?;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        let x = input[i];
        let softplus = (1.0 + x.exp()).ln();
        output[i] = x * softplus.tanh();
    }
    Ok(())
}

/// Softplus activation: output = ln(1 + e^x)
pub fn softplus_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Softplus kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = (1.0 + input[i].exp()).ln();
    }
    Ok(())
}

/// Leaky ReLU activation: output = max(alpha * x, x)
/// alpha is stored in params.extra[0] as f32 bits
pub fn leaky_relu_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "LeakyReLU kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let alpha = f32::from_bits(params.extra[0] as u32);
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        let x = input[i];
        output[i] = if x > 0.0 { x } else { alpha * x };
    }
    Ok(())
}

// =============================================================================
// TRANSCENDENTAL KERNELS
// =============================================================================

/// Exponential: output = e^x
pub fn exp_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Exp kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = input[i].exp();
    }
    Ok(())
}

/// Natural logarithm: output = ln(x)
pub fn log_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Log kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    // Clamp to minimum value to avoid log(0) = -inf and log(negative) = NaN
    const MIN_LOG_INPUT: f32 = 1e-12;
    for i in 0..size {
        output[i] = input[i].max(MIN_LOG_INPUT).ln();
    }
    Ok(())
}

/// Square root: output = sqrt(x)
pub fn sqrt_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Sqrt kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    // Debug: compute input value range
    let sample_size = size.min(1000);
    let in_min = input[..sample_size]
        .iter()
        .copied()
        .fold(f32::INFINITY, f32::min);
    let in_max = input[..sample_size]
        .iter()
        .copied()
        .fold(f32::NEG_INFINITY, f32::max);
    let in_has_nan = input[..sample_size].iter().any(|x| x.is_nan());
    let in_has_inf = input[..sample_size].iter().any(|x| x.is_infinite());
    let in_zeros = input[..sample_size].iter().filter(|&&x| x == 0.0).count();

    tracing::info!(
        "sqrt_kernel_f32: size={}, input_range=[{:.6e}, {:.6e}], zeros={}, nan={}, inf={}",
        size,
        in_min,
        in_max,
        in_zeros,
        in_has_nan,
        in_has_inf
    );

    // Numerical stability: clamp input to minimum epsilon before sqrt.
    // This prevents sqrt(0) = 0 which causes division by zero in RMS normalization.
    // T5 and other models use decomposed RMS norm: sqrt(variance + epsilon).
    // If epsilon is not properly added, variance=0 for padding positions causes NaN.
    const MIN_EPSILON: f32 = 1e-12;

    for i in 0..size {
        // Handle NaN and negative values by clamping to MIN_EPSILON
        // NaN.max(x) returns NaN, so we need explicit handling
        let val = input[i];
        let safe_val = if val.is_nan() || val < MIN_EPSILON {
            MIN_EPSILON
        } else {
            val
        };
        output[i] = safe_val.sqrt();
    }
    Ok(())
}

/// Sine: output = sin(x)
pub fn sin_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Sin kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = input[i].sin();
    }
    Ok(())
}

/// Cosine: output = cos(x)
pub fn cos_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Cos kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = input[i].cos();
    }
    Ok(())
}

/// Tangent: output = tan(x)
pub fn tan_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Tan kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = input[i].tan();
    }
    Ok(())
}

/// Arcsine: output = asin(x)
pub fn asin_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Asin kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = input[i].asin();
    }
    Ok(())
}

/// Arccosine: output = acos(x)
pub fn acos_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Acos kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = input[i].acos();
    }
    Ok(())
}

/// Negate: output = -x
pub fn neg_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Neg kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = -input[i];
    }
    Ok(())
}

/// Absolute value: output = |x|
pub fn abs_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Abs kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for i in 0..size {
        output[i] = input[i].abs();
    }
    Ok(())
}

/// Error function: output = erf(x)
/// Uses Abramowitz and Stegun polynomial approximation (accurate to ~1.5e-7).
/// This is critical for GELU activation: GELU(x) = 0.5 * x * (1 + erf(x / sqrt(2)))
pub fn erf_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Erf kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    // Abramowitz and Stegun approximation constants (f32 precision)
    const P: f32 = 0.327_591_1;
    const A1: f32 = 0.254_829_6;
    const A2: f32 = -0.284_496_72;
    const A3: f32 = 1.421_413_8;
    const A4: f32 = -1.453_152;
    const A5: f32 = 1.061_405_4;

    for i in 0..size {
        let x = input[i];
        let sign = if x >= 0.0 { 1.0 } else { -1.0 };
        let x_abs = x.abs();

        // t = 1 / (1 + p * |x|)
        let t = 1.0 / (1.0 + P * x_abs);

        // Horner's method for polynomial evaluation
        let poly = ((((A5 * t + A4) * t + A3) * t + A2) * t + A1) * t;

        // erf(x) = sign(x) * (1 - poly * exp(-x^2))
        output[i] = sign * (1.0 - poly * (-x_abs * x_abs).exp());
    }
    Ok(())
}

// =============================================================================
// NORMALIZATION KERNELS
// =============================================================================

/// Softmax: output[i] = exp(x[i]) / sum(exp(x))
/// dims[0] = batch, dims[1] = size per batch
pub fn softmax_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    tracing::info!("SOFTMAX_KERNEL: CALLED with dims={:?}", params.dims);

    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Softmax kernel requires 1 input and 1 output",
        ));
    }

    let batch = params.dims[0].max(1);
    let size = params.dims[1].max(1);
    let total = batch * size;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, total) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, total) };

    for b in 0..batch {
        let start = b * size;
        let end = start + size;
        let slice = &input[start..end];

        // Find max for numerical stability
        let max_val = slice.iter().copied().fold(f32::NEG_INFINITY, f32::max);

        // Handle case where all values are -inf (fully masked row in attention).
        // This happens when attention mask zeros out all positions.
        // In this case, -inf - (-inf) = NaN, so we output uniform distribution.
        if max_val.is_infinite() && max_val.is_sign_negative() {
            let uniform = 1.0 / size as f32;
            output[start..end].fill(uniform);
            continue;
        }

        // Compute exp(x - max) and sum
        let mut sum = 0.0f32;
        for i in start..end {
            let exp_val = (input[i] - max_val).exp();
            output[i] = exp_val;
            sum += exp_val;
        }

        // Handle edge case where sum is 0 (shouldn't happen after max subtraction, but be safe)
        if sum == 0.0 {
            let uniform = 1.0 / size as f32;
            for val in output[start..end].iter_mut() {
                *val = uniform;
            }
        } else {
            // Normalize
            for val in output[start..end].iter_mut() {
                *val /= sum;
            }
        }
    }
    Ok(())
}

/// Log softmax: output[i] = x[i] - log(sum(exp(x)))
pub fn log_softmax_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "LogSoftmax kernel requires 1 input and 1 output",
        ));
    }

    let batch = params.dims[0].max(1);
    let size = params.dims[1].max(1);
    let total = batch * size;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, total) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, total) };

    for b in 0..batch {
        let start = b * size;
        let end = start + size;
        let slice = &input[start..end];

        // Find max for numerical stability
        let max_val = slice.iter().copied().fold(f32::NEG_INFINITY, f32::max);

        // Compute sum(exp(x - max))
        let sum: f32 = slice.iter().map(|&x| (x - max_val).exp()).sum();
        let log_sum = sum.ln();

        // Output = x - max - log(sum)
        for i in start..end {
            output[i] = input[i] - max_val - log_sum;
        }
    }
    Ok(())
}

/// Layer normalization: output = (x - mean) / sqrt(var + eps) * gamma + beta
/// dims[0] = batch, dims[1] = hidden_size
/// eps stored in extra[0] as f32 bits
pub fn layer_norm_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "LayerNorm kernel requires 1 input and 1 output",
        ));
    }

    let batch = params.dims[0].max(1);
    let hidden_size = params.dims[1].max(1);
    let total = batch * hidden_size;
    let eps = f32::from_bits(params.extra[0] as u32);

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, total) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, total) };

    // Optional gamma and beta (inputs[1] and inputs[2])
    let gamma = if inputs.len() > 1 && !inputs[1].is_null() {
        Some(unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, hidden_size) })
    } else {
        None
    };
    let beta = if inputs.len() > 2 && !inputs[2].is_null() {
        Some(unsafe { std::slice::from_raw_parts(inputs[2] as *const f32, hidden_size) })
    } else {
        None
    };

    for b in 0..batch {
        let start = b * hidden_size;
        let end = start + hidden_size;
        let slice = &input[start..end];

        // Compute mean
        let mean: f32 = slice.iter().sum::<f32>() / hidden_size as f32;

        // Compute variance
        let variance: f32 =
            slice.iter().map(|x| (x - mean).powi(2)).sum::<f32>() / hidden_size as f32;
        let std_dev = (variance + eps).sqrt();

        // Normalize and apply affine transform
        for (i, idx) in (start..end).enumerate() {
            let normalized = (input[idx] - mean) / std_dev;
            let g = gamma.map_or(1.0, |g| g[i]);
            let b = beta.map_or(0.0, |b| b[i]);
            output[idx] = normalized * g + b;
        }
    }
    Ok(())
}

/// Batch normalization: output = (x - mean) / sqrt(var + eps) * gamma + beta
/// dims[0] = batch, dims[1] = channels, dims[2] = spatial_size
pub fn batch_norm_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "BatchNorm kernel requires 1 input and 1 output",
        ));
    }

    let batch = params.dims[0].max(1);
    let channels = params.dims[1].max(1);
    let spatial_size = params.dims[2].max(1);
    let total = batch * channels * spatial_size;
    let eps = f32::from_bits(params.extra[0] as u32);

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, total) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, total) };

    // Running mean and variance (inputs[1] and inputs[2])
    let running_mean = if inputs.len() > 1 && !inputs[1].is_null() {
        Some(unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, channels) })
    } else {
        None
    };
    let running_var = if inputs.len() > 2 && !inputs[2].is_null() {
        Some(unsafe { std::slice::from_raw_parts(inputs[2] as *const f32, channels) })
    } else {
        None
    };
    // Gamma and beta (inputs[3] and inputs[4])
    let gamma = if inputs.len() > 3 && !inputs[3].is_null() {
        Some(unsafe { std::slice::from_raw_parts(inputs[3] as *const f32, channels) })
    } else {
        None
    };
    let beta = if inputs.len() > 4 && !inputs[4].is_null() {
        Some(unsafe { std::slice::from_raw_parts(inputs[4] as *const f32, channels) })
    } else {
        None
    };

    for c in 0..channels {
        let mean = running_mean.map_or(0.0, |m| m[c]);
        let var = running_var.map_or(1.0, |v| v[c]);
        let g = gamma.map_or(1.0, |g| g[c]);
        let b = beta.map_or(0.0, |b| b[c]);
        let std_dev = (var + eps).sqrt();

        for n in 0..batch {
            for s in 0..spatial_size {
                let idx = n * channels * spatial_size + c * spatial_size + s;
                output[idx] = (input[idx] - mean) / std_dev * g + b;
            }
        }
    }
    Ok(())
}

/// Instance normalization (per-sample, per-channel)
pub fn instance_norm_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "InstanceNorm kernel requires 1 input and 1 output",
        ));
    }

    let batch = params.dims[0].max(1);
    let channels = params.dims[1].max(1);
    let spatial_size = params.dims[2].max(1);
    let total = batch * channels * spatial_size;
    let eps = f32::from_bits(params.extra[0] as u32);

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, total) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, total) };

    for n in 0..batch {
        for c in 0..channels {
            let start = n * channels * spatial_size + c * spatial_size;
            let end = start + spatial_size;
            let slice = &input[start..end];

            let mean: f32 = slice.iter().sum::<f32>() / spatial_size as f32;
            let variance: f32 =
                slice.iter().map(|x| (x - mean).powi(2)).sum::<f32>() / spatial_size as f32;
            let std_dev = (variance + eps).sqrt();

            for idx in start..end {
                output[idx] = (input[idx] - mean) / std_dev;
            }
        }
    }
    Ok(())
}

/// Group normalization
pub fn group_norm_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "GroupNorm kernel requires 1 input and 1 output",
        ));
    }

    let batch = params.dims[0].max(1);
    let channels = params.dims[1].max(1);
    let spatial_size = params.dims[2].max(1);
    let num_groups = params.extra[1].max(1);
    let channels_per_group = channels / num_groups;
    let total = batch * channels * spatial_size;
    let eps = f32::from_bits(params.extra[0] as u32);

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, total) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, total) };

    for n in 0..batch {
        for g in 0..num_groups {
            // Compute mean and variance for this group
            let mut sum = 0.0f32;
            let mut sq_sum = 0.0f32;
            let group_size = channels_per_group * spatial_size;

            for c in 0..channels_per_group {
                let channel = g * channels_per_group + c;
                let start = n * channels * spatial_size + channel * spatial_size;
                for s in 0..spatial_size {
                    let val = input[start + s];
                    sum += val;
                    sq_sum += val * val;
                }
            }

            let mean = sum / group_size as f32;
            let variance = sq_sum / group_size as f32 - mean * mean;
            let std_dev = (variance + eps).sqrt();

            // Normalize
            for c in 0..channels_per_group {
                let channel = g * channels_per_group + c;
                let start = n * channels * spatial_size + channel * spatial_size;
                for s in 0..spatial_size {
                    output[start + s] = (input[start + s] - mean) / std_dev;
                }
            }
        }
    }
    Ok(())
}

// =============================================================================
// TENSOR OPERATION KERNELS
// =============================================================================

/// Gather: output = input[indices] along axis (for embedding lookups)
///
/// For axis=0 (embedding lookup): input[vocab_size, embedding_dim], indices[batch*seq]
/// Output shape: [batch*seq, embedding_dim]
///
/// dims[0] = vocab_size (axis_size), dims[1] = embedding_dim (inner_size)
/// dims[2] = num_indices, dims[3] = output total size
pub fn gather_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Gather kernel requires 2 inputs and 1 output",
        ));
    }

    let axis_size = params.dims[0].max(1); // vocab_size for embeddings
    let inner_size = params.dims[1].max(1); // embedding_dim
    let num_indices = params.dims[2];
    let output_total = params.dims[3].max(num_indices * inner_size);

    let input_total = axis_size * inner_size;
    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, input_total) };

    // indices are passed as f32 (from ONNX input tensor), convert to i64
    let indices_f32 = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, num_indices) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, output_total) };

    // Debug: log the indices and input range
    let input_range = (
        input.iter().copied().fold(f32::INFINITY, f32::min),
        input.iter().copied().fold(f32::NEG_INFINITY, f32::max),
    );
    let first_indices: Vec<_> = indices_f32.iter().take(10).copied().collect();
    tracing::info!(
        "gather_kernel_f32: axis_size={}, inner_size={}, num_indices={}, output_total={}, indices[..10]={:?}, input_range=[{:.4e}, {:.4e}]",
        axis_size, inner_size, num_indices, output_total, first_indices, input_range.0, input_range.1
    );

    // For each index, copy inner_size elements
    for (i, &idx_f32) in indices_f32.iter().enumerate() {
        let idx = (idx_f32 as i64 as usize) % axis_size;
        let src_start = idx * inner_size;
        let dst_start = i * inner_size;
        if src_start + inner_size <= input.len() && dst_start + inner_size <= output.len() {
            output[dst_start..dst_start + inner_size]
                .copy_from_slice(&input[src_start..src_start + inner_size]);
        }
    }

    // Debug: log output range
    let output_range = (
        output.iter().copied().fold(f32::INFINITY, f32::min),
        output.iter().copied().fold(f32::NEG_INFINITY, f32::max),
    );
    let nonzero = output.iter().filter(|&&x| x != 0.0).count();
    tracing::info!(
        "gather_kernel_f32 output: nonzero={}/{}, range=[{:.4e}, {:.4e}]",
        nonzero,
        output_total,
        output_range.0,
        output_range.1
    );

    Ok(())
}

/// Slice: output = input[start:end:step]
/// extra[0..4] = starts, extra[4..8] = ends
pub fn slice_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Slice kernel requires 1 input and 1 output",
        ));
    }

    let input_size = params.dims[0];
    let output_size = params.dims[1];
    let start = params.extra[0];

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, input_size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, output_size) };

    output[..output_size].copy_from_slice(&input[start..start + output_size]);
    Ok(())
}

/// Concat: output = concat(inputs) along axis
pub fn concat_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Concat kernel requires at least 1 input and 1 output",
        ));
    }

    let num_inputs = params.dims[0].min(inputs.len());
    let output_size = params.dims[1];
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, output_size) };

    let mut offset = 0;
    for (i, &input_ptr) in inputs.iter().enumerate().take(num_inputs) {
        let size = params.extra[i];
        if size > 0 && offset + size <= output_size {
            let inp = unsafe { std::slice::from_raw_parts(input_ptr as *const f32, size) };
            output[offset..offset + size].copy_from_slice(inp);
            offset += size;
        }
    }
    Ok(())
}

/// Reshape: output = input (just copy, reshape is handled by buffer aliasing)
pub fn reshape_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Reshape kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        tracing::warn!(
            "reshape_kernel_f32: size=0, skipping copy (params.dims={:?})",
            params.dims
        );
        return Ok(());
    }

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    let nonzero = input.iter().filter(|&&x| x != 0.0).count();
    tracing::info!(
        "reshape_kernel_f32: size={}, input_nonzero={}/{}, first_10={:?}",
        size,
        nonzero,
        size,
        &input[..size.min(10)]
    );

    if inputs[0] == outputs[0] {
        return Ok(());
    }

    unsafe {
        std::ptr::copy(input.as_ptr(), output.as_mut_ptr(), size);
    }
    Ok(())
}

/// Expand: broadcast input to output shape
pub fn expand_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Expand kernel requires 1 input and 1 output",
        ));
    }

    let input_size = params.dims[0];
    let output_size = params.dims[1];

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, input_size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, output_size) };

    // Simple broadcast: repeat input to fill output
    for i in 0..output_size {
        output[i] = input[i % input_size];
    }
    Ok(())
}

/// Tile: repeat input along dimensions
pub fn tile_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Tile kernel requires 1 input and 1 output",
        ));
    }

    let input_size = params.dims[0];
    let output_size = params.dims[1];

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, input_size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, output_size) };

    for i in 0..output_size {
        output[i] = input[i % input_size];
    }
    Ok(())
}

/// Squeeze: remove dimensions of size 1 (copy)
pub fn squeeze_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    tables: &LookupTables,
) -> Result<(), BackendError> {
    reshape_kernel_f32(inputs, outputs, params, tables)
}

/// Unsqueeze: add dimension of size 1 (copy)
pub fn unsqueeze_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    tables: &LookupTables,
) -> Result<(), BackendError> {
    reshape_kernel_f32(inputs, outputs, params, tables)
}

// =============================================================================
// METADATA KERNELS
// =============================================================================

/// Emit automorphism_dimension for each byte in the input buffer.
///
/// Inputs:
/// - inputs[0]: byte buffer
///
///   Outputs:
/// - outputs[0]: u64 buffer of same length; each entry = automorphism_dimension
pub fn byte_meta_emit(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    _params: &KernelParams,
    tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "byte_meta_emit requires 1 input and 1 output",
        ));
    }
    let in_buf = unsafe { std::slice::from_raw_parts(inputs[0], tables.byte_meta_table.len()) };
    let out_buf = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut u64, in_buf.len()) };

    for (i, &b) in in_buf.iter().enumerate() {
        out_buf[i] = tables.byte_meta_table[b as usize]
            .derivation
            .automorphism_dimension;
    }
    Ok(())
}

/// Transpose: swap dimensions
/// For 2D: dims[0]=rows, dims[1]=cols
pub fn transpose_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Transpose kernel requires 1 input and 1 output",
        ));
    }

    let rows = params.dims[0];
    let cols = params.dims[1];
    let size = rows * cols;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for r in 0..rows {
        for c in 0..cols {
            output[c * rows + r] = input[r * cols + c];
        }
    }
    Ok(())
}

/// Shape: output shape of input (metadata only, returns dims)
pub fn shape_kernel_f32(
    _inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Shape kernel requires 1 output",
        ));
    }

    let ndims = params.dims[0].min(4);
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut i64, ndims) };

    for (i, out_val) in output.iter_mut().enumerate().take(ndims) {
        *out_val = params.extra[i] as i64;
    }
    Ok(())
}

/// Range: output = [start, start+step, start+2*step, ...]
/// extra[0] = start bits, extra[1] = step bits
pub fn range_kernel_f32(
    _inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Range kernel requires 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }
    validate_unary_size(size, "Range")?;

    let start = f32::from_bits(params.extra[0] as u32);
    let step = f32::from_bits(params.extra[1] as u32);

    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for (i, out_val) in output.iter_mut().enumerate().take(size) {
        *out_val = start + (i as f32) * step;
    }
    Ok(())
}

/// ConstantOfShape: fill output with constant value
/// extra[0] = constant value bits
pub fn constant_of_shape_kernel_f32(
    _inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ConstantOfShape kernel requires 1 output",
        ));
    }

    let size = params.dims[0];
    if size == 0 {
        return Ok(());
    }
    validate_unary_size(size, "ConstantOfShape")?;

    let value = f32::from_bits(params.extra[0] as u32);

    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    output[..size].fill(value);
    Ok(())
}

/// Trilu: upper or lower triangular matrix
/// extra[0] = upper (1) or lower (0), extra[1] = diagonal offset
pub fn trilu_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Trilu kernel requires 1 input and 1 output",
        ));
    }

    let rows = params.dims[0];
    let cols = params.dims[1];
    let size = rows.checked_mul(cols).ok_or_else(|| {
        BackendError::invalid_config(format!(
            "Trilu kernel: rows={} * cols={} overflows",
            rows, cols
        ))
    })?;

    if size == 0 {
        return Ok(());
    }
    validate_unary_size(size, "Trilu")?;

    let upper = params.extra[0] != 0;
    let k = params.extra[1] as i32;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, size) };

    for r in 0..rows {
        for c in 0..cols {
            let idx = r * cols + c;
            let diag = c as i32 - r as i32;
            let keep = if upper { diag >= k } else { diag <= k };
            output[idx] = if keep { input[idx] } else { 0.0 };
        }
    }
    Ok(())
}

/// ScatterND: scatter updates into output
pub fn scatter_nd_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 3 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ScatterND kernel requires 3 inputs and 1 output",
        ));
    }

    let data_size = params.dims[0];
    let num_updates = params.dims[1];

    if data_size == 0 || num_updates == 0 {
        return Ok(());
    }
    validate_unary_size(data_size, "ScatterND data")?;
    validate_unary_size(num_updates, "ScatterND updates")?;

    let data = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, data_size) };
    let indices = unsafe { std::slice::from_raw_parts(inputs[1] as *const i64, num_updates) };
    let updates = unsafe { std::slice::from_raw_parts(inputs[2] as *const f32, num_updates) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, data_size) };

    // Copy data to output
    output.copy_from_slice(data);

    // Apply updates
    for (i, &idx) in indices.iter().enumerate() {
        let idx = idx as usize;
        if idx < data_size {
            output[idx] = updates[i];
        }
    }
    Ok(())
}

/// Split: split input into multiple outputs along axis
pub fn split_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Split kernel requires 1 input and at least 1 output",
        ));
    }

    let input_size = params.dims[0];
    let num_outputs = params.dims[1].min(outputs.len());

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, input_size) };

    let mut offset = 0;
    for (i, &output_ptr) in outputs.iter().enumerate().take(num_outputs) {
        let size = params.extra[i];
        if size > 0 && offset + size <= input_size {
            let out = unsafe { std::slice::from_raw_parts_mut(output_ptr as *mut f32, size) };
            out.copy_from_slice(&input[offset..offset + size]);
            offset += size;
        }
    }
    Ok(())
}

// =============================================================================
// COMPARISON KERNELS
// =============================================================================

/// Less than: output = a < b
pub fn less_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Less kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0], size) };

    for i in 0..size {
        out[i] = (a[i] < b[i]) as u8;
    }
    Ok(())
}

/// Equal: output = a == b
pub fn equal_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Equal kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0], size) };

    for i in 0..size {
        out[i] = (a[i] == b[i]) as u8;
    }
    Ok(())
}

/// Greater than: output = a > b
pub fn greater_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Greater kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0], size) };

    for i in 0..size {
        out[i] = (a[i] > b[i]) as u8;
    }
    Ok(())
}

/// Less than or equal: output = a <= b
pub fn less_equal_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "LessEqual kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0], size) };

    for i in 0..size {
        out[i] = (a[i] <= b[i]) as u8;
    }
    Ok(())
}

/// Greater than or equal: output = a >= b
pub fn greater_equal_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "GreaterEqual kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0], size) };

    for i in 0..size {
        out[i] = (a[i] >= b[i]) as u8;
    }
    Ok(())
}

/// Not equal: output = a != b
pub fn not_equal_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "NotEqual kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0], size) };

    for i in 0..size {
        out[i] = (a[i] != b[i]) as u8;
    }
    Ok(())
}

// =============================================================================
// BITWISE KERNELS (operate on i32)
// =============================================================================

/// Bitwise AND: output = a & b
pub fn bitwise_and_kernel(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "BitwiseAnd kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const i32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const i32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut i32, size) };

    for i in 0..size {
        out[i] = a[i] & b[i];
    }
    Ok(())
}

/// Bitwise OR: output = a | b
pub fn bitwise_or_kernel(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "BitwiseOr kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const i32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const i32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut i32, size) };

    for i in 0..size {
        out[i] = a[i] | b[i];
    }
    Ok(())
}

/// Bitwise XOR: output = a ^ b
pub fn bitwise_xor_kernel(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "BitwiseXor kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const i32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const i32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut i32, size) };

    for i in 0..size {
        out[i] = a[i] ^ b[i];
    }
    Ok(())
}

/// Bitwise NOT: output = !a
pub fn bitwise_not_kernel(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "BitwiseNot kernel requires 1 input and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const i32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut i32, size) };

    for i in 0..size {
        out[i] = !a[i];
    }
    Ok(())
}

/// Shift left: output = a << b
pub fn shl_kernel(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ShiftLeft kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const i32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const i32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut i32, size) };

    for i in 0..size {
        out[i] = a[i] << (b[i] as u32);
    }
    Ok(())
}

/// Shift right: output = a >> b
pub fn shr_kernel(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "ShiftRight kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const i32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const i32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut i32, size) };

    for i in 0..size {
        out[i] = a[i] >> (b[i] as u32);
    }
    Ok(())
}

// =============================================================================
// LINEAR ALGEBRA KERNELS
// =============================================================================

/// Matrix-vector multiplication: output = A @ x
/// dims[0] = rows (M), dims[1] = cols (K)
pub fn matvec_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "MatVec kernel requires 2 inputs and 1 output",
        ));
    }

    let m = params.dims[0];
    let k = params.dims[1];

    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, m * k) };
    let x = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, k) };
    let y = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, m) };

    for i in 0..m {
        let mut sum = 0.0f32;
        for j in 0..k {
            sum += a[i * k + j] * x[j];
        }
        y[i] = sum;
    }
    Ok(())
}

/// Vector-matrix multiplication: output = x @ A
/// dims[0] = cols (M), dims[1] = rows (K)
pub fn vecmat_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "VecMat kernel requires 2 inputs and 1 output",
        ));
    }

    let m = params.dims[0];
    let k = params.dims[1];

    let x = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, k) };
    let a = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, k * m) };
    let y = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, m) };

    for j in 0..m {
        let mut sum = 0.0f32;
        for i in 0..k {
            sum += x[i] * a[i * m + j];
        }
        y[j] = sum;
    }
    Ok(())
}

/// Dot product: output = sum(a * b)
pub fn dot_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Dot kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, 1) };

    out[0] = a.iter().zip(b.iter()).map(|(x, y)| x * y).sum();
    Ok(())
}

/// Outer product: output = a ⊗ b (M x N matrix from vectors)
/// dims[0] = M (length of a), dims[1] = N (length of b)
pub fn outer_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Outer kernel requires 2 inputs and 1 output",
        ));
    }

    let m = params.dims[0];
    let n = params.dims[1];

    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, m) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, n) };
    let out = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, m * n) };

    for i in 0..m {
        for j in 0..n {
            out[i * n + j] = a[i] * b[j];
        }
    }
    Ok(())
}

/// Batch matrix multiplication: output[b] = A[b] @ B[b]
/// dims[0] = batch, dims[1] = M, dims[2] = K, dims[3] = N
pub fn batch_matmul_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "BatchMatMul kernel requires 2 inputs and 1 output",
        ));
    }

    let batch = params.dims[0];
    let m = params.dims[1];
    let k = params.dims[2];
    let n = params.dims[3];

    let a_stride = m * k;
    let b_stride = k * n;
    let c_stride = m * n;

    let a = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, batch * a_stride) };
    let b = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, batch * b_stride) };
    let c = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, batch * c_stride) };

    // Debug: compute input value ranges
    let sample_a = (batch * a_stride).min(1000);
    let sample_b = (batch * b_stride).min(1000);
    let a_min = a[..sample_a].iter().copied().fold(f32::INFINITY, f32::min);
    let a_max = a[..sample_a]
        .iter()
        .copied()
        .fold(f32::NEG_INFINITY, f32::max);
    let b_min = b[..sample_b].iter().copied().fold(f32::INFINITY, f32::min);
    let b_max = b[..sample_b]
        .iter()
        .copied()
        .fold(f32::NEG_INFINITY, f32::max);

    tracing::info!(
        "batch_matmul_kernel_f32: batch={}, m={}, k={}, n={}, A_range=[{:.6e}, {:.6e}], B_range=[{:.6e}, {:.6e}]",
        batch, m, k, n, a_min, a_max, b_min, b_max
    );

    for batch_idx in 0..batch {
        let a_off = batch_idx * a_stride;
        let b_off = batch_idx * b_stride;
        let c_off = batch_idx * c_stride;

        for i in 0..m {
            for j in 0..n {
                let mut sum = 0.0f32;
                for kk in 0..k {
                    sum += a[a_off + i * k + kk] * b[b_off + kk * n + j];
                }
                c[c_off + i * n + j] = sum;
            }
        }
    }

    // Debug: compute output value range
    let sample_c = (batch * c_stride).min(1000);
    let c_min = c[..sample_c].iter().copied().fold(f32::INFINITY, f32::min);
    let c_max = c[..sample_c]
        .iter()
        .copied()
        .fold(f32::NEG_INFINITY, f32::max);
    let c_has_nan = c[..sample_c].iter().any(|x| x.is_nan());
    let c_has_inf = c[..sample_c].iter().any(|x| x.is_infinite());

    tracing::info!(
        "batch_matmul_kernel_f32: OUTPUT_range=[{:.6e}, {:.6e}], nan={}, inf={}",
        c_min,
        c_max,
        c_has_nan,
        c_has_inf
    );

    Ok(())
}

// =============================================================================
// POOLING KERNELS
// =============================================================================

/// Max pooling 2D
/// dims[0] = batch, dims[1] = channels, dims[2] = height, dims[3] = width
/// extra[0] = kernel_h, extra[1] = kernel_w, extra[2] = stride_h, extra[3] = stride_w
pub fn max_pool_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "MaxPool kernel requires 1 input and 1 output",
        ));
    }

    let batch = params.dims[0];
    let channels = params.dims[1];
    let in_h = params.dims[2];
    let in_w = params.dims[3];
    let kernel_h = params.extra[0];
    let kernel_w = params.extra[1];
    let stride_h = params.extra[2].max(1);
    let stride_w = params.extra[3].max(1);

    let out_h = (in_h - kernel_h) / stride_h + 1;
    let out_w = (in_w - kernel_w) / stride_w + 1;

    let input_size = batch * channels * in_h * in_w;
    let output_size = batch * channels * out_h * out_w;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, input_size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, output_size) };

    for n in 0..batch {
        for c in 0..channels {
            for oh in 0..out_h {
                for ow in 0..out_w {
                    let mut max_val = f32::NEG_INFINITY;
                    for kh in 0..kernel_h {
                        for kw in 0..kernel_w {
                            let ih = oh * stride_h + kh;
                            let iw = ow * stride_w + kw;
                            let idx = n * channels * in_h * in_w + c * in_h * in_w + ih * in_w + iw;
                            max_val = max_val.max(input[idx]);
                        }
                    }
                    let out_idx =
                        n * channels * out_h * out_w + c * out_h * out_w + oh * out_w + ow;
                    output[out_idx] = max_val;
                }
            }
        }
    }
    Ok(())
}

/// Average pooling 2D
pub fn avg_pool_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "AvgPool kernel requires 1 input and 1 output",
        ));
    }

    let batch = params.dims[0];
    let channels = params.dims[1];
    let in_h = params.dims[2];
    let in_w = params.dims[3];
    let kernel_h = params.extra[0];
    let kernel_w = params.extra[1];
    let stride_h = params.extra[2].max(1);
    let stride_w = params.extra[3].max(1);

    let out_h = (in_h - kernel_h) / stride_h + 1;
    let out_w = (in_w - kernel_w) / stride_w + 1;
    let pool_size = (kernel_h * kernel_w) as f32;

    let input_size = batch * channels * in_h * in_w;
    let output_size = batch * channels * out_h * out_w;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, input_size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, output_size) };

    for n in 0..batch {
        for c in 0..channels {
            for oh in 0..out_h {
                for ow in 0..out_w {
                    let mut sum = 0.0f32;
                    for kh in 0..kernel_h {
                        for kw in 0..kernel_w {
                            let ih = oh * stride_h + kh;
                            let iw = ow * stride_w + kw;
                            let idx = n * channels * in_h * in_w + c * in_h * in_w + ih * in_w + iw;
                            sum += input[idx];
                        }
                    }
                    let out_idx =
                        n * channels * out_h * out_w + c * out_h * out_w + oh * out_w + ow;
                    output[out_idx] = sum / pool_size;
                }
            }
        }
    }
    Ok(())
}

/// Global max pooling: reduce spatial dimensions to 1x1
pub fn global_max_pool_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "GlobalMaxPool kernel requires 1 input and 1 output",
        ));
    }

    let batch = params.dims[0];
    let channels = params.dims[1];
    let spatial_size = params.dims[2] * params.dims[3];

    let input_size = batch * channels * spatial_size;
    let output_size = batch * channels;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, input_size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, output_size) };

    for n in 0..batch {
        for c in 0..channels {
            let start = n * channels * spatial_size + c * spatial_size;
            let slice = &input[start..start + spatial_size];
            output[n * channels + c] = slice.iter().copied().fold(f32::NEG_INFINITY, f32::max);
        }
    }
    Ok(())
}

/// Global average pooling: reduce spatial dimensions to 1x1
pub fn global_avg_pool_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.is_empty() || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "GlobalAvgPool kernel requires 1 input and 1 output",
        ));
    }

    let batch = params.dims[0];
    let channels = params.dims[1];
    let spatial_size = params.dims[2] * params.dims[3];

    let input_size = batch * channels * spatial_size;
    let output_size = batch * channels;

    let input = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, input_size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, output_size) };

    for n in 0..batch {
        for c in 0..channels {
            let start = n * channels * spatial_size + c * spatial_size;
            let slice = &input[start..start + spatial_size];
            output[n * channels + c] = slice.iter().sum::<f32>() / spatial_size as f32;
        }
    }
    Ok(())
}

// =============================================================================
// LOSS KERNELS
// =============================================================================

/// Cross entropy loss: output = -sum(target * log(pred))
pub fn cross_entropy_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "CrossEntropy kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let pred = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let target = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, 1) };

    let eps = 1e-7f32;
    let loss: f32 = pred
        .iter()
        .zip(target.iter())
        .map(|(&p, &t)| -t * (p + eps).ln())
        .sum();
    output[0] = loss / size as f32;
    Ok(())
}

/// Mean squared error: output = mean((pred - target)^2)
pub fn mse_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "MSE kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let pred = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let target = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, 1) };

    let mse: f32 = pred
        .iter()
        .zip(target.iter())
        .map(|(&p, &t)| (p - t).powi(2))
        .sum::<f32>()
        / size as f32;
    output[0] = mse;
    Ok(())
}

/// Mean absolute error: output = mean(|pred - target|)
pub fn mae_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "MAE kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let pred = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let target = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, 1) };

    let mae: f32 = pred
        .iter()
        .zip(target.iter())
        .map(|(&p, &t)| (p - t).abs())
        .sum::<f32>()
        / size as f32;
    output[0] = mae;
    Ok(())
}

/// Huber loss: quadratic for small errors, linear for large
/// extra[0] = delta bits
pub fn huber_kernel_f32(
    inputs: &[*const u8],
    outputs: &[*mut u8],
    params: &KernelParams,
    _tables: &LookupTables,
) -> Result<(), BackendError> {
    if inputs.len() < 2 || outputs.is_empty() {
        return Err(BackendError::invalid_config(
            "Huber kernel requires 2 inputs and 1 output",
        ));
    }

    let size = params.dims[0];
    let delta = f32::from_bits(params.extra[0] as u32);
    let pred = unsafe { std::slice::from_raw_parts(inputs[0] as *const f32, size) };
    let target = unsafe { std::slice::from_raw_parts(inputs[1] as *const f32, size) };
    let output = unsafe { std::slice::from_raw_parts_mut(outputs[0] as *mut f32, 1) };

    let loss: f32 = pred
        .iter()
        .zip(target.iter())
        .map(|(&p, &t)| {
            let diff = (p - t).abs();
            if diff <= delta {
                0.5 * diff * diff
            } else {
                delta * (diff - 0.5 * delta)
            }
        })
        .sum::<f32>()
        / size as f32;
    output[0] = loss;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_relu_kernel() {
        let input = [-1.0f32, 0.0, 1.0, 2.0];
        let mut output = [0.0f32; 4];
        let params = KernelParams {
            dims: [4, 0, 0, 0],
            ..Default::default()
        };

        relu_kernel_f32(
            &[input.as_ptr() as *const u8],
            &[output.as_mut_ptr() as *mut u8],
            &params,
            &LookupTables::default(),
        )
        .unwrap();

        assert_eq!(output, [0.0, 0.0, 1.0, 2.0]);
    }

    #[test]
    fn test_add_kernel() {
        let a = [1.0f32, 2.0, 3.0, 4.0];
        let b = [4.0f32, 3.0, 2.0, 1.0];
        let mut output = [0.0f32; 4];
        let params = KernelParams {
            dims: [4, 4, 0, 0], // dims[1] = 4 for element-wise (not broadcast)
            ..Default::default()
        };

        add_kernel_f32(
            &[a.as_ptr() as *const u8, b.as_ptr() as *const u8],
            &[output.as_mut_ptr() as *mut u8],
            &params,
            &LookupTables::default(),
        )
        .unwrap();

        assert_eq!(output, [5.0, 5.0, 5.0, 5.0]);
    }

    #[test]
    fn test_reduce_sum_kernel() {
        let input = [1.0f32, 2.0, 3.0, 4.0];
        let mut output = [0.0f32];
        let params = KernelParams {
            dims: [4, 0, 0, 0],
            ..Default::default()
        };

        reduce_sum_kernel_f32(
            &[input.as_ptr() as *const u8],
            &[output.as_mut_ptr() as *mut u8],
            &params,
            &LookupTables::default(),
        )
        .unwrap();

        assert_eq!(output[0], 10.0);
    }

    #[test]
    fn test_reduce_argmax_last_token_kernel() {
        // batch=2, seq_len=3, vocab=4
        // For batch 0, last token logits: [0.1, 0.9, 0.2, 0.3] -> idx 1
        // For batch 1, last token logits: [0.4, 0.2, 0.8, 0.1] -> idx 2
        let input: [f32; 24] = [
            // batch 0, seq 0
            0.0, 0.1, 0.2, 0.3, // seq 1
            0.2, 0.1, 0.0, 0.4, // seq 2 (last)
            0.1, 0.9, 0.2, 0.3, // batch 1, seq 0
            0.0, 0.2, 0.1, 0.3, // seq 1
            0.2, 0.1, 0.0, 0.4, // seq 2 (last)
            0.4, 0.2, 0.8, 0.1,
        ];
        let mut output = [0i64; 2];
        let params = KernelParams {
            dims: [4, 3, 2, 0],
            ..Default::default()
        };

        reduce_argmax_last_token_kernel_f32(
            &[input.as_ptr() as *const u8],
            &[output.as_mut_ptr() as *mut u8],
            &params,
            &LookupTables::default(),
        )
        .unwrap();

        assert_eq!(output, [1, 2]);
    }

    #[test]
    fn test_reshape_kernel_alias() {
        let mut buffer = [1.0f32, 2.0, 3.0, 4.0];
        let params = KernelParams {
            dims: [4, 0, 0, 0],
            ..Default::default()
        };

        reshape_kernel_f32(
            &[buffer.as_ptr() as *const u8],
            &[buffer.as_mut_ptr() as *mut u8],
            &params,
            &LookupTables::default(),
        )
        .unwrap();

        assert_eq!(buffer, [1.0, 2.0, 3.0, 4.0]);
    }
}
