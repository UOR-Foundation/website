//! Plan assembly (Stage 8).
//!
//! This module assembles the final `BackendPlan` from all compilation stages:
//! - Emits ISA instructions from topological order
//! - Computes buffer metadata from layout decisions
//! - Embeds constant data (weights, lookup tables)
//! - Sets workspace size from workspace planning

use std::collections::HashMap;

use hologram_holo::types::BufferType;
use hologram_holo::{
    BackendPlan, BufferMetadata, IsaInstruction, LayerLocation, LayerRef, PlanMetadata,
};

use crate::graph::{CompileGraph, ConstantData, DType, OpKind};
use crate::pipeline::WorkspaceLayout;

/// Assemble the final `BackendPlan` from all compilation stages.
///
/// This function:
/// 1. Registers Input buffers in user-specified order
/// 2. Registers other buffers in topological order
/// 3. Emits ISA instructions for each operation
/// 4. Embeds constant data referenced by operations
/// 5. Sets the pre-computed workspace size
#[must_use]
#[allow(clippy::too_many_lines)]
pub fn assemble_plan(
    graph: &CompileGraph,
    workspace: &WorkspaceLayout,
    input_node_ids: &[u32],
    output_node_ids: &[u32],
    constants: &[ConstantData],
) -> BackendPlan {
    let topo_order = graph.topo_order();

    let mut buffer_registry = BufferRegistry::new();
    let mut instructions = Vec::new();
    let mut layer_ids: Vec<u64> = Vec::new();

    // First, register Input buffers in user-specified order.
    // This ensures buffer indices match the user's input registration order.
    for &node_id in input_node_ids {
        if let Some(node) = graph.get_node(node_id) {
            let element_count: usize = node.shape.iter().product();
            let buffer_size = element_count * dtype_size(node.dtype);
            let alignment = node.layout.map_or(8, |_| 32);
            buffer_registry.register(node_id, buffer_size, alignment, BufferType::Input);
        }
    }

    // Then register remaining buffers (workspace, constants) in topological order,
    // skipping nodes already registered as inputs.
    for &node_id in &topo_order {
        let Some(node) = graph.get_node(node_id) else {
            continue;
        };

        // Skip if already registered (inputs and outputs handled separately)
        if buffer_registry.has(node_id) {
            continue;
        }

        // Skip output nodes - they're registered last
        if output_node_ids.contains(&node_id) {
            continue;
        }

        // Register buffer
        let element_count: usize = node.shape.iter().product();
        let buffer_size = compute_output_size(&node.op, element_count, node.dtype);
        let alignment = node.layout.map_or(8, |_| 32);
        let buffer_type = classify_buffer_type(&node.op);

        buffer_registry.register(node_id, buffer_size, alignment, buffer_type);
    }

    // Finally, register Output buffers in user-specified order.
    for &node_id in output_node_ids {
        if let Some(node) = graph.get_node(node_id) {
            let element_count: usize = node.shape.iter().product();
            let buffer_size = element_count * dtype_size(node.dtype);
            let alignment = node.layout.map_or(8, |_| 32);
            buffer_registry.register(node_id, buffer_size, alignment, BufferType::Output);
        }
    }

    // Validate buffer registration completeness
    #[cfg(feature = "debug-large-graph")]
    {
        let missing = buffer_registry.validate_completeness(&topo_order);
        if !missing.is_empty() {
            eprintln!(
                "[BUG] {} node(s) in topo_order have no buffer registration:",
                missing.len()
            );
            for id in &missing {
                if let Some(node) = graph.get_node(*id) {
                    eprintln!("  - node {}: {:?}", id, node.op);
                } else {
                    eprintln!("  - node {id}: <not found in graph>");
                }
            }
        }
    }

    // Register synthetic constant buffers from quantization pass
    // These are folded constants that don't have corresponding graph nodes
    for (&node_id, data) in graph.folded_constants() {
        if !buffer_registry.has(node_id) {
            let buffer_size = data.to_bytes().len();
            buffer_registry.register(node_id, buffer_size, 8, BufferType::Constant);
        }
    }

    // Emit instructions in topological order
    #[cfg(feature = "debug-large-graph")]
    let mut skipped_ops = Vec::new();

    for &node_id in &topo_order {
        if let Some(instr) = emit_instruction(graph, node_id, &buffer_registry) {
            // Track CallLayer dependencies
            if let IsaInstruction::CallLayer { layer_id, .. } = &instr {
                if !layer_ids.contains(layer_id) {
                    layer_ids.push(*layer_id);
                }
            }
            instructions.push(instr);
        } else {
            // Track operations that should emit instructions but didn't
            #[cfg(feature = "debug-large-graph")]
            if let Some(node) = graph.get_node(node_id) {
                if should_emit_instruction(&node.op) {
                    skipped_ops.push((node_id, node.op.clone()));
                }
            }
        }
    }

    // Diagnostic: Report any skipped operations
    #[cfg(feature = "debug-large-graph")]
    if !skipped_ops.is_empty() {
        eprintln!(
            "[WARN] {} operation(s) failed to emit instructions:",
            skipped_ops.len()
        );
        for (id, op) in &skipped_ops {
            let has_buffer = buffer_registry.has(*id);
            let preds = graph.predecessors(*id);
            let pred_buffers: Vec<_> = preds.iter().map(|&p| (p, buffer_registry.has(p))).collect();
            eprintln!("  - node {id}: {op:?} (buffer={has_buffer}, preds={pred_buffers:?})",);
        }
    }

    // Serialize constants in buffer registration order
    // Folded constants (from constant folding pass) take priority over original constants
    let constant_index_map = build_constant_index_map(graph);
    let constants_blob = serialize_constants(
        &buffer_registry,
        constants,
        &constant_index_map,
        graph.folded_constants(),
    );

    // Build dependencies from tracked CallLayer layer_ids
    let dependencies: Vec<LayerRef> = layer_ids
        .iter()
        .map(|&id| {
            let mut layer_id_bytes = [0u8; 32];
            layer_id_bytes[..8].copy_from_slice(&id.to_le_bytes());
            LayerRef {
                layer_id: layer_id_bytes,
                name: None,
                location: LayerLocation::External(format!("layer_{id:016x}.holb")),
            }
        })
        .collect();

    BackendPlan {
        instructions,
        buffers: buffer_registry.to_metadata(),
        constants: constants_blob,
        workspace_size: workspace.total_size,
        dependencies,
        metadata: PlanMetadata::default(),
        node_buffer_map: buffer_registry.to_node_buffer_map(),
        observable_metadata: hologram_holo::types::ObservableMetadata::default(),
        // Embed LUT data for portable execution without uor dependency at runtime
        lut_section: hologram_holo::types::LutSection::with_embedded_luts(),
    }
}

fn classify_buffer_type(op: &OpKind) -> BufferType {
    match op {
        OpKind::Input => BufferType::Input,
        OpKind::Output => BufferType::Output,
        OpKind::Constant => BufferType::Constant,
        _ => BufferType::Workspace,
    }
}

/// Check if an operation should emit an ISA instruction.
/// Used for diagnostic validation.
#[cfg(feature = "debug-large-graph")]
fn should_emit_instruction(op: &OpKind) -> bool {
    !matches!(
        op,
        OpKind::Input | OpKind::Constant | OpKind::Div | OpKind::Mean
    )
}

/// Compute output buffer size for an operation.
/// Most operations preserve size, but Lift doubles it (1 byte input -> 2 byte `PackedCell`).
fn compute_output_size(op: &OpKind, element_count: usize, dtype: DType) -> usize {
    match op {
        // Lift outputs 2 bytes (PackedCell) per input byte
        OpKind::Lift => element_count * 2,
        // SHA-256 always outputs exactly 32 bytes regardless of input
        OpKind::Sha256 { .. } | OpKind::DoubleSha256 { .. } => 32,
        // Cast may change element size based on target dtype
        OpKind::Cast { to } => element_count * dtype_size(*to),
        // All other operations preserve size
        _ => element_count * dtype_size(dtype),
    }
}

/// Parse a LUT-GEMM annotation and emit a `MatMulLUT` instruction.
///
/// Annotation format: `lut_gemm:<bits>:<indices_id>:<centroids_id>:<m>:<k>:<n>`
fn parse_lut_gemm_annotation(
    annotation: &str,
    dst: u32,
    buffers: &BufferRegistry,
    preds: &[u32],
) -> Option<IsaInstruction> {
    let parts: Vec<&str> = annotation.split(':').collect();
    if parts.len() != 7 {
        return None;
    }

    let quant_bits: u8 = parts[1].parse().ok()?;
    let indices_id: u32 = parts[2].parse().ok()?;
    let centroids_id: u32 = parts[3].parse().ok()?;
    let m: usize = parts[4].parse().ok()?;
    let k: usize = parts[5].parse().ok()?;
    let n: usize = parts[6].parse().ok()?;

    // Get buffer indices for the quantized data
    let indices_buf = buffers.index(indices_id)?;
    let centroids_buf = buffers.index(centroids_id)?;
    let a_buf = buffers.index(preds[0])?; // Activation input

    Some(IsaInstruction::MatMulLUT {
        c: dst,
        a: a_buf,
        indices: indices_buf,
        centroids: centroids_buf,
        m,
        k,
        n,
        quant_bits,
    })
}

// ============================================================================
// EmissionContext: Context for emitting ISA instructions
// ============================================================================

/// Context for emitting ISA instructions from compile operations.
struct EmissionContext<'a> {
    graph: &'a CompileGraph,
    node: &'a crate::graph::CompileOp,
    preds: Vec<u32>,
    buffers: &'a BufferRegistry,
    dst: u32,
    count: usize,
}

impl<'a> EmissionContext<'a> {
    fn new(graph: &'a CompileGraph, node_id: u32, buffers: &'a BufferRegistry) -> Option<Self> {
        let node = graph.get_node(node_id)?;
        let preds = graph.predecessors(node_id);
        let count: usize = node.shape.iter().product();
        let dst = buffers.index(node_id)?;
        Some(Self {
            graph,
            node,
            preds,
            buffers,
            dst,
            count,
        })
    }

    fn has_annotation(&self, ann: &str) -> bool {
        self.node.annotations.iter().any(|a| a == ann)
    }

    fn unary_src(&self) -> Option<u32> {
        self.preds.first().and_then(|&p| self.buffers.index(p))
    }

    fn binary_srcs(&self) -> Option<(u32, u32)> {
        if self.preds.len() < 2 {
            return None;
        }
        Some((
            self.buffers.index(self.preds[0])?,
            self.buffers.index(self.preds[1])?,
        ))
    }

    fn pred_node(&self, idx: usize) -> Option<&'a crate::graph::CompileOp> {
        self.preds.get(idx).and_then(|&p| self.graph.get_node(p))
    }

    fn byte_size(&self) -> usize {
        self.count * dtype_size(self.node.dtype)
    }
}

// ============================================================================
// Binary Arithmetic Emitters
// ============================================================================

fn emit_add(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::Add {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

fn emit_sub(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::Sub {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

fn emit_mul(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::Mul {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

fn emit_div(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::Div {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

fn emit_pow(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::Pow {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

fn emit_elem_min(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::ElemMin {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

fn emit_elem_max(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::ElemMax {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

// ============================================================================
// Comparison Emitters
// ============================================================================

fn emit_greater(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::Greater {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

fn emit_less(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::Less {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

fn emit_less_or_equal(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::LessOrEqual {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

fn emit_greater_or_equal(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::GreaterOrEqual {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

fn emit_where(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    if ctx.preds.len() < 3 {
        return None;
    }
    Some(IsaInstruction::Where {
        dst: ctx.dst,
        cond: ctx.buffers.index(ctx.preds[0])?,
        x: ctx.buffers.index(ctx.preds[1])?,
        y: ctx.buffers.index(ctx.preds[2])?,
        count: ctx.count,
    })
}

// ============================================================================
// Unary Math / LUT Emitters
// ============================================================================

fn emit_sqrt(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let src = ctx.unary_src()?;
    if ctx.has_annotation("activation_lut:sqrt") {
        Some(IsaInstruction::SqrtLUT {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    } else {
        Some(IsaInstruction::Sqrt {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    }
}

fn emit_log(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let src = ctx.unary_src()?;
    if ctx.has_annotation("activation_lut:log") {
        Some(IsaInstruction::LogLUT {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    } else {
        Some(IsaInstruction::Log {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    }
}

fn emit_exp(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let src = ctx.unary_src()?;
    if ctx.has_annotation("activation_lut:exp") {
        Some(IsaInstruction::ExpLUT {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    } else {
        Some(IsaInstruction::Exp {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    }
}

fn emit_abs(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let src = ctx.unary_src()?;
    if ctx.has_annotation("activation_lut:abs") {
        Some(IsaInstruction::AbsLUT {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    } else {
        Some(IsaInstruction::Abs {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    }
}

// ============================================================================
// Activation Emitters
// ============================================================================

fn emit_sigmoid(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let src = ctx.unary_src()?;
    if ctx.has_annotation("activation_lut:sigmoid") {
        Some(IsaInstruction::SigmoidLUT {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    } else {
        Some(IsaInstruction::Sigmoid {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    }
}

fn emit_tanh(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let src = ctx.unary_src()?;
    if ctx.has_annotation("activation_lut:tanh") {
        Some(IsaInstruction::TanhLUT {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    } else {
        Some(IsaInstruction::Tanh {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    }
}

fn emit_relu(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let src = ctx.unary_src()?;
    if ctx.has_annotation("activation_lut:relu") {
        Some(IsaInstruction::ReluLUT {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    } else {
        Some(IsaInstruction::Relu {
            dst: ctx.dst,
            src,
            count: ctx.count,
        })
    }
}

fn emit_gelu(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    if !ctx.has_annotation("activation_lut:gelu") {
        return None;
    }
    let src = ctx.unary_src()?;
    Some(IsaInstruction::GeluLUT {
        dst: ctx.dst,
        src,
        count: ctx.count,
    })
}

fn emit_silu(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    if !ctx.has_annotation("activation_lut:silu") {
        return None;
    }
    let src = ctx.unary_src()?;
    Some(IsaInstruction::SiluLUT {
        dst: ctx.dst,
        src,
        count: ctx.count,
    })
}

fn emit_softmax(ctx: &EmissionContext<'_>, axis: i32) -> Option<IsaInstruction> {
    let src = ctx.unary_src()?;
    let ndim = ctx.node.shape.len();
    if ndim == 0 {
        return None;
    }

    // Normalize axis (negative indexing support)
    let norm_axis = if axis < 0 {
        let ndim_i32 = i32::try_from(ndim).ok()?;
        let result = ndim_i32.checked_add(axis)?;
        usize::try_from(result).ok()?
    } else {
        usize::try_from(axis).ok()?
    };

    if norm_axis >= ndim {
        return None;
    }

    let outer_size: usize = ctx.node.shape[..norm_axis].iter().product();
    let axis_size = ctx.node.shape[norm_axis];
    let inner_size: usize = if norm_axis + 1 < ndim {
        ctx.node.shape[norm_axis + 1..].iter().product()
    } else {
        1
    };

    Some(IsaInstruction::Softmax {
        dst: ctx.dst,
        src,
        outer_size: if outer_size == 0 { 1 } else { outer_size },
        axis_size,
        inner_size,
    })
}

// ============================================================================
// CNN Emitters
// ============================================================================

fn emit_conv2d(
    ctx: &EmissionContext<'_>,
    kernel: (usize, usize),
    stride: (usize, usize),
    padding: (usize, usize),
    dilation: (usize, usize),
    groups: usize,
) -> Option<IsaInstruction> {
    if ctx.preds.len() < 2 {
        return None;
    }
    let input_buf = ctx.buffers.index(ctx.preds[0])?;
    let weight_buf = ctx.buffers.index(ctx.preds[1])?;
    let bias_buf = if ctx.preds.len() > 2 {
        ctx.buffers.index(ctx.preds[2])
    } else {
        None
    };

    let input_node = ctx.pred_node(0)?;
    let (batch, in_c, in_h, in_w) = (
        input_node.shape[0],
        input_node.shape[1],
        input_node.shape[2],
        input_node.shape[3],
    );
    let (out_c, out_h, out_w) = (ctx.node.shape[1], ctx.node.shape[2], ctx.node.shape[3]);

    Some(IsaInstruction::Conv2d {
        dst: ctx.dst,
        input: input_buf,
        weight: weight_buf,
        bias: bias_buf,
        kernel_h: kernel.0,
        kernel_w: kernel.1,
        stride_h: stride.0,
        stride_w: stride.1,
        pad_h: padding.0,
        pad_w: padding.1,
        dilation_h: dilation.0,
        dilation_w: dilation.1,
        groups,
        batch,
        in_channels: in_c,
        out_channels: out_c,
        in_h,
        in_w,
        out_h,
        out_w,
    })
}

fn emit_batch_norm(ctx: &EmissionContext<'_>, epsilon: f32) -> Option<IsaInstruction> {
    if ctx.preds.len() < 5 {
        return None;
    }
    let input_node = ctx.pred_node(0)?;
    let (batch, channels) = (input_node.shape[0], input_node.shape[1]);
    let spatial: usize = input_node.shape[2..].iter().product();

    Some(IsaInstruction::BatchNorm {
        dst: ctx.dst,
        input: ctx.buffers.index(ctx.preds[0])?,
        scale: ctx.buffers.index(ctx.preds[1])?,
        bias: ctx.buffers.index(ctx.preds[2])?,
        mean: ctx.buffers.index(ctx.preds[3])?,
        var: ctx.buffers.index(ctx.preds[4])?,
        epsilon,
        batch,
        channels,
        spatial,
    })
}

fn emit_layer_norm(
    ctx: &EmissionContext<'_>,
    normalized_dims: usize,
    epsilon: f32,
) -> Option<IsaInstruction> {
    if ctx.preds.len() < 3 {
        return None;
    }
    let input_node = ctx.pred_node(0)?;
    let input_shape = &input_node.shape;

    if normalized_dims == 0 || normalized_dims > input_shape.len() {
        return None;
    }

    let normalized_count: usize = input_shape[input_shape.len() - normalized_dims..]
        .iter()
        .product();
    let num_instances: usize = input_shape[..input_shape.len() - normalized_dims]
        .iter()
        .product();

    Some(IsaInstruction::LayerNorm {
        dst: ctx.dst,
        input: ctx.buffers.index(ctx.preds[0])?,
        scale: ctx.buffers.index(ctx.preds[1])?,
        bias: ctx.buffers.index(ctx.preds[2])?,
        epsilon,
        num_instances,
        normalized_count,
    })
}

fn emit_max_pool(
    ctx: &EmissionContext<'_>,
    kernel: (usize, usize),
    stride: (usize, usize),
    padding: (usize, usize),
) -> Option<IsaInstruction> {
    let input_node = ctx.pred_node(0)?;
    let (batch, channels, in_h, in_w) = (
        input_node.shape[0],
        input_node.shape[1],
        input_node.shape[2],
        input_node.shape[3],
    );
    let (out_h, out_w) = (ctx.node.shape[2], ctx.node.shape[3]);

    Some(IsaInstruction::MaxPool2d {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        kernel_h: kernel.0,
        kernel_w: kernel.1,
        stride_h: stride.0,
        stride_w: stride.1,
        pad_h: padding.0,
        pad_w: padding.1,
        batch,
        channels,
        in_h,
        in_w,
        out_h,
        out_w,
    })
}

fn emit_avg_pool(
    ctx: &EmissionContext<'_>,
    kernel: (usize, usize),
    stride: (usize, usize),
    padding: (usize, usize),
) -> Option<IsaInstruction> {
    let input_node = ctx.pred_node(0)?;
    let (batch, channels, in_h, in_w) = (
        input_node.shape[0],
        input_node.shape[1],
        input_node.shape[2],
        input_node.shape[3],
    );
    let (out_h, out_w) = (ctx.node.shape[2], ctx.node.shape[3]);

    Some(IsaInstruction::AvgPool2d {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        kernel_h: kernel.0,
        kernel_w: kernel.1,
        stride_h: stride.0,
        stride_w: stride.1,
        pad_h: padding.0,
        pad_w: padding.1,
        batch,
        channels,
        in_h,
        in_w,
        out_h,
        out_w,
    })
}

fn emit_global_avg_pool(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let input_node = ctx.pred_node(0)?;
    let (batch, channels) = (input_node.shape[0], input_node.shape[1]);
    let spatial: usize = input_node.shape[2..].iter().product();

    Some(IsaInstruction::GlobalAvgPool {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        batch,
        channels,
        spatial,
    })
}

// ============================================================================
// Shape Emitters
// ============================================================================

fn emit_reshape(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    Some(IsaInstruction::Reshape {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        count: ctx.count,
    })
}

fn emit_flatten(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    Some(IsaInstruction::Copy {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        size: ctx.byte_size(),
    })
}

fn emit_output(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    Some(IsaInstruction::Copy {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        size: ctx.byte_size(),
    })
}

#[allow(clippy::cast_possible_truncation)]
fn emit_transpose(ctx: &EmissionContext<'_>, perm: &[usize]) -> Option<IsaInstruction> {
    let src_node = ctx.pred_node(0)?;
    let mut shape_arr = [1usize; 8];
    let mut perm_arr = [0u8; 8];
    for (i, &s) in src_node.shape.iter().take(8).enumerate() {
        shape_arr[i] = s;
    }
    for (i, &p) in perm.iter().take(8).enumerate() {
        perm_arr[i] = p as u8;
    }
    let ndim = perm.len().min(8) as u8;
    Some(IsaInstruction::Transpose {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        count: ctx.count,
        ndim,
        shape: shape_arr,
        perm: perm_arr,
    })
}

#[allow(clippy::cast_possible_truncation)]
fn emit_gather(ctx: &EmissionContext<'_>, axis: usize) -> Option<IsaInstruction> {
    if ctx.preds.len() < 2 {
        return None;
    }
    let data_node = ctx.pred_node(0)?;
    let indices_node = ctx.pred_node(1)?;
    let num_indices: usize = indices_node.shape.iter().product();
    let slice_size: usize = data_node
        .shape
        .iter()
        .skip(axis + 1)
        .product::<usize>()
        .max(1);
    let data_size: usize = data_node.shape.iter().product();

    Some(IsaInstruction::Gather {
        dst: ctx.dst,
        data: ctx.buffers.index(ctx.preds[0])?,
        indices: ctx.buffers.index(ctx.preds[1])?,
        axis: axis as u8,
        num_indices,
        slice_size,
        data_size,
    })
}

#[allow(clippy::cast_possible_truncation)]
fn emit_concat(
    ctx: &EmissionContext<'_>,
    axis: usize,
    num_inputs: usize,
) -> Option<IsaInstruction> {
    if ctx.preds.len() < num_inputs {
        return None;
    }
    let mut srcs = [0u32; 8];
    let mut sizes = [0usize; 8];
    for (i, &pred) in ctx.preds.iter().take(num_inputs).take(8).enumerate() {
        srcs[i] = ctx.buffers.index(pred)?;
        if let Some(pred_node) = ctx.graph.get_node(pred) {
            sizes[i] = pred_node.shape.iter().product::<usize>() * dtype_size(ctx.node.dtype);
        }
    }
    let num_srcs = num_inputs.min(8) as u8;
    let _ = axis; // axis is used for shape validation, not ISA instruction
    Some(IsaInstruction::Concat {
        dst: ctx.dst,
        srcs,
        num_srcs,
        sizes,
    })
}

fn emit_unsqueeze(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    Some(IsaInstruction::Unsqueeze {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        size: ctx.byte_size(),
    })
}

fn emit_squeeze(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    Some(IsaInstruction::Squeeze {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        size: ctx.byte_size(),
    })
}

#[allow(
    clippy::cast_possible_wrap,
    clippy::cast_sign_loss,
    clippy::cast_possible_truncation
)]
fn emit_slice(
    ctx: &EmissionContext<'_>,
    starts: &[isize],
    steps: &[isize],
) -> Option<IsaInstruction> {
    let src_node = ctx.pred_node(0)?;
    let ndim = src_node.shape.len().min(4);

    let mut src_shape_arr = [0u32; 4];
    let mut dst_shape_arr = [0u32; 4];
    let mut starts_arr = [0u32; 4];
    let mut steps_arr = [1i32; 4];

    for i in 0..ndim {
        src_shape_arr[i] = src_node.shape[i] as u32;

        let dim_size = src_node.shape[i];
        let start = if i < starts.len() {
            let s = starts[i];
            if s < 0 {
                (dim_size as isize + s).max(0) as usize
            } else {
                (s as usize).min(dim_size)
            }
        } else {
            0
        };
        starts_arr[i] = start as u32;

        let step = if i < steps.len() { steps[i] } else { 1 };
        steps_arr[i] = step as i32;
    }

    for (i, dst_dim) in dst_shape_arr
        .iter_mut()
        .enumerate()
        .take(ctx.node.shape.len().min(4))
    {
        *dst_dim = ctx.node.shape[i] as u32;
    }

    let elem_size = dtype_size(ctx.node.dtype) as u8;

    Some(IsaInstruction::Slice {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        ndim: ndim as u8,
        src_shape: src_shape_arr,
        dst_shape: dst_shape_arr,
        starts: starts_arr,
        steps: steps_arr,
        elem_size,
    })
}

#[allow(clippy::cast_possible_truncation)]
fn emit_split(
    ctx: &EmissionContext<'_>,
    axis: usize,
    split_sizes: &[usize],
    output_index: usize,
) -> Option<IsaInstruction> {
    let src_node = ctx.pred_node(0)?;
    let ndim = src_node.shape.len().min(4);

    let start_offset: usize = split_sizes.iter().take(output_index).sum();

    let mut src_shape_arr = [0u32; 4];
    let mut dst_shape_arr = [0u32; 4];
    let mut starts_arr = [0u32; 4];
    let steps_arr = [1i32; 4];

    for i in 0..ndim {
        #[allow(clippy::cast_possible_truncation)]
        {
            src_shape_arr[i] = src_node.shape[i] as u32;
            starts_arr[i] = if i == axis { start_offset as u32 } else { 0 };
        }
    }

    for (i, dst_dim) in dst_shape_arr
        .iter_mut()
        .enumerate()
        .take(ctx.node.shape.len().min(4))
    {
        #[allow(clippy::cast_possible_truncation)]
        {
            *dst_dim = ctx.node.shape[i] as u32;
        }
    }

    #[allow(clippy::cast_possible_truncation)]
    let elem_size = dtype_size(ctx.node.dtype) as u8;

    Some(IsaInstruction::Slice {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        ndim: ndim as u8,
        src_shape: src_shape_arr,
        dst_shape: dst_shape_arr,
        starts: starts_arr,
        steps: steps_arr,
        elem_size,
    })
}

#[allow(clippy::cast_possible_truncation)]
fn emit_pad(
    ctx: &EmissionContext<'_>,
    pads: &[(usize, usize)],
    constant_value: f32,
) -> Option<IsaInstruction> {
    let src_node = ctx.pred_node(0)?;
    let ndim = src_node.shape.len().min(4);

    let mut src_shape_arr = [0u32; 4];
    let mut pad_before_arr = [0u32; 4];
    let mut pad_after_arr = [0u32; 4];

    for i in 0..ndim {
        src_shape_arr[i] = src_node.shape[i] as u32;
        if i < pads.len() {
            pad_before_arr[i] = pads[i].0 as u32;
            pad_after_arr[i] = pads[i].1 as u32;
        }
    }

    let elem_size = dtype_size(ctx.node.dtype) as u8;

    Some(IsaInstruction::Pad {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        ndim: ndim as u8,
        src_shape: src_shape_arr,
        pad_before: pad_before_arr,
        pad_after: pad_after_arr,
        constant_value,
        elem_size,
    })
}

fn emit_cast(ctx: &EmissionContext<'_>, to: DType) -> Option<IsaInstruction> {
    let src_node = ctx.pred_node(0)?;
    Some(IsaInstruction::Cast {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        count: ctx.count,
        src_dtype: dtype_to_u8(src_node.dtype),
        dst_dtype: dtype_to_u8(to),
    })
}

#[allow(clippy::cast_possible_truncation)]
fn emit_tile(ctx: &EmissionContext<'_>, multiples: &[usize]) -> Option<IsaInstruction> {
    let src_node = ctx.pred_node(0)?;
    let mut input_shape = [0usize; 8];
    let mut multiples_arr = [1usize; 8];
    for (i, &s) in src_node.shape.iter().take(8).enumerate() {
        input_shape[i] = s;
    }
    for (i, &m) in multiples.iter().take(8).enumerate() {
        multiples_arr[i] = m;
    }
    let ndim = multiples.len().min(8) as u8;
    Some(IsaInstruction::Tile {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        ndim,
        input_shape,
        multiples: multiples_arr,
        count: ctx.count,
    })
}

#[allow(clippy::cast_possible_truncation)]
fn emit_expand(ctx: &EmissionContext<'_>, shape: &[usize]) -> Option<IsaInstruction> {
    let src_node = ctx.pred_node(0)?;
    let mut input_shape = [0usize; 8];
    let mut target_shape = [0usize; 8];

    let ndim = shape.len().min(8) as u8;

    let src_rank = src_node.shape.len();
    let tgt_rank = shape.len().min(8);
    let rank_diff = tgt_rank.saturating_sub(src_rank);

    for dim in input_shape.iter_mut().take(rank_diff) {
        *dim = 1;
    }
    for (i, &s) in src_node.shape.iter().take(8 - rank_diff).enumerate() {
        input_shape[rank_diff + i] = s;
    }
    for (i, &s) in shape.iter().take(8).enumerate() {
        target_shape[i] = s;
    }

    Some(IsaInstruction::Expand {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        ndim,
        input_shape,
        target_shape,
        count: ctx.count,
    })
}

// ============================================================================
// Linear Algebra / Reduction Emitters
// ============================================================================

fn emit_matmul(ctx: &EmissionContext<'_>, m: usize, k: usize, n: usize) -> Option<IsaInstruction> {
    if ctx.preds.len() < 2 {
        return None;
    }

    // Check for LUT-GEMM annotation from quantization pass
    if let Some(ann) = ctx
        .node
        .annotations
        .iter()
        .find(|a| a.starts_with("lut_gemm:"))
    {
        if let Some(instr) = parse_lut_gemm_annotation(ann, ctx.dst, ctx.buffers, &ctx.preds) {
            return Some(instr);
        }
    }

    Some(IsaInstruction::MatMul {
        c: ctx.dst,
        a: ctx.buffers.index(ctx.preds[0])?,
        b: ctx.buffers.index(ctx.preds[1])?,
        m,
        k,
        n,
    })
}

fn emit_batch_matmul(
    ctx: &EmissionContext<'_>,
    batch: &[usize],
    m: usize,
    k: usize,
    n: usize,
) -> Option<IsaInstruction> {
    if ctx.preds.len() < 2 {
        return None;
    }
    let batch_count: usize = batch.iter().product();
    Some(IsaInstruction::BatchMatMul {
        c: ctx.dst,
        a: ctx.buffers.index(ctx.preds[0])?,
        b: ctx.buffers.index(ctx.preds[1])?,
        batch_count,
        m,
        k,
        n,
    })
}

fn emit_sum_reduction(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let src_node = ctx.pred_node(0)?;
    let src_count: usize = src_node.shape.iter().product();
    Some(IsaInstruction::Sum {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        count: src_count,
    })
}

fn emit_max_reduction(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let src_node = ctx.pred_node(0)?;
    let src_count: usize = src_node.shape.iter().product();
    Some(IsaInstruction::Max {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        count: src_count,
    })
}

fn emit_min_reduction(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let src_node = ctx.pred_node(0)?;
    let src_count: usize = src_node.shape.iter().product();
    Some(IsaInstruction::Min {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        count: src_count,
    })
}

fn emit_mean_reduction(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let src_node = ctx.pred_node(0)?;
    let src_shape = &src_node.shape;
    let dst_shape = &ctx.node.shape;

    let (outer_size, axis_size, inner_size) = infer_reduction_axis(src_shape, dst_shape);

    Some(IsaInstruction::ReduceMean {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        outer_size,
        axis_size,
        inner_size,
    })
}

// ============================================================================
// Categorical Emitters
// ============================================================================

fn emit_lift(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    Some(IsaInstruction::Lift {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        count: ctx.count,
    })
}

fn emit_orbit_classify(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    Some(IsaInstruction::OrbitClassify {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        count: ctx.count,
    })
}

// ============================================================================
// Codec / Memory Emitters
// ============================================================================

fn emit_sha256(ctx: &EmissionContext<'_>, src_len: usize) -> Option<IsaInstruction> {
    Some(IsaInstruction::Sha256 {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        src_len,
    })
}

fn emit_double_sha256(ctx: &EmissionContext<'_>, src_len: usize) -> Option<IsaInstruction> {
    Some(IsaInstruction::DoubleSha256 {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        src_len,
    })
}

fn emit_encode(ctx: &EmissionContext<'_>, codec_id: u32) -> Option<IsaInstruction> {
    Some(IsaInstruction::Encode {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        codec_id,
        count: ctx.count,
    })
}

fn emit_decode(ctx: &EmissionContext<'_>, codec_id: u32) -> Option<IsaInstruction> {
    Some(IsaInstruction::Decode {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        codec_id,
        count: ctx.count,
    })
}

#[allow(clippy::unnecessary_wraps)]
fn emit_load(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    Some(IsaInstruction::Load {
        buffer: ctx.dst,
        offset: 0,
        size: ctx.byte_size(),
    })
}

fn emit_store(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    Some(IsaInstruction::Store {
        buffer: ctx.unary_src()?,
        offset: 0,
        size: ctx.byte_size(),
    })
}

fn emit_copy(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    Some(IsaInstruction::Copy {
        dst: ctx.dst,
        src: ctx.unary_src()?,
        size: ctx.byte_size(),
    })
}

#[allow(clippy::unnecessary_wraps)]
fn emit_call_layer(ctx: &EmissionContext<'_>, layer_id: u64) -> Option<IsaInstruction> {
    Some(IsaInstruction::CallLayer {
        layer_id,
        inputs: ctx
            .preds
            .iter()
            .filter_map(|&p| ctx.buffers.index(p))
            .collect(),
        outputs: vec![ctx.dst],
    })
}

fn emit_viterbi_tokenize(
    ctx: &EmissionContext<'_>,
    max_tokens: usize,
    normalize_flags: u32,
    unk_token_id: u32,
    unk_score: f32,
) -> Option<IsaInstruction> {
    if ctx.preds.len() < 2 {
        return None;
    }

    let src = ctx.buffers.index(ctx.preds[0])?;
    let src_node = ctx.pred_node(0)?;
    let src_len: usize = src_node.shape.iter().product();

    let vocab_data = ctx.buffers.index(ctx.preds[1])?;
    let vocab_node = ctx.pred_node(1)?;
    let vocab_size: usize = vocab_node.shape.iter().product();

    let dst_len = ctx.dst + 1;

    Some(IsaInstruction::ViterbiTokenize {
        dst: ctx.dst,
        dst_len,
        src,
        src_len,
        vocab_data,
        vocab_size,
        max_tokens,
        normalize_flags,
        unk_token_id,
        unk_score,
    })
}

fn emit_matmul_relu(
    ctx: &EmissionContext<'_>,
    m: usize,
    k: usize,
    n: usize,
) -> Option<IsaInstruction> {
    if ctx.preds.len() < 2 {
        return None;
    }
    Some(IsaInstruction::MatMulRelu {
        c: ctx.dst,
        a: ctx.buffers.index(ctx.preds[0])?,
        b: ctx.buffers.index(ctx.preds[1])?,
        m,
        k,
        n,
    })
}

fn emit_add_sigmoid(ctx: &EmissionContext<'_>) -> Option<IsaInstruction> {
    let (a, b) = ctx.binary_srcs()?;
    Some(IsaInstruction::AddSigmoid {
        dst: ctx.dst,
        a,
        b,
        count: ctx.count,
    })
}

/// Emit an ISA instruction for a given operation.
///
/// Delegates to category-specific emitter functions for each operation type.
#[allow(clippy::too_many_lines)]
fn emit_instruction(
    graph: &CompileGraph,
    node_id: u32,
    buffers: &BufferRegistry,
) -> Option<IsaInstruction> {
    let ctx = EmissionContext::new(graph, node_id, buffers)?;

    match &ctx.node.op {
        // Operations that don't generate instructions
        OpKind::Input | OpKind::Constant => None,

        // Binary arithmetic
        OpKind::Add => emit_add(&ctx),
        OpKind::Sub => emit_sub(&ctx),
        OpKind::Mul => emit_mul(&ctx),
        OpKind::Div => emit_div(&ctx),
        OpKind::Pow => emit_pow(&ctx),
        OpKind::ElemMin => emit_elem_min(&ctx),
        OpKind::ElemMax => emit_elem_max(&ctx),

        // Comparisons
        OpKind::Greater => emit_greater(&ctx),
        OpKind::Less => emit_less(&ctx),
        OpKind::LessOrEqual => emit_less_or_equal(&ctx),
        OpKind::GreaterOrEqual => emit_greater_or_equal(&ctx),
        OpKind::Where => emit_where(&ctx),

        // Unary math / LUT
        OpKind::Sqrt => emit_sqrt(&ctx),
        OpKind::Log => emit_log(&ctx),
        OpKind::Exp => emit_exp(&ctx),
        OpKind::Abs => emit_abs(&ctx),

        // Activations
        OpKind::Sigmoid => emit_sigmoid(&ctx),
        OpKind::Tanh => emit_tanh(&ctx),
        OpKind::Relu => emit_relu(&ctx),
        OpKind::Gelu => emit_gelu(&ctx),
        OpKind::Silu => emit_silu(&ctx),
        OpKind::Softmax { axis } => emit_softmax(&ctx, *axis),

        // CNN operations
        OpKind::Conv2d {
            kernel,
            stride,
            padding,
            dilation,
            groups,
        } => emit_conv2d(&ctx, *kernel, *stride, *padding, *dilation, *groups),
        OpKind::BatchNormalization { epsilon } => emit_batch_norm(&ctx, *epsilon),
        OpKind::LayerNorm {
            normalized_dims,
            epsilon,
        } => emit_layer_norm(&ctx, *normalized_dims, *epsilon),
        OpKind::MaxPool {
            kernel,
            stride,
            padding,
        } => emit_max_pool(&ctx, *kernel, *stride, *padding),
        OpKind::AvgPool {
            kernel,
            stride,
            padding,
        } => emit_avg_pool(&ctx, *kernel, *stride, *padding),
        OpKind::GlobalAveragePool => emit_global_avg_pool(&ctx),

        // Shape operations
        OpKind::Reshape { .. } => emit_reshape(&ctx),
        OpKind::Flatten { .. } => emit_flatten(&ctx),
        OpKind::Output => emit_output(&ctx),
        OpKind::Transpose { perm } => emit_transpose(&ctx, perm),
        OpKind::Gather { axis } => emit_gather(&ctx, *axis),
        OpKind::Concat { axis, num_inputs } => emit_concat(&ctx, *axis, *num_inputs),
        OpKind::Unsqueeze { .. } => emit_unsqueeze(&ctx),
        OpKind::Squeeze { .. } => emit_squeeze(&ctx),
        OpKind::Slice {
            starts,
            ends: _,
            steps,
        } => emit_slice(&ctx, starts, steps),
        OpKind::Split {
            axis,
            split_sizes,
            output_index,
        } => emit_split(&ctx, *axis, split_sizes, *output_index),
        OpKind::Pad {
            pads,
            mode: _,
            constant_value,
        } => emit_pad(&ctx, pads, *constant_value),
        OpKind::Cast { to } => emit_cast(&ctx, *to),
        OpKind::Tile { multiples } => emit_tile(&ctx, multiples),
        OpKind::Expand { shape } => emit_expand(&ctx, shape),

        // Linear algebra
        OpKind::MatMul { m, k, n } => emit_matmul(&ctx, *m, *k, *n),
        OpKind::BatchMatMul { batch, m, k, n } => emit_batch_matmul(&ctx, batch, *m, *k, *n),

        // Reductions
        OpKind::Sum => emit_sum_reduction(&ctx),
        OpKind::Max => emit_max_reduction(&ctx),
        OpKind::Min => emit_min_reduction(&ctx),
        OpKind::Mean => emit_mean_reduction(&ctx),

        // Categorical ops
        OpKind::Lift => emit_lift(&ctx),
        OpKind::OrbitClassify => emit_orbit_classify(&ctx),

        // Hash operations
        OpKind::Sha256 { src_len } => emit_sha256(&ctx, *src_len),
        OpKind::DoubleSha256 { src_len } => emit_double_sha256(&ctx, *src_len),

        // Codec operations
        OpKind::Encode { codec_id } => emit_encode(&ctx, *codec_id),
        OpKind::Decode { codec_id } => emit_decode(&ctx, *codec_id),

        // Memory ops
        OpKind::Load => emit_load(&ctx),
        OpKind::Store => emit_store(&ctx),
        OpKind::Copy => emit_copy(&ctx),

        // Control flow
        OpKind::CallLayer { layer_id } => emit_call_layer(&ctx, *layer_id),

        // Tokenization
        OpKind::ViterbiTokenize {
            max_tokens,
            normalize_flags,
            unk_token_id,
            unk_score,
        } => emit_viterbi_tokenize(
            &ctx,
            *max_tokens,
            *normalize_flags,
            *unk_token_id,
            *unk_score,
        ),

        // Fused operations (TASK-327)
        OpKind::MatMulRelu { m, k, n } => emit_matmul_relu(&ctx, *m, *k, *n),
        OpKind::AddSigmoid => emit_add_sigmoid(&ctx),
    }
}

/// Infer reduction axis from input/output shape changes.
///
/// Returns (`outer_size`, `axis_size`, `inner_size`) for axis-aware reduction.
///
/// Example: `src_shape`=[1, 5, 512], `dst_shape`=[1, 5, 1]
/// - axis=2, `axis_size`=512
/// - `outer_size` = 1*5 = 5
/// - `inner_size` = 1
fn infer_reduction_axis(src_shape: &[usize], dst_shape: &[usize]) -> (usize, usize, usize) {
    // Find the axis that was reduced (went from N to 1)
    // Handle shape differences (keepdims=true means same rank, keepdims=false means fewer dims)
    let src_ndim = src_shape.len();
    let dst_ndim = dst_shape.len();

    // Common case: keepdims=true, same rank, find dimension that became 1
    if src_ndim == dst_ndim {
        for i in 0..src_ndim {
            if src_shape[i] > 1 && dst_shape[i] == 1 {
                // Found the reduced axis
                let outer: usize = src_shape[..i].iter().product();
                let axis_size = src_shape[i];
                let inner: usize = src_shape[i + 1..].iter().product();
                return (
                    if outer == 0 { 1 } else { outer },
                    axis_size,
                    if inner == 0 { 1 } else { inner },
                );
            }
        }
    }

    // Fallback: reduce all elements (full reduction)
    // This handles cases where we can't infer the axis
    let total: usize = src_shape.iter().product();
    (1, if total == 0 { 1 } else { total }, 1)
}

const fn dtype_size(dtype: DType) -> usize {
    match dtype {
        DType::F32 | DType::I32 | DType::U32 => 4,
        DType::F64 | DType::I64 | DType::U64 => 8,
        DType::I8 | DType::U8 | DType::Bool => 1,
        DType::I16 | DType::U16 => 2,
    }
}

/// Convert `DType` to u8 encoding for ISA instructions.
const fn dtype_to_u8(dtype: DType) -> u8 {
    match dtype {
        DType::F32 => 0,
        DType::F64 => 1,
        DType::I8 => 2,
        DType::I16 => 3,
        DType::I32 => 4,
        DType::I64 => 5,
        DType::U8 => 6,
        DType::U16 => 7,
        DType::U32 => 8,
        DType::U64 => 9,
        DType::Bool => 10,
    }
}

/// Build a map from constant node IDs to their index in the constants array.
///
/// Uses `constant_nodes_in_order()` which preserves the insertion order from
/// `OperationGraph`. This matches the order `add_constant()` was called,
/// which is critical because `graph.constants[]` is indexed by insertion order.
fn build_constant_index_map(graph: &CompileGraph) -> Vec<(u32, usize)> {
    graph
        .constant_nodes_in_order()
        .iter()
        .copied()
        .enumerate()
        .map(|(idx, node_id)| (node_id, idx))
        .collect()
}

/// Serialize constants to bytes in buffer registration order.
///
/// The runtime iterates through buffers sequentially and uses a running offset
/// to read constant data. This function serializes constants in the same order
/// as Constant buffers appear in the buffer registry.
///
/// Folded constants (computed during constant folding) take priority over
/// original constants. This ensures that operations like Transpose(Constant)
/// produce correctly transformed data.
fn serialize_constants(
    registry: &BufferRegistry,
    original_constants: &[ConstantData],
    constant_index_map: &[(u32, usize)],
    folded_constants: &HashMap<u32, ConstantData>,
) -> Vec<u8> {
    let mut blob = Vec::new();

    #[cfg(feature = "debug-large-graph")]
    let mut const_buffer_idx = 0usize;

    for (node_id, meta) in registry.entries() {
        if meta.buffer_type != BufferType::Constant {
            continue;
        }

        // First check if this is a folded constant (takes priority)
        if let Some(data) = folded_constants.get(&node_id) {
            let bytes = data.to_bytes();
            let copy_len = bytes.len().min(meta.size);
            blob.extend_from_slice(&bytes[..copy_len]);
            // Pad if constant data is smaller than buffer size
            if copy_len < meta.size {
                blob.resize(blob.len() + meta.size - copy_len, 0);
            }
            #[cfg(feature = "debug-large-graph")]
            {
                const_buffer_idx += 1;
            }
            continue;
        }

        // Fall back to original constants via index map
        let const_idx = constant_index_map
            .iter()
            .find(|(id, _)| *id == node_id)
            .map(|(_, idx)| *idx);

        #[cfg(feature = "debug-large-graph")]
        {
            if const_idx.is_none() {
                eprintln!(
                    "[BUG] No constant mapping for node {node_id} (const_buffer_idx={const_buffer_idx})",
                );
            }
        }

        // Serialize constant data (or zeros if missing)
        if let Some(idx) = const_idx {
            if let Some(data) = original_constants.get(idx) {
                let bytes = data.to_bytes();
                let copy_len = bytes.len().min(meta.size);
                blob.extend_from_slice(&bytes[..copy_len]);
                // Pad if constant data is smaller than buffer size
                if copy_len < meta.size {
                    #[cfg(feature = "debug-large-graph")]
                    eprintln!(
                        "[WARN] Padding constant node {} with {} zeros (bytes.len={}, meta.size={})",
                        node_id,
                        meta.size - copy_len,
                        bytes.len(),
                        meta.size
                    );
                    blob.resize(blob.len() + meta.size - copy_len, 0);
                }
            } else {
                panic!(
                    "BUG: Constant index {idx} out of bounds for node {node_id}. \
                     original_constants has {} entries. This indicates a mismatch between \
                     constant nodes and constant data.",
                    original_constants.len()
                );
            }
        } else {
            panic!(
                "BUG: No constant data found for node {node_id}. The node is registered as a \
                 Constant buffer but has no entry in constant_index_map or folded_constants. \
                 Use add_constant_for_node() to explicitly link constant data to nodes."
            );
        }

        #[cfg(feature = "debug-large-graph")]
        {
            const_buffer_idx += 1;
        }
    }

    blob
}

struct BufferRegistry {
    entries: Vec<(u32, BufferMetadata)>,
    node_ids: Vec<u32>,
    /// Node ID to buffer index mapping for O(1) lookup.
    /// Indexed by `node_id`, value is `Some(buffer_idx)` if node has a buffer.
    node_to_buffer: Vec<Option<u32>>,
}

impl BufferRegistry {
    fn new() -> Self {
        Self {
            entries: Vec::new(),
            node_ids: Vec::new(),
            node_to_buffer: Vec::new(),
        }
    }

    fn register(&mut self, node_id: u32, size: usize, alignment: usize, buffer_type: BufferType) {
        let base = BufferMetadata::with_alignment(size, alignment, buffer_type);
        // Output and Workspace buffers are always fully written by their first
        // instruction (matmul, element-wise ops, etc.), so the runtime can skip
        // pre-zeroing them.
        let metadata = match buffer_type {
            BufferType::Output | BufferType::Workspace => base.with_fully_written(),
            _ => base,
        };
        #[allow(clippy::cast_possible_truncation)]
        let buffer_idx = self.entries.len() as u32;
        self.entries.push((node_id, metadata));
        self.node_ids.push(node_id);

        // Ensure node_to_buffer is large enough
        let required_len = (node_id as usize) + 1;
        if self.node_to_buffer.len() < required_len {
            self.node_to_buffer.resize(required_len, None);
        }
        self.node_to_buffer[node_id as usize] = Some(buffer_idx);
    }

    fn index(&self, node_id: u32) -> Option<u32> {
        self.node_to_buffer.get(node_id as usize).copied().flatten()
    }

    fn has(&self, node_id: u32) -> bool {
        self.index(node_id).is_some()
    }

    fn to_metadata(&self) -> Vec<BufferMetadata> {
        self.entries.iter().map(|(_, meta)| *meta).collect()
    }

    fn to_node_buffer_map(&self) -> Vec<Option<u32>> {
        self.node_to_buffer.clone()
    }

    /// Iterate over registered buffers with their node IDs.
    fn entries(&self) -> impl Iterator<Item = (u32, &BufferMetadata)> {
        self.entries.iter().map(|(id, meta)| (*id, meta))
    }

    /// Validate that all expected nodes have buffer registrations.
    /// Returns list of node IDs that are missing buffers.
    #[cfg(feature = "debug-large-graph")]
    fn validate_completeness(&self, expected_nodes: &[u32]) -> Vec<u32> {
        expected_nodes
            .iter()
            .filter(|&&id| !self.has(id))
            .copied()
            .collect()
    }
}

/// Get the total number of instructions in a plan.
#[must_use]
pub fn instruction_count(plan: &BackendPlan) -> usize {
    plan.instructions.len()
}

/// Get the total number of buffers in a plan.
#[must_use]
pub fn buffer_count(plan: &BackendPlan) -> usize {
    plan.buffers.len()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{OpNode, OperationGraph};

    /// Creates a test graph and returns (`CompileGraph`, `input_ids`, `output_ids`)
    fn make_graph(
        nodes: Vec<OpNode>,
        edges: Vec<(u32, u32)>,
    ) -> (CompileGraph, Vec<u32>, Vec<u32>) {
        let mut graph = OperationGraph::new();
        let mut input_ids = Vec::new();
        let mut output_ids = Vec::new();

        for node in &nodes {
            if matches!(node.op, OpKind::Input) {
                input_ids.push(node.id);
            } else if matches!(node.op, OpKind::Output) {
                output_ids.push(node.id);
            }
        }

        for node in nodes {
            graph.add_node(node);
        }
        for (src, dst) in edges {
            graph.add_edge(src, dst);
        }
        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        (compile_graph, input_ids, output_ids)
    }

    #[test]
    fn test_assemble_empty_plan() {
        let (graph, inputs, outputs) = make_graph(vec![], vec![]);
        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);
        assert!(plan.instructions.is_empty());
        assert!(plan.buffers.is_empty());
    }

    #[test]
    fn test_assemble_io_only() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // Now Output nodes emit Copy, so we have 1 instruction
        assert_eq!(instruction_count(&plan), 1);
        assert_eq!(buffer_count(&plan), 2);
    }

    #[test]
    fn test_assemble_single_relu() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // Relu + Copy for output
        assert_eq!(instruction_count(&plan), 2);
        assert!(matches!(plan.instructions[0], IsaInstruction::Relu { .. }));
        assert_eq!(buffer_count(&plan), 3);
    }

    #[test]
    fn test_assemble_add_operation() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Input, vec![64], DType::F32),
                OpNode::new(2, OpKind::Add, vec![64], DType::F32),
                OpNode::new(3, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // Add + Copy for output
        assert_eq!(instruction_count(&plan), 2);
        match &plan.instructions[0] {
            IsaInstruction::Add { dst, a, b, count } => {
                assert_eq!(*count, 64);
                assert_ne!(*a, *b);
                assert_ne!(*dst, *a);
            }
            _ => panic!("Expected Add instruction"),
        }
    }

    #[test]
    fn test_assemble_matmul() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![8, 16], DType::F32),
                OpNode::new(1, OpKind::Input, vec![16, 32], DType::F32),
                OpNode::new(
                    2,
                    OpKind::MatMul { m: 8, k: 16, n: 32 },
                    vec![8, 32],
                    DType::F32,
                ),
                OpNode::new(3, OpKind::Output, vec![8, 32], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // MatMul + Copy for output
        assert_eq!(instruction_count(&plan), 2);
        match &plan.instructions[0] {
            IsaInstruction::MatMul { m, k, n, .. } => {
                assert_eq!(*m, 8);
                assert_eq!(*k, 16);
                assert_eq!(*n, 32);
            }
            _ => panic!("Expected MatMul instruction"),
        }
    }

    #[test]
    fn test_assemble_chain() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64], DType::F32),
                OpNode::new(3, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1), (1, 2), (2, 3)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // Relu + Sigmoid + Copy
        assert_eq!(instruction_count(&plan), 3);
        assert!(matches!(plan.instructions[0], IsaInstruction::Relu { .. }));
        assert!(matches!(
            plan.instructions[1],
            IsaInstruction::Sigmoid { .. }
        ));
    }

    #[test]
    fn test_assemble_sum_reduction() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Sum, vec![1], DType::F32),
                OpNode::new(2, OpKind::Output, vec![1], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // Sum + Copy
        assert_eq!(instruction_count(&plan), 2);
        match &plan.instructions[0] {
            IsaInstruction::Sum { count, .. } => {
                assert_eq!(*count, 64);
            }
            _ => panic!("Expected Sum instruction"),
        }
    }

    #[test]
    fn test_assemble_lift_operation() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::U8),
                OpNode::new(1, OpKind::Lift, vec![256], DType::U8),
                OpNode::new(2, OpKind::Output, vec![256], DType::U8),
            ],
            vec![(0, 1), (1, 2)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // Lift + Copy
        assert_eq!(instruction_count(&plan), 2);
        assert!(matches!(plan.instructions[0], IsaInstruction::Lift { .. }));
    }

    #[test]
    fn test_assemble_workspace_size() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let workspace = WorkspaceLayout {
            total_size: 4096,
            slots: vec![],
        };
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        assert_eq!(plan.workspace_size, 4096);
    }

    #[test]
    fn test_assemble_buffer_types() {
        // Build graph manually to include constant data
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![64], DType::F32));
        graph.add_node(OpNode::new(1, OpKind::Constant, vec![64], DType::F32));
        graph.add_constant_for_node(1, ConstantData::F32(vec![0.0; 64]));
        graph.add_node(OpNode::new(2, OpKind::Add, vec![64], DType::F32));
        graph.add_node(OpNode::new(3, OpKind::Output, vec![64], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);
        graph.add_edge(2, 3);

        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        let inputs = vec![0];
        let outputs = vec![3];

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(
            &compile_graph,
            &workspace,
            &inputs,
            &outputs,
            &graph.constants,
        );

        // Check buffer types exist
        let buffer_types: Vec<_> = plan.buffers.iter().map(|b| b.buffer_type).collect();
        assert!(buffer_types.contains(&BufferType::Input));
        assert!(buffer_types.contains(&BufferType::Constant));
        assert!(buffer_types.contains(&BufferType::Workspace));
        assert!(buffer_types.contains(&BufferType::Output));
        assert_eq!(plan.buffers.len(), 4);
    }

    #[test]
    fn test_assemble_buffer_sizes() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![32, 32], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![32, 32], DType::F32),
                OpNode::new(2, OpKind::Output, vec![32, 32], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        for buffer in &plan.buffers {
            assert_eq!(buffer.size, 4096);
        }
    }

    #[test]
    fn test_assemble_complex_graph() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64], DType::F32),
                OpNode::new(2, OpKind::Sigmoid, vec![64], DType::F32),
                OpNode::new(3, OpKind::Add, vec![64], DType::F32),
                OpNode::new(4, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1), (0, 2), (1, 3), (2, 3), (3, 4)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // Relu + Sigmoid + Add + Copy
        assert_eq!(instruction_count(&plan), 4);
        assert_eq!(buffer_count(&plan), 5);
    }

    #[test]
    fn test_dtype_size() {
        assert_eq!(dtype_size(DType::F32), 4);
        assert_eq!(dtype_size(DType::F64), 8);
        assert_eq!(dtype_size(DType::I8), 1);
        assert_eq!(dtype_size(DType::U8), 1);
        assert_eq!(dtype_size(DType::I16), 2);
        assert_eq!(dtype_size(DType::U16), 2);
        assert_eq!(dtype_size(DType::I32), 4);
        assert_eq!(dtype_size(DType::U32), 4);
        assert_eq!(dtype_size(DType::I64), 8);
        assert_eq!(dtype_size(DType::U64), 8);
    }

    #[test]
    fn test_buffer_registry() {
        let mut registry = BufferRegistry::new();
        registry.register(10, 1024, 32, BufferType::Input);
        registry.register(20, 2048, 64, BufferType::Workspace);
        registry.register(30, 512, 16, BufferType::Output);

        assert_eq!(registry.index(10), Some(0));
        assert_eq!(registry.index(20), Some(1));
        assert_eq!(registry.index(30), Some(2));
        assert_eq!(registry.index(99), None);
        assert!(registry.has(10));
        assert!(!registry.has(99));

        let metadata = registry.to_metadata();
        assert_eq!(metadata.len(), 3);
        assert_eq!(metadata[0].size, 1024);
        assert_eq!(metadata[1].alignment, 64);
        assert_eq!(metadata[2].buffer_type, BufferType::Output);

        // Verify node_buffer_map
        let map = registry.to_node_buffer_map();
        assert_eq!(map.len(), 31); // max node_id is 30, so len is 31
        assert_eq!(map[10], Some(0));
        assert_eq!(map[20], Some(1));
        assert_eq!(map[30], Some(2));
        assert_eq!(map[0], None); // no node at index 0
    }

    #[test]
    fn test_node_buffer_map_in_plan() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![64], DType::F32),
                OpNode::new(1, OpKind::Relu, vec![64], DType::F32),
                OpNode::new(2, OpKind::Output, vec![64], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // Verify node_buffer_map is populated
        assert!(!plan.node_buffer_map.is_empty());

        // Each node should map to a unique buffer index
        assert_eq!(plan.node_buffer_map[0], Some(0)); // Input at buffer 0
        assert_eq!(plan.node_buffer_map[1], Some(1)); // Relu at buffer 1
        assert_eq!(plan.node_buffer_map[2], Some(2)); // Output at buffer 2

        // Verify buffer lookup matches direct index
        for (node_id, expected_buf) in [(0, 0), (1, 1), (2, 2)] {
            assert_eq!(
                plan.node_buffer_map[node_id],
                Some(expected_buf),
                "node {node_id} should map to buffer {expected_buf}"
            );
        }
    }

    #[test]
    fn test_assemble_tanh() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![32], DType::F32),
                OpNode::new(1, OpKind::Tanh, vec![32], DType::F32),
                OpNode::new(2, OpKind::Output, vec![32], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // Tanh + Copy
        assert_eq!(instruction_count(&plan), 2);
        assert!(matches!(plan.instructions[0], IsaInstruction::Tanh { .. }));
    }

    #[test]
    fn test_assemble_sub_mul() {
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![16], DType::F32),
                OpNode::new(1, OpKind::Input, vec![16], DType::F32),
                OpNode::new(2, OpKind::Sub, vec![16], DType::F32),
                OpNode::new(3, OpKind::Mul, vec![16], DType::F32),
                OpNode::new(4, OpKind::Output, vec![16], DType::F32),
            ],
            vec![(0, 2), (1, 2), (2, 3), (1, 3), (3, 4)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // Sub + Mul + Copy
        assert_eq!(instruction_count(&plan), 3);
        assert!(matches!(plan.instructions[0], IsaInstruction::Sub { .. }));
        assert!(matches!(plan.instructions[1], IsaInstruction::Mul { .. }));
    }

    #[test]
    fn test_assemble_with_single_constant() {
        let mut graph = OperationGraph::new();

        // Node 0: Input [4] f32
        graph.add_node(OpNode::new(0, OpKind::Input, vec![4], DType::F32));
        graph.add_input("input", 0);

        // Node 1: Constant [4] f32
        graph.add_node(OpNode::new(1, OpKind::Constant, vec![4], DType::F32));
        graph.add_constant_for_node(1, ConstantData::F32(vec![1.0, 2.0, 3.0, 4.0]));

        // Node 2: Add (input + constant)
        graph.add_node(OpNode::new(2, OpKind::Add, vec![4], DType::F32));
        graph.add_edge(0, 2);
        graph.add_edge(1, 2);

        // Node 3: Output
        graph.add_node(OpNode::new(3, OpKind::Output, vec![4], DType::F32));
        graph.add_edge(2, 3);
        graph.add_output("output", 3);

        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        let input_ids: Vec<u32> = graph.inputs.iter().map(|(_, id)| *id).collect();
        let output_ids: Vec<u32> = graph.outputs.iter().map(|(_, id)| *id).collect();

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(
            &compile_graph,
            &workspace,
            &input_ids,
            &output_ids,
            &graph.constants,
        );

        // Verify constants are embedded
        assert!(
            !plan.constants.is_empty(),
            "BackendPlan.constants should contain the constant data"
        );

        // 4 floats * 4 bytes = 16 bytes
        assert_eq!(plan.constants.len(), 16);

        // Verify the actual constant values
        let expected: Vec<u8> = [1.0f32, 2.0, 3.0, 4.0]
            .iter()
            .flat_map(|f| f.to_le_bytes())
            .collect();
        assert_eq!(plan.constants, expected);
    }

    #[test]
    fn test_assemble_with_multiple_constants() {
        let mut graph = OperationGraph::new();

        // Node 0: Input [4] f32
        graph.add_node(OpNode::new(0, OpKind::Input, vec![4], DType::F32));
        graph.add_input("input", 0);

        // Node 1: Constant (weights) [4] f32
        graph.add_node(OpNode::new(1, OpKind::Constant, vec![4], DType::F32));
        graph.add_constant_for_node(1, ConstantData::F32(vec![1.0, 2.0, 3.0, 4.0]));

        // Node 2: Constant (bias) [4] f32
        graph.add_node(OpNode::new(2, OpKind::Constant, vec![4], DType::F32));
        graph.add_constant_for_node(2, ConstantData::F32(vec![0.1, 0.2, 0.3, 0.4]));

        // Node 3: Mul (input * weights)
        graph.add_node(OpNode::new(3, OpKind::Mul, vec![4], DType::F32));
        graph.add_edge(0, 3);
        graph.add_edge(1, 3);

        // Node 4: Add (mul_result + bias)
        graph.add_node(OpNode::new(4, OpKind::Add, vec![4], DType::F32));
        graph.add_edge(3, 4);
        graph.add_edge(2, 4);

        // Node 5: Output
        graph.add_node(OpNode::new(5, OpKind::Output, vec![4], DType::F32));
        graph.add_edge(4, 5);
        graph.add_output("output", 5);

        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        let input_ids: Vec<u32> = graph.inputs.iter().map(|(_, id)| *id).collect();
        let output_ids: Vec<u32> = graph.outputs.iter().map(|(_, id)| *id).collect();

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(
            &compile_graph,
            &workspace,
            &input_ids,
            &output_ids,
            &graph.constants,
        );

        // 2 constants * 4 floats * 4 bytes = 32 bytes
        assert_eq!(plan.constants.len(), 32);
    }

    #[test]
    fn test_assemble_constants_correct_order() {
        let mut graph = OperationGraph::new();

        // Create nodes in non-sequential order to test ordering
        // Node 5: Input
        graph.add_node(OpNode::new(5, OpKind::Input, vec![2], DType::F32));
        graph.add_input("input", 5);

        // Node 10: Constant (added first to constants vec)
        graph.add_node(OpNode::new(10, OpKind::Constant, vec![2], DType::F32));
        graph.add_constant_for_node(10, ConstantData::F32(vec![1.0, 2.0]));

        // Node 15: Constant (added second to constants vec)
        graph.add_node(OpNode::new(15, OpKind::Constant, vec![2], DType::F32));
        graph.add_constant_for_node(15, ConstantData::F32(vec![3.0, 4.0]));

        // Node 20: Add
        graph.add_node(OpNode::new(20, OpKind::Add, vec![2], DType::F32));
        graph.add_edge(5, 20);
        graph.add_edge(10, 20);

        // Node 25: Add
        graph.add_node(OpNode::new(25, OpKind::Add, vec![2], DType::F32));
        graph.add_edge(20, 25);
        graph.add_edge(15, 25);

        // Node 30: Output
        graph.add_node(OpNode::new(30, OpKind::Output, vec![2], DType::F32));
        graph.add_edge(25, 30);
        graph.add_output("output", 30);

        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        let input_ids: Vec<u32> = graph.inputs.iter().map(|(_, id)| *id).collect();
        let output_ids: Vec<u32> = graph.outputs.iter().map(|(_, id)| *id).collect();

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(
            &compile_graph,
            &workspace,
            &input_ids,
            &output_ids,
            &graph.constants,
        );

        // 2 constants * 2 floats * 4 bytes = 16 bytes
        assert_eq!(plan.constants.len(), 16);
    }

    #[test]
    #[allow(clippy::too_many_lines)]
    fn test_cnn_operations_emit_instructions() {
        // Build a mini-CNN: Input -> Conv2d -> BatchNorm -> ReLU -> MaxPool -> GlobalAvgPool -> Flatten -> Output
        let mut graph = OperationGraph::new();

        // Node 0: Input [1, 1, 8, 8] (batch=1, channels=1, height=8, width=8)
        graph.add_node(OpNode::new(0, OpKind::Input, vec![1, 1, 8, 8], DType::F32));
        graph.add_input("input", 0);

        // Node 1: Conv2d weights [4, 1, 3, 3] (out_channels=4, in_channels=1, kernel=3x3)
        graph.add_node(OpNode::new(
            1,
            OpKind::Constant,
            vec![4, 1, 3, 3],
            DType::F32,
        ));
        #[allow(clippy::cast_precision_loss)]
        let conv_weights: Vec<f32> = (0..36).map(|i: i32| (i as f32) * 0.01).collect();
        graph.add_constant_for_node(1, ConstantData::F32(conv_weights));

        // Node 2: Conv2d bias [4]
        graph.add_node(OpNode::new(2, OpKind::Constant, vec![4], DType::F32));
        graph.add_constant_for_node(2, ConstantData::F32(vec![0.1, 0.2, 0.3, 0.4]));

        // Node 3: Conv2d output [1, 4, 8, 8] (with padding=1 to preserve spatial dims)
        graph.add_node(OpNode::new(
            3,
            OpKind::Conv2d {
                kernel: (3, 3),
                stride: (1, 1),
                padding: (1, 1),
                dilation: (1, 1),
                groups: 1,
            },
            vec![1, 4, 8, 8],
            DType::F32,
        ));
        graph.add_edge(0, 3); // input
        graph.add_edge(1, 3); // weights
        graph.add_edge(2, 3); // bias

        // Node 4-7: BatchNorm parameters (scale, bias, mean, var)
        graph.add_node(OpNode::new(4, OpKind::Constant, vec![4], DType::F32));
        graph.add_constant_for_node(4, ConstantData::F32(vec![1.0, 1.0, 1.0, 1.0])); // scale (gamma)

        graph.add_node(OpNode::new(5, OpKind::Constant, vec![4], DType::F32));
        graph.add_constant_for_node(5, ConstantData::F32(vec![0.0, 0.0, 0.0, 0.0])); // bias (beta)

        graph.add_node(OpNode::new(6, OpKind::Constant, vec![4], DType::F32));
        graph.add_constant_for_node(6, ConstantData::F32(vec![0.0, 0.0, 0.0, 0.0])); // running mean

        graph.add_node(OpNode::new(7, OpKind::Constant, vec![4], DType::F32));
        graph.add_constant_for_node(7, ConstantData::F32(vec![1.0, 1.0, 1.0, 1.0])); // running var

        // Node 8: BatchNorm output [1, 4, 8, 8]
        graph.add_node(OpNode::new(
            8,
            OpKind::BatchNormalization { epsilon: 1e-5 },
            vec![1, 4, 8, 8],
            DType::F32,
        ));
        graph.add_edge(3, 8); // input (conv output)
        graph.add_edge(4, 8); // scale
        graph.add_edge(5, 8); // bias
        graph.add_edge(6, 8); // mean
        graph.add_edge(7, 8); // var

        // Node 9: ReLU [1, 4, 8, 8]
        graph.add_node(OpNode::new(9, OpKind::Relu, vec![1, 4, 8, 8], DType::F32));
        graph.add_edge(8, 9);

        // Node 10: MaxPool [1, 4, 4, 4] (kernel=2, stride=2)
        graph.add_node(OpNode::new(
            10,
            OpKind::MaxPool {
                kernel: (2, 2),
                stride: (2, 2),
                padding: (0, 0),
            },
            vec![1, 4, 4, 4],
            DType::F32,
        ));
        graph.add_edge(9, 10);

        // Node 11: GlobalAveragePool [1, 4, 1, 1]
        graph.add_node(OpNode::new(
            11,
            OpKind::GlobalAveragePool,
            vec![1, 4, 1, 1],
            DType::F32,
        ));
        graph.add_edge(10, 11);

        // Node 12: Flatten [1, 4]
        graph.add_node(OpNode::new(
            12,
            OpKind::Flatten { start_dim: 1 },
            vec![1, 4],
            DType::F32,
        ));
        graph.add_edge(11, 12);

        // Node 13: Output
        graph.add_node(OpNode::new(13, OpKind::Output, vec![1, 4], DType::F32));
        graph.add_edge(12, 13);
        graph.add_output("output", 13);

        let compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();
        let input_ids: Vec<u32> = graph.inputs.iter().map(|(_, id)| *id).collect();
        let output_ids: Vec<u32> = graph.outputs.iter().map(|(_, id)| *id).collect();

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(
            &compile_graph,
            &workspace,
            &input_ids,
            &output_ids,
            &graph.constants,
        );

        // Verify constants are loaded
        assert!(
            !plan.constants.is_empty(),
            "Constants should contain conv weights and batchnorm params"
        );

        // Count instruction types
        let mut conv_count = 0;
        let mut bn_count = 0;
        let mut maxpool_count = 0;
        let mut gap_count = 0;
        let mut relu_count = 0;

        for instr in &plan.instructions {
            let name = format!("{instr:?}");
            if name.starts_with("Conv2d") {
                conv_count += 1;
            }
            if name.starts_with("BatchNorm") {
                bn_count += 1;
            }
            if name.starts_with("MaxPool") {
                maxpool_count += 1;
            }
            if name.starts_with("GlobalAvgPool") {
                gap_count += 1;
            }
            if name.starts_with("Relu") {
                relu_count += 1;
            }
        }

        // Verify the CNN ops emit instructions
        assert_eq!(conv_count, 1, "Should emit 1 Conv2d instruction");
        assert_eq!(bn_count, 1, "Should emit 1 BatchNorm instruction");
        assert_eq!(maxpool_count, 1, "Should emit 1 MaxPool instruction");
        assert_eq!(gap_count, 1, "Should emit 1 GlobalAvgPool instruction");
        assert_eq!(relu_count, 1, "Should emit 1 ReLU instruction");
    }

    #[test]
    fn test_assemble_sigmoid_lut_with_annotation() {
        // When a Sigmoid node has the activation_lut:sigmoid annotation,
        // it should emit SigmoidLUT instead of Sigmoid
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![256], DType::U8));
        graph.add_node(OpNode::new(1, OpKind::Sigmoid, vec![256], DType::U8));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![256], DType::U8));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_input("input", 0);
        graph.add_output("output", 2);

        let mut compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();

        // Add the activation_lut annotation
        compile_graph.add_annotation(1, "activation_lut:sigmoid".to_string());

        let inputs = vec![0];
        let outputs = vec![2];
        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&compile_graph, &workspace, &inputs, &outputs, &[]);

        // Should emit SigmoidLUT, not Sigmoid
        assert!(
            plan.instructions
                .iter()
                .any(|i| matches!(i, IsaInstruction::SigmoidLUT { .. })),
            "Should emit SigmoidLUT instruction"
        );
        assert!(
            !plan
                .instructions
                .iter()
                .any(|i| matches!(i, IsaInstruction::Sigmoid { .. })),
            "Should NOT emit regular Sigmoid instruction"
        );
    }

    #[test]
    fn test_assemble_tanh_lut_with_annotation() {
        // When a Tanh node has the activation_lut:tanh annotation,
        // it should emit TanhLUT instead of Tanh
        let mut graph = OperationGraph::new();
        graph.add_node(OpNode::new(0, OpKind::Input, vec![256], DType::U8));
        graph.add_node(OpNode::new(1, OpKind::Tanh, vec![256], DType::U8));
        graph.add_node(OpNode::new(2, OpKind::Output, vec![256], DType::U8));
        graph.add_edge(0, 1);
        graph.add_edge(1, 2);
        graph.add_input("input", 0);
        graph.add_output("output", 2);

        let mut compile_graph = CompileGraph::from_operation_graph(&graph).unwrap();

        // Add the activation_lut annotation
        compile_graph.add_annotation(1, "activation_lut:tanh".to_string());

        let inputs = vec![0];
        let outputs = vec![2];
        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&compile_graph, &workspace, &inputs, &outputs, &[]);

        // Should emit TanhLUT, not Tanh
        assert!(
            plan.instructions
                .iter()
                .any(|i| matches!(i, IsaInstruction::TanhLUT { .. })),
            "Should emit TanhLUT instruction"
        );
        assert!(
            !plan
                .instructions
                .iter()
                .any(|i| matches!(i, IsaInstruction::Tanh { .. })),
            "Should NOT emit regular Tanh instruction"
        );
    }

    #[test]
    fn test_assemble_sigmoid_without_annotation_emits_regular() {
        // Without the annotation, Sigmoid should emit regular Sigmoid
        let (graph, inputs, outputs) = make_graph(
            vec![
                OpNode::new(0, OpKind::Input, vec![256], DType::F32),
                OpNode::new(1, OpKind::Sigmoid, vec![256], DType::F32),
                OpNode::new(2, OpKind::Output, vec![256], DType::F32),
            ],
            vec![(0, 1), (1, 2)],
        );

        let workspace = WorkspaceLayout::default();
        let plan = assemble_plan(&graph, &workspace, &inputs, &outputs, &[]);

        // Should emit regular Sigmoid, not SigmoidLUT
        assert!(
            plan.instructions
                .iter()
                .any(|i| matches!(i, IsaInstruction::Sigmoid { .. })),
            "Should emit Sigmoid instruction"
        );
        assert!(
            !plan
                .instructions
                .iter()
                .any(|i| matches!(i, IsaInstruction::SigmoidLUT { .. })),
            "Should NOT emit SigmoidLUT instruction"
        );
    }
}
