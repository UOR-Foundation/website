//! Pre-built operation sequences.
//!
//! Provides ready-made programs that compose multiple wavefront
//! operations into common cryptographic and mathematical primitives.

pub mod aes;
pub mod sha256;
