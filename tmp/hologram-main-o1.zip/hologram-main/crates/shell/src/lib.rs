//! Shell DSL parser and code generator for ISA and query layers.
//!
//! Parses `.shell` files into an AST and (in later phases) generates Rust code
//! for ISA dispatch infrastructure and query-layer resolvers.
//!
//! # Example
//!
//! ```
//! let input = r#"
//! shell isa {
//!     op matmul(c: buf, a: buf, b: buf, m: usize, k: usize, n: usize)
//! }
//! "#;
//! let shell = hologram_shell::parse_shell(input).unwrap();
//! assert_eq!(shell.name, "isa");
//! ```

pub mod ast;
pub mod emit_isa;
pub mod emit_query;
pub mod emit_shacl;
pub mod error;
pub mod naming;
mod parse;
pub mod parse_shacl;

pub use error::ParseError;
pub use parse::parse_shell;
