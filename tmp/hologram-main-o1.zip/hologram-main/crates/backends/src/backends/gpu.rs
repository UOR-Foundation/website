//! GPU backend trait extensions.
//!
//! This module defines GPU-specific trait extensions that add capabilities
//! beyond the base [`Backend`](super::Backend) trait for GPU-accelerated execution.
//!
//! # Architecture
//!
//! GPU backends extend the base `Backend` trait with:
//! - Device enumeration and selection
//! - GPU memory allocation and transfer
//! - Kernel dispatch and synchronization
//!
//! # Implementations
//!
//! - [`cuda`](super::cuda) - NVIDIA CUDA backend (skeleton)
//! - [`metal`](super::metal) - Apple Metal backend (skeleton)
//! - [`webgpu`](super::webgpu) - Cross-platform WebGPU backend (skeleton)
//!
//! # Zero-Copy Design
//!
//! GPU backends maintain the zero-copy contract where possible:
//! - Constants are uploaded once and cached on device
//! - Workspace is pre-allocated on device
//! - Only inputs/outputs cross the host-device boundary per execution

use crate::types::Result;

/// GPU device information.
#[derive(Debug, Clone)]
pub struct GpuDevice {
    /// Device index (0-based)
    pub index: u32,
    /// Device name (e.g., "NVIDIA GeForce RTX 3090")
    pub name: String,
    /// Total device memory in bytes
    pub total_memory: u64,
    /// Available device memory in bytes
    pub available_memory: u64,
    /// Compute capability or version string
    pub compute_version: String,
}

/// GPU memory buffer handle.
///
/// Represents an allocation on GPU device memory. The actual implementation
/// is backend-specific (CUDA device pointer, Metal buffer, etc.).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct GpuBuffer {
    /// Opaque handle to device memory
    pub handle: u64,
    /// Size in bytes
    pub size: usize,
}

/// GPU kernel execution configuration.
#[derive(Debug, Clone, Copy)]
pub struct KernelConfig {
    /// Grid dimensions (number of thread blocks)
    pub grid: [u32; 3],
    /// Block dimensions (threads per block)
    pub block: [u32; 3],
    /// Shared memory size in bytes
    pub shared_memory: u32,
}

impl Default for KernelConfig {
    fn default() -> Self {
        Self {
            grid: [1, 1, 1],
            block: [256, 1, 1],
            shared_memory: 0,
        }
    }
}

/// GPU backend trait extension.
///
/// Provides GPU-specific operations beyond the base `Backend` trait.
/// Implementations handle device management, memory transfers, and kernel dispatch.
///
/// # Example (Conceptual)
///
/// ```ignore
/// let backend = CudaBackend::new()?;
///
/// // Enumerate devices
/// let devices = backend.enumerate_devices()?;
/// backend.select_device(devices[0].index)?;
///
/// // Allocate and transfer
/// let gpu_input = backend.allocate(1024)?;
/// backend.upload(gpu_input, &host_data)?;
///
/// // Execute plan (uses GPU)
/// backend.execute_plan(&plan, &[&input], &mut [&mut output])?;
///
/// // Cleanup
/// backend.free(gpu_input)?;
/// ```
pub trait GpuBackend: super::Backend {
    // ========================================================================
    // Device Management
    // ========================================================================

    /// Enumerate available GPU devices.
    ///
    /// Returns information about all compatible devices on the system.
    fn enumerate_devices(&self) -> Result<Vec<GpuDevice>>;

    /// Select a device for subsequent operations.
    ///
    /// # Arguments
    /// * `device_index` - Index from `enumerate_devices()`
    fn select_device(&mut self, device_index: u32) -> Result<()>;

    /// Get the currently selected device, if any.
    fn current_device(&self) -> Option<&GpuDevice>;

    // ========================================================================
    // Memory Management
    // ========================================================================

    /// Allocate GPU device memory.
    ///
    /// # Arguments
    /// * `size` - Size in bytes to allocate
    ///
    /// # Returns
    /// Handle to the allocated GPU buffer.
    fn allocate(&mut self, size: usize) -> Result<GpuBuffer>;

    /// Free GPU device memory.
    ///
    /// # Arguments
    /// * `buffer` - Handle from `allocate()`
    fn free(&mut self, buffer: GpuBuffer) -> Result<()>;

    /// Upload data from host to device.
    ///
    /// # Arguments
    /// * `dst` - Destination GPU buffer
    /// * `src` - Source host data
    fn upload(&mut self, dst: GpuBuffer, src: &[u8]) -> Result<()>;

    /// Download data from device to host.
    ///
    /// # Arguments
    /// * `src` - Source GPU buffer
    /// * `dst` - Destination host buffer
    fn download(&self, src: GpuBuffer, dst: &mut [u8]) -> Result<()>;

    // ========================================================================
    // Synchronization
    // ========================================================================

    /// Synchronize with the device (wait for all operations to complete).
    fn synchronize(&self) -> Result<()>;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_gpu_device_clone() {
        let device = GpuDevice {
            index: 0,
            name: "Test GPU".into(),
            total_memory: 8 * 1024 * 1024 * 1024,
            available_memory: 6 * 1024 * 1024 * 1024,
            compute_version: "8.6".into(),
        };
        let cloned = device.clone();
        assert_eq!(cloned.index, 0);
        assert_eq!(cloned.name, "Test GPU");
    }

    #[test]
    fn test_gpu_buffer_equality() {
        let buf1 = GpuBuffer {
            handle: 0x1234,
            size: 1024,
        };
        let buf2 = GpuBuffer {
            handle: 0x1234,
            size: 1024,
        };
        let buf3 = GpuBuffer {
            handle: 0x5678,
            size: 1024,
        };
        assert_eq!(buf1, buf2);
        assert_ne!(buf1, buf3);
    }

    #[test]
    fn test_kernel_config_default() {
        let config = KernelConfig::default();
        assert_eq!(config.grid, [1, 1, 1]);
        assert_eq!(config.block, [256, 1, 1]);
        assert_eq!(config.shared_memory, 0);
    }
}
