//! Error types for orchestration operations.

use crate::types::WorkerHandle;
use std::time::Duration;
use thiserror::Error;

/// Error type for orchestration operations.
#[derive(Debug, Error)]
pub enum OrchestrateError {
    /// Worker provisioning failed.
    #[error("failed to provision worker: {message}")]
    ProvisionFailed {
        /// Error message describing the failure.
        message: String,
    },

    /// Worker not found.
    #[error("worker not found: {0}")]
    WorkerNotFound(WorkerHandle),

    /// Operation timed out.
    #[error("operation '{operation}' timed out after {duration:?}")]
    Timeout {
        /// Name of the operation that timed out.
        operation: String,
        /// Duration before timeout.
        duration: Duration,
    },

    /// Backend communication error.
    #[error("backend error: {message}")]
    BackendError {
        /// Error message from the backend.
        message: String,
    },

    /// Configuration error.
    #[error("configuration error: {message}")]
    ConfigError {
        /// Configuration error message.
        message: String,
    },

    /// Resource exhausted.
    #[error("resource exhausted: {resource}")]
    ResourceExhausted {
        /// Name of the exhausted resource.
        resource: String,
    },

    /// Worker in unexpected state.
    #[error("worker in unexpected state: expected {expected}, got {actual}")]
    UnexpectedState {
        /// Expected state.
        expected: String,
        /// Actual state.
        actual: String,
    },

    /// Network error during P2P join.
    #[error("network error: {message}")]
    NetworkError {
        /// Network error message.
        message: String,
    },

    /// Security error (authentication, token validation, etc.).
    #[error("security error: {message}")]
    SecurityError {
        /// Security error message.
        message: String,
    },

    /// Certificate error (generation, validation, etc.).
    #[error("certificate error: {message}")]
    CertificateError {
        /// Certificate error message.
        message: String,
    },

    /// IO error.
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),

    /// Serialization error.
    #[error("serialization error: {message}")]
    Serialization {
        /// Serialization error message.
        message: String,
    },

    /// Firecracker-specific error.
    #[cfg(feature = "firecracker")]
    #[error("firecracker error: {message}")]
    Firecracker {
        /// Firecracker error message.
        message: String,
    },

    /// Kubernetes-specific error.
    #[cfg(feature = "kubernetes")]
    #[error("kubernetes error: {message}")]
    Kubernetes {
        /// Kubernetes error message.
        message: String,
    },
}

impl OrchestrateError {
    /// Create a provision failed error.
    pub fn provision_failed(message: impl Into<String>) -> Self {
        Self::ProvisionFailed {
            message: message.into(),
        }
    }

    /// Create a backend error.
    pub fn backend(message: impl Into<String>) -> Self {
        Self::BackendError {
            message: message.into(),
        }
    }

    /// Create a config error.
    pub fn config(message: impl Into<String>) -> Self {
        Self::ConfigError {
            message: message.into(),
        }
    }

    /// Create a security error.
    pub fn security(message: impl Into<String>) -> Self {
        Self::SecurityError {
            message: message.into(),
        }
    }

    /// Create a certificate error.
    pub fn certificate(message: impl Into<String>) -> Self {
        Self::CertificateError {
            message: message.into(),
        }
    }

    /// Create a timeout error.
    pub fn timeout(operation: impl Into<String>, duration: Duration) -> Self {
        Self::Timeout {
            operation: operation.into(),
            duration,
        }
    }

    /// Create a serialization error.
    pub fn serialization(message: impl Into<String>) -> Self {
        Self::Serialization {
            message: message.into(),
        }
    }

    /// Create a network error.
    pub fn network(message: impl Into<String>) -> Self {
        Self::NetworkError {
            message: message.into(),
        }
    }

    /// Create a resource exhausted error.
    pub fn resource_exhausted(resource: impl Into<String>) -> Self {
        Self::ResourceExhausted {
            resource: resource.into(),
        }
    }

    /// Create an unexpected state error.
    pub fn unexpected_state(expected: impl Into<String>, actual: impl Into<String>) -> Self {
        Self::UnexpectedState {
            expected: expected.into(),
            actual: actual.into(),
        }
    }

    /// Check if this is a retryable error.
    #[must_use]
    pub fn is_retryable(&self) -> bool {
        matches!(
            self,
            Self::Timeout { .. } | Self::NetworkError { .. } | Self::Io(_)
        )
    }

    /// Check if this is a configuration error.
    #[must_use]
    pub fn is_config_error(&self) -> bool {
        matches!(self, Self::ConfigError { .. })
    }

    /// Check if this is a security error.
    #[must_use]
    pub fn is_security_error(&self) -> bool {
        matches!(
            self,
            Self::SecurityError { .. } | Self::CertificateError { .. }
        )
    }
}

/// Result type for orchestration operations.
pub type Result<T> = std::result::Result<T, OrchestrateError>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_error_display() {
        let err = OrchestrateError::provision_failed("VM creation failed");
        assert!(err.to_string().contains("VM creation failed"));

        let err = OrchestrateError::WorkerNotFound(WorkerHandle(42));
        // WorkerHandle displays as hex: worker-0000002a
        assert!(err.to_string().contains("worker-0000002a"));

        let err = OrchestrateError::timeout("connect", Duration::from_secs(30));
        assert!(err.to_string().contains("connect"));
        assert!(err.to_string().contains("30"));
    }

    #[test]
    fn test_error_constructors() {
        let _ = OrchestrateError::backend("connection refused");
        let _ = OrchestrateError::config("invalid path");
        let _ = OrchestrateError::security("token expired");
        let _ = OrchestrateError::certificate("invalid signature");
        let _ = OrchestrateError::serialization("invalid JSON");
        let _ = OrchestrateError::network("connection refused");
        let _ = OrchestrateError::resource_exhausted("memory");
        let _ = OrchestrateError::unexpected_state("Running", "Failed");
    }

    #[test]
    fn test_is_retryable() {
        assert!(OrchestrateError::timeout("test", Duration::from_secs(1)).is_retryable());
        assert!(OrchestrateError::network("test").is_retryable());
        assert!(!OrchestrateError::config("test").is_retryable());
        assert!(!OrchestrateError::security("test").is_retryable());
    }

    #[test]
    fn test_is_config_error() {
        assert!(OrchestrateError::config("test").is_config_error());
        assert!(!OrchestrateError::security("test").is_config_error());
    }

    #[test]
    fn test_is_security_error() {
        assert!(OrchestrateError::security("test").is_security_error());
        assert!(OrchestrateError::certificate("test").is_security_error());
        assert!(!OrchestrateError::config("test").is_security_error());
    }

    #[test]
    fn test_io_error_from() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "file not found");
        let err: OrchestrateError = io_err.into();
        assert!(matches!(err, OrchestrateError::Io(_)));
        assert!(err.is_retryable());
    }

    #[test]
    fn test_error_debug() {
        let err = OrchestrateError::provision_failed("test");
        let debug = format!("{:?}", err);
        assert!(debug.contains("ProvisionFailed"));
    }
}
