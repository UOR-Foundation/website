/**
 * TrustMeter — How much others trust you, and how to build that trust.
 *
 * Plain language, no jargon. Shows a simple progress bar and
 * clear milestones anyone can understand.
 */

import type { TrustScore, CeremonyRecord } from "../types";
import { trustLevelFromCeremonies } from "../engine";
import { Shield, CheckCircle, Users } from "lucide-react";

interface Props {
  readonly trustScore: TrustScore | null;
  readonly ceremonies?: readonly CeremonyRecord[];
}

const LEVEL_LABELS: Record<string, { label: string; description: string; color: string }> = {
  sovereign: { label: "Fully trusted", description: "You've built a strong reputation", color: "text-primary" },
  verified: { label: "Verified", description: "People have confirmed who you are", color: "text-primary" },
  basic: { label: "Getting started", description: "A few people know you", color: "text-primary/70" },
  minimal: { label: "Just beginning", description: "You've made your first connection", color: "text-muted-foreground" },
  unknown: { label: "New", description: "No one has verified you yet — and that's okay", color: "text-muted-foreground/60" },
  distrusted: { label: "Flagged", description: "Something needs attention", color: "text-destructive" },
};

const MILESTONES = [
  { count: 1, label: "First step" },
  { count: 4, label: "Getting known" },
  { count: 11, label: "Verified" },
  { count: 25, label: "Fully trusted" },
] as const;

export default function TrustMeter({ trustScore, ceremonies = [] }: Props) {
  const level = trustScore?.level ?? "unknown";
  const info = LEVEL_LABELS[level] || LEVEL_LABELS.unknown;

  const peerCount = ceremonies.filter((c) => c.type === "peer").length;
  const ceremonyLevel = trustLevelFromCeremonies(ceremonies);
  const ceremonyInfo = LEVEL_LABELS[ceremonyLevel] || LEVEL_LABELS.unknown;

  // Find next milestone
  const nextMilestone = MILESTONES.find((m) => peerCount < m.count);
  const currentIdx = MILESTONES.findIndex((m) => m.label === ceremonyInfo.label);
  const currentThreshold = currentIdx >= 0 ? MILESTONES[currentIdx].count : 0;
  const nextThreshold = nextMilestone?.count ?? 25;
  const progress = nextMilestone
    ? ((peerCount - currentThreshold) / (nextThreshold - currentThreshold)) * 100
    : 100;

  return (
    <div className="rounded-2xl border border-border/15 bg-card/30 p-6 animate-fade-in space-y-6">
      {/* Current status */}
      <div>
        <p className="text-sm text-muted-foreground/50 mb-5">
          Trust grows when real people verify who you are. The more connections you make, the stronger your reputation.
        </p>

        <div className="flex items-center gap-4 mb-5">
          <div className={`shrink-0 ${info.color}`}>
            {level === "unknown" || level === "minimal" ? (
              <Shield className="h-7 w-7" />
            ) : (
              <CheckCircle className="h-7 w-7" />
            )}
          </div>
          <div>
            <p className={`text-lg font-medium ${info.color}`}>{info.label}</p>
            <p className="text-sm text-muted-foreground/50">{info.description}</p>
          </div>
        </div>
      </div>

      <div className="border-t border-border/15" />

      {/* Progress toward next milestone */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-muted-foreground/40" />
            <span className="text-sm text-foreground">
              {peerCount} {peerCount === 1 ? "person" : "people"} verified you
            </span>
          </div>
          {nextMilestone && (
            <span className="text-xs text-muted-foreground/40">
              {nextMilestone.count - peerCount} more to reach "{nextMilestone.label}"
            </span>
          )}
        </div>

        {/* Progress bar */}
        <div className="w-full h-2 rounded-full bg-muted/40 overflow-hidden mb-4">
          <div
            className="h-full rounded-full bg-primary/60 transition-all duration-700 ease-out"
            style={{ width: `${Math.max(0, Math.min(100, progress))}%` }}
          />
        </div>

        {/* Milestones */}
        <div className="flex justify-between">
          {MILESTONES.map((milestone) => {
            const reached = peerCount >= milestone.count;
            return (
              <div key={milestone.label} className="flex flex-col items-center gap-1.5">
                <div className={`w-2 h-2 rounded-full transition-colors duration-500 ${reached ? "bg-primary" : "bg-muted/40"}`} />
                <span className={`text-xs transition-colors duration-500 ${reached ? "text-foreground" : "text-muted-foreground/30"}`}>
                  {milestone.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
