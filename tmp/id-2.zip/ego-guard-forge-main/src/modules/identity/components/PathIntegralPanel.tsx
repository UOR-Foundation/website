/**
 * PathIntegralPanel — Shows how well-protected your data is across all categories.
 *
 * Translates the mathematical path integral into a human-readable
 * "protection journey" showing verification status across dimensions.
 */

import { useMemo } from "react";
import { Activity, CheckCircle2, XCircle, AlertTriangle, RotateCcw, TrendingUp } from "lucide-react";
import GlossaryTooltip from "./GlossaryTooltip";
import type { SovereigntySurface } from "../types";
import type { PathIntegralResult, PathStep } from "../types/path-integral";
import { computePathIntegral, pathEfficiency, DEFAULT_PATH_INTEGRAL_CONFIG } from "../engine/path-integral-engine";

interface Props {
  readonly surface: SovereigntySurface;
}

const STATUS_ICON = {
  verified: CheckCircle2,
  reverified: RotateCcw,
  failed: XCircle,
  unverified: AlertTriangle,
} as const;

const STATUS_STYLE = {
  verified: "text-primary",
  reverified: "text-accent-foreground",
  failed: "text-destructive",
  unverified: "text-muted-foreground",
} as const;

function SegmentBar({ step, maxDensity }: { step: PathStep; maxDensity: number }) {
  const pct = maxDensity > 0 ? (step.valueDensity / maxDensity) * 100 : 0;
  const Icon = step.verified
    ? step.feedbackApplied ? STATUS_ICON.reverified : STATUS_ICON.verified
    : STATUS_ICON.failed;
  const style = step.verified
    ? step.feedbackApplied ? STATUS_STYLE.reverified : STATUS_STYLE.verified
    : STATUS_STYLE.failed;
  const statusLabel = step.verified
    ? step.feedbackApplied ? "Re-verified" : "Verified"
    : "Needs attention";

  return (
    <div className="flex items-center gap-2 group">
      <div className="flex items-center gap-1.5 w-[140px] shrink-0">
        <span className="text-[10px] font-mono text-muted-foreground capitalize">
          {step.fromNode}
        </span>
        <span className="text-[10px] text-muted-foreground">→</span>
        <span className="text-[10px] font-mono text-foreground capitalize">
          {step.toNode}
        </span>
      </div>

      <div className="flex-1 h-3 rounded-full bg-muted overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{
            width: `${Math.max(pct, 2)}%`,
            backgroundColor: step.verified
              ? step.feedbackApplied
                ? "hsl(38, 40%, 40%)"
                : "hsl(38, 60%, 55%)"
              : "hsl(0, 40%, 35%)",
          }}
        />
      </div>

      <div className="flex items-center gap-1 w-[60px] shrink-0 justify-end">
        <span className="text-[10px] font-mono text-muted-foreground">
          {(step.valueDensity * 100).toFixed(1)}%
        </span>
        <Icon className={`h-3 w-3 ${style}`} />
      </div>
    </div>
  );
}

export default function PathIntegralPanel({ surface }: Props) {
  const result: PathIntegralResult = useMemo(
    () => computePathIntegral(surface),
    [surface],
  );

  const efficiency = useMemo(() => pathEfficiency(result), [result]);
  const maxDensity = useMemo(
    () => Math.max(...result.path.map((s) => s.valueDensity), 0.01),
    [result],
  );

  return (
    <div className="rounded-lg border border-border bg-card p-6 animate-fade-in space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
          <Activity className="h-3.5 w-3.5" />
          <GlossaryTooltip term="Protection Score">Protection Score</GlossaryTooltip>
        </h3>
      </div>

      {/* Summary metrics */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-md bg-muted/50 p-3 text-center">
          <div className="text-lg font-semibold text-foreground font-mono">
            {result.integralValue.toFixed(3)}
          </div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            Overall score
          </div>
        </div>
        <div className="rounded-md bg-muted/50 p-3 text-center">
          <div className="text-lg font-semibold text-foreground font-mono">
            {(efficiency * 100).toFixed(1)}%
          </div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            Efficiency
          </div>
        </div>
        <div className="rounded-md bg-muted/50 p-3 text-center">
          <div className="text-lg font-semibold text-foreground font-mono">
            {result.verifiedCheckpoints}/6
          </div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            Verified
          </div>
        </div>
      </div>

      {/* Verification steps across dimensions */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-semibold text-muted-foreground uppercase">
            Verification by Category
          </span>
          <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
            {result.feedbackLoops > 0 && (
              <span className="flex items-center gap-1">
                <RotateCcw className="h-2.5 w-2.5" />
                {result.feedbackLoops} re-check{result.feedbackLoops !== 1 ? "s" : ""}
              </span>
            )}
            <span className="flex items-center gap-1">
              <TrendingUp className="h-2.5 w-2.5" />
              {(result.boundaryUtilization * 100).toFixed(0)}% coverage
            </span>
          </div>
        </div>

        <div className="space-y-1.5">
          {result.path.map((step) => (
            <SegmentBar
              key={step.edgeId}
              step={step}
              maxDensity={maxDensity}
            />
          ))}
        </div>
      </div>

      {/* Progress visualization */}
      <div className="rounded-md border border-border bg-muted/20 p-3 space-y-1.5">
        <span className="text-[10px] font-semibold text-muted-foreground uppercase">
          Cumulative Protection
        </span>
        <div className="flex items-end gap-1 h-10">
          {result.path.map((step) => {
            const maxCumulative = result.rawIntegral || 1;
            const height = (step.cumulativeValue / maxCumulative) * 100;
            return (
              <div
                key={step.edgeId}
                className="flex-1 rounded-t transition-all duration-500"
                style={{
                  height: `${Math.max(height, 4)}%`,
                  backgroundColor: step.verified
                    ? "hsl(38, 60%, 55%)"
                    : "hsl(38, 15%, 25%)",
                }}
                title={`After ${step.toNode}: ${(step.cumulativeValue * 100).toFixed(0)}% protected`}
              />
            );
          })}
        </div>
        <div className="flex gap-1">
          {result.path.map((step) => (
            <div key={step.edgeId} className="flex-1 text-center">
              <span className="text-[8px] text-muted-foreground capitalize">
                {step.toNode.slice(0, 4)}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
