//! Kernel registry for operation implementations.

use std::collections::HashMap;

use hologram_backend::{BackendCapabilities, BackendType};

use crate::graph::OpCategory;

/// Unique kernel identifier.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct KernelId(pub u32);

impl KernelId {
    /// Scalar fallback kernel ID.
    pub const SCALAR: Self = Self(0);
}

/// Feature requirements for a kernel.
#[derive(Debug, Clone, Copy, Default)]
pub struct KernelRequirements {
    /// Minimum SIMD width required (0 = no SIMD)
    pub min_vector_width: usize,
    /// Requires FMA support
    pub requires_fma: bool,
    /// Requires SHA-NI support
    pub requires_sha: bool,
    /// Requires AES-NI support
    pub requires_aes: bool,
}

impl KernelRequirements {
    /// Check if capabilities satisfy requirements.
    #[must_use]
    pub fn satisfied_by(&self, caps: &BackendCapabilities) -> bool {
        caps.vector_width >= self.min_vector_width
            && (!self.requires_fma || caps.has_fma)
            && (!self.requires_sha || caps.has_sha)
            && (!self.requires_aes || caps.has_aes)
    }
}

/// Kernel information and metadata.
#[derive(Debug, Clone)]
pub struct KernelInfo {
    /// Unique kernel ID.
    pub id: KernelId,
    /// Human-readable name.
    pub name: &'static str,
    /// Supported backend types.
    pub backends: &'static [BackendType],
    /// Feature requirements.
    pub requirements: KernelRequirements,
    /// Base cost multiplier (1.0 = baseline).
    pub cost_multiplier: f32,
}

impl KernelInfo {
    /// Create a new kernel info.
    #[must_use]
    pub const fn new(
        id: KernelId,
        name: &'static str,
        backends: &'static [BackendType],
        requirements: KernelRequirements,
        cost_multiplier: f32,
    ) -> Self {
        Self {
            id,
            name,
            backends,
            requirements,
            cost_multiplier,
        }
    }

    /// Check if kernel is compatible with capabilities.
    #[must_use]
    pub fn compatible(&self, caps: &BackendCapabilities) -> bool {
        // Check backend type
        let backend_ok = self.backends.contains(&caps.backend_type);
        // Check requirements
        backend_ok && self.requirements.satisfied_by(caps)
    }
}

/// Registry of available kernels per operation category.
#[derive(Debug)]
pub struct KernelRegistry {
    /// Kernels indexed by operation category.
    kernels: HashMap<OpCategory, Vec<KernelInfo>>,
}

impl Default for KernelRegistry {
    fn default() -> Self {
        Self::new()
    }
}

// Static kernel definitions
static CPU_BACKENDS: &[BackendType] = &[BackendType::Cpu];
static ALL_BACKENDS: &[BackendType] = &[BackendType::Cpu, BackendType::Wasm];

impl KernelRegistry {
    /// Create a new registry with default kernels.
    #[must_use]
    pub fn new() -> Self {
        let mut registry = Self {
            kernels: HashMap::new(),
        };
        registry.register_default_kernels();
        registry
    }

    /// Register default kernels for all operation categories.
    fn register_default_kernels(&mut self) {
        self.register_binary_kernels();
        self.register_activation_kernels();
        self.register_matmul_kernels();
        self.register_reduction_kernels();
        self.register_misc_kernels();
    }

    fn register_binary_kernels(&mut self) {
        self.register(
            OpCategory::BinaryElementwise,
            KernelInfo::new(
                KernelId(1),
                "binary_scalar",
                ALL_BACKENDS,
                KernelRequirements::default(),
                1.0,
            ),
        );
        self.register(
            OpCategory::BinaryElementwise,
            KernelInfo::new(
                KernelId(2),
                "binary_avx2",
                CPU_BACKENDS,
                KernelRequirements {
                    min_vector_width: 8,
                    ..Default::default()
                },
                0.125,
            ),
        );
        self.register(
            OpCategory::BinaryElementwise,
            KernelInfo::new(
                KernelId(3),
                "binary_avx512",
                CPU_BACKENDS,
                KernelRequirements {
                    min_vector_width: 16,
                    ..Default::default()
                },
                0.0625,
            ),
        );
    }

    fn register_activation_kernels(&mut self) {
        self.register(
            OpCategory::UnaryActivation,
            KernelInfo::new(
                KernelId(10),
                "activation_scalar",
                ALL_BACKENDS,
                KernelRequirements::default(),
                1.0,
            ),
        );
        self.register(
            OpCategory::UnaryActivation,
            KernelInfo::new(
                KernelId(11),
                "activation_lut",
                CPU_BACKENDS,
                KernelRequirements::default(),
                0.5,
            ),
        );
        self.register(
            OpCategory::UnaryActivation,
            KernelInfo::new(
                KernelId(12),
                "activation_avx2",
                CPU_BACKENDS,
                KernelRequirements {
                    min_vector_width: 8,
                    ..Default::default()
                },
                0.125,
            ),
        );
    }

    fn register_matmul_kernels(&mut self) {
        self.register(
            OpCategory::MatMul,
            KernelInfo::new(
                KernelId(20),
                "matmul_naive",
                ALL_BACKENDS,
                KernelRequirements::default(),
                1.0,
            ),
        );
        self.register(
            OpCategory::MatMul,
            KernelInfo::new(
                KernelId(21),
                "matmul_blocked",
                CPU_BACKENDS,
                KernelRequirements::default(),
                0.3,
            ),
        );
        self.register(
            OpCategory::MatMul,
            KernelInfo::new(
                KernelId(22),
                "matmul_avx2_fma",
                CPU_BACKENDS,
                KernelRequirements {
                    min_vector_width: 8,
                    requires_fma: true,
                    ..Default::default()
                },
                0.05,
            ),
        );

        // Batched matrix multiplication kernels
        self.register(
            OpCategory::BatchMatMul,
            KernelInfo::new(
                KernelId(23),
                "batch_matmul_naive",
                ALL_BACKENDS,
                KernelRequirements::default(),
                1.0,
            ),
        );
        self.register(
            OpCategory::BatchMatMul,
            KernelInfo::new(
                KernelId(24),
                "batch_matmul_blocked",
                CPU_BACKENDS,
                KernelRequirements::default(),
                0.3,
            ),
        );
        self.register(
            OpCategory::BatchMatMul,
            KernelInfo::new(
                KernelId(25),
                "batch_matmul_avx2_fma",
                CPU_BACKENDS,
                KernelRequirements {
                    min_vector_width: 8,
                    requires_fma: true,
                    ..Default::default()
                },
                0.05,
            ),
        );
    }

    fn register_reduction_kernels(&mut self) {
        self.register(
            OpCategory::Reduction,
            KernelInfo::new(
                KernelId(30),
                "reduce_scalar",
                ALL_BACKENDS,
                KernelRequirements::default(),
                1.0,
            ),
        );
        self.register(
            OpCategory::Reduction,
            KernelInfo::new(
                KernelId(31),
                "reduce_simd",
                CPU_BACKENDS,
                KernelRequirements {
                    min_vector_width: 8,
                    ..Default::default()
                },
                0.125,
            ),
        );
    }

    fn register_misc_kernels(&mut self) {
        // Softmax
        self.register(
            OpCategory::Softmax,
            KernelInfo::new(
                KernelId(40),
                "softmax_scalar",
                ALL_BACKENDS,
                KernelRequirements::default(),
                1.0,
            ),
        );
        self.register(
            OpCategory::Softmax,
            KernelInfo::new(
                KernelId(41),
                "softmax_stable",
                CPU_BACKENDS,
                KernelRequirements::default(),
                1.1,
            ),
        );
        // Categorical
        self.register(
            OpCategory::Categorical,
            KernelInfo::new(
                KernelId(50),
                "categorical_lut",
                ALL_BACKENDS,
                KernelRequirements::default(),
                1.0,
            ),
        );
        // Memory
        self.register(
            OpCategory::Memory,
            KernelInfo::new(
                KernelId(60),
                "memcpy",
                ALL_BACKENDS,
                KernelRequirements::default(),
                1.0,
            ),
        );
        // Control flow
        self.register(
            OpCategory::ControlFlow,
            KernelInfo::new(
                KernelId(70),
                "call_layer",
                ALL_BACKENDS,
                KernelRequirements::default(),
                1.0,
            ),
        );
        // I/O
        self.register(
            OpCategory::Io,
            KernelInfo::new(
                KernelId(80),
                "io_passthrough",
                ALL_BACKENDS,
                KernelRequirements::default(),
                0.0,
            ),
        );
    }

    /// Register a kernel for an operation category.
    pub fn register(&mut self, category: OpCategory, kernel: KernelInfo) {
        self.kernels.entry(category).or_default().push(kernel);
    }

    /// Get all kernels for an operation category.
    #[must_use]
    pub fn get_kernels(&self, category: OpCategory) -> &[KernelInfo] {
        self.kernels.get(&category).map_or(&[], Vec::as_slice)
    }

    /// Get compatible kernels for an operation given capabilities.
    #[must_use]
    pub fn compatible_kernels(
        &self,
        category: OpCategory,
        caps: &BackendCapabilities,
    ) -> Vec<&KernelInfo> {
        self.get_kernels(category)
            .iter()
            .filter(|k| k.compatible(caps))
            .collect()
    }

    /// Select the best kernel for an operation given capabilities.
    ///
    /// Returns the kernel with the lowest cost multiplier that is compatible.
    #[must_use]
    pub fn select_best(
        &self,
        category: OpCategory,
        caps: &BackendCapabilities,
    ) -> Option<&KernelInfo> {
        self.compatible_kernels(category, caps)
            .into_iter()
            .min_by(|a, b| {
                a.cost_multiplier
                    .partial_cmp(&b.cost_multiplier)
                    .unwrap_or(std::cmp::Ordering::Equal)
            })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::OpKind;

    fn test_caps() -> BackendCapabilities {
        BackendCapabilities {
            backend_type: BackendType::Cpu,
            vector_width: 8,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: true,
            has_sha: false,
            has_aes: false,
        }
    }

    #[test]
    fn test_kernel_requirements_satisfied() {
        let caps = test_caps();

        let req_none = KernelRequirements::default();
        assert!(req_none.satisfied_by(&caps));

        let req_simd = KernelRequirements {
            min_vector_width: 8,
            ..Default::default()
        };
        assert!(req_simd.satisfied_by(&caps));

        let req_avx512 = KernelRequirements {
            min_vector_width: 16,
            ..Default::default()
        };
        assert!(!req_avx512.satisfied_by(&caps));

        let req_fma = KernelRequirements {
            requires_fma: true,
            ..Default::default()
        };
        assert!(req_fma.satisfied_by(&caps));

        let req_sha = KernelRequirements {
            requires_sha: true,
            ..Default::default()
        };
        assert!(!req_sha.satisfied_by(&caps));
    }

    #[test]
    fn test_kernel_info_compatible() {
        let caps = test_caps();

        let kernel = KernelInfo::new(
            KernelId(1),
            "test",
            CPU_BACKENDS,
            KernelRequirements::default(),
            1.0,
        );
        assert!(kernel.compatible(&caps));

        let kernel_avx512 = KernelInfo::new(
            KernelId(2),
            "test_avx512",
            CPU_BACKENDS,
            KernelRequirements {
                min_vector_width: 16,
                ..Default::default()
            },
            0.5,
        );
        assert!(!kernel_avx512.compatible(&caps));
    }

    #[test]
    fn test_op_category() {
        assert_eq!(OpKind::Add.category(), OpCategory::BinaryElementwise);
        assert_eq!(OpKind::Sigmoid.category(), OpCategory::UnaryActivation);
        assert_eq!(
            OpKind::MatMul { m: 1, k: 1, n: 1 }.category(),
            OpCategory::MatMul
        );
        assert_eq!(OpKind::Sum.category(), OpCategory::Reduction);
        assert_eq!(OpKind::Softmax { axis: -1 }.category(), OpCategory::Softmax);
        assert_eq!(OpKind::Lift.category(), OpCategory::Categorical);
        assert_eq!(OpKind::Load.category(), OpCategory::Memory);
        assert_eq!(
            OpKind::CallLayer { layer_id: 0 }.category(),
            OpCategory::ControlFlow
        );
        assert_eq!(OpKind::Input.category(), OpCategory::Io);
    }

    #[test]
    fn test_registry_default_kernels() {
        let registry = KernelRegistry::new();

        // Should have kernels for all categories
        assert!(!registry
            .get_kernels(OpCategory::BinaryElementwise)
            .is_empty());
        assert!(!registry.get_kernels(OpCategory::UnaryActivation).is_empty());
        assert!(!registry.get_kernels(OpCategory::MatMul).is_empty());
        assert!(!registry.get_kernels(OpCategory::Reduction).is_empty());
        assert!(!registry.get_kernels(OpCategory::Softmax).is_empty());
        assert!(!registry.get_kernels(OpCategory::Categorical).is_empty());
        assert!(!registry.get_kernels(OpCategory::Memory).is_empty());
        assert!(!registry.get_kernels(OpCategory::ControlFlow).is_empty());
        assert!(!registry.get_kernels(OpCategory::Io).is_empty());
    }

    #[test]
    fn test_registry_compatible_kernels() {
        let registry = KernelRegistry::new();
        let caps = test_caps();

        let kernels = registry.compatible_kernels(OpCategory::BinaryElementwise, &caps);
        assert!(!kernels.is_empty());

        // Should include scalar and AVX2, but not AVX512
        let names: Vec<_> = kernels.iter().map(|k| k.name).collect();
        assert!(names.contains(&"binary_scalar"));
        assert!(names.contains(&"binary_avx2"));
        assert!(!names.contains(&"binary_avx512"));
    }

    #[test]
    fn test_registry_select_best() {
        let registry = KernelRegistry::new();
        let caps = test_caps();

        // For binary elementwise, AVX2 should be best (lowest cost multiplier)
        let best = registry.select_best(OpCategory::BinaryElementwise, &caps);
        assert!(best.is_some());
        assert_eq!(best.unwrap().name, "binary_avx2");

        // For MatMul with FMA, should select avx2_fma
        let best_matmul = registry.select_best(OpCategory::MatMul, &caps);
        assert!(best_matmul.is_some());
        assert_eq!(best_matmul.unwrap().name, "matmul_avx2_fma");
    }

    #[test]
    fn test_registry_select_best_no_fma() {
        let registry = KernelRegistry::new();
        let mut caps = test_caps();
        caps.has_fma = false;

        // Without FMA, should select blocked kernel instead
        let best = registry.select_best(OpCategory::MatMul, &caps);
        assert!(best.is_some());
        assert_eq!(best.unwrap().name, "matmul_blocked");
    }

    #[test]
    fn test_registry_select_best_wasm() {
        let registry = KernelRegistry::new();
        let caps = BackendCapabilities {
            backend_type: BackendType::Wasm,
            vector_width: 4,
            l1_cache_size: 32 * 1024,
            l2_cache_size: 256 * 1024,
            has_fma: false,
            has_sha: false,
            has_aes: false,
        };

        // WASM should get scalar kernels
        let best = registry.select_best(OpCategory::BinaryElementwise, &caps);
        assert!(best.is_some());
        assert_eq!(best.unwrap().name, "binary_scalar");
    }

    #[test]
    fn test_registry_custom_kernel() {
        let mut registry = KernelRegistry::new();

        registry.register(
            OpCategory::BinaryElementwise,
            KernelInfo::new(
                KernelId(100),
                "custom_binary",
                CPU_BACKENDS,
                KernelRequirements::default(),
                0.01, // Very fast
            ),
        );

        let caps = test_caps();
        let best = registry.select_best(OpCategory::BinaryElementwise, &caps);
        assert_eq!(best.unwrap().name, "custom_binary");
    }
}
