/**
 * IdentityProfileCard — Displays identity information.
 * Uses Hologram OS palette via design system tokens.
 */
import { useState, useCallback } from "react";

import { User, Shield, Clock, Lock, Fingerprint, Copy, Check } from "lucide-react";
import type { IdentityProfile, TrustScore } from "../types";
import { algorithmInfo } from "../engine/pq-crypto";
import GlossaryTooltip from "./GlossaryTooltip";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface Props {
  readonly profile: IdentityProfile;
  readonly trustScore: TrustScore | null;
}

function PQBadge() {
  const info = algorithmInfo();
  return (
    <TooltipProvider delayDuration={200}>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="inline-flex items-center gap-1.5 px-2 py-1 rounded-full bg-primary/10 border border-primary/20 cursor-help">
            <Lock className="h-3 w-3 text-primary" />
            <span className="text-[10px] font-mono font-semibold text-primary">
              {info.fips.replace("FIPS 204 (", "").replace(")", "")}
            </span>
            <span className="text-[9px] text-muted-foreground">
              Level {info.nistLevel}
            </span>
          </div>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="text-xs space-y-1.5 max-w-[260px]">
          <p className="font-semibold"><GlossaryTooltip term="Quantum-safe">Quantum-resistant encryption</GlossaryTooltip></p>
          <p className="text-muted-foreground">{info.fips}</p>
          <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[10px] pt-1 border-t border-border">
            <span className="text-muted-foreground">Security level</span>
            <span className="font-mono">NIST Level {info.nistLevel}</span>
            <span className="text-muted-foreground">Quantum-safe</span>
            <span className="font-mono">{info.quantumBits}-bit</span>
            <span className="text-muted-foreground">Classical</span>
            <span className="font-mono">{info.classicalBits}-bit</span>
            <span className="text-muted-foreground">Based on</span>
            <span className="font-mono text-[9px]">Lattice cryptography</span>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export default function IdentityProfileCard({ profile, trustScore }: Props) {
  return (
    <div className="rounded-lg border border-border bg-card p-6 animate-fade-in">
      <div className="flex items-start gap-4">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/20">
          <User className="h-7 w-7 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-xl font-display text-foreground">{profile.displayName}</h2>
            <PQBadge />
          </div>
          <p className="text-sm text-muted-foreground font-mono">{profile.handle}</p>
          {profile.bio && (
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{profile.bio}</p>
          )}
        </div>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <div className="rounded-md bg-muted p-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
            <Shield className="h-3.5 w-3.5" />
            Trust Level
          </div>
          <span className="text-sm font-semibold text-primary capitalize">
            {trustScore?.level ?? "unknown"}
          </span>
        </div>
        <div className="rounded-md bg-muted p-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
            <Clock className="h-3.5 w-3.5" />
            Member Since
          </div>
          <span className="text-sm font-semibold text-foreground">
            {new Date(profile.createdAt).toLocaleDateString()}
          </span>
        </div>
      </div>

      <UorIdDisplay id={profile.id} />
    </div>
  );
}

function UorIdDisplay({ id }: { id: string }) {
  const [copied, setCopied] = useState(false);
  const isUor = id.startsWith("uor:");
  const displayId = isUor ? id : `ID: ${id}`;
  const truncated = isUor
    ? `uor:${id.slice(4, 12)}…${id.slice(-8)}`
    : id.length > 24 ? `${id.slice(0, 12)}…${id.slice(-8)}` : id;

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [id]);

  return (
    <div className="mt-4 pt-4 border-t border-border">
      <div className="flex items-center gap-2">
        <Fingerprint className="h-3.5 w-3.5 text-primary shrink-0" />
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
          {isUor ? "UOR Identity" : "Identity ID"}
        </span>
      </div>
      <TooltipProvider delayDuration={200}>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={handleCopy}
              className="mt-1.5 group flex items-center gap-2 text-xs font-mono text-muted-foreground hover:text-foreground transition-colors w-full text-left"
            >
              <span className="truncate">{truncated}</span>
              {copied ? (
                <Check className="h-3 w-3 text-primary shrink-0" />
              ) : (
                <Copy className="h-3 w-3 opacity-0 group-hover:opacity-60 shrink-0 transition-opacity" />
              )}
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="text-[10px] font-mono max-w-[320px] break-all">
            {displayId}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
}