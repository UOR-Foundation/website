//! Core traits for embeddable sections.
//!
//! These traits define the contract for data that can be embedded in and
//! extracted from `.holb` bundles. Implementing these traits allows custom
//! data types to be serialized into bundle sections.

use crate::Result;

/// Trait for data that can be embedded in a bundle as a section.
///
/// Implement this trait to make a type embeddable in `.holb` files.
/// Each section has a unique identifier, serialization format, and version.
///
/// # Example
///
/// ```rust
/// use hologram_holo::traits::EmbeddableSection;
///
/// struct Vocabulary {
///     tokens: Vec<String>,
/// }
///
/// impl EmbeddableSection for Vocabulary {
///     fn section_id(&self) -> &'static str {
///         "vocabulary"
///     }
///
///     fn to_bytes(&self) -> Vec<u8> {
///         // Serialize tokens (simplified)
///         self.tokens.join("\n").into_bytes()
///     }
///
///     fn content_type(&self) -> &'static str {
///         "text/plain"
///     }
/// }
/// ```
pub trait EmbeddableSection: Send + Sync {
    /// Unique identifier for this section type.
    ///
    /// This ID is used to locate and retrieve sections from bundles.
    /// Common IDs include:
    /// - `"vocabulary"` - Token vocabulary
    /// - `"tokenizer_config"` - Tokenizer parameters
    /// - `"model_config"` - Model architecture config
    fn section_id(&self) -> &'static str;

    /// Serialize section data to bytes.
    ///
    /// The serialization format is defined by the section type.
    /// Common formats include JSON, plain text, and binary formats.
    fn to_bytes(&self) -> Vec<u8>;

    /// MIME content type for this section.
    ///
    /// Used for tooling and debugging. Common types:
    /// - `"application/json"` - JSON data
    /// - `"text/plain"` - Plain text
    /// - `"application/octet-stream"` - Binary data (default)
    fn content_type(&self) -> &'static str {
        "application/octet-stream"
    }

    /// Version number for this section format.
    ///
    /// Increment when the serialization format changes in a
    /// backward-incompatible way. Default is 1.
    fn version(&self) -> u32 {
        1
    }
}

/// Trait for deserializing sections from bundle data.
///
/// Implement this trait alongside `EmbeddableSection` to enable
/// round-trip serialization and deserialization.
///
/// # Example
///
/// ```rust
/// use hologram_holo::traits::FromEmbeddedSection;
/// use hologram_holo::Result;
///
/// struct Vocabulary {
///     tokens: Vec<String>,
/// }
///
/// impl FromEmbeddedSection for Vocabulary {
///     const SECTION_ID: &'static str = "vocabulary";
///
///     fn from_bytes(bytes: &[u8]) -> Result<Self> {
///         let text = std::str::from_utf8(bytes)
///             .map_err(|e| hologram_holo::HoloError::Other(e.to_string()))?;
///         Ok(Self {
///             tokens: text.lines().map(String::from).collect(),
///         })
///     }
/// }
/// ```
pub trait FromEmbeddedSection: Sized {
    /// Section ID this type deserializes from.
    ///
    /// Must match the `section_id()` of the corresponding `EmbeddableSection`.
    const SECTION_ID: &'static str;

    /// Deserialize section data from bytes.
    ///
    /// # Errors
    /// Returns error if the bytes cannot be parsed into the target type.
    fn from_bytes(bytes: &[u8]) -> Result<Self>;

    /// Expected version for this section format.
    ///
    /// Used to validate version compatibility during deserialization.
    /// Default is 1.
    #[must_use]
    fn expected_version() -> u32 {
        1
    }
}

/// Helper trait for sections that can be cloned.
///
/// This enables storing sections in containers that require `Clone`
/// while maintaining the `EmbeddableSection` interface.
pub trait CloneableSection: EmbeddableSection {
    /// Clone this section into a boxed trait object.
    fn clone_boxed(&self) -> Box<dyn EmbeddableSection>;
}

impl<T: EmbeddableSection + Clone + 'static> CloneableSection for T {
    fn clone_boxed(&self) -> Box<dyn EmbeddableSection> {
        Box::new(self.clone())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Clone)]
    struct TestSection {
        data: Vec<u8>,
    }

    impl EmbeddableSection for TestSection {
        fn section_id(&self) -> &'static str {
            "test"
        }

        fn to_bytes(&self) -> Vec<u8> {
            self.data.clone()
        }

        fn content_type(&self) -> &'static str {
            "application/x-test"
        }

        fn version(&self) -> u32 {
            2
        }
    }

    impl FromEmbeddedSection for TestSection {
        const SECTION_ID: &'static str = "test";

        fn from_bytes(bytes: &[u8]) -> Result<Self> {
            Ok(Self {
                data: bytes.to_vec(),
            })
        }

        fn expected_version() -> u32 {
            2
        }
    }

    #[test]
    fn test_embeddable_section() {
        let section = TestSection {
            data: vec![1, 2, 3, 4],
        };

        assert_eq!(section.section_id(), "test");
        assert_eq!(section.to_bytes(), vec![1, 2, 3, 4]);
        assert_eq!(section.content_type(), "application/x-test");
        assert_eq!(section.version(), 2);
    }

    #[test]
    fn test_from_embedded_section() {
        let bytes = vec![5, 6, 7, 8];
        let section = TestSection::from_bytes(&bytes).unwrap();

        assert_eq!(section.data, bytes);
        assert_eq!(TestSection::SECTION_ID, "test");
        assert_eq!(TestSection::expected_version(), 2);
    }

    #[test]
    fn test_cloneable_section() {
        let section = TestSection {
            data: vec![1, 2, 3],
        };

        let boxed: Box<dyn EmbeddableSection> = section.clone_boxed();
        assert_eq!(boxed.section_id(), "test");
        assert_eq!(boxed.to_bytes(), vec![1, 2, 3]);
    }

    #[test]
    fn test_default_content_type() {
        struct MinimalSection;

        impl EmbeddableSection for MinimalSection {
            fn section_id(&self) -> &'static str {
                "minimal"
            }

            fn to_bytes(&self) -> Vec<u8> {
                vec![]
            }
        }

        let section = MinimalSection;
        assert_eq!(section.content_type(), "application/octet-stream");
        assert_eq!(section.version(), 1);
    }

    #[test]
    fn test_default_expected_version() {
        struct MinimalParsed;

        impl FromEmbeddedSection for MinimalParsed {
            const SECTION_ID: &'static str = "minimal";

            fn from_bytes(_bytes: &[u8]) -> Result<Self> {
                Ok(MinimalParsed)
            }
        }

        assert_eq!(MinimalParsed::expected_version(), 1);
    }
}
