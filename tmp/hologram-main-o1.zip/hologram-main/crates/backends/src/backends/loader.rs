//! Dynamic kernel loader for external native libraries.
//!
//! This module implements loading of external `.so`/`.dylib`/`.dll` files that
//! provide optimized kernel implementations (e.g., cuBLAS, oneDNN, ONNX Runtime).

use super::kernel_abi::{KernelVTable, KERNEL_ABI_VERSION, KERNEL_MAGIC};
use crate::backends::kernel::KernelOverride;
use crate::types::{BackendError, Result};
use libloading::{Library, Symbol};
use std::path::Path;
use std::sync::Arc;

/// Dynamic kernel provider that loads external libraries.
pub struct DynamicKernelProvider {
    _lib: Arc<Library>,
    vtable: &'static KernelVTable,
}

impl DynamicKernelProvider {
    /// Load a kernel library from the given path.
    ///
    /// The library must export a symbol `hologram_kernel_vtable` returning a pointer
    /// to a `KernelVTable` structure.
    ///
    /// # Safety
    /// This function loads and executes code from an external library. The library:
    /// - Must have been compiled with a compatible ABI
    /// - Must export a valid `KernelVTable` with matching magic/version
    /// - Should not perform unsafe operations in its initializers
    pub unsafe fn load(path: &str) -> Result<Self> {
        let lib = Library::new(path)
            .map_err(|e| BackendError::ExecutionError(format!("Failed to load library: {e}")))?;

        // Load the VTable symbol
        let vtable_fn: Symbol<unsafe extern "C" fn() -> *const KernelVTable> = lib
            .get(b"hologram_kernel_vtable")
            .map_err(|e| BackendError::ExecutionError(format!("Missing vtable symbol: {e}")))?;

        let vtable_ptr = vtable_fn();
        if vtable_ptr.is_null() {
            return Err(BackendError::ExecutionError(
                "VTable pointer is null".into(),
            ));
        }

        let vtable = &*vtable_ptr;

        // Verify magic and version
        if vtable.magic != KERNEL_MAGIC {
            return Err(BackendError::ExecutionError(format!(
                "Invalid kernel magic: expected 0x{:016x}, got 0x{:016x}",
                KERNEL_MAGIC, vtable.magic
            )));
        }

        if vtable.version != KERNEL_ABI_VERSION {
            return Err(BackendError::ExecutionError(format!(
                "Incompatible kernel ABI version: expected {}, got {}",
                KERNEL_ABI_VERSION, vtable.version
            )));
        }

        Ok(Self {
            _lib: Arc::new(lib),
            vtable,
        })
    }
}

impl KernelOverride for DynamicKernelProvider {
    fn matmul(
        &self,
        matrix_a: &[f32],
        matrix_b: &[f32],
        matrix_c: &mut [f32],
        rows_m: usize,
        inner_k: usize,
        cols_n: usize,
    ) -> Option<Result<()>> {
        self.vtable.matmul.map(|f| unsafe {
            let ret = f(
                matrix_a.as_ptr(),
                matrix_b.as_ptr(),
                matrix_c.as_mut_ptr(),
                rows_m,
                inner_k,
                cols_n,
            );
            if ret == 0 {
                Ok(())
            } else {
                Err(BackendError::ExecutionError(format!(
                    "External matmul failed with code {ret}"
                )))
            }
        })
    }

    fn batch_matmul(
        &self,
        matrix_a: &[f32],
        matrix_b: &[f32],
        matrix_c: &mut [f32],
        batch: usize,
        rows_m: usize,
        inner_k: usize,
        cols_n: usize,
    ) -> Option<Result<()>> {
        self.vtable.batch_matmul.map(|f| unsafe {
            let ret = f(
                matrix_a.as_ptr(),
                matrix_b.as_ptr(),
                matrix_c.as_mut_ptr(),
                batch,
                rows_m,
                inner_k,
                cols_n,
            );
            if ret == 0 {
                Ok(())
            } else {
                Err(BackendError::ExecutionError(format!(
                    "External batch_matmul failed with code {ret}"
                )))
            }
        })
    }
}

/// Registry for managing multiple loaded kernels.
///
/// Supports auto-discovery from directories and priority-based fallback.
pub struct KernelRegistry {
    providers: Vec<DynamicKernelProvider>,
}

impl KernelRegistry {
    /// Create a new empty kernel registry.
    #[must_use]
    pub fn new() -> Self {
        Self {
            providers: Vec::new(),
        }
    }

    /// Load all kernels from a directory.
    ///
    /// Scans for `.so`, `.dylib`, `.dll` files and attempts to load each.
    /// Successfully loaded kernels are added to the registry.
    /// Failed loads are logged but don't stop the process.
    ///
    /// Returns the number of kernels successfully loaded.
    ///
    /// # Safety
    /// Same safety requirements as `DynamicKernelProvider::load`.
    pub unsafe fn load_from_directory(&mut self, path: impl AsRef<Path>) -> Result<usize> {
        let mut count = 0;
        let dir = std::fs::read_dir(path)
            .map_err(|e| BackendError::ExecutionError(format!("Failed to read directory: {e}")))?;

        for entry in dir {
            let Ok(entry) = entry else { continue };

            let path = entry.path();

            // Check if it's a dynamic library
            if let Some(ext) = path.extension() {
                let ext_str = ext.to_str().unwrap_or("");
                if matches!(ext_str, "so" | "dylib" | "dll") {
                    match DynamicKernelProvider::load(path.to_str().unwrap()) {
                        Ok(provider) => {
                            self.providers.push(provider);
                            count += 1;
                        }
                        Err(e) => {
                            // Log warning but continue
                            #[cfg(feature = "instrumentation")]
                            tracing::warn!("Failed to load kernel {}: {e}", path.display());
                            #[cfg(not(feature = "instrumentation"))]
                            eprintln!("Warning: failed to load kernel {}: {e}", path.display());
                        }
                    }
                }
            }
        }

        Ok(count)
    }

    /// Add a single kernel provider to the registry.
    pub fn add_provider(&mut self, provider: DynamicKernelProvider) {
        self.providers.push(provider);
    }

    /// Get the number of loaded kernels.
    #[must_use]
    pub fn len(&self) -> usize {
        self.providers.len()
    }

    /// Check if the registry is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.providers.is_empty()
    }
}

impl Default for KernelRegistry {
    fn default() -> Self {
        Self::new()
    }
}

impl KernelOverride for KernelRegistry {
    fn matmul(
        &self,
        matrix_a: &[f32],
        matrix_b: &[f32],
        matrix_c: &mut [f32],
        rows_m: usize,
        inner_k: usize,
        cols_n: usize,
    ) -> Option<Result<()>> {
        // Try each provider in order until one succeeds
        for provider in &self.providers {
            if let Some(result) =
                provider.matmul(matrix_a, matrix_b, matrix_c, rows_m, inner_k, cols_n)
            {
                return Some(result);
            }
        }
        None
    }

    fn batch_matmul(
        &self,
        matrix_a: &[f32],
        matrix_b: &[f32],
        matrix_c: &mut [f32],
        batch: usize,
        rows_m: usize,
        inner_k: usize,
        cols_n: usize,
    ) -> Option<Result<()>> {
        // Try each provider in order until one succeeds
        for provider in &self.providers {
            if let Some(result) =
                provider.batch_matmul(matrix_a, matrix_b, matrix_c, batch, rows_m, inner_k, cols_n)
            {
                return Some(result);
            }
        }
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_invalid_path() {
        let result = unsafe { DynamicKernelProvider::load("/nonexistent/path.so") };
        assert!(result.is_err());
    }
}
