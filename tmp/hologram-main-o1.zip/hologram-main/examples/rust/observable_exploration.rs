//! Observable Exploration Example
//!
//! Demonstrates the UOR monodromy observables:
//! - WindingNumber: counts complete ring cycles
//! - TotalVariation: measures path "turbulence"
//! - CascadeSpectrum: histogram of carry propagation
//! - MonodromySignature: the complete path fingerprint
//!
//! Run with: cargo run --example observable_exploration

use hologram::{all_q1_datums, Datum16};

fn main() {
    println!("═══════════════════════════════════════════════════════════════");
    println!("              UOR Observable Exploration");
    println!("═══════════════════════════════════════════════════════════════\n");

    // =========================================================================
    // Part 1: Point Observables (Datum16)
    // =========================================================================
    println!("┌─────────────────────────────────────────────────────────────┐");
    println!("│ Part 1: Point Observables (per-datum)                       │");
    println!("└─────────────────────────────────────────────────────────────┘\n");

    let examples = [0u16, 1, 255, 256, 0x5555, 0xAAAA, 0xFFFF];

    println!("  Value   │ Stratum │ Curvature │ Glyph  │ Spectrum");
    println!("──────────┼─────────┼───────────┼────────┼──────────────────");

    for &val in &examples {
        let d = Datum16::from_value(val);
        println!(
            "  0x{:04X}  │    {:2}   │     {:2}    │   {}   │ [{}]",
            val,
            d.stratum(),
            d.curvature(),
            d.glyph(),
            d.spectrum_string()
        );
    }

    println!("\n  Legend:");
    println!("  • Stratum = popcount (number of 1-bits)");
    println!("  • Curvature = popcount(x XOR (x+1)) = bits that flip on increment");
    println!("  • Glyph = Braille encoding (high byte, low byte)");
    println!("  • Spectrum = positions of 1-bits\n");

    // =========================================================================
    // Part 2: Path Observables
    // =========================================================================
    println!("┌─────────────────────────────────────────────────────────────┐");
    println!("│ Part 2: Path Observables (over sequences)                   │");
    println!("└─────────────────────────────────────────────────────────────┘\n");

    // Simple incrementing path
    let path_linear: Vec<u64> = (0..16).collect();
    analyze_path("Linear (0→15)", &path_linear, 8);

    // Wrap-around path (goes past 255 in Q0)
    let path_wrap: Vec<u64> = (250..260).map(|x| x % 256).collect();
    analyze_path("Wrap-around (250→259 mod 256)", &path_wrap, 8);

    // Alternating path (high turbulence)
    let path_alt: Vec<u64> = (0..8).flat_map(|i| [i, 255 - i]).collect();
    analyze_path("Alternating (0,255,1,254,...)", &path_alt, 8);

    // Powers of 2 (low turbulence, stratum always 1)
    let path_pow2: Vec<u64> = (0..8).map(|i| 1u64 << i).collect();
    analyze_path("Powers of 2 (1,2,4,8,...)", &path_pow2, 8);

    // =========================================================================
    // Part 3: Cascade Spectrum Analysis
    // =========================================================================
    println!("┌─────────────────────────────────────────────────────────────┐");
    println!("│ Part 3: Cascade Spectrum Deep Dive                          │");
    println!("└─────────────────────────────────────────────────────────────┘\n");

    println!("  Cascade length = how far carries propagate when adding 1\n");
    println!("  Value  │ Binary       │ +1 Result    │ Cascade │ Explanation");
    println!("─────────┼──────────────┼──────────────┼─────────┼─────────────────────");

    let cascade_examples = [0b0000u16, 0b0001, 0b0011, 0b0111, 0b1111, 0b1010];
    for val in cascade_examples {
        let next = val.wrapping_add(1);
        let cascade = cascade_length(val as u64);
        let explanation: &str = match cascade {
            0 => "No carry",
            1 => "1 carry",
            2 => "2 carries",
            3 => "3 carries",
            4 => "4 carries",
            _ => "many carries",
        };
        println!(
            "  {:5}  │ {:012b} │ {:012b} │    {}    │ {}",
            val, val, next, cascade, explanation
        );
    }

    println!("\n  Theoretical: P(cascade=k) = (1/2)^k for random sequences");

    // =========================================================================
    // Part 4: Monodromy Signature Comparison
    // =========================================================================
    println!("\n┌─────────────────────────────────────────────────────────────┐");
    println!("│ Part 4: Monodromy Signature Fingerprinting                  │");
    println!("└─────────────────────────────────────────────────────────────┘\n");

    // Two different paths that might have similar signatures
    let path_a: Vec<u64> = (0..32).collect();
    let path_b: Vec<u64> = (100..132).collect();
    let path_c: Vec<u64> = (0..32).map(|x| x * 2).collect();

    println!("  Comparing three paths at Q0 (8-bit):\n");
    println!("  Path A: 0→31 (consecutive)");
    println!("  Path B: 100→131 (consecutive, shifted)");
    println!("  Path C: 0,2,4,...,62 (even numbers)\n");

    let sig_a = compute_signature(&path_a, 8);
    let sig_b = compute_signature(&path_b, 8);
    let sig_c = compute_signature(&path_c, 8);

    println!("           │ Winding │ TotalVar │ Cascade[0:4]");
    println!("  ─────────┼─────────┼──────────┼──────────────────");
    println!(
        "  Path A   │   {:3}   │   {:4}   │ {:?}",
        sig_a.0,
        sig_a.1,
        &sig_a.2[..4.min(sig_a.2.len())]
    );
    println!(
        "  Path B   │   {:3}   │   {:4}   │ {:?}",
        sig_b.0,
        sig_b.1,
        &sig_b.2[..4.min(sig_b.2.len())]
    );
    println!(
        "  Path C   │   {:3}   │   {:4}   │ {:?}",
        sig_c.0,
        sig_c.1,
        &sig_c.2[..4.min(sig_c.2.len())]
    );

    println!("\n  Note: Paths A and B have identical signatures!");
    println!("  They are 'monodromically equivalent' - same shape, different start.\n");

    // =========================================================================
    // Part 5: Q1 Datum Statistics
    // =========================================================================
    println!("┌─────────────────────────────────────────────────────────────┐");
    println!("│ Part 5: Q1 Datum Population Statistics                      │");
    println!("└─────────────────────────────────────────────────────────────┘\n");

    let mut stratum_counts = [0u32; 17]; // 0-16 possible strata
    let mut curvature_sum = 0u64;
    let mut curvature_counts = [0u32; 17];

    for d in all_q1_datums() {
        stratum_counts[d.stratum() as usize] += 1;
        curvature_sum += d.curvature() as u64;
        curvature_counts[d.curvature() as usize] += 1;
    }

    println!("  Stratum Distribution (binomial coefficients C(16,k)):\n");
    println!("  Stratum │ Count  │ Expected │ Visual");
    println!("  ────────┼────────┼──────────┼────────────────────────────────");

    for (k, &count) in stratum_counts.iter().enumerate() {
        let expected = binomial(16, k as u32);
        let bar_len = (count as f64 / 12870.0 * 30.0) as usize;
        let bar: String = "█".repeat(bar_len);
        println!(
            "     {:2}   │ {:5}  │  {:5}   │ {}",
            k, count, expected, bar
        );
    }

    let mean_curvature = curvature_sum as f64 / 65536.0;
    println!(
        "\n  Mean curvature: {:.6} (theoretical: 2.0)",
        mean_curvature
    );

    println!("\n  Curvature Distribution:\n");
    println!("  Curv │ Count  │ P(k)=(1/2)^k │ Visual");
    println!("  ─────┼────────┼──────────────┼────────────────────────────────");

    for (k, &count) in curvature_counts.iter().enumerate().skip(1).take(8) {
        if count > 0 {
            let theoretical = 65536.0 / (1 << k) as f64;
            let bar_len = (count as f64 / 32768.0 * 30.0) as usize;
            let bar: String = "█".repeat(bar_len);
            println!(
                "    {:1}  │ {:5}  │    {:5.0}     │ {}",
                k, count, theoretical, bar
            );
        }
    }

    println!("\n═══════════════════════════════════════════════════════════════");
    println!("  Observable exploration complete!");
    println!("═══════════════════════════════════════════════════════════════");
}

/// Analyze a path and print its observables.
fn analyze_path(name: &str, path: &[u64], quantum: u32) {
    let winding = winding_number(path, quantum);
    let variation = total_variation(path, quantum);
    let spectrum = cascade_spectrum(path);

    println!("  {} (Q{}):", name, quantum);
    println!("    Path: {:?}", &path[..path.len().min(8)]);
    if path.len() > 8 {
        println!("          ... ({} total elements)", path.len());
    }
    println!("    Winding Number: {}", winding);
    println!("    Total Variation: {}", variation);
    println!(
        "    Cascade Spectrum: {:?}",
        &spectrum[..4.min(spectrum.len())]
    );
    println!();
}

/// Compute winding number: sum of signed steps divided by ring size.
fn winding_number(path: &[u64], quantum: u32) -> i64 {
    if path.len() < 2 {
        return 0;
    }

    let ring_size = 1i64 << quantum;
    let half = ring_size / 2;
    let mut total: i64 = 0;

    for window in path.windows(2) {
        let a = window[0] as i64;
        let b = window[1] as i64;
        let mut delta = b - a;

        // Signed interpretation: wrap to [-half, half)
        if delta >= half {
            delta -= ring_size;
        } else if delta < -half {
            delta += ring_size;
        }

        total += delta;
    }

    total / ring_size
}

/// Compute total variation: sum of absolute stratum changes.
fn total_variation(path: &[u64], quantum: u32) -> u64 {
    if path.len() < 2 {
        return 0;
    }

    let mask = if quantum >= 64 {
        u64::MAX
    } else {
        (1u64 << quantum) - 1
    };

    path.windows(2)
        .map(|w| {
            let s1 = (w[0] & mask).count_ones() as i32;
            let s2 = (w[1] & mask).count_ones() as i32;
            (s2 - s1).unsigned_abs() as u64
        })
        .sum()
}

/// Compute cascade spectrum: histogram of carry-cascade lengths.
fn cascade_spectrum(path: &[u64]) -> Vec<u32> {
    let mut spectrum = vec![0u32; 16];

    for window in path.windows(2) {
        if window[1] == window[0].wrapping_add(1) {
            let len = cascade_length(window[0]);
            if (len as usize) < spectrum.len() {
                spectrum[len as usize] += 1;
            }
        }
    }

    spectrum
}

/// Compute cascade length for a single value.
fn cascade_length(value: u64) -> u32 {
    // Cascade length = trailing ones count
    // When we add 1, all trailing 1s flip to 0 and carry propagates
    (!value).trailing_zeros().min(63)
}

/// Compute monodromy signature tuple.
fn compute_signature(path: &[u64], quantum: u32) -> (i64, u64, Vec<u32>) {
    (
        winding_number(path, quantum),
        total_variation(path, quantum),
        cascade_spectrum(path),
    )
}

/// Binomial coefficient C(n, k).
fn binomial(n: u32, k: u32) -> u32 {
    if k > n {
        return 0;
    }
    let k = k.min(n - k);
    let mut result = 1u32;
    for i in 0..k {
        result = result * (n - i) / (i + 1);
    }
    result
}
