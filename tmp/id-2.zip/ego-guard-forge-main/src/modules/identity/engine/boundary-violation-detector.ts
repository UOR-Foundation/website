/**
 * Boundary Violation Detector — Real-time AI Response Scanner
 * ════════════════════════════════════════════════════════════
 *
 * Monitors AI assistant responses for references to shielded dimensions.
 * When the sovereignty surface marks a dimension as "shielded", the AI
 * should NEVER reference, infer, or reconstruct data from that dimension.
 *
 * The detector uses keyword/pattern matching per dimension plus inference
 * heuristics (e.g. "based on your location" when location is shielded).
 *
 * Pure functions. No side effects.
 *
 * @module identity/engine/boundary-violation-detector
 */

import type { SovereigntySurface, SovereigntyDimensionId } from "../types";
import type { BoundaryAttestation, DimensionClaim } from "./attestation-engine";

// ── Types ───────────────────────────────────────────────────────────────────

export type ViolationSeverity = "warning" | "critical";

export interface BoundaryViolation {
  readonly id: string;
  readonly dimension: SovereigntyDimensionId;
  readonly dimensionLabel: string;
  readonly severity: ViolationSeverity;
  readonly matchedTerm: string;
  readonly context: string;          // surrounding text snippet
  readonly position: number;         // char offset in response
  readonly rule: string;             // which rule triggered
  readonly timestamp: number;
}

export interface ViolationReport {
  readonly responseId: string;
  readonly violations: readonly BoundaryViolation[];
  readonly scannedAt: number;
  readonly shieldedDimensions: readonly string[];
  readonly isClean: boolean;
}

// ── Dimension Keyword Maps ──────────────────────────────────────────────────

/** Keywords and patterns associated with each dimension. */
const DIMENSION_PATTERNS: Record<SovereigntyDimensionId, readonly RegExp[]> = {
  identity: [
    /\b(real\s*name|full\s*name|legal\s*name|birth\s*name)\b/i,
    /\b(passport|ssn|social\s*security|national\s*id|driver'?s?\s*licen[cs]e)\b/i,
    /\b(date\s*of\s*birth|dob|age|born\s*(in|on))\b/i,
    /\b(your\s*identity|who\s*you\s*are|your\s*person)\b/i,
    /\b(pii|personal\s*identif)/i,
  ],
  data: [
    /\b(your\s*(data|files|documents|records|history))\b/i,
    /\b(stored\s*(data|information)|data\s*you\s*(have|store))\b/i,
    /\b(browsing\s*history|search\s*history|activity\s*log)\b/i,
    /\b(personal\s*data|private\s*data|sensitive\s*data)\b/i,
    /\b(your\s*database|your\s*storage)\b/i,
  ],
  compute: [
    /\b(your\s*(device|computer|phone|hardware|machine))\b/i,
    /\b(processing\s*power|cpu|gpu|compute\s*resource)\b/i,
    /\b(local\s*computation|edge\s*compute|your\s*server)\b/i,
    /\b(running\s*on\s*your|executed\s*locally)\b/i,
  ],
  social: [
    /\b(your\s*(friends|contacts|followers|connections|network))\b/i,
    /\b(social\s*(graph|circle|network|media))\b/i,
    /\b(relationship|who\s*you\s*know|your\s*community)\b/i,
    /\b(your\s*(group|team|org|organization))\b/i,
    /\b(messaging|chat\s*history|conversations\s*with)\b/i,
  ],
  economic: [
    /\b(your\s*(balance|wallet|account|funds|money|income|salary))\b/i,
    /\b(financial|payment|transaction|banking)\b/i,
    /\b(credit|debit|invest|portfolio|asset)\b/i,
    /\b(earn|spend|purchas|buy|sell)\b/i,
    /\b(your\s*(budget|savings|debt|loan))\b/i,
  ],
  governance: [
    /\b(your\s*(vote|voting|ballot|poll))\b/i,
    /\b(governance\s*decision|your\s*decision\s*making)\b/i,
    /\b(your\s*(authority|jurisdiction|mandate))\b/i,
    /\b(access\s*control|your\s*permissions|your\s*role)\b/i,
    /\b(policy\s*preference|regulatory)\b/i,
  ],
};

/** Inference heuristic patterns — indirect data reconstruction attempts. */
const INFERENCE_PATTERNS: Record<SovereigntyDimensionId, readonly RegExp[]> = {
  identity: [
    /\b(based\s*on\s*who\s*you\s*are|given\s*your\s*identity)\b/i,
    /\b(i\s*(can\s*see|know|infer)\s*(that\s*)?you\s*are)\b/i,
    /\b(you\s*seem\s*to\s*be|you\s*appear\s*to\s*be)\b/i,
  ],
  data: [
    /\b(from\s*your\s*data|your\s*data\s*(shows?|indicates?|suggests?))\b/i,
    /\b(based\s*on\s*(your|the)\s*(records?|logs?|history))\b/i,
    /\b(i\s*can\s*see\s*(from|in)\s*your)\b/i,
  ],
  compute: [
    /\b(your\s*(system|device)\s*(shows?|indicates?|runs?))\b/i,
    /\b(on\s*your\s*machine|locally\s*on\s*your)\b/i,
  ],
  social: [
    /\b(your\s*(friends?|contacts?)\s*(would|might|seem))\b/i,
    /\b(people\s*you\s*know|in\s*your\s*network)\b/i,
    /\b(your\s*social\s*(circle|graph)\s*(shows?|suggests?))\b/i,
  ],
  economic: [
    /\b(your\s*spending\s*(pattern|habit|shows?))\b/i,
    /\b(based\s*on\s*your\s*(financ|transact|purchas))\b/i,
    /\b(you\s*(can|could)\s*afford|within\s*your\s*budget)\b/i,
  ],
  governance: [
    /\b(your\s*(voting|governance)\s*(pattern|history|record))\b/i,
    /\b(based\s*on\s*your\s*(decisions?|choices?|authority))\b/i,
  ],
};

const DIMENSION_LABELS: Record<SovereigntyDimensionId, string> = {
  identity: "Identity",
  data: "Data",
  compute: "Compute",
  social: "Social",
  economic: "Economic",
  governance: "Governance",
};

// ── Core Detection ──────────────────────────────────────────────────────────

function extractContext(text: string, position: number, radius = 40): string {
  const start = Math.max(0, position - radius);
  const end = Math.min(text.length, position + radius);
  let ctx = text.slice(start, end);
  if (start > 0) ctx = "…" + ctx;
  if (end < text.length) ctx = ctx + "…";
  return ctx;
}

/**
 * Get shielded dimension IDs from attestation or surface.
 */
export function getShieldedDimensions(
  attestation: BoundaryAttestation | null,
  surface?: SovereigntySurface,
): SovereigntyDimensionId[] {
  if (attestation) {
    return attestation.dimensions
      .filter((d) => d.state === "shielded")
      .map((d) => {
        const entry = Object.entries(DIMENSION_LABELS).find(([, v]) => v === d.dimension);
        return (entry?.[0] ?? d.dimension.toLowerCase()) as SovereigntyDimensionId;
      });
  }
  return [];
}

/**
 * Scan a single AI response for boundary violations against shielded dimensions.
 */
export function detectViolations(
  responseText: string,
  responseId: string,
  shieldedDimensions: SovereigntyDimensionId[],
): ViolationReport {
  const violations: BoundaryViolation[] = [];
  let violationIdx = 0;

  for (const dimId of shieldedDimensions) {
    // Direct reference patterns
    const directPatterns = DIMENSION_PATTERNS[dimId] ?? [];
    for (const pattern of directPatterns) {
      const matches = responseText.matchAll(new RegExp(pattern, "gi"));
      for (const match of matches) {
        const pos = match.index ?? 0;
        violations.push({
          id: `v-${responseId}-${violationIdx++}`,
          dimension: dimId,
          dimensionLabel: DIMENSION_LABELS[dimId],
          severity: "critical",
          matchedTerm: match[0],
          context: extractContext(responseText, pos),
          position: pos,
          rule: `direct_reference:${dimId}`,
          timestamp: Date.now(),
        });
      }
    }

    // Inference heuristic patterns
    const inferPatterns = INFERENCE_PATTERNS[dimId] ?? [];
    for (const pattern of inferPatterns) {
      const matches = responseText.matchAll(new RegExp(pattern, "gi"));
      for (const match of matches) {
        const pos = match.index ?? 0;
        // Avoid duplicate at same position
        if (violations.some((v) => Math.abs(v.position - pos) < 10 && v.dimension === dimId)) continue;
        violations.push({
          id: `v-${responseId}-${violationIdx++}`,
          dimension: dimId,
          dimensionLabel: DIMENSION_LABELS[dimId],
          severity: "warning",
          matchedTerm: match[0],
          context: extractContext(responseText, pos),
          position: pos,
          rule: `inference_heuristic:${dimId}`,
          timestamp: Date.now(),
        });
      }
    }
  }

  // Sort by position
  violations.sort((a, b) => a.position - b.position);

  return {
    responseId,
    violations,
    scannedAt: Date.now(),
    shieldedDimensions: shieldedDimensions.map((d) => DIMENSION_LABELS[d]),
    isClean: violations.length === 0,
  };
}

/**
 * Redact all violations from a response, replacing matched terms
 * with a human-readable placeholder like [REDACTED: Identity].
 * Processes matches from end to start so positions stay valid.
 */
export function redactViolations(
  text: string,
  report: ViolationReport,
): string {
  if (report.isClean) return text;

  // Deduplicate by position+length to avoid overlapping replacements
  const seen = new Set<string>();
  const unique = report.violations.filter((v) => {
    const key = `${v.position}:${v.matchedTerm.length}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  // Sort descending by position so earlier indices stay valid
  const sorted = [...unique].sort((a, b) => b.position - a.position);

  let result = text;
  for (const v of sorted) {
    const before = result.slice(0, v.position);
    const after = result.slice(v.position + v.matchedTerm.length);
    result = `${before}[REDACTED: ${v.dimensionLabel}]${after}`;
  }
  return result;
}

/**
 * Incrementally scan streaming text — call with accumulating content.
 * Returns only NEW violations since last scan position.
 */
export function detectViolationsIncremental(
  fullText: string,
  responseId: string,
  shieldedDimensions: SovereigntyDimensionId[],
  lastScannedLength: number,
): { report: ViolationReport; newViolations: readonly BoundaryViolation[] } {
  const report = detectViolations(fullText, responseId, shieldedDimensions);
  const newViolations = report.violations.filter((v) => v.position >= lastScannedLength);
  return { report, newViolations };
}
