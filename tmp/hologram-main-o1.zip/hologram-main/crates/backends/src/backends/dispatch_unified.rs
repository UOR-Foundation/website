//! Unified instruction dispatch for all backends.
//!
//! This module provides a single dispatch function that works with any backend
//! implementing the `InstructionDispatcher` trait. This eliminates the ~400-line
//! duplicate match statements in CPU and WASM backends.

use hologram_holo::IsaInstruction;

use crate::types::Result;

/// Extension trait enabling instructions to execute themselves on a dispatcher.
///
/// This trait allows calling `instruction.execute(&mut dispatcher)`, making the
/// dispatch pattern more idiomatic and keeping the execution logic closer to the
/// instruction type.
///
/// # Example
///
/// ```rust,ignore
/// use hologram_backend::backends::{ExecuteOn, InstructionDispatcher};
///
/// for instruction in &plan.instructions {
///     instruction.execute(&mut dispatcher)?;
/// }
/// ```
pub trait ExecuteOn<D> {
    /// Execute this instruction using the provided dispatcher.
    fn execute(&self, dispatcher: &mut D) -> Result<()>;
}

// Generated from descriptors/shells/isa.shell — see specs/research/shell-dsl-isa-codegen.md
include!(concat!(env!("OUT_DIR"), "/generated_dispatcher_trait.rs"));

include!(concat!(env!("OUT_DIR"), "/generated_execute_on.rs"));

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::BackendError;

    /// Mock dispatcher that counts method calls for testing
    #[allow(clippy::struct_field_names)]
    struct MockDispatcher {
        add_calls: usize,
        matmul_calls: usize,
        conv2d_calls: usize,
    }

    impl MockDispatcher {
        fn new() -> Self {
            Self {
                add_calls: 0,
                matmul_calls: 0,
                conv2d_calls: 0,
            }
        }
    }

    /// No-op mock method: accepts any signature, returns Ok(()).
    macro_rules! mock_noop {
        ($( fn $name:ident($($args:tt)*); )+) => {
            $( fn $name(&mut self, $($args)*) -> Result<()> { Ok(()) } )+
        };
    }

    impl InstructionDispatcher for MockDispatcher {
        fn exec_add(&mut self, _: u32, _: u32, _: u32, _: usize) -> Result<()> {
            self.add_calls += 1;
            Ok(())
        }
        fn exec_matmul(
            &mut self,
            _: u32,
            _: u32,
            _: u32,
            _: usize,
            _: usize,
            _: usize,
        ) -> Result<()> {
            self.matmul_calls += 1;
            Ok(())
        }
        fn exec_conv2d(
            &mut self,
            _: u32,
            _: u32,
            _: u32,
            _: Option<u32>,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
            _: usize,
        ) -> Result<()> {
            self.conv2d_calls += 1;
            Ok(())
        }
        fn exec_call_layer(&mut self, _: u64, _: &[u32], _: &[u32]) -> Result<()> {
            Err(BackendError::UnsupportedInstruction("CallLayer".into()))
        }
        fn exec_viterbi_tokenize(
            &mut self,
            _: u32,
            _: u32,
            _: u32,
            _: usize,
            _: u32,
            _: usize,
            _: usize,
            _: u32,
            _: u32,
            _: f32,
        ) -> Result<()> {
            Err(BackendError::UnsupportedInstruction(
                "ViterbiTokenize".into(),
            ))
        }

        mock_noop!(
            fn exec_sub(_: u32, _: u32, _: u32, _: usize);
            fn exec_mul(_: u32, _: u32, _: u32, _: usize);
            fn exec_div(_: u32, _: u32, _: u32, _: usize);
            fn exec_sqrt(_: u32, _: u32, _: usize);
            fn exec_log(_: u32, _: u32, _: usize);
            fn exec_pow(_: u32, _: u32, _: u32, _: usize);
            fn exec_exp(_: u32, _: u32, _: usize);
            fn exec_abs(_: u32, _: u32, _: usize);
            fn exec_elem_min(_: u32, _: u32, _: u32, _: usize);
            fn exec_elem_max(_: u32, _: u32, _: u32, _: usize);
            fn exec_greater(_: u32, _: u32, _: u32, _: usize);
            fn exec_less(_: u32, _: u32, _: u32, _: usize);
            fn exec_less_or_equal(_: u32, _: u32, _: u32, _: usize);
            fn exec_greater_or_equal(_: u32, _: u32, _: u32, _: usize);
            fn exec_where(_: u32, _: u32, _: u32, _: u32, _: usize);
            fn exec_sigmoid(_: u32, _: u32, _: usize);
            fn exec_tanh(_: u32, _: u32, _: usize);
            fn exec_relu(_: u32, _: u32, _: usize);
            fn exec_softmax(_: u32, _: u32, _: usize, _: usize, _: usize);
            fn exec_batch_matmul(_: u32, _: u32, _: u32, _: usize, _: usize, _: usize, _: usize);
            fn exec_matmul_lut(_: u32, _: u32, _: u32, _: u32, _: usize, _: usize, _: usize, _: u8);
            fn exec_sum(_: u32, _: u32, _: usize);
            fn exec_max(_: u32, _: u32, _: usize);
            fn exec_min(_: u32, _: u32, _: usize);
            fn exec_reduce_mean(_: u32, _: u32, _: usize, _: usize, _: usize);
            fn exec_lift(_: u32, _: u32, _: usize);
            fn exec_orbit_classify(_: u32, _: u32, _: usize);
            fn exec_ring_add(_: u32, _: u32, _: u32, _: usize);
            fn exec_ring_mul(_: u32, _: u32, _: u32, _: usize);
            fn exec_sigmoid_lut(_: u32, _: u32, _: usize);
            fn exec_tanh_lut(_: u32, _: u32, _: usize);
            fn exec_exp_lut(_: u32, _: u32, _: usize);
            fn exec_log_lut(_: u32, _: u32, _: usize);
            fn exec_relu_lut(_: u32, _: u32, _: usize);
            fn exec_sqrt_lut(_: u32, _: u32, _: usize);
            fn exec_abs_lut(_: u32, _: u32, _: usize);
            fn exec_gelu_lut(_: u32, _: u32, _: usize);
            fn exec_silu_lut(_: u32, _: u32, _: usize);
            fn exec_load(_: u32, _: usize, _: usize);
            fn exec_store(_: u32, _: usize, _: usize);
            fn exec_copy(_: u32, _: u32, _: usize);
            fn exec_encode(_: u32, _: u32, _: u32, _: usize);
            fn exec_decode(_: u32, _: u32, _: u32, _: usize);
            fn exec_reshape(_: u32, _: u32, _: usize);
            fn exec_transpose(_: u32, _: u32, _: usize, _: u8, _: &[usize; 8], _: [u8; 8]);
            fn exec_gather(_: u32, _: u32, _: u32, _: u8, _: usize, _: usize, _: usize);
            fn exec_concat(_: u32, _: &[u32; 8], _: u8, _: &[usize; 8]);
            fn exec_unsqueeze(_: u32, _: u32, _: usize);
            fn exec_squeeze(_: u32, _: u32, _: usize);
            fn exec_slice(
                _: u32,
                _: u32,
                _: u8,
                _: &[u32; 4],
                _: &[u32; 4],
                _: &[u32; 4],
                _: &[i32; 4],
                _: u8,
            );
            fn exec_pad(
                _: u32,
                _: u32,
                _: u8,
                _: &[u32; 4],
                _: &[u32; 4],
                _: &[u32; 4],
                _: f32,
                _: u8,
            );
            fn exec_cast(_: u32, _: u32, _: usize, _: u8, _: u8);
            fn exec_tile(_: u32, _: u32, _: u8, _: &[usize; 8], _: &[usize; 8], _: usize);
            fn exec_expand(_: u32, _: u32, _: u8, _: &[usize; 8], _: &[usize; 8], _: usize);
            fn exec_batch_norm(
                _: u32,
                _: u32,
                _: u32,
                _: u32,
                _: u32,
                _: u32,
                _: f32,
                _: usize,
                _: usize,
                _: usize,
            );
            fn exec_layer_norm(_: u32, _: u32, _: u32, _: u32, _: f32, _: usize, _: usize);
            fn exec_max_pool2d(
                _: u32,
                _: u32,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
            );
            fn exec_avg_pool2d(
                _: u32,
                _: u32,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
                _: usize,
            );
            fn exec_global_avg_pool(_: u32, _: u32, _: usize, _: usize, _: usize);
            fn exec_sha256(_: u32, _: u32, _: usize);
            fn exec_double_sha256(_: u32, _: u32, _: usize);
            fn exec_matmul_relu(_: u32, _: u32, _: u32, _: usize, _: usize, _: usize);
            fn exec_add_sigmoid(_: u32, _: u32, _: u32, _: usize);
        );
    }

    #[test]
    fn test_dispatch_add() {
        let mut mock = MockDispatcher::new();
        let instr = IsaInstruction::Add {
            dst: 0,
            a: 1,
            b: 2,
            count: 100,
        };
        instr.execute(&mut mock).unwrap();
        assert_eq!(mock.add_calls, 1);
    }

    #[test]
    fn test_dispatch_matmul() {
        let mut mock = MockDispatcher::new();
        let instr = IsaInstruction::MatMul {
            c: 0,
            a: 1,
            b: 2,
            m: 32,
            k: 64,
            n: 16,
        };
        instr.execute(&mut mock).unwrap();
        assert_eq!(mock.matmul_calls, 1);
    }

    #[test]
    fn test_dispatch_conv2d() {
        let mut mock = MockDispatcher::new();
        let instr = IsaInstruction::Conv2d {
            dst: 0,
            input: 1,
            weight: 2,
            bias: Some(3),
            kernel_h: 3,
            kernel_w: 3,
            stride_h: 1,
            stride_w: 1,
            pad_h: 1,
            pad_w: 1,
            dilation_h: 1,
            dilation_w: 1,
            groups: 1,
            batch: 1,
            in_channels: 64,
            out_channels: 128,
            in_h: 28,
            in_w: 28,
            out_h: 28,
            out_w: 28,
        };
        instr.execute(&mut mock).unwrap();
        assert_eq!(mock.conv2d_calls, 1);
    }

    #[test]
    fn test_dispatch_call_layer_unsupported() {
        let mut mock = MockDispatcher::new();
        let instr = IsaInstruction::CallLayer {
            layer_id: 12345,
            inputs: vec![0, 1],
            outputs: vec![2],
        };
        let result = instr.execute(&mut mock);
        assert!(result.is_err());
    }
}
