//! Conformance test suite for prism stdlib operations.
//!
//! Verifies that all stdlib operations:
//! 1. Have valid conformance targets defined
//! 2. Execute without panic
//! 3. Produce correct results for known inputs
//!
//! Note: Actual cycle measurements are hardware-dependent and validated
//! via benchmarks, not tests. These tests verify the conformance framework
//! is correctly configured.

use prism::ops::elementwise::{
    AddOp, AndOp, NotOp, OrOp, RotlOp, RotrOp, ShlOp, ShrOp, SubOp, XorOp,
};
use prism::ops::shuffle::{BroadcastOp, ShuffleOp};
use prism::ops::{BinaryOperation, ConformanceTier, Operation};
use prism::state::State;

/// Verify that conformance targets are valid (minimum >= optimal >= theoretical).
fn verify_targets_valid<O: Operation>() {
    let targets = O::TARGETS;
    assert!(
        targets.minimum >= targets.optimal,
        "{}: minimum ({}) must be >= optimal ({})",
        O::NAME,
        targets.minimum,
        targets.optimal
    );
    assert!(
        targets.optimal >= targets.theoretical,
        "{}: optimal ({}) must be >= theoretical ({})",
        O::NAME,
        targets.optimal,
        targets.theoretical
    );
    assert!(
        targets.theoretical >= 1,
        "{}: theoretical ({}) must be >= 1",
        O::NAME,
        targets.theoretical
    );
}

fn verify_binary_targets_valid<O: BinaryOperation>() {
    let targets = O::TARGETS;
    assert!(
        targets.minimum >= targets.optimal,
        "{}: minimum ({}) must be >= optimal ({})",
        O::NAME,
        targets.minimum,
        targets.optimal
    );
    assert!(
        targets.optimal >= targets.theoretical,
        "{}: optimal ({}) must be >= theoretical ({})",
        O::NAME,
        targets.optimal,
        targets.theoretical
    );
    assert!(
        targets.theoretical >= 1,
        "{}: theoretical ({}) must be >= 1",
        O::NAME,
        targets.theoretical
    );
}

// ---------------------------------------------------------------------------
// Elementwise binary operations conformance
// ---------------------------------------------------------------------------

#[test]
fn test_xor_conformance_targets() {
    verify_binary_targets_valid::<XorOp>();
}

#[test]
fn test_and_conformance_targets() {
    verify_binary_targets_valid::<AndOp>();
}

#[test]
fn test_or_conformance_targets() {
    verify_binary_targets_valid::<OrOp>();
}

#[test]
fn test_add_conformance_targets() {
    verify_binary_targets_valid::<AddOp>();
}

#[test]
fn test_sub_conformance_targets() {
    verify_binary_targets_valid::<SubOp>();
}

// ---------------------------------------------------------------------------
// Elementwise unary operations conformance
// ---------------------------------------------------------------------------

#[test]
fn test_not_conformance_targets() {
    verify_targets_valid::<NotOp>();
}

#[test]
fn test_shl_conformance_targets() {
    verify_targets_valid::<ShlOp>();
}

#[test]
fn test_shr_conformance_targets() {
    verify_targets_valid::<ShrOp>();
}

#[test]
fn test_rotl_conformance_targets() {
    verify_targets_valid::<RotlOp>();
}

#[test]
fn test_rotr_conformance_targets() {
    verify_targets_valid::<RotrOp>();
}

// ---------------------------------------------------------------------------
// Shuffle operations conformance
// ---------------------------------------------------------------------------

#[test]
fn test_shuffle_conformance_targets() {
    verify_targets_valid::<ShuffleOp>();
}

#[test]
fn test_broadcast_conformance_targets() {
    verify_targets_valid::<BroadcastOp>();
}

// ---------------------------------------------------------------------------
// Conformance tier logic tests
// ---------------------------------------------------------------------------

#[test]
fn test_conformance_tier_ordering() {
    // Verify tier ordering is correct
    assert!(ConformanceTier::Theoretical as u8 > ConformanceTier::Optimal as u8);
    assert!(ConformanceTier::Optimal as u8 > ConformanceTier::Minimum as u8);
    assert!(ConformanceTier::Minimum as u8 > ConformanceTier::NonConformant as u8);
}

#[test]
fn test_conformance_tier_is_conformant() {
    assert!(!ConformanceTier::NonConformant.is_conformant());
    assert!(ConformanceTier::Minimum.is_conformant());
    assert!(ConformanceTier::Optimal.is_conformant());
    assert!(ConformanceTier::Theoretical.is_conformant());
}

// ---------------------------------------------------------------------------
// Operation correctness tests (verify they execute without panic)
// ---------------------------------------------------------------------------

#[test]
fn test_all_binary_ops_execute() {
    let a = State::from_bytes(&[0xAA; 624]);
    let b = State::from_bytes(&[0x55; 624]);

    // All binary ops should execute without panic
    let _ = XorOp.apply(a, b);
    let _ = AndOp.apply(a, b);
    let _ = OrOp.apply(a, b);
    let _ = AddOp.apply(a, b);
    let _ = SubOp.apply(a, b);
}

#[test]
fn test_all_unary_ops_execute() {
    let s = State::from_bytes(&[0xAA; 624]);

    // All unary ops should execute without panic
    let _ = NotOp.apply(s);
    let _ = ShlOp(8).apply(s);
    let _ = ShrOp(8).apply(s);
    let _ = RotlOp(7).apply(s);
    let _ = RotrOp(7).apply(s);
}

#[test]
fn test_shuffle_ops_execute() {
    let s = State::from_bytes(&[0xCD; 624]);
    let indices = [0u8; State::LEN];

    let _ = ShuffleOp { indices }.apply(s);
    let _ = BroadcastOp(0).apply(s);
}

// ---------------------------------------------------------------------------
// Known-answer tests for correctness
// ---------------------------------------------------------------------------

#[test]
fn test_xor_known_answer() {
    let a = State::ones();
    let b = State::ones();
    let result = XorOp.apply(a, b);
    assert_eq!(result, State::zeros());
}

#[test]
fn test_and_known_answer() {
    let a = State::ones();
    let b = State::zeros();
    let result = AndOp.apply(a, b);
    assert_eq!(result, State::zeros());
}

#[test]
fn test_or_known_answer() {
    let a = State::zeros();
    let b = State::ones();
    let result = OrOp.apply(a, b);
    assert_eq!(result, State::ones());
}

#[test]
fn test_not_known_answer() {
    let s = State::zeros();
    let result = NotOp.apply(s);
    assert_eq!(result, State::ones());
}

#[test]
fn test_broadcast_known_answer() {
    let mut s = State::zeros();
    s.as_bytes_mut()[0] = 42;
    let result = BroadcastOp(0).apply(s);
    assert!(result.as_bytes().iter().all(|&b| b == 42));
}

// ---------------------------------------------------------------------------
// Verify conformance framework integration
// ---------------------------------------------------------------------------

#[test]
fn test_verify_conformance_integration() {
    use prism::ops::verify_operation;

    // Simulate a measurement at the optimal tier
    let result = verify_operation(&NotOp, NotOp::TARGETS.optimal);
    assert!(result.tier.is_conformant());
    assert_eq!(result.tier, ConformanceTier::Optimal);

    // Simulate a measurement above minimum (non-conformant)
    let result = verify_operation(&NotOp, NotOp::TARGETS.minimum + 1);
    assert!(!result.tier.is_conformant());
}

#[test]
fn test_verify_binary_conformance_integration() {
    use prism::ops::verify_binary_operation;

    // Simulate a measurement at the theoretical tier
    let result = verify_binary_operation(&XorOp, XorOp::TARGETS.theoretical);
    assert!(result.tier.is_conformant());
    assert_eq!(result.tier, ConformanceTier::Theoretical);
}
