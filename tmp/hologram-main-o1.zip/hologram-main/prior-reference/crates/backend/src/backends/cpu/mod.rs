//! CPU backend implementation.
//!
//! The CPU backend uses interior mutability to enable thread-safe parallel execution.
//! Buffer storage uses `RwLock` for concurrent reads, handle generation uses `AtomicU64`,
//! and the buffer pool uses `Mutex` for allocation reuse.

pub mod aspect_gemm;
pub mod compute;
pub mod depthwise;
#[cfg(feature = "fft")]
pub mod fft;
pub mod grouped;
mod interpreter;
pub mod kernels;
pub mod pointwise;
pub mod simd_dispatch;
pub mod winograd;

use crate::{
    AspectAwareMatMulParams, BackendError, BackendType, BufferHandle, ComputeBackend, Conv2DParams,
    DepthwiseConv2DParams, GemmAspectHint, GroupedConv2DParams, LaunchConfig, MatMulParams,
    PointwiseConvParams, ProgramBackend,
};
use hologram_isa::{Program, Type};
use rustc_hash::FxHashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Mutex, RwLock};

pub use interpreter::Interpreter;
pub use simd_dispatch::{
    cpu_capability, cpu_kernels, CpuKernelTable, SimdCapability, SimdDispatcher, TileConfig,
    CPU_CAPABILITY, CPU_KERNELS,
};

// ============================================================================
// BUFFER POOL
// ============================================================================

/// Pool for reusing temporary buffer allocations.
///
/// Buffers are stored by size bucket for fast matching.
/// Uses power-of-2 size classes to reduce fragmentation.
pub struct BufferPool {
    /// Free buffers organized by size bucket (power of 2).
    /// Key: log2(capacity), Value: list of available buffers.
    buckets: FxHashMap<u8, Vec<Vec<u8>>>,
    /// Maximum total bytes to keep in pool (default: 64MB).
    max_pool_bytes: usize,
    /// Current total bytes in pool.
    current_bytes: usize,
}

impl BufferPool {
    /// Create a new buffer pool with default 64MB capacity.
    pub fn new() -> Self {
        Self::with_max_bytes(64 * 1024 * 1024)
    }

    /// Create a buffer pool with custom maximum capacity.
    pub fn with_max_bytes(max_bytes: usize) -> Self {
        Self {
            buckets: FxHashMap::default(),
            max_pool_bytes: max_bytes,
            current_bytes: 0,
        }
    }

    /// Get a buffer of at least `size` bytes.
    ///
    /// Returns a pooled buffer if available, otherwise allocates new.
    /// Buffers are zeroed before return.
    /// Minimum capacity is 64 bytes for cache-line alignment compatibility.
    pub fn get(&mut self, size: usize) -> Vec<u8> {
        if size == 0 {
            return Vec::new();
        }

        // Ensure minimum capacity of 64 bytes for cache-line alignment
        let effective_size = size.max(64);
        let bucket = effective_size.next_power_of_two().trailing_zeros() as u8;

        // Try to find a buffer in this bucket
        if let Some(buffers) = self.buckets.get_mut(&bucket) {
            if let Some(mut buf) = buffers.pop() {
                self.current_bytes -= buf.capacity();
                buf.clear();
                buf.resize(size, 0);
                return buf;
            }
        }

        // Allocate new buffer with power-of-2 capacity (minimum 64 bytes)
        let capacity = effective_size.next_power_of_two();
        let mut buf = Vec::with_capacity(capacity);
        buf.resize(size, 0);
        buf
    }

    /// Return a buffer to the pool for reuse.
    ///
    /// If the pool is at capacity, the buffer is dropped instead.
    pub fn put(&mut self, buf: Vec<u8>) {
        if buf.capacity() == 0 {
            return;
        }

        // Don't exceed max pool size
        if self.current_bytes + buf.capacity() > self.max_pool_bytes {
            return; // Let it drop
        }

        let bucket = buf.capacity().trailing_zeros() as u8;
        self.current_bytes += buf.capacity();
        self.buckets.entry(bucket).or_default().push(buf);
    }

    /// Clear all pooled buffers, freeing memory.
    pub fn clear(&mut self) {
        self.buckets.clear();
        self.current_bytes = 0;
    }

    /// Get the current number of bytes held in the pool.
    pub fn bytes_pooled(&self) -> usize {
        self.current_bytes
    }
}

impl Default for BufferPool {
    fn default() -> Self {
        Self::new()
    }
}

// ============================================================================
// CPU BACKEND
// ============================================================================

/// CPU backend for ISA execution.
///
/// Uses interior mutability for thread-safe parallel execution:
/// - `RwLock<HashMap>` for buffer storage (concurrent reads, exclusive writes)
/// - `AtomicU64` for handle generation (lock-free allocation)
/// - `Mutex<BufferPool>` for buffer reuse (rarely contended)
pub struct CpuBackend {
    /// Buffer storage with read-write lock for concurrent access.
    buffers: RwLock<FxHashMap<u64, Vec<u8>>>,
    /// Atomic counter for handle IDs - lock-free allocation.
    next_handle: AtomicU64,
    /// ISA interpreter (has internal state, protected by mutex).
    interpreter: Mutex<Interpreter>,
    /// SIMD dispatcher (stateless, safe to share).
    simd_dispatcher: SimdDispatcher,
    /// Buffer pool for allocation reuse (protected by mutex).
    buffer_pool: Mutex<BufferPool>,
}

impl CpuBackend {
    /// Create a new CPU backend.
    pub fn new() -> Self {
        Self {
            buffers: RwLock::new(FxHashMap::default()),
            next_handle: AtomicU64::new(0),
            interpreter: Mutex::new(Interpreter::new()),
            simd_dispatcher: SimdDispatcher::new(),
            buffer_pool: Mutex::new(BufferPool::new()),
        }
    }

    /// Create a new CPU backend with custom buffer pool capacity.
    pub fn with_pool_capacity(max_pool_bytes: usize) -> Self {
        Self {
            buffers: RwLock::new(FxHashMap::default()),
            next_handle: AtomicU64::new(0),
            interpreter: Mutex::new(Interpreter::new()),
            simd_dispatcher: SimdDispatcher::new(),
            buffer_pool: Mutex::new(BufferPool::with_max_bytes(max_pool_bytes)),
        }
    }

    /// Get the number of bytes currently held in the buffer pool.
    pub fn pool_bytes(&self) -> usize {
        self.buffer_pool
            .lock()
            .map(|pool| pool.bytes_pooled())
            .unwrap_or(0)
    }

    /// Clear the buffer pool, freeing all cached memory.
    pub fn clear_pool(&self) {
        if let Ok(mut pool) = self.buffer_pool.lock() {
            pool.clear();
        }
    }

    /// Get the SIMD capability of this backend.
    pub fn simd_capability(&self) -> SimdCapability {
        self.simd_dispatcher.capability()
    }

    /// Generate the next buffer handle (lock-free).
    fn next_buffer_handle(&self) -> BufferHandle {
        let id = self.next_handle.fetch_add(1, Ordering::Relaxed);
        BufferHandle::new(id)
    }

    /// Get buffer data as f32 slice.
    fn get_buffer_f32(&self, handle: BufferHandle) -> Result<Vec<f32>, BackendError> {
        let buffers = self
            .buffers
            .read()
            .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;

        let buffer = buffers
            .get(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;

        // Interpret bytes as f32
        if buffer.len() % 4 != 0 {
            return Err(BackendError::buffer("Buffer size not aligned to f32"));
        }

        let floats: Vec<f32> = buffer
            .chunks_exact(4)
            .map(|chunk| f32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]))
            .collect();

        Ok(floats)
    }

    /// Write f32 slice to buffer.
    fn write_buffer_f32(&self, handle: BufferHandle, data: &[f32]) -> Result<(), BackendError> {
        let mut buffers = self
            .buffers
            .write()
            .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;

        let buffer = buffers
            .get_mut(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;

        let bytes: Vec<u8> = data.iter().flat_map(|f| f.to_le_bytes()).collect();

        if bytes.len() > buffer.len() {
            return Err(BackendError::buffer("Data exceeds buffer size"));
        }

        buffer[..bytes.len()].copy_from_slice(&bytes);
        Ok(())
    }
}

impl Default for CpuBackend {
    fn default() -> Self {
        Self::new()
    }
}

impl ProgramBackend for CpuBackend {
    fn backend_type(&self) -> BackendType {
        BackendType::Cpu
    }

    fn execute_program(
        &self,
        program: &Program,
        _config: &LaunchConfig,
    ) -> Result<(), BackendError> {
        // Use the ISA interpreter to execute the program
        let mut buffers = self
            .buffers
            .write()
            .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;
        let mut interpreter = self
            .interpreter
            .lock()
            .map_err(|_| BackendError::buffer("Interpreter lock poisoned"))?;
        interpreter.execute(program, &mut buffers)
    }

    fn allocate_buffer(&self, size: usize) -> Result<BufferHandle, BackendError> {
        let handle = self.next_buffer_handle();

        // Get buffer from pool (reuses if available, otherwise allocates new)
        let buffer = {
            let mut pool = self
                .buffer_pool
                .lock()
                .map_err(|_| BackendError::buffer("Buffer pool lock poisoned"))?;
            pool.get(size)
        };

        // Insert into storage
        let mut buffers = self
            .buffers
            .write()
            .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;
        buffers.insert(handle.id(), buffer);
        Ok(handle)
    }

    fn free_buffer(&self, handle: BufferHandle) -> Result<(), BackendError> {
        let buffer = {
            let mut buffers = self
                .buffers
                .write()
                .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;
            buffers
                .remove(&handle.id())
                .ok_or(BackendError::InvalidHandle(handle))?
        };

        // Return to pool for reuse
        if let Ok(mut pool) = self.buffer_pool.lock() {
            pool.put(buffer);
        }
        Ok(())
    }

    fn copy_to_buffer(&self, handle: BufferHandle, data: &[u8]) -> Result<(), BackendError> {
        let mut buffers = self
            .buffers
            .write()
            .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;

        let buffer = buffers
            .get_mut(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;
        if data.len() > buffer.len() {
            return Err(BackendError::BufferError("Data exceeds buffer size".into()));
        }
        buffer[..data.len()].copy_from_slice(data);
        Ok(())
    }

    fn copy_from_buffer(&self, handle: BufferHandle, data: &mut [u8]) -> Result<(), BackendError> {
        let buffers = self
            .buffers
            .read()
            .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;

        let buffer = buffers
            .get(&handle.id())
            .ok_or(BackendError::InvalidHandle(handle))?;
        if data.len() > buffer.len() {
            return Err(BackendError::BufferError(
                "Request exceeds buffer size".into(),
            ));
        }
        data.copy_from_slice(&buffer[..data.len()]);
        Ok(())
    }

    fn buffer_size(&self, handle: BufferHandle) -> Result<usize, BackendError> {
        let buffers = self
            .buffers
            .read()
            .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;

        buffers
            .get(&handle.id())
            .map(|b| b.len())
            .ok_or(BackendError::InvalidHandle(handle))
    }

    fn synchronize(&self) -> Result<(), BackendError> {
        // CPU is synchronous, nothing to do
        Ok(())
    }

    fn get_buffer_ptr(&self, handle: BufferHandle) -> Option<*mut u8> {
        let buffers = self.buffers.read().ok()?;
        buffers.get(&handle.id()).map(|v| v.as_ptr() as *mut u8)
    }
}

impl ComputeBackend for CpuBackend {
    fn fma_scalar_crt_batch(
        &self,
        target: &mut [u8],
        a: &[u8],
        k: u64,
    ) -> Result<(), BackendError> {
        for i in 0..target.len().min(a.len()) {
            target[i] = ((a[i] as u64).wrapping_mul(k) % 256) as u8;
        }
        Ok(())
    }

    fn vector_add(
        &self,
        dst: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        count: usize,
    ) -> Result<(), BackendError> {
        let mut buffers = self
            .buffers
            .write()
            .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;

        // Fast path: in-place operation when dst == a (dst += b)
        if dst.id() == a.id() {
            let b_buf = buffers.get(&b.id()).ok_or(BackendError::InvalidHandle(b))?;
            let b_ptr = b_buf.as_ptr();
            let b_len = b_buf.len();

            let dst_buf = buffers
                .get_mut(&dst.id())
                .ok_or(BackendError::InvalidHandle(dst))?;
            let len = count.min(dst_buf.len()).min(b_len);

            // SAFETY: Pointers valid, lengths validated
            unsafe {
                let dst_ptr = dst_buf.as_mut_ptr();
                for i in 0..len {
                    *dst_ptr.add(i) = (*dst_ptr.add(i)).wrapping_add(*b_ptr.add(i));
                }
            }
            return Ok(());
        }

        // Regular path: dst = a + b
        let a_buf = buffers.get(&a.id()).ok_or(BackendError::InvalidHandle(a))?;
        let b_buf = buffers.get(&b.id()).ok_or(BackendError::InvalidHandle(b))?;

        let a_ptr = a_buf.as_ptr();
        let a_len = a_buf.len();
        let b_ptr = b_buf.as_ptr();
        let b_len = b_buf.len();

        // Now get mutable access to dst
        let dst_buf = buffers
            .get_mut(&dst.id())
            .ok_or(BackendError::InvalidHandle(dst))?;

        let len = count.min(dst_buf.len()).min(a_len).min(b_len);

        // SAFETY: Pointers are valid as we hold the write lock, lengths are validated
        unsafe {
            let dst_ptr = dst_buf.as_mut_ptr();
            for i in 0..len {
                *dst_ptr.add(i) = (*a_ptr.add(i)).wrapping_add(*b_ptr.add(i));
            }
        }
        Ok(())
    }

    fn vector_mul(
        &self,
        dst: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        count: usize,
    ) -> Result<(), BackendError> {
        let mut buffers = self
            .buffers
            .write()
            .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;

        // Fast path: in-place operation when dst == a (dst *= b)
        if dst.id() == a.id() {
            let b_buf = buffers.get(&b.id()).ok_or(BackendError::InvalidHandle(b))?;
            let b_ptr = b_buf.as_ptr();
            let b_len = b_buf.len();

            let dst_buf = buffers
                .get_mut(&dst.id())
                .ok_or(BackendError::InvalidHandle(dst))?;
            let len = count.min(dst_buf.len()).min(b_len);

            // SAFETY: Pointers valid, lengths validated
            unsafe {
                let dst_ptr = dst_buf.as_mut_ptr();
                for i in 0..len {
                    *dst_ptr.add(i) = (*dst_ptr.add(i)).wrapping_mul(*b_ptr.add(i));
                }
            }
            return Ok(());
        }

        // Regular path: dst = a * b
        let a_buf = buffers.get(&a.id()).ok_or(BackendError::InvalidHandle(a))?;
        let b_buf = buffers.get(&b.id()).ok_or(BackendError::InvalidHandle(b))?;

        let a_ptr = a_buf.as_ptr();
        let a_len = a_buf.len();
        let b_ptr = b_buf.as_ptr();
        let b_len = b_buf.len();

        // Now get mutable access to dst
        let dst_buf = buffers
            .get_mut(&dst.id())
            .ok_or(BackendError::InvalidHandle(dst))?;

        let len = count.min(dst_buf.len()).min(a_len).min(b_len);

        // SAFETY: Pointers are valid as we hold the write lock, lengths are validated
        unsafe {
            let dst_ptr = dst_buf.as_mut_ptr();
            for i in 0..len {
                *dst_ptr.add(i) = (*a_ptr.add(i)).wrapping_mul(*b_ptr.add(i));
            }
        }
        Ok(())
    }

    fn matmul(
        &self,
        c: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        params: &MatMulParams,
    ) -> Result<(), BackendError> {
        // Currently only support F32
        if params.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "matmul only supports F32, got {:?}",
                params.dtype
            )));
        }

        let m = params.m as usize;
        let k = params.k as usize;
        let n = params.n as usize;

        let mut buffers = self
            .buffers
            .write()
            .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;

        // Get raw pointers and lengths without allocation
        let a_buf = buffers.get(&a.id()).ok_or(BackendError::InvalidHandle(a))?;
        let b_buf = buffers.get(&b.id()).ok_or(BackendError::InvalidHandle(b))?;

        // Validate buffer sizes (in bytes, 4 bytes per f32)
        let a_floats = a_buf.len() / 4;
        let b_floats = b_buf.len() / 4;
        if a_floats < m * k {
            return Err(BackendError::buffer("A buffer too small for matmul"));
        }
        if b_floats < k * n {
            return Err(BackendError::buffer("B buffer too small for matmul"));
        }

        // Get raw pointers (these remain valid as long as we hold the write lock)
        let a_ptr = a_buf.as_ptr() as *const f32;
        let b_ptr = b_buf.as_ptr() as *const f32;

        // Now get mutable access to C
        let c_buf = buffers
            .get_mut(&c.id())
            .ok_or(BackendError::InvalidHandle(c))?;
        let c_floats = c_buf.len() / 4;
        if c_floats < m * n {
            return Err(BackendError::buffer("C buffer too small for matmul"));
        }
        let c_ptr = c_buf.as_mut_ptr() as *mut f32;

        // Create slices from raw pointers (zero-copy)
        // SAFETY: Pointers are valid as we hold the write lock, sizes are validated above
        let a_slice = unsafe { std::slice::from_raw_parts(a_ptr, m * k) };
        let b_slice = unsafe { std::slice::from_raw_parts(b_ptr, k * n) };
        let c_slice = unsafe { std::slice::from_raw_parts_mut(c_ptr, m * n) };

        // Dispatch to SIMD kernel - writes directly to C buffer
        self.simd_dispatcher.matmul_f32(
            c_slice,
            a_slice,
            b_slice,
            m,
            k,
            n,
            params.alpha as f32,
            params.beta as f32,
        )?;

        // No write_buffer_f32 needed - SIMD kernel wrote directly to C buffer
        Ok(())
    }

    fn batch_matmul(
        &self,
        c: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        batch: u32,
        params: &MatMulParams,
    ) -> Result<(), BackendError> {
        // Currently only support F32
        if params.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "batch_matmul only supports F32, got {:?}",
                params.dtype
            )));
        }

        let m = params.m as usize;
        let k = params.k as usize;
        let n = params.n as usize;
        let batch_count = batch as usize;

        let a_stride = m * k;
        let b_stride = k * n;
        let c_stride = m * n;

        let mut buffers = self
            .buffers
            .write()
            .map_err(|_| BackendError::buffer("Buffer storage lock poisoned"))?;

        // Get raw pointers without allocation
        let a_buf = buffers.get(&a.id()).ok_or(BackendError::InvalidHandle(a))?;
        let b_buf = buffers.get(&b.id()).ok_or(BackendError::InvalidHandle(b))?;

        // Validate buffer sizes
        let a_floats = a_buf.len() / 4;
        let b_floats = b_buf.len() / 4;
        if a_floats < batch_count * a_stride {
            return Err(BackendError::buffer("A buffer too small for batch_matmul"));
        }
        if b_floats < batch_count * b_stride {
            return Err(BackendError::buffer("B buffer too small for batch_matmul"));
        }

        let a_ptr = a_buf.as_ptr() as *const f32;
        let b_ptr = b_buf.as_ptr() as *const f32;

        // Get mutable access to C
        let c_buf = buffers
            .get_mut(&c.id())
            .ok_or(BackendError::InvalidHandle(c))?;
        let c_floats = c_buf.len() / 4;
        if c_floats < batch_count * c_stride {
            return Err(BackendError::buffer("C buffer too small for batch_matmul"));
        }
        let c_ptr = c_buf.as_mut_ptr() as *mut f32;

        // Process each batch using raw pointers (zero-copy)
        for i in 0..batch_count {
            // SAFETY: Pointers valid, sizes validated, offsets within bounds
            let a_slice = unsafe { std::slice::from_raw_parts(a_ptr.add(i * a_stride), a_stride) };
            let b_slice = unsafe { std::slice::from_raw_parts(b_ptr.add(i * b_stride), b_stride) };
            let c_slice =
                unsafe { std::slice::from_raw_parts_mut(c_ptr.add(i * c_stride), c_stride) };

            self.simd_dispatcher.matmul_f32(
                c_slice,
                a_slice,
                b_slice,
                m,
                k,
                n,
                params.alpha as f32,
                params.beta as f32,
            )?;
        }

        // No write_buffer_f32 needed - SIMD kernel wrote directly to C buffer
        Ok(())
    }

    fn conv2d(
        &self,
        output: BufferHandle,
        input: BufferHandle,
        kernel: BufferHandle,
        bias: BufferHandle,
        params: &Conv2DParams,
    ) -> Result<(), BackendError> {
        // Currently only support F32
        if params.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "conv2d only supports F32, got {:?}",
                params.dtype
            )));
        }

        let input_data = self.get_buffer_f32(input)?;
        let kernel_data = self.get_buffer_f32(kernel)?;
        let bias_data = if !bias.is_null() {
            Some(self.get_buffer_f32(bias)?)
        } else {
            None
        };

        let out_dims = params.output_dims();
        let out_size = out_dims.iter().map(|&d| d as usize).product::<usize>();
        let mut output_data = vec![0.0f32; out_size];

        let batch = params.input_dims[0] as usize;
        let in_channels = params.input_dims[1] as usize;
        let in_height = params.input_dims[2] as usize;
        let in_width = params.input_dims[3] as usize;
        let out_channels = params.kernel_dims[0] as usize;
        let kernel_h = params.kernel_dims[2] as usize;
        let kernel_w = params.kernel_dims[3] as usize;
        let out_height = out_dims[2] as usize;
        let out_width = out_dims[3] as usize;
        let stride_h = params.stride[0] as usize;
        let stride_w = params.stride[1] as usize;
        let pad_h = params.padding[0] as usize;
        let pad_w = params.padding[1] as usize;

        self.simd_dispatcher.conv2d_f32(
            &mut output_data,
            &input_data,
            &kernel_data,
            bias_data.as_deref(),
            batch,
            in_channels,
            in_height,
            in_width,
            out_channels,
            kernel_h,
            kernel_w,
            out_height,
            out_width,
            stride_h,
            stride_w,
            pad_h,
            pad_w,
        )?;

        // Write result back
        self.write_buffer_f32(output, &output_data)?;

        Ok(())
    }

    fn depthwise_conv2d(
        &self,
        output: BufferHandle,
        input: BufferHandle,
        kernel: BufferHandle,
        bias: BufferHandle,
        params: &DepthwiseConv2DParams,
    ) -> Result<(), BackendError> {
        // Only support F32 for now
        if params.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "depthwise_conv2d only supports F32, got {:?}",
                params.dtype
            )));
        }

        let input_data = self.get_buffer_f32(input)?;
        let kernel_data = self.get_buffer_f32(kernel)?;
        let bias_data = if !bias.is_null() {
            Some(self.get_buffer_f32(bias)?)
        } else {
            None
        };

        let out_dims = params.output_dims();
        let out_size = out_dims.iter().map(|&d| d as usize).product::<usize>();
        let mut output_data = vec![0.0f32; out_size];

        let batch = params.input_dims[0] as usize;
        let in_channels = params.input_dims[1] as usize;
        let in_height = params.input_dims[2] as usize;
        let in_width = params.input_dims[3] as usize;
        let kernel_h = params.kernel_dims[2] as usize;
        let kernel_w = params.kernel_dims[3] as usize;
        let out_height = out_dims[2] as usize;
        let out_width = out_dims[3] as usize;
        let stride_h = params.stride[0] as usize;
        let stride_w = params.stride[1] as usize;
        let pad_h = params.padding[0] as usize;
        let pad_w = params.padding[1] as usize;
        let dilation_h = params.dilation[0] as usize;
        let dilation_w = params.dilation[1] as usize;
        let channel_mul = params.channel_multiplier as usize;

        // Depthwise convolution: each input channel is convolved independently
        // with channel_multiplier output channels per input channel
        let out_channels = in_channels * channel_mul;

        for n in 0..batch {
            for c_in in 0..in_channels {
                for m in 0..channel_mul {
                    let c_out = c_in * channel_mul + m;
                    for oh in 0..out_height {
                        for ow in 0..out_width {
                            let mut sum = 0.0f32;
                            for kh in 0..kernel_h {
                                for kw in 0..kernel_w {
                                    let ih = oh * stride_h + kh * dilation_h;
                                    let iw = ow * stride_w + kw * dilation_w;

                                    // Check padding bounds
                                    if ih >= pad_h
                                        && ih < in_height + pad_h
                                        && iw >= pad_w
                                        && iw < in_width + pad_w
                                    {
                                        let ih_adj = ih - pad_h;
                                        let iw_adj = iw - pad_w;

                                        let in_idx = ((n * in_channels + c_in) * in_height
                                            + ih_adj)
                                            * in_width
                                            + iw_adj;
                                        // Kernel layout: [C_in, channel_mul, KH, KW]
                                        let k_idx = ((c_in * channel_mul + m) * kernel_h + kh)
                                            * kernel_w
                                            + kw;

                                        if in_idx < input_data.len() && k_idx < kernel_data.len() {
                                            sum += input_data[in_idx] * kernel_data[k_idx];
                                        }
                                    }
                                }
                            }

                            // Add bias if present
                            if let Some(ref bias) = bias_data {
                                if c_out < bias.len() {
                                    sum += bias[c_out];
                                }
                            }

                            let out_idx =
                                ((n * out_channels + c_out) * out_height + oh) * out_width + ow;
                            if out_idx < output_data.len() {
                                output_data[out_idx] = sum;
                            }
                        }
                    }
                }
            }
        }

        self.write_buffer_f32(output, &output_data)
    }

    fn pointwise_conv(
        &self,
        output: BufferHandle,
        input: BufferHandle,
        kernel: BufferHandle,
        bias: BufferHandle,
        params: &PointwiseConvParams,
    ) -> Result<(), BackendError> {
        // Only support F32 for now
        if params.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "pointwise_conv only supports F32, got {:?}",
                params.dtype
            )));
        }

        // Pointwise (1x1) convolution is equivalent to GEMM:
        // Input: [N, C_in, H, W] reshaped to [N*H*W, C_in]
        // Kernel: [C_out, C_in, 1, 1] reshaped to [C_in, C_out]
        // Output: [N*H*W, C_out] reshaped to [N, C_out, H, W]

        let (m, k, n) = params.as_matmul_dims();
        let m = m as usize;
        let k = k as usize;
        let n = n as usize;

        let input_data = self.get_buffer_f32(input)?;
        let kernel_data = self.get_buffer_f32(kernel)?;
        let bias_data = if !bias.is_null() {
            Some(self.get_buffer_f32(bias)?)
        } else {
            None
        };

        let mut output_data = vec![0.0f32; m * n];

        // Transpose input from [N, C_in, H, W] to [N*H*W, C_in]
        let batch = params.batch_size() as usize;
        let c_in = params.input_channels() as usize;
        let h = params.input_dims[2] as usize;
        let w = params.input_dims[3] as usize;

        let mut input_reshaped = vec![0.0f32; m * k];
        for nn in 0..batch {
            for hh in 0..h {
                for ww in 0..w {
                    let spatial_idx = nn * h * w + hh * w + ww;
                    for c in 0..c_in {
                        let in_idx = ((nn * c_in + c) * h + hh) * w + ww;
                        if in_idx < input_data.len() {
                            input_reshaped[spatial_idx * k + c] = input_data[in_idx];
                        }
                    }
                }
            }
        }

        // Perform GEMM: output = input_reshaped @ kernel^T
        // kernel is [C_out, C_in], we want [C_in, C_out] for standard GEMM
        self.simd_dispatcher.matmul_f32(
            &mut output_data,
            &input_reshaped,
            &kernel_data,
            m,
            k,
            n,
            1.0,
            0.0,
        )?;

        // Add bias if present (broadcast across spatial dimensions)
        if let Some(ref bias) = bias_data {
            for row in 0..m {
                for col in 0..n {
                    if col < bias.len() {
                        output_data[row * n + col] += bias[col];
                    }
                }
            }
        }

        // Transpose output from [N*H*W, C_out] to [N, C_out, H, W]
        let out_dims = params.output_dims();
        let out_channels = out_dims[1] as usize;
        let mut final_output = vec![0.0f32; m * n];

        for nn in 0..batch {
            for c_out in 0..out_channels {
                for hh in 0..h {
                    for ww in 0..w {
                        let spatial_idx = nn * h * w + hh * w + ww;
                        let out_idx = ((nn * out_channels + c_out) * h + hh) * w + ww;
                        if out_idx < final_output.len()
                            && spatial_idx * n + c_out < output_data.len()
                        {
                            final_output[out_idx] = output_data[spatial_idx * n + c_out];
                        }
                    }
                }
            }
        }

        self.write_buffer_f32(output, &final_output)
    }

    fn grouped_conv2d(
        &self,
        output: BufferHandle,
        input: BufferHandle,
        kernel: BufferHandle,
        bias: BufferHandle,
        params: &GroupedConv2DParams,
    ) -> Result<(), BackendError> {
        // Special case: groups=1 is standard convolution
        if params.is_standard() {
            let conv_params =
                Conv2DParams::new(params.input_dims, params.kernel_dims, params.dtype)
                    .with_stride(params.stride[0], params.stride[1])
                    .with_padding(params.padding[0], params.padding[1])
                    .with_dilation(params.dilation[0], params.dilation[1]);
            return self.conv2d(output, input, kernel, bias, &conv_params);
        }

        // Special case: groups=C_in is depthwise convolution
        if params.is_depthwise() {
            let out_channels = params.kernel_dims[0];
            let in_channels = params.input_dims[1];
            let channel_mul = if in_channels > 0 {
                out_channels / in_channels
            } else {
                1
            };
            let kernel_h = params.kernel_dims[2];
            let kernel_w = params.kernel_dims[3];

            let depthwise_params =
                DepthwiseConv2DParams::new(params.input_dims, kernel_h, kernel_w, params.dtype)
                    .with_stride(params.stride[0], params.stride[1])
                    .with_padding(params.padding[0], params.padding[1])
                    .with_dilation(params.dilation[0], params.dilation[1])
                    .with_multiplier(channel_mul);

            return self.depthwise_conv2d(output, input, kernel, bias, &depthwise_params);
        }

        // General grouped convolution: process G independent convolutions
        // Only support F32 for now
        if params.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "grouped_conv2d only supports F32, got {:?}",
                params.dtype
            )));
        }

        let input_data = self.get_buffer_f32(input)?;
        let kernel_data = self.get_buffer_f32(kernel)?;
        let bias_data = if !bias.is_null() {
            Some(self.get_buffer_f32(bias)?)
        } else {
            None
        };

        let out_dims = params.output_dims();
        let out_size = out_dims.iter().map(|&d| d as usize).product::<usize>();
        let mut output_data = vec![0.0f32; out_size];

        let batch = params.input_dims[0] as usize;
        let in_channels = params.input_dims[1] as usize;
        let in_height = params.input_dims[2] as usize;
        let in_width = params.input_dims[3] as usize;
        let out_channels = params.kernel_dims[0] as usize;
        let kernel_h = params.kernel_dims[2] as usize;
        let kernel_w = params.kernel_dims[3] as usize;
        let out_height = out_dims[2] as usize;
        let out_width = out_dims[3] as usize;
        let stride_h = params.stride[0] as usize;
        let stride_w = params.stride[1] as usize;
        let pad_h = params.padding[0] as usize;
        let pad_w = params.padding[1] as usize;
        let dilation_h = params.dilation[0] as usize;
        let dilation_w = params.dilation[1] as usize;
        let groups = params.groups as usize;
        let in_channels_per_group = params.input_channels_per_group() as usize;
        let out_channels_per_group = params.output_channels_per_group() as usize;

        // Process each group independently
        for g in 0..groups {
            let c_in_start = g * in_channels_per_group;
            let c_out_start = g * out_channels_per_group;

            for n in 0..batch {
                for c_out_g in 0..out_channels_per_group {
                    let c_out = c_out_start + c_out_g;
                    for oh in 0..out_height {
                        for ow in 0..out_width {
                            let mut sum = 0.0f32;

                            for c_in_g in 0..in_channels_per_group {
                                let c_in = c_in_start + c_in_g;
                                for kh in 0..kernel_h {
                                    for kw in 0..kernel_w {
                                        let ih = oh * stride_h + kh * dilation_h;
                                        let iw = ow * stride_w + kw * dilation_w;

                                        if ih >= pad_h
                                            && ih < in_height + pad_h
                                            && iw >= pad_w
                                            && iw < in_width + pad_w
                                        {
                                            let ih_adj = ih - pad_h;
                                            let iw_adj = iw - pad_w;

                                            let in_idx = ((n * in_channels + c_in) * in_height
                                                + ih_adj)
                                                * in_width
                                                + iw_adj;
                                            // Kernel layout: [C_out, C_in/G, KH, KW]
                                            let k_idx = ((c_out * in_channels_per_group + c_in_g)
                                                * kernel_h
                                                + kh)
                                                * kernel_w
                                                + kw;

                                            if in_idx < input_data.len()
                                                && k_idx < kernel_data.len()
                                            {
                                                sum += input_data[in_idx] * kernel_data[k_idx];
                                            }
                                        }
                                    }
                                }
                            }

                            // Add bias
                            if let Some(ref bias) = bias_data {
                                if c_out < bias.len() {
                                    sum += bias[c_out];
                                }
                            }

                            let out_idx =
                                ((n * out_channels + c_out) * out_height + oh) * out_width + ow;
                            if out_idx < output_data.len() {
                                output_data[out_idx] = sum;
                            }
                        }
                    }
                }
            }
        }

        self.write_buffer_f32(output, &output_data)
    }

    fn aspect_aware_matmul(
        &self,
        c: BufferHandle,
        a: BufferHandle,
        b: BufferHandle,
        params: &AspectAwareMatMulParams,
    ) -> Result<(), BackendError> {
        // Only support F32 for now
        if params.base.dtype != Type::F32 {
            return Err(BackendError::unsupported(format!(
                "aspect_aware_matmul only supports F32, got {:?}",
                params.base.dtype
            )));
        }

        let a_data = self.get_buffer_f32(a)?;
        let b_data = self.get_buffer_f32(b)?;
        let mut c_data = self.get_buffer_f32(c)?;

        let m = params.base.m as usize;
        let k = params.base.k as usize;
        let n = params.base.n as usize;
        let alpha = params.base.alpha as f32;
        let beta = params.base.beta as f32;

        // Validate sizes
        if a_data.len() < m * k {
            return Err(BackendError::buffer("A buffer too small for matmul"));
        }
        if b_data.len() < k * n {
            return Err(BackendError::buffer("B buffer too small for matmul"));
        }
        if c_data.len() < m * n {
            return Err(BackendError::buffer("C buffer too small for matmul"));
        }

        // Select tiling strategy based on aspect hint
        // For now, we use the standard SIMD dispatcher, but the hint guides
        // future optimizations for different tile configurations
        match params.aspect_hint {
            GemmAspectHint::SmallBatched => {
                // For small batched operations, fuse across batch dimension
                if let Some(batch_count) = params.batch_count {
                    let batch = batch_count as usize;
                    let a_stride = m * k;
                    let b_stride = k * n;
                    let c_stride = m * n;

                    // Validate batch sizes
                    if a_data.len() < batch * a_stride {
                        return Err(BackendError::buffer("A buffer too small for batch matmul"));
                    }
                    if b_data.len() < batch * b_stride {
                        return Err(BackendError::buffer("B buffer too small for batch matmul"));
                    }
                    if c_data.len() < batch * c_stride {
                        return Err(BackendError::buffer("C buffer too small for batch matmul"));
                    }

                    for i in 0..batch {
                        let a_slice = &a_data[i * a_stride..(i + 1) * a_stride];
                        let b_slice = &b_data[i * b_stride..(i + 1) * b_stride];
                        let c_slice = &mut c_data[i * c_stride..(i + 1) * c_stride];
                        self.simd_dispatcher
                            .matmul_f32(c_slice, a_slice, b_slice, m, k, n, alpha, beta)?;
                    }

                    self.write_buffer_f32(c, &c_data)?;
                    return Ok(());
                }
            }
            GemmAspectHint::TallThin | GemmAspectHint::WideShort | GemmAspectHint::SkinnyK => {
                // These hints can guide tile configuration in future optimizations
                // For now, fall through to standard GEMM
            }
            GemmAspectHint::Balanced => {
                // Standard balanced tiling
            }
        }

        // Standard GEMM dispatch
        self.simd_dispatcher
            .matmul_f32(&mut c_data, &a_data, &b_data, m, k, n, alpha, beta)?;

        self.write_buffer_f32(c, &c_data)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cpu_backend_new() {
        let backend = CpuBackend::new();
        assert_eq!(backend.backend_type(), BackendType::Cpu);
    }

    #[test]
    fn test_allocate_buffer() {
        let backend = CpuBackend::new();
        let handle = backend.allocate_buffer(1024).unwrap();
        assert_eq!(backend.buffer_size(handle).unwrap(), 1024);
    }

    #[test]
    fn test_free_buffer() {
        let backend = CpuBackend::new();
        let handle = backend.allocate_buffer(1024).unwrap();
        assert!(backend.free_buffer(handle).is_ok());
        assert!(backend.buffer_size(handle).is_err());
    }

    #[test]
    fn test_copy_to_buffer() {
        let backend = CpuBackend::new();
        let handle = backend.allocate_buffer(1024).unwrap();
        let data = vec![1u8, 2, 3, 4, 5];
        assert!(backend.copy_to_buffer(handle, &data).is_ok());

        let mut read_data = vec![0u8; 5];
        backend.copy_from_buffer(handle, &mut read_data).unwrap();
        assert_eq!(read_data, data);
    }

    #[test]
    fn test_copy_from_buffer() {
        let backend = CpuBackend::new();
        let handle = backend.allocate_buffer(1024).unwrap();
        let data = vec![10u8, 20, 30];
        backend.copy_to_buffer(handle, &data).unwrap();

        let mut read_data = vec![0u8; 3];
        backend.copy_from_buffer(handle, &mut read_data).unwrap();
        assert_eq!(read_data, data);
    }

    #[test]
    fn test_invalid_handle() {
        let backend = CpuBackend::new();
        let invalid_handle = BufferHandle::new(9999);
        assert!(backend.buffer_size(invalid_handle).is_err());
    }

    #[test]
    fn test_execute_empty_program() {
        let backend = CpuBackend::new();
        let program = Program::default();
        let config = LaunchConfig::default();
        assert!(backend.execute_program(&program, &config).is_ok());
    }

    #[test]
    fn test_fma_scalar_crt_batch() {
        let backend = CpuBackend::new();
        let mut target = vec![0u8; 4];
        let a = vec![1u8, 2, 3, 4];
        backend.fma_scalar_crt_batch(&mut target, &a, 2).unwrap();
        assert_eq!(target, vec![2u8, 4, 6, 8]);
    }

    #[test]
    fn test_vector_add() {
        let backend = CpuBackend::new();
        let a = backend.allocate_buffer(4).unwrap();
        let b = backend.allocate_buffer(4).unwrap();
        let dst = backend.allocate_buffer(4).unwrap();

        backend.copy_to_buffer(a, &[1, 2, 3, 4]).unwrap();
        backend.copy_to_buffer(b, &[10, 20, 30, 40]).unwrap();

        backend.vector_add(dst, a, b, 4).unwrap();

        let mut result = vec![0u8; 4];
        backend.copy_from_buffer(dst, &mut result).unwrap();
        assert_eq!(result, vec![11, 22, 33, 44]);
    }

    #[test]
    fn test_vector_mul() {
        let backend = CpuBackend::new();
        let a = backend.allocate_buffer(4).unwrap();
        let b = backend.allocate_buffer(4).unwrap();
        let dst = backend.allocate_buffer(4).unwrap();

        backend.copy_to_buffer(a, &[2, 3, 4, 5]).unwrap();
        backend.copy_to_buffer(b, &[10, 10, 10, 10]).unwrap();

        backend.vector_mul(dst, a, b, 4).unwrap();

        let mut result = vec![0u8; 4];
        backend.copy_from_buffer(dst, &mut result).unwrap();
        assert_eq!(result, vec![20, 30, 40, 50]);
    }

    #[test]
    fn test_synchronize() {
        let backend = CpuBackend::new();
        assert!(backend.synchronize().is_ok());
    }

    // ========================================================================
    // BUFFER POOL TESTS
    // ========================================================================

    #[test]
    fn test_buffer_pool_basic() {
        let mut pool = BufferPool::new();

        // Get a buffer
        let buf = pool.get(1024);
        assert_eq!(buf.len(), 1024);
        assert!(buf.capacity() >= 1024);

        // Return it
        pool.put(buf);
        assert!(pool.bytes_pooled() > 0);
    }

    #[test]
    fn test_buffer_pool_reuse() {
        let mut pool = BufferPool::new();

        // Get and return a buffer
        let buf = pool.get(1024);
        let original_capacity = buf.capacity();
        pool.put(buf);

        // Get another buffer of same size - should reuse
        let buf2 = pool.get(1024);
        assert_eq!(buf2.capacity(), original_capacity);

        // Pool should be empty now
        assert_eq!(pool.bytes_pooled(), 0);
    }

    #[test]
    fn test_buffer_pool_size_buckets() {
        let mut pool = BufferPool::new();

        // Different sizes go to different buckets
        let buf_small = pool.get(100); // Bucket for 128
        let buf_large = pool.get(1000); // Bucket for 1024

        assert!(buf_small.capacity() >= 100);
        assert!(buf_large.capacity() >= 1000);

        pool.put(buf_small);
        pool.put(buf_large);

        // Requesting 50 should get a buffer with capacity <= 128
        let buf = pool.get(50);
        assert!(buf.capacity() <= 128);
    }

    #[test]
    fn test_buffer_pool_power_of_two() {
        let mut pool = BufferPool::new();

        // Allocations should be power-of-2 capacity
        let buf = pool.get(100);
        assert_eq!(buf.capacity(), 128); // Next power of 2

        let buf2 = pool.get(500);
        assert_eq!(buf2.capacity(), 512); // Next power of 2
    }

    #[test]
    fn test_buffer_pool_zeroed() {
        let mut pool = BufferPool::new();

        // Get a buffer and write data
        let mut buf = pool.get(100);
        buf[0] = 42;
        buf[99] = 123;
        pool.put(buf);

        // Get another buffer - should be zeroed
        let buf2 = pool.get(100);
        assert_eq!(buf2[0], 0);
        assert_eq!(buf2[99], 0);
    }

    #[test]
    fn test_buffer_pool_clear() {
        let mut pool = BufferPool::new();

        let buf1 = pool.get(1024);
        let buf2 = pool.get(2048);
        pool.put(buf1);
        pool.put(buf2);
        assert!(pool.bytes_pooled() > 0);

        pool.clear();
        assert_eq!(pool.bytes_pooled(), 0);
    }

    #[test]
    fn test_buffer_pool_max_capacity() {
        // Create pool with small max
        let mut pool = BufferPool::with_max_bytes(1024);

        // Put a buffer that fits
        let buf = pool.get(512);
        pool.put(buf);
        assert!(pool.bytes_pooled() > 0);

        // Try to put a buffer that would exceed max
        let large_buf = pool.get(2048);
        pool.put(large_buf);
        // Pool should reject it (still under max)
        assert!(pool.bytes_pooled() <= 1024);
    }

    #[test]
    fn test_allocate_free_reuse() {
        let backend = CpuBackend::new();

        // Allocate and free
        let h1 = backend.allocate_buffer(1024).unwrap();
        backend.free_buffer(h1).unwrap();

        // Pool should have the buffer
        assert!(backend.pool_bytes() > 0);

        // Allocate again - should reuse
        let h2 = backend.allocate_buffer(1024).unwrap();
        assert_ne!(h1.id(), h2.id()); // Different handle

        // Pool should be empty now
        assert_eq!(backend.pool_bytes(), 0);

        backend.free_buffer(h2).unwrap();
    }

    // ========================================================================
    // IN-PLACE OPERATION TESTS
    // ========================================================================

    #[test]
    fn test_inplace_vector_add() {
        let backend = CpuBackend::new();
        let a = backend.allocate_buffer(4).unwrap();
        let b = backend.allocate_buffer(4).unwrap();

        backend.copy_to_buffer(a, &[1, 2, 3, 4]).unwrap();
        backend.copy_to_buffer(b, &[10, 20, 30, 40]).unwrap();

        // In-place: a += b (dst == a)
        backend.vector_add(a, a, b, 4).unwrap();

        let mut result = vec![0u8; 4];
        backend.copy_from_buffer(a, &mut result).unwrap();
        assert_eq!(result, vec![11, 22, 33, 44]);
    }

    #[test]
    fn test_inplace_vector_mul() {
        let backend = CpuBackend::new();
        let a = backend.allocate_buffer(4).unwrap();
        let b = backend.allocate_buffer(4).unwrap();

        backend.copy_to_buffer(a, &[2, 3, 4, 5]).unwrap();
        backend.copy_to_buffer(b, &[10, 10, 10, 10]).unwrap();

        // In-place: a *= b (dst == a)
        backend.vector_mul(a, a, b, 4).unwrap();

        let mut result = vec![0u8; 4];
        backend.copy_from_buffer(a, &mut result).unwrap();
        assert_eq!(result, vec![20, 30, 40, 50]);
    }
}
