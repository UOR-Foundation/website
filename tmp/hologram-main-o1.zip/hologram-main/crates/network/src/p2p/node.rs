//! P2P node implementation.
//!
//! This module provides the main P2P node that handles networking and
//! content sharing with other peers.

use super::content_store::{ContentId, ContentStoreError, LocalBlobStore, LocalBlobStoreConfig};
use super::discovery::Discovery;
use super::protocol::{Message, MessageType, PeerId};
use super::transport::TransportError;
use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;
use thiserror::Error;

#[cfg(feature = "async")]
use super::transport::MessageBus;
#[cfg(feature = "async")]
use tokio::sync::RwLock;

/// Error type for node operations.
#[derive(Debug, Error)]
pub enum NodeError {
    /// Failed to bind to address.
    #[error("failed to bind: {0}")]
    BindError(String),

    /// Connection failed.
    #[error("connection failed: {0}")]
    ConnectionError(String),

    /// Channel closed.
    #[error("channel closed")]
    ChannelClosed,

    /// Invalid message.
    #[error("invalid message: {0}")]
    InvalidMessage(String),

    /// Layer not found.
    #[error("layer not found: {0}")]
    LayerNotFound(String),

    /// Content not found.
    #[error("content not found: {0}")]
    ContentNotFound(String),

    /// Transport error.
    #[error("transport error: {0}")]
    Transport(#[from] TransportError),

    /// Request timeout.
    #[error("request timed out")]
    Timeout,

    /// Content store error.
    #[error("content store error: {0}")]
    ContentStore(#[from] ContentStoreError),
}

/// Configuration for a P2P node.
#[derive(Debug, Clone)]
pub struct NodeConfig {
    /// Listen address (default: "0.0.0.0:0" for random port).
    pub listen_addr: String,
    /// Bootstrap peers to connect to.
    pub bootstrap_peers: Vec<String>,
    /// Maximum number of connections.
    pub max_connections: usize,
    /// Enable DHT for peer discovery.
    pub enable_dht: bool,
    /// Local storage path for layers.
    pub storage_path: Option<String>,
    /// Request timeout.
    pub request_timeout: Duration,
    /// Content store configuration (used when storage_path is provided).
    pub content_store_config: Option<LocalBlobStoreConfig>,
}

impl Default for NodeConfig {
    fn default() -> Self {
        Self {
            listen_addr: "0.0.0.0:0".to_string(),
            bootstrap_peers: vec![],
            max_connections: 50,
            enable_dht: true,
            storage_path: None,
            request_timeout: Duration::from_secs(10),
            content_store_config: None,
        }
    }
}

impl NodeConfig {
    /// Create a new configuration with default settings.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Set the listen address.
    #[must_use]
    pub fn listen_addr(mut self, addr: impl Into<String>) -> Self {
        self.listen_addr = addr.into();
        self
    }

    /// Add a bootstrap peer.
    #[must_use]
    pub fn bootstrap_peer(mut self, peer: impl Into<String>) -> Self {
        self.bootstrap_peers.push(peer.into());
        self
    }

    /// Set maximum connections.
    #[must_use]
    pub fn max_connections(mut self, max: usize) -> Self {
        self.max_connections = max;
        self
    }

    /// Set storage path.
    #[must_use]
    pub fn storage_path(mut self, path: impl Into<String>) -> Self {
        self.storage_path = Some(path.into());
        self
    }

    /// Set request timeout.
    #[must_use]
    pub fn request_timeout(mut self, timeout: Duration) -> Self {
        self.request_timeout = timeout;
        self
    }

    /// Set content store configuration.
    #[must_use]
    pub fn content_store_config(mut self, config: LocalBlobStoreConfig) -> Self {
        self.content_store_config = Some(config);
        self
    }
}

/// State of a connected peer.
#[derive(Debug)]
struct PeerState {
    /// Layers this peer has announced.
    layers: Vec<String>,
    /// Last seen timestamp (seconds since epoch).
    last_seen: u64,
}

/// A P2P node in the network.
#[cfg(feature = "async")]
pub struct Node {
    /// Our peer ID.
    peer_id: PeerId,
    /// Node configuration.
    config: NodeConfig,
    /// Connected peers.
    peers: Arc<RwLock<HashMap<PeerId, PeerState>>>,
    /// Local content store.
    content_store: Arc<LocalBlobStore>,
    /// Layer announcements (layer ref list).
    local_layers: Arc<RwLock<Vec<String>>>,
    /// Message bus for transport.
    bus: Arc<MessageBus>,
    /// Discovery service for peer/layer tracking.
    discovery: Arc<Discovery>,
    /// Running state.
    running: Arc<AtomicBool>,
    /// Next sequence number.
    next_seq: AtomicU64,
}

#[cfg(feature = "async")]
impl Node {
    /// Create a new node with the given configuration.
    pub fn new(config: NodeConfig) -> Result<Self, NodeError> {
        Self::with_bus(config, Arc::new(MessageBus::new()))
    }

    /// Create a new node with a specific message bus (useful for testing).
    pub fn with_bus(config: NodeConfig, bus: Arc<MessageBus>) -> Result<Self, NodeError> {
        let peer_id = PeerId::random();

        // Register with the message bus
        let _rx = bus.register(peer_id);

        // Create discovery service
        let discovery = Arc::new(Discovery::new());

        // Create content store
        let content_store = if let Some(store_config) = config.content_store_config.clone() {
            Arc::new(LocalBlobStore::new(store_config)?)
        } else {
            Arc::new(LocalBlobStore::in_memory())
        };

        Ok(Self {
            peer_id,
            config,
            peers: Arc::new(RwLock::new(HashMap::new())),
            content_store,
            local_layers: Arc::new(RwLock::new(Vec::new())),
            bus,
            discovery,
            running: Arc::new(AtomicBool::new(true)),
            next_seq: AtomicU64::new(1),
        })
    }

    /// Get our peer ID.
    #[must_use]
    pub fn peer_id(&self) -> PeerId {
        self.peer_id
    }

    /// Get the node configuration.
    #[must_use]
    pub fn config(&self) -> &NodeConfig {
        &self.config
    }

    /// Get the discovery service.
    #[must_use]
    pub fn discovery(&self) -> &Arc<Discovery> {
        &self.discovery
    }

    /// Get the content store.
    #[must_use]
    pub fn content_store(&self) -> &Arc<LocalBlobStore> {
        &self.content_store
    }

    /// Get the number of connected peers.
    pub async fn peer_count(&self) -> usize {
        self.peers.read().await.len()
    }

    /// Check if the node is running.
    #[must_use]
    pub fn is_running(&self) -> bool {
        self.running.load(Ordering::SeqCst)
    }

    /// Get next sequence number.
    fn next_seq(&self) -> u64 {
        self.next_seq.fetch_add(1, Ordering::SeqCst)
    }

    /// Connect to a peer.
    pub async fn connect(&self, peer_id: PeerId) -> Result<(), NodeError> {
        // Send hello message
        let msg = Message::hello(self.peer_id, self.next_seq());
        self.bus.send(peer_id, msg).await?;

        // Add to discovery
        self.discovery.add_peer(peer_id, None);

        Ok(())
    }

    /// Handle an incoming message.
    pub async fn handle_message(&self, msg: Message) {
        let now = now_secs();

        match msg.msg_type {
            MessageType::ContentRequest => {
                if let Some(req) = msg.parse_content_request() {
                    // Look up content
                    let content_id = ContentId::from_bytes(req.content_id);
                    let response = match self.content_store.get(&content_id) {
                        Ok(data) => Message::content_data(
                            self.peer_id,
                            self.next_seq(),
                            req.request_id,
                            data,
                        ),
                        Err(_) => Message::content_not_found(
                            self.peer_id,
                            self.next_seq(),
                            req.request_id,
                            "Content not found",
                        ),
                    };

                    // Send response back
                    let _ = self.bus.send(msg.source, response).await;
                }
            }
            MessageType::ContentData | MessageType::ContentNotFound => {
                // Response to our request - handled by the request/response correlation
                if let Some(resp) = msg.parse_content_response() {
                    self.bus.respond(resp.request_id, msg);
                }
            }
            MessageType::LayerAnnounce => {
                // Peer is announcing they have a layer
                if let Some(announcement) = msg.parse_layer_announcement() {
                    let layer_ref = announcement.layer_ref;

                    // Update local peer state
                    let mut peers_write = self.peers.write().await;
                    peers_write
                        .entry(msg.source)
                        .and_modify(|state| {
                            if !state.layers.contains(&layer_ref) {
                                state.layers.push(layer_ref.clone());
                            }
                            state.last_seen = now;
                        })
                        .or_insert_with(|| PeerState {
                            layers: vec![layer_ref.clone()],
                            last_seen: now,
                        });
                    drop(peers_write);

                    // Update discovery service with layer provider
                    self.discovery.record_layer_provider(&layer_ref, msg.source);
                }
            }
            MessageType::Hello => {
                // Peer is connecting - send HelloAck
                let response = Message::hello_ack(self.peer_id, self.next_seq());
                let _ = self.bus.send(msg.source, response).await;

                // Add peer to local state
                let mut peers_write = self.peers.write().await;
                peers_write.entry(msg.source).or_insert_with(|| PeerState {
                    layers: vec![],
                    last_seen: now,
                });
                drop(peers_write);

                // Add peer to discovery service
                self.discovery.add_peer(msg.source, None);

                // Send our layer announcements
                let layers = self.local_layers.read().await;
                for layer in layers.iter() {
                    let announce =
                        Message::layer_announce(self.peer_id, self.next_seq(), layer, None, None);
                    let _ = self.bus.send(msg.source, announce).await;
                }
            }
            MessageType::HelloAck => {
                // Connection confirmed
                let mut peers_write = self.peers.write().await;
                peers_write.entry(msg.source).or_insert_with(|| PeerState {
                    layers: vec![],
                    last_seen: now,
                });
                drop(peers_write);

                // Add peer to discovery service
                self.discovery.add_peer(msg.source, None);
            }
            MessageType::Ping => {
                // Respond with pong
                let response = Message::pong(self.peer_id, self.next_seq());
                let _ = self.bus.send(msg.source, response).await;

                // Update last seen
                if let Some(state) = self.peers.write().await.get_mut(&msg.source) {
                    state.last_seen = now;
                }
            }
            MessageType::Pong => {
                // Update last seen
                if let Some(state) = self.peers.write().await.get_mut(&msg.source) {
                    state.last_seen = now;
                }
            }
            _ => {
                // Other messages
            }
        }
    }

    /// Store content locally.
    pub fn store_content(&self, data: &[u8]) -> Result<ContentId, NodeError> {
        self.content_store.put(data).map_err(NodeError::from)
    }

    /// Get content from local store.
    #[must_use]
    pub fn get_local_content(&self, content_id: &ContentId) -> Option<Vec<u8>> {
        self.content_store.get(content_id).ok()
    }

    /// Check if we have content locally.
    #[must_use]
    pub fn has_content(&self, content_id: &ContentId) -> bool {
        self.content_store.contains(content_id)
    }

    /// Request content from a specific peer.
    pub async fn request_content(
        &self,
        peer_id: PeerId,
        content_id: &ContentId,
    ) -> Result<Vec<u8>, NodeError> {
        let request_id = self.bus.next_request_id();
        let msg = Message::content_request(
            self.peer_id,
            self.next_seq(),
            request_id,
            *content_id.as_bytes(),
        );

        // Send request and wait for response
        let response = self
            .bus
            .request(peer_id, msg, self.config.request_timeout)
            .await?;

        // Parse response
        if let Some(resp) = response.parse_content_response() {
            if let Some(data) = resp.data {
                return Ok(data);
            }
            if let Some(error) = resp.error {
                return Err(NodeError::ContentNotFound(error));
            }
        }

        Err(NodeError::InvalidMessage(
            "Invalid content response".to_string(),
        ))
    }

    /// Announce that we have a layer available.
    pub async fn announce_layer(&self, layer_ref: &str) -> Result<(), NodeError> {
        // Add to local layers
        self.local_layers.write().await.push(layer_ref.to_string());

        // Broadcast to all connected peers
        let peers = self.peers.read().await;
        let msg = Message::layer_announce(self.peer_id, self.next_seq(), layer_ref, None, None);

        for &peer_id in peers.keys() {
            let _ = self.bus.send(peer_id, msg.clone()).await;
        }

        Ok(())
    }

    /// Find peers that have a specific layer.
    pub async fn find_layer_providers(&self, layer_ref: &str) -> Vec<PeerId> {
        // First check discovery service
        let from_discovery = self.discovery.find_providers(layer_ref);
        if !from_discovery.is_empty() {
            return from_discovery;
        }

        // Fall back to local peer state
        let peers = self.peers.read().await;
        peers
            .iter()
            .filter(|(_, state)| state.layers.contains(&layer_ref.to_string()))
            .map(|(id, _)| *id)
            .collect()
    }

    /// Get list of layers we have available.
    pub async fn local_layers(&self) -> Vec<String> {
        self.local_layers.read().await.clone()
    }

    /// Shutdown the node.
    pub fn shutdown(&self) {
        self.running.store(false, Ordering::SeqCst);
        self.bus.unregister(&self.peer_id);
    }

    /// Remove stale peers that haven't been seen within the timeout.
    pub async fn remove_stale_peers(&self, timeout_secs: u64) {
        let cutoff = now_secs().saturating_sub(timeout_secs);
        let stale: Vec<PeerId> = {
            let peers = self.peers.read().await;
            peers
                .iter()
                .filter(|(_, state)| state.last_seen < cutoff)
                .map(|(id, _)| *id)
                .collect()
        };

        if !stale.is_empty() {
            let mut peers = self.peers.write().await;
            for peer_id in &stale {
                peers.remove(peer_id);
            }
        }

        // Also clean up discovery
        self.discovery.remove_stale_peers(timeout_secs);
    }
}

/// Synchronous node (without async feature).
#[cfg(not(feature = "async"))]
pub struct Node {
    /// Our peer ID.
    peer_id: PeerId,
    /// Node configuration.
    config: NodeConfig,
    /// Discovery service for peer/layer tracking.
    discovery: Arc<Discovery>,
    /// Running state.
    running: AtomicBool,
}

#[cfg(not(feature = "async"))]
impl Node {
    /// Create a new node with the given configuration.
    #[must_use]
    pub fn new(config: NodeConfig) -> Self {
        Self {
            peer_id: PeerId::random(),
            config,
            discovery: Arc::new(Discovery::new()),
            running: AtomicBool::new(true),
        }
    }

    /// Get our peer ID.
    #[must_use]
    pub fn peer_id(&self) -> PeerId {
        self.peer_id
    }

    /// Get the node configuration.
    #[must_use]
    pub fn config(&self) -> &NodeConfig {
        &self.config
    }

    /// Get the discovery service.
    #[must_use]
    pub fn discovery(&self) -> &Arc<Discovery> {
        &self.discovery
    }

    /// Check if the node is running.
    #[must_use]
    pub fn is_running(&self) -> bool {
        self.running.load(Ordering::SeqCst)
    }

    /// Shutdown the node.
    pub fn shutdown(&self) {
        self.running.store(false, Ordering::SeqCst);
    }
}

/// Get current time in seconds since Unix epoch.
fn now_secs() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_node_config_default() {
        let config = NodeConfig::default();
        assert_eq!(config.listen_addr, "0.0.0.0:0");
        assert!(config.bootstrap_peers.is_empty());
        assert_eq!(config.max_connections, 50);
        assert!(config.enable_dht);
        assert!(config.storage_path.is_none());
        assert_eq!(config.request_timeout, Duration::from_secs(10));
    }

    #[test]
    fn test_node_config_builder() {
        let store_config = LocalBlobStoreConfig::new("/tmp/test").with_max_size(1024 * 1024);
        let config = NodeConfig::new()
            .listen_addr("127.0.0.1:8080")
            .bootstrap_peer("peer1.example.com")
            .bootstrap_peer("peer2.example.com")
            .max_connections(100)
            .storage_path("/tmp/hologram")
            .request_timeout(Duration::from_secs(30))
            .content_store_config(store_config);

        assert_eq!(config.listen_addr, "127.0.0.1:8080");
        assert_eq!(config.bootstrap_peers.len(), 2);
        assert_eq!(config.max_connections, 100);
        assert_eq!(config.storage_path, Some("/tmp/hologram".to_string()));
        assert_eq!(config.request_timeout, Duration::from_secs(30));
        assert!(config.content_store_config.is_some());
    }

    #[test]
    fn test_node_error_display() {
        let err = NodeError::BindError("port in use".to_string());
        assert!(err.to_string().contains("port in use"));

        let err = NodeError::ContentNotFound("abc123".to_string());
        assert!(err.to_string().contains("abc123"));

        let err = NodeError::Timeout;
        assert!(err.to_string().contains("timed out"));
    }

    #[cfg(feature = "async")]
    mod async_tests {
        use super::*;

        #[tokio::test]
        async fn test_node_creation() {
            let config = NodeConfig::default();
            let node = Node::new(config).unwrap();
            assert!(node.is_running());
            assert_eq!(node.peer_count().await, 0);
        }

        #[tokio::test]
        async fn test_node_peer_id() {
            let node = Node::new(NodeConfig::default()).unwrap();
            let peer_id = node.peer_id();
            assert_ne!(peer_id, PeerId::default());
        }

        #[tokio::test]
        async fn test_node_shutdown() {
            let node = Node::new(NodeConfig::default()).unwrap();
            assert!(node.is_running());

            node.shutdown();
            assert!(!node.is_running());
        }

        #[tokio::test]
        async fn test_store_and_get_content() {
            let node = Node::new(NodeConfig::default()).unwrap();
            let data = b"test data";

            let content_id = node.store_content(data).unwrap();
            assert!(node.has_content(&content_id));

            let retrieved = node.get_local_content(&content_id).unwrap();
            assert_eq!(retrieved, data);
        }

        #[tokio::test]
        async fn test_announce_layer() {
            let node = Node::new(NodeConfig::default()).unwrap();
            node.announce_layer("bert/embeddings:v1.0").await.unwrap();

            let layers = node.local_layers().await;
            assert!(layers.contains(&"bert/embeddings:v1.0".to_string()));
        }

        #[tokio::test]
        async fn test_peer_connection() {
            // Test that we can add peers to discovery directly
            let node = Node::new(NodeConfig::default()).unwrap();
            let peer_id = PeerId::random();

            // Discovery should initially be empty (except no bootstrap)
            let initial_peers = node.discovery().known_peers();
            assert!(!initial_peers.contains(&peer_id));

            // Add peer to discovery
            node.discovery()
                .add_peer(peer_id, Some("127.0.0.1:8080".to_string()));

            // Check discovery knows about the peer
            assert!(node.discovery().known_peers().contains(&peer_id));
            assert_eq!(
                node.discovery().peer_address(&peer_id),
                Some("127.0.0.1:8080".to_string())
            );
        }

        #[tokio::test]
        async fn test_local_content_operations() {
            let node = Node::new(NodeConfig::default()).unwrap();

            // Store content
            let data = b"test content for local operations";
            let content_id = node.store_content(data).unwrap();

            // Verify we can retrieve it locally
            assert!(node.has_content(&content_id));
            let retrieved = node.get_local_content(&content_id).unwrap();
            assert_eq!(retrieved, data);

            // Different content gets different ID
            let data2 = b"different content";
            let content_id2 = node.store_content(data2).unwrap();
            assert_ne!(content_id, content_id2);
        }

        #[tokio::test]
        async fn test_find_layer_providers_empty() {
            let node = Node::new(NodeConfig::default()).unwrap();
            let providers = node.find_layer_providers("nonexistent").await;
            assert!(providers.is_empty());
        }
    }
}
