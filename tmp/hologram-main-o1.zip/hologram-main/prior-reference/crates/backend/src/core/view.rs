//! Tensor view wrapper around pre-compiled backend plans.
//!
//! Tensor views allow treating a [`BackendPlan`] as a reusable transformation
//! over buffer handles, analogous to element-wise views in the lookup crate.

use crate::error::BackendResult;
use crate::{BackendPlan, BufferHandle, PlanExecutor, ProgramBackend};

/// A tensor-level view backed by a pre-compiled backend plan.
///
/// This provides a light wrapper so higher-level code can treat plans as
/// reusable "views" without re-deriving layouts or kernels.
pub struct TensorView {
    plan: BackendPlan,
}

impl TensorView {
    /// Create a new tensor view from an existing plan.
    pub fn new(plan: BackendPlan) -> Self {
        Self { plan }
    }

    /// Execute the view using the provided backend and buffers.
    pub fn execute(
        &self,
        inputs: &[BufferHandle],
        outputs: &mut [BufferHandle],
        backend: &mut dyn ProgramBackend,
    ) -> BackendResult<()> {
        let mut executor = PlanExecutor::without_workspace(self.plan.clone());
        executor.execute(inputs, outputs, backend)
    }

    /// Expose the underlying plan (for tooling or inspection).
    pub fn plan(&self) -> &BackendPlan {
        &self.plan
    }
}
