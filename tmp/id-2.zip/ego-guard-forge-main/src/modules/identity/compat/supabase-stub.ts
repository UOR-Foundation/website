/**
 * Supabase Auth Stub — standalone compat layer
 * ═══════════════════════════════════════════════
 *
 * Simulates supabase.auth for standalone identity module dev.
 * On merge: delete this file, import from @/integrations/supabase/client.
 */

type AuthChangeCallback = (
  event: "SIGNED_IN" | "TOKEN_REFRESHED" | "SIGNED_OUT",
  session: { user: { id: string; email: string; user_metadata: Record<string, unknown> } } | null,
) => void;

let _currentUser: { id: string; email: string; user_metadata: Record<string, unknown> } | null = null;
let _listeners: AuthChangeCallback[] = [];

function notifyListeners(event: "SIGNED_IN" | "TOKEN_REFRESHED", user: NonNullable<typeof _currentUser>) {
  for (const cb of _listeners) {
    cb(event, { user });
  }
}

export const supabaseStub = {
  auth: {
    getSession: async () => ({
      data: {
        session: _currentUser ? { user: _currentUser } : null,
      },
    }),

    signInWithOtp: async ({ email }: { email: string; options?: { emailRedirectTo?: string } }) => {
      // Simulate: after 2s, "sign in" the user
      setTimeout(() => {
        _currentUser = {
          id: crypto.randomUUID(),
          email,
          user_metadata: {},
        };
        notifyListeners("SIGNED_IN", _currentUser);
      }, 2000);
      return { error: null };
    },

    onAuthStateChange: (callback: AuthChangeCallback) => {
      _listeners.push(callback);
      return {
        data: {
          subscription: {
            unsubscribe: () => {
              _listeners = _listeners.filter((cb) => cb !== callback);
            },
          },
        },
      };
    },
  },

  from: (_table: string) => ({
    select: (..._cols: string[]) => ({
      eq: (_col: string, _val: string) => ({
        maybeSingle: async () => ({ data: null }),
      }),
    }),
    update: (_data: Record<string, unknown>) => ({
      eq: async (_col: string, _val: string) => ({ error: null }),
    }),
  }),
};

/** Lovable auth stub — simulates Google OAuth redirect */
export const lovableStub = {
  auth: {
    signInWithOAuth: async (_provider: string, _opts?: { redirect_uri?: string }) => {
      // Simulate Google sign-in: after 2s, auto-sign-in
      setTimeout(() => {
        _currentUser = {
          id: crypto.randomUUID(),
          email: "user@example.com",
          user_metadata: { full_name: "UOR User" },
        };
        notifyListeners("SIGNED_IN", _currentUser);
      }, 2000);
      return { error: null };
    },
  },
};
