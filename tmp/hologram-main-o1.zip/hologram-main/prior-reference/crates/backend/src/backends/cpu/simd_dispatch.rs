//! SIMD dispatch for CPU kernels.
//!
//! This module provides runtime SIMD capability detection and dispatch
//! to optimized kernel implementations.
//!
//! # Kernel Design
//!
//! The kernel uses a configurable tiling strategy:
//! - **Micro-kernel**: Small register-blocked computation (e.g., 6x16 for AVX2)
//! - **Macro-tile**: L1/L2 cache-friendly blocks (configurable)
//!
//! Tile sizes are configurable via [`TileConfig`] and can be auto-tuned.
//!
//! # Static Kernel Table
//!
//! SIMD capability is detected once at process start and cached in a static
//! kernel table. This ensures zero per-call overhead for feature detection.
//! Access the global capability via [`CPU_CAPABILITY`] or use the static
//! kernel table via [`CPU_KERNELS`].
//!
//! # Instrumentation
//!
//! When the `instrumentation` feature is enabled, this module records:
//! - `simd_dispatch_avx512` / `simd_dispatch_avx2` / `simd_dispatch_neon` / `simd_dispatch_scalar`:
//!   Counts which SIMD path was taken for each kernel invocation

use crate::BackendError;
use std::sync::OnceLock;

// Import instrumentation macros (no-ops when feature disabled)
#[cfg(feature = "instrumentation")]
use hologram_telemetry::simd_path;

// Provide no-op version when feature is disabled
#[cfg(not(feature = "instrumentation"))]
macro_rules! simd_path {
    ($level:expr) => {};
}

#[cfg(feature = "instrumentation")]
use hologram_telemetry::timed;

#[cfg(not(feature = "instrumentation"))]
macro_rules! timed {
    ($name:expr, $block:expr) => {
        $block
    };
}

#[cfg(target_arch = "x86_64")]
use core::arch::x86_64::*;

#[cfg(target_arch = "aarch64")]
use core::arch::aarch64::*;

// ============================================================================
// STATIC KERNEL TABLE
// ============================================================================

/// Global CPU SIMD capability, detected once at first access.
///
/// This avoids per-call CPUID checks by caching the result of feature detection.
/// The value is computed lazily on first access and never changes thereafter.
pub static CPU_CAPABILITY: OnceLock<SimdCapability> = OnceLock::new();

/// Get the cached CPU SIMD capability.
///
/// On first call, this detects the CPU's SIMD features and caches the result.
/// Subsequent calls return the cached value with no overhead.
pub fn cpu_capability() -> SimdCapability {
    *CPU_CAPABILITY.get_or_init(SimdCapability::detect)
}

/// Static kernel dispatch table.
///
/// Contains function pointers selected based on the detected SIMD capability.
/// This table is initialized once at first access and provides O(1) dispatch
/// with no runtime feature detection overhead.
pub struct CpuKernelTable {
    /// SIMD capability this table was built for.
    pub capability: SimdCapability,
    /// Optimal tile configuration for this capability.
    pub tile_config: TileConfig,
    /// Floats per SIMD register.
    pub floats_per_register: usize,
    /// Bytes per SIMD register.
    pub bytes_per_register: usize,
}

impl CpuKernelTable {
    /// Build the kernel table for the detected SIMD capability.
    fn build() -> Self {
        let capability = cpu_capability();
        let tile_config = match capability {
            SimdCapability::Avx512 => TileConfig::avx512(),
            SimdCapability::Avx2 => TileConfig::avx2(),
            SimdCapability::Neon => TileConfig::neon(),
            SimdCapability::Sse42 => TileConfig::sse42(),
            SimdCapability::Scalar => TileConfig::scalar(),
        };

        Self {
            capability,
            tile_config,
            floats_per_register: capability.floats_per_register(),
            bytes_per_register: capability.bytes_per_register(),
        }
    }

    /// Get the optimal micro-kernel dimensions (MR, NR).
    pub fn micro_kernel_dims(&self) -> (usize, usize) {
        (self.tile_config.mr, self.tile_config.nr)
    }

    /// Get the optimal macro-tile dimensions (MC, NC, KC).
    pub fn macro_tile_dims(&self) -> (usize, usize, usize) {
        (
            self.tile_config.mc,
            self.tile_config.nc,
            self.tile_config.kc,
        )
    }
}

/// Global kernel table, initialized once at first access.
pub static CPU_KERNELS: OnceLock<CpuKernelTable> = OnceLock::new();

/// Get the cached CPU kernel table.
///
/// On first call, this builds the kernel table based on detected SIMD capability.
/// Subsequent calls return the cached table with no overhead.
pub fn cpu_kernels() -> &'static CpuKernelTable {
    CPU_KERNELS.get_or_init(CpuKernelTable::build)
}

// ============================================================================
// TILE CONFIGURATION
// ============================================================================

/// Configuration for matrix multiplication tiling.
///
/// The tiling strategy uses a 3-level hierarchy:
/// 1. **Macro-tile** (MC x NC): Fits in L2 cache
/// 2. **Micro-tile** (MR x NR): Register-blocked micro-kernel
/// 3. **K-tile** (KC): Reduction tile for L1 cache
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TileConfig {
    /// Rows processed per micro-kernel (MR).
    pub mr: usize,
    /// Columns processed per micro-kernel (NR).
    pub nr: usize,
    /// Macro-tile rows (MC), should be multiple of MR.
    pub mc: usize,
    /// Macro-tile columns (NC), should be multiple of NR.
    pub nc: usize,
    /// K-dimension tile (KC) for L1 cache efficiency.
    pub kc: usize,
}

impl TileConfig {
    /// Create a new tile configuration.
    pub const fn new(mr: usize, nr: usize, mc: usize, nc: usize, kc: usize) -> Self {
        Self { mr, nr, mc, nc, kc }
    }

    /// AVX2 optimized configuration (6x16 micro-kernel).
    ///
    /// - MR=6: Process 6 rows at once
    /// - NR=16: 2 YMM registers (8 floats each)
    /// - MC=72: 12 micro-tiles vertically (fits L2)
    /// - NC=256: 16 micro-tiles horizontally
    /// - KC=512: Larger K-tile for better L2 cache utilization on modern CPUs
    pub const fn avx2() -> Self {
        Self::new(6, 16, 72, 256, 512)
    }

    /// AVX-512 optimized configuration (8x32 micro-kernel).
    ///
    /// - MR=8: Process 8 rows at once
    /// - NR=32: 2 ZMM registers (16 floats each)
    /// - MC=96: 12 micro-tiles vertically
    /// - NC=256: 8 micro-tiles horizontally
    /// - KC=384: Balanced K-tile for register pressure vs cache efficiency
    pub const fn avx512() -> Self {
        Self::new(8, 32, 96, 256, 384)
    }

    /// NEON optimized configuration (4x8 micro-kernel).
    ///
    /// - MR=4: Process 4 rows at once
    /// - NR=8: 2 NEON registers (4 floats each)
    /// - MC=64: 16 micro-tiles vertically
    /// - NC=128: 16 micro-tiles horizontally
    /// - KC=512: Larger K-tile for Apple M1/M2's large L1 cache (192KB)
    pub const fn neon() -> Self {
        Self::new(4, 8, 64, 128, 512)
    }

    /// SSE4.2 optimized configuration (4x8 micro-kernel).
    ///
    /// - MR=4: Process 4 rows at once
    /// - NR=8: 2 XMM registers (4 floats each)
    /// - MC=64: 16 micro-tiles vertically
    /// - NC=128: 16 micro-tiles horizontally
    /// - KC=256: Reduction tile for L1 cache
    pub const fn sse42() -> Self {
        Self::new(4, 8, 64, 128, 256)
    }

    /// Scalar fallback configuration (1x4 micro-kernel).
    pub const fn scalar() -> Self {
        Self::new(1, 4, 64, 64, 256)
    }

    /// Small matrix configuration (for sizes < 32).
    pub const fn small() -> Self {
        Self::new(2, 4, 32, 32, 32)
    }

    /// Select optimal tile configuration based on matrix dimensions.
    ///
    /// Uses aspect-ratio heuristics to optimize for different matrix shapes:
    /// - Tall-thin (m >> n): Increase MC, decrease NC for better A-panel reuse
    /// - Wide-short (n >> m): Decrease MC, increase NC for better B-panel reuse
    /// - Balanced: Use standard configuration
    pub fn auto_select(m: usize, k: usize, n: usize, simd: SimdCapability) -> Self {
        const L2_TARGET_BYTES: usize = 256 * 1024; // Aim to keep B-panel within L2

        // Select base config based on SIMD capability
        // The micro-kernel dimensions (MR, NR) must match the SIMD implementation
        let base = match simd {
            SimdCapability::Avx512 => Self::avx512(),
            SimdCapability::Avx2 => Self::avx2(),
            SimdCapability::Neon => Self::neon(),
            SimdCapability::Sse42 => Self::sse42(),
            SimdCapability::Scalar => Self::scalar(),
        };

        // For very small matrices, reduce macro-tile sizes but keep micro-kernel sizes
        // The micro-kernel (MR x NR) must match the SIMD implementation
        let (mc, nc, kc) = if m * n < 256 || k < 32 {
            // Small matrix: use minimal macro-tiles
            let mc = base.mr.max(m.min(base.mc));
            let nc = base.nr.max(n.min(base.nc));
            let kc = k.clamp(1, 32); // Ensure kc >= 1 to avoid step_by(0) panic
            (mc, nc, kc)
        } else if m > 4 * n && m >= 256 {
            // Tall-thin matrix: increase MC for better A-panel reuse
            // More rows in A-panel means each B-panel is used more times
            let mc = (base.mc * 2).min(m);
            let nc = (base.nc / 2).max(base.nr);
            let kc = k.clamp(1, base.kc);
            (mc, nc, kc)
        } else if n > 4 * m && n >= 256 {
            // Wide-short matrix: increase NC for better B-panel reuse
            // More columns in B-panel means each A-panel is used more times
            let mc = (base.mc / 2).max(base.mr);
            let nc = (base.nc * 2).min(n);
            let kc = k.clamp(1, base.kc);
            (mc, nc, kc)
        } else {
            // Balanced matrix: use standard macro-tiles
            let mc = base.mc.min(m);
            let nc = base.nc.min(n);
            let kc = k.clamp(1, base.kc); // Ensure kc >= 1 to avoid step_by(0) panic
            (mc, nc, kc)
        };

        // Keep the B panel (kc * nr floats) inside an L2-sized budget.
        let l2_bound_kc = L2_TARGET_BYTES
            .checked_div(base.nr.max(1) * core::mem::size_of::<f32>())
            .unwrap_or(base.kc)
            .max(base.nr); // keep multiples of NR for packing
        let kc = kc.min(l2_bound_kc);

        Self {
            mr: base.mr,
            nr: base.nr,
            mc: (mc / base.mr).max(1) * base.mr,
            nc: (nc / base.nr).max(1) * base.nr,
            kc,
        }
    }

    /// Validate the configuration.
    pub const fn is_valid(&self) -> bool {
        self.mr > 0
            && self.nr > 0
            && self.mc >= self.mr
            && self.nc >= self.nr
            && self.kc > 0
            && self.mc.is_multiple_of(self.mr)
            && self.nc.is_multiple_of(self.nr)
    }
}

// ============================================================================
// SIMD CAPABILITY DETECTION
// ============================================================================

/// SIMD capability levels.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum SimdCapability {
    /// No SIMD, scalar fallback.
    Scalar,
    /// SSE4.2 (128-bit vectors).
    Sse42,
    /// AVX2 (256-bit vectors).
    Avx2,
    /// AVX-512 (512-bit vectors).
    Avx512,
    /// ARM NEON (128-bit vectors).
    Neon,
}

impl SimdCapability {
    /// Detect the best available SIMD capability.
    #[cfg(target_arch = "x86_64")]
    pub fn detect() -> Self {
        if is_x86_feature_detected!("avx512f") {
            Self::Avx512
        } else if is_x86_feature_detected!("avx2") {
            Self::Avx2
        } else if is_x86_feature_detected!("sse4.2") {
            Self::Sse42
        } else {
            Self::Scalar
        }
    }

    /// Detect the best available SIMD capability.
    #[cfg(target_arch = "aarch64")]
    pub fn detect() -> Self {
        // NEON is always available on aarch64
        Self::Neon
    }

    /// Detect the best available SIMD capability.
    #[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
    pub fn detect() -> Self {
        Self::Scalar
    }

    /// Number of f32 elements per SIMD register.
    pub const fn floats_per_register(self) -> usize {
        match self {
            Self::Scalar => 1,
            Self::Sse42 | Self::Neon => 4,
            Self::Avx2 => 8,
            Self::Avx512 => 16,
        }
    }

    /// Number of bytes per SIMD register.
    pub const fn bytes_per_register(self) -> usize {
        match self {
            Self::Scalar => 4,
            Self::Sse42 | Self::Neon => 16,
            Self::Avx2 => 32,
            Self::Avx512 => 64,
        }
    }
}

// ============================================================================
// SIMD DISPATCHER
// ============================================================================

/// SIMD dispatcher for CPU kernels.
///
/// Routes operations to the best available SIMD implementation.
#[derive(Clone, Copy)]
pub struct SimdDispatcher {
    capability: SimdCapability,
}

impl SimdDispatcher {
    /// Create a new dispatcher with auto-detected capability.
    pub fn new() -> Self {
        Self {
            capability: SimdCapability::detect(),
        }
    }

    /// Create a dispatcher with a specific capability.
    pub fn with_capability(capability: SimdCapability) -> Self {
        Self { capability }
    }

    /// Get the current SIMD capability.
    pub fn capability(&self) -> SimdCapability {
        self.capability
    }

    // ========================================================================
    // MATRIX MULTIPLICATION KERNELS
    // ========================================================================

    /// Matrix multiplication: C = alpha * A @ B + beta * C
    ///
    /// Dispatches to the best available SIMD implementation with automatic
    /// tile size selection based on matrix dimensions and SIMD capability.
    #[allow(clippy::too_many_arguments)]
    pub fn matmul_f32(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        m: usize,
        k: usize,
        n: usize,
        alpha: f32,
        beta: f32,
    ) -> Result<(), BackendError> {
        // Empty matrix: nothing to compute (standard GEMM semantics)
        if m == 0 || k == 0 || n == 0 {
            return Ok(());
        }

        // Validate sizes
        if a.len() < m * k {
            return Err(BackendError::buffer("A buffer too small for matmul"));
        }
        if b.len() < k * n {
            return Err(BackendError::buffer("B buffer too small for matmul"));
        }
        if c.len() < m * n {
            return Err(BackendError::buffer("C buffer too small for matmul"));
        }

        // Auto-select tile configuration
        let tile = TileConfig::auto_select(m, k, n, self.capability);
        debug_assert!(tile.is_valid(), "Invalid tile config: {:?}", tile);

        self.matmul_f32_tiled(c, a, b, m, k, n, alpha, beta, &tile)
    }

    /// Matrix multiplication with explicit tile configuration.
    #[allow(clippy::too_many_arguments)]
    pub fn matmul_f32_with_config(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        m: usize,
        k: usize,
        n: usize,
        alpha: f32,
        beta: f32,
        tile: &TileConfig,
    ) -> Result<(), BackendError> {
        // Validate sizes
        if a.len() < m * k {
            return Err(BackendError::buffer("A buffer too small for matmul"));
        }
        if b.len() < k * n {
            return Err(BackendError::buffer("B buffer too small for matmul"));
        }
        if c.len() < m * n {
            return Err(BackendError::buffer("C buffer too small for matmul"));
        }

        self.matmul_f32_tiled(c, a, b, m, k, n, alpha, beta, tile)
    }

    /// Tiled matrix multiplication dispatcher.
    #[allow(clippy::too_many_arguments)]
    fn matmul_f32_tiled(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        m: usize,
        k: usize,
        n: usize,
        alpha: f32,
        beta: f32,
        tile: &TileConfig,
    ) -> Result<(), BackendError> {
        const PARALLEL_MIN_ROWS: usize = 128;
        const PARALLEL_MIN_WORK: usize = 256 * 256 * 64; // Roughly 4e6 mul-adds
        let work = m.saturating_mul(n).saturating_mul(k);
        let use_parallel =
            cfg!(feature = "parallel") && m >= PARALLEL_MIN_ROWS && work >= PARALLEL_MIN_WORK;

        if use_parallel {
            #[cfg(feature = "parallel")]
            {
                return timed!("cpu_matmul_parallel_ms", {
                    self.matmul_f32_tiled_parallel(c, a, b, m, k, n, alpha, beta, tile)
                });
            }
        }

        self.matmul_f32_tiled_sequential(c, a, b, m, k, n, alpha, beta, tile)
    }

    #[cfg(feature = "parallel")]
    #[allow(clippy::too_many_arguments)]
    fn matmul_f32_tiled_parallel(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        m: usize,
        k: usize,
        n: usize,
        alpha: f32,
        beta: f32,
        tile: &TileConfig,
    ) -> Result<(), BackendError> {
        use rayon::prelude::*;

        // Scale C once before sharding so each worker can assume beta=1.
        if beta != 1.0 {
            for val in c.iter_mut().take(m * n) {
                *val *= beta;
            }
        }

        // Keep shards reasonably sized to balance cache reuse and overhead.
        let rows_per_chunk = tile.mc.max(tile.mr * 2).min(m.max(tile.mr)).max(tile.mr);
        let dispatcher = *self;
        let tile_copy = *tile;
        let stride_c = rows_per_chunk * n;

        c.par_chunks_mut(stride_c)
            .enumerate()
            .try_for_each(|(chunk_idx, c_chunk)| {
                let row_start = chunk_idx * rows_per_chunk;
                if row_start >= m {
                    return Ok(());
                }
                let rows = rows_per_chunk.min(m - row_start);
                let a_start = row_start * k;
                let a_end = a_start + rows * k;
                let a_chunk = &a[a_start..a_end];
                let c_rows = &mut c_chunk[..rows * n];

                dispatcher.matmul_f32_tiled_sequential(
                    c_rows, a_chunk, b, rows, k, n, alpha, 1.0, // Already applied beta
                    &tile_copy,
                )
            })
    }

    #[allow(clippy::too_many_arguments)]
    fn matmul_f32_tiled_sequential(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        m: usize,
        k: usize,
        n: usize,
        alpha: f32,
        beta: f32,
        tile: &TileConfig,
    ) -> Result<(), BackendError> {
        // Apply beta scaling to C first
        if beta != 1.0 {
            for val in c.iter_mut().take(m * n) {
                *val *= beta;
            }
        }

        // Dispatch based on capability
        match self.capability {
            #[cfg(target_arch = "x86_64")]
            SimdCapability::Avx512 => {
                simd_path!("avx512");
                // SAFETY: AVX-512 is detected at runtime
                unsafe { self.matmul_f32_avx512(c, a, b, m, k, n, alpha, tile) }
            }
            #[cfg(target_arch = "x86_64")]
            SimdCapability::Avx2 => {
                simd_path!("avx2");
                // SAFETY: AVX2 is detected at runtime
                unsafe { self.matmul_f32_avx2(c, a, b, m, k, n, alpha, tile) }
            }
            #[cfg(target_arch = "aarch64")]
            SimdCapability::Neon => {
                simd_path!("neon");
                // SAFETY: NEON is always available on aarch64
                unsafe { self.matmul_f32_neon(c, a, b, m, k, n, alpha, tile) }
            }
            _ => {
                simd_path!("scalar");
                self.matmul_f32_scalar(c, a, b, m, k, n, alpha, tile)
            }
        }
    }

    /// Scalar fallback for matrix multiplication with tiling.
    #[allow(clippy::too_many_arguments)]
    fn matmul_f32_scalar(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        m: usize,
        k: usize,
        n: usize,
        alpha: f32,
        tile: &TileConfig,
    ) -> Result<(), BackendError> {
        let mc = tile.mc.min(m);
        let nc = tile.nc.min(n);
        let kc = tile.kc.min(k);

        // Macro-tile loop
        for i0 in (0..m).step_by(mc) {
            let i_end = (i0 + mc).min(m);
            for j0 in (0..n).step_by(nc) {
                let j_end = (j0 + nc).min(n);
                for k0 in (0..k).step_by(kc) {
                    let k_end = (k0 + kc).min(k);

                    // Micro-kernel: MR x NR blocks
                    for i in i0..i_end {
                        for j in j0..j_end {
                            let mut sum = 0.0f32;
                            for ki in k0..k_end {
                                sum += a[i * k + ki] * b[ki * n + j];
                            }
                            c[i * n + j] += alpha * sum;
                        }
                    }
                }
            }
        }
        Ok(())
    }

    /// AVX2 optimized matrix multiplication.
    ///
    /// Uses configurable micro-kernel with FMA instructions.
    #[cfg(target_arch = "x86_64")]
    #[target_feature(enable = "avx2", enable = "fma")]
    #[allow(clippy::too_many_arguments)]
    unsafe fn matmul_f32_avx2(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        m: usize,
        k: usize,
        n: usize,
        alpha: f32,
        tile: &TileConfig,
    ) -> Result<(), BackendError> {
        let mr = tile.mr;
        let nr = tile.nr;
        let mc = tile.mc.min(m);
        let nc = tile.nc.min(n);
        let kc = tile.kc.min(k);

        let alpha_vec = _mm256_set1_ps(alpha);

        // Macro-tile loop over C
        for i0 in (0..m).step_by(mc) {
            let i_end = (i0 + mc).min(m);
            for j0 in (0..n).step_by(nc) {
                let j_end = (j0 + nc).min(n);

                // K-tile loop
                for k0 in (0..k).step_by(kc) {
                    let k_end = (k0 + kc).min(k);

                    // Micro-tile loop: process MR rows x NR columns
                    let mut i = i0;
                    while i + mr <= i_end {
                        let mut j = j0;
                        while j + nr <= j_end {
                            // 6x16 micro-kernel (or configured size)
                            self.microkernel_avx2_6x16(c, a, b, i, j, k0, k_end, k, n, alpha_vec);
                            j += nr;
                        }
                        // Handle remaining columns
                        while j < j_end {
                            for ii in i..i + mr {
                                let mut sum = 0.0f32;
                                for ki in k0..k_end {
                                    sum += a[ii * k + ki] * b[ki * n + j];
                                }
                                c[ii * n + j] += alpha * sum;
                            }
                            j += 1;
                        }
                        i += mr;
                    }
                    // Handle remaining rows
                    while i < i_end {
                        for j in j0..j_end {
                            let mut sum = 0.0f32;
                            for ki in k0..k_end {
                                sum += a[i * k + ki] * b[ki * n + j];
                            }
                            c[i * n + j] += alpha * sum;
                        }
                        i += 1;
                    }
                }
            }
        }
        Ok(())
    }

    /// AVX2 6x16 micro-kernel using FMA.
    ///
    /// Processes 6 rows × 16 columns using 12 YMM registers for accumulators.
    #[cfg(target_arch = "x86_64")]
    #[target_feature(enable = "avx2", enable = "fma")]
    #[allow(clippy::too_many_arguments)]
    unsafe fn microkernel_avx2_6x16(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        i: usize,
        j: usize,
        k0: usize,
        k_end: usize,
        k: usize,
        n: usize,
        alpha: __m256,
    ) {
        // 12 accumulators: 6 rows × 2 YMM registers (16 floats)
        let mut c00 = _mm256_setzero_ps();
        let mut c01 = _mm256_setzero_ps();
        let mut c10 = _mm256_setzero_ps();
        let mut c11 = _mm256_setzero_ps();
        let mut c20 = _mm256_setzero_ps();
        let mut c21 = _mm256_setzero_ps();
        let mut c30 = _mm256_setzero_ps();
        let mut c31 = _mm256_setzero_ps();
        let mut c40 = _mm256_setzero_ps();
        let mut c41 = _mm256_setzero_ps();
        let mut c50 = _mm256_setzero_ps();
        let mut c51 = _mm256_setzero_ps();

        // Reduction loop
        for ki in k0..k_end {
            // Load B row (16 floats = 2 YMM registers)
            let b_ptr = b.as_ptr().add(ki * n + j);
            let b0 = _mm256_loadu_ps(b_ptr);
            let b1 = _mm256_loadu_ps(b_ptr.add(8));

            // Broadcast each A element and FMA
            let a0 = _mm256_set1_ps(*a.get_unchecked(i * k + ki));
            c00 = _mm256_fmadd_ps(a0, b0, c00);
            c01 = _mm256_fmadd_ps(a0, b1, c01);

            let a1 = _mm256_set1_ps(*a.get_unchecked((i + 1) * k + ki));
            c10 = _mm256_fmadd_ps(a1, b0, c10);
            c11 = _mm256_fmadd_ps(a1, b1, c11);

            let a2 = _mm256_set1_ps(*a.get_unchecked((i + 2) * k + ki));
            c20 = _mm256_fmadd_ps(a2, b0, c20);
            c21 = _mm256_fmadd_ps(a2, b1, c21);

            let a3 = _mm256_set1_ps(*a.get_unchecked((i + 3) * k + ki));
            c30 = _mm256_fmadd_ps(a3, b0, c30);
            c31 = _mm256_fmadd_ps(a3, b1, c31);

            let a4 = _mm256_set1_ps(*a.get_unchecked((i + 4) * k + ki));
            c40 = _mm256_fmadd_ps(a4, b0, c40);
            c41 = _mm256_fmadd_ps(a4, b1, c41);

            let a5 = _mm256_set1_ps(*a.get_unchecked((i + 5) * k + ki));
            c50 = _mm256_fmadd_ps(a5, b0, c50);
            c51 = _mm256_fmadd_ps(a5, b1, c51);
        }

        // Scale by alpha and accumulate to C
        let c_ptr = c.as_mut_ptr();

        // Row 0
        let c0_ptr = c_ptr.add(i * n + j);
        let old0 = _mm256_loadu_ps(c0_ptr);
        let old1 = _mm256_loadu_ps(c0_ptr.add(8));
        _mm256_storeu_ps(c0_ptr, _mm256_fmadd_ps(alpha, c00, old0));
        _mm256_storeu_ps(c0_ptr.add(8), _mm256_fmadd_ps(alpha, c01, old1));

        // Row 1
        let c1_ptr = c_ptr.add((i + 1) * n + j);
        let old0 = _mm256_loadu_ps(c1_ptr);
        let old1 = _mm256_loadu_ps(c1_ptr.add(8));
        _mm256_storeu_ps(c1_ptr, _mm256_fmadd_ps(alpha, c10, old0));
        _mm256_storeu_ps(c1_ptr.add(8), _mm256_fmadd_ps(alpha, c11, old1));

        // Row 2
        let c2_ptr = c_ptr.add((i + 2) * n + j);
        let old0 = _mm256_loadu_ps(c2_ptr);
        let old1 = _mm256_loadu_ps(c2_ptr.add(8));
        _mm256_storeu_ps(c2_ptr, _mm256_fmadd_ps(alpha, c20, old0));
        _mm256_storeu_ps(c2_ptr.add(8), _mm256_fmadd_ps(alpha, c21, old1));

        // Row 3
        let c3_ptr = c_ptr.add((i + 3) * n + j);
        let old0 = _mm256_loadu_ps(c3_ptr);
        let old1 = _mm256_loadu_ps(c3_ptr.add(8));
        _mm256_storeu_ps(c3_ptr, _mm256_fmadd_ps(alpha, c30, old0));
        _mm256_storeu_ps(c3_ptr.add(8), _mm256_fmadd_ps(alpha, c31, old1));

        // Row 4
        let c4_ptr = c_ptr.add((i + 4) * n + j);
        let old0 = _mm256_loadu_ps(c4_ptr);
        let old1 = _mm256_loadu_ps(c4_ptr.add(8));
        _mm256_storeu_ps(c4_ptr, _mm256_fmadd_ps(alpha, c40, old0));
        _mm256_storeu_ps(c4_ptr.add(8), _mm256_fmadd_ps(alpha, c41, old1));

        // Row 5
        let c5_ptr = c_ptr.add((i + 5) * n + j);
        let old0 = _mm256_loadu_ps(c5_ptr);
        let old1 = _mm256_loadu_ps(c5_ptr.add(8));
        _mm256_storeu_ps(c5_ptr, _mm256_fmadd_ps(alpha, c50, old0));
        _mm256_storeu_ps(c5_ptr.add(8), _mm256_fmadd_ps(alpha, c51, old1));
    }

    /// AVX-512 optimized matrix multiplication.
    ///
    /// Uses 8x32 micro-kernel with FMA instructions (16 floats per ZMM register).
    #[cfg(target_arch = "x86_64")]
    #[target_feature(enable = "avx512f")]
    #[allow(clippy::too_many_arguments)]
    unsafe fn matmul_f32_avx512(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        m: usize,
        k: usize,
        n: usize,
        alpha: f32,
        tile: &TileConfig,
    ) -> Result<(), BackendError> {
        let mr = tile.mr;
        let nr = tile.nr;
        let mc = tile.mc.min(m);
        let nc = tile.nc.min(n);
        let kc = tile.kc.min(k);

        let alpha_vec = _mm512_set1_ps(alpha);

        // Macro-tile loop over C
        for i0 in (0..m).step_by(mc) {
            let i_end = (i0 + mc).min(m);
            for j0 in (0..n).step_by(nc) {
                let j_end = (j0 + nc).min(n);

                // K-tile loop
                for k0 in (0..k).step_by(kc) {
                    let k_end = (k0 + kc).min(k);

                    // Micro-tile loop: process MR rows x NR columns
                    let mut i = i0;
                    while i + mr <= i_end {
                        let mut j = j0;
                        while j + nr <= j_end {
                            // 8x32 micro-kernel (or configured size)
                            self.microkernel_avx512_8x32(c, a, b, i, j, k0, k_end, k, n, alpha_vec);
                            j += nr;
                        }
                        // Handle remaining columns with AVX2 (16-wide) or scalar
                        while j + 16 <= j_end {
                            self.microkernel_avx512_8x16(c, a, b, i, j, k0, k_end, k, n, alpha_vec);
                            j += 16;
                        }
                        while j < j_end {
                            for ii in i..i + mr.min(i_end - i) {
                                let mut sum = 0.0f32;
                                for ki in k0..k_end {
                                    sum += a[ii * k + ki] * b[ki * n + j];
                                }
                                c[ii * n + j] += alpha * sum;
                            }
                            j += 1;
                        }
                        i += mr;
                    }
                    // Handle remaining rows with scalar
                    while i < i_end {
                        for j in j0..j_end {
                            let mut sum = 0.0f32;
                            for ki in k0..k_end {
                                sum += a[i * k + ki] * b[ki * n + j];
                            }
                            c[i * n + j] += alpha * sum;
                        }
                        i += 1;
                    }
                }
            }
        }
        Ok(())
    }

    /// AVX-512 8x32 micro-kernel using FMA.
    ///
    /// Processes 8 rows × 32 columns using 16 ZMM registers for accumulators.
    #[cfg(target_arch = "x86_64")]
    #[target_feature(enable = "avx512f")]
    #[allow(clippy::too_many_arguments)]
    unsafe fn microkernel_avx512_8x32(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        i: usize,
        j: usize,
        k0: usize,
        k_end: usize,
        k: usize,
        n: usize,
        alpha: __m512,
    ) {
        // 16 accumulators: 8 rows × 2 ZMM registers (32 floats)
        let mut c00 = _mm512_setzero_ps();
        let mut c01 = _mm512_setzero_ps();
        let mut c10 = _mm512_setzero_ps();
        let mut c11 = _mm512_setzero_ps();
        let mut c20 = _mm512_setzero_ps();
        let mut c21 = _mm512_setzero_ps();
        let mut c30 = _mm512_setzero_ps();
        let mut c31 = _mm512_setzero_ps();
        let mut c40 = _mm512_setzero_ps();
        let mut c41 = _mm512_setzero_ps();
        let mut c50 = _mm512_setzero_ps();
        let mut c51 = _mm512_setzero_ps();
        let mut c60 = _mm512_setzero_ps();
        let mut c61 = _mm512_setzero_ps();
        let mut c70 = _mm512_setzero_ps();
        let mut c71 = _mm512_setzero_ps();

        // Reduction loop
        for ki in k0..k_end {
            // Load B row (32 floats = 2 ZMM registers)
            let b_ptr = b.as_ptr().add(ki * n + j);
            let b0 = _mm512_loadu_ps(b_ptr);
            let b1 = _mm512_loadu_ps(b_ptr.add(16));

            // Broadcast each A element and FMA
            let a0 = _mm512_set1_ps(*a.get_unchecked(i * k + ki));
            c00 = _mm512_fmadd_ps(a0, b0, c00);
            c01 = _mm512_fmadd_ps(a0, b1, c01);

            let a1 = _mm512_set1_ps(*a.get_unchecked((i + 1) * k + ki));
            c10 = _mm512_fmadd_ps(a1, b0, c10);
            c11 = _mm512_fmadd_ps(a1, b1, c11);

            let a2 = _mm512_set1_ps(*a.get_unchecked((i + 2) * k + ki));
            c20 = _mm512_fmadd_ps(a2, b0, c20);
            c21 = _mm512_fmadd_ps(a2, b1, c21);

            let a3 = _mm512_set1_ps(*a.get_unchecked((i + 3) * k + ki));
            c30 = _mm512_fmadd_ps(a3, b0, c30);
            c31 = _mm512_fmadd_ps(a3, b1, c31);

            let a4 = _mm512_set1_ps(*a.get_unchecked((i + 4) * k + ki));
            c40 = _mm512_fmadd_ps(a4, b0, c40);
            c41 = _mm512_fmadd_ps(a4, b1, c41);

            let a5 = _mm512_set1_ps(*a.get_unchecked((i + 5) * k + ki));
            c50 = _mm512_fmadd_ps(a5, b0, c50);
            c51 = _mm512_fmadd_ps(a5, b1, c51);

            let a6 = _mm512_set1_ps(*a.get_unchecked((i + 6) * k + ki));
            c60 = _mm512_fmadd_ps(a6, b0, c60);
            c61 = _mm512_fmadd_ps(a6, b1, c61);

            let a7 = _mm512_set1_ps(*a.get_unchecked((i + 7) * k + ki));
            c70 = _mm512_fmadd_ps(a7, b0, c70);
            c71 = _mm512_fmadd_ps(a7, b1, c71);
        }

        // Scale by alpha and accumulate to C
        let c_ptr = c.as_mut_ptr();

        // Row 0
        let c0_ptr = c_ptr.add(i * n + j);
        let old0 = _mm512_loadu_ps(c0_ptr);
        let old1 = _mm512_loadu_ps(c0_ptr.add(16));
        _mm512_storeu_ps(c0_ptr, _mm512_fmadd_ps(alpha, c00, old0));
        _mm512_storeu_ps(c0_ptr.add(16), _mm512_fmadd_ps(alpha, c01, old1));

        // Row 1
        let c1_ptr = c_ptr.add((i + 1) * n + j);
        let old0 = _mm512_loadu_ps(c1_ptr);
        let old1 = _mm512_loadu_ps(c1_ptr.add(16));
        _mm512_storeu_ps(c1_ptr, _mm512_fmadd_ps(alpha, c10, old0));
        _mm512_storeu_ps(c1_ptr.add(16), _mm512_fmadd_ps(alpha, c11, old1));

        // Row 2
        let c2_ptr = c_ptr.add((i + 2) * n + j);
        let old0 = _mm512_loadu_ps(c2_ptr);
        let old1 = _mm512_loadu_ps(c2_ptr.add(16));
        _mm512_storeu_ps(c2_ptr, _mm512_fmadd_ps(alpha, c20, old0));
        _mm512_storeu_ps(c2_ptr.add(16), _mm512_fmadd_ps(alpha, c21, old1));

        // Row 3
        let c3_ptr = c_ptr.add((i + 3) * n + j);
        let old0 = _mm512_loadu_ps(c3_ptr);
        let old1 = _mm512_loadu_ps(c3_ptr.add(16));
        _mm512_storeu_ps(c3_ptr, _mm512_fmadd_ps(alpha, c30, old0));
        _mm512_storeu_ps(c3_ptr.add(16), _mm512_fmadd_ps(alpha, c31, old1));

        // Row 4
        let c4_ptr = c_ptr.add((i + 4) * n + j);
        let old0 = _mm512_loadu_ps(c4_ptr);
        let old1 = _mm512_loadu_ps(c4_ptr.add(16));
        _mm512_storeu_ps(c4_ptr, _mm512_fmadd_ps(alpha, c40, old0));
        _mm512_storeu_ps(c4_ptr.add(16), _mm512_fmadd_ps(alpha, c41, old1));

        // Row 5
        let c5_ptr = c_ptr.add((i + 5) * n + j);
        let old0 = _mm512_loadu_ps(c5_ptr);
        let old1 = _mm512_loadu_ps(c5_ptr.add(16));
        _mm512_storeu_ps(c5_ptr, _mm512_fmadd_ps(alpha, c50, old0));
        _mm512_storeu_ps(c5_ptr.add(16), _mm512_fmadd_ps(alpha, c51, old1));

        // Row 6
        let c6_ptr = c_ptr.add((i + 6) * n + j);
        let old0 = _mm512_loadu_ps(c6_ptr);
        let old1 = _mm512_loadu_ps(c6_ptr.add(16));
        _mm512_storeu_ps(c6_ptr, _mm512_fmadd_ps(alpha, c60, old0));
        _mm512_storeu_ps(c6_ptr.add(16), _mm512_fmadd_ps(alpha, c61, old1));

        // Row 7
        let c7_ptr = c_ptr.add((i + 7) * n + j);
        let old0 = _mm512_loadu_ps(c7_ptr);
        let old1 = _mm512_loadu_ps(c7_ptr.add(16));
        _mm512_storeu_ps(c7_ptr, _mm512_fmadd_ps(alpha, c70, old0));
        _mm512_storeu_ps(c7_ptr.add(16), _mm512_fmadd_ps(alpha, c71, old1));
    }

    /// AVX-512 8x16 micro-kernel for edge cases.
    ///
    /// Processes 8 rows × 16 columns using 8 ZMM registers.
    #[cfg(target_arch = "x86_64")]
    #[target_feature(enable = "avx512f")]
    #[allow(clippy::too_many_arguments)]
    unsafe fn microkernel_avx512_8x16(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        i: usize,
        j: usize,
        k0: usize,
        k_end: usize,
        k: usize,
        n: usize,
        alpha: __m512,
    ) {
        let mut c0 = _mm512_setzero_ps();
        let mut c1 = _mm512_setzero_ps();
        let mut c2 = _mm512_setzero_ps();
        let mut c3 = _mm512_setzero_ps();
        let mut c4 = _mm512_setzero_ps();
        let mut c5 = _mm512_setzero_ps();
        let mut c6 = _mm512_setzero_ps();
        let mut c7 = _mm512_setzero_ps();

        for ki in k0..k_end {
            let b_ptr = b.as_ptr().add(ki * n + j);
            let b0 = _mm512_loadu_ps(b_ptr);

            let a0 = _mm512_set1_ps(*a.get_unchecked(i * k + ki));
            c0 = _mm512_fmadd_ps(a0, b0, c0);

            let a1 = _mm512_set1_ps(*a.get_unchecked((i + 1) * k + ki));
            c1 = _mm512_fmadd_ps(a1, b0, c1);

            let a2 = _mm512_set1_ps(*a.get_unchecked((i + 2) * k + ki));
            c2 = _mm512_fmadd_ps(a2, b0, c2);

            let a3 = _mm512_set1_ps(*a.get_unchecked((i + 3) * k + ki));
            c3 = _mm512_fmadd_ps(a3, b0, c3);

            let a4 = _mm512_set1_ps(*a.get_unchecked((i + 4) * k + ki));
            c4 = _mm512_fmadd_ps(a4, b0, c4);

            let a5 = _mm512_set1_ps(*a.get_unchecked((i + 5) * k + ki));
            c5 = _mm512_fmadd_ps(a5, b0, c5);

            let a6 = _mm512_set1_ps(*a.get_unchecked((i + 6) * k + ki));
            c6 = _mm512_fmadd_ps(a6, b0, c6);

            let a7 = _mm512_set1_ps(*a.get_unchecked((i + 7) * k + ki));
            c7 = _mm512_fmadd_ps(a7, b0, c7);
        }

        let c_ptr = c.as_mut_ptr();

        let c0_ptr = c_ptr.add(i * n + j);
        _mm512_storeu_ps(c0_ptr, _mm512_fmadd_ps(alpha, c0, _mm512_loadu_ps(c0_ptr)));

        let c1_ptr = c_ptr.add((i + 1) * n + j);
        _mm512_storeu_ps(c1_ptr, _mm512_fmadd_ps(alpha, c1, _mm512_loadu_ps(c1_ptr)));

        let c2_ptr = c_ptr.add((i + 2) * n + j);
        _mm512_storeu_ps(c2_ptr, _mm512_fmadd_ps(alpha, c2, _mm512_loadu_ps(c2_ptr)));

        let c3_ptr = c_ptr.add((i + 3) * n + j);
        _mm512_storeu_ps(c3_ptr, _mm512_fmadd_ps(alpha, c3, _mm512_loadu_ps(c3_ptr)));

        let c4_ptr = c_ptr.add((i + 4) * n + j);
        _mm512_storeu_ps(c4_ptr, _mm512_fmadd_ps(alpha, c4, _mm512_loadu_ps(c4_ptr)));

        let c5_ptr = c_ptr.add((i + 5) * n + j);
        _mm512_storeu_ps(c5_ptr, _mm512_fmadd_ps(alpha, c5, _mm512_loadu_ps(c5_ptr)));

        let c6_ptr = c_ptr.add((i + 6) * n + j);
        _mm512_storeu_ps(c6_ptr, _mm512_fmadd_ps(alpha, c6, _mm512_loadu_ps(c6_ptr)));

        let c7_ptr = c_ptr.add((i + 7) * n + j);
        _mm512_storeu_ps(c7_ptr, _mm512_fmadd_ps(alpha, c7, _mm512_loadu_ps(c7_ptr)));
    }

    /// NEON optimized matrix multiplication.
    ///
    /// Uses configurable micro-kernel with FMA instructions.
    #[cfg(target_arch = "aarch64")]
    #[allow(clippy::too_many_arguments)]
    unsafe fn matmul_f32_neon(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        m: usize,
        k: usize,
        n: usize,
        alpha: f32,
        tile: &TileConfig,
    ) -> Result<(), BackendError> {
        let mr = tile.mr;
        let nr = tile.nr;
        let mc = tile.mc.min(m);
        let nc = tile.nc.min(n);
        let kc = tile.kc.min(k);

        let alpha_vec = vdupq_n_f32(alpha);

        // Macro-tile loop over C
        for i0 in (0..m).step_by(mc) {
            let i_end = (i0 + mc).min(m);
            for j0 in (0..n).step_by(nc) {
                let j_end = (j0 + nc).min(n);

                // K-tile loop
                for k0 in (0..k).step_by(kc) {
                    let k_end = (k0 + kc).min(k);

                    // Micro-tile loop: process MR rows x NR columns
                    let mut i = i0;
                    while i + mr <= i_end {
                        let mut j = j0;
                        while j + nr <= j_end {
                            // 4x8 micro-kernel
                            self.microkernel_neon_4x8(c, a, b, i, j, k0, k_end, k, n, alpha_vec);
                            j += nr;
                        }
                        // Handle remaining columns
                        while j < j_end {
                            for ii in i..i + mr {
                                let mut sum = 0.0f32;
                                for ki in k0..k_end {
                                    sum += a[ii * k + ki] * b[ki * n + j];
                                }
                                c[ii * n + j] += alpha * sum;
                            }
                            j += 1;
                        }
                        i += mr;
                    }
                    // Handle remaining rows
                    while i < i_end {
                        for j in j0..j_end {
                            let mut sum = 0.0f32;
                            for ki in k0..k_end {
                                sum += a[i * k + ki] * b[ki * n + j];
                            }
                            c[i * n + j] += alpha * sum;
                        }
                        i += 1;
                    }
                }
            }
        }
        Ok(())
    }

    /// NEON 4x8 micro-kernel using FMA.
    ///
    /// Processes 4 rows × 8 columns using 8 NEON registers for accumulators.
    #[cfg(target_arch = "aarch64")]
    #[allow(clippy::too_many_arguments)]
    unsafe fn microkernel_neon_4x8(
        &self,
        c: &mut [f32],
        a: &[f32],
        b: &[f32],
        i: usize,
        j: usize,
        k0: usize,
        k_end: usize,
        k: usize,
        n: usize,
        alpha: float32x4_t,
    ) {
        // 8 accumulators: 4 rows × 2 NEON registers (8 floats)
        let mut c00 = vdupq_n_f32(0.0);
        let mut c01 = vdupq_n_f32(0.0);
        let mut c10 = vdupq_n_f32(0.0);
        let mut c11 = vdupq_n_f32(0.0);
        let mut c20 = vdupq_n_f32(0.0);
        let mut c21 = vdupq_n_f32(0.0);
        let mut c30 = vdupq_n_f32(0.0);
        let mut c31 = vdupq_n_f32(0.0);

        // Reduction loop
        for ki in k0..k_end {
            // Load B row (8 floats = 2 NEON registers)
            let b_ptr = b.as_ptr().add(ki * n + j);
            let b0 = vld1q_f32(b_ptr);
            let b1 = vld1q_f32(b_ptr.add(4));

            // Broadcast each A element and FMA
            let a0 = vdupq_n_f32(*a.get_unchecked(i * k + ki));
            c00 = vfmaq_f32(c00, a0, b0);
            c01 = vfmaq_f32(c01, a0, b1);

            let a1 = vdupq_n_f32(*a.get_unchecked((i + 1) * k + ki));
            c10 = vfmaq_f32(c10, a1, b0);
            c11 = vfmaq_f32(c11, a1, b1);

            let a2 = vdupq_n_f32(*a.get_unchecked((i + 2) * k + ki));
            c20 = vfmaq_f32(c20, a2, b0);
            c21 = vfmaq_f32(c21, a2, b1);

            let a3 = vdupq_n_f32(*a.get_unchecked((i + 3) * k + ki));
            c30 = vfmaq_f32(c30, a3, b0);
            c31 = vfmaq_f32(c31, a3, b1);
        }

        // Scale by alpha and accumulate to C
        let c_ptr = c.as_mut_ptr();

        // Row 0
        let c0_ptr = c_ptr.add(i * n + j);
        let old0 = vld1q_f32(c0_ptr);
        let old1 = vld1q_f32(c0_ptr.add(4));
        vst1q_f32(c0_ptr, vfmaq_f32(old0, alpha, c00));
        vst1q_f32(c0_ptr.add(4), vfmaq_f32(old1, alpha, c01));

        // Row 1
        let c1_ptr = c_ptr.add((i + 1) * n + j);
        let old0 = vld1q_f32(c1_ptr);
        let old1 = vld1q_f32(c1_ptr.add(4));
        vst1q_f32(c1_ptr, vfmaq_f32(old0, alpha, c10));
        vst1q_f32(c1_ptr.add(4), vfmaq_f32(old1, alpha, c11));

        // Row 2
        let c2_ptr = c_ptr.add((i + 2) * n + j);
        let old0 = vld1q_f32(c2_ptr);
        let old1 = vld1q_f32(c2_ptr.add(4));
        vst1q_f32(c2_ptr, vfmaq_f32(old0, alpha, c20));
        vst1q_f32(c2_ptr.add(4), vfmaq_f32(old1, alpha, c21));

        // Row 3
        let c3_ptr = c_ptr.add((i + 3) * n + j);
        let old0 = vld1q_f32(c3_ptr);
        let old1 = vld1q_f32(c3_ptr.add(4));
        vst1q_f32(c3_ptr, vfmaq_f32(old0, alpha, c30));
        vst1q_f32(c3_ptr.add(4), vfmaq_f32(old1, alpha, c31));
    }

    // ========================================================================
    // CONVOLUTION KERNELS
    // ========================================================================

    /// 2D convolution with automatic algorithm selection.
    ///
    /// Selects the best algorithm based on kernel size and stride:
    /// - **Winograd F(2,3)**: For 3x3 kernels with stride 1 (4-6x faster)
    /// - **Im2Col + GEMM**: For all other cases
    #[allow(clippy::too_many_arguments)]
    pub fn conv2d_f32(
        &self,
        output: &mut [f32],
        input: &[f32],
        kernel: &[f32],
        bias: Option<&[f32]>,
        batch: usize,
        in_channels: usize,
        in_height: usize,
        in_width: usize,
        out_channels: usize,
        kernel_h: usize,
        kernel_w: usize,
        out_height: usize,
        out_width: usize,
        stride_h: usize,
        stride_w: usize,
        pad_h: usize,
        pad_w: usize,
    ) -> Result<(), BackendError> {
        // TEMPORARILY DISABLED: Winograd filter transform overhead is too high.
        // The current implementation transforms filters on every call, which is
        // 6-20x slower than Im2Col+GEMM. To re-enable Winograd with proper performance:
        // 1. Cache transformed filters in a static or thread-local cache
        // 2. Key by filter pointer + dimensions to avoid redundant transforms
        // 3. Use conv2d_f32_winograd() for 3x3 stride-1 kernels
        //
        // Re-enable by caching transformed filters keyed by filter pointer + dimensions.

        // Use Im2Col + GEMM for all cases (fast path)
        self.conv2d_f32_im2col(
            output,
            input,
            kernel,
            bias,
            batch,
            in_channels,
            in_height,
            in_width,
            out_channels,
            kernel_h,
            kernel_w,
            out_height,
            out_width,
            stride_h,
            stride_w,
            pad_h,
            pad_w,
        )
    }

    /// Winograd F(2,3) convolution for 3x3 kernels with stride 1.
    ///
    /// Transforms filters on-the-fly. For pre-transformed filters, use
    /// `winograd::winograd_conv2d_f23` directly with a `PrepackedFilter`.
    ///
    /// NOTE: Currently unused - disabled due to filter transform overhead.
    /// Will be re-enabled once filter caching is implemented.
    #[allow(dead_code, clippy::too_many_arguments)]
    fn conv2d_f32_winograd(
        &self,
        output: &mut [f32],
        input: &[f32],
        kernel: &[f32],
        bias: Option<&[f32]>,
        batch: usize,
        in_channels: usize,
        in_height: usize,
        in_width: usize,
        out_channels: usize,
        out_height: usize,
        out_width: usize,
        pad_h: usize,
        pad_w: usize,
    ) -> Result<(), BackendError> {
        use crate::layout::WinogradVariant;
        use crate::transform_cache::{FilterId, TransformCache};

        // Transform filter on-the-fly
        let mut cache = TransformCache::new();
        cache.add_winograd_filter(
            FilterId(0),
            kernel,
            [out_channels, in_channels, 3, 3],
            WinogradVariant::F23,
        );

        let prepacked = cache
            .get_winograd_filter(FilterId(0))
            .ok_or_else(|| BackendError::execution("Failed to create Winograd filter"))?;

        // Call Winograd convolution
        super::winograd::winograd_conv2d_f23(
            output,
            input,
            prepacked,
            bias,
            batch,
            in_channels,
            in_height,
            in_width,
            out_channels,
            out_height,
            out_width,
            pad_h,
            pad_w,
        );

        Ok(())
    }

    /// Im2Col + GEMM convolution (fallback for non-3x3 or non-stride-1).
    #[allow(clippy::too_many_arguments)]
    fn conv2d_f32_im2col(
        &self,
        output: &mut [f32],
        input: &[f32],
        kernel: &[f32],
        bias: Option<&[f32]>,
        batch: usize,
        in_channels: usize,
        in_height: usize,
        in_width: usize,
        out_channels: usize,
        kernel_h: usize,
        kernel_w: usize,
        out_height: usize,
        out_width: usize,
        stride_h: usize,
        stride_w: usize,
        pad_h: usize,
        pad_w: usize,
    ) -> Result<(), BackendError> {
        const CONV_PARALLEL_MIN_WORK: usize = 512 * 512; // heuristic on output elements

        let m = out_channels;
        let n = out_height * out_width;
        let k_dim = in_channels * kernel_h * kernel_w;
        let total_work = batch
            .saturating_mul(out_channels)
            .saturating_mul(out_height * out_width);

        if cfg!(feature = "parallel") && total_work >= CONV_PARALLEL_MIN_WORK {
            #[cfg(feature = "parallel")]
            {
                use rayon::prelude::*;
                let bias_opt = bias;
                let input_stride = in_channels * in_height * in_width;
                let output_stride = out_channels * out_height * out_width;

                return output
                    .par_chunks_mut(output_stride)
                    .zip((0..batch).into_par_iter())
                    .try_for_each(|(output_slice, b)| {
                        let mut col = vec![0.0f32; k_dim * n];
                        let input_offset = b * input_stride;
                        let input_slice = &input[input_offset..input_offset + input_stride];

                        timed!("cpu_im2col_ms", {
                            self.im2col_f32(
                                &mut col,
                                input_slice,
                                in_channels,
                                in_height,
                                in_width,
                                kernel_h,
                                kernel_w,
                                out_height,
                                out_width,
                                stride_h,
                                stride_w,
                                pad_h,
                                pad_w,
                            )
                        })?;

                        timed!("cpu_conv_matmul_ms", {
                            self.matmul_f32(output_slice, kernel, &col, m, k_dim, n, 1.0, 0.0)
                        })?;

                        if let Some(bias) = bias_opt {
                            if bias.len() != out_channels {
                                return Err(BackendError::buffer(
                                    "Bias length does not match out_channels",
                                ));
                            }
                            for oc in 0..out_channels {
                                let bias_val = bias[oc];
                                for spatial in 0..n {
                                    output_slice[oc * n + spatial] += bias_val;
                                }
                            }
                        }

                        Ok(())
                    });
            }
        }

        for b in 0..batch {
            let mut col = vec![0.0f32; k_dim * n];

            timed!("cpu_im2col_ms", {
                self.im2col_f32(
                    &mut col,
                    &input[b * in_channels * in_height * in_width..],
                    in_channels,
                    in_height,
                    in_width,
                    kernel_h,
                    kernel_w,
                    out_height,
                    out_width,
                    stride_h,
                    stride_w,
                    pad_h,
                    pad_w,
                )
            })?;

            let output_offset = b * out_channels * out_height * out_width;
            let output_slice = &mut output[output_offset..output_offset + m * n];

            timed!("cpu_conv_matmul_ms", {
                self.matmul_f32(output_slice, kernel, &col, m, k_dim, n, 1.0, 0.0)
            })?;

            if let Some(bias) = bias {
                for oc in 0..out_channels {
                    let bias_val = bias[oc];
                    for spatial in 0..n {
                        output_slice[oc * n + spatial] += bias_val;
                    }
                }
            }
        }

        Ok(())
    }

    /// Im2col transformation for convolution.
    #[allow(clippy::too_many_arguments)]
    fn im2col_f32(
        &self,
        col: &mut [f32],
        input: &[f32],
        in_channels: usize,
        in_height: usize,
        in_width: usize,
        kernel_h: usize,
        kernel_w: usize,
        out_height: usize,
        out_width: usize,
        stride_h: usize,
        stride_w: usize,
        pad_h: usize,
        pad_w: usize,
    ) -> Result<(), BackendError> {
        let k_dim = in_channels * kernel_h * kernel_w;
        let n_dim = out_height * out_width;

        for c in 0..in_channels {
            for kh in 0..kernel_h {
                for kw in 0..kernel_w {
                    let col_row = c * kernel_h * kernel_w + kh * kernel_w + kw;

                    for oh in 0..out_height {
                        for ow in 0..out_width {
                            let col_col = oh * out_width + ow;

                            // Calculate input position
                            let ih = oh * stride_h + kh;
                            let iw = ow * stride_w + kw;

                            // Handle padding
                            let in_ih = ih as isize - pad_h as isize;
                            let in_iw = iw as isize - pad_w as isize;

                            let val = if in_ih >= 0
                                && in_ih < in_height as isize
                                && in_iw >= 0
                                && in_iw < in_width as isize
                            {
                                let in_idx = c * in_height * in_width
                                    + in_ih as usize * in_width
                                    + in_iw as usize;
                                input[in_idx]
                            } else {
                                0.0
                            };

                            col[col_row * n_dim + col_col] = val;
                        }
                    }
                }
            }
        }

        // Verify column buffer was filled correctly
        debug_assert!(col.len() >= k_dim * n_dim);
        Ok(())
    }
}

/// Standalone conv2d function for use by other modules.
///
/// Creates a dispatcher and delegates to its conv2d_f32 method.
pub fn conv2d_f32_direct(
    output: &mut [f32],
    input: &[f32],
    kernel: &[f32],
    bias: Option<&[f32]>,
    params: &crate::Conv2DParams,
) -> Result<(), BackendError> {
    let dispatcher = SimdDispatcher::new();

    let batch = params.input_dims[0] as usize;
    let in_channels = params.input_dims[1] as usize;
    let in_height = params.input_dims[2] as usize;
    let in_width = params.input_dims[3] as usize;
    let out_channels = params.kernel_dims[0] as usize;
    let kernel_h = params.kernel_dims[2] as usize;
    let kernel_w = params.kernel_dims[3] as usize;
    let out_dims = params.output_dims();
    let out_height = out_dims[2] as usize;
    let out_width = out_dims[3] as usize;
    let stride_h = params.stride[0] as usize;
    let stride_w = params.stride[1] as usize;
    let pad_h = params.padding[0] as usize;
    let pad_w = params.padding[1] as usize;

    dispatcher.conv2d_f32(
        output,
        input,
        kernel,
        bias,
        batch,
        in_channels,
        in_height,
        in_width,
        out_channels,
        kernel_h,
        kernel_w,
        out_height,
        out_width,
        stride_h,
        stride_w,
        pad_h,
        pad_w,
    )
}

impl Default for SimdDispatcher {
    fn default() -> Self {
        Self::new()
    }
}

// ============================================================================
// TESTS
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    // ========================================================================
    // STATIC KERNEL TABLE TESTS
    // ========================================================================

    #[test]
    fn test_cpu_capability_cached() {
        // First call initializes
        let cap1 = cpu_capability();
        // Second call returns cached value
        let cap2 = cpu_capability();
        assert_eq!(cap1, cap2);
    }

    #[test]
    fn test_cpu_kernels_cached() {
        // First call initializes
        let kernels1 = cpu_kernels();
        // Second call returns same reference
        let kernels2 = cpu_kernels();
        assert!(std::ptr::eq(kernels1, kernels2));
    }

    #[test]
    fn test_cpu_kernels_consistency() {
        let kernels = cpu_kernels();
        let cap = cpu_capability();

        // Kernel table capability should match global capability
        assert_eq!(kernels.capability, cap);

        // Tile config should be valid
        assert!(kernels.tile_config.is_valid());

        // Register sizes should be consistent
        assert_eq!(kernels.floats_per_register, cap.floats_per_register());
        assert_eq!(kernels.bytes_per_register, cap.bytes_per_register());
    }

    #[test]
    fn test_cpu_kernel_table_micro_dims() {
        let kernels = cpu_kernels();
        let (mr, nr) = kernels.micro_kernel_dims();

        assert!(mr > 0);
        assert!(nr > 0);
        assert!(mr <= kernels.tile_config.mc);
        assert!(nr <= kernels.tile_config.nc);
    }

    #[test]
    fn test_cpu_kernel_table_macro_dims() {
        let kernels = cpu_kernels();
        let (mc, nc, kc) = kernels.macro_tile_dims();

        assert!(mc > 0);
        assert!(nc > 0);
        assert!(kc > 0);
    }

    // ========================================================================
    // TILE CONFIGURATION TESTS
    // ========================================================================

    #[test]
    fn test_tile_config_new() {
        let config = TileConfig::new(6, 16, 72, 256, 256);
        assert_eq!(config.mr, 6);
        assert_eq!(config.nr, 16);
        assert_eq!(config.mc, 72);
        assert_eq!(config.nc, 256);
        assert_eq!(config.kc, 256);
    }

    #[test]
    fn test_tile_config_presets() {
        // AVX2 preset
        let avx2 = TileConfig::avx2();
        assert_eq!(avx2.mr, 6);
        assert_eq!(avx2.nr, 16);
        assert!(avx2.is_valid());

        // NEON preset
        let neon = TileConfig::neon();
        assert_eq!(neon.mr, 4);
        assert_eq!(neon.nr, 8);
        assert!(neon.is_valid());

        // Scalar preset
        let scalar = TileConfig::scalar();
        assert!(scalar.is_valid());

        // Small preset
        let small = TileConfig::small();
        assert!(small.is_valid());
    }

    #[test]
    fn test_tile_config_is_valid() {
        // Valid config
        let valid = TileConfig::new(4, 8, 64, 128, 256);
        assert!(valid.is_valid());

        // Invalid: MC not divisible by MR
        let invalid1 = TileConfig::new(4, 8, 65, 128, 256);
        assert!(!invalid1.is_valid());

        // Invalid: NC not divisible by NR
        let invalid2 = TileConfig::new(4, 8, 64, 129, 256);
        assert!(!invalid2.is_valid());

        // Invalid: zero MR
        let invalid3 = TileConfig::new(0, 8, 64, 128, 256);
        assert!(!invalid3.is_valid());
    }

    #[test]
    fn test_tile_config_auto_select() {
        // Small matrix with AVX2 - still uses AVX2 micro-kernel size
        let small_avx2 = TileConfig::auto_select(8, 8, 8, SimdCapability::Avx2);
        assert_eq!(small_avx2.mr, 6); // AVX2 micro-kernel size preserved
        assert_eq!(small_avx2.nr, 16);
        assert!(small_avx2.is_valid());

        // Small matrix with NEON - uses NEON micro-kernel size
        let small_neon = TileConfig::auto_select(8, 8, 8, SimdCapability::Neon);
        assert_eq!(small_neon.mr, 4); // NEON micro-kernel size preserved
        assert_eq!(small_neon.nr, 8);
        assert!(small_neon.is_valid());

        // Small matrix with scalar
        let small_scalar = TileConfig::auto_select(8, 8, 8, SimdCapability::Scalar);
        assert_eq!(small_scalar.mr, 1);
        assert_eq!(small_scalar.nr, 4);
        assert!(small_scalar.is_valid());

        // Large matrix with AVX2
        let large_avx2 = TileConfig::auto_select(256, 256, 256, SimdCapability::Avx2);
        assert_eq!(large_avx2.mr, 6);
        assert_eq!(large_avx2.nr, 16);
        assert!(large_avx2.is_valid());

        // Large matrix with NEON
        let large_neon = TileConfig::auto_select(256, 256, 256, SimdCapability::Neon);
        assert_eq!(large_neon.mr, 4);
        assert_eq!(large_neon.nr, 8);
        assert!(large_neon.is_valid());
    }

    // ========================================================================
    // SIMD CAPABILITY TESTS
    // ========================================================================

    #[test]
    fn test_simd_capability_detect() {
        let cap = SimdCapability::detect();
        // Should return some valid capability
        assert!(matches!(
            cap,
            SimdCapability::Scalar
                | SimdCapability::Sse42
                | SimdCapability::Avx2
                | SimdCapability::Avx512
                | SimdCapability::Neon
        ));
    }

    #[test]
    fn test_simd_capability_floats() {
        assert_eq!(SimdCapability::Scalar.floats_per_register(), 1);
        assert_eq!(SimdCapability::Sse42.floats_per_register(), 4);
        assert_eq!(SimdCapability::Avx2.floats_per_register(), 8);
        assert_eq!(SimdCapability::Avx512.floats_per_register(), 16);
        assert_eq!(SimdCapability::Neon.floats_per_register(), 4);
    }

    #[test]
    fn test_simd_capability_bytes() {
        assert_eq!(SimdCapability::Scalar.bytes_per_register(), 4);
        assert_eq!(SimdCapability::Sse42.bytes_per_register(), 16);
        assert_eq!(SimdCapability::Avx2.bytes_per_register(), 32);
        assert_eq!(SimdCapability::Avx512.bytes_per_register(), 64);
        assert_eq!(SimdCapability::Neon.bytes_per_register(), 16);
    }

    #[test]
    fn test_simd_capability_ordering() {
        // Scalar < SSE < AVX2 < AVX512
        assert!(SimdCapability::Scalar < SimdCapability::Sse42);
        assert!(SimdCapability::Sse42 < SimdCapability::Avx2);
        assert!(SimdCapability::Avx2 < SimdCapability::Avx512);
    }

    // ========================================================================
    // DISPATCHER TESTS
    // ========================================================================

    #[test]
    fn test_dispatcher_new() {
        let dispatcher = SimdDispatcher::new();
        let _ = dispatcher.capability(); // Should not panic
    }

    #[test]
    fn test_dispatcher_default() {
        let d1 = SimdDispatcher::new();
        let d2 = SimdDispatcher::default();
        assert_eq!(d1.capability(), d2.capability());
    }

    // ========================================================================
    // MATRIX MULTIPLICATION TESTS
    // ========================================================================

    #[test]
    fn test_matmul_f32_scalar() {
        let dispatcher = SimdDispatcher::with_capability(SimdCapability::Scalar);

        // 2x3 @ 3x2 = 2x2
        let a = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0];
        let b = vec![7.0, 8.0, 9.0, 10.0, 11.0, 12.0];
        let mut c = vec![0.0; 4];

        dispatcher
            .matmul_f32(&mut c, &a, &b, 2, 3, 2, 1.0, 0.0)
            .unwrap();

        // Expected: [[1*7+2*9+3*11, 1*8+2*10+3*12], [4*7+5*9+6*11, 4*8+5*10+6*12]]
        //         = [[7+18+33, 8+20+36], [28+45+66, 32+50+72]]
        //         = [[58, 64], [139, 154]]
        assert_eq!(c[0], 58.0);
        assert_eq!(c[1], 64.0);
        assert_eq!(c[2], 139.0);
        assert_eq!(c[3], 154.0);
    }

    #[test]
    fn test_matmul_f32_with_scaling() {
        let dispatcher = SimdDispatcher::with_capability(SimdCapability::Scalar);

        // Simple 2x2 identity test
        let a = vec![1.0, 0.0, 0.0, 1.0];
        let b = vec![2.0, 3.0, 4.0, 5.0];
        let mut c = vec![10.0, 20.0, 30.0, 40.0];

        // C = 0.5 * A @ B + 1.0 * C
        dispatcher
            .matmul_f32(&mut c, &a, &b, 2, 2, 2, 0.5, 1.0)
            .unwrap();

        // A @ B = [[2, 3], [4, 5]]
        // 0.5 * A @ B = [[1, 1.5], [2, 2.5]]
        // + C = [[11, 21.5], [32, 42.5]]
        assert_eq!(c[0], 11.0);
        assert_eq!(c[1], 21.5);
        assert_eq!(c[2], 32.0);
        assert_eq!(c[3], 42.5);
    }

    #[test]
    fn test_conv2d_f32_simple() {
        let dispatcher = SimdDispatcher::with_capability(SimdCapability::Scalar);

        // 1x1x3x3 input, 1x1x2x2 kernel, no padding, stride 1
        // Output should be 1x1x2x2
        let input = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0];
        let kernel = vec![1.0, 0.0, 0.0, 1.0]; // 2x2 identity-ish kernel
        let mut output = vec![0.0; 4];

        dispatcher
            .conv2d_f32(
                &mut output,
                &input,
                &kernel,
                None,
                1, // batch
                1, // in_channels
                3, // in_height
                3, // in_width
                1, // out_channels
                2, // kernel_h
                2, // kernel_w
                2, // out_height
                2, // out_width
                1, // stride_h
                1, // stride_w
                0, // pad_h
                0, // pad_w
            )
            .unwrap();

        // Kernel [1, 0, 0, 1] applied to:
        // [1, 2]  -> 1*1 + 2*0 + 4*0 + 5*1 = 6
        // [4, 5]
        // [2, 3]  -> 2*1 + 3*0 + 5*0 + 6*1 = 8
        // [5, 6]
        // etc.
        assert_eq!(output[0], 6.0);
        assert_eq!(output[1], 8.0);
        assert_eq!(output[2], 12.0);
        assert_eq!(output[3], 14.0);
    }

    #[test]
    fn test_conv2d_f32_with_bias() {
        let dispatcher = SimdDispatcher::with_capability(SimdCapability::Scalar);

        let input = vec![1.0, 2.0, 3.0, 4.0];
        let kernel = vec![1.0]; // 1x1 kernel
        let bias = vec![10.0];
        let mut output = vec![0.0; 4];

        dispatcher
            .conv2d_f32(
                &mut output,
                &input,
                &kernel,
                Some(&bias),
                1,
                1,
                2,
                2,
                1,
                1,
                1,
                2,
                2,
                1,
                1,
                0,
                0,
            )
            .unwrap();

        // Each output = input * 1.0 + 10.0
        assert_eq!(output[0], 11.0);
        assert_eq!(output[1], 12.0);
        assert_eq!(output[2], 13.0);
        assert_eq!(output[3], 14.0);
    }

    // ========================================================================
    // MATMUL WITH CUSTOM CONFIG TESTS
    // ========================================================================

    #[test]
    fn test_matmul_with_custom_config() {
        let dispatcher = SimdDispatcher::with_capability(SimdCapability::Scalar);

        // Use a custom tile configuration
        let custom_tile = TileConfig::new(2, 2, 4, 4, 4);

        // 4x4 @ 4x4 = 4x4
        let a: Vec<f32> = (1..=16).map(|x| x as f32).collect();
        let b: Vec<f32> = (1..=16).map(|x| x as f32).collect();
        let mut c = [0.0f32; 16];

        dispatcher
            .matmul_f32_with_config(&mut c, &a, &b, 4, 4, 4, 1.0, 0.0, &custom_tile)
            .unwrap();

        // Verify result against scalar computation
        let mut expected = [0.0f32; 16];
        for i in 0..4 {
            for j in 0..4 {
                for ki in 0..4 {
                    expected[i * 4 + j] += a[i * 4 + ki] * b[ki * 4 + j];
                }
            }
        }

        for i in 0..16 {
            assert!((c[i] - expected[i]).abs() < 1e-5, "Mismatch at {i}");
        }
    }

    #[test]
    fn test_matmul_larger_matrix() {
        let dispatcher = SimdDispatcher::new(); // Use auto-detected SIMD

        // 32x32 @ 32x32 = 32x32
        let m = 32;
        let k = 32;
        let n = 32;
        let a: Vec<f32> = (0..m * k).map(|x| (x as f32) * 0.01).collect();
        let b: Vec<f32> = (0..k * n).map(|x| (x as f32) * 0.01).collect();
        let mut c = vec![0.0f32; m * n];

        dispatcher
            .matmul_f32(&mut c, &a, &b, m, k, n, 1.0, 0.0)
            .unwrap();

        // Verify against scalar reference
        let scalar_dispatcher = SimdDispatcher::with_capability(SimdCapability::Scalar);
        let mut expected = vec![0.0f32; m * n];
        scalar_dispatcher
            .matmul_f32(&mut expected, &a, &b, m, k, n, 1.0, 0.0)
            .unwrap();

        for i in 0..m * n {
            assert!(
                (c[i] - expected[i]).abs() < 1e-3,
                "Mismatch at {i}: got {}, expected {}",
                c[i],
                expected[i]
            );
        }
    }

    #[test]
    fn test_matmul_non_square() {
        let dispatcher = SimdDispatcher::new();

        // 64x128 @ 128x48 = 64x48
        let m = 64;
        let k = 128;
        let n = 48;
        let a: Vec<f32> = (0..m * k).map(|x| ((x % 10) as f32) * 0.1).collect();
        let b: Vec<f32> = (0..k * n).map(|x| ((x % 10) as f32) * 0.1).collect();
        let mut c = vec![0.0f32; m * n];

        dispatcher
            .matmul_f32(&mut c, &a, &b, m, k, n, 1.0, 0.0)
            .unwrap();

        // Verify against scalar reference
        let scalar_dispatcher = SimdDispatcher::with_capability(SimdCapability::Scalar);
        let mut expected = vec![0.0f32; m * n];
        scalar_dispatcher
            .matmul_f32(&mut expected, &a, &b, m, k, n, 1.0, 0.0)
            .unwrap();

        for i in 0..m * n {
            assert!(
                (c[i] - expected[i]).abs() < 1e-2,
                "Mismatch at {i}: got {}, expected {}",
                c[i],
                expected[i]
            );
        }
    }

    #[test]
    fn test_matmul_beta_accumulate() {
        let dispatcher = SimdDispatcher::new();

        // Test beta accumulation
        let m = 16;
        let k = 16;
        let n = 16;
        let a: Vec<f32> = vec![1.0; m * k];
        let b: Vec<f32> = vec![1.0; k * n];
        let mut c: Vec<f32> = vec![10.0; m * n];

        // C = 2.0 * A @ B + 0.5 * C
        // A @ B = 16.0 (each element)
        // 2.0 * 16.0 + 0.5 * 10.0 = 32.0 + 5.0 = 37.0
        dispatcher
            .matmul_f32(&mut c, &a, &b, m, k, n, 2.0, 0.5)
            .unwrap();

        for val in c.iter() {
            assert!((val - 37.0).abs() < 1e-5, "Expected 37.0, got {val}");
        }
    }

    // ========================================================================
    // SIMD VERIFICATION TESTS
    // ========================================================================

    #[test]
    fn test_native_simd_matches_scalar() {
        // Test that native SIMD implementation matches scalar for correctness
        let native = SimdDispatcher::new();
        let scalar = SimdDispatcher::with_capability(SimdCapability::Scalar);

        // If native is scalar, skip this test
        if native.capability() == SimdCapability::Scalar {
            return;
        }

        let m = 48;
        let k = 64;
        let n = 32;
        let a: Vec<f32> = (0..m * k).map(|x| (x as f32) * 0.001).collect();
        let b: Vec<f32> = (0..k * n).map(|x| (x as f32) * 0.001).collect();

        let mut c_native = vec![0.0f32; m * n];
        let mut c_scalar = vec![0.0f32; m * n];

        native
            .matmul_f32(&mut c_native, &a, &b, m, k, n, 1.0, 0.0)
            .unwrap();
        scalar
            .matmul_f32(&mut c_scalar, &a, &b, m, k, n, 1.0, 0.0)
            .unwrap();

        for i in 0..m * n {
            assert!(
                (c_native[i] - c_scalar[i]).abs() < 1e-2,
                "Native SIMD mismatch at {i}: native={}, scalar={}",
                c_native[i],
                c_scalar[i]
            );
        }
    }

    #[test]
    fn test_matmul_error_handling() {
        let dispatcher = SimdDispatcher::new();

        // Buffer too small for A
        let a = vec![1.0; 4];
        let b = vec![1.0; 16];
        let mut c = vec![0.0; 16];
        assert!(dispatcher
            .matmul_f32(&mut c, &a, &b, 4, 4, 4, 1.0, 0.0)
            .is_err());

        // Buffer too small for B
        let a = vec![1.0; 16];
        let b = vec![1.0; 4];
        assert!(dispatcher
            .matmul_f32(&mut c, &a, &b, 4, 4, 4, 1.0, 0.0)
            .is_err());

        // Buffer too small for C
        let mut c = vec![0.0; 4];
        let b = vec![1.0; 16];
        assert!(dispatcher
            .matmul_f32(&mut c, &a, &b, 4, 4, 4, 1.0, 0.0)
            .is_err());
    }
}
