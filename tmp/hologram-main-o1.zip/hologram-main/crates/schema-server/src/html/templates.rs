//! HTML template strings.

/// Base HTML wrapper.
pub fn base(title: &str, content: &str) -> String {
    format!(
        r#"<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - UOR Schema</title>
    <style>
        :root {{
            --bg: #fafafa;
            --text: #222;
            --link: #0066cc;
            --border: #ddd;
            --card-bg: #fff;
            --code-bg: #f5f5f5;
        }}
        @media (prefers-color-scheme: dark) {{
            :root {{
                --bg: #1a1a1a;
                --text: #eee;
                --link: #6db3f2;
                --border: #444;
                --card-bg: #2a2a2a;
                --code-bg: #333;
            }}
        }}
        * {{ box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            background: var(--bg);
            color: var(--text);
        }}
        a {{ color: var(--link); text-decoration: none; }}
        a:hover {{ text-decoration: underline; }}
        nav {{
            padding: 1rem 0;
            border-bottom: 1px solid var(--border);
            margin-bottom: 2rem;
        }}
        nav a {{ margin-right: 1.5rem; font-weight: 500; }}
        h1 {{ margin-top: 0; }}
        .card {{
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1rem;
        }}
        .card h3 {{ margin-top: 0; }}
        .grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1rem;
        }}
        .property {{
            display: flex;
            padding: 0.5rem 0;
            border-bottom: 1px solid var(--border);
        }}
        .property:last-child {{ border-bottom: none; }}
        .property-label {{
            font-weight: 600;
            width: 140px;
            flex-shrink: 0;
        }}
        .property-value {{ word-break: break-word; }}
        .braille {{
            font-size: 3rem;
            line-height: 1;
        }}
        .braille-grid {{
            display: grid;
            grid-template-columns: repeat(16, 1fr);
            gap: 0.5rem;
            text-align: center;
        }}
        .braille-cell {{
            padding: 0.5rem;
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 4px;
        }}
        .braille-cell:hover {{
            background: var(--code-bg);
        }}
        .braille-cell .char {{ font-size: 1.5rem; }}
        .braille-cell .val {{ font-size: 0.75rem; color: #888; }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
        }}
        th, td {{
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }}
        th {{ font-weight: 600; background: var(--code-bg); }}
        code {{
            background: var(--code-bg);
            padding: 0.2rem 0.4rem;
            border-radius: 4px;
            font-family: 'SF Mono', Monaco, monospace;
        }}
        .tag {{
            display: inline-block;
            padding: 0.2rem 0.6rem;
            background: var(--code-bg);
            border-radius: 4px;
            font-size: 0.85rem;
            margin-right: 0.5rem;
        }}
        .tag.theta {{ background: #e3f2fd; color: #1565c0; }}
        .tag.psi {{ background: #f3e5f5; color: #7b1fa2; }}
        .tag.delta {{ background: #fff3e0; color: #e65100; }}
        @media (prefers-color-scheme: dark) {{
            .tag.theta {{ background: #1a237e; color: #90caf9; }}
            .tag.psi {{ background: #4a148c; color: #ce93d8; }}
            .tag.delta {{ background: #e65100; color: #ffe0b2; }}
        }}
        .breadcrumb {{
            font-size: 0.9rem;
            margin-bottom: 1rem;
            color: #888;
        }}
        .breadcrumb a {{ color: inherit; }}
    </style>
</head>
<body>
    <nav>
        <a href="/">Home</a>
        <a href="/schemas">Schemas</a>
        <a href="/taxons">Taxons</a>
        <a href="/domains">Domains</a>
        <a href="/constants">Constants</a>
        <a href="/gauge-tower">Gauge Tower</a>
    </nav>
    {content}
</body>
</html>"#,
        title = title,
        content = content
    )
}
